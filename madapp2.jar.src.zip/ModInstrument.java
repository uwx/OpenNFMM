/* ModInstrument - Decompiled by JODE extended
 * DragShot Software
 * JODE (c) 1998-2001 Jochen Hoenicke
 */
class ModInstrument
{
    String name;
    byte[] samples;
    int sample_length;
    int finetune_rate;
    int period_low_limit;
    int period_high_limit;
    int finetune_value;
    int volume;
    int repeat_point;
    int repeat_length;
}
