/* Mad - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Color;

public class Mad
{
    Medium m;
    Record rpd;
    xtGraphics xt;
    int cn = 0;
    int im = 0;
    int mxz = 0;
    int cxz = 0;
    CarDefine cd;
    boolean[] dominate = new boolean[8];
    boolean[] caught = new boolean[8];
    int pzy = 0;
    int pxy = 0;
    float speed = 0.0F;
    float forca = 0.0F;
    float[] scy = new float[4];
    float[] scz = new float[4];
    float[] scx = new float[4];
    float drag = 0.5F;
    boolean mtouch = false;
    boolean wtouch = false;
    int cntouch = 0;
    boolean capsized = false;
    int txz = 0;
    int fxz = 0;
    int pmlt = 1;
    int nmlt = 1;
    int dcnt = 0;
    int skid = 0;
    boolean pushed = false;
    boolean gtouch = false;
    boolean pl = false;
    boolean pr = false;
    boolean pd = false;
    boolean pu = false;
    int loop = 0;
    float ucomp = 0.0F;
    float dcomp = 0.0F;
    float lcomp = 0.0F;
    float rcomp = 0.0F;
    int lxz = 0;
    int travxy = 0;
    int travzy = 0;
    int travxz = 0;
    int trcnt = 0;
    int capcnt = 0;
    int srfcnt = 0;
    boolean rtab = false;
    boolean ftab = false;
    boolean btab = false;
    boolean surfer = false;
    float powerup = 0.0F;
    int xtpower = 0;
    float tilt = 0.0F;
    int[][] crank = new int[4][4];
    int[][] lcrank = new int[4][4];
    int squash = 0;
    int nbsq = 0;
    int hitmag = 0;
    int cntdest = 0;
    boolean dest = false;
    boolean newcar = false;
    int pan = 0;
    int pcleared = 0;
    int clear = 0;
    int nlaps = 0;
    int focus = -1;
    float power = 75.0F;
    int missedcp = 0;
    int lastcolido = 0;
    int point = 0;
    boolean nofocus = false;
    int rpdcatch = 0;
    int newedcar = 0;
    int fixes = -1;
    int shakedam = 0;
    int outshakedam = 0;
    boolean colidim = false;
    
    public Mad(CarDefine cardefine, Medium medium, Record record,
	       xtGraphics var_xtGraphics, int i) {
	((Mad) this).cd = cardefine;
	((Mad) this).m = medium;
	((Mad) this).rpd = record;
	((Mad) this).xt = var_xtGraphics;
	((Mad) this).im = i;
    }
    
    public void reseto(int i, ContO conto, CheckPoints checkpoints) {
	((Mad) this).cn = i;
	for (int i_0_ = 0; i_0_ < 8; i_0_++) {
	    ((Mad) this).dominate[i_0_] = false;
	    ((Mad) this).caught[i_0_] = false;
	}
	((Mad) this).mxz = 0;
	((Mad) this).cxz = 0;
	((Mad) this).pzy = 0;
	((Mad) this).pxy = 0;
	((Mad) this).speed = 0.0F;
	for (int i_1_ = 0; i_1_ < 4; i_1_++) {
	    ((Mad) this).scy[i_1_] = 0.0F;
	    ((Mad) this).scx[i_1_] = 0.0F;
	    ((Mad) this).scz[i_1_] = 0.0F;
	}
	((Mad) this).forca
	    = (((float) Math.sqrt((double) ((((ContO) conto).keyz[0]
					     * ((ContO) conto).keyz[0])
					    + (((ContO) conto).keyx[0]
					       * ((ContO) conto).keyx[0])))
		+ (float) Math.sqrt((double) ((((ContO) conto).keyz[1]
					       * ((ContO) conto).keyz[1])
					      + (((ContO) conto).keyx[1]
						 * ((ContO) conto).keyx[1])))
		+ (float) Math.sqrt((double) ((((ContO) conto).keyz[2]
					       * ((ContO) conto).keyz[2])
					      + (((ContO) conto).keyx[2]
						 * ((ContO) conto).keyx[2])))
		+ (float) Math.sqrt((double) ((((ContO) conto).keyz[3]
					       * ((ContO) conto).keyz[3])
					      + (((ContO) conto).keyx[3]
						 * ((ContO) conto).keyx[3]))))
	       / 10000.0F
	       * (float) ((double) (((CarDefine) ((Mad) this).cd).bounce
				    [((Mad) this).cn])
			  - 0.3));
	((Mad) this).mtouch = false;
	((Mad) this).wtouch = false;
	((Mad) this).txz = 0;
	((Mad) this).fxz = 0;
	((Mad) this).pmlt = 1;
	((Mad) this).nmlt = 1;
	((Mad) this).dcnt = 0;
	((Mad) this).skid = 0;
	((Mad) this).pushed = false;
	((Mad) this).gtouch = false;
	((Mad) this).pl = false;
	((Mad) this).pr = false;
	((Mad) this).pd = false;
	((Mad) this).pu = false;
	((Mad) this).loop = 0;
	((Mad) this).ucomp = 0.0F;
	((Mad) this).dcomp = 0.0F;
	((Mad) this).lcomp = 0.0F;
	((Mad) this).rcomp = 0.0F;
	((Mad) this).lxz = 0;
	((Mad) this).travxy = 0;
	((Mad) this).travzy = 0;
	((Mad) this).travxz = 0;
	((Mad) this).rtab = false;
	((Mad) this).ftab = false;
	((Mad) this).btab = false;
	((Mad) this).powerup = 0.0F;
	((Mad) this).xtpower = 0;
	((Mad) this).trcnt = 0;
	((Mad) this).capcnt = 0;
	((Mad) this).tilt = 0.0F;
	for (int i_2_ = 0; i_2_ < 4; i_2_++) {
	    for (int i_3_ = 0; i_3_ < 4; i_3_++) {
		((Mad) this).crank[i_2_][i_3_] = 0;
		((Mad) this).lcrank[i_2_][i_3_] = 0;
	    }
	}
	((Mad) this).pan = 0;
	((Mad) this).pcleared = ((CheckPoints) checkpoints).pcs;
	((Mad) this).clear = 0;
	((Mad) this).nlaps = 0;
	((Mad) this).focus = -1;
	((Mad) this).missedcp = 0;
	((Mad) this).nofocus = false;
	((Mad) this).power = 98.0F;
	((Mad) this).lastcolido = 0;
	((CheckPoints) checkpoints).dested[((Mad) this).im] = 0;
	((Mad) this).squash = 0;
	((Mad) this).nbsq = 0;
	((Mad) this).hitmag = 0;
	((Mad) this).cntdest = 0;
	((Mad) this).dest = false;
	((Mad) this).newcar = false;
	if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
	    ((Medium) ((Mad) this).m).checkpoint = -1;
	    ((Medium) ((Mad) this).m).lastcheck = false;
	}
	((Mad) this).rpdcatch = 0;
	((Mad) this).newedcar = 0;
	((Mad) this).fixes = -1;
	if (((CheckPoints) checkpoints).nfix == 1)
	    ((Mad) this).fixes = 4;
	if (((CheckPoints) checkpoints).nfix == 2)
	    ((Mad) this).fixes = 3;
	if (((CheckPoints) checkpoints).nfix == 3)
	    ((Mad) this).fixes = 2;
	if (((CheckPoints) checkpoints).nfix == 4)
	    ((Mad) this).fixes = 1;
    }
    
    public void drive(Control control, ContO conto, Trackers trackers,
		      CheckPoints checkpoints) {
	int i = 1;
	int i_4_ = 1;
	boolean bool = false;
	boolean bool_5_ = false;
	boolean bool_6_ = false;
	((Mad) this).capsized = false;
	int i_7_;
	for (i_7_ = Math.abs(((Mad) this).pzy); i_7_ > 270; i_7_ -= 360) {
	    /* empty */
	}
	i_7_ = Math.abs(i_7_);
	if (i_7_ > 90)
	    bool = true;
	boolean bool_8_ = false;
	int i_9_;
	for (i_9_ = Math.abs(((Mad) this).pxy); i_9_ > 270; i_9_ -= 360) {
	    /* empty */
	}
	i_9_ = Math.abs(i_9_);
	if (i_9_ > 90) {
	    bool_8_ = true;
	    i_4_ = -1;
	}
	int i_10_ = ((ContO) conto).grat;
	if (bool) {
	    if (bool_8_) {
		bool_8_ = false;
		bool_5_ = true;
	    } else {
		bool_8_ = true;
		((Mad) this).capsized = true;
	    }
	    i = -1;
	} else if (bool_8_)
	    ((Mad) this).capsized = true;
	if (((Mad) this).capsized)
	    i_10_ = (((CarDefine) ((Mad) this).cd).flipy[((Mad) this).cn]
		     + ((Mad) this).squash);
	((Control) control).zyinv = bool;
	float f = 0.0F;
	float f_11_ = 0.0F;
	float f_12_ = 0.0F;
	if (((Mad) this).mtouch)
	    ((Mad) this).loop = 0;
	if (((Mad) this).wtouch) {
	    if (((Mad) this).loop == 2 || ((Mad) this).loop == -1) {
		((Mad) this).loop = -1;
		if (((Control) control).left)
		    ((Mad) this).pl = true;
		if (((Control) control).right)
		    ((Mad) this).pr = true;
		if (((Control) control).up)
		    ((Mad) this).pu = true;
		if (((Control) control).down)
		    ((Mad) this).pd = true;
	    }
	    ((Mad) this).ucomp = 0.0F;
	    ((Mad) this).dcomp = 0.0F;
	    ((Mad) this).lcomp = 0.0F;
	    ((Mad) this).rcomp = 0.0F;
	}
	if (((Control) control).handb) {
	    if (!((Mad) this).pushed) {
		if (!((Mad) this).wtouch) {
		    if (((Mad) this).loop == 0)
			((Mad) this).loop = 1;
		} else if (((Mad) this).gtouch)
		    ((Mad) this).pushed = true;
	    }
	} else
	    ((Mad) this).pushed = false;
	if (((Mad) this).loop == 1) {
	    float f_13_ = ((((Mad) this).scy[0] + ((Mad) this).scy[1]
			    + ((Mad) this).scy[2] + ((Mad) this).scy[3])
			   / 4.0F);
	    for (int i_14_ = 0; i_14_ < 4; i_14_++)
		((Mad) this).scy[i_14_] = f_13_;
	    ((Mad) this).loop = 2;
	}
	if (!((Mad) this).dest) {
	    if (((Mad) this).loop == 2) {
		if (((Control) control).up) {
		    if (((Mad) this).ucomp == 0.0F) {
			((Mad) this).ucomp
			    = 10.0F + (((Mad) this).scy[0] + 50.0F) / 20.0F;
			if (((Mad) this).ucomp < 5.0F)
			    ((Mad) this).ucomp = 5.0F;
			if (((Mad) this).ucomp > 10.0F)
			    ((Mad) this).ucomp = 10.0F;
			((Mad) this).ucomp *= (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
		    }
		    if (((Mad) this).ucomp < 20.0F)
			((Mad) this).ucomp
			    += 0.5 * (double) (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
		    f = ((float) -(((CarDefine) ((Mad) this).cd).airc
				   [((Mad) this).cn])
			 * ((Mad) this).m.sin(((ContO) conto).xz)
			 * (float) i_4_);
		    f_11_ = ((float) (((CarDefine) ((Mad) this).cd).airc
				      [((Mad) this).cn])
			     * ((Mad) this).m.cos(((ContO) conto).xz)
			     * (float) i_4_);
		} else if (((Mad) this).ucomp != 0.0F
			   && ((Mad) this).ucomp > -2.0F)
		    ((Mad) this).ucomp
			-= 0.5 * (double) (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
		if (((Control) control).down) {
		    if (((Mad) this).dcomp == 0.0F) {
			((Mad) this).dcomp
			    = 10.0F + (((Mad) this).scy[0] + 50.0F) / 20.0F;
			if (((Mad) this).dcomp < 5.0F)
			    ((Mad) this).dcomp = 5.0F;
			if (((Mad) this).dcomp > 10.0F)
			    ((Mad) this).dcomp = 10.0F;
			((Mad) this).dcomp *= (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
		    }
		    if (((Mad) this).dcomp < 20.0F)
			((Mad) this).dcomp
			    += 0.5 * (double) (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
		    f_12_ = (float) -(((CarDefine) ((Mad) this).cd).airc
				      [((Mad) this).cn]);
		} else if (((Mad) this).dcomp != 0.0F
			   && ((Mad) this).ucomp > -2.0F)
		    ((Mad) this).dcomp
			-= 0.5 * (double) (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
		if (((Control) control).left) {
		    if (((Mad) this).lcomp == 0.0F)
			((Mad) this).lcomp = 5.0F;
		    if (((Mad) this).lcomp < 20.0F)
			((Mad) this).lcomp
			    += 2.0F * (((CarDefine) ((Mad) this).cd).airs
				       [((Mad) this).cn]);
		    f = ((float) -(((CarDefine) ((Mad) this).cd).airc
				   [((Mad) this).cn])
			 * ((Mad) this).m.cos(((ContO) conto).xz) * (float) i);
		    f_11_ = ((float) -(((CarDefine) ((Mad) this).cd).airc
				       [((Mad) this).cn])
			     * ((Mad) this).m.sin(((ContO) conto).xz)
			     * (float) i);
		} else if (((Mad) this).lcomp > 0.0F)
		    ((Mad) this).lcomp -= 2.0F * (((CarDefine) ((Mad) this).cd)
						  .airs[((Mad) this).cn]);
		if (((Control) control).right) {
		    if (((Mad) this).rcomp == 0.0F)
			((Mad) this).rcomp = 5.0F;
		    if (((Mad) this).rcomp < 20.0F)
			((Mad) this).rcomp
			    += 2.0F * (((CarDefine) ((Mad) this).cd).airs
				       [((Mad) this).cn]);
		    f = ((float) (((CarDefine) ((Mad) this).cd).airc
				  [((Mad) this).cn])
			 * ((Mad) this).m.cos(((ContO) conto).xz) * (float) i);
		    f_11_ = ((float) (((CarDefine) ((Mad) this).cd).airc
				      [((Mad) this).cn])
			     * ((Mad) this).m.sin(((ContO) conto).xz)
			     * (float) i);
		} else if (((Mad) this).rcomp > 0.0F)
		    ((Mad) this).rcomp -= 2.0F * (((CarDefine) ((Mad) this).cd)
						  .airs[((Mad) this).cn]);
		((Mad) this).pzy += ((((Mad) this).dcomp - ((Mad) this).ucomp)
				     * ((Mad) this).m.cos(((Mad) this).pxy));
		if (bool)
		    ((ContO) conto).xz
			+= ((((Mad) this).dcomp - ((Mad) this).ucomp)
			    * ((Mad) this).m.sin(((Mad) this).pxy));
		else
		    ((ContO) conto).xz
			-= ((((Mad) this).dcomp - ((Mad) this).ucomp)
			    * ((Mad) this).m.sin(((Mad) this).pxy));
		((Mad) this).pxy += ((Mad) this).rcomp - ((Mad) this).lcomp;
	    } else {
		float f_15_ = ((Mad) this).power;
		if (f_15_ < 40.0F)
		    f_15_ = 40.0F;
		if (((Control) control).down) {
		    if (((Mad) this).speed > 0.0F)
			((Mad) this).speed
			    -= (float) ((((CarDefine) ((Mad) this).cd).handb
					 [((Mad) this).cn])
					/ 2);
		    else {
			int i_16_ = 0;
			for (int i_17_ = 0; i_17_ < 2; i_17_++) {
			    if (((Mad) this).speed
				<= -((float) ((((CarDefine) ((Mad) this).cd)
					       .swits[((Mad) this).cn][i_17_])
					      / 2)
				     + f_15_ * (float) (((CarDefine)
							 ((Mad) this).cd)
							.swits[((Mad) this).cn]
							[i_17_]) / 196.0F))
				i_16_++;
			}
			if (i_16_ != 2)
			    ((Mad) this).speed
				-= ((((CarDefine) ((Mad) this).cd).acelf
				     [((Mad) this).cn][i_16_]) / 2.0F
				    + f_15_ * (((CarDefine) ((Mad) this).cd)
					       .acelf[((Mad) this).cn]
					       [i_16_]) / 196.0F);
			else
			    ((Mad) this).speed
				= -((float) ((((CarDefine) ((Mad) this).cd)
					      .swits[((Mad) this).cn][1])
					     / 2)
				    + (f_15_
				       * (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn][1])
				       / 196.0F));
		    }
		}
		if (((Control) control).up) {
		    if (((Mad) this).speed < 0.0F)
			((Mad) this).speed
			    += (float) (((CarDefine) ((Mad) this).cd).handb
					[((Mad) this).cn]);
		    else {
			int i_18_ = 0;
			for (int i_19_ = 0; i_19_ < 3; i_19_++) {
			    if (((Mad) this).speed
				>= ((float) ((((CarDefine) ((Mad) this).cd)
					      .swits[((Mad) this).cn][i_19_])
					     / 2)
				    + (f_15_
				       * (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn]
						  [i_19_])
				       / 196.0F)))
				i_18_++;
			}
			if (i_18_ != 3)
			    ((Mad) this).speed
				+= ((((CarDefine) ((Mad) this).cd).acelf
				     [((Mad) this).cn][i_18_]) / 2.0F
				    + f_15_ * (((CarDefine) ((Mad) this).cd)
					       .acelf[((Mad) this).cn]
					       [i_18_]) / 196.0F);
			else
			    ((Mad) this).speed
				= ((float) ((((CarDefine) ((Mad) this).cd)
					     .swits[((Mad) this).cn][2])
					    / 2)
				   + (f_15_
				      * (float) (((CarDefine) ((Mad) this).cd)
						 .swits[((Mad) this).cn][2])
				      / 196.0F));
		    }
		}
		if (((Control) control).handb
		    && (Math.abs(((Mad) this).speed)
			> (float) (((CarDefine) ((Mad) this).cd).handb
				   [((Mad) this).cn]))) {
		    if (((Mad) this).speed < 0.0F)
			((Mad) this).speed
			    += (float) (((CarDefine) ((Mad) this).cd).handb
					[((Mad) this).cn]);
		    else
			((Mad) this).speed
			    -= (float) (((CarDefine) ((Mad) this).cd).handb
					[((Mad) this).cn]);
		}
		if (((Mad) this).loop == -1 && ((ContO) conto).y < 100) {
		    if (((Control) control).left) {
			if (!((Mad) this).pl) {
			    if (((Mad) this).lcomp == 0.0F)
				((Mad) this).lcomp
				    = 5.0F * (((CarDefine) ((Mad) this).cd)
					      .airs[((Mad) this).cn]);
			    if (((Mad) this).lcomp < 20.0F)
				((Mad) this).lcomp
				    += 2.0F * (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
			}
		    } else {
			if (((Mad) this).lcomp > 0.0F)
			    ((Mad) this).lcomp
				-= 2.0F * (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
			((Mad) this).pl = false;
		    }
		    if (((Control) control).right) {
			if (!((Mad) this).pr) {
			    if (((Mad) this).rcomp == 0.0F)
				((Mad) this).rcomp
				    = 5.0F * (((CarDefine) ((Mad) this).cd)
					      .airs[((Mad) this).cn]);
			    if (((Mad) this).rcomp < 20.0F)
				((Mad) this).rcomp
				    += 2.0F * (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
			}
		    } else {
			if (((Mad) this).rcomp > 0.0F)
			    ((Mad) this).rcomp
				-= 2.0F * (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
			((Mad) this).pr = false;
		    }
		    if (((Control) control).up) {
			if (!((Mad) this).pu) {
			    if (((Mad) this).ucomp == 0.0F)
				((Mad) this).ucomp
				    = 5.0F * (((CarDefine) ((Mad) this).cd)
					      .airs[((Mad) this).cn]);
			    if (((Mad) this).ucomp < 20.0F)
				((Mad) this).ucomp
				    += 2.0F * (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
			}
		    } else {
			if (((Mad) this).ucomp > 0.0F)
			    ((Mad) this).ucomp
				-= 2.0F * (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
			((Mad) this).pu = false;
		    }
		    if (((Control) control).down) {
			if (!((Mad) this).pd) {
			    if (((Mad) this).dcomp == 0.0F)
				((Mad) this).dcomp
				    = 5.0F * (((CarDefine) ((Mad) this).cd)
					      .airs[((Mad) this).cn]);
			    if (((Mad) this).dcomp < 20.0F)
				((Mad) this).dcomp
				    += 2.0F * (((CarDefine) ((Mad) this).cd)
					       .airs[((Mad) this).cn]);
			}
		    } else {
			if (((Mad) this).dcomp > 0.0F)
			    ((Mad) this).dcomp
				-= 2.0F * (((CarDefine) ((Mad) this).cd).airs
					   [((Mad) this).cn]);
			((Mad) this).pd = false;
		    }
		    ((Mad) this).pzy
			+= ((((Mad) this).dcomp - ((Mad) this).ucomp)
			    * ((Mad) this).m.cos(((Mad) this).pxy));
		    if (bool)
			((ContO) conto).xz
			    += ((((Mad) this).dcomp - ((Mad) this).ucomp)
				* ((Mad) this).m.sin(((Mad) this).pxy));
		    else
			((ContO) conto).xz
			    -= ((((Mad) this).dcomp - ((Mad) this).ucomp)
				* ((Mad) this).m.sin(((Mad) this).pxy));
		    ((Mad) this).pxy
			+= ((Mad) this).rcomp - ((Mad) this).lcomp;
		}
	    }
	}
	float f_20_
	    = (20.0F * ((Mad) this).speed
	       / (154.0F
		  * ((CarDefine) ((Mad) this).cd).simag[((Mad) this).cn]));
	if (f_20_ > 20.0F)
	    f_20_ = 20.0F;
	((ContO) conto).wzy -= f_20_;
	if (((ContO) conto).wzy < -30)
	    ((ContO) conto).wzy += 30;
	if (((ContO) conto).wzy > 30)
	    ((ContO) conto).wzy -= 30;
	if (((Control) control).right) {
	    ((ContO) conto).wxz
		-= ((CarDefine) ((Mad) this).cd).turn[((Mad) this).cn];
	    if (((ContO) conto).wxz < -36)
		((ContO) conto).wxz = -36;
	}
	if (((Control) control).left) {
	    ((ContO) conto).wxz
		+= ((CarDefine) ((Mad) this).cd).turn[((Mad) this).cn];
	    if (((ContO) conto).wxz > 36)
		((ContO) conto).wxz = 36;
	}
	if (((ContO) conto).wxz != 0 && !((Control) control).left
	    && !((Control) control).right) {
	    if (Math.abs(((Mad) this).speed) < 10.0F) {
		if (Math.abs(((ContO) conto).wxz) == 1)
		    ((ContO) conto).wxz = 0;
		if (((ContO) conto).wxz > 0)
		    ((ContO) conto).wxz--;
		if (((ContO) conto).wxz < 0)
		    ((ContO) conto).wxz++;
	    } else {
		if (Math.abs(((ContO) conto).wxz)
		    < ((CarDefine) ((Mad) this).cd).turn[((Mad) this).cn] * 2)
		    ((ContO) conto).wxz = 0;
		if (((ContO) conto).wxz > 0)
		    ((ContO) conto).wxz
			-= (((CarDefine) ((Mad) this).cd).turn[((Mad) this).cn]
			    * 2);
		if (((ContO) conto).wxz < 0)
		    ((ContO) conto).wxz
			+= (((CarDefine) ((Mad) this).cd).turn[((Mad) this).cn]
			    * 2);
	    }
	}
	int i_21_
	    = (int) (3600.0F / (((Mad) this).speed * ((Mad) this).speed));
	if (i_21_ < 5)
	    i_21_ = 5;
	if (((Mad) this).speed < 0.0F)
	    i_21_ = -i_21_;
	if (((Mad) this).wtouch) {
	    if (!((Mad) this).capsized) {
		if (!((Control) control).handb)
		    ((Mad) this).fxz = ((ContO) conto).wxz / (i_21_ * 3);
		else
		    ((Mad) this).fxz = ((ContO) conto).wxz / i_21_;
		((ContO) conto).xz += ((ContO) conto).wxz / i_21_;
	    }
	    ((Mad) this).wtouch = false;
	    ((Mad) this).gtouch = false;
	} else
	    ((ContO) conto).xz += ((Mad) this).fxz;
	if (((Mad) this).speed > 30.0F || ((Mad) this).speed < -100.0F) {
	    while (Math.abs(((Mad) this).mxz - ((Mad) this).cxz) > 180) {
		if (((Mad) this).cxz > ((Mad) this).mxz)
		    ((Mad) this).cxz -= 360;
		else if (((Mad) this).cxz < ((Mad) this).mxz)
		    ((Mad) this).cxz += 360;
	    }
	    if (Math.abs(((Mad) this).mxz - ((Mad) this).cxz) < 30)
		((Mad) this).cxz
		    += (float) (((Mad) this).mxz - ((Mad) this).cxz) / 4.0F;
	    else {
		if (((Mad) this).cxz > ((Mad) this).mxz)
		    ((Mad) this).cxz -= 10;
		if (((Mad) this).cxz < ((Mad) this).mxz)
		    ((Mad) this).cxz += 10;
	    }
	}
	float[] fs = new float[4];
	float[] fs_22_ = new float[4];
	float[] fs_23_ = new float[4];
	for (int i_24_ = 0; i_24_ < 4; i_24_++) {
	    fs[i_24_]
		= (float) (((ContO) conto).keyx[i_24_] + ((ContO) conto).x);
	    fs_23_[i_24_] = (float) (i_10_ + ((ContO) conto).y);
	    fs_22_[i_24_]
		= (float) (((ContO) conto).z + ((ContO) conto).keyz[i_24_]);
	    ((Mad) this).scy[i_24_] += 7.0F;
	}
	rot(fs, fs_23_, ((ContO) conto).x, ((ContO) conto).y, ((Mad) this).pxy,
	    4);
	rot(fs_23_, fs_22_, ((ContO) conto).y, ((ContO) conto).z,
	    ((Mad) this).pzy, 4);
	rot(fs, fs_22_, ((ContO) conto).x, ((ContO) conto).z,
	    ((ContO) conto).xz, 4);
	boolean bool_25_ = false;
	double d = 0.0;
	int i_26_ = (int) ((((Mad) this).scx[0] + ((Mad) this).scx[1]
			    + ((Mad) this).scx[2] + ((Mad) this).scx[3])
			   / 4.0F);
	int i_27_ = (int) ((((Mad) this).scz[0] + ((Mad) this).scz[1]
			    + ((Mad) this).scz[2] + ((Mad) this).scz[3])
			   / 4.0F);
	for (int i_28_ = 0; i_28_ < 4; i_28_++) {
	    if (((Mad) this).scx[i_28_] - (float) i_26_ > 200.0F)
		((Mad) this).scx[i_28_] = (float) (200 + i_26_);
	    if (((Mad) this).scx[i_28_] - (float) i_26_ < -200.0F)
		((Mad) this).scx[i_28_] = (float) (i_26_ - 200);
	    if (((Mad) this).scz[i_28_] - (float) i_27_ > 200.0F)
		((Mad) this).scz[i_28_] = (float) (200 + i_27_);
	    if (((Mad) this).scz[i_28_] - (float) i_27_ < -200.0F)
		((Mad) this).scz[i_28_] = (float) (i_27_ - 200);
	}
	for (int i_29_ = 0; i_29_ < 4; i_29_++) {
	    fs_23_[i_29_] += ((Mad) this).scy[i_29_];
	    fs[i_29_] += (((Mad) this).scx[0] + ((Mad) this).scx[1]
			  + ((Mad) this).scx[2] + ((Mad) this).scx[3]) / 4.0F;
	    fs_22_[i_29_]
		+= (((Mad) this).scz[0] + ((Mad) this).scz[1]
		    + ((Mad) this).scz[2] + ((Mad) this).scz[3]) / 4.0F;
	}
	int i_30_ = (((ContO) conto).x - ((Trackers) trackers).sx) / 3000;
	if (i_30_ > ((Trackers) trackers).ncx)
	    i_30_ = ((Trackers) trackers).ncx;
	if (i_30_ < 0)
	    i_30_ = 0;
	int i_31_ = (((ContO) conto).z - ((Trackers) trackers).sz) / 3000;
	if (i_31_ > ((Trackers) trackers).ncz)
	    i_31_ = ((Trackers) trackers).ncz;
	if (i_31_ < 0)
	    i_31_ = 0;
	int i_32_ = 1;
	for (int i_33_ = 0;
	     i_33_ < ((Trackers) trackers).sect[i_30_][i_31_].length;
	     i_33_++) {
	    int i_34_ = ((Trackers) trackers).sect[i_30_][i_31_][i_33_];
	    if (Math.abs(((Trackers) trackers).zy[i_34_]) != 90
		&& Math.abs(((Trackers) trackers).xy[i_34_]) != 90
		&& (Math.abs(((ContO) conto).x
			     - ((Trackers) trackers).x[i_34_])
		    < ((Trackers) trackers).radx[i_34_])
		&& (Math.abs(((ContO) conto).z
			     - ((Trackers) trackers).z[i_34_])
		    < ((Trackers) trackers).radz[i_34_])
		&& (!((Trackers) trackers).decor[i_34_]
		    || ((Medium) ((Mad) this).m).resdown != 2
		    || ((xtGraphics) ((Mad) this).xt).multion != 0))
		i_32_ = ((Trackers) trackers).skd[i_34_];
	}
	if (((Mad) this).mtouch) {
	    float f_35_ = ((CarDefine) ((Mad) this).cd).grip[((Mad) this).cn];
	    f_35_ -= ((float) Math.abs(((Mad) this).txz - ((ContO) conto).xz)
		      * ((Mad) this).speed / 250.0F);
	    if (((Control) control).handb)
		f_35_
		    -= (float) (Math.abs(((Mad) this).txz - ((ContO) conto).xz)
				* 4);
	    if (f_35_ < ((CarDefine) ((Mad) this).cd).grip[((Mad) this).cn]) {
		if (((Mad) this).skid != 2)
		    ((Mad) this).skid = 1;
		((Mad) this).speed -= ((Mad) this).speed / 100.0F;
	    } else if (((Mad) this).skid == 1)
		((Mad) this).skid = 2;
	    if (i_32_ == 1)
		f_35_ *= 0.75;
	    if (i_32_ == 2)
		f_35_ *= 0.55;
	    int i_36_ = -(int) (((Mad) this).speed
				* ((Mad) this).m.sin(((ContO) conto).xz)
				* ((Mad) this).m.cos(((Mad) this).pzy));
	    int i_37_ = (int) (((Mad) this).speed
			       * ((Mad) this).m.cos(((ContO) conto).xz)
			       * ((Mad) this).m.cos(((Mad) this).pzy));
	    int i_38_ = -(int) (((Mad) this).speed
				* ((Mad) this).m.sin(((Mad) this).pzy));
	    if (((Mad) this).capsized || ((Mad) this).dest
		|| ((CheckPoints) checkpoints).haltall) {
		i_36_ = 0;
		i_37_ = 0;
		i_38_ = 0;
		f_35_ = (((CarDefine) ((Mad) this).cd).grip[((Mad) this).cn]
			 / 5.0F);
		if (((Mad) this).speed > 0.0F)
		    ((Mad) this).speed -= 2.0F;
		else
		    ((Mad) this).speed += 2.0F;
	    }
	    if (Math.abs(((Mad) this).speed) > ((Mad) this).drag) {
		if (((Mad) this).speed > 0.0F)
		    ((Mad) this).speed -= ((Mad) this).drag;
		else
		    ((Mad) this).speed += ((Mad) this).drag;
	    } else
		((Mad) this).speed = 0.0F;
	    if (((Mad) this).cn == 8 && f_35_ < 5.0F)
		f_35_ = 5.0F;
	    if (f_35_ < 1.0F)
		f_35_ = 1.0F;
	    float f_39_ = 0.0F;
	    float f_40_ = 0.0F;
	    for (int i_41_ = 0; i_41_ < 4; i_41_++) {
		if (Math.abs(((Mad) this).scx[i_41_] - (float) i_36_)
		    > f_35_) {
		    if (((Mad) this).scx[i_41_] < (float) i_36_)
			((Mad) this).scx[i_41_] += f_35_;
		    else
			((Mad) this).scx[i_41_] -= f_35_;
		} else
		    ((Mad) this).scx[i_41_] = (float) i_36_;
		if (Math.abs(((Mad) this).scz[i_41_] - (float) i_37_)
		    > f_35_) {
		    if (((Mad) this).scz[i_41_] < (float) i_37_)
			((Mad) this).scz[i_41_] += f_35_;
		    else
			((Mad) this).scz[i_41_] -= f_35_;
		} else
		    ((Mad) this).scz[i_41_] = (float) i_37_;
		if (Math.abs(((Mad) this).scy[i_41_] - (float) i_38_)
		    > f_35_) {
		    if (((Mad) this).scy[i_41_] < (float) i_38_)
			((Mad) this).scy[i_41_] += f_35_;
		    else
			((Mad) this).scy[i_41_] -= f_35_;
		} else
		    ((Mad) this).scy[i_41_] = (float) i_38_;
		if (f_35_
		    < ((CarDefine) ((Mad) this).cd).grip[((Mad) this).cn]) {
		    if (((Mad) this).txz != ((ContO) conto).xz)
			((Mad) this).dcnt++;
		    else if (((Mad) this).dcnt != 0)
			((Mad) this).dcnt = 0;
		    if (((float) ((Mad) this).dcnt
			 > 40.0F * f_35_ / (((CarDefine) ((Mad) this).cd).grip
					    [((Mad) this).cn]))
			|| ((Mad) this).capsized) {
			float f_42_ = 1.0F;
			if (i_32_ != 0)
			    f_42_ = 1.2F;
			if ((double) ((Mad) this).m.random() > 0.65) {
			    conto.dust(i_41_, fs[i_41_], fs_23_[i_41_],
				       fs_22_[i_41_],
				       (int) ((Mad) this).scx[i_41_],
				       (int) ((Mad) this).scz[i_41_],
				       f_42_ * (((CarDefine) ((Mad) this).cd)
						.simag[((Mad) this).cn]),
				       (int) ((Mad) this).tilt,
				       (((Mad) this).capsized
					&& ((Mad) this).mtouch));
			    if ((((Mad) this).im
				 == ((xtGraphics) ((Mad) this).xt).im)
				&& !((Mad) this).capsized)
				((Mad) this).xt.skid
				    (i_32_,
				     (float) (Math.sqrt
					      ((double) (((((Mad) this).scx
							   [i_41_])
							  * (((Mad) this).scx
							     [i_41_]))
							 + ((((Mad) this).scz
							     [i_41_])
							    * (((Mad) this).scz
							       [i_41_]))))));
			}
		    } else {
			if (i_32_ == 1
			    && (double) ((Mad) this).m.random() > 0.8)
			    conto.dust(i_41_, fs[i_41_], fs_23_[i_41_],
				       fs_22_[i_41_],
				       (int) ((Mad) this).scx[i_41_],
				       (int) ((Mad) this).scz[i_41_],
				       1.1F * (((CarDefine) ((Mad) this).cd)
					       .simag[((Mad) this).cn]),
				       (int) ((Mad) this).tilt,
				       (((Mad) this).capsized
					&& ((Mad) this).mtouch));
			if ((i_32_ == 2 || i_32_ == 3)
			    && (double) ((Mad) this).m.random() > 0.6)
			    conto.dust(i_41_, fs[i_41_], fs_23_[i_41_],
				       fs_22_[i_41_],
				       (int) ((Mad) this).scx[i_41_],
				       (int) ((Mad) this).scz[i_41_],
				       1.15F * (((CarDefine) ((Mad) this).cd)
						.simag[((Mad) this).cn]),
				       (int) ((Mad) this).tilt,
				       (((Mad) this).capsized
					&& ((Mad) this).mtouch));
		    }
		} else if (((Mad) this).dcnt != 0) {
		    ((Mad) this).dcnt -= 2;
		    if (((Mad) this).dcnt < 0)
			((Mad) this).dcnt = 0;
		}
		if (i_32_ == 3) {
		    int i_43_ = (int) (((Mad) this).m.random() * 4.0F);
		    ((Mad) this).scy[i_43_]
			= (float) ((double) (-100.0F * ((Mad) this).m.random()
					     * (((Mad) this).speed
						/ (float) (((CarDefine)
							    ((Mad) this).cd)
							   .swits
							   [((Mad) this).cn]
							   [2])))
				   * ((double) (((CarDefine) ((Mad) this).cd)
						.bounce[((Mad) this).cn])
				      - 0.3));
		}
		if (i_32_ == 4) {
		    int i_44_ = (int) (((Mad) this).m.random() * 4.0F);
		    ((Mad) this).scy[i_44_]
			= (float) ((double) (-150.0F * ((Mad) this).m.random()
					     * (((Mad) this).speed
						/ (float) (((CarDefine)
							    ((Mad) this).cd)
							   .swits
							   [((Mad) this).cn]
							   [2])))
				   * ((double) (((CarDefine) ((Mad) this).cd)
						.bounce[((Mad) this).cn])
				      - 0.3));
		}
		f_39_ += ((Mad) this).scx[i_41_];
		f_40_ += ((Mad) this).scz[i_41_];
	    }
	    ((Mad) this).txz = ((ContO) conto).xz;
	    if (f_39_ > 0.0F)
		i = -1;
	    else
		i = 1;
	    d = (double) f_40_ / Math.sqrt((double) (f_39_ * f_39_
						     + f_40_ * f_40_));
	    ((Mad) this).mxz
		= (int) (Math.acos(d) / 0.017453292519943295 * (double) i);
	    if (((Mad) this).skid == 2) {
		if (!((Mad) this).capsized) {
		    f_39_ /= 4.0F;
		    f_40_ /= 4.0F;
		    if (bool_5_)
			((Mad) this).speed
			    = -((float) Math.sqrt((double) (f_39_ * f_39_
							    + f_40_ * f_40_))
				* ((Mad) this).m.cos(((Mad) this).mxz
						     - ((ContO) conto).xz));
		    else
			((Mad) this).speed
			    = ((float) Math.sqrt((double) (f_39_ * f_39_
							   + f_40_ * f_40_))
			       * ((Mad) this).m.cos(((Mad) this).mxz
						    - ((ContO) conto).xz));
		}
		((Mad) this).skid = 0;
	    }
	    if (((Mad) this).capsized && f_39_ == 0.0F && f_40_ == 0.0F)
		i_32_ = 0;
	    ((Mad) this).mtouch = false;
	    bool_25_ = true;
	} else if (((Mad) this).skid != 2)
	    ((Mad) this).skid = 2;
	int i_45_ = 0;
	boolean[] bools = new boolean[4];
	boolean[] bools_46_ = new boolean[4];
	boolean[] bools_47_ = new boolean[4];
	float f_48_ = 0.0F;
	for (int i_49_ = 0; i_49_ < 4; i_49_++) {
	    bools_46_[i_49_] = false;
	    bools_47_[i_49_] = false;
	    if (fs_23_[i_49_] > 245.0F) {
		i_45_++;
		((Mad) this).wtouch = true;
		((Mad) this).gtouch = true;
		if (!bool_25_ && ((Mad) this).scy[i_49_] != 7.0F) {
		    float f_50_ = ((Mad) this).scy[i_49_] / 333.33F;
		    if ((double) f_50_ > 0.3)
			f_50_ = 0.3F;
		    if (i_32_ == 0)
			f_50_ += 1.1;
		    else
			f_50_ += 1.2;
		    conto.dust(i_49_, fs[i_49_], fs_23_[i_49_], fs_22_[i_49_],
			       (int) ((Mad) this).scx[i_49_],
			       (int) ((Mad) this).scz[i_49_],
			       f_50_ * (((CarDefine) ((Mad) this).cd).simag
					[((Mad) this).cn]),
			       0,
			       ((Mad) this).capsized && ((Mad) this).mtouch);
		}
		fs_23_[i_49_] = 250.0F;
		bools_47_[i_49_] = true;
		f_48_ += fs_23_[i_49_] - 250.0F;
		float f_51_
		    = (Math.abs(((Mad) this).m.sin(((Mad) this).pxy))
		       + Math.abs(((Mad) this).m.sin(((Mad) this).pzy)));
		f_51_ /= 3.0F;
		if ((double) f_51_ > 0.4)
		    f_51_ = 0.4F;
		f_51_ += ((CarDefine) ((Mad) this).cd).bounce[((Mad) this).cn];
		if ((double) f_51_ < 1.1)
		    f_51_ = 1.1F;
		regy(i_49_, Math.abs(((Mad) this).scy[i_49_] * f_51_), conto);
		if (((Mad) this).scy[i_49_] > 0.0F)
		    ((Mad) this).scy[i_49_]
			-= Math.abs(((Mad) this).scy[i_49_] * f_51_);
		if (((Mad) this).capsized)
		    bools_46_[i_49_] = true;
	    }
	    bools[i_49_] = false;
	}
	if (i_45_ != 0) {
	    f_48_ /= (float) i_45_;
	    for (int i_52_ = 0; i_52_ < 4; i_52_++) {
		if (!bools_47_[i_52_])
		    fs_23_[i_52_] -= f_48_;
	    }
	}
	int i_53_ = 0;
	for (int i_54_ = 0;
	     i_54_ < ((Trackers) trackers).sect[i_30_][i_31_].length;
	     i_54_++) {
	    int i_55_ = ((Trackers) trackers).sect[i_30_][i_31_][i_54_];
	    int i_56_ = 0;
	    int i_57_ = 0;
	    for (int i_58_ = 0; i_58_ < 4; i_58_++) {
		if (bools_46_[i_58_]
		    && (((Trackers) trackers).skd[i_55_] == 0
			|| ((Trackers) trackers).skd[i_55_] == 1)
		    && (fs[i_58_]
			> (float) (((Trackers) trackers).x[i_55_]
				   - ((Trackers) trackers).radx[i_55_]))
		    && (fs[i_58_]
			< (float) (((Trackers) trackers).x[i_55_]
				   + ((Trackers) trackers).radx[i_55_]))
		    && (fs_22_[i_58_]
			> (float) (((Trackers) trackers).z[i_55_]
				   - ((Trackers) trackers).radz[i_55_]))
		    && (fs_22_[i_58_]
			< (float) (((Trackers) trackers).z[i_55_]
				   + ((Trackers) trackers).radz[i_55_]))) {
		    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
			       ((Mad) this).scx[i_58_],
			       ((Mad) this).scy[i_58_],
			       ((Mad) this).scz[i_58_], 1);
		    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im)
			((Mad) this).xt.gscrape((int) ((Mad) this).scx[i_58_],
						(int) ((Mad) this).scy[i_58_],
						(int) ((Mad) this).scz[i_58_]);
		}
		if (!bools[i_58_]
		    && (fs[i_58_]
			> (float) (((Trackers) trackers).x[i_55_]
				   - ((Trackers) trackers).radx[i_55_]))
		    && (fs[i_58_]
			< (float) (((Trackers) trackers).x[i_55_]
				   + ((Trackers) trackers).radx[i_55_]))
		    && (fs_22_[i_58_]
			> (float) (((Trackers) trackers).z[i_55_]
				   - ((Trackers) trackers).radz[i_55_]))
		    && (fs_22_[i_58_]
			< (float) (((Trackers) trackers).z[i_55_]
				   + ((Trackers) trackers).radz[i_55_]))
		    && (fs_23_[i_58_]
			> (float) (((Trackers) trackers).y[i_55_]
				   - ((Trackers) trackers).rady[i_55_]))
		    && (fs_23_[i_58_]
			< (float) (((Trackers) trackers).y[i_55_]
				   + ((Trackers) trackers).rady[i_55_]))
		    && (!((Trackers) trackers).decor[i_55_]
			|| ((Medium) ((Mad) this).m).resdown != 2
			|| ((xtGraphics) ((Mad) this).xt).multion != 0)) {
		    if (((Trackers) trackers).xy[i_55_] == 0
			&& ((Trackers) trackers).zy[i_55_] == 0
			&& ((Trackers) trackers).y[i_55_] != 250
			&& (fs_23_[i_58_]
			    > (float) (((Trackers) trackers).y[i_55_] - 5))) {
			i_57_++;
			((Mad) this).wtouch = true;
			((Mad) this).gtouch = true;
			if (!bool_25_ && ((Mad) this).scy[i_58_] != 7.0F) {
			    float f_59_ = ((Mad) this).scy[i_58_] / 333.33F;
			    if ((double) f_59_ > 0.3)
				f_59_ = 0.3F;
			    if (i_32_ == 0)
				f_59_ += 1.1;
			    else
				f_59_ += 1.2;
			    conto.dust(i_58_, fs[i_58_], fs_23_[i_58_],
				       fs_22_[i_58_],
				       (int) ((Mad) this).scx[i_58_],
				       (int) ((Mad) this).scz[i_58_],
				       f_59_ * (((CarDefine) ((Mad) this).cd)
						.simag[((Mad) this).cn]),
				       0,
				       (((Mad) this).capsized
					&& ((Mad) this).mtouch));
			}
			fs_23_[i_58_] = (float) ((Trackers) trackers).y[i_55_];
			if (((Mad) this).capsized
			    && (((Trackers) trackers).skd[i_55_] == 0
				|| ((Trackers) trackers).skd[i_55_] == 1)) {
			    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
				       ((Mad) this).scx[i_58_],
				       ((Mad) this).scy[i_58_],
				       ((Mad) this).scz[i_58_], 1);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) this).xt.gscrape
				    ((int) ((Mad) this).scx[i_58_],
				     (int) ((Mad) this).scy[i_58_],
				     (int) ((Mad) this).scz[i_58_]);
			}
			float f_60_
			    = (Math.abs(((Mad) this).m.sin(((Mad) this).pxy))
			       + Math.abs(((Mad) this).m
					      .sin(((Mad) this).pzy)));
			f_60_ /= 3.0F;
			if ((double) f_60_ > 0.4)
			    f_60_ = 0.4F;
			f_60_ += (((CarDefine) ((Mad) this).cd).bounce
				  [((Mad) this).cn]);
			if ((double) f_60_ < 1.1)
			    f_60_ = 1.1F;
			regy(i_58_, Math.abs(((Mad) this).scy[i_58_] * f_60_),
			     conto);
			if (((Mad) this).scy[i_58_] > 0.0F)
			    ((Mad) this).scy[i_58_]
				-= Math.abs(((Mad) this).scy[i_58_] * f_60_);
			bools[i_58_] = true;
		    }
		    if (((Trackers) trackers).zy[i_55_] == -90
			&& (fs_22_[i_58_]
			    < (float) (((Trackers) trackers).z[i_55_]
				       + ((Trackers) trackers).radz[i_55_]))
			&& (((Mad) this).scz[i_58_] < 0.0F
			    || ((Trackers) trackers).radz[i_55_] == 287)) {
			for (int i_61_ = 0; i_61_ < 4; i_61_++) {
			    if (i_58_ != i_61_
				&& (fs_22_[i_61_]
				    >= (float) (((Trackers) trackers).z[i_55_]
						+ (((Trackers) trackers).radz
						   [i_55_]))))
				fs_22_[i_61_]
				    -= (fs_22_[i_58_]
					- (float) ((((Trackers) trackers).z
						    [i_55_])
						   + (((Trackers) trackers)
						      .radz[i_55_])));
			}
			fs_22_[i_58_]
			    = (float) (((Trackers) trackers).z[i_55_]
				       + ((Trackers) trackers).radz[i_55_]);
			if (((Trackers) trackers).skd[i_55_] != 2)
			    ((Mad) this).crank[0][i_58_]++;
			if (((Trackers) trackers).skd[i_55_] == 5
			    && (((Mad) this).m.random()
				> ((Mad) this).m.random()))
			    ((Mad) this).crank[0][i_58_]++;
			if (((Mad) this).crank[0][i_58_] > 1) {
			    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
				       ((Mad) this).scx[i_58_],
				       ((Mad) this).scy[i_58_],
				       ((Mad) this).scz[i_58_], 0);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) this).xt.scrape
				    ((int) ((Mad) this).scx[i_58_],
				     (int) ((Mad) this).scy[i_58_],
				     (int) ((Mad) this).scz[i_58_]);
			}
			float f_62_
			    = (Math.abs(((Mad) this).m.cos(((Mad) this).pxy))
			       + Math.abs(((Mad) this).m
					      .cos(((Mad) this).pzy)));
			f_62_ /= 4.0F;
			if ((double) f_62_ > 0.3)
			    f_62_ = 0.3F;
			if (bool_25_)
			    f_62_ = 0.0F;
			f_62_ += (double) (((CarDefine) ((Mad) this).cd).bounce
					   [((Mad) this).cn]) - 0.2;
			if ((double) f_62_ < 1.1)
			    f_62_ = 1.1F;
			regz(i_58_, Math.abs(((Mad) this).scz[i_58_] * f_62_
					     * (float) (((Trackers) trackers)
							.dam[i_55_])), conto);
			((Mad) this).scz[i_58_]
			    += Math.abs(((Mad) this).scz[i_58_] * f_62_);
			((Mad) this).skid = 2;
			bool_6_ = true;
			bools[i_58_] = true;
			if (!((Trackers) trackers).notwall[i_55_])
			    ((Control) control).wall = i_55_;
		    }
		    if (((Trackers) trackers).zy[i_55_] == 90
			&& (fs_22_[i_58_]
			    > (float) (((Trackers) trackers).z[i_55_]
				       - ((Trackers) trackers).radz[i_55_]))
			&& (((Mad) this).scz[i_58_] > 0.0F
			    || ((Trackers) trackers).radz[i_55_] == 287)) {
			for (int i_63_ = 0; i_63_ < 4; i_63_++) {
			    if (i_58_ != i_63_
				&& (fs_22_[i_63_]
				    <= (float) (((Trackers) trackers).z[i_55_]
						- (((Trackers) trackers).radz
						   [i_55_]))))
				fs_22_[i_63_]
				    -= (fs_22_[i_58_]
					- (float) ((((Trackers) trackers).z
						    [i_55_])
						   - (((Trackers) trackers)
						      .radz[i_55_])));
			}
			fs_22_[i_58_]
			    = (float) (((Trackers) trackers).z[i_55_]
				       - ((Trackers) trackers).radz[i_55_]);
			if (((Trackers) trackers).skd[i_55_] != 2)
			    ((Mad) this).crank[1][i_58_]++;
			if (((Trackers) trackers).skd[i_55_] == 5
			    && (((Mad) this).m.random()
				> ((Mad) this).m.random()))
			    ((Mad) this).crank[1][i_58_]++;
			if (((Mad) this).crank[1][i_58_] > 1) {
			    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
				       ((Mad) this).scx[i_58_],
				       ((Mad) this).scy[i_58_],
				       ((Mad) this).scz[i_58_], 0);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) this).xt.scrape
				    ((int) ((Mad) this).scx[i_58_],
				     (int) ((Mad) this).scy[i_58_],
				     (int) ((Mad) this).scz[i_58_]);
			}
			float f_64_
			    = (Math.abs(((Mad) this).m.cos(((Mad) this).pxy))
			       + Math.abs(((Mad) this).m
					      .cos(((Mad) this).pzy)));
			f_64_ /= 4.0F;
			if ((double) f_64_ > 0.3)
			    f_64_ = 0.3F;
			if (bool_25_)
			    f_64_ = 0.0F;
			f_64_ += (double) (((CarDefine) ((Mad) this).cd).bounce
					   [((Mad) this).cn]) - 0.2;
			if ((double) f_64_ < 1.1)
			    f_64_ = 1.1F;
			regz(i_58_, -Math.abs(((Mad) this).scz[i_58_] * f_64_
					      * (float) (((Trackers) trackers)
							 .dam[i_55_])), conto);
			((Mad) this).scz[i_58_]
			    -= Math.abs(((Mad) this).scz[i_58_] * f_64_);
			((Mad) this).skid = 2;
			bool_6_ = true;
			bools[i_58_] = true;
			if (!((Trackers) trackers).notwall[i_55_])
			    ((Control) control).wall = i_55_;
		    }
		    if (((Trackers) trackers).xy[i_55_] == -90
			&& (fs[i_58_]
			    < (float) (((Trackers) trackers).x[i_55_]
				       + ((Trackers) trackers).radx[i_55_]))
			&& (((Mad) this).scx[i_58_] < 0.0F
			    || ((Trackers) trackers).radx[i_55_] == 287)) {
			for (int i_65_ = 0; i_65_ < 4; i_65_++) {
			    if (i_58_ != i_65_
				&& (fs[i_65_]
				    >= (float) (((Trackers) trackers).x[i_55_]
						+ (((Trackers) trackers).radx
						   [i_55_]))))
				fs[i_65_]
				    -= (fs[i_58_]
					- (float) ((((Trackers) trackers).x
						    [i_55_])
						   + (((Trackers) trackers)
						      .radx[i_55_])));
			}
			fs[i_58_]
			    = (float) (((Trackers) trackers).x[i_55_]
				       + ((Trackers) trackers).radx[i_55_]);
			if (((Trackers) trackers).skd[i_55_] != 2)
			    ((Mad) this).crank[2][i_58_]++;
			if (((Trackers) trackers).skd[i_55_] == 5
			    && (((Mad) this).m.random()
				> ((Mad) this).m.random()))
			    ((Mad) this).crank[2][i_58_]++;
			if (((Mad) this).crank[2][i_58_] > 1) {
			    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
				       ((Mad) this).scx[i_58_],
				       ((Mad) this).scy[i_58_],
				       ((Mad) this).scz[i_58_], 0);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) this).xt.scrape
				    ((int) ((Mad) this).scx[i_58_],
				     (int) ((Mad) this).scy[i_58_],
				     (int) ((Mad) this).scz[i_58_]);
			}
			float f_66_
			    = (Math.abs(((Mad) this).m.cos(((Mad) this).pxy))
			       + Math.abs(((Mad) this).m
					      .cos(((Mad) this).pzy)));
			f_66_ /= 4.0F;
			if ((double) f_66_ > 0.3)
			    f_66_ = 0.3F;
			if (bool_25_)
			    f_66_ = 0.0F;
			f_66_ += (double) (((CarDefine) ((Mad) this).cd).bounce
					   [((Mad) this).cn]) - 0.2;
			if ((double) f_66_ < 1.1)
			    f_66_ = 1.1F;
			regx(i_58_, Math.abs(((Mad) this).scx[i_58_] * f_66_
					     * (float) (((Trackers) trackers)
							.dam[i_55_])), conto);
			((Mad) this).scx[i_58_]
			    += Math.abs(((Mad) this).scx[i_58_] * f_66_);
			((Mad) this).skid = 2;
			bool_6_ = true;
			bools[i_58_] = true;
			if (!((Trackers) trackers).notwall[i_55_])
			    ((Control) control).wall = i_55_;
		    }
		    if (((Trackers) trackers).xy[i_55_] == 90
			&& (fs[i_58_]
			    > (float) (((Trackers) trackers).x[i_55_]
				       - ((Trackers) trackers).radx[i_55_]))
			&& (((Mad) this).scx[i_58_] > 0.0F
			    || ((Trackers) trackers).radx[i_55_] == 287)) {
			for (int i_67_ = 0; i_67_ < 4; i_67_++) {
			    if (i_58_ != i_67_
				&& (fs[i_67_]
				    <= (float) (((Trackers) trackers).x[i_55_]
						- (((Trackers) trackers).radx
						   [i_55_]))))
				fs[i_67_]
				    -= (fs[i_58_]
					- (float) ((((Trackers) trackers).x
						    [i_55_])
						   - (((Trackers) trackers)
						      .radx[i_55_])));
			}
			fs[i_58_]
			    = (float) (((Trackers) trackers).x[i_55_]
				       - ((Trackers) trackers).radx[i_55_]);
			if (((Trackers) trackers).skd[i_55_] != 2)
			    ((Mad) this).crank[3][i_58_]++;
			if (((Trackers) trackers).skd[i_55_] == 5
			    && (((Mad) this).m.random()
				> ((Mad) this).m.random()))
			    ((Mad) this).crank[3][i_58_]++;
			if (((Mad) this).crank[3][i_58_] > 1) {
			    conto.sprk(fs[i_58_], fs_23_[i_58_], fs_22_[i_58_],
				       ((Mad) this).scx[i_58_],
				       ((Mad) this).scy[i_58_],
				       ((Mad) this).scz[i_58_], 0);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) this).xt.scrape
				    ((int) ((Mad) this).scx[i_58_],
				     (int) ((Mad) this).scy[i_58_],
				     (int) ((Mad) this).scz[i_58_]);
			}
			float f_68_
			    = (Math.abs(((Mad) this).m.cos(((Mad) this).pxy))
			       + Math.abs(((Mad) this).m
					      .cos(((Mad) this).pzy)));
			f_68_ /= 4.0F;
			if ((double) f_68_ > 0.3)
			    f_68_ = 0.3F;
			if (bool_25_)
			    f_68_ = 0.0F;
			f_68_ += (double) (((CarDefine) ((Mad) this).cd).bounce
					   [((Mad) this).cn]) - 0.2;
			if ((double) f_68_ < 1.1)
			    f_68_ = 1.1F;
			regx(i_58_, -Math.abs(((Mad) this).scx[i_58_] * f_68_
					      * (float) (((Trackers) trackers)
							 .dam[i_55_])), conto);
			((Mad) this).scx[i_58_]
			    -= Math.abs(((Mad) this).scx[i_58_] * f_68_);
			((Mad) this).skid = 2;
			bool_6_ = true;
			bools[i_58_] = true;
			if (!((Trackers) trackers).notwall[i_55_])
			    ((Control) control).wall = i_55_;
		    }
		    if (((Trackers) trackers).zy[i_55_] != 0
			&& ((Trackers) trackers).zy[i_55_] != 90
			&& ((Trackers) trackers).zy[i_55_] != -90) {
			int i_69_ = 90 + ((Trackers) trackers).zy[i_55_];
			float f_70_
			    = (1.0F
			       + (float) (50 - Math.abs(((Trackers) trackers)
							.zy[i_55_])) / 30.0F);
			if (f_70_ < 1.0F)
			    f_70_ = 1.0F;
			float f_71_
			    = ((float) ((Trackers) trackers).y[i_55_]
			       + (((fs_23_[i_58_]
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.cos(i_69_))
				  - ((fs_22_[i_58_]
				      - (float) ((Trackers) trackers).z[i_55_])
				     * ((Mad) this).m.sin(i_69_))));
			float f_72_
			    = ((float) ((Trackers) trackers).z[i_55_]
			       + (((fs_23_[i_58_]
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.sin(i_69_))
				  + ((fs_22_[i_58_]
				      - (float) ((Trackers) trackers).z[i_55_])
				     * ((Mad) this).m.cos(i_69_))));
			if (f_72_ > (float) ((Trackers) trackers).z[i_55_]
			    && f_72_ < (float) (((Trackers) trackers).z[i_55_]
						+ 200)) {
			    ((Mad) this).scy[i_58_]
				-= ((f_72_
				     - (float) ((Trackers) trackers).z[i_55_])
				    / f_70_);
			    f_72_ = (float) ((Trackers) trackers).z[i_55_];
			}
			if (f_72_
			    > (float) (((Trackers) trackers).z[i_55_] - 30)) {
			    if (((Trackers) trackers).skd[i_55_] == 2)
				i_56_++;
			    else
				i_53_++;
			    ((Mad) this).wtouch = true;
			    ((Mad) this).gtouch = false;
			    if (((Mad) this).capsized
				&& (((Trackers) trackers).skd[i_55_] == 0
				    || (((Trackers) trackers).skd[i_55_]
					== 1))) {
				conto.sprk(fs[i_58_], fs_23_[i_58_],
					   fs_22_[i_58_],
					   ((Mad) this).scx[i_58_],
					   ((Mad) this).scy[i_58_],
					   ((Mad) this).scz[i_58_], 1);
				if (((Mad) this).im
				    == ((xtGraphics) ((Mad) this).xt).im)
				    ((Mad) this).xt.gscrape
					((int) ((Mad) this).scx[i_58_],
					 (int) ((Mad) this).scy[i_58_],
					 (int) ((Mad) this).scz[i_58_]);
			    }
			    if (!bool_25_ && i_32_ != 0) {
				float f_73_ = 1.4F;
				conto.dust(i_58_, fs[i_58_], fs_23_[i_58_],
					   fs_22_[i_58_],
					   (int) ((Mad) this).scx[i_58_],
					   (int) ((Mad) this).scz[i_58_],
					   (f_73_
					    * (((CarDefine) ((Mad) this).cd)
					       .simag[((Mad) this).cn])),
					   0,
					   (((Mad) this).capsized
					    && ((Mad) this).mtouch));
			    }
			}
			fs_23_[i_58_]
			    = ((float) ((Trackers) trackers).y[i_55_]
			       + (((f_71_
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.cos(-i_69_))
				  - ((f_72_
				      - (float) ((Trackers) trackers).z[i_55_])
				     * ((Mad) this).m.sin(-i_69_))));
			fs_22_[i_58_]
			    = ((float) ((Trackers) trackers).z[i_55_]
			       + (((f_71_
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.sin(-i_69_))
				  + ((f_72_
				      - (float) ((Trackers) trackers).z[i_55_])
				     * ((Mad) this).m.cos(-i_69_))));
			bools[i_58_] = true;
		    }
		    if (((Trackers) trackers).xy[i_55_] != 0
			&& ((Trackers) trackers).xy[i_55_] != 90
			&& ((Trackers) trackers).xy[i_55_] != -90) {
			int i_74_ = 90 + ((Trackers) trackers).xy[i_55_];
			float f_75_
			    = (1.0F
			       + (float) (50 - Math.abs(((Trackers) trackers)
							.xy[i_55_])) / 30.0F);
			if (f_75_ < 1.0F)
			    f_75_ = 1.0F;
			float f_76_
			    = ((float) ((Trackers) trackers).y[i_55_]
			       + (((fs_23_[i_58_]
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.cos(i_74_))
				  - ((fs[i_58_]
				      - (float) ((Trackers) trackers).x[i_55_])
				     * ((Mad) this).m.sin(i_74_))));
			float f_77_
			    = ((float) ((Trackers) trackers).x[i_55_]
			       + (((fs_23_[i_58_]
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.sin(i_74_))
				  + ((fs[i_58_]
				      - (float) ((Trackers) trackers).x[i_55_])
				     * ((Mad) this).m.cos(i_74_))));
			if (f_77_ > (float) ((Trackers) trackers).x[i_55_]
			    && f_77_ < (float) (((Trackers) trackers).x[i_55_]
						+ 200)) {
			    ((Mad) this).scy[i_58_]
				-= ((f_77_
				     - (float) ((Trackers) trackers).x[i_55_])
				    / f_75_);
			    f_77_ = (float) ((Trackers) trackers).x[i_55_];
			}
			if (f_77_
			    > (float) (((Trackers) trackers).x[i_55_] - 30)) {
			    if (((Trackers) trackers).skd[i_55_] == 2)
				i_56_++;
			    else
				i_53_++;
			    ((Mad) this).wtouch = true;
			    ((Mad) this).gtouch = false;
			    if (((Mad) this).capsized
				&& (((Trackers) trackers).skd[i_55_] == 0
				    || (((Trackers) trackers).skd[i_55_]
					== 1))) {
				conto.sprk(fs[i_58_], fs_23_[i_58_],
					   fs_22_[i_58_],
					   ((Mad) this).scx[i_58_],
					   ((Mad) this).scy[i_58_],
					   ((Mad) this).scz[i_58_], 1);
				if (((Mad) this).im
				    == ((xtGraphics) ((Mad) this).xt).im)
				    ((Mad) this).xt.gscrape
					((int) ((Mad) this).scx[i_58_],
					 (int) ((Mad) this).scy[i_58_],
					 (int) ((Mad) this).scz[i_58_]);
			    }
			    if (!bool_25_ && i_32_ != 0) {
				float f_78_ = 1.4F;
				conto.dust(i_58_, fs[i_58_], fs_23_[i_58_],
					   fs_22_[i_58_],
					   (int) ((Mad) this).scx[i_58_],
					   (int) ((Mad) this).scz[i_58_],
					   (f_78_
					    * (((CarDefine) ((Mad) this).cd)
					       .simag[((Mad) this).cn])),
					   0,
					   (((Mad) this).capsized
					    && ((Mad) this).mtouch));
			    }
			}
			fs_23_[i_58_]
			    = ((float) ((Trackers) trackers).y[i_55_]
			       + (((f_76_
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.cos(-i_74_))
				  - ((f_77_
				      - (float) ((Trackers) trackers).x[i_55_])
				     * ((Mad) this).m.sin(-i_74_))));
			fs[i_58_]
			    = ((float) ((Trackers) trackers).x[i_55_]
			       + (((f_76_
				    - (float) ((Trackers) trackers).y[i_55_])
				   * ((Mad) this).m.sin(-i_74_))
				  + ((f_77_
				      - (float) ((Trackers) trackers).x[i_55_])
				     * ((Mad) this).m.cos(-i_74_))));
			bools[i_58_] = true;
		    }
		}
	    }
	    if (i_56_ == 4)
		((Mad) this).mtouch = true;
	    if (i_57_ == 4)
		i_45_ = 4;
	}
	if (i_53_ == 4)
	    ((Mad) this).mtouch = true;
	for (int i_79_ = 0; i_79_ < 4; i_79_++) {
	    for (int i_80_ = 0; i_80_ < 4; i_80_++) {
		if (((Mad) this).crank[i_79_][i_80_]
		    == ((Mad) this).lcrank[i_79_][i_80_])
		    ((Mad) this).crank[i_79_][i_80_] = 0;
		((Mad) this).lcrank[i_79_][i_80_]
		    = ((Mad) this).crank[i_79_][i_80_];
	    }
	}
	int i_81_ = 0;
	int i_82_ = 0;
	int i_83_ = 0;
	int i_84_ = 0;
	if (((Mad) this).scy[2] != ((Mad) this).scy[0]) {
	    if (((Mad) this).scy[2] < ((Mad) this).scy[0])
		i = -1;
	    else
		i = 1;
	    d = (Math.sqrt((double) ((fs_22_[0] - fs_22_[2]) * (fs_22_[0]
								- fs_22_[2])
				     + (fs_23_[0] - fs_23_[2]) * (fs_23_[0]
								  - fs_23_[2])
				     + (fs[0] - fs[2]) * (fs[0] - fs[2])))
		 / (double) (Math.abs(((ContO) conto).keyz[0])
			     + Math.abs(((ContO) conto).keyz[2])));
	    if (d >= 0.9998)
		i_81_ = i;
	    else
		i_81_
		    = (int) (Math.acos(d) / 0.017453292519943295 * (double) i);
	}
	if (((Mad) this).scy[3] != ((Mad) this).scy[1]) {
	    if (((Mad) this).scy[3] < ((Mad) this).scy[1])
		i = -1;
	    else
		i = 1;
	    d = (Math.sqrt((double) ((fs_22_[1] - fs_22_[3]) * (fs_22_[1]
								- fs_22_[3])
				     + (fs_23_[1] - fs_23_[3]) * (fs_23_[1]
								  - fs_23_[3])
				     + (fs[1] - fs[3]) * (fs[1] - fs[3])))
		 / (double) (Math.abs(((ContO) conto).keyz[1])
			     + Math.abs(((ContO) conto).keyz[3])));
	    if (d >= 0.9998)
		i_82_ = i;
	    else
		i_82_
		    = (int) (Math.acos(d) / 0.017453292519943295 * (double) i);
	}
	if (((Mad) this).scy[1] != ((Mad) this).scy[0]) {
	    if (((Mad) this).scy[1] < ((Mad) this).scy[0])
		i = -1;
	    else
		i = 1;
	    d = (Math.sqrt((double) ((fs_22_[0] - fs_22_[1]) * (fs_22_[0]
								- fs_22_[1])
				     + (fs_23_[0] - fs_23_[1]) * (fs_23_[0]
								  - fs_23_[1])
				     + (fs[0] - fs[1]) * (fs[0] - fs[1])))
		 / (double) (Math.abs(((ContO) conto).keyx[0])
			     + Math.abs(((ContO) conto).keyx[1])));
	    if (d >= 0.9998)
		i_83_ = i;
	    else
		i_83_
		    = (int) (Math.acos(d) / 0.017453292519943295 * (double) i);
	}
	if (((Mad) this).scy[3] != ((Mad) this).scy[2]) {
	    if (((Mad) this).scy[3] < ((Mad) this).scy[2])
		i = -1;
	    else
		i = 1;
	    d = (Math.sqrt((double) ((fs_22_[2] - fs_22_[3]) * (fs_22_[2]
								- fs_22_[3])
				     + (fs_23_[2] - fs_23_[3]) * (fs_23_[2]
								  - fs_23_[3])
				     + (fs[2] - fs[3]) * (fs[2] - fs[3])))
		 / (double) (Math.abs(((ContO) conto).keyx[2])
			     + Math.abs(((ContO) conto).keyx[3])));
	    if (d >= 0.9998)
		i_84_ = i;
	    else
		i_84_
		    = (int) (Math.acos(d) / 0.017453292519943295 * (double) i);
	}
	if (bool_6_) {
	    int i_85_;
	    for (i_85_ = Math.abs(((ContO) conto).xz + 45); i_85_ > 180;
		 i_85_ -= 360) {
		/* empty */
	    }
	    if (Math.abs(i_85_) > 90)
		((Mad) this).pmlt = 1;
	    else
		((Mad) this).pmlt = -1;
	    for (i_85_ = Math.abs(((ContO) conto).xz - 45); i_85_ > 180;
		 i_85_ -= 360) {
		/* empty */
	    }
	    if (Math.abs(i_85_) > 90)
		((Mad) this).nmlt = 1;
	    else
		((Mad) this).nmlt = -1;
	}
	((ContO) conto).xz
	    += (((Mad) this).forca
		* (((Mad) this).scz[0] * (float) ((Mad) this).nmlt
		   - ((Mad) this).scz[1] * (float) ((Mad) this).pmlt
		   + ((Mad) this).scz[2] * (float) ((Mad) this).pmlt
		   - ((Mad) this).scz[3] * (float) ((Mad) this).nmlt
		   + ((Mad) this).scx[0] * (float) ((Mad) this).pmlt
		   + ((Mad) this).scx[1] * (float) ((Mad) this).nmlt
		   - ((Mad) this).scx[2] * (float) ((Mad) this).nmlt
		   - ((Mad) this).scx[3] * (float) ((Mad) this).pmlt));
	if (Math.abs(i_82_) > Math.abs(i_81_))
	    i_81_ = i_82_;
	if (Math.abs(i_84_) > Math.abs(i_83_))
	    i_83_ = i_84_;
	if (!bool)
	    ((Mad) this).pzy += i_81_;
	else
	    ((Mad) this).pzy -= i_81_;
	if (!bool_8_)
	    ((Mad) this).pxy += i_83_;
	else
	    ((Mad) this).pxy -= i_83_;
	if (i_45_ == 4) {
	    int i_86_ = 0;
	    while (((Mad) this).pzy < 360) {
		((Mad) this).pzy += 360;
		((ContO) conto).zy += 360;
	    }
	    while (((Mad) this).pzy > 360) {
		((Mad) this).pzy -= 360;
		((ContO) conto).zy -= 360;
	    }
	    if (((Mad) this).pzy < 190 && ((Mad) this).pzy > 170) {
		((Mad) this).pzy = 180;
		((ContO) conto).zy = 180;
		i_86_++;
	    }
	    if (((Mad) this).pzy > 350 || ((Mad) this).pzy < 10) {
		((Mad) this).pzy = 0;
		((ContO) conto).zy = 0;
		i_86_++;
	    }
	    while (((Mad) this).pxy < 360) {
		((Mad) this).pxy += 360;
		((ContO) conto).xy += 360;
	    }
	    while (((Mad) this).pxy > 360) {
		((Mad) this).pxy -= 360;
		((ContO) conto).xy -= 360;
	    }
	    if (((Mad) this).pxy < 190 && ((Mad) this).pxy > 170) {
		((Mad) this).pxy = 180;
		((ContO) conto).xy = 180;
		i_86_++;
	    }
	    if (((Mad) this).pxy > 350 || ((Mad) this).pxy < 10) {
		((Mad) this).pxy = 0;
		((ContO) conto).xy = 0;
		i_86_++;
	    }
	    if (i_86_ == 2)
		((Mad) this).mtouch = true;
	}
	if (!((Mad) this).mtouch && ((Mad) this).wtouch) {
	    if (((Mad) this).cntouch == 10)
		((Mad) this).mtouch = true;
	    else
		((Mad) this).cntouch++;
	} else
	    ((Mad) this).cntouch = 0;
	((ContO) conto).y
	    = (int) ((fs_23_[0] + fs_23_[1] + fs_23_[2] + fs_23_[3]) / 4.0F
		     - ((float) i_10_ * ((Mad) this).m.cos(((Mad) this).pzy)
			* ((Mad) this).m.cos(((Mad) this).pxy))
		     + f_12_);
	if (bool)
	    i = -1;
	else
	    i = 1;
	((ContO) conto).x
	    = (int) ((fs[0]
		      - ((float) ((ContO) conto).keyx[0]
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      + ((float) (i * ((ContO) conto).keyz[0])
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs[1]
		      - ((float) ((ContO) conto).keyx[1]
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      + ((float) (i * ((ContO) conto).keyz[1])
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs[2]
		      - ((float) ((ContO) conto).keyx[2]
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      + ((float) (i * ((ContO) conto).keyz[2])
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs[3]
		      - ((float) ((ContO) conto).keyx[3]
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      + ((float) (i * ((ContO) conto).keyz[3])
			 * ((Mad) this).m.sin(((ContO) conto).xz))) / 4.0F
		     + ((float) i_10_ * ((Mad) this).m.sin(((Mad) this).pxy)
			* ((Mad) this).m.cos(((ContO) conto).xz))
		     - ((float) i_10_ * ((Mad) this).m.sin(((Mad) this).pzy)
			* ((Mad) this).m.sin(((ContO) conto).xz))
		     + f);
	((ContO) conto).z
	    = (int) ((fs_22_[0]
		      - ((float) (i * ((ContO) conto).keyz[0])
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      - ((float) ((ContO) conto).keyx[0]
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs_22_[1]
		      - ((float) (i * ((ContO) conto).keyz[1])
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      - ((float) ((ContO) conto).keyx[1]
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs_22_[2]
		      - ((float) (i * ((ContO) conto).keyz[2])
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      - ((float) ((ContO) conto).keyx[2]
			 * ((Mad) this).m.sin(((ContO) conto).xz))
		      + fs_22_[3]
		      - ((float) (i * ((ContO) conto).keyz[3])
			 * ((Mad) this).m.cos(((ContO) conto).xz))
		      - ((float) ((ContO) conto).keyx[3]
			 * ((Mad) this).m.sin(((ContO) conto).xz))) / 4.0F
		     + ((float) i_10_ * ((Mad) this).m.sin(((Mad) this).pxy)
			* ((Mad) this).m.sin(((ContO) conto).xz))
		     - ((float) i_10_ * ((Mad) this).m.sin(((Mad) this).pzy)
			* ((Mad) this).m.cos(((ContO) conto).xz))
		     + f_11_);
	if (Math.abs(((Mad) this).speed) > 10.0F || !((Mad) this).mtouch) {
	    if (Math.abs(((Mad) this).pxy - ((ContO) conto).xy) >= 4) {
		if (((Mad) this).pxy > ((ContO) conto).xy)
		    ((ContO) conto).xy
			+= 2 + (((Mad) this).pxy - ((ContO) conto).xy) / 2;
		else
		    ((ContO) conto).xy
			-= 2 + (((ContO) conto).xy - ((Mad) this).pxy) / 2;
	    } else
		((ContO) conto).xy = ((Mad) this).pxy;
	    if (Math.abs(((Mad) this).pzy - ((ContO) conto).zy) >= 4) {
		if (((Mad) this).pzy > ((ContO) conto).zy)
		    ((ContO) conto).zy
			+= 2 + (((Mad) this).pzy - ((ContO) conto).zy) / 2;
		else
		    ((ContO) conto).zy
			-= 2 + (((ContO) conto).zy - ((Mad) this).pzy) / 2;
	    } else
		((ContO) conto).zy = ((Mad) this).pzy;
	}
	if (((Mad) this).wtouch && !((Mad) this).capsized) {
	    float f_87_
		= (float) ((double) (((Mad) this).speed
				     / (float) (((CarDefine) ((Mad) this).cd)
						.swits[((Mad) this).cn][2])
				     * 14.0F)
			   * ((double) (((CarDefine) ((Mad) this).cd).bounce
					[((Mad) this).cn])
			      - 0.4));
	    if (((Control) control).left && ((Mad) this).tilt < f_87_
		&& ((Mad) this).tilt >= 0.0F)
		((Mad) this).tilt += 0.4;
	    else if (((Control) control).right && ((Mad) this).tilt > -f_87_
		     && ((Mad) this).tilt <= 0.0F)
		((Mad) this).tilt -= 0.4;
	    else if ((double) Math.abs(((Mad) this).tilt)
		     > 3.0 * ((double) (((CarDefine) ((Mad) this).cd).bounce
					[((Mad) this).cn])
			      - 0.4)) {
		if (((Mad) this).tilt > 0.0F)
		    ((Mad) this).tilt
			-= 3.0 * ((double) (((CarDefine) ((Mad) this).cd)
					    .bounce[((Mad) this).cn])
				  - 0.3);
		else
		    ((Mad) this).tilt
			+= 3.0 * ((double) (((CarDefine) ((Mad) this).cd)
					    .bounce[((Mad) this).cn])
				  - 0.3);
	    } else
		((Mad) this).tilt = 0.0F;
	    ((ContO) conto).xy += ((Mad) this).tilt;
	    if (((Mad) this).gtouch)
		((ContO) conto).y -= (double) ((Mad) this).tilt / 1.5;
	} else if (((Mad) this).tilt != 0.0F)
	    ((Mad) this).tilt = 0.0F;
	if (((Mad) this).wtouch && i_32_ == 2) {
	    ((ContO) conto).zy
		+= (int) ((double) ((((Mad) this).m.random() * 6.0F
				     * ((Mad) this).speed
				     / (float) (((CarDefine) ((Mad) this).cd)
						.swits[((Mad) this).cn][2]))
				    - (3.0F * ((Mad) this).speed
				       / (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn][2])))
			  * ((double) (((CarDefine) ((Mad) this).cd).bounce
				       [((Mad) this).cn])
			     - 0.3));
	    ((ContO) conto).xy
		+= (int) ((double) ((((Mad) this).m.random() * 6.0F
				     * ((Mad) this).speed
				     / (float) (((CarDefine) ((Mad) this).cd)
						.swits[((Mad) this).cn][2]))
				    - (3.0F * ((Mad) this).speed
				       / (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn][2])))
			  * ((double) (((CarDefine) ((Mad) this).cd).bounce
				       [((Mad) this).cn])
			     - 0.3));
	}
	if (((Mad) this).wtouch && i_32_ == 1) {
	    ((ContO) conto).zy
		+= (int) ((double) ((((Mad) this).m.random() * 4.0F
				     * ((Mad) this).speed
				     / (float) (((CarDefine) ((Mad) this).cd)
						.swits[((Mad) this).cn][2]))
				    - (2.0F * ((Mad) this).speed
				       / (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn][2])))
			  * ((double) (((CarDefine) ((Mad) this).cd).bounce
				       [((Mad) this).cn])
			     - 0.3));
	    ((ContO) conto).xy
		+= (int) ((double) ((((Mad) this).m.random() * 4.0F
				     * ((Mad) this).speed
				     / (float) (((CarDefine) ((Mad) this).cd)
						.swits[((Mad) this).cn][2]))
				    - (2.0F * ((Mad) this).speed
				       / (float) (((CarDefine) ((Mad) this).cd)
						  .swits[((Mad) this).cn][2])))
			  * ((double) (((CarDefine) ((Mad) this).cd).bounce
				       [((Mad) this).cn])
			     - 0.3));
	}
	if ((((Mad) this).hitmag
	     >= ((CarDefine) ((Mad) this).cd).maxmag[((Mad) this).cn])
	    && !((Mad) this).dest) {
	    distruct(conto);
	    if (((Mad) this).cntdest == 7)
		((Mad) this).dest = true;
	    else
		((Mad) this).cntdest++;
	    if (((Mad) this).cntdest == 1)
		((Record) ((Mad) this).rpd).dest[((Mad) this).im] = 300;
	}
	if (((ContO) conto).dist == 0) {
	    for (int i_88_ = 0; i_88_ < ((ContO) conto).npl; i_88_++) {
		if (((Plane) ((ContO) conto).p[i_88_]).chip != 0)
		    ((Plane) ((ContO) conto).p[i_88_]).chip = 0;
		if (((Plane) ((ContO) conto).p[i_88_]).embos != 0)
		    ((Plane) ((ContO) conto).p[i_88_]).embos = 13;
	    }
	}
	int i_89_ = 0;
	int i_90_ = 0;
	int i_91_ = 0;
	if (((Mad) this).nofocus)
	    i_4_ = 1;
	else
	    i_4_ = 7;
	for (int i_92_ = 0; i_92_ < ((CheckPoints) checkpoints).n; i_92_++) {
	    if (((CheckPoints) checkpoints).typ[i_92_] > 0) {
		i_91_++;
		if (((CheckPoints) checkpoints).typ[i_92_] == 1) {
		    if (((Mad) this).clear
			== i_91_ + (((Mad) this).nlaps
				    * ((CheckPoints) checkpoints).nsp))
			i_4_ = 1;
		    if (((float) Math.abs(((ContO) conto).z
					  - (((CheckPoints) checkpoints).z
					     [i_92_]))
			 < 60.0F + Math.abs(((Mad) this).scz[0]
					    + ((Mad) this).scz[1]
					    + ((Mad) this).scz[2]
					    + ((Mad) this).scz[3]) / 4.0F)
			&& (Math.abs(((ContO) conto).x
				     - ((CheckPoints) checkpoints).x[i_92_])
			    < 700)
			&& Math.abs(((ContO) conto).y
				    - ((CheckPoints) checkpoints).y[i_92_]
				    + 350) < 450
			&& (((Mad) this).clear
			    == (i_91_
				+ (((Mad) this).nlaps
				   * ((CheckPoints) checkpoints).nsp)
				- 1))) {
			((Mad) this).clear
			    = i_91_ + (((Mad) this).nlaps
				       * ((CheckPoints) checkpoints).nsp);
			((Mad) this).pcleared = i_92_;
			((Mad) this).focus = -1;
		    }
		}
		if (((CheckPoints) checkpoints).typ[i_92_] == 2) {
		    if (((Mad) this).clear
			== i_91_ + (((Mad) this).nlaps
				    * ((CheckPoints) checkpoints).nsp))
			i_4_ = 1;
		    if (((float) Math.abs(((ContO) conto).x
					  - (((CheckPoints) checkpoints).x
					     [i_92_]))
			 < 60.0F + Math.abs(((Mad) this).scx[0]
					    + ((Mad) this).scx[1]
					    + ((Mad) this).scx[2]
					    + ((Mad) this).scx[3]) / 4.0F)
			&& (Math.abs(((ContO) conto).z
				     - ((CheckPoints) checkpoints).z[i_92_])
			    < 700)
			&& Math.abs(((ContO) conto).y
				    - ((CheckPoints) checkpoints).y[i_92_]
				    + 350) < 450
			&& (((Mad) this).clear
			    == (i_91_
				+ (((Mad) this).nlaps
				   * ((CheckPoints) checkpoints).nsp)
				- 1))) {
			((Mad) this).clear
			    = i_91_ + (((Mad) this).nlaps
				       * ((CheckPoints) checkpoints).nsp);
			((Mad) this).pcleared = i_92_;
			((Mad) this).focus = -1;
		    }
		}
	    }
	    if (py(((ContO) conto).x / 100,
		   ((CheckPoints) checkpoints).x[i_92_] / 100,
		   ((ContO) conto).z / 100,
		   ((CheckPoints) checkpoints).z[i_92_] / 100) * i_4_ < i_90_
		|| i_90_ == 0) {
		i_89_ = i_92_;
		i_90_ = py(((ContO) conto).x / 100,
			   ((CheckPoints) checkpoints).x[i_92_] / 100,
			   ((ContO) conto).z / 100,
			   ((CheckPoints) checkpoints).z[i_92_] / 100) * i_4_;
	    }
	}
	if (((Mad) this).clear
	    == i_91_ + ((Mad) this).nlaps * ((CheckPoints) checkpoints).nsp) {
	    ((Mad) this).nlaps++;
	    if (((xtGraphics) ((Mad) this).xt).multion == 1
		&& ((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
		if ((((xtGraphics) ((Mad) this).xt).laptime
		     < ((xtGraphics) ((Mad) this).xt).fastestlap)
		    || ((xtGraphics) ((Mad) this).xt).fastestlap == 0)
		    ((xtGraphics) ((Mad) this).xt).fastestlap
			= ((xtGraphics) ((Mad) this).xt).laptime;
		((xtGraphics) ((Mad) this).xt).laptime = 0;
	    }
	}
	if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
	    if (((xtGraphics) ((Mad) this).xt).multion == 1
		&& ((xtGraphics) ((Mad) this).xt).starcnt == 0)
		((xtGraphics) ((Mad) this).xt).laptime++;
	    for (((Medium) ((Mad) this).m).checkpoint = ((Mad) this).clear;
		 (((Medium) ((Mad) this).m).checkpoint
		  >= ((CheckPoints) checkpoints).nsp);
		 ((Medium) ((Mad) this).m).checkpoint
		     -= ((CheckPoints) checkpoints).nsp) {
		/* empty */
	    }
	    if (((Mad) this).clear == (((CheckPoints) checkpoints).nlaps
				       * ((CheckPoints) checkpoints).nsp) - 1)
		((Medium) ((Mad) this).m).lastcheck = true;
	    if (((CheckPoints) checkpoints).haltall)
		((Medium) ((Mad) this).m).lastcheck = false;
	}
	if (((Mad) this).focus == -1) {
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im)
		i_89_ += 2;
	    else
		i_89_++;
	    if (!((Mad) this).nofocus) {
		i_91_ = ((Mad) this).pcleared + 1;
		if (i_91_ >= ((CheckPoints) checkpoints).n)
		    i_91_ = 0;
		while (((CheckPoints) checkpoints).typ[i_91_] <= 0) {
		    if (++i_91_ >= ((CheckPoints) checkpoints).n)
			i_91_ = 0;
		}
		if (i_89_ > i_91_ && ((((Mad) this).clear
				       != (((Mad) this).nlaps
					   * ((CheckPoints) checkpoints).nsp))
				      || i_89_ < ((Mad) this).pcleared)) {
		    i_89_ = i_91_;
		    ((Mad) this).focus = i_89_;
		}
	    }
	    if (i_89_ >= ((CheckPoints) checkpoints).n)
		i_89_ -= ((CheckPoints) checkpoints).n;
	    if (((CheckPoints) checkpoints).typ[i_89_] == -3)
		i_89_ = 0;
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
		if (((Mad) this).missedcp != -1)
		    ((Mad) this).missedcp = -1;
	    } else if (((Mad) this).missedcp != 0)
		((Mad) this).missedcp = 0;
	} else {
	    i_89_ = ((Mad) this).focus;
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
		if (((Mad) this).missedcp == 0 && ((Mad) this).mtouch
		    && (Math.sqrt((double) py(((ContO) conto).x / 10,
					      (((CheckPoints) checkpoints).x
					       [((Mad) this).focus]) / 10,
					      ((ContO) conto).z / 10,
					      (((CheckPoints) checkpoints).z
					       [((Mad) this).focus]) / 10))
			> 800.0))
		    ((Mad) this).missedcp = 1;
		if (((Mad) this).missedcp == -2
		    && (Math.sqrt((double) py(((ContO) conto).x / 10,
					      (((CheckPoints) checkpoints).x
					       [((Mad) this).focus]) / 10,
					      ((ContO) conto).z / 10,
					      (((CheckPoints) checkpoints).z
					       [((Mad) this).focus]) / 10))
			< 400.0))
		    ((Mad) this).missedcp = 0;
		if (((Mad) this).missedcp != 0 && ((Mad) this).mtouch
		    && (Math.sqrt((double) py(((ContO) conto).x / 10,
					      (((CheckPoints) checkpoints).x
					       [((Mad) this).focus]) / 10,
					      ((ContO) conto).z / 10,
					      (((CheckPoints) checkpoints).z
					       [((Mad) this).focus]) / 10))
			< 250.0))
		    ((Mad) this).missedcp = 68;
	    } else
		((Mad) this).missedcp = 1;
	    if (((Mad) this).nofocus) {
		((Mad) this).focus = -1;
		((Mad) this).missedcp = 0;
	    }
	}
	if (((Mad) this).nofocus)
	    ((Mad) this).nofocus = false;
	((Mad) this).point = i_89_;
	if (((Mad) this).fixes != 0) {
	    if (((Medium) ((Mad) this).m).noelec == 0) {
		for (int i_93_ = 0; i_93_ < ((CheckPoints) checkpoints).fn;
		     i_93_++) {
		    if (!((CheckPoints) checkpoints).roted[i_93_]) {
			if ((Math.abs(((ContO) conto).z
				      - ((CheckPoints) checkpoints).fz[i_93_])
			     < 200)
			    && (py(((ContO) conto).x / 100,
				   ((CheckPoints) checkpoints).fx[i_93_] / 100,
				   ((ContO) conto).y / 100,
				   ((CheckPoints) checkpoints).fy[i_93_] / 100)
				< 30)) {
			    if (((ContO) conto).dist == 0)
				((ContO) conto).fcnt = 8;
			    else {
				if ((((Mad) this).im
				     == ((xtGraphics) ((Mad) this).xt).im)
				    && !((ContO) conto).fix
				    && !((xtGraphics) ((Mad) this).xt).mutes)
				    ((xtGraphics) ((Mad) this).xt).carfixed
					.play();
				((ContO) conto).fix = true;
			    }
			    ((Record) ((Mad) this).rpd).fix[((Mad) this).im]
				= 300;
			}
		    } else if (Math.abs(((ContO) conto).x
					- (((CheckPoints) checkpoints).fx
					   [i_93_])) < 200
			       && py(((ContO) conto).z / 100,
				     (((CheckPoints) checkpoints).fz[i_93_]
				      / 100),
				     ((ContO) conto).y / 100,
				     (((CheckPoints) checkpoints).fy[i_93_]
				      / 100)) < 30) {
			if (((ContO) conto).dist == 0)
			    ((ContO) conto).fcnt = 8;
			else {
			    if ((((Mad) this).im
				 == ((xtGraphics) ((Mad) this).xt).im)
				&& !((ContO) conto).fix
				&& !((xtGraphics) ((Mad) this).xt).mutes)
				((xtGraphics) ((Mad) this).xt).carfixed.play();
			    ((ContO) conto).fix = true;
			}
			((Record) ((Mad) this).rpd).fix[((Mad) this).im] = 300;
		    }
		}
	    }
	} else {
	    for (int i_94_ = 0; i_94_ < ((CheckPoints) checkpoints).fn;
		 i_94_++) {
		if (rpy((float) (((ContO) conto).x / 100),
			(float) (((CheckPoints) checkpoints).fx[i_94_] / 100),
			(float) (((ContO) conto).y / 100),
			(float) (((CheckPoints) checkpoints).fy[i_94_] / 100),
			(float) (((ContO) conto).z / 100),
			(float) (((CheckPoints) checkpoints).fz[i_94_] / 100))
		    < 760)
		    ((Medium) ((Mad) this).m).noelec = 2;
	    }
	}
	if (((ContO) conto).fcnt == 7 || ((ContO) conto).fcnt == 8) {
	    ((Mad) this).squash = 0;
	    ((Mad) this).nbsq = 0;
	    ((Mad) this).hitmag = 0;
	    ((Mad) this).cntdest = 0;
	    ((Mad) this).dest = false;
	    ((Mad) this).newcar = true;
	    ((ContO) conto).fcnt = 9;
	    if (((Mad) this).fixes > 0)
		((Mad) this).fixes--;
	}
	if (((Mad) this).newedcar != 0) {
	    ((Mad) this).newedcar--;
	    if (((Mad) this).newedcar == 10)
		((Mad) this).newcar = false;
	}
	if (!((Mad) this).mtouch) {
	    if (((Mad) this).trcnt != 1) {
		((Mad) this).trcnt = 1;
		((Mad) this).lxz = ((ContO) conto).xz;
	    }
	    if (((Mad) this).loop == 2 || ((Mad) this).loop == -1) {
		((Mad) this).travxy += ((Mad) this).rcomp - ((Mad) this).lcomp;
		if (Math.abs(((Mad) this).travxy) > 135)
		    ((Mad) this).rtab = true;
		((Mad) this).travzy += ((Mad) this).ucomp - ((Mad) this).dcomp;
		if (((Mad) this).travzy > 135)
		    ((Mad) this).ftab = true;
		if (((Mad) this).travzy < -135)
		    ((Mad) this).btab = true;
	    }
	    if (((Mad) this).lxz != ((ContO) conto).xz) {
		((Mad) this).travxz += ((Mad) this).lxz - ((ContO) conto).xz;
		((Mad) this).lxz = ((ContO) conto).xz;
	    }
	    if (((Mad) this).srfcnt < 10) {
		if (((Control) control).wall != -1)
		    ((Mad) this).surfer = true;
		((Mad) this).srfcnt++;
	    }
	} else if (!((Mad) this).dest) {
	    if (!((Mad) this).capsized) {
		if (((Mad) this).capcnt != 0)
		    ((Mad) this).capcnt = 0;
		if (((Mad) this).gtouch && ((Mad) this).trcnt != 0) {
		    if (((Mad) this).trcnt == 9) {
			((Mad) this).powerup = 0.0F;
			if (Math.abs(((Mad) this).travxy) > 90)
			    ((Mad) this).powerup
				+= ((float) Math.abs(((Mad) this).travxy)
				    / 24.0F);
			else if (((Mad) this).rtab)
			    ((Mad) this).powerup += 30.0F;
			if (Math.abs(((Mad) this).travzy) > 90)
			    ((Mad) this).powerup
				+= ((float) Math.abs(((Mad) this).travzy)
				    / 18.0F);
			else {
			    if (((Mad) this).ftab)
				((Mad) this).powerup += 40.0F;
			    if (((Mad) this).btab)
				((Mad) this).powerup += 40.0F;
			}
			if (Math.abs(((Mad) this).travxz) > 90)
			    ((Mad) this).powerup
				+= ((float) Math.abs(((Mad) this).travxz)
				    / 18.0F);
			if (((Mad) this).surfer)
			    ((Mad) this).powerup += 30.0F;
			((Mad) this).power += ((Mad) this).powerup;
			if ((((Mad) this).im
			     == ((xtGraphics) ((Mad) this).xt).im)
			    && ((int) ((Mad) this).powerup
				> ((Record) ((Mad) this).rpd).powered)
			    && ((Record) ((Mad) this).rpd).wasted == 0
			    && (((Mad) this).powerup > 60.0F
				|| ((CheckPoints) checkpoints).stage == 1
				|| ((CheckPoints) checkpoints).stage == 2)) {
			    ((Mad) this).rpdcatch = 30;
			    if (((Record) ((Mad) this).rpd).hcaught)
				((Record) ((Mad) this).rpd).powered
				    = (int) ((Mad) this).powerup;
			    if (((xtGraphics) ((Mad) this).xt).multion == 1
				&& (((Mad) this).powerup
				    > (float) (((xtGraphics) ((Mad) this).xt)
					       .beststunt)))
				((xtGraphics) ((Mad) this).xt).beststunt
				    = (int) ((Mad) this).powerup;
			}
			if (((Mad) this).power > 98.0F) {
			    ((Mad) this).power = 98.0F;
			    if (((Mad) this).powerup > 150.0F)
				((Mad) this).xtpower = 200;
			    else
				((Mad) this).xtpower = 100;
			}
		    }
		    if (((Mad) this).trcnt == 10) {
			((Mad) this).travxy = 0;
			((Mad) this).travzy = 0;
			((Mad) this).travxz = 0;
			((Mad) this).ftab = false;
			((Mad) this).rtab = false;
			((Mad) this).btab = false;
			((Mad) this).trcnt = 0;
			((Mad) this).srfcnt = 0;
			((Mad) this).surfer = false;
		    } else
			((Mad) this).trcnt++;
		}
	    } else {
		if (((Mad) this).trcnt != 0) {
		    ((Mad) this).travxy = 0;
		    ((Mad) this).travzy = 0;
		    ((Mad) this).travxz = 0;
		    ((Mad) this).ftab = false;
		    ((Mad) this).rtab = false;
		    ((Mad) this).btab = false;
		    ((Mad) this).trcnt = 0;
		    ((Mad) this).srfcnt = 0;
		    ((Mad) this).surfer = false;
		}
		if (((Mad) this).capcnt == 0) {
		    int i_95_ = 0;
		    for (int i_96_ = 0; i_96_ < 4; i_96_++) {
			if (Math.abs(((Mad) this).scz[i_96_]) < 70.0F
			    && Math.abs(((Mad) this).scx[i_96_]) < 70.0F)
			    i_95_++;
		    }
		    if (i_95_ == 4)
			((Mad) this).capcnt = 1;
		} else {
		    ((Mad) this).capcnt++;
		    if (((Mad) this).capcnt == 30) {
			((Mad) this).speed = 0.0F;
			((ContO) conto).y += (((CarDefine) ((Mad) this).cd)
					      .flipy[((Mad) this).cn]);
			((Mad) this).pxy += 180;
			((ContO) conto).xy += 180;
			((Mad) this).capcnt = 0;
		    }
		}
	    }
	    if (((Mad) this).trcnt == 0 && ((Mad) this).speed != 0.0F) {
		if (((Mad) this).xtpower == 0) {
		    if (((Mad) this).power > 0.0F)
			((Mad) this).power
			    -= (((Mad) this).power * ((Mad) this).power
				* ((Mad) this).power
				/ (float) (((CarDefine) ((Mad) this).cd)
					   .powerloss[((Mad) this).cn]));
		    else
			((Mad) this).power = 0.0F;
		} else
		    ((Mad) this).xtpower--;
	    }
	}
	if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im) {
	    if (((Control) control).wall != -1)
		((Control) control).wall = -1;
	} else if (((Mad) this).lastcolido != 0 && !((Mad) this).dest)
	    ((Mad) this).lastcolido--;
	if (((Mad) this).dest) {
	    if (((CheckPoints) checkpoints).dested[((Mad) this).im] == 0) {
		if (((Mad) this).lastcolido == 0)
		    ((CheckPoints) checkpoints).dested[((Mad) this).im] = 1;
		else
		    ((CheckPoints) checkpoints).dested[((Mad) this).im] = 2;
	    }
	} else if (((CheckPoints) checkpoints).dested[((Mad) this).im] != 0
		   && ((CheckPoints) checkpoints).dested[((Mad) this).im] != 3)
	    ((CheckPoints) checkpoints).dested[((Mad) this).im] = 0;
	if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im
	    && ((Record) ((Mad) this).rpd).wasted == 0
	    && ((Mad) this).rpdcatch != 0) {
	    ((Mad) this).rpdcatch--;
	    if (((Mad) this).rpdcatch == 0) {
		((Mad) this).rpd.cotchinow(((Mad) this).im);
		if (((Record) ((Mad) this).rpd).hcaught)
		    ((Record) ((Mad) this).rpd).whenwasted
			= (int) (185.0F + ((Mad) this).m.random() * 20.0F);
	    }
	}
    }
    
    public void distruct(ContO conto) {
	for (int i = 0; i < ((ContO) conto).npl; i++) {
	    if (((Plane) ((ContO) conto).p[i]).wz == 0
		|| ((Plane) ((ContO) conto).p[i]).gr == -17
		|| ((Plane) ((ContO) conto).p[i]).gr == -16)
		((Plane) ((ContO) conto).p[i]).embos = 1;
	}
    }
    
    public int regy(int i, float f, ContO conto) {
	int i_97_ = 0;
	boolean bool = true;
	if (((xtGraphics) ((Mad) this).xt).multion == 1
	    && ((xtGraphics) ((Mad) this).xt).im != ((Mad) this).im)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).multion >= 2)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).lan
	    && ((xtGraphics) ((Mad) this).xt).multion >= 1
	    && ((xtGraphics) ((Mad) this).xt).isbot[((Mad) this).im])
	    bool = true;
	f *= ((CarDefine) ((Mad) this).cd).dammult[((Mad) this).cn];
	if (f > 100.0F) {
	    ((Mad) this).rpd.recy(i, f, ((Mad) this).mtouch, ((Mad) this).im);
	    f -= 100.0F;
	    int i_98_ = 0;
	    int i_99_ = 0;
	    int i_100_ = ((ContO) conto).zy;
	    int i_101_ = ((ContO) conto).xy;
	    for (/**/; i_100_ < 360; i_100_ += 360) {
		/* empty */
	    }
	    for (/**/; i_100_ > 360; i_100_ -= 360) {
		/* empty */
	    }
	    if (i_100_ < 210 && i_100_ > 150)
		i_98_ = -1;
	    if (i_100_ > 330 || i_100_ < 30)
		i_98_ = 1;
	    for (/**/; i_101_ < 360; i_101_ += 360) {
		/* empty */
	    }
	    for (/**/; i_101_ > 360; i_101_ -= 360) {
		/* empty */
	    }
	    if (i_101_ < 210 && i_101_ > 150)
		i_99_ = -1;
	    if (i_101_ > 330 || i_101_ < 30)
		i_99_ = 1;
	    if (i_99_ * i_98_ == 0)
		((Mad) this).shakedam
		    = (int) ((Math.abs(f) + (float) ((Mad) this).shakedam)
			     / 2.0F);
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im
		|| ((Mad) this).colidim)
		((Mad) this).xt.crash(f, i_99_ * i_98_);
	    if (i_99_ * i_98_ == 0 || ((Mad) this).mtouch) {
		for (int i_102_ = 0; i_102_ < ((ContO) conto).npl; i_102_++) {
		    float f_103_ = 0.0F;
		    for (int i_104_ = 0;
			 i_104_ < ((Plane) ((ContO) conto).p[i_102_]).n;
			 i_104_++) {
			if (((Plane) ((ContO) conto).p[i_102_]).wz == 0
			    && (py(((ContO) conto).keyx[i],
				   (((Plane) ((ContO) conto).p[i_102_]).ox
				    [i_104_]),
				   ((ContO) conto).keyz[i],
				   (((Plane) ((ContO) conto).p[i_102_]).oz
				    [i_104_]))
				< (((CarDefine) ((Mad) this).cd).clrad
				   [((Mad) this).cn]))) {
			    f_103_ = f / 20.0F * ((Mad) this).m.random();
			    ((Plane) ((ContO) conto).p[i_102_]).oz[i_104_]
				+= f_103_ * ((Mad) this).m.sin(i_100_);
			    ((Plane) ((ContO) conto).p[i_102_]).ox[i_104_]
				-= f_103_ * ((Mad) this).m.sin(i_101_);
			    if (bool) {
				((Mad) this).hitmag += Math.abs(f_103_);
				i_97_ += Math.abs(f_103_);
			    }
			}
		    }
		    if (f_103_ != 0.0F) {
			if (Math.abs(f_103_) >= 1.0F) {
			    ((Plane) ((ContO) conto).p[i_102_]).chip = 1;
			    ((Plane) ((ContO) conto).p[i_102_]).ctmag = f_103_;
			}
			if (!((Plane) ((ContO) conto).p[i_102_]).nocol
			    && (((Plane) ((ContO) conto).p[i_102_]).glass
				!= 1)) {
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 20
				&& (double) ((Plane) (((ContO) conto).p
						      [i_102_])).hsb[1] > 0.25)
				((Plane) ((ContO) conto).p[i_102_]).hsb[1]
				    = 0.25F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 25
				&& (double) ((Plane) (((ContO) conto).p
						      [i_102_])).hsb[2] > 0.7)
				((Plane) ((ContO) conto).p[i_102_]).hsb[2]
				    = 0.7F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 30
				&& (double) ((Plane) (((ContO) conto).p
						      [i_102_])).hsb[1] > 0.15)
				((Plane) ((ContO) conto).p[i_102_]).hsb[1]
				    = 0.15F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 35
				&& (double) ((Plane) (((ContO) conto).p
						      [i_102_])).hsb[2] > 0.6)
				((Plane) ((ContO) conto).p[i_102_]).hsb[2]
				    = 0.6F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 40)
				((Plane) ((ContO) conto).p[i_102_]).hsb[0]
				    = 0.075F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 50
				&& (double) ((Plane) (((ContO) conto).p
						      [i_102_])).hsb[2] > 0.5)
				((Plane) ((ContO) conto).p[i_102_]).hsb[2]
				    = 0.5F;
			    if (((Plane) ((ContO) conto).p[i_102_]).bfase > 60)
				((Plane) ((ContO) conto).p[i_102_]).hsb[0]
				    = 0.05F;
			    ((Plane) ((ContO) conto).p[i_102_]).bfase
				+= f_103_;
			    new Color(((Plane) ((ContO) conto).p[i_102_]).c[0],
				      ((Plane) ((ContO) conto).p[i_102_]).c[1],
				      (((Plane) ((ContO) conto).p[i_102_]).c
				       [2]));
			    Color color
				= (Color.getHSBColor
				   (((Plane) ((ContO) conto).p[i_102_]).hsb[0],
				    ((Plane) ((ContO) conto).p[i_102_]).hsb[1],
				    (((Plane) ((ContO) conto).p[i_102_]).hsb
				     [2])));
			    ((Plane) ((ContO) conto).p[i_102_]).c[0]
				= color.getRed();
			    ((Plane) ((ContO) conto).p[i_102_]).c[1]
				= color.getGreen();
			    ((Plane) ((ContO) conto).p[i_102_]).c[2]
				= color.getBlue();
			}
			if (((Plane) ((ContO) conto).p[i_102_]).glass == 1)
			    ((Plane) ((ContO) conto).p[i_102_]).gr
				+= Math.abs((double) f_103_ * 1.5);
		    }
		}
	    }
	    if (i_99_ * i_98_ == -1) {
		if (((Mad) this).nbsq > 0) {
		    int i_105_ = 0;
		    int i_106_ = 1;
		    for (int i_107_ = 0; i_107_ < ((ContO) conto).npl;
			 i_107_++) {
			float f_108_ = 0.0F;
			for (int i_109_ = 0;
			     i_109_ < ((Plane) ((ContO) conto).p[i_107_]).n;
			     i_109_++) {
			    if (((Plane) ((ContO) conto).p[i_107_]).wz == 0) {
				f_108_ = f / 15.0F * ((Mad) this).m.random();
				if (((Math.abs(((Plane) (((ContO) conto).p
							 [i_107_])).oy[i_109_]
					       - (((CarDefine) ((Mad) this).cd)
						  .flipy[((Mad) this).cn])
					       - ((Mad) this).squash)
				      < (((CarDefine) ((Mad) this).cd).msquash
					 [((Mad) this).cn]) * 3)
				     || ((((Plane) ((ContO) conto).p[i_107_])
					  .oy[i_109_])
					 < ((((CarDefine) ((Mad) this).cd)
					     .flipy[((Mad) this).cn])
					    + ((Mad) this).squash)))
				    && (((Mad) this).squash
					< (((CarDefine) ((Mad) this).cd)
					   .msquash[((Mad) this).cn]))) {
				    ((Plane) ((ContO) conto).p[i_107_]).oy
					[i_109_]
					+= f_108_;
				    i_105_ += f_108_;
				    i_106_++;
				    if (bool) {
					((Mad) this).hitmag
					    += Math.abs(f_108_);
					i_97_ += Math.abs(f_108_);
				    }
				}
			    }
			}
			if (((Plane) ((ContO) conto).p[i_107_]).glass == 1)
			    ((Plane) ((ContO) conto).p[i_107_]).gr += 5;
			else if (f_108_ != 0.0F)
			    ((Plane) ((ContO) conto).p[i_107_]).bfase
				+= f_108_;
			if (Math.abs(f_108_) >= 1.0F) {
			    ((Plane) ((ContO) conto).p[i_107_]).chip = 1;
			    ((Plane) ((ContO) conto).p[i_107_]).ctmag = f_108_;
			}
		    }
		    ((Mad) this).squash += i_105_ / i_106_;
		    ((Mad) this).nbsq = 0;
		} else
		    ((Mad) this).nbsq++;
	    }
	}
	return i_97_;
    }
    
    public int regx(int i, float f, ContO conto) {
	int i_110_ = 0;
	boolean bool = true;
	if (((xtGraphics) ((Mad) this).xt).multion == 1
	    && ((xtGraphics) ((Mad) this).xt).im != ((Mad) this).im)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).multion >= 2)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).lan
	    && ((xtGraphics) ((Mad) this).xt).multion >= 1
	    && ((xtGraphics) ((Mad) this).xt).isbot[((Mad) this).im])
	    bool = true;
	f *= ((CarDefine) ((Mad) this).cd).dammult[((Mad) this).cn];
	if (Math.abs(f) > 100.0F) {
	    ((Mad) this).rpd.recx(i, f, ((Mad) this).im);
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    ((Mad) this).shakedam
		= (int) ((Math.abs(f) + (float) ((Mad) this).shakedam) / 2.0F);
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im
		|| ((Mad) this).colidim)
		((Mad) this).xt.crash(f, 0);
	    for (int i_111_ = 0; i_111_ < ((ContO) conto).npl; i_111_++) {
		float f_112_ = 0.0F;
		for (int i_113_ = 0;
		     i_113_ < ((Plane) ((ContO) conto).p[i_111_]).n;
		     i_113_++) {
		    if (((Plane) ((ContO) conto).p[i_111_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_111_]).ox[i_113_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_111_]).oz[i_113_])
			    < (((CarDefine) ((Mad) this).cd).clrad
			       [((Mad) this).cn]))) {
			f_112_ = f / 20.0F * ((Mad) this).m.random();
			((Plane) ((ContO) conto).p[i_111_]).oz[i_113_]
			    -= (f_112_ * ((Mad) this).m.sin(((ContO) conto).xz)
				* ((Mad) this).m.cos(((ContO) conto).zy));
			((Plane) ((ContO) conto).p[i_111_]).ox[i_113_]
			    += (f_112_ * ((Mad) this).m.cos(((ContO) conto).xz)
				* ((Mad) this).m.cos(((ContO) conto).xy));
			if (bool) {
			    ((Mad) this).hitmag += Math.abs(f_112_);
			    i_110_ += Math.abs(f_112_);
			}
		    }
		}
		if (f_112_ != 0.0F) {
		    if (Math.abs(f_112_) >= 1.0F) {
			((Plane) ((ContO) conto).p[i_111_]).chip = 1;
			((Plane) ((ContO) conto).p[i_111_]).ctmag = f_112_;
		    }
		    if (!((Plane) ((ContO) conto).p[i_111_]).nocol
			&& ((Plane) ((ContO) conto).p[i_111_]).glass != 1) {
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 20
			    && (double) (((Plane) ((ContO) conto).p[i_111_])
					 .hsb[1]) > 0.25)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[1] = 0.25F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 25
			    && (double) (((Plane) ((ContO) conto).p[i_111_])
					 .hsb[2]) > 0.7)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[2] = 0.7F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 30
			    && (double) (((Plane) ((ContO) conto).p[i_111_])
					 .hsb[1]) > 0.15)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[1] = 0.15F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 35
			    && (double) (((Plane) ((ContO) conto).p[i_111_])
					 .hsb[2]) > 0.6)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[2] = 0.6F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 40)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[0]
				= 0.075F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 50
			    && (double) (((Plane) ((ContO) conto).p[i_111_])
					 .hsb[2]) > 0.5)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[2] = 0.5F;
			if (((Plane) ((ContO) conto).p[i_111_]).bfase > 60)
			    ((Plane) ((ContO) conto).p[i_111_]).hsb[0] = 0.05F;
			((Plane) ((ContO) conto).p[i_111_]).bfase
			    += Math.abs(f_112_);
			new Color(((Plane) ((ContO) conto).p[i_111_]).c[0],
				  ((Plane) ((ContO) conto).p[i_111_]).c[1],
				  ((Plane) ((ContO) conto).p[i_111_]).c[2]);
			Color color
			    = (Color.getHSBColor
			       (((Plane) ((ContO) conto).p[i_111_]).hsb[0],
				((Plane) ((ContO) conto).p[i_111_]).hsb[1],
				((Plane) ((ContO) conto).p[i_111_]).hsb[2]));
			((Plane) ((ContO) conto).p[i_111_]).c[0]
			    = color.getRed();
			((Plane) ((ContO) conto).p[i_111_]).c[1]
			    = color.getGreen();
			((Plane) ((ContO) conto).p[i_111_]).c[2]
			    = color.getBlue();
		    }
		    if (((Plane) ((ContO) conto).p[i_111_]).glass == 1)
			((Plane) ((ContO) conto).p[i_111_]).gr
			    += Math.abs((double) f_112_ * 1.5);
		}
	    }
	}
	return i_110_;
    }
    
    public int regz(int i, float f, ContO conto) {
	int i_114_ = 0;
	boolean bool = true;
	if (((xtGraphics) ((Mad) this).xt).multion == 1
	    && ((xtGraphics) ((Mad) this).xt).im != ((Mad) this).im)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).multion >= 2)
	    bool = false;
	if (((xtGraphics) ((Mad) this).xt).lan
	    && ((xtGraphics) ((Mad) this).xt).multion >= 1
	    && ((xtGraphics) ((Mad) this).xt).isbot[((Mad) this).im])
	    bool = true;
	f *= ((CarDefine) ((Mad) this).cd).dammult[((Mad) this).cn];
	if (Math.abs(f) > 100.0F) {
	    ((Mad) this).rpd.recz(i, f, ((Mad) this).im);
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    ((Mad) this).shakedam
		= (int) ((Math.abs(f) + (float) ((Mad) this).shakedam) / 2.0F);
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im
		|| ((Mad) this).colidim)
		((Mad) this).xt.crash(f, 0);
	    for (int i_115_ = 0; i_115_ < ((ContO) conto).npl; i_115_++) {
		float f_116_ = 0.0F;
		for (int i_117_ = 0;
		     i_117_ < ((Plane) ((ContO) conto).p[i_115_]).n;
		     i_117_++) {
		    if (((Plane) ((ContO) conto).p[i_115_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_115_]).ox[i_117_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_115_]).oz[i_117_])
			    < (((CarDefine) ((Mad) this).cd).clrad
			       [((Mad) this).cn]))) {
			f_116_ = f / 20.0F * ((Mad) this).m.random();
			((Plane) ((ContO) conto).p[i_115_]).oz[i_117_]
			    += (f_116_ * ((Mad) this).m.cos(((ContO) conto).xz)
				* ((Mad) this).m.cos(((ContO) conto).zy));
			((Plane) ((ContO) conto).p[i_115_]).ox[i_117_]
			    += (f_116_ * ((Mad) this).m.sin(((ContO) conto).xz)
				* ((Mad) this).m.cos(((ContO) conto).xy));
			if (bool) {
			    ((Mad) this).hitmag += Math.abs(f_116_);
			    i_114_ += Math.abs(f_116_);
			}
		    }
		}
		if (f_116_ != 0.0F) {
		    if (Math.abs(f_116_) >= 1.0F) {
			((Plane) ((ContO) conto).p[i_115_]).chip = 1;
			((Plane) ((ContO) conto).p[i_115_]).ctmag = f_116_;
		    }
		    if (!((Plane) ((ContO) conto).p[i_115_]).nocol
			&& ((Plane) ((ContO) conto).p[i_115_]).glass != 1) {
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 20
			    && (double) (((Plane) ((ContO) conto).p[i_115_])
					 .hsb[1]) > 0.25)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[1] = 0.25F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 25
			    && (double) (((Plane) ((ContO) conto).p[i_115_])
					 .hsb[2]) > 0.7)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[2] = 0.7F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 30
			    && (double) (((Plane) ((ContO) conto).p[i_115_])
					 .hsb[1]) > 0.15)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[1] = 0.15F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 35
			    && (double) (((Plane) ((ContO) conto).p[i_115_])
					 .hsb[2]) > 0.6)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[2] = 0.6F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 40)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[0]
				= 0.075F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 50
			    && (double) (((Plane) ((ContO) conto).p[i_115_])
					 .hsb[2]) > 0.5)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[2] = 0.5F;
			if (((Plane) ((ContO) conto).p[i_115_]).bfase > 60)
			    ((Plane) ((ContO) conto).p[i_115_]).hsb[0] = 0.05F;
			((Plane) ((ContO) conto).p[i_115_]).bfase
			    += Math.abs(f_116_);
			new Color(((Plane) ((ContO) conto).p[i_115_]).c[0],
				  ((Plane) ((ContO) conto).p[i_115_]).c[1],
				  ((Plane) ((ContO) conto).p[i_115_]).c[2]);
			Color color
			    = (Color.getHSBColor
			       (((Plane) ((ContO) conto).p[i_115_]).hsb[0],
				((Plane) ((ContO) conto).p[i_115_]).hsb[1],
				((Plane) ((ContO) conto).p[i_115_]).hsb[2]));
			((Plane) ((ContO) conto).p[i_115_]).c[0]
			    = color.getRed();
			((Plane) ((ContO) conto).p[i_115_]).c[1]
			    = color.getGreen();
			((Plane) ((ContO) conto).p[i_115_]).c[2]
			    = color.getBlue();
		    }
		    if (((Plane) ((ContO) conto).p[i_115_]).glass == 1)
			((Plane) ((ContO) conto).p[i_115_]).gr
			    += Math.abs((double) f_116_ * 1.5);
		}
	    }
	}
	return i_114_;
    }
    
    public void colide(ContO conto, Mad mad_118_, ContO conto_119_) {
	float[] fs = new float[4];
	float[] fs_120_ = new float[4];
	float[] fs_121_ = new float[4];
	float[] fs_122_ = new float[4];
	float[] fs_123_ = new float[4];
	float[] fs_124_ = new float[4];
	for (int i = 0; i < 4; i++) {
	    fs[i] = (float) (((ContO) conto).x + ((ContO) conto).keyx[i]);
	    if (((Mad) this).capsized)
		fs_120_[i] = (float) (((ContO) conto).y
				      + (((CarDefine) ((Mad) this).cd).flipy
					 [((Mad) this).cn])
				      + ((Mad) this).squash);
	    else
		fs_120_[i]
		    = (float) (((ContO) conto).y + ((ContO) conto).grat);
	    fs_121_[i] = (float) (((ContO) conto).z + ((ContO) conto).keyz[i]);
	    fs_122_[i] = (float) (((ContO) conto_119_).x
				  + ((ContO) conto_119_).keyx[i]);
	    if (((Mad) this).capsized)
		fs_123_[i] = (float) (((ContO) conto_119_).y
				      + (((CarDefine) ((Mad) this).cd).flipy
					 [((Mad) mad_118_).cn])
				      + ((Mad) mad_118_).squash);
	    else
		fs_123_[i] = (float) (((ContO) conto_119_).y
				      + ((ContO) conto_119_).grat);
	    fs_124_[i] = (float) (((ContO) conto_119_).z
				  + ((ContO) conto_119_).keyz[i]);
	}
	rot(fs, fs_120_, ((ContO) conto).x, ((ContO) conto).y,
	    ((ContO) conto).xy, 4);
	rot(fs_120_, fs_121_, ((ContO) conto).y, ((ContO) conto).z,
	    ((ContO) conto).zy, 4);
	rot(fs, fs_121_, ((ContO) conto).x, ((ContO) conto).z,
	    ((ContO) conto).xz, 4);
	rot(fs_122_, fs_123_, ((ContO) conto_119_).x, ((ContO) conto_119_).y,
	    ((ContO) conto_119_).xy, 4);
	rot(fs_123_, fs_124_, ((ContO) conto_119_).y, ((ContO) conto_119_).z,
	    ((ContO) conto_119_).zy, 4);
	rot(fs_122_, fs_124_, ((ContO) conto_119_).x, ((ContO) conto_119_).z,
	    ((ContO) conto_119_).xz, 4);
	if ((double) rpy((float) ((ContO) conto).x,
			 (float) ((ContO) conto_119_).x,
			 (float) ((ContO) conto).y,
			 (float) ((ContO) conto_119_).y,
			 (float) ((ContO) conto).z,
			 (float) ((ContO) conto_119_).z)
	    < (double) (((ContO) conto).maxR * ((ContO) conto).maxR
			+ (((ContO) conto_119_).maxR
			   * ((ContO) conto_119_).maxR)) * 1.5) {
	    if (!((Mad) this).caught[((Mad) mad_118_).im]
		&& (((Mad) this).speed != 0.0F
		    || ((Mad) mad_118_).speed != 0.0F)) {
		if (Math.abs(((Mad) this).power * ((Mad) this).speed
			     * (((CarDefine) ((Mad) this).cd).moment
				[((Mad) this).cn]))
		    != Math.abs(((Mad) mad_118_).power * ((Mad) mad_118_).speed
				* (((CarDefine) ((Mad) this).cd).moment
				   [((Mad) mad_118_).cn]))) {
		    if (Math.abs(((Mad) this).power * ((Mad) this).speed
				 * (((CarDefine) ((Mad) this).cd).moment
				    [((Mad) this).cn]))
			> Math.abs(((Mad) mad_118_).power
				   * ((Mad) mad_118_).speed
				   * (((CarDefine) ((Mad) this).cd).moment
				      [((Mad) mad_118_).cn])))
			((Mad) this).dominate[((Mad) mad_118_).im] = true;
		    else
			((Mad) this).dominate[((Mad) mad_118_).im] = false;
		} else if ((((CarDefine) ((Mad) this).cd).moment
			    [((Mad) this).cn])
			   > (((CarDefine) ((Mad) this).cd).moment
			      [((Mad) mad_118_).cn]))
		    ((Mad) this).dominate[((Mad) mad_118_).im] = true;
		else
		    ((Mad) this).dominate[((Mad) mad_118_).im] = false;
		((Mad) this).caught[((Mad) mad_118_).im] = true;
	    }
	} else if (((Mad) this).caught[((Mad) mad_118_).im])
	    ((Mad) this).caught[((Mad) mad_118_).im] = false;
	int i = 0;
	int i_125_ = 0;
	if (((Mad) this).dominate[((Mad) mad_118_).im]) {
	    int i_126_
		= (int) ((((((Mad) this).scz[0] - ((Mad) mad_118_).scz[0]
			    + ((Mad) this).scz[1] - ((Mad) mad_118_).scz[1]
			    + ((Mad) this).scz[2] - ((Mad) mad_118_).scz[2]
			    + ((Mad) this).scz[3] - ((Mad) mad_118_).scz[3])
			   * (((Mad) this).scz[0] - ((Mad) mad_118_).scz[0]
			      + ((Mad) this).scz[1] - ((Mad) mad_118_).scz[1]
			      + ((Mad) this).scz[2] - ((Mad) mad_118_).scz[2]
			      + ((Mad) this).scz[3] - ((Mad) mad_118_).scz[3]))
			  + ((((Mad) this).scx[0] - ((Mad) mad_118_).scx[0]
			      + ((Mad) this).scx[1] - ((Mad) mad_118_).scx[1]
			      + ((Mad) this).scx[2] - ((Mad) mad_118_).scx[2]
			      + ((Mad) this).scx[3] - ((Mad) mad_118_).scx[3])
			     * (((Mad) this).scx[0] - ((Mad) mad_118_).scx[0]
				+ ((Mad) this).scx[1] - ((Mad) mad_118_).scx[1]
				+ ((Mad) this).scx[2] - ((Mad) mad_118_).scx[2]
				+ ((Mad) this).scx[3]
				- ((Mad) mad_118_).scx[3])))
			 / 16.0F);
	    int i_127_ = 7000;
	    float f = 1.0F;
	    if (((xtGraphics) ((Mad) this).xt).multion != 0) {
		i_127_ = 28000;
		f = 1.27F;
	    }
	    for (int i_128_ = 0; i_128_ < 4; i_128_++) {
		for (int i_129_ = 0; i_129_ < 4; i_129_++) {
		    if ((float) rpy(fs[i_128_], fs_122_[i_129_],
				    fs_120_[i_128_], fs_123_[i_129_],
				    fs_121_[i_128_], fs_124_[i_129_])
			< ((float) (i_126_ + i_127_)
			   * ((((CarDefine) ((Mad) this).cd).comprad
			       [((Mad) mad_118_).cn])
			      + (((CarDefine) ((Mad) this).cd).comprad
				 [((Mad) this).cn])))) {
			if (Math.abs(((Mad) this).scx[i_128_]
				     * (((CarDefine) ((Mad) this).cd).moment
					[((Mad) this).cn]))
			    > Math.abs(((Mad) mad_118_).scx[i_129_]
				       * (((CarDefine) ((Mad) this).cd).moment
					  [((Mad) mad_118_).cn]))) {
			    float f_130_
				= (((Mad) mad_118_).scx[i_129_]
				   * (float) (((CarDefine) ((Mad) this).cd)
					      .revpush[((Mad) this).cn]));
			    if (f_130_ > 300.0F)
				f_130_ = 300.0F;
			    if (f_130_ < -300.0F)
				f_130_ = -300.0F;
			    float f_131_
				= (((Mad) this).scx[i_128_]
				   * (float) (((CarDefine) ((Mad) this).cd)
					      .push[((Mad) this).cn]));
			    if (f_131_ > 300.0F)
				f_131_ = 300.0F;
			    if (f_131_ < -300.0F)
				f_131_ = -300.0F;
			    ((Mad) mad_118_).scx[i_129_] += f_131_;
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) mad_118_).colidim = true;
			    i += mad_118_.regx(i_129_,
					       (f_131_
						* (((CarDefine)
						    ((Mad) this).cd)
						   .moment[((Mad) this).cn])
						* f),
					       conto_119_);
			    if (((Mad) mad_118_).colidim)
				((Mad) mad_118_).colidim = false;
			    ((Mad) this).scx[i_128_] -= f_130_;
			    i_125_ += regx(i_128_,
					   (-f_130_
					    * (((CarDefine) ((Mad) this).cd)
					       .moment[((Mad) this).cn])
					    * f),
					   conto);
			    ((Mad) this).scy[i_128_]
				-= (float) (((CarDefine) ((Mad) this).cd)
					    .revlift[((Mad) this).cn]);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) mad_118_).colidim = true;
			    i += mad_118_.regy(i_129_,
					       (float) ((((CarDefine)
							  ((Mad) this).cd)
							 .revlift
							 [((Mad) this).cn])
							* 7),
					       conto_119_);
			    if (((Mad) mad_118_).colidim)
				((Mad) mad_118_).colidim = false;
			    if (((Mad) this).m.random()
				> ((Mad) this).m.random())
				conto_119_.sprk(((fs[i_128_] + fs_122_[i_129_])
						 / 2.0F),
						(fs_120_[i_128_]
						 + fs_123_[i_129_]) / 2.0F,
						(fs_121_[i_128_]
						 + fs_124_[i_129_]) / 2.0F,
						((((Mad) mad_118_).scx[i_129_]
						  + ((Mad) this).scx[i_128_])
						 / 4.0F),
						((((Mad) mad_118_).scy[i_129_]
						  + ((Mad) this).scy[i_128_])
						 / 4.0F),
						((((Mad) mad_118_).scz[i_129_]
						  + ((Mad) this).scz[i_128_])
						 / 4.0F),
						2);
			}
			if (Math.abs(((Mad) this).scz[i_128_]
				     * (((CarDefine) ((Mad) this).cd).moment
					[((Mad) this).cn]))
			    > Math.abs(((Mad) mad_118_).scz[i_129_]
				       * (((CarDefine) ((Mad) this).cd).moment
					  [((Mad) mad_118_).cn]))) {
			    float f_132_
				= (((Mad) mad_118_).scz[i_129_]
				   * (float) (((CarDefine) ((Mad) this).cd)
					      .revpush[((Mad) this).cn]));
			    if (f_132_ > 300.0F)
				f_132_ = 300.0F;
			    if (f_132_ < -300.0F)
				f_132_ = -300.0F;
			    float f_133_
				= (((Mad) this).scz[i_128_]
				   * (float) (((CarDefine) ((Mad) this).cd)
					      .push[((Mad) this).cn]));
			    if (f_133_ > 300.0F)
				f_133_ = 300.0F;
			    if (f_133_ < -300.0F)
				f_133_ = -300.0F;
			    ((Mad) mad_118_).scz[i_129_] += f_133_;
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) mad_118_).colidim = true;
			    i += mad_118_.regz(i_129_,
					       (f_133_
						* (((CarDefine)
						    ((Mad) this).cd)
						   .moment[((Mad) this).cn])
						* f),
					       conto_119_);
			    if (((Mad) mad_118_).colidim)
				((Mad) mad_118_).colidim = false;
			    ((Mad) this).scz[i_128_] -= f_132_;
			    i_125_ += regz(i_128_,
					   (-f_132_
					    * (((CarDefine) ((Mad) this).cd)
					       .moment[((Mad) this).cn])
					    * f),
					   conto);
			    ((Mad) this).scy[i_128_]
				-= (float) (((CarDefine) ((Mad) this).cd)
					    .revlift[((Mad) this).cn]);
			    if (((Mad) this).im
				== ((xtGraphics) ((Mad) this).xt).im)
				((Mad) mad_118_).colidim = true;
			    i += mad_118_.regy(i_129_,
					       (float) ((((CarDefine)
							  ((Mad) this).cd)
							 .revlift
							 [((Mad) this).cn])
							* 7),
					       conto_119_);
			    if (((Mad) mad_118_).colidim)
				((Mad) mad_118_).colidim = false;
			    if (((Mad) this).m.random()
				> ((Mad) this).m.random())
				conto_119_.sprk(((fs[i_128_] + fs_122_[i_129_])
						 / 2.0F),
						(fs_120_[i_128_]
						 + fs_123_[i_129_]) / 2.0F,
						(fs_121_[i_128_]
						 + fs_124_[i_129_]) / 2.0F,
						((((Mad) mad_118_).scx[i_129_]
						  + ((Mad) this).scx[i_128_])
						 / 4.0F),
						((((Mad) mad_118_).scy[i_129_]
						  + ((Mad) this).scy[i_128_])
						 / 4.0F),
						((((Mad) mad_118_).scz[i_129_]
						  + ((Mad) this).scz[i_128_])
						 / 4.0F),
						2);
			}
			if (((Mad) this).im
			    == ((xtGraphics) ((Mad) this).xt).im)
			    ((Mad) mad_118_).lastcolido = 70;
			if (((Mad) mad_118_).im
			    == ((xtGraphics) ((Mad) this).xt).im)
			    ((Mad) this).lastcolido = 70;
			((Mad) mad_118_).scy[i_129_]
			    -= (float) (((CarDefine) ((Mad) this).cd).lift
					[((Mad) this).cn]);
		    }
		}
	    }
	}
	if (((xtGraphics) ((Mad) this).xt).multion == 1) {
	    if (((Mad) mad_118_).im == ((xtGraphics) ((Mad) this).xt).im
		&& i != 0)
		((xtGraphics) ((Mad) this).xt).dcrashes[((Mad) this).im] += i;
	    if (((Mad) this).im == ((xtGraphics) ((Mad) this).xt).im
		&& i_125_ != 0)
		((xtGraphics) ((Mad) this).xt).dcrashes[((Mad) mad_118_).im]
		    += i_125_;
	}
    }
    
    public void rot(float[] fs, float[] fs_134_, int i, int i_135_, int i_136_,
		    int i_137_) {
	if (i_136_ != 0) {
	    for (int i_138_ = 0; i_138_ < i_137_; i_138_++) {
		float f = fs[i_138_];
		float f_139_ = fs_134_[i_138_];
		fs[i_138_]
		    = (float) i + ((f - (float) i) * ((Mad) this).m.cos(i_136_)
				   - ((f_139_ - (float) i_135_)
				      * ((Mad) this).m.sin(i_136_)));
		fs_134_[i_138_]
		    = ((float) i_135_
		       + ((f - (float) i) * ((Mad) this).m.sin(i_136_)
			  + ((f_139_ - (float) i_135_)
			     * ((Mad) this).m.cos(i_136_))));
	    }
	}
    }
    
    public int rpy(float f, float f_140_, float f_141_, float f_142_,
		   float f_143_, float f_144_) {
	return (int) ((f - f_140_) * (f - f_140_)
		      + (f_141_ - f_142_) * (f_141_ - f_142_)
		      + (f_143_ - f_144_) * (f_143_ - f_144_));
    }
    
    public int py(int i, int i_145_, int i_146_, int i_147_) {
	return ((i - i_145_) * (i - i_145_)
		+ (i_146_ - i_147_) * (i_146_ - i_147_));
    }
}
