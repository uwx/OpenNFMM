/* Globe - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.Calendar;

public class Globe implements Runnable
{
    MediaTracker mt;
    Graphics2D rd;
    xtGraphics xt;
    FontMetrics ftm;
    ImageObserver ob;
    GameSparker gs;
    Login lg;
    CarDefine cd;
    Medium m;
    Graphics2D rdo;
    Image gImage;
    Thread connector;
    boolean domon = false;
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    int fase = 0;
    int open = 0;
    boolean upo = false;
    int tab = 3;
    boolean onp = false;
    int ptab = 0;
    int spos = 0;
    int lspos = 0;
    int mscro = 825;
    int spos2 = 0;
    int lspos2 = 0;
    int mscro2 = 825;
    int spos3 = 0;
    int lspos3 = 0;
    int mscro3 = 825;
    int spos4 = 208;
    int lspos4 = 0;
    int mscro4 = 825;
    int spos5 = 0;
    int lspos5 = 0;
    int mscro5 = 825;
    int overit = 0;
    int flk = 0;
    int flko = 0;
    boolean flg = false;
    int curs = 0;
    int waitlink = 0;
    int addstage = 0;
    boolean darker = false;
    int npo = -1;
    String[] pname = new String[900];
    int[] proom = new int[900];
    int[] pserver = new int[900];
    int[][] roomf = new int[3][5];
    int npf = -1;
    String[] fname = new String[900];
    String[] cnfname = new String[10];
    int ncnf = 0;
    int freq = 0;
    int sfreq = 0;
    String freqname = "";
    String sfreqname = "";
    int cntf = 0;
    String[] cnames = new String[21];
    String[] sentn = new String[21];
    String[] ctime = new String[21];
    long[] nctime = new long[21];
    int updatec = -1;
    String proname = "";
    boolean loadedp = false;
    int edit = 0;
    int upload = 0;
    int perc = 0;
    int playt = 0;
    int uploadt = 0;
    String filename = "";
    String msg = "";
    String trackname = "";
    boolean refresh = false;
    boolean logol = false;
    boolean avatarl = false;
    int sentchange = 0;
    boolean badlang = false;
    String[] aboutxt = new String[3];
    int nab = 0;
    Image clanlogo;
    Image avatar;
    int racing = 50;
    int wasting = 150;
    String themesong = "";
    String sentance = "";
    int trackvol = 0;
    int comesoon = 0;
    String proclan = "";
    int protab = 0;
    int loadpst = 0;
    String loadpstage = "";
    boolean loadedpstage = false;
    int nlg = 0;
    String[] logos = new String[200];
    boolean[] logon = new boolean[200];
    Image[] logoi = new Image[200];
    int loadmsgs = -1;
    String hasmsgs = "";
    String lastsub = "";
    int nm = 0;
    String[] mname = new String[200];
    String[] mconvo = new String[200];
    String[] msub = new String[200];
    int[] mtyp = new int[200];
    String[] mtime = new String[200];
    long[] mctime = new long[200];
    int openc = 0;
    int opy = 0;
    int addopy = 0;
    int oph = 0;
    int itemsel = 0;
    int loaditem = 0;
    String[] mline = new String[1000];
    int[] mlinetyp = new int[1000];
    long[] mctimes = new long[1000];
    String[] mtimes = new String[1000];
    int nml = 0;
    int readmsg = 0;
    String opname = "";
    String blockname = "";
    String unblockname = "";
    int sendmsg = 0;
    String[] wday = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday",
		      "Friday", "Saturday" };
    String[] month
	= { "January", "February", "March", "April", "May", "June", "July",
	    "August", "September", "October", "November", "December" };
    int itab = 0;
    int litab = -1;
    int cadmin = 0;
    String[] cmline = new String[1000];
    int[] cmlinetyp = new int[1000];
    long[] cmctimes = new long[1000];
    String[] cmtimes = new String[1000];
    int cnml = 0;
    int readclan = 0;
    int sendcmsg = 0;
    int loadinter = -1;
    int ni = 0;
    String[] iclan = new String[200];
    String[] iconvo = new String[200];
    String[] isub = new String[200];
    String[] icheck = new String[200];
    String[] itime = new String[200];
    long[] ictime = new long[200];
    String[] istat = new String[200];
    String[] itcar = new String[200];
    String[] igcar = new String[200];
    String[] iwarn = new String[200];
    int openi = 0;
    int readint = 0;
    String intclan = "";
    String lastint = "";
    int dispi = 0;
    String dwarn = "";
    String dtcar = "";
    String dgcar = "";
    int nil = 0;
    String[] iline = new String[1000];
    int[] ilinetyp = new int[1000];
    long[] ictimes = new long[1000];
    String[] itimes = new String[1000];
    int intsel = 0;
    int isel = 0;
    int ifas = 0;
    int leader = -1;
    int sendint = 0;
    boolean inishsel = false;
    boolean redif = false;
    String imsg = "";
    int wag = 0;
    int iflk = 0;
    String itake = "";
    String igive = "";
    String viewcar = "";
    String warnum = "";
    boolean sendwarnum = false;
    String[] wstages = new String[5];
    int[] wlaps = new int[5];
    int[] wcars = new int[5];
    int[] wclass = new int[5];
    int[] wfix = new int[5];
    int nvgames1 = 0;
    int nvgames2 = 0;
    int viewgame1 = 0;
    int viewgame2 = 0;
    String viewwar1 = "";
    String viewwar2 = "";
    String xclan = "";
    String sendwar = "";
    boolean ichlng = false;
    String[] vwstages1 = new String[10];
    int[] vwlaps1 = new int[10];
    int[] vwcars1 = new int[10];
    int[] vwclass1 = new int[10];
    int[] vwfix1 = new int[10];
    String[] vwstages2 = new String[10];
    int[] vwlaps2 = new int[10];
    int[] vwcars2 = new int[10];
    int[] vwclass2 = new int[10];
    int[] vwfix2 = new int[10];
    String[] vwinner = new String[10];
    int vwscorex = 0;
    int vwscorei = 0;
    Image intclanbg = null;
    String intclanlo = "";
    boolean intclanbgloaded = false;
    Image myclanbg = null;
    int loadedmyclanbg = 0;
    int cfase = 0;
    boolean notclan = false;
    String claname = "EvilOnes";
    boolean loadedc = false;
    boolean clanbgl = false;
    Image clanbg;
    int editc = 0;
    int em = 0;
    int ctab = 0;
    int nmb = 0;
    String lccnam = "";
    String[] member = new String[20];
    int[] mlevel = new int[20];
    String[] mrank = new String[20];
    int nrmb = 0;
    String[] rmember = new String[100];
    boolean showreqs = false;
    int blocknote = 0;
    int blockb = 0;
    boolean loadedcm = false;
    int ncln = 0;
    String[] clname = new String[20];
    String smsg = "";
    String sltit = "";
    boolean attachetoclan = false;
    boolean loadedlink = false;
    int loadedcars = -1;
    int loadedcar = 0;
    String ltit = "";
    String ldes = "";
    String lurl = "";
    boolean forcsel = false;
    String selcar = "";
    String selstage = "";
    String perry = "";
    int mrot = 0;
    int loadedstages = -1;
    int loadedstage = 0;
    CheckPoints cp;
    ContO[] bco;
    ContO[] co;
    int mouson = -1;
    int nclns = 0;
    String[] clanlo = new String[20];
    int ntab = 0;
    int loadednews = 0;
    int spos6 = 0;
    int lspos6 = 0;
    String[] newplayers = { "", "", "", "", "" };
    int[] nwarbs = { -1, -1, -1, -1, -1 };
    String[] nwclan = new String[5];
    String[] nlclan = new String[5];
    String[] nwinob = new String[5];
    int[] nwinp = new int[5];
    int[] nlosp = new int[5];
    String[] nwtime = new String[5];
    int il = 0;
    String[] nttime = new String[300];
    String[] text = new String[300];
    int[] nln = new int[300];
    String[][][] link = new String[300][4][2];
    int maxclans = 1000;
    int loadwstat = 0;
    int ncc = 0;
    int champ = -1;
    int leadsby = 0;
    String[] conclan;
    int[] totp;
    int[] ord;
    int[] nvc;
    int[][] points;
    String[][] verclan;
    int eng = -1;
    int engo = 0;
    boolean frkl = false;
    int underc = 0;
    float bgf = 0.0F;
    boolean bgup = false;
    int[] bgx = { 0, 670, 1340 };
    int flkn = 0;
    int cur = 0;
    int sdist = 0;
    int scro = 0;
    boolean donewc = false;
    boolean dosrch = false;
    boolean dorank = false;
    boolean doweb1 = false;
    boolean doweb2 = false;
    boolean dommsg = false;
    boolean donemsg = false;
    int doi = 0;
    int ados = 0;
    int lspos6w = 0;
    long ntime = 0L;
    int loadwbgames = 0;
    int warb = 0;
    int gameturn = -1;
    String warbnum = "";
    String vclan = "";
    String[] wbstages = new String[10];
    int[] wbstage = new int[10];
    int[] wblaps = new int[10];
    int[] wbcars = new int[10];
    int[] wbclass = new int[10];
    int[] wbfix = new int[10];
    String gameturndisp = "";
    int ascore = 0;
    int vscore = 0;
    String lwbwinner = "";
    boolean canredo = false;
    
    public Globe(Graphics2D graphics2d, xtGraphics var_xtGraphics,
		 Medium medium, Login login, CarDefine cardefine,
		 CheckPoints checkpoints, ContO[] contos, ContO[] contos_0_,
		 GameSparker gamesparker) {
	((Globe) this).rd = graphics2d;
	((Globe) this).xt = var_xtGraphics;
	((Globe) this).m = medium;
	((Globe) this).gs = gamesparker;
	((Globe) this).lg = login;
	((Globe) this).cd = cardefine;
	((Globe) this).cp = checkpoints;
	((Globe) this).bco = contos;
	((Globe) this).co = contos_0_;
	((Globe) this).gImage = ((Globe) this).gs.createImage(560, 300);
	((Globe) this).rdo = (Graphics2D) ((Globe) this).gImage.getGraphics();
	((Globe) this).rdo.setRenderingHint((RenderingHints
					     .KEY_TEXT_ANTIALIASING),
					    (RenderingHints
					     .VALUE_TEXT_ANTIALIAS_ON));
	((Globe) this).rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					    RenderingHints.VALUE_ANTIALIAS_ON);
	for (int i = 0; i < 21; i++) {
	    ((Globe) this).ctime[i] = "";
	    ((Globe) this).cnames[i] = "";
	    ((Globe) this).sentn[i] = "";
	    ((Globe) this).nctime[i] = 0L;
	}
	for (int i = 0; i < 900; i++)
	    ((Globe) this).pname[i] = "";
	for (int i = 0; i < 200; i++) {
	    ((Globe) this).logos[i] = "";
	    ((Globe) this).logon[i] = false;
	}
	((Globe) this).mt = new MediaTracker(((Globe) this).gs);
	((GameSparker) ((Globe) this).gs).sendtyp
	    .setBackground(colorb2k(false, 210, 210, 210));
	((GameSparker) ((Globe) this).gs).sendtyp.setForeground(new Color(0, 0,
									  0));
	((GameSparker) ((Globe) this).gs).sendtyp.removeAll();
	((GameSparker) ((Globe) this).gs).sendtyp.add(((Globe) this).rd,
						      "Write a Message");
	((GameSparker) ((Globe) this).gs).sendtyp.add(((Globe) this).rd,
						      "Share a Custom Car");
	((GameSparker) ((Globe) this).gs).sendtyp.add(((Globe) this).rd,
						      "Share a Custom Stage");
	((GameSparker) ((Globe) this).gs).sendtyp
	    .add(((Globe) this).rd, "Send a Clan Invitation");
	((GameSparker) ((Globe) this).gs).sendtyp.add(((Globe) this).rd,
						      "Share a Relative Date");
	((GameSparker) ((Globe) this).gs).senditem
	    .setBackground(colorb2k(false, 230, 230, 230));
	((GameSparker) ((Globe) this).gs).senditem
	    .setForeground(new Color(0, 0, 0));
	((GameSparker) ((Globe) this).gs).proitem
	    .setBackground(new Color(206, 171, 98));
	((GameSparker) ((Globe) this).gs).proitem.setForeground(new Color(0, 0,
									  0));
	((GameSparker) ((Globe) this).gs).datat
	    .setBackground(colorb2k(false, 230, 230, 230));
	((GameSparker) ((Globe) this).gs).datat.setForeground(new Color(0, 0,
									0));
	((GameSparker) ((Globe) this).gs).mmsg
	    .setBackground(colorb2k(false, 240, 240, 240));
	((GameSparker) ((Globe) this).gs).mmsg.setForeground(new Color(0, 0,
								       0));
	((GameSparker) ((Globe) this).gs).clanlev
	    .setBackground(colorb2k(false, 230, 230, 230));
	((GameSparker) ((Globe) this).gs).clanlev.setForeground(new Color(0, 0,
									  0));
	((GameSparker) ((Globe) this).gs).clcars.setBackground(new Color(0, 0,
									 0));
	((GameSparker) ((Globe) this).gs).clcars
	    .setForeground(new Color(255, 255, 255));
	((GameSparker) ((Globe) this).gs).ilaps
	    .setBackground(colorb2k(false, 220, 220, 220));
	((GameSparker) ((Globe) this).gs).ilaps.setForeground(new Color(0, 0,
									0));
	((GameSparker) ((Globe) this).gs).icars
	    .setBackground(colorb2k(false, 220, 220, 220));
	((GameSparker) ((Globe) this).gs).icars.setForeground(new Color(0, 0,
									0));
	if (!((xtGraphics) ((Globe) this).xt).clan.equals(""))
	    ((Globe) this).itab = 2;
    }
    
    public void dome(int i, int i_1_, int i_2_, boolean bool,
		     Control control) {
	boolean bool_3_ = false;
	boolean bool_4_ = false;
	((Globe) this).dommsg = false;
	((Globe) this).dorank = false;
	((Globe) this).donewc = false;
	((Globe) this).dosrch = false;
	((Globe) this).doweb1 = false;
	((Globe) this).doweb2 = false;
	if (((Globe) this).open == 0) {
	    boolean bool_5_ = false;
	    if (((Login) ((Globe) this).lg).nmsgs == 0
		&& ((Login) ((Globe) this).lg).nfreq == 0
		&& ((Login) ((Globe) this).lg).nconf == 0
		&& ((Login) ((Globe) this).lg).ncreq == 0
		&& ((Login) ((Globe) this).lg).clanapv.equals("")) {
		if (i_2_ > 425 && i_2_ < 450 && i_1_ < 568 && i_1_ > 232)
		    bool_5_ = true;
		int[] is = { 0, 9, 232, 250, 550, 568, 791, 800 };
		int[] is_6_ = { 452, 443, 443, 425, 425, 443, 443, 452 };
		if (bool_5_)
		    ((Globe) this).rd.setColor(color2k(255, 255, 255));
		else
		    ((Globe) this).rd.setColor(new Color(207, 177, 110));
		((Globe) this).rd.fillPolygon(is, is_6_, 8);
		((Globe) this).rd.setColor(new Color(103, 88, 55));
		((Globe) this).rd.drawPolygon(is, is_6_, 8);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .dome),
					    311, 430, null);
	    } else {
		String string = "You have ";
		if (!((Login) ((Globe) this).lg).clanapv.equals("")) {
		    string = new StringBuilder().append(string).append
				 ("been approved for a clan membership")
				 .toString();
		    if (((Login) ((Globe) this).lg).nmsgs != 0
			|| ((Login) ((Globe) this).lg).nfreq != 0
			|| ((Login) ((Globe) this).lg).nconf != 0)
			string = new StringBuilder().append(string).append
				     ("! + You have ").toString();
		}
		if (((Login) ((Globe) this).lg).ncreq != 0) {
		    string
			= new StringBuilder().append(string).append("").append
			      (((Login) ((Globe) this).lg).ncreq).append
			      (" clan membership requests").toString();
		    if (((Login) ((Globe) this).lg).nmsgs != 0
			|| ((Login) ((Globe) this).lg).nfreq != 0
			|| ((Login) ((Globe) this).lg).nconf != 0)
			string = new StringBuilder().append(string).append
				     ("! + You have ").toString();
		}
		if (((Login) ((Globe) this).lg).nmsgs != 0) {
		    string = new StringBuilder().append(string).append
				 ("new interactions").toString();
		    if (((Login) ((Globe) this).lg).fclan > 0
			&& ((Login) ((Globe) this).lg).fplayer > 0) {
			String string_7_ = "";
			String string_8_ = "";
			if (((Login) ((Globe) this).lg).fplayer > 1)
			    string_7_ = "s";
			if (((Login) ((Globe) this).lg).fclan > 1)
			    string_8_ = "s";
			string
			    = new StringBuilder().append(string).append
				  (" from ").append
				  (((Login) ((Globe) this).lg).fplayer).append
				  (" player").append
				  (string_7_).append
				  (" & ").append
				  (((Login) ((Globe) this).lg).fclan).append
				  (" clan").append
				  (string_8_).append
				  ("").toString();
		    } else {
			if (((Login) ((Globe) this).lg).fclan == 1)
			    string = new StringBuilder().append(string).append
					 (" from 1 clan").toString();
			if (((Login) ((Globe) this).lg).fclan > 1)
			    string = new StringBuilder().append(string).append
					 (" from ").append
					 (((Login) ((Globe) this).lg).fclan)
					 .append
					 (" clans").toString();
			if (((Login) ((Globe) this).lg).fplayer == 1)
			    string = new StringBuilder().append(string).append
					 (" from 1 player").toString();
			if (((Login) ((Globe) this).lg).fplayer > 1)
			    string = new StringBuilder().append(string).append
					 (" from ").append
					 (((Login) ((Globe) this).lg).fplayer)
					 .append
					 (" players").toString();
			if (((Login) ((Globe) this).lg).fclan == 0
			    && ((Login) ((Globe) this).lg).fplayer == 0)
			    string = new StringBuilder().append(string).append
					 (" from your clan's discussion")
					 .toString();
		    }
		    if (((Login) ((Globe) this).lg).nfreq != 0
			&& ((Login) ((Globe) this).lg).nconf != 0)
			string = new StringBuilder().append(string).append
				     (", ").toString();
		    else {
			if (((Login) ((Globe) this).lg).nfreq != 0)
			    string = new StringBuilder().append(string).append
					 (" and ").toString();
			if (((Login) ((Globe) this).lg).nconf != 0)
			    string = new StringBuilder().append(string).append
					 (" and ").toString();
		    }
		}
		if (((Login) ((Globe) this).lg).nfreq != 0) {
		    string
			= new StringBuilder().append(string).append("").append
			      (((Login) ((Globe) this).lg).nfreq).append
			      (" friend request").toString();
		    if (((Login) ((Globe) this).lg).nfreq > 1)
			string = new StringBuilder().append(string).append
				     ("s").toString();
		    if (((Login) ((Globe) this).lg).nconf != 0)
			string = new StringBuilder().append(string).append
				     (" and ").toString();
		}
		if (((Login) ((Globe) this).lg).nconf != 0) {
		    string
			= new StringBuilder().append(string).append("").append
			      (((Login) ((Globe) this).lg).nconf).append
			      (" friend confirmation").toString();
		    if (((Login) ((Globe) this).lg).nconf > 1)
			string = new StringBuilder().append(string).append
				     ("s").toString();
		}
		string = new StringBuilder().append(string).append("!")
			     .toString();
		((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		int i_9_ = 0;
		if (((Globe) this).ftm.stringWidth(string) > 280)
		    i_9_ = (((Globe) this).ftm.stringWidth(string) - 280) / 2;
		if (i_2_ > 425 && i_2_ < 450 && i_1_ < 568 + i_9_
		    && i_1_ > 232 - i_9_)
		    bool_5_ = true;
		int[] is = { 0, 9, 232 - i_9_, 250 - i_9_, 550 + i_9_,
			     568 + i_9_, 791, 800 };
		int[] is_10_ = { 452, 443, 443, 425, 425, 443, 443, 452 };
		if (bool_5_)
		    ((Globe) this).rd.setColor(color2k(255, 255, 255));
		else
		    ((Globe) this).rd.setColor(new Color(207, 177, 110));
		((Globe) this).rd.fillPolygon(is, is_10_, 8);
		((Globe) this).rd.setColor(new Color(103, 88, 55));
		((Globe) this).rd.drawPolygon(is, is_10_, 8);
		if (((Globe) this).flkn % 3 == 0)
		    ((Globe) this).rd.setColor(new Color(60, 30, 0));
		else
		    ((Globe) this).rd.setColor(new Color(0, 100, 0));
		((Globe) this).rd.drawString(string,
					     400 - (((Globe) this).ftm
							.stringWidth(string)
						    / 2),
					     442);
		if (((Globe) this).flkn < 33)
		    ((Globe) this).flkn++;
	    }
	    if (bool_5_ && bool && i < 2) {
		((Globe) this).open = 2;
		((Globe) this).upo = true;
		if (((Login) ((Globe) this).lg).nmsgs != 0) {
		    ((Globe) this).tab = 2;
		    if (((Login) ((Globe) this).lg).fplayer > 0)
			((Globe) this).itab = 0;
		    else if (((Login) ((Globe) this).lg).fclan > 0)
			((Globe) this).itab = 1;
		    else
			((Globe) this).itab = 2;
		    ((Globe) this).litab = -1;
		}
		if (!((Login) ((Globe) this).lg).clanapv.equals("")) {
		    ((Globe) this).claname
			= ((Login) ((Globe) this).lg).clanapv;
		    ((Globe) this).loadedc = false;
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).tab = 3;
		    ((Globe) this).ctab = 0;
		}
		if (((Login) ((Globe) this).lg).ncreq != 0) {
		    ((Globe) this).claname
			= ((xtGraphics) ((Globe) this).xt).clan;
		    ((Globe) this).loadedc = false;
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).tab = 3;
		    ((Globe) this).ctab = 0;
		}
		if (((Login) ((Globe) this).lg).nfreq != 0
		    || ((Login) ((Globe) this).lg).nconf != 0)
		    ((Globe) this).ptab = 1;
	    }
	    if (((xtGraphics) ((Globe) this).xt).onviewpro) {
		((Globe) this).proname
		    = ((CarDefine) ((Globe) this).cd).viewname;
		((Globe) this).open = 2;
		((Globe) this).upo = true;
		((Globe) this).tab = 1;
		((xtGraphics) ((Globe) this).xt).onviewpro = false;
	    }
	} else if (((Globe) this).flkn != 0)
	    ((Globe) this).flkn = 0;
	if (((Globe) this).open >= 2 && ((Globe) this).open < 452) {
	    int[] is = { 0, 0, 9, 232, 250, 550, 568, 791, 800, 800 };
	    int[] is_11_
		= { 902 - ((Globe) this).open, 452 - ((Globe) this).open,
		    443 - ((Globe) this).open, 443 - ((Globe) this).open,
		    425 - ((Globe) this).open, 425 - ((Globe) this).open,
		    443 - ((Globe) this).open, 443 - ((Globe) this).open,
		    452 - ((Globe) this).open, 902 - ((Globe) this).open };
	    float f = ((float) ((Globe) this).open - 2.0F) / 450.0F;
	    int i_12_ = (int) (255.0F * (1.0F - f) + 216.0F * f);
	    if (i_12_ > 255)
		i_12_ = 255;
	    if (i_12_ < 0)
		i_12_ = 0;
	    int i_13_ = (int) (243.0F * (1.0F - f) + 179.0F * f);
	    if (i_13_ > 255)
		i_13_ = 255;
	    if (i_13_ < 0)
		i_13_ = 0;
	    int i_14_ = (int) (179.0F * (1.0F - f) + 100.0F * f);
	    if (i_14_ > 255)
		i_14_ = 255;
	    if (i_14_ < 0)
		i_14_ = 0;
	    ((Globe) this).rd.setColor(new Color(i_12_, i_13_, i_14_));
	    ((Globe) this).rd.fillPolygon(is, is_11_, 10);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).dome,
					311, 430 - ((Globe) this).open, null);
	    if (((Globe) this).upo)
		((Globe) this).open += 45;
	    else
		((Globe) this).open -= 45;
	    ((Globe) this).gs.hidefields();
	    if (((Globe) this).open == 452) {
		((Globe) this).gs.setCursor(new Cursor(0));
		((Globe) this).npo = -1;
		((Globe) this).updatec = -1;
		((Globe) this).domon = true;
		((Globe) this).connector = new Thread(this);
		((Globe) this).connector.start();
	    }
	}
	if (((Globe) this).open == 452) {
	    if (((xtGraphics) ((Globe) this).xt).warning == 0
		|| ((xtGraphics) ((Globe) this).xt).warning == 210) {
		((Globe) this).cur = 0;
		int i_15_ = (int) (255.0F * ((Globe) this).bgf
				   + 191.0F * (1.0F - ((Globe) this).bgf));
		int i_16_ = (int) (176.0F * ((Globe) this).bgf
				   + 184.0F * (1.0F - ((Globe) this).bgf));
		int i_17_ = (int) (67.0F * ((Globe) this).bgf
				   + 124.0F * (1.0F - ((Globe) this).bgf));
		if (!((Globe) this).bgup) {
		    ((Globe) this).bgf += 0.02F;
		    if (((Globe) this).bgf > 0.9F) {
			((Globe) this).bgf = 0.9F;
			((Globe) this).bgup = true;
		    }
		} else {
		    ((Globe) this).bgf -= 0.02F;
		    if (((Globe) this).bgf < 0.2F) {
			((Globe) this).bgf = 0.2F;
			((Globe) this).bgup = false;
		    }
		}
		((Globe) this).rd.setColor(new Color(i_15_, i_16_, i_17_));
		((Globe) this).rd.fillRect(0, 0, 800, 450);
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[0], 0, null);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[1], 0, null);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[2], 0, null);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[0], 400, null);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[1], 400, null);
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bgmain),
					    ((Globe) this).bgx[2], 400, null);
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 0.1F));
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .bggo),
					    0, 0, null);
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 1.0F));
		for (int i_18_ = 0; i_18_ < 3; i_18_++) {
		    ((Globe) this).bgx[i_18_] -= 5;
		    if (((Globe) this).bgx[i_18_] <= -670)
			((Globe) this).bgx[i_18_] = 1340;
		}
		if (drawbutton(((xtGraphics) ((Globe) this).xt).exit, 755, 17,
			       i_1_, i_2_, bool)
		    || i >= 2) {
		    ((Globe) this).open = 450;
		    ((Globe) this).upo = false;
		    ((Globe) this).domon = false;
		    onexit();
		}
		((Globe) this).sdist = 0;
		((Globe) this).scro = 0;
		if (((Globe) this).domon) {
		    if (((Globe) this).tab == 0) {
			((Globe) this).rd.setColor(color2k(230, 230, 230));
			((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20,
							20);
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20,
							20);
			if (((Globe) this).updatec != -1) {
			    String[] strings = new String[42];
			    String[] strings_19_ = new String[42];
			    String[] strings_20_ = new String[42];
			    boolean[] bools = new boolean[42];
			    for (int i_21_ = 0; i_21_ < 42; i_21_++) {
				strings[i_21_] = "";
				strings_19_[i_21_] = "";
				strings_20_[i_21_] = "";
				bools[i_21_] = false;
			    }
			    int i_22_ = 0;
			    ((Globe) this).rd.setFont(new Font("Tahoma", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    for (int i_23_ = 0; i_23_ < 21; i_23_++) {
				strings[i_22_] = "";
				strings_19_[i_22_]
				    = ((Globe) this).cnames[i_23_];
				strings_20_[i_22_]
				    = ((Globe) this).ctime[i_23_];
				int i_24_ = 0;
				int i_25_ = 0;
				int i_26_ = 0;
				int i_27_ = 0;
				int i_28_ = 0;
				for (/**/;
				     (i_24_
				      < ((Globe) this).sentn[i_23_].length());
				     i_24_++) {
				    String string
					= new StringBuilder().append("").append
					      (((Globe) this).sentn[i_23_]
						   .charAt(i_24_))
					      .toString();
				    if (string.equals(" ")) {
					i_25_ = i_26_;
					i_27_ = i_24_;
					i_28_++;
				    } else
					i_28_ = 0;
				    if (i_28_ <= 1) {
					StringBuilder stringbuilder
					    = new StringBuilder();
					String[] strings_29_ = strings;
					int i_30_ = i_22_;
					strings_29_[i_30_]
					    = stringbuilder.append
						  (strings_29_[i_30_]).append
						  (string).toString();
					i_26_++;
					if (((Globe) this).ftm
						.stringWidth(strings[i_22_])
					    > 469) {
					    if (i_25_ != 0) {
						strings[i_22_]
						    = strings[i_22_]
							  .substring(0, i_25_);
						if (i_22_ == 41) {
						    for (int i_31_ = 0;
							 i_31_ < 41; i_31_++) {
							strings[i_31_]
							    = (strings
							       [i_31_ + 1]);
							strings_19_[i_31_]
							    = (strings_19_
							       [i_31_ + 1]);
							strings_20_[i_31_]
							    = (strings_20_
							       [i_31_ + 1]);
							bools[i_31_]
							    = bools[i_31_ + 1];
						    }
						    strings[i_22_] = "";
						    bools[i_22_] = true;
						} else {
						    i_22_++;
						    strings_19_[i_22_]
							= (((Globe) this)
							   .cnames[i_23_]);
						    strings_20_[i_22_]
							= (((Globe) this).ctime
							   [i_23_]);
						}
						i_24_ = i_27_;
						i_26_ = 0;
						i_25_ = 0;
					    } else {
						strings[i_22_] = "";
						i_26_ = 0;
					    }
					}
				    }
				}
				if (i_22_ == 41 && i_23_ != 20) {
				    for (int i_32_ = 0; i_32_ < 41; i_32_++) {
					strings[i_32_] = strings[i_32_ + 1];
					strings_19_[i_32_]
					    = strings_19_[i_32_ + 1];
					strings_20_[i_32_]
					    = strings_20_[i_32_ + 1];
					bools[i_32_] = bools[i_32_ + 1];
				    }
				} else
				    i_22_++;
			    }
			    String string = "";
			    int i_33_ = i_22_;
			    for (int i_34_ = 0; i_34_ < i_22_; i_34_++) {
				if (!string.equals(strings_19_[i_34_])) {
				    if (i_34_ != 0)
					i_33_++;
				    string = strings_19_[i_34_];
				}
			    }
			    ((Globe) this).sdist
				= (int) (((float) i_33_ - 21.5F) * 15.0F);
			    if (((Globe) this).sdist < 0)
				((Globe) this).sdist = 0;
			    ((Globe) this).scro
				= (int) ((float) ((Globe) this).spos2 / 275.0F
					 * (float) ((Globe) this).sdist);
			    i_33_ = 0;
			    string = "";
			    for (int i_35_ = 0; i_35_ <= i_22_; i_35_++) {
				if (i_35_ != i_22_) {
				    if (!string.equals(strings_19_[i_35_])) {
					if (i_35_ != 0) {
					    if ((i_33_ * 15
						 - ((Globe) this).scro) > -20
						&& ((i_33_ * 15
						     - ((Globe) this).scro)
						    < 345)) {
						((Globe) this).rd.setFont
						    (new Font("Tahoma", 0,
							      11));
						((Globe) this).rd.setColor
						    (color2k(125, 125, 125));
						((Globe) this).rd.drawString
						    (strings_20_[i_35_ - 1],
						     297,
						     (82 + i_33_ * 15
						      - ((Globe) this).scro));
					    }
					    i_33_++;
					}
					if ((i_33_ * 15 - ((Globe) this).scro
					     > -20)
					    && (i_33_ * 15
						- ((Globe) this).scro) < 345) {
					    ((Globe) this).rd.setFont
						(new Font("Tahoma", 1, 11));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    ((Globe) this).rd
						.setColor(new Color(0, 0, 0));
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     (strings_19_[i_35_])
						     .append
						     (":").toString(),
						 (292
						  - (((Globe) this).ftm
							 .stringWidth
						     (new StringBuilder()
							  .append
							  (strings_19_[i_35_])
							  .append
							  (":").toString()))),
						 (82 + i_33_ * 15
						  - ((Globe) this).scro));
					}
					string = strings_19_[i_35_];
				    }
				    if (bools[i_35_] && i_35_ == 0
					&& strings[i_35_].indexOf(" ") != -1)
					strings[i_35_]
					    = new StringBuilder().append
						  ("...").append
						  (strings[i_35_].substring
						   (strings[i_35_]
							.indexOf(" "),
						    strings[i_35_].length()))
						  .append
						  ("").toString();
				    if (i_33_ * 15 - ((Globe) this).scro > -20
					&& (i_33_ * 15 - ((Globe) this).scro
					    < 345)) {
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).rd
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rd.drawString
					    (strings[i_35_], 297,
					     (82 + i_33_ * 15
					      - ((Globe) this).scro));
				    }
				    i_33_++;
				} else if ((i_33_ * 15 - ((Globe) this).scro
					    > -20)
					   && (i_33_ * 15 - ((Globe) this).scro
					       < 345)) {
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).rd
					.setColor(color2k(125, 125, 125));
				    ((Globe) this).rd.drawString
					(strings_20_[i_35_ - 1], 297,
					 (82 + i_33_ * 15
					  - ((Globe) this).scro));
				}
			    }
			} else {
			    ((Globe) this).sdist = 0;
			    ((Globe) this).scro = 0;
			    ((Globe) this).spos2 = 275;
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.setFont(new Font("Tahoma", 1,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Loading chat...",
				 498 - ((Globe) this).ftm
					   .stringWidth("Loading chat...") / 2,
				 220);
			}
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 46, 582, 25);
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.setColor(color2k(40, 40, 40));
			((Globe) this).rd.drawString("Global Chat", 213, 62);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 68, 770, 68);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 411, 582, 28);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 413, 770, 413);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(772, 88, 17, 306);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(203, 46, 4, 393);
			bool_3_ = true;
			if ((stringbutton(((Globe) this).rd, "Send Message",
					  731, 430, 3, i_1_, i_2_, bool, 0, 0)
			     || ((Control) control).enter)
			    && !((GameSparker) ((Globe) this).gs).cmsg.getText
				    ().equals("Type here...")
			    && !((GameSparker) ((Globe) this).gs).cmsg.getText
				    ().equals("")
			    && ((xtGraphics) ((Globe) this).xt).acexp != -3) {
			    String string = ((GameSparker) ((Globe) this).gs)
						.cmsg.getText
						().replace('|', ':');
			    if ((string.toLowerCase().indexOf
				 (((GameSparker) ((Globe) this).gs).tpass
				      .getText
				      ().toLowerCase()))
				!= -1)
				string = " ";
			    if (!((Globe) this).xt.msgcheck(string)
				&& ((Globe) this).updatec > -12) {
				for (int i_36_ = 0; i_36_ < 20; i_36_++) {
				    ((Globe) this).sentn[i_36_]
					= ((Globe) this).sentn[i_36_ + 1];
				    ((Globe) this).cnames[i_36_]
					= ((Globe) this).cnames[i_36_ + 1];
				    ((Globe) this).ctime[i_36_]
					= ((Globe) this).ctime[i_36_ + 1];
				}
				((Globe) this).sentn[20] = string;
				((Globe) this).cnames[20]
				    = (((xtGraphics) ((Globe) this).xt)
				       .nickname);
				((Globe) this).ctime[20] = "- just now";
				if (((Globe) this).updatec > -11)
				    ((Globe) this).updatec = -11;
				else
				    ((Globe) this).updatec--;
				((Globe) this).spos2 = 275;
			    } else
				((xtGraphics) ((Globe) this).xt).warning++;
			    ((GameSparker) ((Globe) this).gs).cmsg.setText("");
			    ((Control) control).enter = false;
			}
			if (((Globe) this).mscro2 == 831
			    || ((Globe) this).sdist == 0) {
			    if (((Globe) this).sdist == 0)
				((Globe) this).rd.setColor(color2k(205, 205,
								   205));
			    else
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fillRect(772, 71, 17, 17);
			} else {
			    ((Globe) this).rd.setColor(color2k(220, 220, 220));
			    ((Globe) this).rd.fill3DRect(772, 71, 17, 17,
							 true);
			}
			if (((Globe) this).sdist != 0)
			    ((Globe) this).rd.drawImage((((xtGraphics)
							  ((Globe) this).xt)
							 .asu),
							777, 77, null);
			if (((Globe) this).mscro2 == 832
			    || ((Globe) this).sdist == 0) {
			    if (((Globe) this).sdist == 0)
				((Globe) this).rd.setColor(color2k(205, 205,
								   205));
			    else
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fillRect(772, 394, 17, 17);
			} else {
			    ((Globe) this).rd.setColor(color2k(220, 220, 220));
			    ((Globe) this).rd.fill3DRect(772, 394, 17, 17,
							 true);
			}
			if (((Globe) this).sdist != 0)
			    ((Globe) this).rd.drawImage((((xtGraphics)
							  ((Globe) this).xt)
							 .asd),
							777, 401, null);
			if (((Globe) this).sdist != 0) {
			    if (((Globe) this).lspos2
				!= ((Globe) this).spos2) {
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
				((Globe) this).rd.fillRect(772,
							   88 + (((Globe) this)
								 .spos2),
							   17, 31);
			    } else {
				if (((Globe) this).mscro2 == 831)
				    ((Globe) this).rd
					.setColor(color2k(215, 215, 215));
				((Globe) this).rd.fill3DRect(772,
							     88 + ((Globe)
								   this).spos2,
							     17, 31, true);
			    }
			    ((Globe) this).rd.setColor(color2k(150, 150, 150));
			    ((Globe) this).rd.drawLine
				(777, 101 + ((Globe) this).spos2, 783,
				 101 + ((Globe) this).spos2);
			    ((Globe) this).rd.drawLine
				(777, 103 + ((Globe) this).spos2, 783,
				 103 + ((Globe) this).spos2);
			    ((Globe) this).rd.drawLine
				(777, 105 + ((Globe) this).spos2, 783,
				 105 + ((Globe) this).spos2);
			    if (((Globe) this).mscro2 > 800
				&& (((Globe) this).lspos2
				    != ((Globe) this).spos2))
				((Globe) this).lspos2 = ((Globe) this).spos2;
			    if (bool) {
				if (((Globe) this).mscro2 == 825 && i_1_ > 772
				    && i_1_ < 789
				    && i_2_ > 88 + ((Globe) this).spos2
				    && i_2_ < ((Globe) this).spos2 + 119)
				    ((Globe) this).mscro2
					= i_2_ - ((Globe) this).spos2;
				if (((Globe) this).mscro2 == 825 && i_1_ > 770
				    && i_1_ < 791 && i_2_ > 69 && i_2_ < 90)
				    ((Globe) this).mscro2 = 831;
				if (((Globe) this).mscro2 == 825 && i_1_ > 770
				    && i_1_ < 791 && i_2_ > 392 && i_2_ < 413)
				    ((Globe) this).mscro2 = 832;
				if (((Globe) this).mscro2 == 825 && i_1_ > 772
				    && i_1_ < 789 && i_2_ > 88 && i_2_ < 394) {
				    ((Globe) this).mscro2 = 103;
				    ((Globe) this).spos2
					= i_2_ - ((Globe) this).mscro2;
				}
				int i_37_ = 2670 / ((Globe) this).sdist;
				if (i_37_ < 1)
				    i_37_ = 1;
				if (((Globe) this).mscro2 == 831) {
				    ((Globe) this).spos2 -= i_37_;
				    if (((Globe) this).spos2 > 275)
					((Globe) this).spos2 = 275;
				    if (((Globe) this).spos2 < 0)
					((Globe) this).spos2 = 0;
				    ((Globe) this).lspos2
					= ((Globe) this).spos2;
				}
				if (((Globe) this).mscro2 == 832) {
				    ((Globe) this).spos2 += i_37_;
				    if (((Globe) this).spos2 > 275)
					((Globe) this).spos2 = 275;
				    if (((Globe) this).spos2 < 0)
					((Globe) this).spos2 = 0;
				    ((Globe) this).lspos2
					= ((Globe) this).spos2;
				}
				if (((Globe) this).mscro2 < 800) {
				    ((Globe) this).spos2
					= i_2_ - ((Globe) this).mscro2;
				    if (((Globe) this).spos2 > 275)
					((Globe) this).spos2 = 275;
				    if (((Globe) this).spos2 < 0)
					((Globe) this).spos2 = 0;
				}
				if (((Globe) this).mscro2 == 825)
				    ((Globe) this).mscro2 = 925;
			    } else if (((Globe) this).mscro2 != 825)
				((Globe) this).mscro2 = 825;
			}
		    }
		    if (((Globe) this).tab == 1) {
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 0.4F));
			((Globe) this).rd.setColor(new Color(255, 255, 255));
			((Globe) this).rd.fillRoundRect(207, 45, 577, 394, 20,
							20);
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 1.0F));
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawRoundRect(207, 45, 577, 394, 20,
							20);
			if (!((Globe) this).flg)
			    ((Globe) this).flk += 5;
			else
			    ((Globe) this).flk -= 5;
			if (((Globe) this).flk >= 100) {
			    ((Globe) this).flk = 100;
			    ((Globe) this).flg = true;
			}
			if (((Globe) this).flk <= 60) {
			    ((Globe) this).flk = 60;
			    ((Globe) this).flg = false;
			}
			((Globe) this).rd.setFont(new Font("Arial", 1, 13));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.setComposite
			    (AlphaComposite.getInstance(3, ((float) ((Globe)
								     this).flk
							    / 100.0F)));
			boolean bool_38_ = false;
			if (((Globe) this).protab == 2) {
			    if (((Globe) this).proname.equals
				(((xtGraphics) ((Globe) this).xt).nickname)) {
				((Globe) this).rd.drawString("Your Stages",
							     227, 67);
				bool_38_ = true;
			    } else {
				((Globe) this).rd.drawString
				    (new StringBuilder().append("").append
					 (((Globe) this).proname).append
					 ("'s").toString(),
				     227, 67);
				((Globe) this).rd.drawString("Stages", 227,
							     84);
			    }
			    ((Globe) this).rd.setComposite
				(AlphaComposite.getInstance(3, 1.0F));
			    ((GameSparker) ((Globe) this).gs).proitem.move
				(496 - ((GameSparker) ((Globe) this).gs)
					   .proitem.getWidth() / 2,
				 60);
			    ((Smenu) ((GameSparker) ((Globe) this).gs).proitem)
				.show
				= true;
			    if (stringbutton(((Globe) this).rd,
					     "< Back to Profile", 715, 76, 1,
					     i_1_, i_2_, bool, 0, 0)) {
				((Globe) this).protab = 0;
				((Smenu) (((GameSparker) ((Globe) this).gs)
					  .proitem)).show
				    = false;
				((Globe) this).addstage = 0;
			    }
			    if (((Smenu)
				 ((GameSparker) ((Globe) this).gs).proitem).sel
				!= 0) {
				if (((GameSparker) ((Globe) this).gs)
					.proitem.getSelectedItem
					().equals(((Globe) this).loadpstage)) {
				    if (((Globe) this).loadedpstage) {
					((Medium) ((Globe) this).m).trk = 4;
					((Medium) ((Globe) this).m).ih = -10;
					((Medium) ((Globe) this).m).iw = -10;
					((Medium) ((Globe) this).m).h = 320;
					((Medium) ((Globe) this).m).w = 580;
					((Medium) ((Globe) this).m).cx = 280;
					((Medium) ((Globe) this).m).cy = 150;
					((Globe) this).m
					    .aroundtrack(((Globe) this).cp);
					((Globe) this).rdo.setRenderingHint
					    (RenderingHints.KEY_ANTIALIASING,
					     (RenderingHints
					      .VALUE_ANTIALIAS_OFF));
					((Globe) this).m.d(((Globe) this).rdo);
					int i_39_ = 0;
					int[] is = new int[1000];
					for (int i_40_ = 0;
					     i_40_ < ((GameSparker)
						      ((Globe) this).gs).nob;
					     i_40_++) {
					    if (((ContO)
						 ((Globe) this).co[i_40_]).dist
						!= 0) {
						is[i_39_] = i_40_;
						i_39_++;
					    } else
						((Globe) this).co[i_40_]
						    .d(((Globe) this).rdo);
					}
					int[] is_41_ = new int[i_39_];
					for (int i_42_ = 0; i_42_ < i_39_;
					     i_42_++)
					    is_41_[i_42_] = 0;
					for (int i_43_ = 0; i_43_ < i_39_;
					     i_43_++) {
					    for (int i_44_ = i_43_ + 1;
						 i_44_ < i_39_; i_44_++) {
						if ((((ContO) (((Globe) this)
							       .co[is[i_43_]]))
						     .dist)
						    != ((ContO)
							(((Globe) this).co
							 [is[i_44_]])).dist) {
						    if (((ContO)
							 (((Globe) this).co
							  [is[i_43_]])).dist
							< ((ContO)
							   (((Globe) this).co
							    [is[i_44_]])).dist)
							is_41_[i_43_]++;
						    else
							is_41_[i_44_]++;
						} else if (i_44_ > i_43_)
						    is_41_[i_43_]++;
						else
						    is_41_[i_44_]++;
					    }
					}
					for (int i_45_ = 0; i_45_ < i_39_;
					     i_45_++) {
					    for (int i_46_ = 0; i_46_ < i_39_;
						 i_46_++) {
						if (is_41_[i_46_] == i_45_)
						    ((Globe) this).co
							[is[i_46_]]
							.d(((Globe) this).rdo);
					    }
					}
					((Globe) this).rdo.setRenderingHint
					    (RenderingHints.KEY_ANTIALIASING,
					     (RenderingHints
					      .VALUE_ANTIALIAS_ON));
					((Medium) ((Globe) this).m).trk = 0;
					((Medium) ((Globe) this).m).h = 450;
					((Medium) ((Globe) this).m).w = 800;
					((Medium) ((Globe) this).m).cx = 400;
					((Medium) ((Globe) this).m).cy = 225;
					((Globe) this).rdo.setComposite
					    (AlphaComposite.getInstance(3,
									0.5F));
					((Globe) this).rdo.setColor
					    (new Color(255, 255, 255));
					((Globe) this).rdo.fillRoundRect(9, 44,
									 136,
									 39,
									 20,
									 20);
					((Globe) this).rdo.setComposite
					    (AlphaComposite.getInstance(3,
									1.0F));
					((Globe) this).rdo
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rdo
						  .getFontMetrics();
					((Globe) this).rdo
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rdo.drawString
					    ("Created/Published by", 17, 59);
					int i_47_
					    = (17
					       + (((Globe) this).ftm
						      .stringWidth
						  ("Created/Published by")) / 2
					       - ((((Globe) this).ftm
						       .stringWidth
						   (((CheckPoints)
						     ((Globe) this).cp).maker))
						  / 2));
					int i_48_
					    = i_47_ + (((Globe) this).ftm
							   .stringWidth
						       (((CheckPoints)
							 ((Globe) this).cp)
							.maker));
					((Globe) this).rdo.drawString
					    ((((CheckPoints) ((Globe) this).cp)
					      .maker),
					     i_47_, 74);
					((Globe) this).rdo.drawLine(i_47_, 76,
								    i_48_, 76);
					if (i_1_ > i_47_ + 216
					    && i_1_ < i_48_ + 216 && i_2_ > 154
					    && i_2_ < 168) {
					    ((Globe) this).cur = 12;
					    if (bool) {
						((Globe) this).tab = 1;
						if (!((Globe) this).proname
							 .equals
						     (((CheckPoints)
						       ((Globe) this).cp)
						      .maker)) {
						    ((Globe) this).proname
							= (((CheckPoints)
							    ((Globe) this).cp)
							   .maker);
						    ((Globe) this).loadedp
							= false;
						    onexitpro();
						}
					    }
					}
					if ((((GameSparker) ((Globe) this).gs)
						 .proitem.getSelectedIndex()
					     != ((Smenu) (((GameSparker)
							   ((Globe) this).gs)
							  .proitem)).no - 1)
					    && (stringbutton
						(((Globe) this).rdo,
						 " Next > ", 510, 200, -3,
						 i_1_, i_2_,
						 bool && !(((GameSparker)
							    ((Globe) this).gs)
							   .openm),
						 216, 92)))
					    ((Smenu)
					     (((GameSparker) ((Globe) this).gs)
					      .proitem)).sel++;
					if ((((GameSparker) ((Globe) this).gs)
						 .proitem.getSelectedIndex()
					     != 1)
					    && (stringbutton
						(((Globe) this).rdo,
						 " < Prev ", 50, 200, -3, i_1_,
						 i_2_,
						 bool && !(((GameSparker)
							    ((Globe) this).gs)
							   .openm),
						 216, 92)))
					    ((Smenu)
					     (((GameSparker) ((Globe) this).gs)
					      .proitem)).sel--;
					if ((((CheckPoints) ((Globe) this).cp)
					     .pubt)
					    > 0) {
					    ((Globe) this).rd.setFont
						(new Font("Arial", 1, 12));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    ((Globe) this).rd
						.setColor(new Color(0, 0, 0));
					    if (((Globe) this).addstage == 2) {
						((Globe) this).rd.drawString
						    ("Adding Stage...",
						     (496
						      - ((((Globe) this)
							      .ftm.stringWidth
							  ("Adding Stage..."))
							 / 2)),
						     419);
						if ((((CarDefine)
						      ((Globe) this).cd)
						     .staction)
						    == 0)
						    ((Globe) this).addstage
							= 3;
						if ((((CarDefine)
						      ((Globe) this).cd)
						     .staction)
						    == -2)
						    ((Globe) this).addstage
							= 4;
						if ((((CarDefine)
						      ((Globe) this).cd)
						     .staction)
						    == -3)
						    ((Globe) this).addstage
							= 5;
						if ((((CarDefine)
						      ((Globe) this).cd)
						     .staction)
						    == -1)
						    ((Globe) this).addstage
							= 6;
					    }
					    if (((Globe) this).addstage == 3)
						((Globe) this).rd.drawString
						    (new StringBuilder().append
							 ("[").append
							 (((CarDefine)
							   ((Globe) this).cd)
							  .onstage)
							 .append
							 ("] has been added to your stages!")
							 .toString(),
						     (496
						      - (((Globe) this).ftm
							     .stringWidth
							 (new StringBuilder
							      ().append
							      ("[").append
							      (((CarDefine)
								(((Globe) this)
								 .cd)).onstage)
							      .append
							      ("] has been added to your stages!")
							      .toString
							  ())) / 2),
						     419);
					    if (((Globe) this).addstage == 4)
						((Globe) this).rd.drawString
						    ("You already have this stage.",
						     (496
						      - ((((Globe) this)
							      .ftm.stringWidth
							  ("You already have this stage."))
							 / 2)),
						     419);
					    if (((Globe) this).addstage == 5)
						((Globe) this).rd.drawString
						    ("Cannot add more then 20 stages to your account!",
						     (496
						      - ((((Globe) this)
							      .ftm.stringWidth
							  ("Cannot add more then 20 stages to your account!"))
							 / 2)),
						     419);
					    if (((Globe) this).addstage == 6)
						((Globe) this).rd.drawString
						    ("Failed to add stage!  Unknown error, please try again later.",
						     (496
						      - ((((Globe) this)
							      .ftm.stringWidth
							  ("Failed to add stage!  Unknown error, please try again later."))
							 / 2)),
						     419);
					    if (((Globe) this).addstage == 1) {
						String string
						    = "Upgrade to a full account to add custom stages!";
						int i_49_
						    = 496 - (((Globe) this)
								 .ftm
								 .stringWidth
							     (string)) / 2;
						int i_50_
						    = (i_49_
						       + (((Globe) this)
							      .ftm.stringWidth
							  (string)));
						((Globe) this).rd.drawString
						    (string, i_49_, 419);
						if (((Globe) this).waitlink
						    != -1)
						    ((Globe) this).rd.drawLine
							(i_49_, 435, i_50_,
							 435);
						if (i_1_ > i_49_
						    && i_1_ < i_50_
						    && i_2_ > 421
						    && i_2_ < 435) {
						    if (((Globe) this).waitlink
							!= -1)
							((Globe) this).cur
							    = 12;
						    if (bool
							&& (((Globe) this)
							    .waitlink) == 0) {
							((Globe) this).gs
							    .editlink
							    (((xtGraphics)
							      (((Globe) this)
							       .xt)).nickname,
							     true);
							((Globe) this).waitlink
							    = -1;
						    }
						}
						if (((Globe) this).waitlink
						    > 0)
						    ((Globe) this).waitlink--;
					    }
					    if (((Globe) this).addstage == 0
						&& (((Globe) this).xt.drawcarb
						    (true, null,
						     " Add to My Stages ", 437,
						     401, i_1_, i_2_,
						     bool && ((((Globe) this)
							       .blocknote)
							      == 0)))) {
						if (((xtGraphics)
						     ((Globe) this).xt)
						    .logged) {
						    ((CarDefine)
						     ((Globe) this).cd).onstage
							= (((Globe) this)
							   .loadpstage);
						    ((CarDefine)
						     ((Globe) this).cd)
							.staction
							= 2;
						    ((Globe) this).cd
							.sparkstageaction();
						    ((Globe) this).addstage
							= 2;
						} else {
						    ((Globe) this).addstage
							= 1;
						    ((Globe) this).waitlink
							= 20;
						}
					    }
					} else {
					    ((Globe) this).rd.setFont
						(new Font("Arial", 1, 12));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    ((Globe) this).rd
						.setColor(new Color(0, 0, 0));
					    ((Globe) this).rd.drawString
						("Private Stage",
						 496 - (((Globe) this).ftm
							    .stringWidth
							("Private Stage")) / 2,
						 419);
					}
				    } else {
					((Globe) this).rdo
					    .setColor(new Color(206, 171, 98));
					((Globe) this).rdo.fillRect(0, 0, 560,
								    300);
					((Globe) this).rdo
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rdo
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rdo
						  .getFontMetrics();
					((Globe) this).rdo.drawString
					    ("Failed to load stage, try again later or try another stage...",
					     (280
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Failed to load stage, try again later or try another stage..."))
						 / 2)),
					     140);
				    }
				} else {
				    ((Globe) this).rdo
					.setColor(new Color(206, 171, 98));
				    ((Globe) this).rdo.fillRect(0, 0, 560,
								300);
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    ((Globe) this).rdo
					.setFont(new Font("Arial", 1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rdo.getFontMetrics();
				    ((Globe) this).rdo.drawString
					("Loading stage, please wait...",
					 (280
					  - ((((Globe) this).ftm.stringWidth
					      ("Loading stage, please wait..."))
					     / 2)),
					 140);
				}
			    } else {
				((Globe) this).rdo.setColor(new Color(206, 171,
								      98));
				((Globe) this).rdo.fillRect(0, 0, 560, 300);
			    }
			    ((Globe) this).rd.drawImage(((Globe) this).gImage,
							216, 92, null);
			}
			if (((Globe) this).protab == 0) {
			    if (((Globe) this).proname.equals
				(((xtGraphics) ((Globe) this).xt).nickname)) {
				((Globe) this).rd.drawString("Your Profile",
							     232, 67);
				bool_38_ = true;
			    } else
				((Globe) this).rd.drawString
				    (new StringBuilder().append("").append
					 (((Globe) this).proname).append
					 ("'s Profile").toString(),
				     232, 67);
			    ((Globe) this).rd.setComposite
				(AlphaComposite.getInstance(3, 1.0F));
			    if (((Globe) this).loadedp) {
				if (!bool_38_
				    && stringbutton(((Globe) this).rd,
						    "   My Profile   ", 715,
						    73, 1, i_1_, i_2_, bool, 0,
						    0)) {
				    ((Globe) this).proname
					= (((xtGraphics) ((Globe) this).xt)
					   .nickname);
				    ((Globe) this).loadedp = false;
				    onexitpro();
				}
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.setFont(new Font("Arial", 0,
								   11));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				if (((Globe) this).logol)
				    drawl(((Globe) this).rd,
					  ((Globe) this).proname, 236, 101,
					  true);
				else
				    ((Globe) this).rd.drawString
					("No logo available",
					 296 - (((Globe) this).ftm.stringWidth
						("No logo available")) / 2,
					 121);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				String string = "Logo";
				if (i_1_ > 232 && i_1_ < 359 && i_2_ > 84
				    && i_2_ < 134 && ((Globe) this).edit == 0
				    && bool_38_) {
				    string = "Edit Logo";
				    ((Globe) this).rd.drawLine
					(238, 98,
					 238 + ((Globe) this).ftm
						   .stringWidth(string),
					 98);
				    if (i_1_ > 238
					&& (i_1_
					    < 238 + ((Globe) this).ftm
							.stringWidth(string))
					&& i_2_ > 85 && i_2_ < 100) {
					((Globe) this).cur = 12;
					if (bool) {
					    if (((xtGraphics)
						 ((Globe) this).xt)
						.logged) {
						((Globe) this).edit = 1;
						((Globe) this).msg
						    = "Edit your Nickname's logo";
						((Globe) this).flko = 0;
					    } else
						((Globe) this).edit = 5;
					}
				    }
				}
				((Globe) this).rd.drawString(string, 238, 97);
				((Globe) this).rd.drawLine(232, 84, 232, 134);
				((Globe) this).rd.drawLine
				    (232, 84,
				     (238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     84);
				((Globe) this).rd.drawLine
				    ((238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     84,
				     (238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     97);
				((Globe) this).rd.drawLine
				    ((238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     97, 359, 97);
				((Globe) this).rd.drawLine(359, 97, 359, 134);
				((Globe) this).rd.drawLine(232, 134, 359, 134);
				if (bool_38_
				    && !((xtGraphics) ((Globe) this).xt)
					    .clan
					    .equals(((Globe) this).proclan))
				    ((Globe) this).proclan
					= (((xtGraphics) ((Globe) this).xt)
					   .clan);
				if (!((Globe) this).proclan.equals("")) {
				    if (!drawl(((Globe) this).rd,
					       new StringBuilder().append
						   ("#").append
						   (((Globe) this).proclan)
						   .append
						   ("#").toString(),
					       406, 101, true)) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 13));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					((Globe) this).rd.drawString
					    (new StringBuilder().append("")
						 .append
						 (((Globe) this).proclan)
						 .append
						 ("").toString(),
					     (581
					      - (((Globe) this).ftm.stringWidth
						 (new StringBuilder().append
						      ("").append
						      (((Globe) this).proclan)
						      .append
						      ("").toString())) / 2),
					     121);
				    }
				} else {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (bool_38_) {
					((Globe) this).rd.drawString
					    ("You have not joined a clan yet!",
					     416, 121);
					if (stringbutton
					    (((Globe) this).rd,
					     "   Find a clan to join   ", 663,
					     121, 1, i_1_, i_2_, bool, 0, 0)) {
					    ((Globe) this).tab = 3;
					    ((Globe) this).cfase = 2;
					    ((Globe) this).em = 1;
					    ((Globe) this).msg = "Clan Search";
					    ((Globe) this).smsg
						= "Listing clans with recent activity...";
					    ((Globe) this).nclns = 0;
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).flko = 0;
					}
				    } else if (((xtGraphics) ((Globe) this).xt)
						   .clan.equals(""))
					((Globe) this).rd.drawString
					    ("Has not joined a clan yet",
					     (581
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Has not joined a clan yet"))
						 / 2)),
					     121);
				    else {
					((Globe) this).rd.drawString
					    ("Has not joined a clan yet", 430,
					     121);
					if (stringbutton
					    (((Globe) this).rd,
					     " Invite to join your clan ", 657,
					     121, 1, i_1_, i_2_, bool, 0, 0)) {
					    ((Globe) this).tab = 2;
					    ((Globe) this).itab = 0;
					    ((Globe) this).litab = -1;
					    ((Globe) this).openc = 10;
					    if (!((Globe) this).opname.equals
						 (((Globe) this).proname)) {
						((Globe) this).opname
						    = ((Globe) this).proname;
						((Globe) this).lastsub = "";
						((Globe) this).readmsg = 1;
					    }
					    ((Globe) this).itemsel = 3;
					    ((Globe) this).forcsel = true;
					}
				    }
				}
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				string = "Clan";
				if (i_1_ > 402 && i_1_ < 759 && i_2_ > 84
				    && i_2_ < 134
				    && !((Globe) this).proclan.equals("")
				    && ((Globe) this).edit == 0) {
				    string
					= new StringBuilder().append
					      ("Clan :  ").append
					      (((Globe) this).proclan).append
					      ("").toString();
				    ((Globe) this).rd.drawLine
					(408, 98,
					 408 + ((Globe) this).ftm
						   .stringWidth(string),
					 98);
				    if ((i_1_ > 408
					 && (i_1_
					     < 408 + ((Globe) this).ftm
							 .stringWidth(string))
					 && i_2_ > 85 && i_2_ < 100)
					|| (i_1_ > 406 && i_1_ < 756
					    && i_2_ > 101 && i_2_ < 131)) {
					((Globe) this).cur = 12;
					if (bool) {
					    if (!((Globe) this).claname.equals
						 (((Globe) this).proclan)) {
						((Globe) this).claname
						    = ((Globe) this).proclan;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).tab = 3;
					    ((Globe) this).ctab = 0;
					}
				    }
				}
				((Globe) this).rd.drawString(string, 408, 97);
				((Globe) this).rd.drawLine(402, 84, 402, 134);
				((Globe) this).rd.drawLine
				    (402, 84,
				     (408
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     84);
				((Globe) this).rd.drawLine
				    ((408
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     84,
				     (408
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     97);
				((Globe) this).rd.drawLine
				    ((408
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     97, 759, 97);
				((Globe) this).rd.drawLine(759, 97, 759, 134);
				((Globe) this).rd.drawLine(402, 134, 759, 134);
				((Globe) this).rd.setFont(new Font("Arial", 0,
								   11));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				if (((Globe) this).avatarl)
				    ((Globe) this).rd.drawImage((((Globe) this)
								 .avatar),
								236, 161,
								null);
				else
				    ((Globe) this).rd.drawString
					("No avatar available",
					 336 - (((Globe) this).ftm.stringWidth
						("No avatar available")) / 2,
					 255);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				string = "Avatar";
				if (i_1_ > 232 && i_1_ < 439 && i_2_ > 144
				    && i_2_ < 364 && ((Globe) this).edit == 0
				    && bool_38_) {
				    string = "Edit Avatar";
				    ((Globe) this).rd.drawLine
					(238, 158,
					 238 + ((Globe) this).ftm
						   .stringWidth(string),
					 158);
				    if (i_1_ > 238
					&& (i_1_
					    < 238 + ((Globe) this).ftm
							.stringWidth(string))
					&& i_2_ > 145 && i_2_ < 160) {
					((Globe) this).cur = 12;
					if (bool) {
					    if (((xtGraphics)
						 ((Globe) this).xt)
						.logged) {
						((Globe) this).edit = 2;
						((Globe) this).msg
						    = "Edit your proflie avatar";
						((Globe) this).flko = 0;
					    } else
						((Globe) this).edit = 5;
					}
				    }
				}
				((Globe) this).rd.drawString(string, 238, 157);
				((Globe) this).rd.drawLine(232, 144, 232, 364);
				((Globe) this).rd.drawLine
				    (232, 144,
				     (238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     144);
				((Globe) this).rd.drawLine
				    ((238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     144,
				     (238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     157);
				((Globe) this).rd.drawLine
				    ((238
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     157, 439, 157);
				((Globe) this).rd.drawLine(439, 157, 439, 364);
				((Globe) this).rd.drawLine(232, 364, 439, 364);
				string = "About";
				if (i_1_ > 459 && i_1_ < 759 && i_2_ > 144
				    && i_2_ < 364 && ((Globe) this).edit == 0
				    && bool_38_) {
				    string = "Edit About";
				    ((Globe) this).rd.drawLine
					(465, 158,
					 465 + ((Globe) this).ftm
						   .stringWidth(string),
					 158);
				    if (i_1_ > 465
					&& (i_1_
					    < 465 + ((Globe) this).ftm
							.stringWidth(string))
					&& i_2_ > 145 && i_2_ < 160) {
					((Globe) this).cur = 12;
					if (bool) {
					    if (((xtGraphics)
						 ((Globe) this).xt)
						.logged) {
						((Globe) this).edit = 3;
						((Globe) this).msg = "";
						((Globe) this).flko = 0;
						((Globe) this).sentchange = 0;
						((Globe) this).badlang = false;
					    } else
						((Globe) this).edit = 5;
					}
				    }
				}
				((Globe) this).rd.drawString(string, 465, 157);
				((Globe) this).rd.drawLine(459, 144, 459, 364);
				((Globe) this).rd.drawLine
				    (459, 144,
				     (465
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     144);
				((Globe) this).rd.drawLine
				    ((465
				      + ((Globe) this).ftm.stringWidth(string)
				      + 2),
				     144,
				     (465
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     157);
				((Globe) this).rd.drawLine
				    ((465
				      + ((Globe) this).ftm.stringWidth(string)
				      + 15),
				     157, 759, 157);
				((Globe) this).rd.drawLine(759, 157, 759, 364);
				((Globe) this).rd.drawLine(459, 364, 759, 364);
				if (((Globe) this).nab != 0) {
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 1, 11));
				    int i_51_ = 200;
				    if (((Globe) this).nab == 2)
					i_51_ = 192;
				    if (((Globe) this).nab == 3)
					i_51_ = 185;
				    for (int i_52_ = 0;
					 i_52_ < ((Globe) this).nab; i_52_++)
					((Globe) this).rd.drawString
					    (((Globe) this).aboutxt[i_52_],
					     469, i_51_ + i_52_ * 15);
				} else {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.drawString
					("No description available",
					 609 - ((((Globe) this).ftm.stringWidth
						 ("No description available"))
						/ 2),
					 200);
				}
				((Globe) this).rd.drawLine(489, 230, 729, 230);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Racing",
				     532 - ((Globe) this).ftm
					       .stringWidth("Racing") / 2,
				     253);
				((Globe) this).rd.drawString
				    ("VS",
				     532 - ((Globe) this).ftm
					       .stringWidth("VS") / 2,
				     270);
				((Globe) this).rd.drawString
				    ("Wasting",
				     532 - ((Globe) this).ftm
					       .stringWidth("Wasting") / 2,
				     287);
				float f = (float) ((Globe) this).racing;
				float f_53_ = (float) ((Globe) this).wasting;
				if (((Globe) this).racing > 10
				    && (((Globe) this).racing
					> ((Globe) this).wasting)) {
				    f = 10.0F;
				    f_53_ = ((float) ((Globe) this).wasting
					     / ((float) ((Globe) this).racing
						/ 10.0F));
				}
				if (((Globe) this).wasting > 10
				    && (((Globe) this).wasting
					>= ((Globe) this).racing)) {
				    f_53_ = 10.0F;
				    f = ((float) ((Globe) this).racing
					 / ((float) ((Globe) this).wasting
					    / 10.0F));
				}
				f *= 14.0F;
				f_53_ *= 14.0F;
				for (int i_54_ = 0; i_54_ < 5; i_54_++) {
				    if (f != 0.0F) {
					((Globe) this).rd.setColor
					    (new Color(0, i_54_ * 50, 255));
					((Globe) this).rd.drawLine
					    (569, 245 + i_54_,
					     (int) (569.0F + f), 245 + i_54_);
					((Globe) this).rd.drawLine
					    (569, 254 - i_54_,
					     (int) (569.0F + f), 254 - i_54_);
				    }
				    if (f_53_ != 0.0F) {
					((Globe) this).rd.setColor
					    (new Color(255, i_54_ * 50, 0));
					((Globe) this).rd.drawLine
					    (569, 279 + i_54_,
					     (int) (569.0F + f_53_),
					     279 + i_54_);
					((Globe) this).rd.drawLine
					    (569, 288 - i_54_,
					     (int) (569.0F + f_53_),
					     288 - i_54_);
				    }
				}
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(569, 244, 140, 11);
				((Globe) this).rd.drawRect(569, 278, 140, 11);
				((Globe) this).rd.drawLine(489, 304, 729, 304);
				if (!((Globe) this).themesong.equals("")
				    && ((Globe) this).trackvol != 0) {
				    if (((Globe) this).playt == 1)
					((Globe) this).rd.drawString
					    ("Loading theme song, please wait...",
					     (609
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Loading theme song, please wait..."))
						 / 2)),
					     340);
				    if (((Globe) this).playt == 0
					&& stringbutton(((Globe) this).rd,
							" Play Theme Song ",
							609, 340, 1, i_1_,
							i_2_, bool, 0, 0)
					&& ((Globe) this).edit == 0)
					((Globe) this).playt = 1;
				    if (((Globe) this).playt == 2) {
					((Globe) this).rd.drawString
					    ("Theme song playing...",
					     609 - ((((Globe) this).ftm
							 .stringWidth
						     ("Theme song playing..."))
						    / 2),
					     325);
					if (stringbutton(((Globe) this).rd,
							 " Stop ", 609, 350, 2,
							 i_1_, i_2_, bool, 0,
							 0)) {
					    ((xtGraphics) ((Globe) this).xt)
						.strack.unload();
					    ((Globe) this).playt = 0;
					}
				    }
				} else {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.drawString
					("No theme song available",
					 609 - ((((Globe) this).ftm.stringWidth
						 ("No theme song available"))
						/ 2),
					 340);
				}
				if (!bool_38_) {
				    if (((Globe) this).sfreq == 0) {
					((Globe) this).rd.drawRect(232, 378,
								   527, 50);
					boolean bool_55_ = false;
					for (int i_56_ = 0;
					     i_56_ < ((Globe) this).npf;
					     i_56_++) {
					    if (((Globe) this).proname
						    .toLowerCase
						    ().equals
						(((Globe) this).fname
						     [i_56_].toLowerCase())) {
						bool_55_ = true;
						break;
					    }
					}
					if (bool_55_) {
					    if (stringbutton
						(((Globe) this).rd,
						 "    Un-friend    ", 313, 408,
						 1, i_1_, i_2_, bool, 0, 0))
						((Globe) this).sfreq = 4;
					} else if (stringbutton
						   (((Globe) this).rd,
						    "   Add Friend   ", 313,
						    408, 1, i_1_, i_2_, bool,
						    0, 0))
					    ((Globe) this).sfreq = 1;
					if (stringbutton(((Globe) this).rd,
							 "   Send Message   ",
							 436, 408, 1, i_1_,
							 i_2_, bool, 0, 0)) {
					    ((Globe) this).tab = 2;
					    ((Globe) this).openc = 10;
					    ((Globe) this).itab = 0;
					    ((Globe) this).litab = -1;
					    if (!((Globe) this).opname.equals
						 (((Globe) this).proname)) {
						((Globe) this).opname
						    = ((Globe) this).proname;
						((Globe) this).lastsub = "";
						((Globe) this).readmsg = 1;
					    }
					}
					if (stringbutton(((Globe) this).rd,
							 "   View Cars   ",
							 558, 408, 1, i_1_,
							 i_2_, bool, 0, 0)) {
					    ((CarDefine) ((Globe) this).cd)
						.viewname
						= ((Globe) this).proname;
					    onexitpro();
					    ((CarDefine) ((Globe) this).cd)
						.action
						= 100;
					    ((xtGraphics) ((Globe) this).xt)
						.cfase
						= 100;
					    ((xtGraphics) ((Globe) this).xt)
						.onviewpro
						= true;
					    ((xtGraphics) ((Globe) this).xt)
						.fase
						= 23;
					}
					if (stringbutton(((Globe) this).rd,
							 "   View Stages   ",
							 673, 408, 1, i_1_,
							 i_2_, bool, 0, 0)) {
					    ((Globe) this).protab = 2;
					    ((Globe) this).loadpst = 0;
					    ((GameSparker) ((Globe) this).gs)
						.proitem.removeAll();
					    ((GameSparker) ((Globe) this).gs)
						.proitem.add
						(((GameSparker)
						  ((Globe) this).gs).rd,
						 "Loading stages, please wait...");
					}
				    } else {
					((Globe) this).rd.setColor
					    (new Color(236, 215, 140));
					((Globe) this).rd.fillRect(232, 378,
								   527, 50);
					((Globe) this).rd
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rd.drawRect(232, 378,
								   527, 50);
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (((Globe) this).sfreq == 1)
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("Sending a friend request to ")
						     .append
						     (((Globe) this).proname)
						     .append
						     (", please wait...")
						     .toString(),
						 (495
						  - (((Globe) this).ftm
							 .stringWidth
						     (new StringBuilder()
							  .append
							  ("Sending a friend request to ")
							  .append
							  (((Globe) this)
							   .proname)
							  .append
							  (", please wait...")
							  .toString())) / 2),
						 408);
					if (((Globe) this).sfreq == 2) {
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("Friend request sent, waiting for ")
						     .append
						     (((Globe) this).proname)
						     .append
						     ("'s approval.")
						     .toString(),
						 (495
						  - (((Globe) this).ftm
							 .stringWidth
						     (new StringBuilder()
							  .append
							  ("Friend request sent, waiting for ")
							  .append
							  (((Globe) this)
							   .proname)
							  .append
							  ("'s approval.")
							  .toString())) / 2),
						 408);
					    if (stringbutton(((Globe) this).rd,
							     "  OK  ", 690,
							     408, 1, i_1_,
							     i_2_, bool, 0, 0))
						((Globe) this).sfreq = 0;
					}
					if (((Globe) this).sfreq == 3) {
					    ((Globe) this).rd.drawString
						("Failed to send friend request, please try again later.",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Failed to send friend request, please try again later."))
						     / 2)),
						 408);
					    if (stringbutton(((Globe) this).rd,
							     "  OK  ", 690,
							     408, 1, i_1_,
							     i_2_, bool, 0, 0))
						((Globe) this).sfreq = 0;
					}
					if (((Globe) this).sfreq == 4)
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("Removing ").append
						     (((Globe) this).proname)
						     .append
						     (" from firends, please wait...")
						     .toString(),
						 (495
						  - (((Globe) this).ftm
							 .stringWidth
						     (new StringBuilder()
							  .append
							  ("Removing ").append
							  (((Globe) this)
							   .proname)
							  .append
							  (" from firends, please wait...")
							  .toString())) / 2),
						 408);
					if (((Globe) this).sfreq == 5) {
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("You are no longer friends with ")
						     .append
						     (((Globe) this).proname)
						     .append
						     (".").toString(),
						 (495
						  - (((Globe) this).ftm
							 .stringWidth
						     (new StringBuilder()
							  .append
							  ("You are no longer friends with ")
							  .append
							  (((Globe) this)
							   .proname)
							  .append
							  (".")
							  .toString())) / 2),
						 408);
					    if (stringbutton(((Globe) this).rd,
							     "  OK  ", 690,
							     408, 1, i_1_,
							     i_2_, bool, 0, 0))
						((Globe) this).sfreq = 0;
					}
					if (((Globe) this).sfreq == 6) {
					    ((Globe) this).rd.drawString
						("Failed to remove friend, please try again later.",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Failed to remove friend, please try again later."))
						     / 2)),
						 408);
					    if (stringbutton(((Globe) this).rd,
							     "  OK  ", 690,
							     408, 1, i_1_,
							     i_2_, bool, 0, 0))
						((Globe) this).sfreq = 0;
					}
				    }
				}
				if (((Globe) this).edit == 1
				    || ((Globe) this).edit == 2) {
				    ((Globe) this).rd
					.setColor(new Color(244, 232, 204));
				    ((Globe) this).rd.fillRoundRect(265, 92,
								    460, 220,
								    20, 20);
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawRoundRect(265, 92,
								    460, 220,
								    20, 20);
				    String[] strings
					= { "logo", "120x30", "4 : 1" };
				    if (((Globe) this).edit == 2) {
					strings[0] = "avatar";
					strings[1] = "200x200";
					strings[2] = "1 : 1";
				    }
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (((Globe) this).flko % 4 != 0
					|| ((Globe) this).flko == 0)
					((Globe) this).rd.drawString
					    (((Globe) this).msg,
					     495 - (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).msg)) / 2,
					     115);
				    if (((Globe) this).flko != 0)
					((Globe) this).flko--;
				    ((Globe) this).rd.setFont(new Font("Arial",
								       0, 12));
				    ((Globe) this).rd.drawString
					(new StringBuilder().append("The ")
					     .append
					     (strings[0]).append
					     (" image is ").append
					     (strings[1]).append
					     (" pixels.").toString(),
					 275, 140);
				    ((Globe) this).rd.drawString
					("Any image uploaded will be resized to that width and height. For the best results",
					 275, 160);
				    ((Globe) this).rd.drawString
					(new StringBuilder().append
					     ("try to upload an image that is bigger or equal to ")
					     .append
					     (strings[1]).append
					     (" and has the scale of")
					     .toString(),
					 275, 180);
				    ((Globe) this).rd.drawString
					(new StringBuilder().append("[ ")
					     .append
					     (strings[2]).append
					     (" ]  in  [ Width : Height ].")
					     .toString(),
					 275, 200);
				    ((Globe) this).rd.drawString
					("Image uploaded must be less than 1MB and in the format of JPEG, GIF or PNG.",
					 275, 220);
				    if (((Globe) this).upload == 0) {
					if (stringbutton(((Globe) this).rd,
							 "  Upload Image  ",
							 495, 250, 0, i_1_,
							 i_2_, bool, 0, 0)) {
					    FileDialog filedialog
						= (new FileDialog
						   (new Frame(),
						    "Upload Image"));
					    filedialog.setMode(0);
					    filedialog.setVisible(true);
					    ((Globe) this).filename
						= new StringBuilder().append
						      ("").append
						      (filedialog
							   .getDirectory())
						      .append
						      ("").append
						      (filedialog.getFile())
						      .append
						      ("").toString();
					    if (!((Globe) this).filename
						     .equals("nullnull"))
						((Globe) this).upload = 1;
					}
				    } else {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (((Globe) this).upload == 1)
					    ((Globe) this).rd.drawString
						("Checking image...",
						 495 - ((((Globe) this).ftm
							     .stringWidth
							 ("Checking image..."))
							/ 2),
						 250);
					if (((Globe) this).upload == 2)
					    ((Globe) this).rd.drawString
						("Authenticating...",
						 495 - ((((Globe) this).ftm
							     .stringWidth
							 ("Authenticating..."))
							/ 2),
						 250);
					if (((Globe) this).upload == 3)
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("Uploading image :  ")
						     .append
						     (((Globe) this).perc)
						     .append
						     (" %").toString(),
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Uploading image :  80 %"))
						     / 2)),
						 250);
					if (((Globe) this).upload == 4)
					    ((Globe) this).rd.drawString
						("Creating image online...",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Creating image online..."))
						     / 2)),
						 250);
					if (((Globe) this).upload == 5)
					    ((Globe) this).rd.drawString
						("Done",
						 (495
						  - (((Globe) this).ftm
							 .stringWidth("Done")
						     / 2)),
						 250);
				    }
				    if (stringbutton(((Globe) this).rd,
						     " Cancel ", 495, 290, 2,
						     i_1_, i_2_, bool, 0, 0)) {
					if (((Globe) this).upload == 0)
					    ((Globe) this).edit = 0;
					else
					    ((Globe) this).upload = 0;
				    }
				}
				if (((Globe) this).edit == 3) {
				    ((Globe) this).rd
					.setColor(new Color(244, 232, 204));
				    ((Globe) this).rd.fillRoundRect(265, 38,
								    460, 390,
								    20, 20);
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawRoundRect(265, 38,
								    460, 390,
								    20, 20);
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.drawString
					("Edit your about section",
					 495 - ((((Globe) this).ftm.stringWidth
						 ("Edit your about section"))
						/ 2),
					 61);
				    ((Globe) this).rd.setFont(new Font("Arial",
								       0, 12));
				    if (!((Globe) this).badlang)
					((Globe) this).rd.drawString
					    ("Type in a sentence that best describes you and your playing style in the game :",
					     275, 86);
				    else {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).rd.drawString
					    ("The sentence must not contain bad language!",
					     275, 86);
					((Globe) this).rd
					    .setFont(new Font("Arial", 0, 12));
				    }
				    bool_4_ = true;
				    ((Globe) this).rd.drawLine(315, 123, 675,
							       123);
				    ((Globe) this).rd.drawString
					("The ( Racing VS Wasting ) is comparison between your multiplayer wins by",
					 275, 146);
				    ((Globe) this).rd.drawString
					("racing versus wasting.", 275, 166);
				    ((Globe) this).rd.drawString
					("It does not in anyway signify if you are better or worse than another player!",
					 275, 186);
				    ((Globe) this).rd.drawString
					("It simply shows whether you have a tendency to win games by racing or by",
					 275, 206);
				    ((Globe) this).rd.drawString
					("wasting, it shows what you are better at.",
					 275, 226);
				    ((Globe) this).rd.drawLine(315, 241, 675,
							       241);
				    ((Globe) this).rd.drawString
					("Upload your very own theme song!",
					 275, 264);
				    ((Globe) this).rd.drawString
					("The theme song must be a Module Track that is in a zip file and less than 700KB.",
					 275, 284);
				    ((Globe) this).rd.drawString
					("You can find lots of Module Tracks at modarchive.org.",
					 275, 304);
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (((Globe) this).uploadt == 0) {
					if (((Globe) this).msg.equals("")) {
					    if (!((Globe) this).themesong
						     .equals("")
						&& (((Globe) this).trackvol
						    != 0))
						((Globe) this).rd.drawString
						    (new StringBuilder().append
							 ("Current Track : ")
							 .append
							 (((Globe) this)
							  .themesong)
							 .append
							 ("").toString(),
						     (495
						      - (((Globe) this).ftm
							     .stringWidth
							 (new StringBuilder
							      ().append
							      ("Current Track : ")
							      .append
							      (((Globe) this)
							       .themesong)
							      .append
							      ("").toString
							  ())) / 2),
						     324);
					    else {
						((Globe) this).rd.setFont
						    (new Font("Arial", 0, 12));
						((Globe) this).rd.drawString
						    ("[ No theme song uploaded... ]",
						     (495
						      - ((((Globe) this)
							      .ftm.stringWidth
							  ("[ No theme song uploaded... ]"))
							 / 2)),
						     324);
					    }
					} else {
					    if (((Globe) this).flko % 4 != 0
						|| ((Globe) this).flko == 0)
						((Globe) this).rd.drawString
						    (((Globe) this).msg,
						     495 - (((Globe) this)
								.ftm
								.stringWidth
							    (((Globe) this)
							     .msg)) / 2,
						     324);
					    if (((Globe) this).flko != 0)
						((Globe) this).flko--;
					}
					if (stringbutton(((Globe) this).rd,
							 "  Upload Track  ",
							 495, 354, 0, i_1_,
							 i_2_, bool, 0, 0)) {
					    FileDialog filedialog
						= (new FileDialog
						   (new Frame(),
						    "Upload Track"));
					    filedialog.setMode(0);
					    filedialog.setFile("*.zip");
					    filedialog.setVisible(true);
					    ((Globe) this).filename
						= new StringBuilder().append
						      ("").append
						      (filedialog
							   .getDirectory())
						      .append
						      ("").append
						      (filedialog.getFile())
						      .append
						      ("").toString();
					    if (!((Globe) this).filename
						     .equals("nullnull")) {
						((Globe) this).trackname
						    = (filedialog.getFile()
							   .substring
						       (0, filedialog.getFile
							       ()
							       .length() - 4));
						((Globe) this).uploadt = 1;
					    }
					}
				    } else {
					if (((Globe) this).uploadt == 1)
					    ((Globe) this).rd.drawString
						("Checking MOD Track...",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Checking MOD Track..."))
						     / 2)),
						 354);
					if (((Globe) this).uploadt == 2)
					    ((Globe) this).rd.drawString
						("Authenticating...",
						 495 - ((((Globe) this).ftm
							     .stringWidth
							 ("Authenticating..."))
							/ 2),
						 354);
					if (((Globe) this).uploadt == 3)
					    ((Globe) this).rd.drawString
						("Uploading track, please wait...",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Uploading track, please wait..."))
						     / 2)),
						 354);
					if (((Globe) this).uploadt == 4)
					    ((Globe) this).rd.drawString
						("Adding track to your profile...",
						 (495
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("Adding track to your profile..."))
						     / 2)),
						 354);
					if (((Globe) this).uploadt == 5)
					    ((Globe) this).rd.drawString
						("Done",
						 (495
						  - (((Globe) this).ftm
							 .stringWidth("Done")
						     / 2)),
						 354);
				    }
				    ((Globe) this).rd.drawLine(315, 376, 675,
							       376);
				    if (stringbutton(((Globe) this).rd,
						     "        Done        ",
						     495, 407, 1, i_1_, i_2_,
						     bool, 0, 0)) {
					((Globe) this).edit = 0;
					if (((Globe) this).sentchange == 1) {
					    if ((((Globe) this).xt.msgcheck
						 (((Globe) this).sentance))
						|| ((((Globe) this)
							 .sentance.toLowerCase
							 ().indexOf
						     (((GameSparker)
						       ((Globe) this).gs)
							  .tpass.getText
							  ().toLowerCase()))
						    != -1)
						|| (((xtGraphics)
						     ((Globe) this).xt).acexp
						    == -3)) {
						((Globe) this).edit = 3;
						((Globe) this).sentchange = 0;
						((Globe) this).sentance = "";
						((GameSparker)
						 ((Globe) this).gs)
						    .cmsg.setText
						    (((Globe) this).sentance);
						((Globe) this).badlang = true;
					    } else
						((Globe) this).sentchange = 2;
					    trunsent();
					}
				    }
				}
				if (((Globe) this).edit == 5) {
				    ((Globe) this).rd
					.setColor(new Color(244, 232, 204));
				    ((Globe) this).rd.fillRoundRect(265, 187,
								    460, 125,
								    20, 20);
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawRoundRect(265, 187,
								    460, 125,
								    20, 20);
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.drawString
					("You need to upgrade your account to a full account to have a profile!",
					 (495
					  - ((((Globe) this).ftm.stringWidth
					      ("You need to upgrade your account to a full account to have a profile!"))
					     / 2)),
					 209);
				    ((Globe) this).rd
					.setColor(new Color(206, 171, 98));
				    ((Globe) this).rd.fillRoundRect(405, 222,
								    180, 50,
								    20, 20);
				    if (drawbutton(((xtGraphics)
						    ((Globe) this).xt).upgrade,
						   495, 247, i_1_, i_2_, bool))
					((Globe) this).gs.editlink
					    ((((xtGraphics) ((Globe) this).xt)
					      .nickname),
					     true);
				    if (stringbutton(((Globe) this).rd,
						     "  Cancel  ", 495, 297, 2,
						     i_1_, i_2_, bool, 0, 0))
					((Globe) this).edit = 0;
				}
			    } else
				((Globe) this).rd.drawString
				    ("Loading profile, please wait...",
				     (495
				      - ((((Globe) this).ftm.stringWidth
					  ("Loading profile, please wait..."))
					 / 2)),
				     222);
			}
		    } else {
			((Globe) this).edit = 0;
			((Globe) this).uploadt = 0;
			((Globe) this).sentchange = 0;
			((Globe) this).underc = 0;
			((Globe) this).protab = 0;
			if (((Smenu) ((GameSparker) ((Globe) this).gs).proitem)
			    .show) {
			    ((Smenu) ((GameSparker) ((Globe) this).gs).proitem)
				.show
				= false;
			    ((Globe) this).addstage = 0;
			}
		    }
		    if (((Globe) this).tab == 2)
			dotab2(i_1_, i_2_, bool);
		    else {
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.isShowing())
			    ((GameSparker) ((Globe) this).gs).sendtyp.hide();
			if (((GameSparker) ((Globe) this).gs).senditem
				.isShowing())
			    ((GameSparker) ((Globe) this).gs).senditem.hide();
			if (((GameSparker) ((Globe) this).gs).datat
				.isShowing())
			    ((GameSparker) ((Globe) this).gs).datat.hide();
			((GameSparker) ((Globe) this).gs).ilaps.hide();
			((GameSparker) ((Globe) this).gs).icars.hide();
			((GameSparker) ((Globe) this).gs).sclass.hide();
			((GameSparker) ((Globe) this).gs).sfix.hide();
		    }
		    if (((Globe) this).tab == 3)
			dotab3(i_1_, i_2_, bool);
		    else {
			if (((GameSparker) ((Globe) this).gs).clcars
				.isShowing())
			    ((GameSparker) ((Globe) this).gs).clcars.hide();
			if (((Globe) this).editc != 0) {
			    ((Globe) this).editc = 0;
			    if (((GameSparker) ((Globe) this).gs).clanlev
				    .isShowing())
				((GameSparker) ((Globe) this).gs).clanlev
				    .hide();
			}
			if (((Globe) this).cfase == 1)
			    ((Globe) this).cfase = 0;
		    }
		    if (((Globe) this).ptab == 0) {
			if (((Globe) this).npo != -1) {
			    ((Globe) this).sdist
				= (((Globe) this).npo - 7) * 50;
			    if (((Globe) this).sdist < 0)
				((Globe) this).sdist = 0;
			    ((Globe) this).scro
				= (int) ((float) ((Globe) this).spos / 345.0F
					 * (float) ((Globe) this).sdist);
			    for (int i_57_ = 0; i_57_ < ((Globe) this).npo;
				 i_57_++) {
				if (57 + 50 * i_57_ - ((Globe) this).scro > 0
				    && (57 + 50 * (i_57_ - 1)
					- ((Globe) this).scro) < 438) {
				    boolean bool_58_ = false;
				    if (i_1_ > 26 && i_1_ < 146
					&& i_2_ > (38 + 50 * i_57_
						   - ((Globe) this).scro)
					&& i_2_ < (68 + 50 * i_57_
						   - ((Globe) this).scro)
					&& !((Globe) this).onp
					&& ((Globe) this).overit == 0) {
					bool_58_ = true;
					((Globe) this).cur = 12;
					if (bool) {
					    ((Globe) this).tab = 1;
					    if (!((Globe) this).proname.equals
						 (((Globe) this).pname
						  [i_57_])) {
						((Globe) this).proname
						    = (((Globe) this).pname
						       [i_57_]);
						((Globe) this).loadedp = false;
						onexitpro();
					    }
					}
				    }
				    boolean bool_59_
					= drawl(((Globe) this).rd,
						((Globe) this).pname[i_57_],
						26,
						(38 + 50 * i_57_
						 - ((Globe) this).scro),
						bool_58_);
				    if (!bool_58_ || !bool_59_) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					((Globe) this).rd
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rd.drawString
					    (((Globe) this).pname[i_57_],
					     86 - (((Globe) this).ftm
						       .stringWidth
						   (((Globe) this).pname
						    [i_57_])) / 2,
					     (49 + 50 * i_57_
					      - ((Globe) this).scro));
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					String string = "Not in any room...";
					if (((Globe) this).pserver[i_57_] >= 0
					    && (((Globe) this).pserver[i_57_]
						<= 2)
					    && ((Globe) this).proom[i_57_] >= 0
					    && (((Globe) this).proom[i_57_]
						<= 4)) {
					    string = new StringBuilder().append
							 ("").append
							 (((Login)
							   ((Globe) this).lg)
							  .snames
							  [(((Globe) this)
							    .pserver[i_57_])])
							 .append
							 (" :: Room ").append
							 ((((Globe) this).proom
							   [i_57_]) + 1)
							 .append
							 ("").toString();
					    ((Globe) this).rd.setColor
						(new Color(49, 79, 0));
					}
					((Globe) this).rd.drawString
					    (string,
					     86 - ((Globe) this).ftm
						      .stringWidth(string) / 2,
					     (65 + 50 * i_57_
					      - ((Globe) this).scro));
				    }
				    ((Globe) this).rd
					.setColor(color2k(150, 150, 150));
				    ((Globe) this).rd.drawLine
					(5,
					 77 + 50 * i_57_ - ((Globe) this).scro,
					 167,
					 (77 + 50 * i_57_
					  - ((Globe) this).scro));
				}
			    }
			} else {
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Loading players...",
				 86 - (((Globe) this).ftm
					   .stringWidth("Loading players...")
				       / 2),
				 200);
			}
		    }
		    if (((Globe) this).ptab == 1) {
			if (((Globe) this).npf >= 0) {
			    ((Globe) this).sdist
				= (((Globe) this).npf - 7) * 50;
			    if (((Globe) this).sdist < 0)
				((Globe) this).sdist = 0;
			    ((Globe) this).scro
				= (int) ((float) ((Globe) this).spos / 345.0F
					 * (float) ((Globe) this).sdist);
			    int i_60_ = 0;
			    if (((Globe) this).npf != 0) {
				for (int i_61_ = 0; i_61_ < ((Globe) this).npf;
				     i_61_++) {
				    int i_62_ = -1;
				    for (int i_63_ = 0;
					 i_63_ < ((Globe) this).npo; i_63_++) {
					if (((Globe) this).pname[i_63_]
						.toLowerCase
						().equals
					    (((Globe) this).fname[i_61_]
						 .toLowerCase())) {
					    i_62_ = i_63_;
					    break;
					}
				    }
				    if (i_62_ != -1) {
					if ((57 + 50 * i_60_
					     - ((Globe) this).scro) > 0
					    && (57 + 50 * (i_60_ - 1)
						- ((Globe) this).scro) < 438) {
					    boolean bool_64_ = false;
					    if (i_1_ > 26 && i_1_ < 146
						&& (i_2_
						    > (38 + 50 * i_60_
						       - ((Globe) this).scro))
						&& (i_2_
						    < (68 + 50 * i_60_
						       - ((Globe) this).scro))
						&& !((Globe) this).onp
						&& ((Globe) this).overit == 0
						&& ((Globe) this).freq <= 0) {
						bool_64_ = true;
						((Globe) this).cur = 12;
						if (bool) {
						    ((Globe) this).tab = 1;
						    if (!((Globe) this)
							     .proname.equals
							 (((Globe) this).fname
							  [i_61_])) {
							((Globe) this).proname
							    = (((Globe) this)
							       .fname[i_61_]);
							((Globe) this).loadedp
							    = false;
							onexitpro();
						    }
						}
					    }
					    boolean bool_65_
						= drawl(((Globe) this).rd,
							(((Globe) this).fname
							 [i_61_]),
							26,
							(38 + 50 * i_60_
							 - (((Globe) this)
							    .scro)),
							bool_64_);
					    if (!bool_64_ || !bool_65_) {
						((Globe) this).rd.setFont
						    (new Font("Arial", 1, 12));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						((Globe) this).rd.setColor
						    (new Color(0, 0, 0));
						((Globe) this).rd.drawString
						    ((((Globe) this).fname
						      [i_61_]),
						     86 - ((((Globe) this)
								.ftm
								.stringWidth
							    (((Globe) this)
							     .fname[i_61_]))
							   / 2),
						     (49 + 50 * i_60_
						      - ((Globe) this).scro));
						((Globe) this).rd.setFont
						    (new Font("Arial", 1, 11));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						String string
						    = "Not in any room...";
						if ((((Globe) this).pserver
						     [i_62_]) >= 0
						    && (((Globe) this).pserver
							[i_62_]) <= 2
						    && (((Globe) this).proom
							[i_62_]) >= 0
						    && (((Globe) this).proom
							[i_62_]) <= 4) {
						    string
							= new StringBuilder
							      ().append
							      ("").append
							      (((Login)
								(((Globe) this)
								 .lg))
							       .snames
							       [(((Globe) this)
								 .pserver
								 [i_62_])])
							      .append
							      (" :: Room ")
							      .append
							      ((((Globe) this)
								.proom[i_62_])
							       + 1)
							      .append
							      ("").toString();
						    ((Globe) this).rd.setColor
							(new Color(49, 79, 0));
						}
						((Globe) this).rd.drawString
						    (string,
						     86 - (((Globe) this)
							       .ftm.stringWidth
							   (string)) / 2,
						     (65 + 50 * i_60_
						      - ((Globe) this).scro));
					    }
					    ((Globe) this).rd.setColor
						(color2k(150, 150, 150));
					    ((Globe) this).rd.drawLine
						(5,
						 (77 + 50 * i_60_
						  - ((Globe) this).scro),
						 167,
						 (77 + 50 * i_60_
						  - ((Globe) this).scro));
					}
					i_60_++;
				    }
				}
				for (int i_66_ = 0; i_66_ < ((Globe) this).npf;
				     i_66_++) {
				    int i_67_ = -1;
				    for (int i_68_ = 0;
					 i_68_ < ((Globe) this).npo; i_68_++) {
					if (((Globe) this).pname[i_68_]
						.toLowerCase
						().equals
					    (((Globe) this).fname[i_66_]
						 .toLowerCase())) {
					    i_67_ = i_68_;
					    break;
					}
				    }
				    if (i_67_ == -1) {
					if ((57 + 50 * i_60_
					     - ((Globe) this).scro) > 0
					    && (57 + 50 * (i_60_ - 1)
						- ((Globe) this).scro) < 438) {
					    boolean bool_69_ = false;
					    if (i_1_ > 26 && i_1_ < 146
						&& (i_2_
						    > (38 + 50 * i_60_
						       - ((Globe) this).scro))
						&& (i_2_
						    < (68 + 50 * i_60_
						       - ((Globe) this).scro))
						&& !((Globe) this).onp
						&& ((Globe) this).overit == 0
						&& ((Globe) this).freq <= 0) {
						bool_69_ = true;
						((Globe) this).cur = 12;
						if (bool) {
						    ((Globe) this).tab = 1;
						    if (!((Globe) this)
							     .proname.equals
							 (((Globe) this).fname
							  [i_66_])) {
							((Globe) this).proname
							    = (((Globe) this)
							       .fname[i_66_]);
							((Globe) this).loadedp
							    = false;
							onexitpro();
						    }
						}
					    }
					    boolean bool_70_
						= drawl(((Globe) this).rd,
							(((Globe) this).fname
							 [i_66_]),
							26,
							(38 + 50 * i_60_
							 - (((Globe) this)
							    .scro)),
							bool_69_);
					    if (!bool_69_ || !bool_70_) {
						((Globe) this).rd.setFont
						    (new Font("Arial", 1, 12));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						((Globe) this).rd.setColor
						    (new Color(0, 0, 0));
						((Globe) this).rd.drawString
						    ((((Globe) this).fname
						      [i_66_]),
						     86 - ((((Globe) this)
								.ftm
								.stringWidth
							    (((Globe) this)
							     .fname[i_66_]))
							   / 2),
						     (49 + 50 * i_60_
						      - ((Globe) this).scro));
						((Globe) this).rd.setFont
						    (new Font("Arial", 0, 11));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						String string
						    = "Player Offline";
						((Globe) this).rd.drawString
						    (string,
						     86 - (((Globe) this)
							       .ftm.stringWidth
							   (string)) / 2,
						     (65 + 50 * i_60_
						      - ((Globe) this).scro));
					    }
					    ((Globe) this).rd.setColor
						(color2k(150, 150, 150));
					    ((Globe) this).rd.drawLine
						(5,
						 (77 + 50 * i_60_
						  - ((Globe) this).scro),
						 167,
						 (77 + 50 * i_60_
						  - ((Globe) this).scro));
					}
					i_60_++;
				    }
				}
			    } else {
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("No friends added yet.",
				     86 - (((Globe) this).ftm.stringWidth
					   ("No friends added yet.")) / 2,
				     200);
			    }
			    if (((Globe) this).freq == 1) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200, 130);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200, 130);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Friend request from:",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Friend request from:")) / 2,
				     45);
				((Globe) this).rd.setColor(new Color(240, 222,
								     164));
				((Globe) this).rd.fillRect(26, 51, 119, 29);
				if (!drawl(((Globe) this).rd,
					   ((Globe) this).freqname, 26, 51,
					   true)) {
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					(((Globe) this).freqname,
					 86 - (((Globe) this).ftm.stringWidth
					       (((Globe) this).freqname)) / 2,
					 70);
				    ((Globe) this).rd
					.setColor(color2k(150, 150, 150));
				    ((Globe) this).rd.drawRect(26, 51, 119,
							       29);
				}
				if (i_1_ > 26 && i_1_ < 146 && i_2_ > 51
				    && i_2_ < 81) {
				    ((Globe) this).cur = 12;
				    if (bool) {
					((Globe) this).tab = 1;
					if (!((Globe) this).proname.equals
					     (((Globe) this).freqname)) {
					    ((Globe) this).proname
						= ((Globe) this).freqname;
					    ((Globe) this).loadedp = false;
					    onexitpro();
					}
				    }
				}
				if (stringbutton(((Globe) this).rd,
						 "    Confirm    ", 86, 107, 0,
						 i_1_, i_2_, bool, 0, 0))
				    ((Globe) this).freq = 2;
				if (stringbutton(((Globe) this).rd, "Cancel",
						 86, 140, 2, i_1_, i_2_, bool,
						 0, 0))
				    ((Globe) this).freq = 3;
			    }
			    if (((Globe) this).freq == -1) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200, 25);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200, 25);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Failed to confirm friend!",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Failed to confirm friend!")) / 2,
				     45);
				((Globe) this).cntf--;
				if (((Globe) this).cntf <= 0)
				    ((Globe) this).freq = 0;
			    }
			    if (((Globe) this).freq == -2) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200, 25);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200, 25);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Failed to cancel request!",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Failed to cancel request!")) / 2,
				     45);
				((Globe) this).cntf--;
				if (((Globe) this).cntf <= 0)
				    ((Globe) this).freq = 0;
			    }
			    if (((Globe) this).freq == 2) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200, 25);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200, 25);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Confirming friend...",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Confirming friend...")) / 2,
				     45);
			    }
			    if (((Globe) this).freq == 3) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200, 25);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200, 25);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Canceling...",
				     86 - ((Globe) this).ftm
					      .stringWidth("Canceling...") / 2,
				     45);
			    }
			    if (((Globe) this).freq == 6) {
				((Globe) this).rd.setColor(new Color(236, 215,
								     140));
				((Globe) this).rd.fillRect(-10, 28, 200,
							   61 + (((Globe) this)
								 .ncnf) * 35);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawRect(-10, 28, 200,
							   61 + (((Globe) this)
								 .ncnf) * 35);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Friend Confirmation(s):",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Friend Confirmation(s):")) / 2,
				     45);
				for (int i_71_ = 0;
				     i_71_ < ((Globe) this).ncnf; i_71_++) {
				    ((Globe) this).rd
					.setColor(new Color(240, 222, 164));
				    ((Globe) this).rd.fillRect(26,
							       51 + 35 * i_71_,
							       119, 29);
				    if (!drawl(((Globe) this).rd,
					       ((Globe) this).cnfname[i_71_],
					       26, 51 + 35 * i_71_, true)) {
					((Globe) this).rd
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rd.drawString
					    (((Globe) this).cnfname[i_71_],
					     86 - (((Globe) this).ftm
						       .stringWidth
						   (((Globe) this).cnfname
						    [i_71_])) / 2,
					     70 + 35 * i_71_);
					((Globe) this).rd
					    .setColor(color2k(150, 150, 150));
					((Globe) this).rd.drawRect
					    (26, 51 + 35 * i_71_, 119, 29);
				    }
				    if (i_1_ > 26 && i_1_ < 146
					&& i_2_ > 51 + 35 * i_71_
					&& i_2_ < 81 + 35 * i_71_) {
					((Globe) this).cur = 12;
					if (bool) {
					    ((Globe) this).tab = 1;
					    if (!((Globe) this).proname.equals
						 (((Globe) this).cnfname
						  [i_71_])) {
						((Globe) this).proname
						    = (((Globe) this).cnfname
						       [i_71_]);
						((Globe) this).loadedp = false;
						onexitpro();
					    }
					}
				    }
				}
				if (stringbutton(((Globe) this).rd, "  OK  ",
						 86,
						 (107
						  + 35 * (((Globe) this).ncnf
							  - 1)),
						 0, i_1_, i_2_, bool, 0, 0))
				    ((Globe) this).freq = -6;
			    }
			} else {
			    if (((Globe) this).npf == -1) {
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Loading friends...",
				     (86
				      - (((Globe) this).ftm
					     .stringWidth("Loading friends...")
					 / 2)),
				     200);
			    }
			    if (((Globe) this).npf == -2) {
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    ("Failed to load friends!",
				     86 - (((Globe) this).ftm.stringWidth
					   ("Failed to load friends!")) / 2,
				     200);
			    }
			}
		    }
		    if (((Globe) this).ptab == 2) {
			if (((xtGraphics) ((Globe) this).xt).clan.equals("")) {
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Not in a Clan",
				 86 - ((Globe) this).ftm
					  .stringWidth("Not in a Clan") / 2,
				 200);
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("You haven't joined and clan yet.",
				 86 - ((((Globe) this).ftm.stringWidth
					("You haven't joined and clan yet."))
				       / 2),
				 220);
			} else if (((Globe) this).loadedcm) {
			    ((Globe) this).sdist
				= (((Globe) this).ncln - 7) * 50;
			    if (((Globe) this).sdist < 0)
				((Globe) this).sdist = 0;
			    ((Globe) this).scro
				= (int) ((float) ((Globe) this).spos / 345.0F
					 * (float) ((Globe) this).sdist);
			    int i_72_ = 0;
			    for (int i_73_ = 0; i_73_ < ((Globe) this).ncln;
				 i_73_++) {
				int i_74_ = -1;
				for (int i_75_ = 0; i_75_ < ((Globe) this).npo;
				     i_75_++) {
				    if (((Globe) this).pname[i_75_].toLowerCase
					    ().equals
					(((Globe) this).clname[i_73_]
					     .toLowerCase())) {
					i_74_ = i_75_;
					break;
				    }
				}
				if (i_74_ != -1) {
				    if ((57 + 50 * i_72_ - ((Globe) this).scro
					 > 0)
					&& (57 + 50 * (i_72_ - 1)
					    - ((Globe) this).scro) < 438) {
					boolean bool_76_ = false;
					if (i_1_ > 26 && i_1_ < 146
					    && i_2_ > (38 + 50 * i_72_
						       - ((Globe) this).scro)
					    && i_2_ < (68 + 50 * i_72_
						       - ((Globe) this).scro)
					    && !((Globe) this).onp
					    && ((Globe) this).overit == 0
					    && ((Globe) this).freq <= 0) {
					    bool_76_ = true;
					    ((Globe) this).cur = 12;
					    if (bool) {
						((Globe) this).tab = 1;
						if (!((Globe) this).proname
							 .equals
						     (((Globe) this).clname
						      [i_73_])) {
						    ((Globe) this).proname
							= (((Globe) this)
							   .clname[i_73_]);
						    ((Globe) this).loadedp
							= false;
						    onexitpro();
						}
					    }
					}
					boolean bool_77_
					    = drawl(((Globe) this).rd,
						    (((Globe) this).clname
						     [i_73_]),
						    26,
						    (38 + 50 * i_72_
						     - ((Globe) this).scro),
						    bool_76_);
					if (!bool_76_ || !bool_77_) {
					    ((Globe) this).rd.setFont
						(new Font("Arial", 1, 12));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    ((Globe) this).rd
						.setColor(new Color(0, 0, 0));
					    ((Globe) this).rd.drawString
						(((Globe) this).clname[i_73_],
						 86 - (((Globe) this).ftm
							   .stringWidth
						       (((Globe) this).clname
							[i_73_])) / 2,
						 (49 + 50 * i_72_
						  - ((Globe) this).scro));
					    ((Globe) this).rd.setFont
						(new Font("Arial", 1, 11));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    String string
						= "Not in any room...";
					    if ((((Globe) this).pserver[i_74_]
						 >= 0)
						&& (((Globe) this).pserver
						    [i_74_]) <= 2
						&& (((Globe) this).proom[i_74_]
						    >= 0)
						&& (((Globe) this).proom[i_74_]
						    <= 4)) {
						string
						    = new StringBuilder()
							  .append
							  ("").append
							  (((Login)
							    ((Globe) this).lg)
							   .snames
							   [(((Globe) this)
							     .pserver[i_74_])])
							  .append
							  (" :: Room ").append
							  ((((Globe) this)
							    .proom[i_74_]) + 1)
							  .append
							  ("").toString();
						((Globe) this).rd.setColor
						    (new Color(49, 79, 0));
					    }
					    ((Globe) this).rd.drawString
						(string,
						 86 - (((Globe) this).ftm
							   .stringWidth(string)
						       / 2),
						 (65 + 50 * i_72_
						  - ((Globe) this).scro));
					}
					((Globe) this).rd
					    .setColor(color2k(150, 150, 150));
					((Globe) this).rd.drawLine
					    (5,
					     (77 + 50 * i_72_
					      - ((Globe) this).scro),
					     167,
					     (77 + 50 * i_72_
					      - ((Globe) this).scro));
				    }
				    i_72_++;
				}
			    }
			    for (int i_78_ = 0; i_78_ < ((Globe) this).ncln;
				 i_78_++) {
				int i_79_ = -1;
				for (int i_80_ = 0; i_80_ < ((Globe) this).npo;
				     i_80_++) {
				    if (((Globe) this).pname[i_80_].toLowerCase
					    ().equals
					(((Globe) this).clname[i_78_]
					     .toLowerCase())) {
					i_79_ = i_80_;
					break;
				    }
				}
				if (i_79_ == -1) {
				    if ((57 + 50 * i_72_ - ((Globe) this).scro
					 > 0)
					&& (57 + 50 * (i_72_ - 1)
					    - ((Globe) this).scro) < 438) {
					boolean bool_81_ = false;
					if (i_1_ > 26 && i_1_ < 146
					    && i_2_ > (38 + 50 * i_72_
						       - ((Globe) this).scro)
					    && i_2_ < (68 + 50 * i_72_
						       - ((Globe) this).scro)
					    && !((Globe) this).onp
					    && ((Globe) this).overit == 0
					    && ((Globe) this).freq <= 0) {
					    bool_81_ = true;
					    ((Globe) this).cur = 12;
					    if (bool) {
						((Globe) this).tab = 1;
						if (!((Globe) this).proname
							 .equals
						     (((Globe) this).clname
						      [i_78_])) {
						    ((Globe) this).proname
							= (((Globe) this)
							   .clname[i_78_]);
						    ((Globe) this).loadedp
							= false;
						    onexitpro();
						}
					    }
					}
					boolean bool_82_
					    = drawl(((Globe) this).rd,
						    (((Globe) this).clname
						     [i_78_]),
						    26,
						    (38 + 50 * i_72_
						     - ((Globe) this).scro),
						    bool_81_);
					if (!bool_81_ || !bool_82_) {
					    ((Globe) this).rd.setFont
						(new Font("Arial", 1, 12));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    ((Globe) this).rd
						.setColor(new Color(0, 0, 0));
					    ((Globe) this).rd.drawString
						(((Globe) this).clname[i_78_],
						 86 - (((Globe) this).ftm
							   .stringWidth
						       (((Globe) this).clname
							[i_78_])) / 2,
						 (49 + 50 * i_72_
						  - ((Globe) this).scro));
					    ((Globe) this).rd.setFont
						(new Font("Arial", 0, 11));
					    ((Globe) this).ftm
						= ((Globe) this).rd
						      .getFontMetrics();
					    String string = "Player Offline";
					    ((Globe) this).rd.drawString
						(string,
						 86 - (((Globe) this).ftm
							   .stringWidth(string)
						       / 2),
						 (65 + 50 * i_72_
						  - ((Globe) this).scro));
					}
					((Globe) this).rd
					    .setColor(color2k(150, 150, 150));
					((Globe) this).rd.drawLine
					    (5,
					     (77 + 50 * i_72_
					      - ((Globe) this).scro),
					     167,
					     (77 + 50 * i_72_
					      - ((Globe) this).scro));
				    }
				    i_72_++;
				}
			    }
			} else {
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Loading clan mates...",
				 (86
				  - (((Globe) this).ftm
					 .stringWidth("Loading clan mates...")
				     / 2)),
				 200);
			}
		    }
		} else if (((Globe) this).open == 452) {
		    ((Globe) this).rd.setColor(color2k(230, 230, 230));
		    ((Globe) this).rd.fillRoundRect(240, 170, 511, 90, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(240, 170, 511, 90, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Failed to connect to server at this time, please exit and try again later.",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to connect to server at this time, please exit and try again later."))
			     / 2)),
			 200);
		    if (stringbutton(((Globe) this).rd, "  Exit  ", 495, 230,
				     1, i_1_, i_2_, bool, 0, 0)) {
			((Globe) this).open = 450;
			((Globe) this).upo = false;
			((Globe) this).domon = false;
		    }
		}
		int[] is = { 193, 193, 295, 318 };
		int[] is_83_ = { 33, 10, 10, 33 };
		for (int i_84_ = 0; i_84_ < 4; i_84_++) {
		    boolean bool_85_ = false;
		    if (((Globe) this).tab == 3 && i_84_ == 0)
			bool_85_ = true;
		    if (((Globe) this).tab == 1 && i_84_ == 1)
			bool_85_ = true;
		    if (((Globe) this).tab == 2 && i_84_ == 2)
			bool_85_ = true;
		    if (((Globe) this).tab == 0 && i_84_ == 3)
			bool_85_ = true;
		    ((Globe) this).rd.setColor(new Color(255, 255, 255));
		    if (bool_85_)
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 0.6F));
		    else
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 0.2F));
		    if (i_2_ >= 12 && i_2_ <= 32 && i_1_ > is[0]
			&& i_1_ < is[3]) {
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 0.4F));
			if (bool && !((GameSparker) ((Globe) this).gs).openm) {
			    if (i_84_ == 0)
				((Globe) this).tab = 3;
			    if (i_84_ == 1 || i_84_ == 2)
				((Globe) this).tab = i_84_;
			    if (i_84_ == 3)
				((Globe) this).tab = 0;
			    if (((Globe) this).tab == 1
				&& ((Globe) this).proname.equals("")) {
				((Globe) this).proname
				    = (((xtGraphics) ((Globe) this).xt)
				       .nickname);
				((Globe) this).loadedp = false;
				onexitpro();
			    }
			}
		    }
		    ((Globe) this).rd.fillPolygon(is, is_83_, 4);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawPolygon(is, is_83_, 4);
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    if (i_84_ == 0) {
			is_83_[1] = 13;
			is_83_[2] = 13;
			is[2] = 298;
		    }
		    for (int i_86_ = 0; i_86_ < 4; i_86_++)
			is[i_86_] += 125;
		}
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .cnmc),
					    224, 15, null);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawLine(191, 34, 800, 34);
		((Globe) this).rd.setColor(color2k(200, 200, 200));
		((Globe) this).rd.fillRect(0, 0, 190, 28);
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawLine(0, 25, 170, 25);
		((Globe) this).rd.setColor(color2k(200, 200, 200));
		((Globe) this).rd.fillRect(0, 438, 190, 12);
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawLine(0, 440, 170, 440);
		((Globe) this).rd.setColor(color2k(200, 200, 200));
		((Globe) this).rd.fillRect(173, 28, 17, 410);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawLine(191, 0, 191, 450);
		if (i_1_ > 0 && i_1_ < 171 && i_2_ > 2 && i_2_ < 23) {
		    if (!((Globe) this).onp) {
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fillRect(2, 2, 146, 21);
		    }
		    ((Globe) this).rd.setColor(color2k(255, 255, 255));
		    if (bool && ((Globe) this).overit == 0
			&& !((Globe) this).onp) {
			((Globe) this).onp = true;
			((Globe) this).overit = 5;
		    }
		} else
		    ((Globe) this).rd.setColor(color2k(235, 235, 235));
		if (((Globe) this).overit < 0)
		    ((Globe) this).overit++;
		((Globe) this).rd.fillRect(150, 2, 20, 20);
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawRect(150, 2, 20, 20);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawLine(157, 10, 157, 11);
		((Globe) this).rd.drawLine(158, 11, 158, 12);
		((Globe) this).rd.drawLine(159, 12, 159, 13);
		((Globe) this).rd.drawLine(160, 13, 160, 14);
		((Globe) this).rd.drawLine(161, 12, 161, 13);
		((Globe) this).rd.drawLine(162, 11, 162, 12);
		((Globe) this).rd.drawLine(163, 10, 163, 11);
		if (((Globe) this).ptab == 0)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).players,
						7, 5, null);
		if (((Globe) this).ptab == 1)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).myfr,
						21, 4, null);
		if (((Globe) this).ptab == 2)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).mycl,
						34, 4, null);
		if (((Globe) this).onp) {
		    ((Globe) this).rd.setColor(color2k(200, 200, 200));
		    ((Globe) this).rd.fillRect(0, 25, 170, 67);
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawRect(0, 25, 170, 67);
		    if (i_1_ > 0 && i_1_ < 171 && i_2_ >= 26 && i_2_ < 48) {
			((Globe) this).rd.setColor(color2k(235, 235, 235));
			((Globe) this).rd.fillRect(1, 26, 169, 22);
			if (bool)
			    ((Globe) this).ptab = 0;
		    }
		    if (i_1_ > 0 && i_1_ < 171 && i_2_ >= 48 && i_2_ < 70) {
			((Globe) this).rd.setColor(color2k(235, 235, 235));
			((Globe) this).rd.fillRect(1, 48, 169, 22);
			if (bool) {
			    ((Globe) this).ptab = 1;
			    ((Globe) this).npf = -1;
			}
		    }
		    if (i_1_ > 0 && i_1_ < 171 && i_2_ >= 70 && i_2_ < 92) {
			((Globe) this).rd.setColor(color2k(235, 235, 235));
			((Globe) this).rd.fillRect(1, 70, 169, 22);
			if (bool)
			    ((Globe) this).ptab = 2;
		    }
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).players,
						7, 30, null);
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).myfr,
						21, 51, null);
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).mycl,
						34, 73, null);
		    if (bool && ((Globe) this).overit == 0) {
			((Globe) this).onp = false;
			((Globe) this).overit = -5;
		    }
		    if (((Globe) this).overit > 0)
			((Globe) this).overit--;
		}
		if (((Globe) this).mscro == 831 || ((Globe) this).sdist == 0) {
		    if (((Globe) this).sdist == 0)
			((Globe) this).rd.setColor(color2k(205, 205, 205));
		    else
			((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fillRect(173, 28, 17, 17);
		} else {
		    ((Globe) this).rd.setColor(color2k(220, 220, 220));
		    ((Globe) this).rd.fill3DRect(173, 28, 17, 17, true);
		}
		if (((Globe) this).sdist != 0)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).asu,
						178, 34, null);
		if (((Globe) this).mscro == 832 || ((Globe) this).sdist == 0) {
		    if (((Globe) this).sdist == 0)
			((Globe) this).rd.setColor(color2k(205, 205, 205));
		    else
			((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fillRect(173, 421, 17, 17);
		} else {
		    ((Globe) this).rd.setColor(color2k(220, 220, 220));
		    ((Globe) this).rd.fill3DRect(173, 421, 17, 17, true);
		}
		if (((Globe) this).sdist != 0)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).asd,
						178, 428, null);
		if (((Globe) this).sdist != 0) {
		    if (((Globe) this).lspos != ((Globe) this).spos) {
			((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd
			    .fillRect(173, 45 + ((Globe) this).spos, 17, 31);
		    } else {
			if (((Globe) this).mscro == 831)
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fill3DRect(173,
						     45 + ((Globe) this).spos,
						     17, 31, true);
		    }
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(178, 58 + ((Globe) this).spos,
					       184, 58 + ((Globe) this).spos);
		    ((Globe) this).rd.drawLine(178, 60 + ((Globe) this).spos,
					       184, 60 + ((Globe) this).spos);
		    ((Globe) this).rd.drawLine(178, 62 + ((Globe) this).spos,
					       184, 62 + ((Globe) this).spos);
		    if (((Globe) this).mscro > 800
			&& ((Globe) this).lspos != ((Globe) this).spos)
			((Globe) this).lspos = ((Globe) this).spos;
		    if (bool) {
			if (((Globe) this).mscro == 825 && i_1_ > 173
			    && i_1_ < 190 && i_2_ > 45 + ((Globe) this).spos
			    && i_2_ < ((Globe) this).spos + 76)
			    ((Globe) this).mscro = i_2_ - ((Globe) this).spos;
			if (((Globe) this).mscro == 825 && i_1_ > 171
			    && i_1_ < 192 && i_2_ > 26 && i_2_ < 47)
			    ((Globe) this).mscro = 831;
			if (((Globe) this).mscro == 825 && i_1_ > 171
			    && i_1_ < 192 && i_2_ > 419 && i_2_ < 440)
			    ((Globe) this).mscro = 832;
			if (((Globe) this).mscro == 825 && i_1_ > 173
			    && i_1_ < 190 && i_2_ > 45 && i_2_ < 421) {
			    ((Globe) this).mscro = 60;
			    ((Globe) this).spos = i_2_ - ((Globe) this).mscro;
			}
			int i_87_ = 2670 / ((Globe) this).sdist;
			if (i_87_ < 1)
			    i_87_ = 1;
			if (((Globe) this).mscro == 831) {
			    ((Globe) this).spos -= i_87_;
			    if (((Globe) this).spos > 345)
				((Globe) this).spos = 345;
			    if (((Globe) this).spos < 0)
				((Globe) this).spos = 0;
			    ((Globe) this).lspos = ((Globe) this).spos;
			}
			if (((Globe) this).mscro == 832) {
			    ((Globe) this).spos += i_87_;
			    if (((Globe) this).spos > 345)
				((Globe) this).spos = 345;
			    if (((Globe) this).spos < 0)
				((Globe) this).spos = 0;
			    ((Globe) this).lspos = ((Globe) this).spos;
			}
			if (((Globe) this).mscro < 800) {
			    ((Globe) this).spos = i_2_ - ((Globe) this).mscro;
			    if (((Globe) this).spos > 345)
				((Globe) this).spos = 345;
			    if (((Globe) this).spos < 0)
				((Globe) this).spos = 0;
			}
			if (((Globe) this).mscro == 825)
			    ((Globe) this).mscro = 925;
		    } else if (((Globe) this).mscro != 825)
			((Globe) this).mscro = 825;
		}
		if (((Globe) this).cur != ((Globe) this).curs) {
		    ((Globe) this).gs
			.setCursor(new Cursor(((Globe) this).cur));
		    ((Globe) this).curs = ((Globe) this).cur;
		}
	    } else {
		((Globe) this).xt.drawWarning();
		if (((GameSparker) ((Globe) this).gs).cmsg.isShowing()) {
		    ((GameSparker) ((Globe) this).gs).cmsg.hide();
		    ((Globe) this).gs.requestFocus();
		}
		if (((xtGraphics) ((Globe) this).xt).warning > 220) {
		    boolean bool_88_ = false;
		    try {
			((Globe) this).socket.close();
			((Globe) this).socket = null;
			((Globe) this).din.close();
			((Globe) this).din = null;
			((Globe) this).dout.close();
			((Globe) this).dout = null;
		    } catch (Exception exception) {
			/* empty */
		    }
		}
		((xtGraphics) ((Globe) this).xt).warning++;
	    }
	}
	if (bool_3_) {
	    ((Globe) this).gs.movefieldd((((GameSparker) ((Globe) this).gs)
					  .cmsg),
					 207, 414, 462, 22, true);
	    if (((GameSparker) ((Globe) this).gs).cmsg.getText()
		    .equals("Type here...")
		&& i_1_ > 197 && i_1_ < 679 && i_2_ > 404 && i_2_ < 446)
		((GameSparker) ((Globe) this).gs).cmsg.setText("");
	    if (((GameSparker) ((Globe) this).gs).cmsg.getText().length()
		> 200) {
		((GameSparker) ((Globe) this).gs).cmsg.setText
		    (((GameSparker) ((Globe) this).gs).cmsg.getText()
			 .substring(0, 200));
		((GameSparker) ((Globe) this).gs).cmsg.select(200, 200);
	    }
	}
	if (bool_4_) {
	    if (!((GameSparker) ((Globe) this).gs).cmsg.isShowing()) {
		((GameSparker) ((Globe) this).gs).cmsg.show();
		((GameSparker) ((Globe) this).gs).cmsg
		    .setText(((Globe) this).sentance);
		((GameSparker) ((Globe) this).gs).cmsg.requestFocus();
	    }
	    ((Globe) this).gs.movefield(((GameSparker) ((Globe) this).gs).cmsg,
					275, 91, 440, 22);
	    if (!((Globe) this).sentance.equals(((GameSparker)
						 ((Globe) this).gs)
						    .cmsg.getText())) {
		((Globe) this).sentchange = 1;
		((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		if (((Globe) this).ftm.stringWidth(((GameSparker)
						    ((Globe) this).gs)
						       .cmsg.getText())
		    > 800)
		    ((GameSparker) ((Globe) this).gs).cmsg
			.setText(((Globe) this).sentance);
		else
		    ((Globe) this).sentance
			= ((GameSparker) ((Globe) this).gs).cmsg.getText();
	    }
	}
	if (((Globe) this).dorank) {
	    if (!((GameSparker) ((Globe) this).gs).cmsg.isShowing()) {
		((GameSparker) ((Globe) this).gs).cmsg.show();
		((GameSparker) ((Globe) this).gs).cmsg
		    .setText(((Globe) this).mrank[((Globe) this).em]);
		((GameSparker) ((Globe) this).gs).cmsg.requestFocus();
	    }
	    ((Globe) this).gs.movefield(((GameSparker) ((Globe) this).gs).cmsg,
					402, 131, 300, 22);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 11));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ftm.stringWidth(((GameSparker)
						((Globe) this).gs)
						   .cmsg.getText())
		> 270) {
		int i_89_ = (((GameSparker) ((Globe) this).gs).cmsg.getText
				 ().length()
			     - 1);
		if (i_89_ < 0)
		    i_89_ = 0;
		((GameSparker) ((Globe) this).gs).cmsg.setText
		    (((GameSparker) ((Globe) this).gs).cmsg.getText()
			 .substring(0, i_89_));
		((GameSparker) ((Globe) this).gs).cmsg.select(i_89_, i_89_);
	    }
	}
	if (((Globe) this).donewc) {
	    if (!((GameSparker) ((Globe) this).gs).temail.isShowing()) {
		((GameSparker) ((Globe) this).gs).temail.show();
		((GameSparker) ((Globe) this).gs).temail.setText("");
		((GameSparker) ((Globe) this).gs).temail.requestFocus();
	    }
	    ((Globe) this).gs.movefield((((GameSparker) ((Globe) this).gs)
					 .temail),
					473, 141, 150, 22);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ftm.stringWidth(((GameSparker)
						((Globe) this).gs)
						   .temail.getText())
		> 150) {
		int i_90_ = (((GameSparker) ((Globe) this).gs).temail.getText
				 ().length()
			     - 1);
		if (i_90_ < 0)
		    i_90_ = 0;
		((GameSparker) ((Globe) this).gs).temail.setText
		    (((GameSparker) ((Globe) this).gs).temail.getText()
			 .substring(0, i_90_));
		((GameSparker) ((Globe) this).gs).temail.select(i_90_, i_90_);
	    }
	    if (!((GameSparker) ((Globe) this).gs).temail.getText()
		     .equals(((Globe) this).lccnam)) {
		((Globe) this).lg
		    .fixtext(((GameSparker) ((Globe) this).gs).temail);
		((Globe) this).lccnam
		    = ((GameSparker) ((Globe) this).gs).temail.getText();
	    }
	    if (((Globe) this).xt.msgcheck(((GameSparker) ((Globe) this).gs)
					       .temail.getText()))
		((GameSparker) ((Globe) this).gs).temail.setText("");
	}
	if (((Globe) this).dosrch) {
	    if (!((GameSparker) ((Globe) this).gs).temail.isShowing()) {
		((GameSparker) ((Globe) this).gs).temail.show();
		((GameSparker) ((Globe) this).gs).temail.setText("");
		((GameSparker) ((Globe) this).gs).temail.requestFocus();
	    }
	    ((Globe) this).gs.movefield((((GameSparker) ((Globe) this).gs)
					 .temail),
					371, 88, 150, 22);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ftm.stringWidth(((GameSparker)
						((Globe) this).gs)
						   .temail.getText())
		> 150) {
		int i_91_ = (((GameSparker) ((Globe) this).gs).temail.getText
				 ().length()
			     - 1);
		if (i_91_ < 0)
		    i_91_ = 0;
		((GameSparker) ((Globe) this).gs).temail.setText
		    (((GameSparker) ((Globe) this).gs).temail.getText()
			 .substring(0, i_91_));
		((GameSparker) ((Globe) this).gs).temail.select(i_91_, i_91_);
	    }
	    if (!((GameSparker) ((Globe) this).gs).temail.getText()
		     .equals(((Globe) this).lccnam)) {
		((Globe) this).lg
		    .fixtext(((GameSparker) ((Globe) this).gs).temail);
		((Globe) this).lccnam
		    = ((GameSparker) ((Globe) this).gs).temail.getText();
	    }
	    if (((Globe) this).xt.msgcheck(((GameSparker) ((Globe) this).gs)
					       .temail.getText()))
		((GameSparker) ((Globe) this).gs).temail.setText("");
	}
	if (((Globe) this).doweb1) {
	    if (!((GameSparker) ((Globe) this).gs).temail.isShowing()) {
		((GameSparker) ((Globe) this).gs).temail.show();
		((GameSparker) ((Globe) this).gs).temail
		    .setText(((Globe) this).ltit);
		((GameSparker) ((Globe) this).gs).temail.requestFocus();
	    }
	    ((Globe) this).gs.movefield((((GameSparker) ((Globe) this).gs)
					 .temail),
					411, 174, 150, 22);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ftm.stringWidth(((GameSparker)
						((Globe) this).gs)
						   .temail.getText())
		> 200) {
		int i_92_ = (((GameSparker) ((Globe) this).gs).temail.getText
				 ().length()
			     - 1);
		if (i_92_ < 0)
		    i_92_ = 0;
		((GameSparker) ((Globe) this).gs).temail.setText
		    (((GameSparker) ((Globe) this).gs).temail.getText()
			 .substring(0, i_92_));
		((GameSparker) ((Globe) this).gs).temail.select(i_92_, i_92_);
	    }
	    if (((Globe) this).xt.msgcheck(((GameSparker) ((Globe) this).gs)
					       .temail.getText()))
		((GameSparker) ((Globe) this).gs).temail.setText("");
	    if (!((GameSparker) ((Globe) this).gs).cmsg.isShowing()) {
		((GameSparker) ((Globe) this).gs).cmsg.show();
		((GameSparker) ((Globe) this).gs).cmsg
		    .setText(((Globe) this).ldes);
	    }
	    ((Globe) this).gs.movefield(((GameSparker) ((Globe) this).gs).cmsg,
					411, 204, 300, 22);
	    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ftm.stringWidth(((GameSparker)
						((Globe) this).gs)
						   .cmsg.getText())
		> 400) {
		int i_93_ = (((GameSparker) ((Globe) this).gs).cmsg.getText
				 ().length()
			     - 1);
		if (i_93_ < 0)
		    i_93_ = 0;
		((GameSparker) ((Globe) this).gs).cmsg.setText
		    (((GameSparker) ((Globe) this).gs).cmsg.getText()
			 .substring(0, i_93_));
		((GameSparker) ((Globe) this).gs).cmsg.select(i_93_, i_93_);
	    }
	    if (((Globe) this).xt.msgcheck(((GameSparker) ((Globe) this).gs)
					       .cmsg.getText()))
		((GameSparker) ((Globe) this).gs).cmsg.setText("");
	}
	if (((Globe) this).doweb2) {
	    if (!((GameSparker) ((Globe) this).gs).temail.isShowing()) {
		((GameSparker) ((Globe) this).gs).temail.show();
		((GameSparker) ((Globe) this).gs).temail.requestFocus();
	    }
	    ((Globe) this).gs.movefield((((GameSparker) ((Globe) this).gs)
					 .temail),
					354, 134, 350, 22);
	}
	if (((Globe) this).dommsg) {
	    if (!((Globe) this).donemsg) {
		((GameSparker) ((Globe) this).gs).mmsg.setText(" ");
		if (!((GameSparker) ((Globe) this).gs).applejava) {
		    ((GameSparker) ((Globe) this).gs).mmsg.show();
		    ((GameSparker) ((Globe) this).gs).mmsg.requestFocus();
		}
		((Globe) this).donemsg = true;
	    }
	    ((Globe) this).gs.movefielda((((GameSparker) ((Globe) this).gs)
					  .mmsg),
					 207, 389, 450, 50);
	} else {
	    if (((GameSparker) ((Globe) this).gs).mmsg.isShowing())
		((GameSparker) ((Globe) this).gs).mmsg.hide();
	    if (((Globe) this).donemsg)
		((Globe) this).donemsg = false;
	}
	if (!((Globe) this).dosrch && !((Globe) this).donewc
	    && !((Globe) this).doweb1 && !((Globe) this).doweb2
	    && ((GameSparker) ((Globe) this).gs).temail.isShowing())
	    ((GameSparker) ((Globe) this).gs).temail.hide();
	if (!bool_3_ && !bool_4_ && !((Globe) this).dorank
	    && !((Globe) this).doweb1 && ((Globe) this).open == 452
	    && ((GameSparker) ((Globe) this).gs).cmsg.isShowing())
	    ((GameSparker) ((Globe) this).gs).cmsg.hide();
    }
    
    public void dotab3(int i, int i_94_, boolean bool) {
	if (((Globe) this).cfase == 0) {
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.drawRect(214, 44, 160, 50);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    int i_95_ = 239;
	    int i_96_ = ((Globe) this).ftm.stringWidth("Search for a clan");
	    ((Globe) this).rd.fillRect(225, 57, 4, 4);
	    ((Globe) this).rd.drawString("Search for a clan", i_95_, 63);
	    if (i > i_95_ && i < i_95_ + i_96_ && i_94_ > 46 && i_94_ < 65
		&& ((Globe) this).editc == 0) {
		((Globe) this).rd.drawLine(i_95_, 65, i_95_ + i_96_, 65);
		((Globe) this).cur = 12;
		if (bool) {
		    ((Globe) this).cfase = 2;
		    ((Globe) this).em = 1;
		    ((Globe) this).msg = "Clan Search";
		    ((Globe) this).smsg
			= "Listing clans with recent activity...";
		    ((Globe) this).nclns = 0;
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).flko = 0;
		}
	    }
	    i_95_ = 239;
	    i_96_ = ((Globe) this).ftm.stringWidth("Create a new clan");
	    ((Globe) this).rd.fillRect(225, 77, 4, 4);
	    ((Globe) this).rd.drawString("Create a new clan", i_95_, 83);
	    if (i > i_95_ && i < i_95_ + i_96_ && i_94_ > 66 && i_94_ < 85
		&& ((Globe) this).editc == 0) {
		((Globe) this).rd.drawLine(i_95_, 85, i_95_ + i_96_, 85);
		((Globe) this).cur = 12;
		if (bool) {
		    ((Globe) this).cfase = 1;
		    ((Globe) this).em = 0;
		    ((Globe) this).msg = "Start a new Need for Madness clan,";
		    ((Globe) this).flko = 0;
		}
	    }
	    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		int i_97_ = -40;
		int i_98_ = 19;
		if (!drawl(((Globe) this).rd,
			   new StringBuilder().append("#").append
			       (((xtGraphics) ((Globe) this).xt).clan).append
			       ("#").toString(),
			   406 + i_98_, 101 + i_97_, true)) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("").append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     ("").toString(),
			 (581 + i_98_
			  - (((Globe) this).ftm.stringWidth
			     (new StringBuilder().append("").append
				  (((xtGraphics) ((Globe) this).xt).clan)
				  .append
				  ("").toString())) / 2),
			 121 + i_97_);
		}
		((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		String string = "Your Clan";
		if (i > 402 + i_98_ && i < 759 + i_98_ && i_94_ > 84 + i_97_
		    && i_94_ < 134 + i_97_) {
		    string = new StringBuilder().append("Clan :  ").append
				 (((xtGraphics) ((Globe) this).xt).clan).append
				 ("").toString();
		    ((Globe) this).rd.drawLine(408 + i_98_, 98 + i_97_,
					       (408 + i_98_
						+ ((Globe) this).ftm
						      .stringWidth(string)),
					       98 + i_97_);
		    if ((i > 408 + i_98_
			 && i < (408 + i_98_
				 + ((Globe) this).ftm.stringWidth(string))
			 && i_94_ > 85 + i_97_ && i_94_ < 100 + i_97_)
			|| (i > 406 + i_98_ && i < 756 + i_98_
			    && i_94_ > 101 + i_97_ && i_94_ < 131 + i_97_)) {
			((Globe) this).cur = 12;
			if (bool) {
			    if (!((Globe) this).claname.equals(((xtGraphics)
								(((Globe) this)
								 .xt)).clan)) {
				((Globe) this).claname
				    = ((xtGraphics) ((Globe) this).xt).clan;
				((Globe) this).loadedc = false;
			    }
			    ((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = 0;
			    ((Globe) this).cfase = 3;
			    ((Globe) this).ctab = 0;
			    ((Globe) this).blocknote = 10;
			}
		    }
		}
		((Globe) this).rd.drawString(string, 408 + i_98_, 97 + i_97_);
		((Globe) this).rd.drawLine(402 + i_98_, 84 + i_97_,
					   402 + i_98_, 134 + i_97_);
		((Globe) this).rd.drawLine(402 + i_98_, 84 + i_97_,
					   (408 + i_98_
					    + ((Globe) this).ftm
						  .stringWidth(string)
					    + 2),
					   84 + i_97_);
		((Globe) this).rd.drawLine
		    (408 + i_98_ + ((Globe) this).ftm.stringWidth(string) + 2,
		     84 + i_97_,
		     408 + i_98_ + ((Globe) this).ftm.stringWidth(string) + 15,
		     97 + i_97_);
		((Globe) this).rd.drawLine
		    (408 + i_98_ + ((Globe) this).ftm.stringWidth(string) + 15,
		     97 + i_97_, 759 + i_98_, 97 + i_97_);
		((Globe) this).rd.drawLine(759 + i_98_, 97 + i_97_,
					   759 + i_98_, 134 + i_97_);
		((Globe) this).rd.drawLine(402 + i_98_, 134 + i_97_,
					   759 + i_98_, 134 + i_97_);
	    }
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).ntab == 0) {
		int[] is
		    = { 214, 225 + ((Globe) this).ftm.stringWidth("Game News"),
			225 + ((Globe) this).ftm.stringWidth("Game News") + 23,
			778, 778, 214 };
		int[] is_99_ = { 112, 112, 135, 135, 443, 443 };
		((Globe) this).rd.setColor(new Color(206, 171, 98));
		((Globe) this).rd.fillPolygon(is, is_99_, 6);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawPolygon(is, is_99_, 6);
	    }
	    if (((Globe) this).ntab == 1) {
		int[] is
		    = { 214,
			225 + ((Globe) this).ftm.stringWidth("Game News") + 23,
			225 + ((Globe) this).ftm.stringWidth("Game News") + 23,
			(236 + ((Globe) this).ftm.stringWidth("Game News") + 23
			 + ((Globe) this).ftm
			       .stringWidth("Wars World Championship")),
			(236 + ((Globe) this).ftm.stringWidth("Game News") + 23
			 + ((Globe) this).ftm
			       .stringWidth("Wars World Championship")
			 + 23),
			778, 778, 214 };
		int[] is_100_ = { 135, 135, 112, 112, 135, 135, 443, 443 };
		((Globe) this).rd.setColor(new Color(206, 171, 98));
		((Globe) this).rd.fillPolygon(is, is_100_, 8);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawPolygon(is, is_100_, 8);
	    }
	    int i_101_ = 223;
	    int i_102_ = ((Globe) this).ftm.stringWidth("Game News");
	    int i_103_ = 23;
	    ((Globe) this).rd.drawString("Game News", i_101_, 107 + i_103_);
	    if (i > i_101_ && i < i_101_ + i_102_ && i_94_ > 90 + i_103_
		&& i_94_ < 109 + i_103_) {
		((Globe) this).rd.drawLine(i_101_, 109 + i_103_,
					   i_101_ + i_102_, 109 + i_103_);
		((Globe) this).cur = 12;
		if (bool) {
		    ((Globe) this).ntab = 0;
		    ((Globe) this).spos6 = 0;
		}
	    }
	    i_101_ += i_102_ + 35;
	    i_102_ = ((Globe) this).ftm.stringWidth("Wars World Championship");
	    ((Globe) this).rd.drawString("Wars World Championship", i_101_,
					 107 + i_103_);
	    if (i > i_101_ && i < i_101_ + i_102_ && i_94_ > 90 + i_103_
		&& i_94_ < 109 + i_103_) {
		((Globe) this).rd.drawLine(i_101_, 109 + i_103_,
					   i_101_ + i_102_, 109 + i_103_);
		((Globe) this).cur = 12;
		if (bool) {
		    ((Globe) this).ntab = 1;
		    ((Globe) this).spos6 = 0;
		}
	    }
	    ((Globe) this).rdo.setColor(new Color(206, 171, 98));
	    ((Globe) this).rdo.fillRect(0, 0, 560, 300);
	    ((Globe) this).darker = true;
	    if (stringbutton(((Globe) this).rd, "  Refresh  ", 738, 125, 3, i,
			     i_94_, bool, 0, 0)) {
		if (((Globe) this).ntab == 0)
		    ((Globe) this).loadednews = 0;
		if (((Globe) this).ntab == 1)
		    ((Globe) this).loadwstat = 0;
	    }
	    ((Globe) this).darker = false;
	    if (((Globe) this).ntab == 0) {
		if (((Globe) this).loadednews == 1) {
		    int i_104_ = 0;
		    for (int i_105_ = 0; i_105_ < 5; i_105_++) {
			if (((Globe) this).nwarbs[i_105_] > 0)
			    i_104_++;
		    }
		    if (i_104_ == 0)
			i_104_ = 1;
		    ((Globe) this).sdist
			= 100 + 35 * i_104_ + ((Globe) this).doi * 16 - 200;
		    if (((Globe) this).sdist < 0)
			((Globe) this).sdist = 0;
		    ((Globe) this).scro
			= (int) ((float) ((Globe) this).spos6 / 229.0F
				 * (float) ((Globe) this).sdist);
		    if (((Globe) this).scro < 55) {
			((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawString
			    ("A big welcome to the latest players to join the game with full accounts!",
			     18, 15 - ((Globe) this).scro);
			for (int i_106_ = 0; i_106_ < 4; i_106_++) {
			    boolean bool_107_ = false;
			    boolean bool_108_ = false;
			    if (i > 234 + 128 * i_106_
				&& i < 354 + 128 * i_106_
				&& i_94_ > 159 - ((Globe) this).scro
				&& i_94_ < 189 - ((Globe) this).scro
				&& i_94_ > 139 && i_94_ < 439) {
				bool_108_ = true;
				((Globe) this).cur = 12;
				if (bool) {
				    ((Globe) this).tab = 1;
				    if (!((Globe) this).proname.equals
					 (((Globe) this).newplayers[i_106_])) {
					((Globe) this).proname
					    = (((Globe) this).newplayers
					       [i_106_]);
					((Globe) this).loadedp = false;
					onexitpro();
				    }
				}
			    }
			    if (!bool_108_)
				bool_107_
				    = drawl(((Globe) this).rdo,
					    ((Globe) this).newplayers[i_106_],
					    18 + 128 * i_106_,
					    20 - ((Globe) this).scro, true);
			    else
				drawl(((Globe) this).rdo,
				      ((Globe) this).newplayers[i_106_],
				      18 + 128 * i_106_,
				      20 - ((Globe) this).scro, false);
			    if (!bool_107_) {
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.2F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRect(18 + 128 * i_106_,
							    20 - ((Globe)
								  this).scro,
							    119, 29);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.drawRect(18 + 128 * i_106_,
							    20 - ((Globe)
								  this).scro,
							    119, 29);
				((Globe) this).rdo.drawString
				    (((Globe) this).newplayers[i_106_],
				     (78 + 128 * i_106_
				      - ((((Globe) this).ftm.stringWidth
					  (((Globe) this).newplayers[i_106_]))
					 / 2)),
				     39 - ((Globe) this).scro);
			    }
			}
		    }
		    if (75 + 35 * i_104_ - ((Globe) this).scro > 0) {
			((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawString
			    ("Recent clan wars & battles:", 18,
			     70 - ((Globe) this).scro);
			i_104_ = 0;
			for (int i_109_ = 0; i_109_ < 5; i_109_++) {
			    if (((Globe) this).nwarbs[i_109_] > 0) {
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.2F));
				boolean bool_110_ = false;
				bool_110_
				    = drawl(((Globe) this).rdo,
					    new StringBuilder().append("#")
						.append
						(((Globe) this).nwclan[i_109_])
						.append
						("#").toString(),
					    18,
					    (75 - ((Globe) this).scro
					     + 35 * i_104_),
					    true);
				if (!bool_110_) {
				    ((Globe) this).rdo
					.setColor(new Color(255, 255, 255));
				    ((Globe) this).rdo.fillRect
					(18, (75 - ((Globe) this).scro
					      + 35 * i_104_), 350, 30);
				}
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.1F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRect(368,
							    (75
							     - (((Globe) this)
								.scro)
							     + 35 * i_104_),
							    154, 30);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    1, 11));
				String string = "war";
				if (((Globe) this).nwarbs[i_109_] == 2)
				    string = "car battle";
				if (((Globe) this).nwarbs[i_109_] == 3)
				    string = "stage battle";
				String string_111_
				    = new StringBuilder().append("").append
					  (((Globe) this).nwclan[i_109_])
					  .append
					  (" defeated ").append
					  (((Globe) this).nlclan[i_109_])
					  .append
					  (" in a ").append
					  (string).append
					  ("!").toString();
				((Globe) this).rdo.drawString
				    (string_111_, 22,
				     87 - ((Globe) this).scro + 35 * i_104_);
				tlink(((Globe) this).rdo, 22,
				      87 - ((Globe) this).scro + 35 * i_104_,
				      string_111_,
				      ((Globe) this).nwclan[i_109_], i, i_94_,
				      bool, 216, 139, 1,
				      ((Globe) this).nwclan[i_109_], "");
				tlink(((Globe) this).rdo, 22,
				      87 - ((Globe) this).scro + 35 * i_104_,
				      string_111_,
				      ((Globe) this).nlclan[i_109_], i, i_94_,
				      bool, 216, 139, 1,
				      ((Globe) this).nlclan[i_109_], "");
				if (((Globe) this).nwarbs[i_109_] == 1
				    && ((Globe) this).nwinp[i_109_] != -1
				    && ((Globe) this).nlosp[i_109_] != -1) {
				    if (((Globe) this).nwinob[i_109_]
					    .equals("champ")) {
					String string_112_
					    = new StringBuilder().append
						  ("").append
						  (((Globe) this).nwclan
						   [i_109_])
						  .append
						  (" has taken the clan wars world championship title!")
						  .toString();
					((Globe) this).rdo.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).rdo.drawString
					    (string_112_, 22,
					     (100 - ((Globe) this).scro
					      + 35 * i_104_));
					tlink
					    (((Globe) this).rdo, 22,
					     (100 - ((Globe) this).scro
					      + 35 * i_104_),
					     string_112_,
					     "clan wars world championship title",
					     i, i_94_, bool, 216, 139, 5, "",
					     "");
				    } else if (((Globe) this).nwinob
						   [i_109_]
						   .equals("re-champ")) {
					String string_113_
					    = new StringBuilder().append
						  ("").append
						  (((Globe) this).nwclan
						   [i_109_])
						  .append
						  (" has defended and re-claimed the clan wars world championship title!")
						  .toString();
					((Globe) this).rdo.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).rdo.drawString
					    (string_113_, 22,
					     (100 - ((Globe) this).scro
					      + 35 * i_104_));
					tlink
					    (((Globe) this).rdo, 22,
					     (100 - ((Globe) this).scro
					      + 35 * i_104_),
					     string_113_,
					     "clan wars world championship title",
					     i, i_94_, bool, 216, 139, 5, "",
					     "");
				    } else {
					String string_114_
					    = new StringBuilder().append
						  ("").append
						  (((Globe) this).nwclan
						   [i_109_])
						  .append
						  (" won: [ ").append
						  (((Globe) this).nwinp
						   [i_109_])
						  .append
						  (" points ]  & ").append
						  (((Globe) this).nlclan
						   [i_109_])
						  .append
						  (" lost: [ ").append
						  (((Globe) this).nlosp
						   [i_109_])
						  .append
						  (" points ]").toString();
					((Globe) this).rdo.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).rdo.drawString
					    (string_114_, 22,
					     (100 - ((Globe) this).scro
					      + 35 * i_104_));
					tlink(((Globe) this).rdo, 22,
					      (100 - ((Globe) this).scro
					       + 35 * i_104_),
					      string_114_,
					      new StringBuilder().append
						  ("").append
						  (((Globe) this).nwinp
						   [i_109_])
						  .append
						  (" points").toString(),
					      i, i_94_, bool, 216, 139, 5, "",
					      "");
					tlink(((Globe) this).rdo, 22,
					      (100 - ((Globe) this).scro
					       + 35 * i_104_),
					      string_114_,
					      new StringBuilder().append
						  ("").append
						  (((Globe) this).nlosp
						   [i_109_])
						  .append
						  (" points").toString(),
					      i, i_94_, bool, 216, 139, 5, "",
					      "");
				    }
				}
				if (((Globe) this).nwarbs[i_109_] == 2) {
				    String string_115_
					= new StringBuilder().append("").append
					      (((Globe) this).nwclan[i_109_])
					      .append
					      (" took car [").append
					      (((Globe) this).nwinob[i_109_])
					      .append
					      ("] from ").append
					      (((Globe) this).nlclan[i_109_])
					      .append
					      (".").toString();
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).rdo.drawString
					(string_115_, 22,
					 (100 - ((Globe) this).scro
					  + 35 * i_104_));
				    tlink(((Globe) this).rdo, 22,
					  (100 - ((Globe) this).scro
					   + 35 * i_104_),
					  string_115_,
					  ((Globe) this).nwinob[i_109_], i,
					  i_94_, bool, 216, 139, 3,
					  ((Globe) this).nwinob[i_109_],
					  ((Globe) this).nwclan[i_109_]);
				}
				if (((Globe) this).nwarbs[i_109_] == 3) {
				    String string_116_
					= ((Globe) this).nwinob[i_109_];
				    if (string_116_.length() > 20)
					string_116_
					    = new StringBuilder().append
						  ("").append
						  (string_116_.substring(0,
									 20))
						  .append
						  ("...").toString();
				    String string_117_
					= new StringBuilder().append("").append
					      (((Globe) this).nwclan[i_109_])
					      .append
					      (" took stage [").append
					      (string_116_).append
					      ("] from ").append
					      (((Globe) this).nlclan[i_109_])
					      .append
					      (".").toString();
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).rdo.drawString
					(string_117_, 22,
					 (100 - ((Globe) this).scro
					  + 35 * i_104_));
				    tlink(((Globe) this).rdo, 22,
					  (100 - ((Globe) this).scro
					   + 35 * i_104_),
					  string_117_, string_116_, i, i_94_,
					  bool, 216, 139, 4,
					  ((Globe) this).nwinob[i_109_],
					  ((Globe) this).nwclan[i_109_]);
				}
				((Globe) this).rdo.setColor(new Color(98, 76,
								      29));
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    0, 11));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.drawString
				    (((Globe) this).nwtime[i_109_],
				     518 - (((Globe) this).ftm.stringWidth
					    (((Globe) this).nwtime[i_109_])),
				     87 - ((Globe) this).scro + 35 * i_104_);
				i_104_++;
			    }
			}
			if (i_104_ == 0) {
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				("(No recent clan wars or battles have been played yet...)",
				 (280
				  - ((((Globe) this).ftm.stringWidth
				      ("(No recent clan wars or battles have been played yet...)"))
				     / 2)),
				 91 - ((Globe) this).scro);
			    i_104_ = 1;
			}
		    }
		    int i_118_ = 70 + 35 * i_104_ - ((Globe) this).scro;
		    if (i_118_ + 25 > 0) {
			((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawString("Recent clan activity:",
						      18, i_118_ + 20);
		    }
		    boolean bool_119_ = false;
		    String string = "";
		    ((Globe) this).doi = 0;
		    for (int i_120_ = 0; i_120_ < ((Globe) this).il;
			 i_120_++) {
			if (!((Globe) this).text[i_120_].equals(string)) {
			    if (!bool_119_)
				bool_119_ = true;
			    else
				bool_119_ = false;
			    if (i_118_ + ((Globe) this).doi * 16 + 38 > 0
				&& (i_118_ + ((Globe) this).doi * 16 + 18
				    < 300)) {
				if (bool_119_) {
				    ((Globe) this).rdo.setComposite
					(AlphaComposite.getInstance(3, 0.1F));
				    ((Globe) this).rdo
					.setColor(new Color(255, 255, 255));
				    ((Globe) this).rdo.fillRect
					(18,
					 i_118_ + ((Globe) this).doi * 16 + 24,
					 504, 16);
				    ((Globe) this).rdo.setComposite
					(AlphaComposite.getInstance(3, 1.0F));
				}
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    0, 11));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				if (((Globe) this).text[i_120_]
					.startsWith("Battle"))
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 1, 11));
				else {
				    ((Globe) this).rdo
					.setColor(new Color(98, 76, 29));
				    ((Globe) this).rdo.drawString
					(((Globe) this).nttime[i_120_],
					 (518
					  - (((Globe) this).ftm.stringWidth
					     (((Globe) this).nttime[i_120_]))),
					 (i_118_ + ((Globe) this).doi * 16
					  + 36));
				}
				if (((Globe) this).text[i_120_]
					.indexOf("started")
				    != -1) {
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 1, 11));
				    if (((Globe) this).text[i_120_]
					    .indexOf("war")
					== -1) {
					if (!bool_119_)
					    bool_119_ = true;
					else
					    bool_119_ = false;
				    }
				}
				if (((Globe) this).text[i_120_]
					.indexOf("clan wars world champion")
				    != -1) {
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 1, 11));
				    if (!bool_119_)
					bool_119_ = true;
				    else
					bool_119_ = false;
				}
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    (((Globe) this).text[i_120_], 22,
				     i_118_ + ((Globe) this).doi * 16 + 36);
				for (int i_121_ = 0;
				     i_121_ < ((Globe) this).nln[i_120_];
				     i_121_++)
				    tlink(((Globe) this).rdo, 22,
					  (i_118_ + ((Globe) this).doi * 16
					   + 36),
					  ((Globe) this).text[i_120_],
					  (((Globe) this).link[i_120_][i_121_]
					   [0]),
					  i, i_94_, bool, 216, 139,
					  getvalue((((Globe) this).link[i_120_]
						    [i_121_][1]),
						   0),
					  getSvalue((((Globe) this).link
						     [i_120_][i_121_][1]),
						    1),
					  getSvalue((((Globe) this).link
						     [i_120_][i_121_][1]),
						    2));
			    }
			    string = ((Globe) this).text[i_120_];
			    ((Globe) this).doi++;
			}
		    }
		} else
		    ((Globe) this).sdist = 0;
		if (((Globe) this).loadednews == 0) {
		    ((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawString
			("Loading game news, please wait...",
			 280 - (((Globe) this).ftm.stringWidth
				("Loading game news, please wait...")) / 2,
			 140);
		}
		if (((Globe) this).loadednews == -1) {
		    ((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawString
			("Failed to load game news, please try again later...",
			 (280
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to load game news, please try again later..."))
			     / 2)),
			 140);
		}
	    }
	    if (((Globe) this).ntab == 1) {
		((Globe) this).darker = true;
		if (stringbutton(((Globe) this).rd, "  About Championship  ",
				 617, 125, 3, i, i_94_, bool, 0, 0))
		    ((Globe) this).ntab = 2;
		((Globe) this).darker = false;
		if (((Globe) this).loadwstat == 1) {
		    if (((Globe) this).eng == -1) {
			int i_122_ = ((Globe) this).ncc;
			if (((Globe) this).champ >= 0)
			    i_122_--;
			if (i_122_ < 0)
			    i_122_ = 0;
			((Globe) this).sdist = 154 + i_122_ * 45 - 260;
			if (((Globe) this).sdist < 0)
			    ((Globe) this).sdist = 0;
			((Globe) this).scro
			    = (int) ((float) ((Globe) this).spos6 / 229.0F
				     * (float) ((Globe) this).sdist);
			((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rdo.getFontMetrics();
			int i_123_ = ((Globe) this).ftm
					 .stringWidth("Engagement Stats");
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawString("Current World Champion",
						      10,
						      (20
						       - ((Globe) this).scro));
			((Globe) this).rdo.setColor(new Color(228, 177, 31));
			((Globe) this).rdo.fillRoundRect(10,
							 28 - (((Globe) this)
							       .scro),
							 520, 70, 20, 20);
			((Globe) this).rdo.setColor(new Color(199, 154, 63));
			((Globe) this).rdo.fillRoundRect(13,
							 33 - (((Globe) this)
							       .scro),
							 514, 60, 20, 20);
			((Globe) this).rdo.setColor(new Color(255, 198, 0));
			((Globe) this).rdo.drawRoundRect(13,
							 33 - (((Globe) this)
							       .scro),
							 514, 60, 20, 20);
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawRoundRect(10,
							 28 - (((Globe) this)
							       .scro),
							 520, 70, 20, 20);
			if (((Globe) this).champ == -1) {
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				("No current world champion because no contender has attained or surpassed 3 points yet!",
				 (270
				  - ((((Globe) this).ftm.stringWidth
				      ("No current world champion because no contender has attained or surpassed 3 points yet!"))
				     / 2)),
				 65 - ((Globe) this).scro);
			}
			if (((Globe) this).champ == -2) {
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				("No current world champion at this moment because the top contenders are tied in points!",
				 (270
				  - ((((Globe) this).ftm.stringWidth
				      ("No current world champion at this moment because the top contenders are tied in points!"))
				     / 2)),
				 65 - ((Globe) this).scro);
			}
			if (((Globe) this).champ >= 0) {
			    if (!drawl(((Globe) this).rdo,
				       new StringBuilder().append("#").append
					   (((Globe) this).conclan
					    [((Globe) this).champ])
					   .append
					   ("#").toString(),
				       21, 40 - ((Globe) this).scro, true)) {
				((Globe) this).rdo.setColor(new Color(100, 77,
								      31));
				((Globe) this).rdo.drawRect(21,
							    40 - ((Globe)
								  this).scro,
							    349, 29);
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    13));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.drawString
				    ((((Globe) this).conclan
				      [((Globe) this).champ]),
				     196 - (((Globe) this).ftm.stringWidth
					    (((Globe) this).conclan
					     [((Globe) this).champ])) / 2,
				     59 - ((Globe) this).scro);
			    }
			    if (i > 237 && i < 587
				&& i_94_ > 179 - ((Globe) this).scro
				&& i_94_ < 209 - ((Globe) this).scro
				&& i_94_ > 139 && i_94_ < 439) {
				((Globe) this).cur = 12;
				if (bool) {
				    if (!((Globe) this).claname.equals
					 (((Globe) this).conclan
					  [((Globe) this).champ])) {
					((Globe) this).claname
					    = (((Globe) this).conclan
					       [((Globe) this).champ]);
					((Globe) this).loadedc = false;
				    }
				    ((Globe) this).spos5 = 0;
				    ((Globe) this).lspos5 = 0;
				    ((Globe) this).cfase = 3;
				    ((Globe) this).ctab = 0;
				}
			    }
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append("").append
				     (((Globe) this).conclan
				      [((Globe) this).champ])
				     .append
				     (" is leading the championship by ")
				     .append
				     (((Globe) this).leadsby).append
				     (" points difference from the first contender!")
				     .toString(),
				 22, 85 - ((Globe) this).scro);
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 1,
								11));
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append
				     ("Attained points:  [ ").append
				     (((Globe) this).totp
				      [((Globe) this).champ])
				     .append
				     (" ]").toString(),
				 383, 51 - ((Globe) this).scro);
			    ((Globe) this).rdo.drawString("Engagement Stats",
							  383,
							  66 - (((Globe) this)
								.scro));
			    ((Globe) this).rdo.drawLine
				(383, 68 - ((Globe) this).scro, 383 + i_123_,
				 68 - ((Globe) this).scro);
			    if (i > 599 && i < 383 + i_123_ + 216
				&& i_94_ > 195 - ((Globe) this).scro
				&& i_94_ < 208 - ((Globe) this).scro
				&& i_94_ > 139 && i_94_ < 439) {
				((Globe) this).cur = 12;
				if (bool) {
				    ((Globe) this).eng = ((Globe) this).champ;
				    ((Globe) this).engo
					= 40 - ((Globe) this).scro;
				    ((Globe) this).lspos6w
					= ((Globe) this).spos6;
				    ((Globe) this).spos6 = 0;
				}
			    }
			}
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rdo.getFontMetrics();
			((Globe) this).rdo.drawString("Contenders", 10,
						      (125
						       - ((Globe) this).scro));
			if (i_122_ > 3)
			    i_122_ = 160 + 45 * (i_122_ - 3);
			else
			    i_122_ = 160;
			((Globe) this).rdo.drawRoundRect(10,
							 133 - (((Globe) this)
								.scro),
							 520, i_122_, 20, 20);
			if (((Globe) this).ncc == 0
			    || (((Globe) this).ncc == 1
				&& ((Globe) this).champ == 0)) {
			    ((Globe) this).rdo.drawString
				("No contenders...",
				 270 - (((Globe) this).ftm
					    .stringWidth("No contenders...")
					/ 2),
				 160 - ((Globe) this).scro);
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString
				("To become a contender, a clan must get points by winning a war against any other clan.",
				 (270
				  - ((((Globe) this).ftm.stringWidth
				      ("To become a contender, a clan must get points by winning a war against any other clan."))
				     / 2)),
				 185 - ((Globe) this).scro);
			} else {
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString
				("To become a contender, a clan must get points by winning a war against any other clan.",
				 (270
				  - ((((Globe) this).ftm.stringWidth
				      ("To become a contender, a clan must get points by winning a war against any other clan."))
				     / 2)),
				 147 - ((Globe) this).scro);
			    int i_124_ = 0;
			    for (int i_125_ = 0; i_125_ < ((Globe) this).ncc;
				 i_125_++) {
				if (((Globe) this).ord[i_125_]
				    != ((Globe) this).champ) {
				    ((Globe) this).rdo
					.setColor(new Color(199, 154, 63));
				    ((Globe) this).rdo.fillRect
					(11, (154 + i_124_ * 45
					      - ((Globe) this).scro), 519, 40);
				    if (!drawl(((Globe) this).rdo,
					       new StringBuilder().append
						   ("#").append
						   (((Globe) this).conclan
						    [(((Globe) this).ord
						      [i_125_])])
						   .append
						   ("#").toString(),
					       21,
					       (159 + i_124_ * 45
						- ((Globe) this).scro),
					       true)) {
					((Globe) this).rdo
					    .setColor(new Color(100, 77, 31));
					((Globe) this).rdo.drawRect
					    (21,
					     (159 + i_124_ * 45
					      - ((Globe) this).scro),
					     349, 29);
					((Globe) this).rdo
					    .setFont(new Font("Arial", 1, 13));
					((Globe) this).ftm
					    = ((Globe) this).rdo
						  .getFontMetrics();
					((Globe) this).rdo.drawString
					    ((((Globe) this).conclan
					      [((Globe) this).ord[i_125_]]),
					     196 - (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).conclan
						     [(((Globe) this).ord
						       [i_125_])])) / 2,
					     (178 + i_124_ * 45
					      - ((Globe) this).scro));
				    }
				    if (i > 237 && i < 587
					&& i_94_ > (159 + i_124_ * 45 + 139
						    - ((Globe) this).scro)
					&& i_94_ < (189 + i_124_ * 45 + 139
						    - ((Globe) this).scro)
					&& i_94_ > 139 && i_94_ < 439) {
					((Globe) this).cur = 12;
					if (bool) {
					    if (!((Globe) this).claname.equals
						 (((Globe) this).conclan
						  [(((Globe) this).ord
						    [i_125_])])) {
						((Globe) this).claname
						    = (((Globe) this).conclan
						       [(((Globe) this).ord
							 [i_125_])]);
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).ctab = 0;
					}
				    }
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    ((Globe) this).rdo
					.setFont(new Font("Tahoma", 1, 11));
				    ((Globe) this).rdo.drawString
					(new StringBuilder().append
					     ("Attained points:  [ ").append
					     (((Globe) this).totp
					      [((Globe) this).ord[i_125_]])
					     .append
					     (" ]").toString(),
					 383,
					 (170 + i_124_ * 45
					  - ((Globe) this).scro));
				    ((Globe) this).rdo.drawString
					("Engagement Stats", 383,
					 (185 + i_124_ * 45
					  - ((Globe) this).scro));
				    ((Globe) this).rdo.drawLine
					(383,
					 (187 + i_124_ * 45
					  - ((Globe) this).scro),
					 383 + i_123_,
					 (187 + i_124_ * 45
					  - ((Globe) this).scro));
				    if (i > 599 && i < 383 + i_123_ + 216
					&& i_94_ > (175 + i_124_ * 45 + 139
						    - ((Globe) this).scro)
					&& i_94_ < (188 + i_124_ * 45 + 139
						    - ((Globe) this).scro)
					&& i_94_ > 139 && i_94_ < 439) {
					((Globe) this).cur = 12;
					if (bool) {
					    ((Globe) this).eng
						= ((Globe) this).ord[i_125_];
					    ((Globe) this).engo
						= (159 + i_124_ * 45
						   - ((Globe) this).scro);
					    ((Globe) this).lspos6w
						= ((Globe) this).spos6;
					    ((Globe) this).spos6 = 0;
					}
				    }
				    i_124_++;
				}
			    }
			}
		    } else {
			if (((Globe) this).engo == 15) {
			    ((Globe) this).sdist
				= (87 + ((Globe) this).ados
				   + (((Globe) this).nvc[((Globe) this).eng]
				      * 17)
				   - 260);
			    if (((Globe) this).sdist < 0)
				((Globe) this).sdist = 0;
			    ((Globe) this).scro
				= (int) ((float) ((Globe) this).spos6 / 229.0F
					 * (float) ((Globe) this).sdist);
			    ((Globe) this).ados = 0;
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 1,
								11));
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString("Engagement Stats",
							  385,
							  40 - (((Globe) this)
								.scro));
			    String string = "s";
			    if (!((xtGraphics) ((Globe) this).xt).clan
				     .equals("")
				&& !(((xtGraphics) ((Globe) this).xt).clan
					 .toLowerCase
					 ().equals
				     (((Globe) this).conclan
					  [((Globe) this).eng]
					  .toLowerCase()))) {
				((Globe) this).ados = 116;
				int i_126_ = -1;
				int i_127_ = 0;
				for (int i_128_ = 0;
				     i_128_ < ((Globe) this).ncc; i_128_++) {
				    if (((xtGraphics) ((Globe) this).xt)
					    .clan.toLowerCase
					    ().equals
					(((Globe) this).conclan[i_128_]
					     .toLowerCase())) {
					i_127_ = ((Globe) this).totp[i_128_];
					i_126_ = i_128_;
					break;
				    }
				}
				int i_129_
				    = (((Globe) this).totp[((Globe) this).eng]
				       + 1);
				int i_130_ = i_127_ + 1;
				if (i_130_
				    > ((Globe) this).totp[((Globe) this).eng])
				    i_130_ = (((Globe) this).totp
					      [((Globe) this).eng]);
				if (i_126_ != -1) {
				    for (int i_131_ = 0;
					 i_131_ < ((Globe) this).nvc[i_126_];
					 i_131_++) {
					if (((Globe) this).conclan
						[((Globe) this).eng]
						.toLowerCase
						().equals
					    (((Globe) this).verclan[i_126_]
						 [i_131_].toLowerCase())) {
					    i_129_ -= (((Globe) this).points
						       [i_126_][i_131_]);
					    if (i_129_ < 0)
						i_129_ = 0;
					    break;
					}
				    }
				}
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    1, 11));
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("If your clan ").append
					 (((xtGraphics) ((Globe) this).xt)
					  .clan)
					 .append
					 (" engages & defeats ").append
					 (((Globe) this).conclan
					  [((Globe) this).eng])
					 .append
					 (" in a war:").toString(),
				     27, 70 - ((Globe) this).scro);
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    0, 11));
				string = "s";
				if (i_129_ == 1)
				    string = "";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("- Your clan will get:  [ ").append
					 (i_129_).append
					 (" point").append
					 (string).append
					 (" ]").toString(),
				     47, 87 - ((Globe) this).scro);
				string = "s";
				if (i_130_ == 1)
				    string = "";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append("- ").append
					 (((Globe) this).conclan
					  [((Globe) this).eng])
					 .append
					 (" will lose:  [ ").append
					 (i_130_).append
					 (" point").append
					 (string).append
					 (" ]").toString(),
				     47, 104 - ((Globe) this).scro);
				if (i_129_ + i_127_ > 3
				    && (i_129_ + i_127_
					> (((Globe) this).totp
					   [((Globe) this).ord[0]]))
				    && !(((xtGraphics) ((Globe) this).xt)
					     .clan.toLowerCase
					     ().equals
					 (((Globe) this).conclan
					      [((Globe) this).ord[0]]
					      .toLowerCase()))) {
				    if (((Globe) this).frkl) {
					((Globe) this).rdo
					    .setColor(new Color(0, 0, 0));
					((Globe) this).frkl = false;
				    } else {
					((Globe) this).rdo
					    .setColor(new Color(106, 80, 0));
					((Globe) this).frkl = true;
				    }
				    if (((Globe) this).champ >= 0)
					((Globe) this).rdo.drawString
					    (new StringBuilder().append
						 ("- Your clan would take the championship title from ")
						 .append
						 (((Globe) this).conclan
						  [((Globe) this).champ])
						 .append
						 (" !").toString(),
					     47, 121 - ((Globe) this).scro);
				    else
					((Globe) this).rdo.drawString
					    ("- Your clan would take the champion ship title!",
					     42, 121 - ((Globe) this).scro);
				    ((Globe) this).ados += 17;
				}
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				i_129_ = i_127_ + 1;
				i_130_
				    = (((Globe) this).totp[((Globe) this).eng]
				       + 1);
				if (i_130_ > i_127_)
				    i_130_ = i_127_;
				for (int i_132_ = 0;
				     i_132_ < (((Globe) this).nvc
					       [((Globe) this).eng]);
				     i_132_++) {
				    if (((xtGraphics) ((Globe) this).xt)
					    .clan.toLowerCase
					    ().equals
					(((Globe) this).verclan
					     [((Globe) this).eng][i_132_]
					     .toLowerCase())) {
					i_129_
					    -= (((Globe) this).points
						[((Globe) this).eng][i_132_]);
					if (i_129_ < 0)
					    i_129_ = 0;
					break;
				    }
				}
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    1, 11));
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("If your clan loses a war against ")
					 .append
					 (((Globe) this).conclan
					  [((Globe) this).eng])
					 .append
					 (":").toString(),
				     27,
				     (12 + ((Globe) this).ados
				      - ((Globe) this).scro));
				((Globe) this).rdo.setFont(new Font("Tahoma",
								    0, 11));
				string = "s";
				if (i_130_ == 1)
				    string = "";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("- Your clan will lose:  [ ").append
					 (i_130_).append
					 (" point").append
					 (string).append
					 (" ]").toString(),
				     47,
				     (29 + ((Globe) this).ados
				      - ((Globe) this).scro));
				string = "s";
				if (i_129_ == 1)
				    string = "";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append("- ").append
					 (((Globe) this).conclan
					  [((Globe) this).eng])
					 .append
					 (" will get:  [ ").append
					 (i_129_).append
					 (" point").append
					 (string).append
					 (" ]").toString(),
				     47,
				     (46 + ((Globe) this).ados
				      - ((Globe) this).scro));
			    }
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 1,
								11));
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append("").append
				     (((Globe) this).conclan
				      [((Globe) this).eng])
				     .append
				     (" has attained its points from clan wars:")
				     .toString(),
				 27,
				 (70 + ((Globe) this).ados
				  - ((Globe) this).scro));
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 0,
								11));
			    for (int i_133_ = 0;
				 (i_133_
				  < ((Globe) this).nvc[((Globe) this).eng]);
				 i_133_++) {
				string = "s";
				if ((((Globe) this).points[((Globe) this).eng]
				     [i_133_])
				    == 1)
				    string = "";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("Versus clan ").append
					 (((Globe) this).verclan
					  [((Globe) this).eng][i_133_])
					 .append
					 (":  [ ").append
					 (((Globe) this).points
					  [((Globe) this).eng][i_133_])
					 .append
					 (" point").append
					 (string).append
					 (" ]").toString(),
				     47,
				     (87 + ((Globe) this).ados + i_133_ * 17
				      - ((Globe) this).scro));
			    }
			    ((Globe) this).rdo.setFont(new Font("Tahoma", 1,
								11));
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append
				     ("Total attained points:  [ ").append
				     (((Globe) this).totp[((Globe) this).eng])
				     .append
				     (" ]").toString(),
				 47,
				 (87 + ((Globe) this).ados
				  + ((Globe) this).nvc[((Globe) this).eng] * 17
				  - ((Globe) this).scro));
			} else if (Math.abs(((Globe) this).engo - 15) < 20)
			    ((Globe) this).engo = 15;
			else if (((Globe) this).engo < 15)
			    ((Globe) this).engo += 20;
			else
			    ((Globe) this).engo -= 20;
			if (!drawl(((Globe) this).rdo,
				   new StringBuilder().append("#").append
				       (((Globe) this).conclan
					[((Globe) this).eng])
				       .append
				       ("#").toString(),
				   21,
				   ((Globe) this).engo - ((Globe) this).scro,
				   true)) {
			    ((Globe) this).rdo.setColor(new Color(100, 77,
								  31));
			    ((Globe) this).rdo.drawRect(21,
							(((Globe) this).engo
							 - (((Globe) this)
							    .scro)),
							349, 29);
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								13));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				(((Globe) this).conclan[((Globe) this).champ],
				 196 - (((Globe) this).ftm.stringWidth
					(((Globe) this).conclan
					 [((Globe) this).champ])) / 2,
				 (((Globe) this).engo + 19
				  - ((Globe) this).scro));
			}
			if (((Globe) this).engo == 15) {
			    ((Globe) this).darker = true;
			    if (!((xtGraphics) ((Globe) this).xt).clan
				     .equals("")
				&& !(((xtGraphics) ((Globe) this).xt).clan
					 .toLowerCase
					 ().equals
				     (((Globe) this).conclan
					  [((Globe) this).eng].toLowerCase()))
				&& stringbutton(((Globe) this).rdo,
						"   Declare War  >   ", 459,
						176, 1, i, i_94_, bool, 216,
						139)) {
				((Globe) this).tab = 2;
				((Globe) this).itab = 1;
				((Globe) this).litab = -1;
				((Globe) this).openi = 10;
				((Globe) this).viewgame2 = 0;
				if (!((Globe) this).intclan.equals
				     (((Globe) this).conclan
				      [((Globe) this).eng])) {
				    ((Globe) this).intclan
					= (((Globe) this).conclan
					   [((Globe) this).eng]);
				    ((Globe) this).dispi = 0;
				    ((Globe) this).nil = 0;
				    ((Globe) this).lastint = "";
				    ((Globe) this).readint = 1;
				}
				((Globe) this).redif = true;
				((Globe) this).intsel = 4;
				((Globe) this).eng = -1;
				((Globe) this).spos6 = ((Globe) this).lspos6w;
			    }
			    if (stringbutton(((Globe) this).rdo,
					     "   <  Back   ", 480, 110, 1, i,
					     i_94_, bool, 216, 139)) {
				((Globe) this).eng = -1;
				((Globe) this).spos6 = ((Globe) this).lspos6w;
			    }
			    ((Globe) this).darker = false;
			}
		    }
		} else
		    ((Globe) this).sdist = 0;
		if (((Globe) this).loadwstat == 0) {
		    ((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawString
			("Loading championship, please wait...",
			 280 - (((Globe) this).ftm.stringWidth
				("Loading championship, please wait...")) / 2,
			 140);
		}
		if (((Globe) this).loadwstat == -1) {
		    ((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawString
			("Failed to load championship, please try again later...",
			 (280
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to load championship, please try again later..."))
			     / 2)),
			 140);
		}
	    }
	    if (((Globe) this).ntab == 2) {
		((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		((Globe) this).rdo.setColor(new Color(0, 0, 0));
		((Globe) this).rdo.drawString
		    ("About the Championship",
		     280 - ((Globe) this).ftm
			       .stringWidth("About the Championship") / 2,
		     40);
		((Globe) this).rdo.setFont(new Font("Tahoma", 0, 11));
		((Globe) this).rdo.drawString
		    ("The clan wars world championship is ongoing championship that does not end!",
		     7, 70);
		((Globe) this).rdo.drawString
		    ("Every clan always has a chance to claim & re-claim the championship title from the current winner.",
		     7, 85);
		((Globe) this).rdo.drawString
		    ("The champion clan is the clan that is at the current moment attaining the most points.",
		     7, 115);
		((Globe) this).rdo.drawString
		    ("Clans get points by defeating other clans in wars, but not every clan you defeat earns you the same amount of",
		     7, 130);
		((Globe) this).rdo.drawString
		    ("points. It depends on how much points that clan has and from which wars where these points attained.",
		     7, 145);
		((Globe) this).rdo.drawString
		    ("The points system is designed to deliver a fair & balanced championship that is also fun, exiting and never ending!",
		     7, 160);
		((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).rdo.drawString
		    ("Currently there are no rewards in the game for claiming or re-claiming the championship title, but",
		     7, 190);
		((Globe) this).rdo.drawString
		    ("in the coming updates there will be rewards that can be used to 'super power' clan cars!",
		     7, 205);
		((Globe) this).rdo.setFont(new Font("Tahoma", 0, 11));
		((Globe) this).rdo.drawString
		    ("Stay tuned for the rewards system to come!", 7, 220);
		((Globe) this).rdo.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		((Globe) this).rdo.drawString
		    ("Good Luck!",
		     280 - ((Globe) this).ftm.stringWidth("Good Luck!") / 2,
		     250);
		((Globe) this).darker = true;
		if (stringbutton(((Globe) this).rdo, "   <  Back   ", 280, 280,
				 1, i, i_94_, bool, 216, 139))
		    ((Globe) this).ntab = 1;
		((Globe) this).darker = false;
	    }
	    if (((Globe) this).sdist != 0) {
		int i_134_ = 27;
		((Globe) this).rdo.setColor(color2k(200, 200, 200));
		((Globe) this).rdo.fillRect(540, 20, 17, 260);
		if (((Globe) this).mscro5 == 831) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 3, 17, 17);
		} else {
		    ((Globe) this).rdo.setColor(color2k(220, 220, 220));
		    ((Globe) this).rdo.fill3DRect(540, 3, 17, 17, true);
		}
		((Globe) this).rdo.drawImage((((xtGraphics) ((Globe) this).xt)
					      .asu),
					     545, 9, null);
		if (((Globe) this).mscro5 == 832) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 280, 17, 17);
		} else {
		    ((Globe) this).rdo.setColor(color2k(220, 220, 220));
		    ((Globe) this).rdo.fill3DRect(540, 280, 17, 17, true);
		}
		((Globe) this).rdo.drawImage((((xtGraphics) ((Globe) this).xt)
					      .asd),
					     545, 287, null);
		if (((Globe) this).lspos6 != ((Globe) this).spos6) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 20 + ((Globe) this).spos6,
						17, 31);
		} else {
		    if (((Globe) this).mscro5 == 831)
			((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fill3DRect(540,
						  20 + ((Globe) this).spos6,
						  17, 31, true);
		}
		((Globe) this).rdo.setColor(color2k(150, 150, 150));
		((Globe) this).rdo.drawLine(545, 33 + ((Globe) this).spos6,
					    551, 33 + ((Globe) this).spos6);
		((Globe) this).rdo.drawLine(545, 35 + ((Globe) this).spos6,
					    551, 35 + ((Globe) this).spos6);
		((Globe) this).rdo.drawLine(545, 37 + ((Globe) this).spos6,
					    551, 37 + ((Globe) this).spos6);
		if (((Globe) this).mscro5 > 800
		    && ((Globe) this).lspos6 != ((Globe) this).spos6)
		    ((Globe) this).lspos6 = ((Globe) this).spos6;
		if (bool) {
		    if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			&& i_94_ > 132 + i_134_ + ((Globe) this).spos6
			&& i_94_ < ((Globe) this).spos6 + i_134_ + 163)
			((Globe) this).mscro5 = i_94_ - ((Globe) this).spos6;
		    if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			&& i_94_ > 26 + i_134_ && i_94_ < 134 + i_134_)
			((Globe) this).mscro5 = 831;
		    if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			&& i_94_ > 390 + i_134_ && i_94_ < 411 + i_134_)
			((Globe) this).mscro5 = 832;
		    if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			&& i_94_ > 132 + i_134_ && i_94_ < 392 + i_134_) {
			((Globe) this).mscro5 = 152 + i_134_;
			((Globe) this).spos6 = i_94_ - ((Globe) this).mscro5;
		    }
		    int i_135_ = 2670 / ((Globe) this).sdist;
		    if (i_135_ < 1)
			i_135_ = 1;
		    if (((Globe) this).mscro5 == 831) {
			((Globe) this).spos6 -= i_135_;
			if (((Globe) this).spos6 > 229)
			    ((Globe) this).spos6 = 229;
			if (((Globe) this).spos6 < 0)
			    ((Globe) this).spos6 = 0;
			((Globe) this).lspos6 = ((Globe) this).spos6;
		    }
		    if (((Globe) this).mscro5 == 832) {
			((Globe) this).spos6 += i_135_;
			if (((Globe) this).spos6 > 229)
			    ((Globe) this).spos6 = 229;
			if (((Globe) this).spos6 < 0)
			    ((Globe) this).spos6 = 0;
			((Globe) this).lspos6 = ((Globe) this).spos6;
		    }
		    if (((Globe) this).mscro5 < 800) {
			((Globe) this).spos6 = i_94_ - ((Globe) this).mscro5;
			if (((Globe) this).spos6 > 229)
			    ((Globe) this).spos6 = 229;
			if (((Globe) this).spos6 < 0)
			    ((Globe) this).spos6 = 0;
		    }
		    if (((Globe) this).mscro5 == 825)
			((Globe) this).mscro5 = 925;
		} else if (((Globe) this).mscro5 != 825)
		    ((Globe) this).mscro5 = 825;
	    }
	    ((Globe) this).rd.drawImage(((Globe) this).gImage, 216, 139, null);
	}
	if (((Globe) this).cfase == 1) {
	    if (((xtGraphics) ((Globe) this).xt).logged) {
		if (((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.4F));
		    ((Globe) this).rd.setColor(new Color(255, 255, 255));
		    ((Globe) this).rd.fillRoundRect(232, 90, 527, 176, 20, 20);
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(232, 90, 527, 176, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    if (((Globe) this).flko % 4 != 0
			|| ((Globe) this).flko == 0)
			((Globe) this).rd.drawString
			    (((Globe) this).msg,
			     495 - ((Globe) this).ftm
				       .stringWidth(((Globe) this).msg) / 2,
			     120);
		    if (((Globe) this).flko != 0)
			((Globe) this).flko--;
		    ((Globe) this).rd.drawString
			("Clan name :",
			 462 - ((Globe) this).ftm.stringWidth("Clan name :"),
			 156);
		    ((Globe) this).donewc = true;
		    if (((Globe) this).em != 1) {
			if (stringbutton(((Globe) this).rd, "     Create     ",
					 495, 204, 0, i, i_94_, bool, 0, 0)) {
			    if (!((GameSparker) ((Globe) this).gs).temail
				     .getText
				     ().equals(""))
				((Globe) this).em = 1;
			    else {
				((Globe) this).msg
				    = "Please enter a clan name!";
				((Globe) this).flko = 45;
			    }
			}
			if (stringbutton(((Globe) this).rd, " Cancel ", 495,
					 244, 2, i, i_94_, bool, 0, 0))
			    ((Globe) this).cfase = 0;
		    } else
			((Globe) this).rd.drawString
			    ("Creating, please wait...",
			     (495
			      - (((Globe) this).ftm
				     .stringWidth("Creating, please wait...")
				 / 2)),
			     224);
		} else {
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.4F));
		    ((Globe) this).rd.setColor(new Color(255, 255, 255));
		    ((Globe) this).rd.fillRoundRect(232, 90, 527, 136, 20, 20);
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(232, 90, 527, 136, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("You are already a member of a clan (").append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     (").").toString(),
			 495 - (((Globe) this).ftm.stringWidth
				(new StringBuilder().append
				     ("You are already a member of a clan (")
				     .append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     (").").toString())) / 2,
			 120);
		    ((Globe) this).rd.drawString
			("You need to leave your clan first in order to create a new one.",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("You need to leave your clan first in order to create a new one."))
			     / 2)),
			 140);
		    if (stringbutton(((Globe) this).rd, "   OK   ", 495, 204,
				     0, i, i_94_, bool, 0, 0))
			((Globe) this).cfase = 0;
		}
	    } else {
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 0.4F));
		((Globe) this).rd.setColor(new Color(255, 255, 255));
		((Globe) this).rd.fillRoundRect(232, 90, 527, 176, 20, 20);
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 1.0F));
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawRoundRect(232, 90, 527, 176, 20, 20);
		((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		((Globe) this).rd.drawString
		    ("You are currently using a trial account.",
		     495 - (((Globe) this).ftm.stringWidth
			    ("You are currently using a trial account.")) / 2,
		     120);
		((Globe) this).rd.drawString
		    ("You need to upgrade to be able participate in any NFM clan activity.",
		     (495
		      - ((((Globe) this).ftm.stringWidth
			  ("You need to upgrade to be able participate in any NFM clan activity."))
			 / 2)),
		     140);
		((Globe) this).rd.setColor(new Color(206, 171, 98));
		((Globe) this).rd.fillRoundRect(405, 163, 180, 50, 20, 20);
		if (drawbutton(((xtGraphics) ((Globe) this).xt).upgrade, 495,
			       188, i, i_94_, bool))
		    ((Globe) this).gs.editlink(((xtGraphics)
						((Globe) this).xt).nickname,
					       true);
		if (stringbutton(((Globe) this).rd, " Cancel ", 495, 244, 2, i,
				 i_94_, bool, 0, 0))
		    ((Globe) this).cfase = 0;
	    }
	}
	if (((Globe) this).cfase == 2) {
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).flko % 4 != 0 || ((Globe) this).flko == 0)
		((Globe) this).rd.drawString
		    (((Globe) this).msg,
		     495 - (((Globe) this).ftm.stringWidth(((Globe) this).msg)
			    / 2),
		     60);
	    if (((Globe) this).flko != 0)
		((Globe) this).flko--;
	    ((Globe) this).rd.setComposite(AlphaComposite.getInstance(3,
								      0.2F));
	    ((Globe) this).rd.setColor(new Color(255, 255, 255));
	    ((Globe) this).rd.fillRoundRect(197, 73, 597, 371, 20, 20);
	    ((Globe) this).rd.setComposite(AlphaComposite.getInstance(3,
								      1.0F));
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.drawRoundRect(197, 73, 597, 371, 20, 20);
	    ((Globe) this).dosrch = true;
	    ((Globe) this).darker = true;
	    if (stringbutton(((Globe) this).rd, "   Search   ", 579, 104, 2, i,
			     i_94_, bool, 0, 0)) {
		if (!((GameSparker) ((Globe) this).gs).temail.getText()
			 .equals("")) {
		    ((Globe) this).em = 2;
		    ((Globe) this).smsg
			= new StringBuilder().append("Searching for '").append
			      (((GameSparker) ((Globe) this).gs).temail
				   .getText())
			      .append
			      ("' in clans...").toString();
		    ((Globe) this).nclns = 0;
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		} else {
		    ((Globe) this).msg = "Please enter a search phrase!";
		    ((Globe) this).flko = 45;
		}
	    }
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).rd.drawString(((Globe) this).smsg, 218, 135);
	    if (stringbutton(((Globe) this).rd, " <   Back to Main  ", 725, 60,
			     2, i, i_94_, bool, 0, 0))
		((Globe) this).cfase = 0;
	    ((Globe) this).darker = false;
	    ((Globe) this).rdo.setColor(new Color(206, 171, 98));
	    ((Globe) this).rdo.fillRect(0, 0, 560, 300);
	    ((Globe) this).sdist
		= (int) (((float) ((Globe) this).nclns - 4.5F) * 55.0F);
	    if (((Globe) this).sdist < 0 || ((Globe) this).nclns == 0)
		((Globe) this).sdist = 0;
	    ((Globe) this).scro = (int) ((float) ((Globe) this).spos5 / 229.0F
					 * (float) ((Globe) this).sdist);
	    ((Globe) this).rdo.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    for (int i_136_ = 0; i_136_ < ((Globe) this).nclns; i_136_++) {
		if (60 + i_136_ * 55 - ((Globe) this).scro > 0
		    && 20 + i_136_ * 55 - ((Globe) this).scro < 300) {
		    boolean bool_137_ = true;
		    if (i > 308 && i < 683
			&& i_94_ > 159 + i_136_ * 55 - ((Globe) this).scro
			&& i_94_ < 199 + i_136_ * 55 - ((Globe) this).scro) {
			((Globe) this).cur = 12;
			bool_137_ = false;
			if (bool) {
			    if (!((Globe) this).claname
				     .equals(((Globe) this).clanlo[i_136_])) {
				((Globe) this).claname
				    = ((Globe) this).clanlo[i_136_];
				((Globe) this).loadedc = false;
			    }
			    ((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = 0;
			    ((Globe) this).cfase = 3;
			    ((Globe) this).ctab = 0;
			}
		    }
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawRoundRect(92,
						     (20 + i_136_ * 55
						      - ((Globe) this).scro),
						     375, 40, 20, 20);
		    if (!drawl(((Globe) this).rdo,
			       new StringBuilder().append("#").append
				   (((Globe) this).clanlo[i_136_]).append
				   ("#").toString(),
			       105, 25 + i_136_ * 55 - ((Globe) this).scro,
			       bool_137_)
			|| !bool_137_)
			((Globe) this).rdo.drawString
			    (new StringBuilder().append("").append
				 (((Globe) this).clanlo[i_136_]).append
				 ("").toString(),
			     280 - (((Globe) this).ftm.stringWidth
				    (new StringBuilder().append("").append
					 (((Globe) this).clanlo[i_136_]).append
					 ("").toString())) / 2,
			     45 + i_136_ * 55 - ((Globe) this).scro);
		}
	    }
	    if (((Globe) this).sdist != 0) {
		int i_138_ = 27;
		((Globe) this).rdo.setColor(color2k(200, 200, 200));
		((Globe) this).rdo.fillRect(540, 20, 17, 260);
		if (((Globe) this).mscro5 == 831) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 3, 17, 17);
		} else {
		    ((Globe) this).rdo.setColor(color2k(220, 220, 220));
		    ((Globe) this).rdo.fill3DRect(540, 3, 17, 17, true);
		}
		((Globe) this).rdo.drawImage((((xtGraphics) ((Globe) this).xt)
					      .asu),
					     545, 9, null);
		if (((Globe) this).mscro5 == 832) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 280, 17, 17);
		} else {
		    ((Globe) this).rdo.setColor(color2k(220, 220, 220));
		    ((Globe) this).rdo.fill3DRect(540, 280, 17, 17, true);
		}
		((Globe) this).rdo.drawImage((((xtGraphics) ((Globe) this).xt)
					      .asd),
					     545, 287, null);
		if (((Globe) this).lspos5 != ((Globe) this).spos5) {
		    ((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fillRect(540, 20 + ((Globe) this).spos5,
						17, 31);
		} else {
		    if (((Globe) this).mscro5 == 831)
			((Globe) this).rdo.setColor(color2k(215, 215, 215));
		    ((Globe) this).rdo.fill3DRect(540,
						  20 + ((Globe) this).spos5,
						  17, 31, true);
		}
		((Globe) this).rdo.setColor(color2k(150, 150, 150));
		((Globe) this).rdo.drawLine(545, 33 + ((Globe) this).spos5,
					    551, 33 + ((Globe) this).spos5);
		((Globe) this).rdo.drawLine(545, 35 + ((Globe) this).spos5,
					    551, 35 + ((Globe) this).spos5);
		((Globe) this).rdo.drawLine(545, 37 + ((Globe) this).spos5,
					    551, 37 + ((Globe) this).spos5);
		if (((Globe) this).mscro5 > 800
		    && ((Globe) this).lspos5 != ((Globe) this).spos5)
		    ((Globe) this).lspos5 = ((Globe) this).spos5;
		if (bool) {
		    if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			&& i_94_ > 132 + i_138_ + ((Globe) this).spos5
			&& i_94_ < ((Globe) this).spos5 + i_138_ + 163)
			((Globe) this).mscro5 = i_94_ - ((Globe) this).spos5;
		    if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			&& i_94_ > 26 + i_138_ && i_94_ < 134 + i_138_)
			((Globe) this).mscro5 = 831;
		    if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			&& i_94_ > 390 + i_138_ && i_94_ < 411 + i_138_)
			((Globe) this).mscro5 = 832;
		    if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			&& i_94_ > 132 + i_138_ && i_94_ < 392 + i_138_) {
			((Globe) this).mscro5 = 152 + i_138_;
			((Globe) this).spos5 = i_94_ - ((Globe) this).mscro5;
		    }
		    int i_139_ = 2670 / ((Globe) this).sdist;
		    if (i_139_ < 1)
			i_139_ = 1;
		    if (((Globe) this).mscro5 == 831) {
			((Globe) this).spos5 -= i_139_;
			if (((Globe) this).spos5 > 229)
			    ((Globe) this).spos5 = 229;
			if (((Globe) this).spos5 < 0)
			    ((Globe) this).spos5 = 0;
			((Globe) this).lspos5 = ((Globe) this).spos5;
		    }
		    if (((Globe) this).mscro5 == 832) {
			((Globe) this).spos5 += i_139_;
			if (((Globe) this).spos5 > 229)
			    ((Globe) this).spos5 = 229;
			if (((Globe) this).spos5 < 0)
			    ((Globe) this).spos5 = 0;
			((Globe) this).lspos5 = ((Globe) this).spos5;
		    }
		    if (((Globe) this).mscro5 < 800) {
			((Globe) this).spos5 = i_94_ - ((Globe) this).mscro5;
			if (((Globe) this).spos5 > 229)
			    ((Globe) this).spos5 = 229;
			if (((Globe) this).spos5 < 0)
			    ((Globe) this).spos5 = 0;
		    }
		    if (((Globe) this).mscro5 == 825)
			((Globe) this).mscro5 = 925;
		} else if (((Globe) this).mscro5 != 825)
		    ((Globe) this).mscro5 = 825;
	    }
	    ((Globe) this).rd.drawImage(((Globe) this).gImage, 216, 139, null);
	}
	if (((Globe) this).cfase == 3) {
	    ((Globe) this).rd.setComposite(AlphaComposite.getInstance(3,
								      0.4F));
	    ((Globe) this).rd.setColor(new Color(255, 255, 255));
	    ((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
	    ((Globe) this).rd.setComposite(AlphaComposite.getInstance(3,
								      1.0F));
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    if (((Globe) this).loadedc) {
		int i_140_ = -1;
		for (int i_141_ = 0; i_141_ < ((Globe) this).nmb; i_141_++) {
		    if ((((Globe) this).member[i_141_].toLowerCase().equals
			 (((xtGraphics) ((Globe) this).xt).nickname
			      .toLowerCase()))
			&& (((Globe) this).mlevel[i_141_] == 7 || i_141_ == 0))
			i_140_ = i_141_;
		}
		boolean bool_142_ = false;
		if (i > 197 && i < 563 && i_94_ > 40 && i_94_ < 83
		    && ((Globe) this).editc == 0)
		    bool_142_ = true;
		boolean bool_143_
		    = drawl(((Globe) this).rd,
			    new StringBuilder().append("#").append
				(((Globe) this).claname).append
				("#").toString(),
			    206, 47, !bool_142_);
		if (!bool_143_ || bool_142_) {
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("Clan :  ").append
			     (((Globe) this).claname).append
			     ("").toString(),
			 381 - (((Globe) this).ftm.stringWidth
				(new StringBuilder().append("Clan :  ").append
				     (((Globe) this).claname).append
				     ("").toString())) / 2,
			 67);
		    if (i_140_ != -1) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString("Edit Logo", 505, 74);
			((Globe) this).rd.drawLine
			    (505, 76,
			     505 + ((Globe) this).ftm.stringWidth("Edit Logo"),
			     76);
			if (i > 505
			    && i < 505 + ((Globe) this).ftm
					     .stringWidth("Edit Logo")
			    && i_94_ > 62 && i_94_ < 77
			    && ((Globe) this).editc == 0) {
			    ((Globe) this).cur = 12;
			    if (bool) {
				((Globe) this).editc = 1;
				((Globe) this).msg = "Edit Clan's Logo Image";
				((Globe) this).flko = 0;
			    }
			}
		    }
		}
		((Globe) this).rd.drawLine(563, 40, 563, 83);
		((Globe) this).rd.drawLine(563, 83, 197, 83);
		if (stringbutton(((Globe) this).rd, "   <   Back to Main  ",
				 688, 69, 1, i, i_94_, bool, 0, 0))
		    ((Globe) this).cfase = 0;
		((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		int i_144_ = 220;
		int i_145_ = ((Globe) this).ftm.stringWidth("Members");
		if (((Globe) this).ctab != 0)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawString("Members", i_144_, 107);
		if (((Globe) this).ctab != 0)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		if (i > i_144_ && i < i_144_ + i_145_ && i_94_ > 90
		    && i_94_ < 109 && ((Globe) this).editc == 0) {
		    ((Globe) this).rd.drawLine(i_144_, 109, i_144_ + i_145_,
					       109);
		    ((Globe) this).cur = 12;
		    if (bool)
			((Globe) this).ctab = 0;
		}
		i_144_ += i_145_ + 20;
		i_145_ = ((Globe) this).ftm.stringWidth("Cars");
		if (((Globe) this).ctab != 2)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawString("Cars", i_144_, 107);
		if (((Globe) this).ctab != 2)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		if (i > i_144_ && i < i_144_ + i_145_ && i_94_ > 90
		    && i_94_ < 109 && ((Globe) this).editc == 0
		    && !((Globe) this).notclan) {
		    ((Globe) this).rd.drawLine(i_144_, 109, i_144_ + i_145_,
					       109);
		    ((Globe) this).cur = 12;
		    if (bool) {
			((Globe) this).ctab = 2;
			((Globe) this).loadedcars = -1;
		    }
		}
		i_144_ += i_145_ + 20;
		i_145_ = ((Globe) this).ftm.stringWidth("Stages");
		if (((Globe) this).ctab != 3)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawString("Stages", i_144_, 107);
		if (((Globe) this).ctab != 3)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		if (i > i_144_ && i < i_144_ + i_145_ && i_94_ > 90
		    && i_94_ < 109 && ((Globe) this).editc == 0
		    && !((Globe) this).notclan) {
		    ((Globe) this).rd.drawLine(i_144_, 109, i_144_ + i_145_,
					       109);
		    ((Globe) this).cur = 12;
		    if (bool) {
			((Globe) this).ctab = 3;
			((Globe) this).loadedstages = -1;
		    }
		}
		i_144_ += i_145_ + 20;
		i_145_ = ((Globe) this).ftm.stringWidth("Interact");
		if (((Globe) this).ctab != 1)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawString("Interact", i_144_, 107);
		if (((Globe) this).ctab != 1)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		if (i > i_144_ && i < i_144_ + i_145_ && i_94_ > 90
		    && i_94_ < 109 && ((Globe) this).editc == 0
		    && !((Globe) this).notclan) {
		    ((Globe) this).rd.drawLine(i_144_, 109, i_144_ + i_145_,
					       109);
		    ((Globe) this).cur = 12;
		    if (bool)
			((Globe) this).ctab = 1;
		}
		i_144_ += i_145_ + 20;
		i_145_ = ((Globe) this).ftm.stringWidth("Web Presence");
		if (((Globe) this).ctab != 4)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 0.6F));
		((Globe) this).rd.drawString("Web Presence", i_144_, 107);
		if (((Globe) this).ctab != 4)
		    ((Globe) this).rd
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		if (i > i_144_ && i < i_144_ + i_145_ && i_94_ > 90
		    && i_94_ < 109 && ((Globe) this).editc == 0
		    && !((Globe) this).notclan) {
		    ((Globe) this).rd.drawLine(i_144_, 109, i_144_ + i_145_,
					       109);
		    ((Globe) this).cur = 12;
		    if (bool) {
			((Globe) this).ctab = 4;
			((Globe) this).loadedlink = false;
		    }
		}
		((Globe) this).rdo.setColor(new Color(206, 171, 98));
		((Globe) this).rdo.fillRect(0, 0, 560, 300);
		if (((Globe) this).clanbgl)
		    ((Globe) this).rdo.drawImage(((Globe) this).clanbg, 0, 0,
						 null);
		if (((Globe) this).notclan) {
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    ((Globe) this).rdo.drawString
			("[  Clan Removed  ]",
			 280 - ((Globe) this).ftm
				   .stringWidth("[  Clan Removed  ]") / 2,
			 40);
		    ((Globe) this).rdo.drawString
			("This clan has been abandoned by its members and no longer exists...",
			 (280
			  - ((((Globe) this).ftm.stringWidth
			      ("This clan has been abandoned by its members and no longer exists..."))
			     / 2)),
			 140);
		}
		if (i_140_ != -1 && i > 216 && i < 776 && i_94_ > 92
		    && i_94_ < 412 && ((Globe) this).editc == 0) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString("Edit Background", 688, 107);
		    ((Globe) this).rd.drawLine
			(688, 109,
			 (688
			  + ((Globe) this).ftm.stringWidth("Edit Background")),
			 109);
		    if (i > 688
			&& i < 688 + ((Globe) this).ftm
					 .stringWidth("Edit Background")
			&& i_94_ > 95 && i_94_ < 110
			&& ((Globe) this).editc == 0) {
			((Globe) this).cur = 12;
			if (bool) {
			    ((Globe) this).editc = 2;
			    ((Globe) this).msg
				= "Edit Clan's Background Display Image";
			    ((Globe) this).flko = 0;
			}
		    }
		}
		if (((Globe) this).ctab == 0) {
		    if (!((Globe) this).showreqs) {
			((Globe) this).sdist
			    = (int) (((float) ((Globe) this).nmb - 4.0F)
				     * 55.0F);
			if (((Globe) this).sdist < 0 || ((Globe) this).nmb < 5)
			    ((Globe) this).sdist = 0;
		    } else {
			((Globe) this).sdist
			    = (int) (((float) ((Globe) this).nrmb - 4.0F)
				     * 40.0F);
			if (((Globe) this).sdist < 0)
			    ((Globe) this).sdist = 0;
		    }
		}
		if (((Globe) this).ctab == 1 || ((Globe) this).ctab == 2
		    || ((Globe) this).ctab == 3 || ((Globe) this).ctab == 4) {
		    ((Globe) this).sdist = 0;
		    if (((Globe) this).sdist < 0)
			((Globe) this).sdist = 0;
		}
		((Globe) this).scro
		    = (int) ((float) ((Globe) this).spos5 / 229.0F
			     * (float) ((Globe) this).sdist);
		if (((Globe) this).ctab == 0) {
		    if (!((Globe) this).showreqs) {
			int i_146_ = 0;
			for (int i_147_ = 0; i_147_ < ((Globe) this).nmb;
			     i_147_++) {
			    boolean bool_148_ = false;
			    for (int i_149_ = 0; i_149_ < ((Globe) this).npo;
				 i_149_++) {
				if (((Globe) this).member[i_147_].toLowerCase
					().equals
				    (((Globe) this).pname[i_149_]
					 .toLowerCase())) {
				    bool_148_ = true;
				    i_146_++;
				}
			    }
			    if (60 + i_147_ * 55 - ((Globe) this).scro > 0
				&& (20 + i_147_ * 55 - ((Globe) this).scro
				    < 300)) {
				int i_150_ = 0;
				float f = 0.5F;
				if (i > 266 && i < 726
				    && i_94_ > (132 + i_147_ * 55
						- ((Globe) this).scro)
				    && i_94_ < (172 + i_147_ * 55
						- ((Globe) this).scro)
				    && ((Globe) this).editc == 0) {
				    f = 0.8F;
				    if (i_147_ >= i_140_ && i_140_ != -1)
					i_150_ = 1;
				    if ((((xtGraphics) ((Globe) this).xt)
					     .nickname.toLowerCase
					     ().equals
					 (((Globe) this).member[i_147_]
					      .toLowerCase()))
					&& i_150_ == 0)
					i_150_ = 2;
				}
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, f));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRoundRect
				    (50,
				     20 + i_147_ * 55 - ((Globe) this).scro,
				     460, 40, 20, 20);
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				if (bool_148_)
				    ((Globe) this).rdo
					.setColor(new Color(123, 200, 0));
				((Globe) this).rdo.drawRoundRect
				    (50,
				     20 + i_147_ * 55 - ((Globe) this).scro,
				     460, 40, 20, 20);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				boolean bool_151_ = false;
				boolean bool_152_ = false;
				if (i > 276 && i < 396
				    && i_94_ > (137 + i_147_ * 55
						- ((Globe) this).scro)
				    && i_94_ < (167 + i_147_ * 55
						- ((Globe) this).scro)
				    && i_94_ > 112 && i_94_ < 412
				    && ((Globe) this).editc == 0) {
				    bool_152_ = true;
				    ((Globe) this).cur = 12;
				    if (bool) {
					((Globe) this).tab = 1;
					if (!((Globe) this).proname.equals
					     (((Globe) this).member[i_147_])) {
					    ((Globe) this).proname
						= (((Globe) this).member
						   [i_147_]);
					    ((Globe) this).loadedp = false;
					    onexitpro();
					}
				    }
				}
				if (!bool_152_)
				    bool_151_
					= drawl(((Globe) this).rdo,
						((Globe) this).member[i_147_],
						60,
						(25 + i_147_ * 55
						 - ((Globe) this).scro),
						true);
				else
				    drawl(((Globe) this).rdo,
					  ((Globe) this).member[i_147_], 60,
					  (25 + i_147_ * 55
					   - ((Globe) this).scro),
					  false);
				if (!bool_151_) {
				    ((Globe) this).rdo.setComposite
					(AlphaComposite.getInstance(3, 0.5F));
				    ((Globe) this).rdo
					.setColor(new Color(255, 255, 255));
				    ((Globe) this).rdo.fillRect
					(60, (25 + i_147_ * 55
					      - ((Globe) this).scro), 119, 29);
				    ((Globe) this).rdo.setComposite
					(AlphaComposite.getInstance(3, 1.0F));
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    ((Globe) this).rdo
					.setFont(new Font("Arial", 1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rdo.getFontMetrics();
				    ((Globe) this).rdo.drawRect
					(60, (25 + i_147_ * 55
					      - ((Globe) this).scro), 119, 29);
				    ((Globe) this).rdo.drawString
					(((Globe) this).member[i_147_],
					 120 - (((Globe) this).ftm.stringWidth
						(((Globe) this).member
						 [i_147_])) / 2,
					 (44 + i_147_ * 55
					  - ((Globe) this).scro));
				}
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    11));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				String string = "";
				if (i_147_ == 0)
				    string = "  ( Clan Leader / Admin )";
				else if (((Globe) this).mlevel[i_147_] == 7)
				    string = "  ( Admin )";
				((Globe) this).rdo.drawString
				    (new StringBuilder().append
					 ("Level :  ").append
					 (((Globe) this).mlevel[i_147_]).append
					 ("").append
					 (string).append
					 ("").toString(),
				     190,
				     36 + i_147_ * 55 - ((Globe) this).scro);
				((Globe) this).rdo.drawString
				    (new StringBuilder().append("Rank :  ")
					 .append
					 (((Globe) this).mrank[i_147_]).append
					 ("").toString(),
				     190,
				     52 + i_147_ * 55 - ((Globe) this).scro);
				if (i_150_ != 0) {
				    if (i_150_ == 1) {
					((Globe) this).rdo.drawString
					    ("Edit", 424,
					     (36 + i_147_ * 55
					      - ((Globe) this).scro));
					((Globe) this).rdo.drawLine
					    (424,
					     (38 + i_147_ * 55
					      - ((Globe) this).scro),
					     424 + ((Globe) this).ftm
						       .stringWidth("Edit"),
					     (38 + i_147_ * 55
					      - ((Globe) this).scro));
					if (i > 640
					    && i < (640
						    + ((Globe) this).ftm
							  .stringWidth("Edit"))
					    && i_94_ > (136 + i_147_ * 55
							- ((Globe) this).scro)
					    && i_94_ < (151 + i_147_ * 55
							- ((Globe) this).scro)
					    && ((Globe) this).editc == 0) {
					    ((Globe) this).cur = 12;
					    if (bool) {
						((Globe) this).em = i_147_;
						((Globe) this).editc = 3;
					    }
					}
				    }
				    String string_153_ = "Remove";
				    if (((xtGraphics) ((Globe) this).xt)
					    .nickname.toLowerCase
					    ().equals
					(((Globe) this).member[i_147_]
					     .toLowerCase()))
					string_153_ = "Leave";
				    ((Globe) this).rdo.drawString
					(string_153_, 454,
					 (36 + i_147_ * 55
					  - ((Globe) this).scro));
				    ((Globe) this).rdo.drawLine
					(454,
					 (38 + i_147_ * 55
					  - ((Globe) this).scro),
					 454 + ((Globe) this).ftm
						   .stringWidth(string_153_),
					 (38 + i_147_ * 55
					  - ((Globe) this).scro));
				    if (i > 670
					&& i < 670 + (((Globe) this).ftm
							  .stringWidth
						      (string_153_))
					&& i_94_ > (136 + i_147_ * 55
						    - ((Globe) this).scro)
					&& i_94_ < (151 + i_147_ * 55
						    - ((Globe) this).scro)
					&& ((Globe) this).editc == 0) {
					((Globe) this).cur = 12;
					if (bool) {
					    ((Globe) this).em = i_147_;
					    ((Globe) this).editc = 4;
					}
				    }
				} else if (bool_148_) {
				    ((Globe) this).rdo
					.setColor(new Color(49, 79, 0));
				    ((Globe) this).rdo.drawString
					("Online", 454,
					 (36 + i_147_ * 55
					  - ((Globe) this).scro));
				}
			    }
			}
			if (((Globe) this).nmb == 1 && i_140_ != -1) {
			    float f = 0.5F;
			    if (i > 266 && i < 726
				&& i_94_ > 187 - ((Globe) this).scro
				&& i_94_ < 287 - ((Globe) this).scro
				&& ((Globe) this).editc == 0)
				f = 0.8F;
			    ((Globe) this).rdo.setComposite
				(AlphaComposite.getInstance(3, f));
			    ((Globe) this).rdo.setColor(new Color(255, 255,
								  255));
			    ((Globe) this).rdo.fillRoundRect(50,
							     75 - ((Globe)
								   this).scro,
							     460, 100, 20, 20);
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawRoundRect(50,
							     75 - ((Globe)
								   this).scro,
							     460, 100, 20, 20);
			    ((Globe) this).rdo.setComposite
				(AlphaComposite.getInstance(3, 1.0F));
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								12));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append
				     ("Welcome to your clan ").append
				     (((Globe) this).claname).append
				     ("!").toString(),
				 60, 91 - ((Globe) this).scro);
			    ((Globe) this).rdo.drawString
				("Now you will need to invite other players to join this clan.",
				 60, 121 - ((Globe) this).scro);
			    ((Globe) this).rdo.drawString
				("To invite, visit a player's profile and in the clan area click 'Invite to Join...'.",
				 60, 136 - ((Globe) this).scro);
			    ((Globe) this).rdo.drawString
				("(That is if the player is not already a member of another clan).",
				 60, 151 - ((Globe) this).scro);
			    ((Globe) this).rdo.drawString
				("The maximum number of members a clan can have is 20.",
				 60, 166 - ((Globe) this).scro);
			} else if (((Globe) this).nmb > 1) {
			    ((Globe) this).rdo.setComposite
				(AlphaComposite.getInstance(3, 0.8F));
			    ((Globe) this).rdo.setColor(new Color(255, 255,
								  255));
			    ((Globe) this).rdo.fillRoundRect
				(212,
				 (20 + ((Globe) this).nmb * 55
				  - ((Globe) this).scro),
				 136, 27, 20, 20);
			    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
			    ((Globe) this).rdo.drawRoundRect
				(212,
				 (20 + ((Globe) this).nmb * 55
				  - ((Globe) this).scro),
				 136, 27, 20, 20);
			    ((Globe) this).rdo.setComposite
				(AlphaComposite.getInstance(3, 1.0F));
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append("").append
				     (i_146_).append
				     (" player(s) online").toString(),
				 280 - (((Globe) this).ftm.stringWidth
					(new StringBuilder().append("").append
					     (i_146_).append
					     (" player(s) online")
					     .toString())) / 2,
				 (37 + ((Globe) this).nmb * 55
				  - ((Globe) this).scro));
			}
		    } else {
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 0.8F));
			((Globe) this).rdo.setColor(new Color(244, 232, 204));
			((Globe) this).rdo.fillRoundRect
			    (70, 20 - ((Globe) this).scro, 420,
			     80 + ((Globe) this).nrmb * 40, 20, 20);
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawRoundRect
			    (70, 20 - ((Globe) this).scro, 420,
			     80 + ((Globe) this).nrmb * 40, 20, 20);
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 1.0F));
			((Globe) this).rdo.setFont(new Font("Arial", 1, 13));
			((Globe) this).ftm
			    = ((Globe) this).rdo.getFontMetrics();
			((Globe) this).rdo.drawString
			    ("Membership Requests",
			     280 - ((Globe) this).ftm
				       .stringWidth("Membership Requests") / 2,
			     45 - ((Globe) this).scro);
			((Globe) this).darker = true;
			for (int i_154_ = 0; i_154_ < ((Globe) this).nrmb;
			     i_154_++) {
			    boolean bool_155_ = false;
			    boolean bool_156_ = false;
			    if (i > 356 && i < 476
				&& (i_94_
				    > 172 + i_154_ * 40 - ((Globe) this).scro)
				&& (i_94_
				    < 202 + i_154_ * 55 - ((Globe) this).scro)
				&& i_94_ > 112 && i_94_ < 412
				&& ((Globe) this).editc == 0) {
				bool_156_ = true;
				((Globe) this).cur = 12;
				if (bool) {
				    ((Globe) this).tab = 1;
				    if (!((Globe) this).proname.equals
					 (((Globe) this).rmember[i_154_])) {
					((Globe) this).proname
					    = ((Globe) this).rmember[i_154_];
					((Globe) this).loadedp = false;
					onexitpro();
				    }
				}
			    }
			    if (!bool_156_)
				bool_155_
				    = drawl(((Globe) this).rdo,
					    ((Globe) this).rmember[i_154_],
					    140,
					    (60 + i_154_ * 40
					     - ((Globe) this).scro),
					    true);
			    else
				drawl(((Globe) this).rdo,
				      ((Globe) this).rmember[i_154_], 140,
				      60 + i_154_ * 40 - ((Globe) this).scro,
				      false);
			    if (!bool_155_) {
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.5F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRect(140,
							    (60 + i_154_ * 40
							     - (((Globe) this)
								.scro)),
							    119, 29);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.drawRect(140,
							    (60 + i_154_ * 40
							     - (((Globe) this)
								.scro)),
							    119, 29);
				((Globe) this).rdo.drawString
				    (((Globe) this).rmember[i_154_],
				     200 - ((((Globe) this).ftm.stringWidth
					     (((Globe) this).rmember[i_154_]))
					    / 2),
				     79 + i_154_ * 40 - ((Globe) this).scro);
			    }
			    if (stringbutton(((Globe) this).rdo, "  Approve  ",
					     310,
					     (79 + i_154_ * 40
					      - ((Globe) this).scro),
					     3, i, i_94_,
					     bool && ((Globe) this).editc == 0,
					     216, 112)) {
				((Globe) this).em = i_154_;
				((Globe) this).editc = 66;
			    }
			    if (stringbutton(((Globe) this).rdo, "  Deny  ",
					     391,
					     (79 + i_154_ * 40
					      - ((Globe) this).scro),
					     3, i, i_94_,
					     bool && ((Globe) this).editc == 0,
					     216, 112)) {
				((Globe) this).em = i_154_;
				((Globe) this).editc = 77;
			    }
			}
			if (stringbutton(((Globe) this).rdo,
					 "    Decide Later    ", 280,
					 (80 + ((Globe) this).nrmb * 40
					  - ((Globe) this).scro),
					 1, i, i_94_,
					 bool && ((Globe) this).editc == 0,
					 216, 112)) {
			    ((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = 0;
			    ((Globe) this).showreqs = false;
			}
			((Globe) this).darker = false;
		    }
		}
		if (((Globe) this).ctab == 1) {
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, 0.25F));
		    ((Globe) this).rdo.setColor(new Color(255, 255, 255));
		    ((Globe) this).rdo.fillRoundRect(20, 246, 520, 39, 20, 20);
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawRoundRect(20, 246, 520, 39, 20, 20);
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    if (((xtGraphics) ((Globe) this).xt).clan.toLowerCase()
			    .equals(((Globe) this).claname.toLowerCase())) {
			if (stringbutton
			    (((Globe) this).rdo,
			     "       Open your clan's discussion       ", 280,
			     270, -1, i, i_94_,
			     bool && !((GameSparker) ((Globe) this).gs).openm,
			     216, 112)) {
			    ((Globe) this).tab = 2;
			    ((Globe) this).itab = 2;
			    ((Globe) this).litab = -1;
			}
		    } else {
			if (stringbutton(((Globe) this).rdo,
					 new StringBuilder().append
					     ("       Declare war on ").append
					     (((Globe) this).claname).append
					     ("       ").toString(),
					 162, 270, -1, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112)) {
			    ((Globe) this).tab = 2;
			    ((Globe) this).itab = 1;
			    ((Globe) this).litab = -1;
			    ((Globe) this).openi = 10;
			    ((Globe) this).viewgame2 = 0;
			    if (!((Globe) this).intclan
				     .equals(((Globe) this).claname)) {
				((Globe) this).intclan
				    = ((Globe) this).claname;
				((Globe) this).dispi = 0;
				((Globe) this).nil = 0;
				((Globe) this).lastint = "";
				((Globe) this).readint = 1;
			    }
			    ((Globe) this).redif = true;
			    ((Globe) this).intsel = 4;
			}
			if (stringbutton(((Globe) this).rdo,
					 new StringBuilder().append
					     ("    Talk with ").append
					     (((Globe) this).claname).append
					     ("    ").toString(),
					 422, 270, -1, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112)) {
			    ((Globe) this).tab = 2;
			    ((Globe) this).itab = 1;
			    ((Globe) this).litab = -1;
			    ((Globe) this).openi = 10;
			    ((Globe) this).viewgame2 = 0;
			    if (!((Globe) this).intclan
				     .equals(((Globe) this).claname)) {
				((Globe) this).intclan
				    = ((Globe) this).claname;
				((Globe) this).dispi = 0;
				((Globe) this).nil = 0;
				((Globe) this).lastint = "";
				((Globe) this).readint = 1;
			    }
			}
		    }
		}
		if (((Globe) this).ctab == 3) {
		    if (((Globe) this).loadedstages != 1
			&& ((Globe) this).loadedstages != 5) {
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 0.7F));
			((Globe) this).rdo.setColor(new Color(255, 255, 255));
			((Globe) this).rdo.fillRoundRect(60, 70, 440, 100, 20,
							 20);
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawRoundRect(60, 70, 440, 100, 20,
							 20);
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 1.0F));
		    }
		    ((Globe) this).rdo.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    if (((Globe) this).loadedstages == -2)
			((Globe) this).rdo.drawString
			    ("Failed to load clan stages, connection error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load clan stages, connection error, try again later..."))
				 / 2)),
			     125);
		    if (((Globe) this).loadedstages == -1)
			((Globe) this).rdo.drawString
			    ("Loading clan stages, please wait...",
			     280 - ((((Globe) this).ftm.stringWidth
				     ("Loading clan stages, please wait..."))
				    / 2),
			     125);
		    if (((Globe) this).loadedstages == 0)
			((Globe) this).rdo.drawString
			    ("No custom clan stages have been added yet!",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("No custom clan stages have been added yet!"))
				 / 2)),
			     125);
		    if (((Globe) this).loadedstages == 2)
			((Globe) this).rdo.drawString
			    (new StringBuilder().append
				 ("Searching for and loading stages created by you,  ")
				 .append
				 (((Globe) this).perry).append
				 ("  ...").toString(),
			     (280
			      - (((Globe) this).ftm.stringWidth
				 (new StringBuilder().append
				      ("Searching for and loading stages created by you,  ")
				      .append
				      (((Globe) this).perry).append
				      ("  ...").toString())) / 2),
			     125);
		    if (((Globe) this).loadedstages == 3) {
			((Globe) this).rdo.drawString
			    ("Found no stages that can be added!",
			     280 - ((((Globe) this).ftm.stringWidth
				     ("Found no stages that can be added!"))
				    / 2),
			     95);
			((Globe) this).rdo.drawString
			    ("Found no stages created by you that also do not already belong to a clan.",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Found no stages created by you that also do not already belong to a clan."))
				 / 2)),
			     115);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 155,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = -1;
		    }
		    if (((Globe) this).loadedstages == 4) {
			((Globe) this).rdo.drawString
			    ("Failed to load stages created by you, connection error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load stages created by you, connection error, try again later..."))
				 / 2)),
			     110);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 140,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = -1;
		    }
		    if (((Globe) this).loadedstages == 6)
			((Globe) this).rdo.drawString
			    ("Adding stage to your clan's stages, please wait...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Adding stage to your clan's stages, please wait..."))
				 / 2)),
			     125);
		    if (((Globe) this).loadedstages == 7) {
			((Globe) this).rdo.drawString
			    ("Failed to add stage, server error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to add stage, server error, try again later..."))
				 / 2)),
			     110);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 140,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = -1;
		    }
		    if (((Globe) this).loadedstages == 8)
			((Globe) this).rdo.drawString
			    ("Removing stage from your clan's cars, please wait...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Removing stage from your clan's cars, please wait..."))
				 / 2)),
			     125);
		    if (((Globe) this).loadedstages == 9) {
			((Globe) this).rdo.drawString
			    ("Failed to remove stage, server error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to remove stage, server error, try again later..."))
				 / 2)),
			     110);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 140,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = -1;
		    }
		    if (((Globe) this).loadedstages == 10) {
			((Globe) this).rdo.drawString
			    ("Are you sure you want to remove this stage from your clan's stages?",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Are you sure you want to remove this stage from your clan's stages?"))
				 / 2)),
			     93);
			if (stringbutton(((Globe) this).rdo, "    Yes    ",
					 280, 128, -2, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = 8;
			if (stringbutton(((Globe) this).rdo, "  No  ", 280,
					 158, -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = 1;
		    }
		    if (((Globe) this).loadedstages == 5) {
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 0.7F));
			((Globe) this).rdo.setColor(new Color(255, 255, 255));
			((Globe) this).rdo.fillRoundRect(60, 58, 440, 162, 20,
							 20);
			((Globe) this).rdo.setColor(new Color(0, 0, 0));
			((Globe) this).rdo.drawRoundRect(60, 58, 440, 162, 20,
							 20);
			((Globe) this).rdo
			    .setComposite(AlphaComposite.getInstance(3, 1.0F));
			((Globe) this).rdo.drawString
			    ("Select a stage to add.",
			     280 - (((Globe) this).ftm
					.stringWidth("Select a stage to add.")
				    / 2),
			     80);
			((GameSparker) ((Globe) this).gs).clcars.move
			    (496 - ((GameSparker) ((Globe) this).gs).clcars
				       .getWidth() / 2,
			     206);
			if (((Globe) this).editc == 0) {
			    if (!((GameSparker) ((Globe) this).gs).clcars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).clcars
				    .show();
				((GameSparker) ((Globe) this).gs).clcars
				    .select(0);
			    }
			} else
			    ((GameSparker) ((Globe) this).gs).clcars.hide();
			if (!((GameSparker) ((Globe) this).gs).clcars
				 .getSelectedItem
				 ().equals(((Globe) this).selstage))
			    ((Globe) this).selstage
				= ((GameSparker) ((Globe) this).gs).clcars
				      .getSelectedItem();
			if (((Smenu) ((GameSparker) ((Globe) this).gs).clcars)
			    .open)
			    ((Globe) this).blocknote = 20;
			if (stringbutton(((Globe) this).rdo,
					 "     Add Stage     ", 280, 150, -2,
					 i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = 6;
			if (stringbutton(((Globe) this).rdo, "  Cancel  ", 280,
					 200, -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedstages = -1;
		    }
		    if (((Globe) this).loadedstages == 1) {
			if (((Globe) this).editc == 0) {
			    if (!((GameSparker) ((Globe) this).gs).clcars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).clcars
				    .show();
				((Globe) this).selstage
				    = ((GameSparker) ((Globe) this).gs)
					  .clcars.getSelectedItem();
			    }
			} else
			    ((GameSparker) ((Globe) this).gs).clcars.hide();
			((GameSparker) ((Globe) this).gs).clcars.move
			    (496 - ((GameSparker) ((Globe) this).gs).clcars
				       .getWidth() / 2,
			     122);
			if (!((GameSparker) ((Globe) this).gs).clcars
				 .getSelectedItem
				 ().equals(((Globe) this).selstage)) {
			    ((Globe) this).selstage
				= ((GameSparker) ((Globe) this).gs).clcars
				      .getSelectedItem();
			    ((Globe) this).loadedstage = 0;
			    ((Globe) this).addstage = 0;
			}
			if (((Smenu) ((GameSparker) ((Globe) this).gs).clcars)
			    .open)
			    ((Globe) this).blocknote = 20;
			if (!((Globe) this).selstage.equals("Select Stage")) {
			    if (((Globe) this).loadedstage > 0) {
				((Medium) ((Globe) this).m).trk = 3;
				((Medium) ((Globe) this).m).ih = 0;
				((Medium) ((Globe) this).m).iw = 0;
				((Medium) ((Globe) this).m).h = 300;
				((Medium) ((Globe) this).m).w = 560;
				((Medium) ((Globe) this).m).cx = 280;
				((Medium) ((Globe) this).m).cy = 150;
				((Globe) this).m
				    .aroundtrack(((Globe) this).cp);
				((Globe) this).rdo.setRenderingHint
				    (RenderingHints.KEY_ANTIALIASING,
				     RenderingHints.VALUE_ANTIALIAS_OFF);
				int i_157_ = 0;
				int[] is = new int[200];
				for (int i_158_ = 0;
				     (i_158_
				      < ((GameSparker) ((Globe) this).gs).nob);
				     i_158_++) {
				    if ((((ContO) ((Globe) this).co[i_158_])
					 .dist)
					!= 0) {
					is[i_157_] = i_158_;
					i_157_++;
				    } else
					((Globe) this).co[i_158_]
					    .d(((Globe) this).rdo);
				}
				int[] is_159_ = new int[i_157_];
				for (int i_160_ = 0; i_160_ < i_157_; i_160_++)
				    is_159_[i_160_] = 0;
				for (int i_161_ = 0; i_161_ < i_157_;
				     i_161_++) {
				    for (int i_162_ = i_161_ + 1;
					 i_162_ < i_157_; i_162_++) {
					if (((ContO) (((Globe) this).co
						      [is[i_161_]])).dist
					    != ((ContO) (((Globe) this).co
							 [is[i_162_]])).dist) {
					    if (((ContO) (((Globe) this).co
							  [is[i_161_]])).dist
						< (((ContO) (((Globe) this).co
							     [is[i_162_]]))
						   .dist))
						is_159_[i_161_]++;
					    else
						is_159_[i_162_]++;
					} else if (i_162_ > i_161_)
					    is_159_[i_161_]++;
					else
					    is_159_[i_162_]++;
				    }
				}
				for (int i_163_ = 0; i_163_ < i_157_;
				     i_163_++) {
				    for (int i_164_ = 0; i_164_ < i_157_;
					 i_164_++) {
					if (is_159_[i_164_] == i_163_)
					    ((Globe) this).co[is[i_164_]]
						.d(((Globe) this).rdo);
				    }
				}
				((Globe) this).rdo.setRenderingHint
				    (RenderingHints.KEY_ANTIALIASING,
				     RenderingHints.VALUE_ANTIALIAS_ON);
				((Medium) ((Globe) this).m).trk = 0;
				((Medium) ((Globe) this).m).h = 450;
				((Medium) ((Globe) this).m).w = 800;
				((Medium) ((Globe) this).m).cx = 400;
				((Medium) ((Globe) this).m).cy = 225;
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.5F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRoundRect(9, 44, 136,
								 39, 20, 20);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Created/Published by", 17, 59);
				int i_165_
				    = (17
				       + (((Globe) this).ftm.stringWidth
					  ("Created/Published by")) / 2
				       - (((Globe) this).ftm.stringWidth
					  (((CheckPoints) ((Globe) this).cp)
					   .maker)) / 2);
				int i_166_
				    = (i_165_
				       + (((Globe) this).ftm.stringWidth
					  (((CheckPoints) ((Globe) this).cp)
					   .maker)));
				((Globe) this).rdo.drawString(((CheckPoints)
							       (((Globe) this)
								.cp)).maker,
							      i_165_, 74);
				((Globe) this).rdo.drawLine(i_165_, 76, i_166_,
							    76);
				if (i > i_165_ + 216 && i < i_166_ + 216
				    && i_94_ > 174 && i_94_ < 188) {
				    ((Globe) this).cur = 12;
				    if (bool) {
					((Globe) this).tab = 1;
					if (!((Globe) this).proname.equals
					     (((CheckPoints) ((Globe) this).cp)
					      .maker)) {
					    ((Globe) this).proname
						= ((CheckPoints)
						   ((Globe) this).cp).maker;
					    ((Globe) this).loadedp = false;
					    onexitpro();
					}
				    }
				}
				if ((i_140_ != -1
				     || (((CheckPoints) ((Globe) this).cp)
					     .maker.toLowerCase
					     ().equals
					 (((xtGraphics) ((Globe) this).xt)
					      .nickname.toLowerCase())))
				    && stringbutton(((Globe) this).rdo,
						    " Remove X ", 510, 27, -3,
						    i, i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Globe) this).loadedstages = 10;
				if ((((GameSparker) ((Globe) this).gs)
					 .clcars.getSelectedIndex()
				     != (((Smenu) ((GameSparker)
						   ((Globe) this).gs).clcars)
					 .no) - 1)
				    && stringbutton(((Globe) this).rdo,
						    " Next > ", 520, 137, -3,
						    i, i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Smenu) (((GameSparker) ((Globe) this).gs)
					      .clcars)).sel++;
				if (((GameSparker) ((Globe) this).gs)
					.clcars.getSelectedIndex() != 1
				    && stringbutton(((Globe) this).rdo,
						    " < Prev ", 40, 137, -3, i,
						    i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Smenu) (((GameSparker) ((Globe) this).gs)
					      .clcars)).sel--;
				if (((CheckPoints) ((Globe) this).cp).pubt
				    > 0) {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    if (((Globe) this).addstage == 2) {
					((Globe) this).rd.drawString
					    ("Adding Stage...",
					     496 - (((Globe) this).ftm
							.stringWidth
						    ("Adding Stage...")) / 2,
					     432);
					if ((((CarDefine) ((Globe) this).cd)
					     .staction)
					    == 0)
					    ((Globe) this).addstage = 3;
					if ((((CarDefine) ((Globe) this).cd)
					     .staction)
					    == -2)
					    ((Globe) this).addstage = 4;
					if ((((CarDefine) ((Globe) this).cd)
					     .staction)
					    == -3)
					    ((Globe) this).addstage = 5;
					if ((((CarDefine) ((Globe) this).cd)
					     .staction)
					    == -1)
					    ((Globe) this).addstage = 6;
				    }
				    if (((Globe) this).addstage == 3)
					((Globe) this).rd.drawString
					    (new StringBuilder().append
						 ("[").append
						 (((CarDefine)
						   ((Globe) this).cd).onstage)
						 .append
						 ("] has been added to your stages!")
						 .toString(),
					     (496
					      - (((Globe) this).ftm.stringWidth
						 (new StringBuilder().append
						      ("[").append
						      (((CarDefine)
							((Globe) this).cd)
						       .onstage)
						      .append
						      ("] has been added to your stages!")
						      .toString())) / 2),
					     432);
				    if (((Globe) this).addstage == 4)
					((Globe) this).rd.drawString
					    ("You already have this stage.",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("You already have this stage."))
						 / 2)),
					     432);
				    if (((Globe) this).addstage == 5)
					((Globe) this).rd.drawString
					    ("Cannot add more then 20 stages to your account!",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Cannot add more then 20 stages to your account!"))
						 / 2)),
					     432);
				    if (((Globe) this).addstage == 6)
					((Globe) this).rd.drawString
					    ("Failed to add stage!  Unknown error, please try again later.",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Failed to add stage!  Unknown error, please try again later."))
						 / 2)),
					     432);
				    if (((Globe) this).addstage == 1) {
					String string
					    = "Upgrade to a full account to add custom stages!";
					int i_167_
					    = (496
					       - ((Globe) this).ftm
						     .stringWidth(string) / 2);
					int i_168_
					    = (i_167_
					       + ((Globe) this).ftm
						     .stringWidth(string));
					((Globe) this).rd
					    .drawString(string, i_167_, 432);
					if (((Globe) this).waitlink != -1)
					    ((Globe) this).rd.drawLine(i_167_,
								       435,
								       i_168_,
								       435);
					if (i > i_167_ && i < i_168_
					    && i_94_ > 421 && i_94_ < 435) {
					    if (((Globe) this).waitlink != -1)
						((Globe) this).cur = 12;
					    if (bool
						&& (((Globe) this).waitlink
						    == 0)) {
						((Globe) this).gs.editlink
						    ((((xtGraphics)
						       ((Globe) this).xt)
						      .nickname),
						     true);
						((Globe) this).waitlink = -1;
					    }
					}
					if (((Globe) this).waitlink > 0)
					    ((Globe) this).waitlink--;
				    }
				    if (((Globe) this).addstage == 0
					&& (((Globe) this).xt.drawcarb
					    (true, null, " Add to My Stages ",
					     437, 414, i, i_94_,
					     bool && (((Globe) this).blocknote
						      == 0)))) {
					if (((xtGraphics) ((Globe) this).xt)
					    .logged) {
					    ((CarDefine) ((Globe) this).cd)
						.onstage
						= ((Globe) this).selstage;
					    ((CarDefine) ((Globe) this).cd)
						.staction
						= 2;
					    ((Globe) this).cd
						.sparkstageaction();
					    ((Globe) this).addstage = 2;
					} else {
					    ((Globe) this).addstage = 1;
					    ((Globe) this).waitlink = 20;
					}
				    }
				} else {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					("Private Stage",
					 (496
					  - (((Globe) this).ftm
						 .stringWidth("Private Stage")
					     / 2)),
					 432);
				}
			    }
			    if (((Globe) this).loadedstage == 0) {
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.7F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRoundRect(150, 100, 260,
								 40, 20, 20);
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawRoundRect(150, 100, 260,
								 40, 20, 20);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Loading...",
				     280 - ((Globe) this).ftm
					       .stringWidth("Loading...") / 2,
				     125);
			    }
			    if (((Globe) this).loadedstage == -1) {
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 0.7F));
				((Globe) this).rdo.setColor(new Color(255, 255,
								      255));
				((Globe) this).rdo.fillRoundRect(50, 100, 460,
								 40, 20, 20);
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawRoundRect(50, 100, 460,
								 40, 20, 20);
				((Globe) this).rdo.setComposite
				    (AlphaComposite.getInstance(3, 1.0F));
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Error loading stage, try again later...",
				     (280
				      - ((((Globe) this).ftm.stringWidth
					  ("Error loading stage, try again later..."))
					 / 2)),
				     125);
			    }
			}
		    }
		    if (((Globe) this).loadedstages != 1
			&& ((Globe) this).loadedstages != 5
			&& ((GameSparker) ((Globe) this).gs).clcars
			       .isShowing())
			((GameSparker) ((Globe) this).gs).clcars.hide();
		    if (((xtGraphics) ((Globe) this).xt).clan.toLowerCase()
			    .equals(((Globe) this).claname.toLowerCase())) {
			if (((Globe) this).loadedstages >= 0
			    && ((Globe) this).loadedstages < 2
			    && (stringbutton
				(((Globe) this).rdo,
				 "     Add a stage of yours to the clan's stages     ",
				 280, 286, -2, i, i_94_,
				 (bool
				  && !((GameSparker) ((Globe) this).gs).openm),
				 216, 112))) {
			    ((Globe) this).loadedstages = 2;
			    ((Globe) this).perry = "0 %";
			}
		    } else if (((Globe) this).loadedstages == 1
			       && !((Globe) this).selstage
				       .equals("Select Stage")
			       && ((Globe) this).loadedstage > 0
			       && (stringbutton
				   (((Globe) this).rdo,
				    "     Battle with clan over this stage!     ",
				    280, 286, -2, i, i_94_,
				    bool && !(((GameSparker) ((Globe) this).gs)
					      .openm),
				    216, 112))) {
			((Globe) this).tab = 2;
			((Globe) this).itab = 1;
			((Globe) this).litab = -1;
			((Globe) this).openi = 10;
			if (!((Globe) this).intclan
				 .equals(((Globe) this).claname)) {
			    ((Globe) this).intclan = ((Globe) this).claname;
			    ((Globe) this).dispi = 0;
			    ((Globe) this).nil = 0;
			    ((Globe) this).lastint = "";
			    ((Globe) this).readint = 1;
			}
			((Globe) this).redif = true;
			((Globe) this).intsel = 2;
		    }
		}
		if (((Globe) this).ctab == 2) {
		    float f = 0.7F;
		    if (((Globe) this).loadedcars == 1)
			f = 0.5F;
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, f));
		    ((Globe) this).rdo.setColor(new Color(255, 255, 255));
		    ((Globe) this).rdo.fillRoundRect(40, 20, 480, 245, 20, 20);
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawRoundRect(40, 20, 480, 245, 20, 20);
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    ((Globe) this).rdo.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
		    if (((Globe) this).loadedcars == -2)
			((Globe) this).rdo.drawString
			    ("Failed to load clan cars, connection error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load clan cars, connection error, try again later..."))
				 / 2)),
			     125);
		    if (((Globe) this).loadedcars == -1)
			((Globe) this).rdo.drawString
			    ("Loading clan cars, please wait...",
			     280 - (((Globe) this).ftm.stringWidth
				    ("Loading clan cars, please wait...")) / 2,
			     125);
		    if (((Globe) this).loadedcars == 0)
			((Globe) this).rdo.drawString
			    ("No custom clan cars have been added yet!",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("No custom clan cars have been added yet!"))
				 / 2)),
			     125);
		    if (((Globe) this).loadedcars == 2)
			((Globe) this).rdo.drawString
			    (new StringBuilder().append
				 ("Searching for and loading cars created by you,  ")
				 .append
				 (((Globe) this).perry).append
				 ("  ...").toString(),
			     (280
			      - (((Globe) this).ftm.stringWidth
				 (new StringBuilder().append
				      ("Searching for and loading cars created by you,  ")
				      .append
				      (((Globe) this).perry).append
				      ("  ...").toString())) / 2),
			     125);
		    if (((Globe) this).loadedcars == 3) {
			((Globe) this).rdo.drawString
			    ("Found no cars that can be added!",
			     280 - (((Globe) this).ftm.stringWidth
				    ("Found no cars that can be added!")) / 2,
			     105);
			((Globe) this).rdo.drawString
			    ("Found no cars created by you that also do not already belong to a clan.",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Found no cars created by you that also do not already belong to a clan."))
				 / 2)),
			     125);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 155,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = -1;
		    }
		    if (((Globe) this).loadedcars == 4) {
			((Globe) this).rdo.drawString
			    ("Failed to load cars created by you, connection error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load cars created by you, connection error, try again later..."))
				 / 2)),
			     125);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 155,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = -1;
		    }
		    if (((Globe) this).loadedcars == 6)
			((Globe) this).rdo.drawString
			    (new StringBuilder().append("Adding ").append
				 (((Globe) this).selcar).append
				 (" to your clan's cars, please wait...")
				 .toString(),
			     (280
			      - (((Globe) this).ftm.stringWidth
				 (new StringBuilder().append("Adding ").append
				      (((Globe) this).selcar).append
				      (" to your clan's cars, please wait...")
				      .toString())) / 2),
			     125);
		    if (((Globe) this).loadedcars == 7) {
			((Globe) this).rdo.drawString
			    ("Failed to add car, server error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to add car, server error, try again later..."))
				 / 2)),
			     125);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 155,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = -1;
		    }
		    if (((Globe) this).loadedcars == 8)
			((Globe) this).rdo.drawString
			    (new StringBuilder().append("Removing ").append
				 (((Globe) this).selcar).append
				 (" from your clan's cars, please wait...")
				 .toString(),
			     (280
			      - (((Globe) this).ftm.stringWidth
				 (new StringBuilder().append("Removing ")
				      .append
				      (((Globe) this).selcar).append
				      (" from your clan's cars, please wait...")
				      .toString())) / 2),
			     125);
		    if (((Globe) this).loadedcars == 9) {
			((Globe) this).rdo.drawString
			    ("Failed to remove car, server error, try again later...",
			     (280
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to remove car, server error, try again later..."))
				 / 2)),
			     125);
			if (stringbutton(((Globe) this).rdo, " OK ", 280, 155,
					 -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = -1;
		    }
		    if (((Globe) this).loadedcars == 10) {
			((Globe) this).rdo.drawString
			    (new StringBuilder().append
				 ("Are you sure you want to remove ").append
				 (((Globe) this).selcar).append
				 (" from your clan's cars?").toString(),
			     280 - (((Globe) this).ftm.stringWidth
				    (new StringBuilder().append
					 ("Are you sure you want to remove ")
					 .append
					 (((Globe) this).selcar).append
					 (" from your clan's cars?")
					 .toString())) / 2,
			     100);
			if (stringbutton(((Globe) this).rdo, "    Yes    ",
					 280, 135, -2, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = 8;
			if (stringbutton(((Globe) this).rdo, "  No  ", 280,
					 165, -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = 1;
		    }
		    if (((Globe) this).loadedcars == 5) {
			((Globe) this).rdo.drawString
			    ("Select a car to add.",
			     280 - (((Globe) this).ftm
					.stringWidth("Select a car to add.")
				    / 2),
			     80);
			((GameSparker) ((Globe) this).gs).clcars.move
			    (496 - ((GameSparker) ((Globe) this).gs).clcars
				       .getWidth() / 2,
			     206);
			if (((Globe) this).editc == 0) {
			    if (!((GameSparker) ((Globe) this).gs).clcars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).clcars
				    .show();
				((GameSparker) ((Globe) this).gs).clcars
				    .select(0);
			    }
			} else
			    ((GameSparker) ((Globe) this).gs).clcars.hide();
			if (!((GameSparker) ((Globe) this).gs).clcars
				 .getSelectedItem
				 ().equals(((Globe) this).selcar))
			    ((Globe) this).selcar
				= ((GameSparker) ((Globe) this).gs).clcars
				      .getSelectedItem();
			if (((Smenu) ((GameSparker) ((Globe) this).gs).clcars)
			    .open)
			    ((Globe) this).blocknote = 20;
			if (stringbutton(((Globe) this).rdo,
					 "     Add Car     ", 280, 150, -2, i,
					 i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = 6;
			if (stringbutton(((Globe) this).rdo, "  Cancel  ", 280,
					 200, -3, i, i_94_,
					 bool && !((GameSparker)
						   ((Globe) this).gs).openm,
					 216, 112))
			    ((Globe) this).loadedcars = -1;
		    }
		    if (((Globe) this).loadedcars == 1) {
			if (((Globe) this).editc == 0) {
			    if (!((GameSparker) ((Globe) this).gs).clcars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).clcars
				    .show();
				((Globe) this).selcar
				    = ((GameSparker) ((Globe) this).gs)
					  .clcars.getSelectedItem();
			    }
			} else
			    ((GameSparker) ((Globe) this).gs).clcars.hide();
			((GameSparker) ((Globe) this).gs).clcars.move
			    (496 - ((GameSparker) ((Globe) this).gs).clcars
				       .getWidth() / 2,
			     140);
			if (!((GameSparker) ((Globe) this).gs).clcars
				 .getSelectedItem
				 ().equals(((Globe) this).selcar)) {
			    ((Globe) this).selcar
				= ((GameSparker) ((Globe) this).gs).clcars
				      .getSelectedItem();
			    ((Globe) this).loadedcar = 0;
			    ((CarDefine) ((Globe) this).cd).action = 0;
			}
			if (((Smenu) ((GameSparker) ((Globe) this).gs).clcars)
			    .open)
			    ((Globe) this).blocknote = 20;
			if (!((Globe) this).selcar.equals("Select Car")) {
			    if (((Globe) this).loadedcar > 0) {
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Created/Published by", 63, 37);
				int i_169_
				    = (63
				       + (((Globe) this).ftm.stringWidth
					  ("Created/Published by")) / 2
				       - (((Globe) this).ftm.stringWidth
					  (((CarDefine) ((Globe) this).cd)
					   .createdby
					   [(19
					     + (((CarDefine) ((Globe) this).cd)
						.haltload))])) / 2);
				int i_170_
				    = (i_169_
				       + (((Globe) this).ftm.stringWidth
					  (((CarDefine) ((Globe) this).cd)
					   .createdby
					   [(19
					     + (((CarDefine) ((Globe) this).cd)
						.haltload))])));
				((Globe) this).rdo.drawString
				    ((((CarDefine) ((Globe) this).cd).createdby
				      [19 + (((CarDefine) ((Globe) this).cd)
					     .haltload)]),
				     i_169_, 52);
				((Globe) this).rdo.drawLine(i_169_, 54, i_170_,
							    54);
				if (i > i_169_ + 216 && i < i_170_ + 216
				    && i_94_ > 152 && i_94_ < 166) {
				    ((Globe) this).cur = 12;
				    if (bool) {
					((Globe) this).tab = 1;
					if (!((Globe) this).proname.equals
					     (((CarDefine) ((Globe) this).cd)
					      .createdby
					      [19 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)])) {
					    ((Globe) this).proname
						= (((CarDefine)
						    ((Globe) this).cd)
						   .createdby
						   [19 + (((CarDefine)
							   ((Globe) this).cd)
							  .haltload)]);
					    ((Globe) this).loadedp = false;
					    onexitpro();
					}
				    }
				}
				String string = "Class C";
				if ((((CarDefine) ((Globe) this).cd).cclass
				     [35 + (((CarDefine) ((Globe) this).cd)
					    .haltload)])
				    == 1)
				    string = "Class B&C";
				if ((((CarDefine) ((Globe) this).cd).cclass
				     [35 + (((CarDefine) ((Globe) this).cd)
					    .haltload)])
				    == 2)
				    string = "Class B";
				if ((((CarDefine) ((Globe) this).cd).cclass
				     [35 + (((CarDefine) ((Globe) this).cd)
					    .haltload)])
				    == 3)
				    string = "Class A&B";
				if ((((CarDefine) ((Globe) this).cd).cclass
				     [35 + (((CarDefine) ((Globe) this).cd)
					    .haltload)])
				    == 4)
				    string = "Class A";
				((Globe) this).rdo.drawString
				    (string,
				     389 - ((Globe) this).ftm
					       .stringWidth(string) / 2,
				     45);
				if ((i_140_ != -1
				     || (((CarDefine) ((Globe) this).cd)
					     .createdby
					     [19 + (((CarDefine)
						     ((Globe) this).cd)
						    .haltload)]
					     .toLowerCase
					     ().equals
					 (((xtGraphics) ((Globe) this).xt)
					      .nickname.toLowerCase())))
				    && stringbutton(((Globe) this).rdo,
						    " Remove X ", 466, 45, -3,
						    i, i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Globe) this).loadedcars = 10;
				((Medium) ((Globe) this).m).crs = true;
				((Medium) ((Globe) this).m).focus_point = 400;
				((Medium) ((Globe) this).m).x = -335;
				((Medium) ((Globe) this).m).y = 0;
				((Medium) ((Globe) this).m).z = -50;
				((Medium) ((Globe) this).m).xz = 0;
				((Medium) ((Globe) this).m).zy = 20;
				((Medium) ((Globe) this).m).ground = -2000;
				((Medium) ((Globe) this).m).cx = 280;
				((Medium) ((Globe) this).m).cy = 150;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).z
				    = 1000;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).y
				    = (480
				       - ((ContO) (((Globe) this).bco
						   [35 + (((CarDefine)
							   ((Globe) this).cd)
							  .haltload)])).grat);
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).x
				    = -52;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).zy
				    = 0;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).xz
				    = ((Globe) this).mrot;
				((Globe) this).mrot -= 5;
				if (((Globe) this).mrot < -360)
				    ((Globe) this).mrot += 360;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).xy
				    = 0;
				((ContO)
				 (((Globe) this).bco
				  [35 + (((CarDefine) ((Globe) this).cd)
					 .haltload)])).wzy
				    -= 10;
				if (((ContO)
				     (((Globe) this).bco
				      [35 + (((CarDefine) ((Globe) this).cd)
					     .haltload)])).wzy
				    < -45)
				    ((ContO)
				     (((Globe) this).bco
				      [35 + (((CarDefine) ((Globe) this).cd)
					     .haltload)])).wzy
					+= 45;
				((Globe) this).rdo.setRenderingHint
				    (RenderingHints.KEY_ANTIALIASING,
				     RenderingHints.VALUE_ANTIALIAS_OFF);
				((Globe) this).bco
				    [35 + (((CarDefine) ((Globe) this).cd)
					   .haltload)]
				    .d(((Globe) this).rdo);
				((Globe) this).rdo.setRenderingHint
				    (RenderingHints.KEY_ANTIALIASING,
				     RenderingHints.VALUE_ANTIALIAS_ON);
				((Medium) ((Globe) this).m).cx = 400;
				((Medium) ((Globe) this).m).cy = 225;
				int i_171_ = 137;
				if (((xtGraphics) ((Globe) this).xt).sc[0]
				    == 35 + (((CarDefine) ((Globe) this).cd)
					     .haltload))
				    i_171_ = 255;
				if ((((GameSparker) ((Globe) this).gs)
					 .clcars.getSelectedIndex()
				     != (((Smenu) ((GameSparker)
						   ((Globe) this).gs).clcars)
					 .no) - 1)
				    && stringbutton(((Globe) this).rdo,
						    " Next > ", 476, i_171_,
						    -3, i, i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Smenu) (((GameSparker) ((Globe) this).gs)
					      .clcars)).sel++;
				if (((GameSparker) ((Globe) this).gs)
					.clcars.getSelectedIndex() != 1
				    && stringbutton(((Globe) this).rdo,
						    " < Prev ", 84, i_171_, -3,
						    i, i_94_,
						    bool && !((GameSparker)
							      (((Globe) this)
							       .gs)).openm,
						    216, 112))
				    ((Smenu) (((GameSparker) ((Globe) this).gs)
					      .clcars)).sel--;
				if ((((xtGraphics) ((Globe) this).xt).sc[0]
				     != 35 + (((CarDefine) ((Globe) this).cd)
					      .haltload))
				    || i < 256 || i > 736 || i_94_ < 132
				    || i_94_ > 377) {
				    ((Globe) this).rdo
					.setFont(new Font("Arial", 1, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rdo.getFontMetrics();
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    int i_172_ = -36;
				    int i_173_ = -181;
				    int i_174_ = -155;
				    ((Globe) this).rdo.drawString("Top Speed:",
								  98 + i_172_,
								  (343
								   + i_174_));
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 162 + i_172_, 337 + i_174_, null);
				    ((Globe) this).rdo.drawString
					("Acceleration:", 88 + i_172_,
					 358 + i_174_);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 162 + i_172_, 352 + i_174_, null);
				    ((Globe) this).rdo.drawString("Handling:",
								  110 + i_172_,
								  (373
								   + i_174_));
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 162 + i_172_, 367 + i_174_, null);
				    ((Globe) this).rdo.drawString("Stunts:",
								  495 + i_173_,
								  (343
								   + i_174_));
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 536 + i_173_, 337 + i_174_, null);
				    ((Globe) this).rdo.drawString("Strength:",
								  483 + i_173_,
								  (358
								   + i_174_));
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 536 + i_173_, 352 + i_174_, null);
				    ((Globe) this).rdo.drawString("Endurance:",
								  473 + i_173_,
								  (373
								   + i_174_));
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statb),
					 536 + i_173_, 367 + i_174_, null);
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    float f_175_
					= ((float) ((((CarDefine)
						      ((Globe) this).cd)
						     .swits
						     [35 + (((CarDefine)
							     ((Globe) this).cd)
							    .haltload)]
						     [2])
						    - 220)
					   / 90.0F);
				    if ((double) f_175_ < 0.2)
					f_175_ = 0.2F;
				    ((Globe) this).rdo.fillRect
					(((int) (162.0F + 156.0F * f_175_)
					  + i_172_),
					 337 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    f_175_
					= ((((CarDefine) ((Globe) this).cd)
					    .acelf
					    [35 + ((CarDefine)
						   ((Globe) this).cd).haltload]
					    [1])
					   * (((CarDefine) ((Globe) this).cd)
					      .acelf
					      [35 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)]
					      [0])
					   * (((CarDefine) ((Globe) this).cd)
					      .acelf
					      [35 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)]
					      [2])
					   * (((CarDefine) ((Globe) this).cd)
					      .grip
					      [35 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)])
					   / 7700.0F);
				    if (f_175_ > 1.0F)
					f_175_ = 1.0F;
				    ((Globe) this).rdo.fillRect
					(((int) (162.0F + 156.0F * f_175_)
					  + i_172_),
					 352 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    f_175_ = (((CarDefine) ((Globe) this).cd)
					      .dishandle
					      [35 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)]);
				    ((Globe) this).rdo.fillRect
					(((int) (162.0F + 156.0F * f_175_)
					  + i_172_),
					 367 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    f_175_
					= (((float) (((CarDefine)
						      ((Globe) this).cd)
						     .airc
						     [35 + (((CarDefine)
							     ((Globe) this).cd)
							    .haltload)])
					    * (((CarDefine) ((Globe) this).cd)
					       .airs
					       [35 + (((CarDefine)
						       ((Globe) this).cd)
						      .haltload)])
					    * (((CarDefine) ((Globe) this).cd)
					       .bounce
					       [35 + (((CarDefine)
						       ((Globe) this).cd)
						      .haltload)]))
					   + 28.0F) / 139.0F;
				    if (f_175_ > 1.0F)
					f_175_ = 1.0F;
				    ((Globe) this).rdo.fillRect
					(((int) (536.0F + 156.0F * f_175_)
					  + i_173_),
					 337 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    float f_176_ = 0.5F;
				    f_175_ = ((((CarDefine) ((Globe) this).cd)
					       .moment
					       [35 + (((CarDefine)
						       ((Globe) this).cd)
						      .haltload)])
					      + f_176_) / 2.6F;
				    if (f_175_ > 1.0F)
					f_175_ = 1.0F;
				    ((Globe) this).rdo.fillRect
					(((int) (536.0F + 156.0F * f_175_)
					  + i_173_),
					 352 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    f_175_ = (((CarDefine) ((Globe) this).cd)
					      .outdam
					      [35 + (((CarDefine)
						      ((Globe) this).cd)
						     .haltload)]);
				    ((Globe) this).rdo.fillRect
					(((int) (536.0F + 156.0F * f_175_)
					  + i_173_),
					 367 + i_174_,
					 (int) (156.0F * (1.0F - f_175_)
						+ 1.0F),
					 7);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 162 + i_172_, 337 + i_174_, null);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 162 + i_172_, 352 + i_174_, null);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 162 + i_172_, 367 + i_174_, null);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 536 + i_173_, 337 + i_174_, null);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 536 + i_173_, 352 + i_174_, null);
				    ((Globe) this).rdo.drawImage
					((((xtGraphics) ((Globe) this).xt)
					  .statbo),
					 536 + i_173_, 367 + i_174_, null);
				} else {
				    int i_177_ = -20;
				    int i_178_ = -220;
				    ((Globe) this).rdo
					.setFont(new Font("Arial", 1, 10));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rdo.drawString("Hue  | ",
								  97 + i_177_,
								  70);
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).brt,
					 137 + i_177_, 63, null);
				    ((Globe) this).rdo.drawString("Intensity",
								  121 + i_177_,
								  219);
				    ((Globe) this).rdo.drawString("Hue  | ",
								  647 + i_178_,
								  70);
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).brt,
					 687 + i_178_, 63, null);
				    ((Globe) this).rdo.drawString("Intensity",
								  671 + i_178_,
								  219);
				    for (int i_179_ = 0; i_179_ < 161;
					 i_179_++) {
					((Globe) this).rdo.setColor
					    (Color.getHSBColor
					     ((float) ((double) (float) i_179_
						       * 0.00625),
					      1.0F, 1.0F));
					((Globe) this).rdo.drawLine
					    (102 + i_177_, 75 + i_179_,
					     110 + i_177_, 75 + i_179_);
					if (i_179_ <= 128) {
					    ((Globe) this).rdo.setColor
						(Color.getHSBColor
						 (1.0F, 0.0F,
						  (float) (1.0
							   - ((double) (float) i_179_
							      * 0.00625))));
					    ((Globe) this).rdo.drawLine
						(137 + i_177_, 75 + i_179_,
						 145 + i_177_, 75 + i_179_);
					}
					((Globe) this).rdo.setColor
					    (Color.getHSBColor
					     ((float) ((double) (float) i_179_
						       * 0.00625),
					      1.0F, 1.0F));
					((Globe) this).rdo.drawLine
					    (652 + i_178_, 75 + i_179_,
					     660 + i_178_, 75 + i_179_);
					if (i_179_ <= 128) {
					    ((Globe) this).rdo.setColor
						(Color.getHSBColor
						 (1.0F, 0.0F,
						  (float) (1.0
							   - ((double) (float) i_179_
							      * 0.00625))));
					    ((Globe) this).rdo.drawLine
						(687 + i_178_, 75 + i_179_,
						 695 + i_178_, 75 + i_179_);
					}
				    }
				    for (int i_180_ = 0; i_180_ < 40;
					 i_180_++) {
					((Globe) this).rdo.setColor
					    (Color.getHSBColor
					     ((((xtGraphics) ((Globe) this).xt)
					       .arnp[0]),
					      (float) ((double) (float) i_180_
						       * 0.025),
					      1.0F - (((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[2])));
					((Globe) this).rdo.drawLine
					    (121 + i_180_ + i_177_, 224,
					     121 + i_180_ + i_177_, 230);
					((Globe) this).rdo.setColor
					    (Color.getHSBColor
					     ((((xtGraphics) ((Globe) this).xt)
					       .arnp[3]),
					      (float) ((double) (float) i_180_
						       * 0.025),
					      1.0F - (((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[5])));
					((Globe) this).rdo.drawLine
					    (671 + i_180_ + i_178_, 224,
					     671 + i_180_ + i_178_, 230);
				    }
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).arn,
					 110 + i_177_,
					 71 + (int) ((((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[0])
						     * 160.0F),
					 null);
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).arn,
					 145 + i_177_,
					 71 + (int) ((((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[2])
						     * 160.0F),
					 null);
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).arn,
					 660 + i_178_,
					 71 + (int) ((((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[3])
						     * 160.0F),
					 null);
				    ((Globe) this).rdo.drawImage
					(((xtGraphics) ((Globe) this).xt).arn,
					 695 + i_178_,
					 71 + (int) ((((xtGraphics)
						       ((Globe) this).xt)
						      .arnp[5])
						     * 160.0F),
					 null);
				    ((Globe) this).rdo.setColor(new Color(0, 0,
									  0));
				    ((Globe) this).rdo.fillRect
					((120 + i_177_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[1]
						   * 40.0F)),
					 222, 3, 3);
				    ((Globe) this).rdo.drawLine
					((121 + i_177_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[1]
						   * 40.0F)),
					 224,
					 (121 + i_177_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[1]
						   * 40.0F)),
					 230);
				    ((Globe) this).rdo.fillRect
					((120 + i_177_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[1]
						   * 40.0F)),
					 230, 3, 3);
				    ((Globe) this).rdo.fillRect
					((670 + i_178_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[4]
						   * 40.0F)),
					 222, 3, 3);
				    ((Globe) this).rdo.drawLine
					((671 + i_178_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[4]
						   * 40.0F)),
					 224,
					 (671 + i_178_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[4]
						   * 40.0F)),
					 230);
				    ((Globe) this).rdo.fillRect
					((670 + i_178_
					  + (int) (((xtGraphics)
						    ((Globe) this).xt).arnp[4]
						   * 40.0F)),
					 230, 3, 3);
				    if (bool) {
					if (((Globe) this).mouson == -1) {
					    ((Globe) this).mouson = -2;
					    if (i > 335 + i_177_
						&& i < 379 + i_177_
						&& i_94_ > 334 && i_94_ < 344)
						((Globe) this).mouson = 1;
					    if (i > 885 + i_178_
						&& i < 929 + i_178_
						&& i_94_ > 334 && i_94_ < 344)
						((Globe) this).mouson = 4;
					    if (i > 314 + i_177_
						&& i < 338 + i_177_
						&& i_94_ > 181 && i_94_ < 353
						&& ((Globe) this).mouson == -2)
						((Globe) this).mouson = 0;
					    if (i > 349 + i_177_
						&& i < 373 + i_177_
						&& i_94_ > 181 && i_94_ < 321
						&& ((Globe) this).mouson == -2)
						((Globe) this).mouson = 2;
					    if (i > 864 + i_178_
						&& i < 888 + i_178_
						&& i_94_ > 181 && i_94_ < 353
						&& ((Globe) this).mouson == -2)
						((Globe) this).mouson = 3;
					    if (i > 899 + i_178_
						&& i < 923 + i_178_
						&& i_94_ > 181 && i_94_ < 321
						&& ((Globe) this).mouson == -2)
						((Globe) this).mouson = 5;
					}
				    } else if (((Globe) this).mouson != -1)
					((Globe) this).mouson = -1;
				    if (((Globe) this).mouson >= 0
					&& ((Globe) this).mouson <= 5)
					((Globe) this).blocknote = 20;
				    if (((Globe) this).mouson == 0
					|| ((Globe) this).mouson == 2
					|| ((Globe) this).mouson == 3
					|| ((Globe) this).mouson == 5) {
					((xtGraphics) ((Globe) this).xt)
					    .arnp[((Globe) this).mouson]
					    = (float) ((double) ((float) i_94_
								 - 187.0F)
						       * 0.00625);
					if (((Globe) this).mouson == 2
					    || ((Globe) this).mouson == 5) {
					    if ((double) (((xtGraphics)
							   ((Globe) this).xt)
							  .arnp
							  [(((Globe) this)
							    .mouson)])
						> 0.8)
						((xtGraphics)
						 ((Globe) this).xt)
						    .arnp
						    [((Globe) this).mouson]
						    = 0.8F;
					} else if ((((xtGraphics)
						     ((Globe) this).xt)
						    .arnp
						    [((Globe) this).mouson])
						   > 1.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 1.0F;
					if ((((xtGraphics) ((Globe) this).xt)
					     .arnp[((Globe) this).mouson])
					    < 0.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 0.0F;
				    }
				    if (((Globe) this).mouson == 1) {
					((xtGraphics) ((Globe) this).xt)
					    .arnp[((Globe) this).mouson]
					    = (float) ((double) ((float) i
								 - (float) (337
									    + i_177_))
						       * 0.025);
					if ((((xtGraphics) ((Globe) this).xt)
					     .arnp[((Globe) this).mouson])
					    > 1.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 1.0F;
					if ((((xtGraphics) ((Globe) this).xt)
					     .arnp[((Globe) this).mouson])
					    < 0.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 0.0F;
				    }
				    if (((Globe) this).mouson == 4) {
					((xtGraphics) ((Globe) this).xt)
					    .arnp[((Globe) this).mouson]
					    = (float) ((double) ((float) i
								 - (float) (887
									    + i_178_))
						       * 0.025);
					if ((((xtGraphics) ((Globe) this).xt)
					     .arnp[((Globe) this).mouson])
					    > 1.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 1.0F;
					if ((((xtGraphics) ((Globe) this).xt)
					     .arnp[((Globe) this).mouson])
					    < 0.0F)
					    ((xtGraphics) ((Globe) this).xt)
						.arnp[((Globe) this).mouson]
						= 0.0F;
				    }
				    Color color
					= (Color.getHSBColor
					   ((((xtGraphics) ((Globe) this).xt)
					     .arnp[0]),
					    (((xtGraphics) ((Globe) this).xt)
					     .arnp[1]),
					    1.0F - (((xtGraphics)
						     ((Globe) this).xt)
						    .arnp[2])));
				    Color color_181_
					= (Color.getHSBColor
					   ((((xtGraphics) ((Globe) this).xt)
					     .arnp[3]),
					    (((xtGraphics) ((Globe) this).xt)
					     .arnp[4]),
					    1.0F - (((xtGraphics)
						     ((Globe) this).xt)
						    .arnp[5])));
				    for (int i_182_ = 0;
					 (i_182_
					  < (((ContO) ((Globe) this).bco[36])
					     .npl));
					 i_182_++) {
					if (((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).colnum
					    == 1) {
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[0]
						= ((xtGraphics)
						   ((Globe) this).xt).arnp[0];
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[1]
						= ((xtGraphics)
						   ((Globe) this).xt).arnp[1];
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[2]
						= 1.0F - (((xtGraphics)
							   ((Globe) this).xt)
							  .arnp[2]);
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[0]
						= color.getRed();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[1]
						= color.getGreen();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[2]
						= color.getBlue();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[0]
						= color.getRed();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[1]
						= color.getGreen();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[2]
						= color.getBlue();
					}
					if (((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).colnum
					    == 2) {
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[0]
						= ((xtGraphics)
						   ((Globe) this).xt).arnp[3];
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[1]
						= ((xtGraphics)
						   ((Globe) this).xt).arnp[4];
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).hsb[2]
						= 1.0F - (((xtGraphics)
							   ((Globe) this).xt)
							  .arnp[5]);
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[0]
						= color_181_.getRed();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[1]
						= color_181_.getGreen();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).c[2]
						= color_181_.getBlue();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[0]
						= color_181_.getRed();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[1]
						= color_181_.getGreen();
					    ((Plane)
					     (((ContO) ((Globe) this).bco[36])
					      .p[i_182_])).oc[2]
						= color_181_.getBlue();
					}
				    }
				    if (stringbutton(((Globe) this).rdo,
						     "    Play >    ", 280,
						     220, -1, i, i_94_,
						     bool && !((GameSparker)
							       (((Globe) this)
								.gs)).openm,
						     216, 112)) {
					((Globe) this).open = 450;
					((Globe) this).upo = false;
					((Globe) this).domon = false;
					onexit();
				    }
				}
				if (((xtGraphics) ((Globe) this).xt).clan
					.toLowerCase
					().equals
				    (((Globe) this).claname.toLowerCase())) {
				    if (((xtGraphics) ((Globe) this).xt).sc[0]
					!= 36) {
					if (stringbutton
					    (((Globe) this).rdo,
					     "     Switch to using clan cars     ",
					     280, 250, -2, i, i_94_,
					     bool && !(((GameSparker)
							((Globe) this).gs)
						       .openm),
					     216, 112)) {
					    ((xtGraphics) ((Globe) this).xt)
						.sc[0]
						= 36;
					    boolean bool_183_ = false;
					    for (int i_184_ = 0;
						 ((i_184_
						   < ((ContO) (((Globe) this)
							       .bco[36])).npl)
						  && !bool_183_);
						 i_184_++) {
						if (((Plane)
						     (((ContO)
						       ((Globe) this).bco[36])
						      .p[i_184_])).colnum
						    == 1) {
						    float[] fs = new float[3];
						    Color.RGBtoHSB
							((((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_184_])
							  .c[0]),
							 (((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_184_])
							  .c[1]),
							 (((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_184_])
							  .c[2]),
							 fs);
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[0]
							= fs[0];
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[1]
							= fs[1];
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[2]
							= 1.0F - fs[2];
						    bool_183_ = true;
						}
					    }
					    bool_183_ = false;
					    for (int i_185_ = 0;
						 ((i_185_
						   < ((ContO) (((Globe) this)
							       .bco[36])).npl)
						  && !bool_183_);
						 i_185_++) {
						if (((Plane)
						     (((ContO)
						       ((Globe) this).bco[36])
						      .p[i_185_])).colnum
						    == 2) {
						    float[] fs = new float[3];
						    Color.RGBtoHSB
							((((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_185_])
							  .c[0]),
							 (((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_185_])
							  .c[1]),
							 (((Plane)
							   ((ContO)
							    (((Globe) this).bco
							     [36])).p[i_185_])
							  .c[2]),
							 fs);
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[3]
							= fs[0];
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[4]
							= fs[1];
						    ((xtGraphics)
						     ((Globe) this).xt).arnp[5]
							= 1.0F - fs[2];
						    bool_183_ = true;
						}
					    }
					}
				    } else {
					((Globe) this).rdo
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rdo
						  .getFontMetrics();
					((Globe) this).rdo
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rdo.drawString
					    ("You are currently using your clan's cars.",
					     (280
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("You are currently using your clan's cars."))
						 / 2)),
					     250);
				    }
				}
				if ((((CarDefine) ((Globe) this).cd).publish
				     [19 + (((CarDefine) ((Globe) this).cd)
					    .haltload)])
				    > 0) {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    if (((CarDefine) ((Globe) this).cd).action
					== -9)
					((Globe) this).rd.drawString
					    ("Failed to add car!  Unknown error, please try again later.",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Failed to add car!  Unknown error, please try again later."))
						 / 2)),
					     432);
				    if (((CarDefine) ((Globe) this).cd).action
					== -8)
					((Globe) this).rd.drawString
					    ("Cannot add more then 20 cars to your account!",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("Cannot add more then 20 cars to your account!"))
						 / 2)),
					     432);
				    if (((CarDefine) ((Globe) this).cd).action
					== 7)
					((Globe) this).rd.drawString
					    (new StringBuilder().append
						 ("[").append
						 (((CarDefine)
						   ((Globe) this).cd).acname)
						 .append
						 ("] has been added to your cars!")
						 .toString(),
					     (496
					      - (((Globe) this).ftm.stringWidth
						 (new StringBuilder().append
						      ("[").append
						      (((CarDefine)
							((Globe) this).cd)
						       .acname)
						      .append
						      ("] has been added to your cars!")
						      .toString())) / 2),
					     432);
				    if (((CarDefine) ((Globe) this).cd).action
					== -7)
					((Globe) this).rd.drawString
					    ("You already have this car.",
					     (496
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("You already have this car."))
						 / 2)),
					     432);
				    if (((CarDefine) ((Globe) this).cd).action
					== 6)
					((Globe) this).rd.drawString
					    ("Adding Car...",
					     496 - (((Globe) this).ftm
							.stringWidth
						    ("Adding Car...")) / 2,
					     432);
				    if (((CarDefine) ((Globe) this).cd).action
					== -6) {
					String string_186_
					    = "Upgrade to a full account to add custom cars!";
					int i_187_
					    = (496
					       - (((Globe) this).ftm
						      .stringWidth(string_186_)
						  / 2));
					int i_188_
					    = i_187_ + (((Globe) this).ftm
							    .stringWidth
							(string_186_));
					((Globe) this).rd.drawString
					    (string_186_, i_187_, 432);
					if (((Globe) this).waitlink != -1)
					    ((Globe) this).rd.drawLine(i_187_,
								       435,
								       i_188_,
								       435);
					if (i > i_187_ && i < i_188_
					    && i_94_ > 421 && i_94_ < 435) {
					    if (((Globe) this).waitlink != -1)
						((Globe) this).cur = 12;
					    if (bool
						&& (((Globe) this).waitlink
						    == 0)) {
						((Globe) this).gs.editlink
						    ((((xtGraphics)
						       ((Globe) this).xt)
						      .nickname),
						     true);
						((Globe) this).waitlink = -1;
					    }
					}
					if (((Globe) this).waitlink > 0)
					    ((Globe) this).waitlink--;
				    }
				    if ((((CarDefine) ((Globe) this).cd).action
					 == 0)
					&& (((Globe) this).xt.drawcarb
					    (true, null, " Add to My Cars ",
					     437, 414, i, i_94_,
					     bool && (((Globe) this).blocknote
						      == 0)))) {
					if (((xtGraphics) ((Globe) this).xt)
					    .logged) {
					    ((CarDefine) ((Globe) this).cd)
						.action
						= 6;
					    ((CarDefine) ((Globe) this).cd).ac
						= -1;
					    ((CarDefine) ((Globe) this).cd)
						.acname
						= ((Globe) this).selcar;
					    ((Globe) this).cd
						.sparkactionloader();
					} else {
					    ((CarDefine) ((Globe) this).cd)
						.action
						= -6;
					    ((Globe) this).waitlink = 20;
					}
				    }
				} else {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					("Private Car",
					 496 - (((Globe) this).ftm
						    .stringWidth("Private Car")
						/ 2),
					 432);
				}
			    }
			    if (((Globe) this).loadedcar == 0) {
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Loading...",
				     280 - ((Globe) this).ftm
					       .stringWidth("Loading...") / 2,
				     125);
			    }
			    if (((Globe) this).loadedcar == -1) {
				((Globe) this).rdo.setFont(new Font("Arial", 1,
								    12));
				((Globe) this).ftm
				    = ((Globe) this).rdo.getFontMetrics();
				((Globe) this).rdo.setColor(new Color(0, 0,
								      0));
				((Globe) this).rdo.drawString
				    ("Error loading car, try again later...",
				     (280
				      - ((((Globe) this).ftm.stringWidth
					  ("Error loading car, try again later..."))
					 / 2)),
				     125);
			    }
			}
		    }
		    if (((Globe) this).loadedcars != 1
			&& ((Globe) this).loadedcars != 5
			&& ((GameSparker) ((Globe) this).gs).clcars
			       .isShowing())
			((GameSparker) ((Globe) this).gs).clcars.hide();
		    if (((xtGraphics) ((Globe) this).xt).clan.toLowerCase()
			    .equals(((Globe) this).claname.toLowerCase())) {
			if (((Globe) this).loadedcars >= 0
			    && ((Globe) this).loadedcars < 2
			    && (stringbutton
				(((Globe) this).rdo,
				 "     Add a car of yours to the clan's cars     ",
				 280, 286, -2, i, i_94_,
				 (bool
				  && !((GameSparker) ((Globe) this).gs).openm),
				 216, 112))) {
			    ((Globe) this).loadedcars = 2;
			    ((Globe) this).perry = "0 %";
			}
		    } else if (((Globe) this).loadedcars == 1
			       && !((Globe) this).selcar.equals("Select Car")
			       && ((Globe) this).loadedcar > 0
			       && (stringbutton
				   (((Globe) this).rdo,
				    "     Battle with clan over this car!     ",
				    280, 286, -2, i, i_94_,
				    bool && !(((GameSparker) ((Globe) this).gs)
					      .openm),
				    216, 112))) {
			((Globe) this).tab = 2;
			((Globe) this).itab = 1;
			((Globe) this).litab = -1;
			((Globe) this).openi = 10;
			if (!((Globe) this).intclan
				 .equals(((Globe) this).claname)) {
			    ((Globe) this).intclan = ((Globe) this).claname;
			    ((Globe) this).dispi = 0;
			    ((Globe) this).nil = 0;
			    ((Globe) this).lastint = "";
			    ((Globe) this).readint = 1;
			}
			((Globe) this).redif = true;
			((Globe) this).intsel = 3;
		    }
		}
		if (((Globe) this).ctab != 2 && ((Globe) this).ctab != 3
		    && ((GameSparker) ((Globe) this).gs).clcars.isShowing())
		    ((GameSparker) ((Globe) this).gs).clcars.hide();
		if (((Globe) this).ctab == 4) {
		    boolean bool_189_ = false;
		    if (i > 266 && i < 726 && i_94_ > 162 && i_94_ < 223
			&& ((Globe) this).editc == 0)
			bool_189_ = true;
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, 0.7F));
		    ((Globe) this).rdo.setColor(new Color(255, 255, 255));
		    ((Globe) this).rdo.fillRoundRect(50, 50, 460, 61, 20, 20);
		    ((Globe) this).rdo.setColor(new Color(0, 0, 0));
		    ((Globe) this).rdo.drawRoundRect(50, 50, 460, 61, 20, 20);
		    ((Globe) this).rdo
			.setComposite(AlphaComposite.getInstance(3, 1.0F));
		    if (((Globe) this).loadedlink) {
			if (i_140_ != -1 && bool_189_) {
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								11));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString("Edit", 480, 66);
			    ((Globe) this).rdo.drawLine
				(480, 68,
				 480 + ((Globe) this).ftm.stringWidth("Edit"),
				 68);
			    if (i > 696
				&& i < 696 + ((Globe) this).ftm
						 .stringWidth("Edit")
				&& i_94_ > 166 && i_94_ < 181
				&& ((Globe) this).editc == 0) {
				((Globe) this).cur = 12;
				if (bool) {
				    ((Globe) this).editc = 6;
				    ((Globe) this).msg
					= "Edit Clan's Web Presence";
				    ((Globe) this).flko = 0;
				    bool = false;
				}
			    }
			}
			if (!((Globe) this).ltit.equals("")
			    && !((Globe) this).lurl.equals("")) {
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								13));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString(((Globe) this).ltit,
							  70, 74);
			    if (bool_189_)
				((Globe) this).rdo.drawLine
				    (70, 76,
				     (70
				      + ((Globe) this).ftm
					    .stringWidth(((Globe) this).ltit)),
				     76);
			    ((Globe) this).rdo.setFont(new Font("Arial", 0,
								12));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString(((Globe) this).ldes,
							  70, 94);
			    if (bool_189_ && ((Globe) this).editc == 0) {
				((Globe) this).cur = 12;
				if (bool)
				    ((Globe) this).gs
					.openurl(((Globe) this).lurl);
			    }
			} else {
			    ((Globe) this).rdo.setFont(new Font("Arial", 1,
								12));
			    ((Globe) this).ftm
				= ((Globe) this).rdo.getFontMetrics();
			    ((Globe) this).rdo.drawString
				(new StringBuilder().append("").append
				     (((Globe) this).claname).append
				     (" has no external online presence.")
				     .toString(),
				 (280
				  - (((Globe) this).ftm.stringWidth
				     (new StringBuilder().append("").append
					  (((Globe) this).claname).append
					  (" has no external online presence.")
					  .toString())) / 2),
				 85);
			}
		    } else {
			((Globe) this).rdo.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rdo.getFontMetrics();
			((Globe) this).rdo.drawString
			    ("Loading...",
			     280 - ((Globe) this).ftm
				       .stringWidth("Loading...") / 2,
			     85);
		    }
		}
		if (((Globe) this).sdist != 0) {
		    ((Globe) this).rdo.setColor(color2k(200, 200, 200));
		    ((Globe) this).rdo.fillRect(540, 20, 17, 260);
		    if (((Globe) this).mscro5 == 831) {
			((Globe) this).rdo.setColor(color2k(215, 215, 215));
			((Globe) this).rdo.fillRect(540, 3, 17, 17);
		    } else {
			((Globe) this).rdo.setColor(color2k(220, 220, 220));
			((Globe) this).rdo.fill3DRect(540, 3, 17, 17, true);
		    }
		    ((Globe) this).rdo.drawImage(((xtGraphics)
						  ((Globe) this).xt).asu,
						 545, 9, null);
		    if (((Globe) this).mscro5 == 832) {
			((Globe) this).rdo.setColor(color2k(215, 215, 215));
			((Globe) this).rdo.fillRect(540, 280, 17, 17);
		    } else {
			((Globe) this).rdo.setColor(color2k(220, 220, 220));
			((Globe) this).rdo.fill3DRect(540, 280, 17, 17, true);
		    }
		    ((Globe) this).rdo.drawImage(((xtGraphics)
						  ((Globe) this).xt).asd,
						 545, 287, null);
		    if (((Globe) this).lspos5 != ((Globe) this).spos5) {
			((Globe) this).rdo.setColor(color2k(215, 215, 215));
			((Globe) this).rdo
			    .fillRect(540, 20 + ((Globe) this).spos5, 17, 31);
		    } else {
			if (((Globe) this).mscro5 == 831)
			    ((Globe) this).rdo.setColor(color2k(215, 215,
								215));
			((Globe) this).rdo.fill3DRect(540,
						      (20
						       + ((Globe) this).spos5),
						      17, 31, true);
		    }
		    ((Globe) this).rdo.setColor(color2k(150, 150, 150));
		    ((Globe) this).rdo.drawLine(545, 33 + ((Globe) this).spos5,
						551,
						33 + ((Globe) this).spos5);
		    ((Globe) this).rdo.drawLine(545, 35 + ((Globe) this).spos5,
						551,
						35 + ((Globe) this).spos5);
		    ((Globe) this).rdo.drawLine(545, 37 + ((Globe) this).spos5,
						551,
						37 + ((Globe) this).spos5);
		    if (((Globe) this).mscro5 > 800
			&& ((Globe) this).lspos5 != ((Globe) this).spos5)
			((Globe) this).lspos5 = ((Globe) this).spos5;
		    if (bool) {
			if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			    && i_94_ > 132 + ((Globe) this).spos5
			    && i_94_ < ((Globe) this).spos5 + 163)
			    ((Globe) this).mscro5
				= i_94_ - ((Globe) this).spos5;
			if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			    && i_94_ > 26 && i_94_ < 134)
			    ((Globe) this).mscro5 = 831;
			if (((Globe) this).mscro5 == 825 && i > 754 && i < 775
			    && i_94_ > 390 && i_94_ < 411)
			    ((Globe) this).mscro5 = 832;
			if (((Globe) this).mscro5 == 825 && i > 756 && i < 773
			    && i_94_ > 132 && i_94_ < 392) {
			    ((Globe) this).mscro5 = 152;
			    ((Globe) this).spos5
				= i_94_ - ((Globe) this).mscro5;
			}
			int i_190_ = 2670 / ((Globe) this).sdist;
			if (i_190_ < 1)
			    i_190_ = 1;
			if (((Globe) this).mscro5 == 831) {
			    ((Globe) this).spos5 -= i_190_;
			    if (((Globe) this).spos5 > 229)
				((Globe) this).spos5 = 229;
			    if (((Globe) this).spos5 < 0)
				((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = ((Globe) this).spos5;
			}
			if (((Globe) this).mscro5 == 832) {
			    ((Globe) this).spos5 += i_190_;
			    if (((Globe) this).spos5 > 229)
				((Globe) this).spos5 = 229;
			    if (((Globe) this).spos5 < 0)
				((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = ((Globe) this).spos5;
			}
			if (((Globe) this).mscro5 < 800) {
			    ((Globe) this).spos5
				= i_94_ - ((Globe) this).mscro5;
			    if (((Globe) this).spos5 > 229)
				((Globe) this).spos5 = 229;
			    if (((Globe) this).spos5 < 0)
				((Globe) this).spos5 = 0;
			}
			if (((Globe) this).mscro5 == 825)
			    ((Globe) this).mscro5 = 925;
		    } else if (((Globe) this).mscro5 != 825)
			((Globe) this).mscro5 = 825;
		}
		((Globe) this).rd.drawImage(((Globe) this).gImage, 216, 112,
					    null);
		if (((Globe) this).ctab != 2 && ((Globe) this).ctab != 3
		    && ((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		    boolean bool_191_ = false;
		    for (int i_192_ = 0; i_192_ < ((Globe) this).nmb;
			 i_192_++) {
			if (((xtGraphics) ((Globe) this).xt).nickname
				.toLowerCase
				().equals
			    (((Globe) this).member[i_192_].toLowerCase())) {
			    bool_191_ = true;
			    break;
			}
		    }
		    if (!bool_191_) {
			boolean bool_193_ = false;
			for (int i_194_ = 0; i_194_ < ((Globe) this).nrmb;
			     i_194_++) {
			    if (((xtGraphics) ((Globe) this).xt).nickname
				    .toLowerCase
				    ().equals
				(((Globe) this).rmember[i_194_]
				     .toLowerCase())) {
				bool_193_ = true;
				break;
			    }
			}
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			if (!bool_193_) {
			    if (stringbutton
				(((Globe) this).rd,
				 "      Request to Join this Clan      ", 496,
				 432, 3, i, i_94_,
				 (bool
				  && !((GameSparker) ((Globe) this).gs).openm),
				 0, 0)) {
				if (((xtGraphics) ((Globe) this).xt).logged)
				    ((Globe) this).editc = 99;
				else
				    ((Globe) this).editc = 101;
			    }
			    int i_195_
				= (((Globe) this).ftm.stringWidth
				   ("      Request to Join this Clan      "));
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawRoundRect((496 - i_195_ / 2
							     - 20),
							    415, i_195_ + 40,
							    24, 20, 20);
			} else {
			    int i_196_
				= (((Globe) this).ftm.stringWidth
				   ("You have requested to join this clan, waiting for admin to approve your membership."));
			    ((Globe) this).rd.drawString
				("You have requested to join this clan, waiting for admin to approve your membership.",
				 496 - i_196_ / 2, 432);
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawRoundRect((496 - i_196_ / 2
							     - 20),
							    415, i_196_ + 40,
							    24, 20, 20);
			}
		    }
		}
		if (((Globe) this).editc == 1 || ((Globe) this).editc == 2) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(265, 92, 460, 220, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(265, 92, 460, 220, 20, 20);
		    String[] strings = { "logo", "350x30", "35 : 3" };
		    if (((Globe) this).editc == 2) {
			strings[0] = "background";
			strings[1] = "560x300";
			strings[2] = "56 : 30";
		    }
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    if (((Globe) this).flko % 4 != 0
			|| ((Globe) this).flko == 0)
			((Globe) this).rd.drawString
			    (((Globe) this).msg,
			     495 - ((Globe) this).ftm
				       .stringWidth(((Globe) this).msg) / 2,
			     115);
		    if (((Globe) this).flko != 0)
			((Globe) this).flko--;
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString(new StringBuilder().append
						     ("The ").append
						     (strings[0]).append
						     (" image is ").append
						     (strings[1]).append
						     (" pixels.").toString(),
						 275, 140);
		    ((Globe) this).rd.drawString
			("Any image uploaded will be resized to that width and height. For the best results",
			 275, 160);
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("try to upload an image that is bigger or equal to ")
			     .append
			     (strings[1]).append
			     (" and has the scale of").toString(),
			 275, 180);
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("[ ").append
			     (strings[2]).append
			     (" ]  in  [ Width : Height ].").toString(),
			 275, 200);
		    ((Globe) this).rd.drawString
			("Image uploaded must be less than 1MB and in the format of JPEG, GIF or PNG.",
			 275, 220);
		    if (((Globe) this).upload == 0) {
			if (stringbutton(((Globe) this).rd, "  Upload Image  ",
					 495, 250, 0, i, i_94_, bool, 0, 0)) {
			    FileDialog filedialog
				= new FileDialog(new Frame(), "Upload Image");
			    filedialog.setMode(0);
			    filedialog.setVisible(true);
			    ((Globe) this).filename
				= new StringBuilder().append("").append
				      (filedialog.getDirectory()).append
				      ("").append
				      (filedialog.getFile()).append
				      ("").toString();
			    if (!((Globe) this).filename.equals("nullnull"))
				((Globe) this).upload = 1;
			}
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			if (((Globe) this).upload == 1)
			    ((Globe) this).rd.drawString
				("Checking image...",
				 495 - (((Globe) this).ftm
					    .stringWidth("Checking image...")
					/ 2),
				 250);
			if (((Globe) this).upload == 2)
			    ((Globe) this).rd.drawString
				("Authenticating...",
				 495 - (((Globe) this).ftm
					    .stringWidth("Authenticating...")
					/ 2),
				 250);
			if (((Globe) this).upload == 3)
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Uploading image :  ").append
				     (((Globe) this).perc).append
				     (" %").toString(),
				 495 - (((Globe) this).ftm.stringWidth
					("Uploading image :  80 %")) / 2,
				 250);
			if (((Globe) this).upload == 4)
			    ((Globe) this).rd.drawString
				("Creating image online...",
				 495 - (((Globe) this).ftm.stringWidth
					("Creating image online...")) / 2,
				 250);
			if (((Globe) this).upload == 5)
			    ((Globe) this).rd.drawString
				("Done",
				 495 - (((Globe) this).ftm.stringWidth("Done")
					/ 2),
				 250);
		    }
		    if (stringbutton(((Globe) this).rd, " Cancel ", 495, 290,
				     2, i, i_94_, bool, 0, 0)) {
			if (((Globe) this).upload == 0)
			    ((Globe) this).editc = 0;
			else
			    ((Globe) this).upload = 0;
		    }
		}
		if (((Globe) this).editc == 3) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(245, 92, 500, 190, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(245, 92, 500, 190, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    String string
			= new StringBuilder().append("").append
			      (((Globe) this).member[((Globe) this).em]).append
			      ("'s").toString();
		    if (((xtGraphics) ((Globe) this).xt).nickname.toLowerCase
			    ().equals
			(((Globe) this).member[((Globe) this).em]
			     .toLowerCase()))
			string = "Your";
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("Edit ").append(string)
			     .append
			     (" Clan Membership").toString(),
			 495 - (((Globe) this).ftm.stringWidth
				(new StringBuilder().append("Edit ").append
				     (string).append
				     ("'s Clan Membership").toString())) / 2,
			 115);
		    ((Globe) this).rd.drawString
			("Rank Description :",
			 399 - ((Globe) this).ftm
				   .stringWidth("Membership Level :"),
			 146);
		    ((Globe) this).dorank = true;
		    ((Globe) this).rd.drawString
			("Membership Level :",
			 503 - ((Globe) this).ftm
				   .stringWidth("Membership Level :"),
			 176);
		    ((GameSparker) ((Globe) this).gs).clanlev.move(513, 159);
		    if (!((GameSparker) ((Globe) this).gs).clanlev
			     .isShowing()) {
			((GameSparker) ((Globe) this).gs).clanlev.select
			    (((Globe) this).mlevel[((Globe) this).em] - 1);
			if (((Globe) this).em == 0
			    && ((Globe) this).mlevel[((Globe) this).em] == 7)
			    ((GameSparker) ((Globe) this).gs).clanlev
				.disable();
			else
			    ((GameSparker) ((Globe) this).gs).clanlev.enable();
			((GameSparker) ((Globe) this).gs).clanlev.show();
		    }
		    if (stringbutton(((Globe) this).rd, "     Save     ", 495,
				     220, 0, i, i_94_, bool, 0, 0)) {
			((GameSparker) ((Globe) this).gs).clanlev.hide();
			((Globe) this).editc = 33;
		    }
		    if (stringbutton(((Globe) this).rd, " Cancel ", 495, 260,
				     2, i, i_94_, bool, 0, 0)) {
			((Globe) this).editc = 0;
			((GameSparker) ((Globe) this).gs).clanlev.hide();
		    }
		}
		if (((Globe) this).editc == 4) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(220, 92, 550, 155, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(220, 92, 550, 155, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    String string
			= new StringBuilder().append("").append
			      (((Globe) this).member[((Globe) this).em]).append
			      ("").toString();
		    if (((xtGraphics) ((Globe) this).xt).nickname.toLowerCase
			    ().equals
			(((Globe) this).member[((Globe) this).em]
			     .toLowerCase()))
			string = "yourself";
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("Are you sure you want to remove ").append
			     (string).append
			     (" from the clan?").toString(),
			 495 - (((Globe) this).ftm.stringWidth
				(new StringBuilder().append
				     ("Are you sure you want to remove ")
				     .append
				     (string).append
				     (" from the clan?").toString())) / 2,
			 120);
		    if ((((xtGraphics) ((Globe) this).xt).nickname.toLowerCase
			     ().equals
			 (((Globe) this).member[((Globe) this).em]
			      .toLowerCase()))
			&& ((Globe) this).em == 0) {
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			if (((Globe) this).nmb > 1)
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Note: This will result in the second high ranking player (")
				     .append
				     (((Globe) this).member[1]).append
				     (") becoming the new Clan Leader!")
				     .toString(),
				 (495
				  - (((Globe) this).ftm.stringWidth
				     (new StringBuilder().append
					  ("Note: This will result in the second high ranking player (")
					  .append
					  (((Globe) this).member[1]).append
					  (") becoming the new Clan Leader!")
					  .toString())) / 2),
				 140);
			else
			    ((Globe) this).rd.drawString
				("Note: This will result in the deletion of this clan since you are the only player in it.",
				 (495
				  - ((((Globe) this).ftm.stringWidth
				      ("Note: This will result in the deletion of this clan since you are the only player in it."))
				     / 2)),
				 140);
		    }
		    if (stringbutton(((Globe) this).rd, "     Yes     ", 495,
				     185, 0, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 44;
		    if (stringbutton(((Globe) this).rd, " No, Cancel ", 495,
				     225, 2, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 0;
		}
		if (((Globe) this).editc == 6) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(245, 92, 500, 225, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(245, 92, 500, 225, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    if (((Globe) this).flko % 4 != 0
			|| ((Globe) this).flko == 0)
			((Globe) this).rd.drawString
			    (((Globe) this).msg,
			     495 - ((Globe) this).ftm
				       .stringWidth(((Globe) this).msg) / 2,
			     115);
		    if (((Globe) this).flko != 0)
			((Globe) this).flko--;
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString
			("Does your clan have an online forum, a Facebook group, a website or any online",
			 255, 140);
		    ((Globe) this).rd.drawString
			("presence at all beyond the game?  If so, you can link to it from here!",
			 255, 160);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Link Title :",
			 400 - ((Globe) this).ftm.stringWidth("Link Title :"),
			 190);
		    ((Globe) this).rd.drawString
			("Link Description :",
			 400 - ((Globe) this).ftm
				   .stringWidth("Link Description :"),
			 220);
		    ((Globe) this).doweb1 = true;
		    if (stringbutton(((Globe) this).rd, "     Next >     ",
				     495, 255, 0, i, i_94_, bool, 0, 0)) {
			if (((GameSparker) ((Globe) this).gs).temail.getText
				().equals("")
			    || ((GameSparker) ((Globe) this).gs).cmsg.getText
				   ().equals("")) {
			    ((Globe) this).msg
				= "Please enter a link title and a link description!";
			    ((Globe) this).flko = 45;
			} else {
			    ((Globe) this).sltit
				= ((GameSparker) ((Globe) this).gs).temail
				      .getText();
			    if (!((Globe) this).lurl.equals("")
				&& ((Globe) this).lurl.toLowerCase()
				       .startsWith("http"))
				((GameSparker) ((Globe) this).gs).temail
				    .setText(((Globe) this).lurl);
			    else
				((GameSparker) ((Globe) this).gs).temail
				    .setText("http://");
			    ((Globe) this).msg = "Edit Clan's Web Presence";
			    ((Globe) this).flko = 0;
			    ((Globe) this).editc = 7;
			}
		    }
		    if (stringbutton(((Globe) this).rd, " Cancel ", 495, 295,
				     2, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 0;
		}
		if (((Globe) this).editc == 7) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(245, 92, 500, 225, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(245, 92, 500, 225, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    if (((Globe) this).flko % 4 != 0
			|| ((Globe) this).flko == 0)
			((Globe) this).rd.drawString
			    (((Globe) this).msg,
			     495 - ((Globe) this).ftm
				       .stringWidth(((Globe) this).msg) / 2,
			     115);
		    if (((Globe) this).flko != 0)
			((Globe) this).flko--;
		    ((Globe) this).rd.drawString
			("Link URL :",
			 343 - ((Globe) this).ftm.stringWidth("Link URL :"),
			 150);
		    ((Globe) this).doweb2 = true;
		    ((Globe) this).rd.drawString("WARNING :", 255, 180);
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString
			("Any link placed that contains inappropriate, spam or unrelated content will result in",
			 255, 200);
		    ((Globe) this).rd.drawString
			("instant clan deletion and permanent account banning!",
			 255, 220);
		    if (stringbutton(((Globe) this).rd, "     Save     ", 495,
				     255, 0, i, i_94_, bool, 0, 0)) {
			if (((GameSparker) ((Globe) this).gs).temail.getText
				().equals("")
			    || ((GameSparker) ((Globe) this).gs).temail.getText
				   ().equals("http://")) {
			    ((Globe) this).msg = "Please enter a link URL!";
			    ((Globe) this).flko = 45;
			} else
			    ((Globe) this).editc = 55;
		    }
		    if (stringbutton(((Globe) this).rd, " Cancel ", 495, 295,
				     2, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 0;
		}
		if (((Globe) this).editc == 33 || ((Globe) this).editc == 44
		    || ((Globe) this).editc == 66 || ((Globe) this).editc == 77
		    || ((Globe) this).editc == 99
		    || ((Globe) this).editc == 55) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(345, 92, 300, 40, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(345, 92, 300, 40, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("One moment...",
			 495 - (((Globe) this).ftm.stringWidth("One moment...")
				/ 2),
			 117);
		}
		if (((Globe) this).editc == 5) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(265, 92, 460, 115, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(265, 92, 460, 115, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Server error occurred or was unable to authorize this action.",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("Server error occurred or was unable to authorize this action."))
			     / 2)),
			 120);
		    ((Globe) this).rd.drawString
			("Please try again later.",
			 495 - ((Globe) this).ftm
				   .stringWidth("Please try again later.") / 2,
			 150);
		    if (stringbutton(((Globe) this).rd, "     OK     ", 495,
				     185, 2, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 0;
		}
		if (((Globe) this).editc == 101) {
		    ((Globe) this).rd.setColor(new Color(244, 232, 204));
		    ((Globe) this).rd.fillRoundRect(232, 90, 527, 176, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(232, 90, 527, 176, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("You are currently using a trial account.",
			 495 - ((((Globe) this).ftm.stringWidth
				 ("You are currently using a trial account."))
				/ 2),
			 120);
		    ((Globe) this).rd.drawString
			("You need to upgrade to be able participate in any NFM clan activity.",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("You need to upgrade to be able participate in any NFM clan activity."))
			     / 2)),
			 140);
		    ((Globe) this).rd.setColor(new Color(206, 171, 98));
		    ((Globe) this).rd.fillRoundRect(405, 163, 180, 50, 20, 20);
		    if (drawbutton(((xtGraphics) ((Globe) this).xt).upgrade,
				   495, 188, i, i_94_, bool))
			((Globe) this).gs.editlink((((xtGraphics)
						     ((Globe) this).xt)
						    .nickname),
						   true);
		    if (stringbutton(((Globe) this).rd, " Cancel ", 495, 244,
				     2, i, i_94_, bool, 0, 0))
			((Globe) this).editc = 0;
		}
	    } else
		((Globe) this).rd.drawString
		    (new StringBuilder().append("Loading clan: ").append
			 (((Globe) this).claname).append
			 (", please wait...").toString(),
		     495 - (((Globe) this).ftm.stringWidth
			    (new StringBuilder().append("Loading clan: ")
				 .append
				 (((Globe) this).claname).append
				 (", please wait...").toString())) / 2,
		     222);
	} else {
	    if (((GameSparker) ((Globe) this).gs).clcars.isShowing())
		((GameSparker) ((Globe) this).gs).clcars.hide();
	    if (((Globe) this).editc != 0) {
		((Globe) this).editc = 0;
		if (((GameSparker) ((Globe) this).gs).clanlev.isShowing())
		    ((GameSparker) ((Globe) this).gs).clanlev.hide();
	    }
	}
    }
    
    public void dotab2(int i, int i_197_, boolean bool) {
	if (((Globe) this).itab == 0) {
	    if (((Globe) this).litab != ((Globe) this).itab) {
		((Globe) this).spos3 = 0;
		((GameSparker) ((Globe) this).gs).senditem.hide();
		((GameSparker) ((Globe) this).gs).datat.hide();
		((GameSparker) ((Globe) this).gs).sendtyp.removeAll();
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Write a Message");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Share a Custom Car");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Share a Custom Stage");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Send a Clan Invitation");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Share a Relative Date");
		if (!((Globe) this).forcsel)
		    ((GameSparker) ((Globe) this).gs).sendtyp.select(0);
		else
		    ((GameSparker) ((Globe) this).gs).sendtyp
			.select(((Globe) this).itemsel);
		((Globe) this).forcsel = false;
		((Globe) this).flko = 0;
		((Globe) this).itemsel = 0;
		((Globe) this).flko = 0;
		((Globe) this).litab = ((Globe) this).itab;
	    }
	    if (((Globe) this).openc != 10) {
		((Globe) this).rd.setColor(color2k(230, 230, 230));
		((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
		if (((Globe) this).loadmsgs != 0
		    && ((Globe) this).loadmsgs != -2
		    && ((Globe) this).loadmsgs != -1) {
		    ((Globe) this).sdist = (((Globe) this).nm - 10) * 31;
		    if (((Globe) this).sdist < 0)
			((Globe) this).sdist = 0;
		    ((Globe) this).scro
			= (int) ((float) ((Globe) this).spos3 / 268.0F
				 * (float) ((Globe) this).sdist);
		    int i_198_ = 0;
		    for (int i_199_ = 0; i_199_ < ((Globe) this).nm;
			 i_199_++) {
			if (((Globe) this).mtyp[i_199_] != 3) {
			    if (76 + 31 * i_198_ - ((Globe) this).scro < 408
				&& (107 + 31 * i_198_ - ((Globe) this).scro
				    > 76)) {
				boolean bool_200_ = false;
				if (i > 207 && i < 770
				    && i_197_ > (76 + 31 * i_198_
						 - ((Globe) this).scro)
				    && i_197_ < (106 + 31 * i_198_
						 - ((Globe) this).scro)) {
				    bool_200_ = true;
				    ((Globe) this).cur = 12;
				    if (bool && ((Globe) this).openc == 0) {
					((Globe) this).opy
					    = (70 + 31 * i_198_
					       - ((Globe) this).scro);
					((Globe) this).addopy
					    = (40 - ((Globe) this).opy) / 10;
					((Globe) this).oph = 44;
					((Globe) this).openc = 1;
					if (!((Globe) this).opname.equals
					     (((Globe) this).mname[i_199_])) {
					    ((Globe) this).opname
						= ((Globe) this).mname[i_199_];
					    ((Globe) this).lastsub = "";
					    ((Globe) this).readmsg = 1;
					}
				    }
				}
				if (((Globe) this).mtyp[i_199_] == 1) {
				    ((Globe) this).rd
					.setColor(color2k(240, 240, 240));
				    ((Globe) this).rd.fillRect(207,
							       (77
								+ 31 * i_198_
								- ((Globe)
								   this).scro),
							       564, 30);
				}
				if (bool_200_) {
				    ((Globe) this).rd
					.setColor(color2k(250, 250, 250));
				    ((Globe) this).rd.fillRect(207,
							       (77
								+ 31 * i_198_
								- ((Globe)
								   this).scro),
							       564, 30);
				}
				boolean bool_201_
				    = drawl(((Globe) this).rd,
					    ((Globe) this).mname[i_199_], 207,
					    (77 + 31 * i_198_
					     - ((Globe) this).scro),
					    bool_200_);
				if (!bool_200_ || !bool_201_) {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					(((Globe) this).mname[i_199_],
					 267 - (((Globe) this).ftm.stringWidth
						(((Globe) this).mname
						 [i_199_])) / 2,
					 (96 + 31 * i_198_
					  - ((Globe) this).scro));
				}
				int[] is = { 0, 5, 5, 14, 14, 5, 5 };
				int[] is_202_ = { 0, -5, -2, -2, 3, 3, 5 };
				if (((Globe) this).mtyp[i_199_] != 2) {
				    for (int i_203_ = 0; i_203_ < 7;
					 i_203_++) {
					is[i_203_] += 335;
					is_202_[i_203_]
					    += (98 + 31 * i_198_
						- ((Globe) this).scro);
				    }
				    ((Globe) this).rd
					.setColor(new Color(0, 128, 0));
				} else {
				    for (int i_204_ = 0; i_204_ < 7;
					 i_204_++) {
					is[i_204_] = 349 - is[i_204_];
					is_202_[i_204_]
					    += (98 + 31 * i_198_
						- ((Globe) this).scro);
				    }
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 128));
				}
				((Globe) this).rd.fillPolygon(is, is_202_, 7);
				((Globe) this).rd.setFont(new Font("Tahoma", 0,
								   11));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.setColor(color2k(125, 125,
								   125));
				((Globe) this).rd.drawString
				    (((Globe) this).mtime[i_199_],
				     760 - (((Globe) this).ftm.stringWidth
					    (((Globe) this).mtime[i_199_])),
				     102 + 31 * i_198_ - ((Globe) this).scro);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawString
				    (((Globe) this).msub[i_199_], 335,
				     89 + 31 * i_198_ - ((Globe) this).scro);
				((Globe) this).rd.setColor(color2k(150, 150,
								   150));
				((Globe) this).rd.drawLine
				    (207,
				     107 + 31 * i_198_ - ((Globe) this).scro,
				     770,
				     107 + 31 * i_198_ - ((Globe) this).scro);
			    }
			    i_198_++;
			}
		    }
		    for (int i_205_ = 0; i_205_ < ((Globe) this).nm;
			 i_205_++) {
			if (((Globe) this).mtyp[i_205_] == 3) {
			    if (76 + 31 * i_198_ - ((Globe) this).scro < 408
				&& (107 + 31 * i_198_ - ((Globe) this).scro
				    > 76)) {
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   12));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				boolean bool_206_ = false;
				if (i > 207 && i < 770
				    && i_197_ > (76 + 31 * i_198_
						 - ((Globe) this).scro)
				    && i_197_ < (106 + 31 * i_198_
						 - ((Globe) this).scro))
				    bool_206_ = true;
				boolean bool_207_
				    = drawl(((Globe) this).rd,
					    ((Globe) this).mname[i_205_], 207,
					    (77 + 31 * i_198_
					     - ((Globe) this).scro),
					    bool_206_);
				if (!bool_206_ || !bool_207_) {
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					(((Globe) this).mname[i_205_],
					 267 - (((Globe) this).ftm.stringWidth
						(((Globe) this).mname
						 [i_205_])) / 2,
					 (96 + 31 * i_198_
					  - ((Globe) this).scro));
				}
				((Globe) this).rd.setColor(color2k(100, 100,
								   100));
				((Globe) this).rd.fillRect(327,
							   (77 + 31 * i_198_
							    - (((Globe) this)
							       .scro)),
							   444, 30);
				((Globe) this).rd.setColor(color2k(200, 200,
								   200));
				if (((Globe) this).unblockname.equals(""))
				    ((Globe) this).rd.drawString
					("Blocked", 337,
					 (96 + 31 * i_198_
					  - ((Globe) this).scro));
				else
				    ((Globe) this).rd.drawString
					("Unblocking...", 337,
					 (96 + 31 * i_198_
					  - ((Globe) this).scro));
				if (bool_206_
				    && stringbutton(((Globe) this).rd,
						    "   Unblock  ", 724,
						    (96 + 31 * i_198_
						     - ((Globe) this).scro),
						    3, i, i_197_, bool, 0, 0)
				    && ((Globe) this).unblockname.equals(""))
				    ((Globe) this).unblockname
					= ((Globe) this).mname[i_205_];
				((Globe) this).rd.setColor(color2k(150, 150,
								   150));
				((Globe) this).rd.drawLine
				    (207,
				     107 + 31 * i_198_ - ((Globe) this).scro,
				     770,
				     107 + 31 * i_198_ - ((Globe) this).scro);
			    }
			    i_198_++;
			}
		    }
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(207, 46, 582, 30);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    String[] strings
			= { "Player Interaction", "Clan Interaction",
			    "Your Clan's Discussion" };
		    int[] is = { 207, 390, 368, 207 };
		    int[] is_208_ = { 73, 73, 51, 51 };
		    for (int i_209_ = 0; i_209_ < 3; i_209_++) {
			if (((Globe) this).itab == i_209_) {
			    ((Globe) this).rd.setColor(color2k(230, 230, 230));
			    ((Globe) this).rd.fillPolygon(is, is_208_, 4);
			} else if (i > is[0] && i < is[2] && i_197_ > 51
				   && i_197_ < 73) {
			    ((Globe) this).rd.setColor(color2k(217, 217, 217));
			    ((Globe) this).rd.fillPolygon(is, is_208_, 4);
			    if (bool)
				((Globe) this).itab = i_209_;
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawPolygon(is, is_208_, 4);
			((Globe) this).rd.setColor(color2k(40, 40, 40));
			((Globe) this).rd.drawString
			    (strings[i_209_],
			     is[0] + 80 - (((Globe) this).ftm
					       .stringWidth(strings[i_209_])
					   / 2),
			     67);
			for (int i_210_ = 0; i_210_ < 4; i_210_++)
			    is[i_210_] += 183;
		    }
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(207, 73, 770, 73);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(207, 409, 582, 30);
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(207, 411, 770, 411);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(772, 93, 17, 299);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(203, 46, 4, 393);
		    if (((Globe) this).mscro3 == 831
			|| ((Globe) this).sdist == 0) {
			if (((Globe) this).sdist == 0)
			    ((Globe) this).rd.setColor(color2k(205, 205, 205));
			else
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fillRect(772, 76, 17, 17);
		    } else {
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fill3DRect(772, 76, 17, 17, true);
		    }
		    if (((Globe) this).sdist != 0)
			((Globe) this).rd.drawImage(((xtGraphics)
						     ((Globe) this).xt).asu,
						    777, 82, null);
		    if (((Globe) this).mscro3 == 832
			|| ((Globe) this).sdist == 0) {
			if (((Globe) this).sdist == 0)
			    ((Globe) this).rd.setColor(color2k(205, 205, 205));
			else
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fillRect(772, 392, 17, 17);
		    } else {
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fill3DRect(772, 392, 17, 17, true);
		    }
		    if (((Globe) this).sdist != 0)
			((Globe) this).rd.drawImage(((xtGraphics)
						     ((Globe) this).xt).asd,
						    777, 399, null);
		    if (((Globe) this).sdist != 0) {
			if (((Globe) this).lspos3 != ((Globe) this).spos3) {
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			    ((Globe) this).rd.fillRect(772,
						       93 + (((Globe) this)
							     .spos3),
						       17, 31);
			} else {
			    if (((Globe) this).mscro3 == 831)
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fill3DRect(772,
							 93 + (((Globe) this)
							       .spos3),
							 17, 31, true);
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(777,
						   106 + ((Globe) this).spos3,
						   783,
						   106 + ((Globe) this).spos3);
			((Globe) this).rd.drawLine(777,
						   108 + ((Globe) this).spos3,
						   783,
						   108 + ((Globe) this).spos3);
			((Globe) this).rd.drawLine(777,
						   110 + ((Globe) this).spos3,
						   783,
						   110 + ((Globe) this).spos3);
			if (((Globe) this).mscro3 > 800
			    && ((Globe) this).lspos3 != ((Globe) this).spos3)
			    ((Globe) this).lspos3 = ((Globe) this).spos3;
			if (bool && ((Globe) this).openc == 0) {
			    if (((Globe) this).mscro3 == 825 && i > 772
				&& i < 789
				&& i_197_ > 93 + ((Globe) this).spos3
				&& i_197_ < ((Globe) this).spos3 + 124)
				((Globe) this).mscro3
				    = i_197_ - ((Globe) this).spos3;
			    if (((Globe) this).mscro3 == 825 && i > 770
				&& i < 791 && i_197_ > 74 && i_197_ < 95)
				((Globe) this).mscro3 = 831;
			    if (((Globe) this).mscro3 == 825 && i > 770
				&& i < 791 && i_197_ > 390 && i_197_ < 411)
				((Globe) this).mscro3 = 832;
			    if (((Globe) this).mscro3 == 825 && i > 772
				&& i < 789 && i_197_ > 93 && i_197_ < 392) {
				((Globe) this).mscro3 = 108;
				((Globe) this).spos3
				    = i_197_ - ((Globe) this).mscro3;
			    }
			    int i_211_ = 2670 / ((Globe) this).sdist;
			    if (i_211_ < 1)
				i_211_ = 1;
			    if (((Globe) this).mscro3 == 831) {
				((Globe) this).spos3 -= i_211_;
				if (((Globe) this).spos3 > 268)
				    ((Globe) this).spos3 = 268;
				if (((Globe) this).spos3 < 0)
				    ((Globe) this).spos3 = 0;
				((Globe) this).lspos3 = ((Globe) this).spos3;
			    }
			    if (((Globe) this).mscro3 == 832) {
				((Globe) this).spos3 += i_211_;
				if (((Globe) this).spos3 > 268)
				    ((Globe) this).spos3 = 268;
				if (((Globe) this).spos3 < 0)
				    ((Globe) this).spos3 = 0;
				((Globe) this).lspos3 = ((Globe) this).spos3;
			    }
			    if (((Globe) this).mscro3 < 800) {
				((Globe) this).spos3
				    = i_197_ - ((Globe) this).mscro3;
				if (((Globe) this).spos3 > 268)
				    ((Globe) this).spos3 = 268;
				if (((Globe) this).spos3 < 0)
				    ((Globe) this).spos3 = 0;
			    }
			    if (((Globe) this).mscro3 == 825)
				((Globe) this).mscro3 = 925;
			} else if (((Globe) this).mscro3 != 825)
			    ((Globe) this).mscro3 = 825;
		    }
		} else {
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(207, 46, 582, 30);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    String[] strings
			= { "Player Interaction", "Clan Interaction",
			    "Your Clan's Discussion" };
		    int[] is = { 207, 390, 368, 207 };
		    int[] is_212_ = { 73, 73, 51, 51 };
		    for (int i_213_ = 0; i_213_ < 3; i_213_++) {
			if (((Globe) this).itab == i_213_) {
			    ((Globe) this).rd.setColor(color2k(230, 230, 230));
			    ((Globe) this).rd.fillPolygon(is, is_212_, 4);
			} else if (i > is[0] && i < is[2] && i_197_ > 51
				   && i_197_ < 73) {
			    ((Globe) this).rd.setColor(color2k(217, 217, 217));
			    ((Globe) this).rd.fillPolygon(is, is_212_, 4);
			    if (bool)
				((Globe) this).itab = i_213_;
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawPolygon(is, is_212_, 4);
			((Globe) this).rd.setColor(color2k(40, 40, 40));
			((Globe) this).rd.drawString
			    (strings[i_213_],
			     is[0] + 80 - (((Globe) this).ftm
					       .stringWidth(strings[i_213_])
					   / 2),
			     67);
			for (int i_214_ = 0; i_214_ < 4; i_214_++)
			    is[i_214_] += 183;
		    }
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(207, 73, 770, 73);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(207, 409, 582, 30);
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(207, 411, 770, 411);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(772, 76, 17, 333);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.fillRect(203, 46, 4, 393);
		    if (((Globe) this).loadmsgs == 0) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("You have not started any conversations yet.",
			     (487
			      - ((((Globe) this).ftm.stringWidth
				  ("You have not started any conversations yet."))
				 / 2)),
			     200);
		    }
		    if (((Globe) this).loadmsgs == -2) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Failed to load conversations, will try again now...",
			     (487
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load conversations, will try again now..."))
				 / 2)),
			     200);
		    }
		    if (((Globe) this).loadmsgs == -1) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Loading conversations, please wait...",
			     487 - ((((Globe) this).ftm.stringWidth
				     ("Loading conversation, please wait..."))
				    / 2),
			     200);
		    }
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp.isShowing()) {
		    ((GameSparker) ((Globe) this).gs).sendtyp.hide();
		    ((GameSparker) ((Globe) this).gs).sendtyp.select(0);
		    ((Globe) this).flko = 0;
		}
		if (((GameSparker) ((Globe) this).gs).senditem.isShowing())
		    ((GameSparker) ((Globe) this).gs).senditem.hide();
		if (((GameSparker) ((Globe) this).gs).datat.isShowing())
		    ((GameSparker) ((Globe) this).gs).datat.hide();
	    } else {
		((Globe) this).rd.setColor(color2k(240, 240, 240));
		((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
		((Globe) this).rd.setColor(color2k(250, 250, 250));
		((Globe) this).rd.fillRect(207, 86, 577, 274);
		((Globe) this).sdist
		    = (int) (((float) ((Globe) this).nml - 14.75F) * 17.0F);
		if (((Globe) this).sdist < 0)
		    ((Globe) this).sdist = 0;
		((Globe) this).scro
		    = (int) ((float) ((Globe) this).spos4 / 208.0F
			     * (float) ((Globe) this).sdist);
		if (((Globe) this).readmsg == 2) {
		    if (((GameSparker) ((Globe) this).gs).openm)
			((Globe) this).blockb = 10;
		    else if (((Globe) this).blockb != 0)
			((Globe) this).blockb--;
		    for (int i_215_ = 0; i_215_ < ((Globe) this).nml;
			 i_215_++) {
			if (86 + 17 * i_215_ - ((Globe) this).scro < 360
			    && 125 + 17 * i_215_ - ((Globe) this).scro > 86
			    && ((Globe) this).mlinetyp[i_215_] != 167) {
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    if (((Globe) this).mlinetyp[i_215_] != 10
				&& ((Globe) this).mlinetyp[i_215_] != 20
				&& ((Globe) this).mlinetyp[i_215_] != 30) {
				if (((Globe) this).mlinetyp[i_215_] == 0
				    || ((Globe) this).mlinetyp[i_215_] == 1
				    || ((Globe) this).mlinetyp[i_215_] == 2
				    || ((Globe) this).mlinetyp[i_215_] == 3
				    || ((Globe) this).mlinetyp[i_215_] == 4)
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 1, 11));
				else
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				((Globe) this).rd.drawString
				    (((Globe) this).mline[i_215_], 217,
				     103 + 17 * i_215_ - ((Globe) this).scro);
				if (((Globe) this).mlinetyp[i_215_] == 0
				    || ((Globe) this).mlinetyp[i_215_] == 1
				    || ((Globe) this).mlinetyp[i_215_] == 2
				    || ((Globe) this).mlinetyp[i_215_] == 3
				    || ((Globe) this).mlinetyp[i_215_] == 4) {
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd
					.setColor(color2k(125, 125, 125));
				    ((Globe) this).rd.drawString
					(((Globe) this).mtimes[i_215_],
					 (757
					  - (((Globe) this).ftm.stringWidth
					     (((Globe) this).mtimes[i_215_]))),
					 (103 + 17 * i_215_
					  - ((Globe) this).scro));
				}
			    } else {
				if (((Globe) this).mlinetyp[i_215_] == 30) {
				    boolean bool_216_ = true;
				    if (i > 217 && i < 567
					&& i_197_ > (93 + i_215_ * 17
						     - ((Globe) this).scro)
					&& i_197_ < (123 + i_215_ * 17
						     - ((Globe) this).scro)
					&& ((Globe) this).blockb == 0) {
					((Globe) this).cur = 12;
					bool_216_ = false;
					if (bool) {
					    if (!((Globe) this).claname.equals
						 (((Globe) this).mline
						  [i_215_])) {
						((Globe) this).claname
						    = (((Globe) this).mline
						       [i_215_]);
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).tab = 3;
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).ctab = 0;
					}
				    }
				    if (!drawl(((Globe) this).rd,
					       new StringBuilder().append
						   ("#").append
						   (((Globe) this).mline
						    [i_215_])
						   .append
						   ("#").toString(),
					       217,
					       (93 + i_215_ * 17
						- ((Globe) this).scro),
					       bool_216_)
					|| !bool_216_) {
					((Globe) this).rd
					    .setColor(new Color(0, 0, 0));
					((Globe) this).rd.drawRect
					    (217,
					     (93 + i_215_ * 17
					      - ((Globe) this).scro),
					     349, 29);
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 13));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					((Globe) this).rd.drawString
					    (new StringBuilder().append("")
						 .append
						 (((Globe) this).mline[i_215_])
						 .append
						 ("").toString(),
					     392 - (((Globe) this).ftm
							.stringWidth
						    (new StringBuilder().append
							 ("").append
							 (((Globe) this).mline
							  [i_215_])
							 .append
							 ("").toString())) / 2,
					     (113 + i_215_ * 17
					      - ((Globe) this).scro));
				    }
				}
				if (((Globe) this).mlinetyp[i_215_] == 10) {
				    if (((CarDefine) ((Globe) this).cd)
					    .acname.equals
					(((Globe) this).mline[i_215_])) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == -9)
					    ((Globe) this).rd.drawString
						("Failed to add car!  Unknown error, please try again later.",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == -8)
					    ((Globe) this).rd.drawString
						("Cannot add more then 20 cars to your account!",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == 7) {
					    ((Globe) this).rd.setColor
						(new Color(94, 170, 0));
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("[").append
						     (((Globe) this).mline
						      [i_215_])
						     .append
						     ("] has been added to your cars!")
						     .toString(),
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					}
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == -7)
					    ((Globe) this).rd.drawString
						("You already have this car.",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == 6)
					    ((Globe) this).rd.drawString
						("Adding Car...", 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if ((((CarDefine) ((Globe) this).cd)
					     .action)
					    == -6) {
					    ((Globe) this).rd.setColor
						(new Color(193, 106, 0));
					    String string
						= "Upgrade to a full account to add custom cars!";
					    int i_217_ = 217;
					    int i_218_
						= (i_217_
						   + ((Globe) this).ftm
							 .stringWidth(string));
					    ((Globe) this).rd.drawString
						(string, i_217_,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					    if (((Globe) this).waitlink != -1)
						((Globe) this).rd.drawLine
						    (i_217_,
						     (111 + 17 * i_215_
						      - ((Globe) this).scro),
						     i_218_,
						     (111 + 17 * i_215_
						      - ((Globe) this).scro));
					    if (i > i_217_ && i < i_218_
						&& (i_197_
						    > (98 + 17 * i_215_
						       - ((Globe) this).scro))
						&& i_197_ < (111 + 17 * i_215_
							     - (((Globe) this)
								.scro))) {
						if (((Globe) this).waitlink
						    != -1)
						    ((Globe) this).cur = 12;
						if (bool
						    && (((Globe) this).waitlink
							== 0)) {
						    ((Globe) this).gs.editlink
							((((xtGraphics)
							   ((Globe) this).xt)
							  .nickname),
							 true);
						    ((Globe) this).waitlink
							= -1;
						}
					    }
					    if (((Globe) this).waitlink > 0)
						((Globe) this).waitlink--;
					}
				    }
				    if ((((CarDefine) ((Globe) this).cd).action
					 == 0)
					|| !(((CarDefine) ((Globe) this).cd)
						 .acname.equals
					     (((Globe) this).mline[i_215_]))) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).rd.drawString
					    (new StringBuilder().append
						 ("[  ").append
						 (((Globe) this).mline[i_215_])
						 .append
						 ("  ]").toString(),
					     340,
					     (109 + 17 * i_215_
					      - ((Globe) this).scro));
					if (((Globe) this).xt.drawcarb
					    (true, null, " Add to My Cars ",
					     217,
					     (90 + 17 * i_215_
					      - ((Globe) this).scro),
					     i, i_197_,
					     bool && (((Globe) this).blockb
						      == 0))) {
					    if (((xtGraphics)
						 ((Globe) this).xt)
						.logged) {
						((CarDefine) ((Globe) this).cd)
						    .action
						    = 6;
						((CarDefine) ((Globe) this).cd)
						    .ac
						    = -1;
						((CarDefine) ((Globe) this).cd)
						    .acname
						    = (((Globe) this).mline
						       [i_215_]);
						((Globe) this).cd
						    .sparkactionloader();
					    } else {
						((CarDefine) ((Globe) this).cd)
						    .acname
						    = (((Globe) this).mline
						       [i_215_]);
						((CarDefine) ((Globe) this).cd)
						    .action
						    = -6;
						((Globe) this).waitlink = 20;
					    }
					}
				    }
				}
				if (((Globe) this).mlinetyp[i_215_] == 20) {
				    if (((CarDefine) ((Globe) this).cd)
					    .onstage.equals
					(((Globe) this).mline[i_215_])) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (((Globe) this).addstage == 2) {
					    ((Globe) this).rd.drawString
						("Adding stage...", 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					    if (((CarDefine)
						 ((Globe) this).cd).staction
						== 0)
						((Globe) this).addstage = 3;
					    if (((CarDefine)
						 ((Globe) this).cd).staction
						== -2)
						((Globe) this).addstage = 4;
					    if (((CarDefine)
						 ((Globe) this).cd).staction
						== -3)
						((Globe) this).addstage = 5;
					    if (((CarDefine)
						 ((Globe) this).cd).staction
						== -1)
						((Globe) this).addstage = 6;
					}
					if (((Globe) this).addstage == 3) {
					    ((Globe) this).rd.setColor
						(new Color(94, 170, 0));
					    ((Globe) this).rd.drawString
						(new StringBuilder().append
						     ("[").append
						     (((Globe) this).mline
						      [i_215_])
						     .append
						     ("] has been added to your stages!")
						     .toString(),
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					}
					if (((Globe) this).addstage == 4)
					    ((Globe) this).rd.drawString
						("You already have this stage.",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if (((Globe) this).addstage == 5)
					    ((Globe) this).rd.drawString
						("Cannot add more then 20 stages to your account!",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if (((Globe) this).addstage == 6)
					    ((Globe) this).rd.drawString
						("Failed to add stage!  Unknown error, please try again later.",
						 217,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					if (((Globe) this).addstage == 1) {
					    ((Globe) this).rd.setColor
						(new Color(193, 106, 0));
					    String string
						= "Upgrade to a full account to add custom stages!";
					    int i_219_ = 217;
					    int i_220_
						= (i_219_
						   + ((Globe) this).ftm
							 .stringWidth(string));
					    ((Globe) this).rd.drawString
						(string, i_219_,
						 (109 + 17 * i_215_
						  - ((Globe) this).scro));
					    if (((Globe) this).waitlink != -1)
						((Globe) this).rd.drawLine
						    (i_219_,
						     (111 + 17 * i_215_
						      - ((Globe) this).scro),
						     i_220_,
						     (111 + 17 * i_215_
						      - ((Globe) this).scro));
					    if (i > i_219_ && i < i_220_
						&& (i_197_
						    > (98 + 17 * i_215_
						       - ((Globe) this).scro))
						&& i_197_ < (111 + 17 * i_215_
							     - (((Globe) this)
								.scro))) {
						if (((Globe) this).waitlink
						    != -1)
						    ((Globe) this).cur = 12;
						if (bool
						    && (((Globe) this).waitlink
							== 0)) {
						    ((Globe) this).gs.editlink
							((((xtGraphics)
							   ((Globe) this).xt)
							  .nickname),
							 true);
						    ((Globe) this).waitlink
							= -1;
						}
					    }
					    if (((Globe) this).waitlink > 0)
						((Globe) this).waitlink--;
					}
				    }
				    if (((Globe) this).addstage == 0
					|| !(((CarDefine) ((Globe) this).cd)
						 .onstage.equals
					     (((Globe) this).mline[i_215_]))) {
					((Globe) this).rd
					    .setFont(new Font("Arial", 1, 12));
					((Globe) this).rd.drawString
					    (new StringBuilder().append
						 ("[  ").append
						 (((Globe) this).mline[i_215_])
						 .append
						 ("  ]").toString(),
					     355,
					     (109 + 17 * i_215_
					      - ((Globe) this).scro));
					if (((Globe) this).xt.drawcarb
					    (true, null, " Add to My Stages ",
					     217,
					     (90 + 17 * i_215_
					      - ((Globe) this).scro),
					     i, i_197_,
					     bool && (((Globe) this).blockb
						      == 0))) {
					    if (((xtGraphics)
						 ((Globe) this).xt)
						.logged) {
						((CarDefine) ((Globe) this).cd)
						    .onstage
						    = (((Globe) this).mline
						       [i_215_]);
						((CarDefine) ((Globe) this).cd)
						    .staction
						    = 2;
						((Globe) this).cd
						    .sparkstageaction();
						((Globe) this).addstage = 2;
					    } else {
						((CarDefine) ((Globe) this).cd)
						    .onstage
						    = (((Globe) this).mline
						       [i_215_]);
						((Globe) this).addstage = 1;
						((Globe) this).waitlink = 20;
					    }
					}
				    }
				}
			    }
			}
		    }
		}
		if (((Globe) this).readmsg == 1) {
		    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Reading...",
			 (487
			  - ((Globe) this).ftm.stringWidth("Reading...") / 2),
			 200);
		}
		if (((Globe) this).readmsg == 3) {
		    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Failed to fetch and load conversation.",
			 487 - ((((Globe) this).ftm.stringWidth
				 ("Failed to fetch and load conversation."))
				/ 2),
			 200);
		}
		if (((Globe) this).readmsg == 4) {
		    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Failed to load conversation, server error, please try again later.",
			 (487
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to load conversation, please try again later."))
			     / 2)),
			 200);
		}
		if (((Globe) this).readmsg == 5) {
		    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Failed to send message, server error, please try again later.",
			 (487
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to send message, server error, please try again later."))
			     / 2)),
			 200);
		}
		((Globe) this).rd.setColor(color2k(240, 240, 240));
		((Globe) this).rd.fillRect(207, 47, 577, 39);
		((Globe) this).rd.fillRect(207, 360, 577, 39);
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.drawLine(207, 86, 783, 86);
		((Globe) this).rd.drawLine(207, 86, 207, 360);
		((Globe) this).rd.drawLine(207, 360, 783, 360);
		((Globe) this).rd.fillRect(767, 104, 17, 239);
		if (((Globe) this).mscro4 == 831
		    || ((Globe) this).sdist == 0) {
		    if (((Globe) this).sdist == 0)
			((Globe) this).rd.setColor(color2k(205, 205, 205));
		    else
			((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fillRect(767, 87, 17, 17);
		} else {
		    ((Globe) this).rd.setColor(color2k(220, 220, 220));
		    ((Globe) this).rd.fill3DRect(767, 87, 17, 17, true);
		}
		if (((Globe) this).sdist != 0)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).asu,
						772, 93, null);
		if (((Globe) this).mscro4 == 832
		    || ((Globe) this).sdist == 0) {
		    if (((Globe) this).sdist == 0)
			((Globe) this).rd.setColor(color2k(205, 205, 205));
		    else
			((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fillRect(767, 343, 17, 17);
		} else {
		    ((Globe) this).rd.setColor(color2k(220, 220, 220));
		    ((Globe) this).rd.fill3DRect(767, 343, 17, 17, true);
		}
		if (((Globe) this).sdist != 0)
		    ((Globe) this).rd.drawImage(((xtGraphics)
						 ((Globe) this).xt).asd,
						772, 350, null);
		if (((Globe) this).sdist != 0) {
		    if (((Globe) this).lspos4 != ((Globe) this).spos4) {
			((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd
			    .fillRect(767, 104 + ((Globe) this).spos4, 17, 31);
		    } else {
			if (((Globe) this).mscro4 == 831)
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fill3DRect(767,
						     (104
						      + ((Globe) this).spos4),
						     17, 31, true);
		    }
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawLine(772, 117 + ((Globe) this).spos4,
					       778,
					       117 + ((Globe) this).spos4);
		    ((Globe) this).rd.drawLine(772, 119 + ((Globe) this).spos4,
					       778,
					       119 + ((Globe) this).spos4);
		    ((Globe) this).rd.drawLine(772, 121 + ((Globe) this).spos4,
					       778,
					       121 + ((Globe) this).spos4);
		    if (((Globe) this).mscro4 > 800
			&& ((Globe) this).lspos4 != ((Globe) this).spos4)
			((Globe) this).lspos4 = ((Globe) this).spos4;
		    if (bool) {
			if (((Globe) this).mscro4 == 825 && i > 767 && i < 784
			    && i_197_ > 104 + ((Globe) this).spos4
			    && i_197_ < ((Globe) this).spos4 + 135)
			    ((Globe) this).mscro4
				= i_197_ - ((Globe) this).spos4;
			if (((Globe) this).mscro4 == 825 && i > 765 && i < 786
			    && i_197_ > 85 && i_197_ < 106)
			    ((Globe) this).mscro4 = 831;
			if (((Globe) this).mscro4 == 825 && i > 765 && i < 786
			    && i_197_ > 341 && i_197_ < 362)
			    ((Globe) this).mscro4 = 832;
			if (((Globe) this).mscro4 == 825 && i > 767 && i < 784
			    && i_197_ > 104 && i_197_ < 343) {
			    ((Globe) this).mscro4 = 119;
			    ((Globe) this).spos4
				= i_197_ - ((Globe) this).mscro4;
			}
			int i_221_ = 2670 / ((Globe) this).sdist;
			if (i_221_ < 1)
			    i_221_ = 1;
			if (((Globe) this).mscro4 == 831) {
			    ((Globe) this).spos4 -= i_221_;
			    if (((Globe) this).spos4 > 208)
				((Globe) this).spos4 = 208;
			    if (((Globe) this).spos4 < 0)
				((Globe) this).spos4 = 0;
			    ((Globe) this).lspos4 = ((Globe) this).spos4;
			}
			if (((Globe) this).mscro4 == 832) {
			    ((Globe) this).spos4 += i_221_;
			    if (((Globe) this).spos4 > 208)
				((Globe) this).spos4 = 208;
			    if (((Globe) this).spos4 < 0)
				((Globe) this).spos4 = 0;
			    ((Globe) this).lspos4 = ((Globe) this).spos4;
			}
			if (((Globe) this).mscro4 < 800) {
			    ((Globe) this).spos4
				= i_197_ - ((Globe) this).mscro4;
			    if (((Globe) this).spos4 > 208)
				((Globe) this).spos4 = 208;
			    if (((Globe) this).spos4 < 0)
				((Globe) this).spos4 = 0;
			}
			if (((Globe) this).mscro4 == 825)
			    ((Globe) this).mscro4 = 925;
		    } else if (((Globe) this).mscro4 != 825)
			((Globe) this).mscro4 = 825;
		}
		((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		if (!drawl(((Globe) this).rd, ((Globe) this).opname, 207, 47,
			   true)) {
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			(((Globe) this).opname,
			 267 - ((Globe) this).ftm
				   .stringWidth(((Globe) this).opname) / 2,
			 66);
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawRect(207, 47, 119, 29);
		}
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawString(new StringBuilder().append
						 ("::  Conversation with ")
						 .append
						 (((Globe) this).opname).append
						 ("").toString(),
					     336, 72);
		if (i > 207 && i < 327 && i_197_ > 47 && i_197_ < 77) {
		    ((Globe) this).cur = 12;
		    if (bool) {
			((Globe) this).tab = 1;
			if (!((Globe) this).proname
				 .equals(((Globe) this).opname)) {
			    ((Globe) this).proname = ((Globe) this).opname;
			    ((Globe) this).loadedp = false;
			    onexitpro();
			}
		    }
		}
		if (stringbutton(((Globe) this).rd, "Block / Ignore", 665, 66,
				 0, i, i_197_, bool, 0, 0)) {
		    ((Globe) this).openc = 0;
		    ((Globe) this).blockname = ((Globe) this).opname;
		}
		if (stringbutton(((Globe) this).rd, "Close X", 752, 66, 0, i,
				 i_197_, bool, 0, 0)) {
		    ((Globe) this).openc = 0;
		    ((Globe) this).readmsg = 0;
		}
		if (!((GameSparker) ((Globe) this).gs).sendtyp.isShowing())
		    ((GameSparker) ((Globe) this).gs).sendtyp.show();
		((GameSparker) ((Globe) this).gs).sendtyp.move(207, 365);
		if (((Globe) this).sendmsg != 0)
		    ((GameSparker) ((Globe) this).gs).sendtyp.disable();
		else
		    ((GameSparker) ((Globe) this).gs).sendtyp.enable();
		String string = "";
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 0) {
		    ((Globe) this).dommsg = true;
		    if (((Globe) this).loaditem != 0)
			((Globe) this).loaditem = 0;
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 1) {
		    string = "car";
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString
			("Send a public car you have or a private car that belongs to you.",
			 376, 382);
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 2) {
		    string = "stage";
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString
			("Send a public stage you have or a private stage that belongs to you.",
			 376, 382);
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 3) {
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString(new StringBuilder().append
						     ("Send an invitation to ")
						     .append
						     (((Globe) this).opname)
						     .append
						     (" to join your clan.")
						     .toString(),
						 376, 382);
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 4) {
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.drawString
			("A date that gets converted to the local time of the person previewing it.",
			 376, 382);
		}
		if (((Globe) this).itemsel
		    != ((GameSparker) ((Globe) this).gs).sendtyp
			   .getSelectedIndex()) {
		    ((GameSparker) ((Globe) this).gs).senditem.hide();
		    ((GameSparker) ((Globe) this).gs).datat.hide();
		    ((Globe) this).itemsel = ((GameSparker) ((Globe) this).gs)
						 .sendtyp.getSelectedIndex();
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 0) {
		    if (((Globe) this).sendmsg == 0) {
			if (stringbutton(((Globe) this).rd, "   Send  >  ",
					 723, 408, 0, i, i_197_, bool, 0, 0)
			    && !((GameSparker) ((Globe) this).gs).mmsg.getText
				    ().trim
				    ().equals("")
			    && (((GameSparker) ((Globe) this).gs).mmsg.getText
				    ().toLowerCase
				    ().indexOf
				(((GameSparker) ((Globe) this).gs).tpass
				     .getText
				     ().toLowerCase())) == -1
			    && ((xtGraphics) ((Globe) this).xt).acexp != -3) {
			    if (!((Globe) this).xt.msgcheck(((GameSparker)
							     ((Globe) this).gs)
								.mmsg
								.getText()))
				((Globe) this).sendmsg = 1;
			    else {
				((GameSparker) ((Globe) this).gs).sendtyp
				    .hide();
				((xtGraphics) ((Globe) this).xt).warning++;
			    }
			}
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("Sending...",
			     723 - ((Globe) this).ftm
				       .stringWidth("Sending...") / 2,
			     408);
		    }
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex() == 1
		    || ((GameSparker) ((Globe) this).gs).sendtyp
			   .getSelectedIndex() == 2) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString(new StringBuilder().append
						     ("Select ").append
						     (string).append
						     (" to share:").toString(),
						 207, 420);
		    if (!((GameSparker) ((Globe) this).gs).senditem
			     .isShowing()) {
			((GameSparker) ((Globe) this).gs).senditem.removeAll();
			if (((xtGraphics) ((Globe) this).xt).logged) {
			    ((GameSparker) ((Globe) this).gs).senditem.add
				(((Globe) this).rd,
				 new StringBuilder().append
				     ("Loading your ").append
				     (string).append
				     (" list, please wait...").toString());
			    ((Globe) this).loaditem
				= ((GameSparker) ((Globe) this).gs).sendtyp
				      .getSelectedIndex();
			} else
			    ((GameSparker) ((Globe) this).gs).senditem.add
				(((Globe) this).rd,
				 new StringBuilder().append
				     ("You need to upgrade to have custom ")
				     .append
				     (string).append
				     ("s!").toString());
			((GameSparker) ((Globe) this).gs).senditem.select(0);
			((GameSparker) ((Globe) this).gs).senditem.show();
		    }
		    ((GameSparker) ((Globe) this).gs).senditem.move
			((207
			  + ((Globe) this).ftm.stringWidth(new StringBuilder
							       ().append
							       ("Select ")
							       .append
							       (string).append
							       (" to share:")
							       .toString())
			  + 11),
			 403);
		    if ((((Globe) this).loaditem == 10
			 && ((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 1)
			|| (((Globe) this).loaditem == 20
			    && ((GameSparker) ((Globe) this).gs).sendtyp
				   .getSelectedIndex() == 2)
			|| !((xtGraphics) ((Globe) this).xt).logged) {
			if (((xtGraphics) ((Globe) this).xt).logged) {
			    if (((Globe) this).sendmsg == 0) {
				if (stringbutton(((Globe) this).rd,
						 "   Send  >  ", 723, 420, 0,
						 i, i_197_, bool, 0, 0))
				    ((Globe) this).sendmsg = 1;
			    } else
				((Globe) this).rd.drawString
				    ("Sending...",
				     723 - ((Globe) this).ftm
					       .stringWidth("Sending...") / 2,
				     420);
			} else {
			    ((Globe) this).rd.setColor(new Color(206, 171,
								 98));
			    ((Globe) this).rd.fillRoundRect(651, 391, 136, 46,
							    20, 20);
			    if (drawbutton((((xtGraphics) ((Globe) this).xt)
					    .upgrade),
					   719, 414, i, i_197_, bool))
				((Globe) this).gs.editlink((((xtGraphics)
							     ((Globe) this).xt)
							    .nickname),
							   true);
			}
		    }
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 3) {
		    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
			int i_222_ = 306;
			int i_223_ = -195;
			if (!drawl(((Globe) this).rd,
				   new StringBuilder().append("#").append
				       (((xtGraphics) ((Globe) this).xt).clan)
				       .append
				       ("#").toString(),
				   406 + i_223_, 101 + i_222_, true)) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       13));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				(new StringBuilder().append("").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     ("").toString(),
				 (581 + i_223_
				  - (((Globe) this).ftm.stringWidth
				     (new StringBuilder().append("").append
					  (((xtGraphics) ((Globe) this).xt)
					   .clan)
					  .append
					  ("").toString())) / 2),
				 121 + i_222_);
			}
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			String string_224_ = "Your Clan";
			if (i > 402 + i_223_ && i < 759 + i_223_
			    && i_197_ > 84 + i_222_ && i_197_ < 134 + i_222_) {
			    string_224_
				= new StringBuilder().append("Clan :  ").append
				      (((xtGraphics) ((Globe) this).xt).clan)
				      .append
				      ("").toString();
			    ((Globe) this).rd.drawLine
				(408 + i_223_, 98 + i_222_,
				 408 + i_223_ + ((Globe) this).ftm
						    .stringWidth(string_224_),
				 98 + i_222_);
			    if ((i > 408 + i_223_
				 && i < (408 + i_223_
					 + ((Globe) this).ftm
					       .stringWidth(string_224_))
				 && i_197_ > 85 + i_222_
				 && i_197_ < 100 + i_222_)
				|| (i > 406 + i_223_ && i < 756 + i_223_
				    && i_197_ > 101 + i_222_
				    && i_197_ < 131 + i_222_)) {
				((Globe) this).cur = 12;
				if (bool && ((Globe) this).sendmsg == 0) {
				    if (!((Globe) this).claname.equals
					 (((xtGraphics) ((Globe) this).xt)
					  .clan)) {
					((Globe) this).claname
					    = (((xtGraphics) ((Globe) this).xt)
					       .clan);
					((Globe) this).loadedc = false;
				    }
				    ((Globe) this).tab = 3;
				    ((Globe) this).spos5 = 0;
				    ((Globe) this).lspos5 = 0;
				    ((Globe) this).cfase = 3;
				    ((Globe) this).ctab = 0;
				}
			    }
			}
			((Globe) this).rd.drawString(string_224_, 408 + i_223_,
						     97 + i_222_);
			((Globe) this).rd.drawLine(402 + i_223_, 84 + i_222_,
						   402 + i_223_, 134 + i_222_);
			((Globe) this).rd.drawLine
			    (402 + i_223_, 84 + i_222_,
			     (408 + i_223_
			      + ((Globe) this).ftm.stringWidth(string_224_)
			      + 2),
			     84 + i_222_);
			((Globe) this).rd.drawLine
			    ((408 + i_223_
			      + ((Globe) this).ftm.stringWidth(string_224_)
			      + 2),
			     84 + i_222_,
			     (408 + i_223_
			      + ((Globe) this).ftm.stringWidth(string_224_)
			      + 15),
			     97 + i_222_);
			((Globe) this).rd.drawLine
			    ((408 + i_223_
			      + ((Globe) this).ftm.stringWidth(string_224_)
			      + 15),
			     97 + i_222_, 759 + i_223_, 97 + i_222_);
			((Globe) this).rd.drawLine(759 + i_223_, 97 + i_222_,
						   759 + i_223_, 134 + i_222_);
			((Globe) this).rd.drawLine(402 + i_223_, 134 + i_222_,
						   759 + i_223_, 134 + i_222_);
		    } else if (((xtGraphics) ((Globe) this).xt).logged) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			if (((Globe) this).flko % 4 != 0
			    || ((Globe) this).flko == 0)
			    ((Globe) this).rd.drawString
				("You are not a member of any clan yet!",
				 (376
				  - ((((Globe) this).ftm.stringWidth
				      ("You are not a member of any clan yet!"))
				     / 2)),
				 417);
			if (((Globe) this).flko != 0)
			    ((Globe) this).flko--;
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("You need to upgrade to a full account to participate in NFM clan's activities.",
			     207, 420);
			((Globe) this).rd.setColor(new Color(206, 171, 98));
			((Globe) this).rd.fillRoundRect(651, 391, 136, 46, 20,
							20);
			if (drawbutton((((xtGraphics) ((Globe) this).xt)
					.upgrade),
				       719, 414, i, i_197_, bool))
			    ((Globe) this).gs.editlink((((xtGraphics)
							 ((Globe) this).xt)
							.nickname),
						       true);
		    }
		    if (((xtGraphics) ((Globe) this).xt).logged) {
			if (((Globe) this).sendmsg == 0) {
			    if (stringbutton(((Globe) this).rd, "   Send  >  ",
					     723, 408, 0, i, i_197_, bool, 0,
					     0)) {
				if (!((xtGraphics) ((Globe) this).xt).clan
					 .equals(""))
				    ((Globe) this).sendmsg = 1;
				else
				    ((Globe) this).flko = 45;
			    }
			} else {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Sending...",
				 723 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 408);
			}
		    }
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 4) {
		    if (!((GameSparker) ((Globe) this).gs).senditem
			     .isShowing()) {
			((GameSparker) ((Globe) this).gs).senditem.removeAll();
			Calendar calendar = Calendar.getInstance();
			boolean bool_225_ = false;
			for (int i_226_ = 0; i_226_ < 20; i_226_++) {
			    String[] strings = ((Globe) this).wday;
			    Calendar calendar_227_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    String string_228_
				= strings[calendar_227_.get(7) - 1];
			    if (!bool_225_) {
				string_228_ = "Today";
				bool_225_ = true;
			    }
			    Smenu smenu
				= ((GameSparker) ((Globe) this).gs).senditem;
			    Graphics2D graphics2d = ((Globe) this).rd;
			    StringBuilder stringbuilder
				= new StringBuilder().append("").append
				      (string_228_).append("  -  ");
			    String[] strings_229_ = ((Globe) this).month;
			    Calendar calendar_230_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    StringBuilder stringbuilder_231_
				= stringbuilder.append
				      (strings_229_[calendar_230_.get(2)])
				      .append(" ");
			    Calendar calendar_232_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    smenu.add(graphics2d,
				      stringbuilder_231_.append
					  (calendar_232_.get(5)).append
					  ("").toString());
			    Calendar calendar_233_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    calendar_233_.roll(5, true);
			}
			((GameSparker) ((Globe) this).gs).senditem.select(0);
			((GameSparker) ((Globe) this).gs).senditem.show();
		    }
		    if (!((GameSparker) ((Globe) this).gs).datat.isShowing()) {
			((GameSparker) ((Globe) this).gs).datat.removeAll();
			int i_234_ = 12;
			String string_235_ = "PM";
			for (int i_236_ = 0; i_236_ < 24; i_236_++) {
			    ((GameSparker) ((Globe) this).gs).datat.add
				(((Globe) this).rd,
				 new StringBuilder().append("").append
				     (i_234_).append
				     (" ").append
				     (string_235_).append
				     ("").toString());
			    if (++i_234_ == 12)
				string_235_ = "AM";
			    if (i_234_ == 13)
				i_234_ = 1;
			}
			((GameSparker) ((Globe) this).gs).datat.select(0);
			((GameSparker) ((Globe) this).gs).datat.show();
		    }
		    ((GameSparker) ((Globe) this).gs).senditem.move(300, 395);
		    ((GameSparker) ((Globe) this).gs).datat.move(491, 395);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Date is displayed based on your computer calendar's date/time, please make sure it is correct.",
			 207, 435);
		    if (((Globe) this).sendmsg == 0) {
			if (stringbutton(((Globe) this).rd, "   Send  >  ",
					 723, 408, 0, i, i_197_, bool, 0, 0))
			    ((Globe) this).sendmsg = 1;
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("Sending...",
			     723 - ((Globe) this).ftm
				       .stringWidth("Sending...") / 2,
			     408);
		    }
		}
	    }
	    if (((Globe) this).openc >= 1 && ((Globe) this).openc < 10) {
		((Globe) this).rd.setColor(color2k(240, 240, 230));
		((Globe) this).rd.fillRoundRect(197, ((Globe) this).opy, 597,
						((Globe) this).oph, 20, 20);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawRoundRect(197, ((Globe) this).opy, 597,
						((Globe) this).oph, 20, 20);
		if (!drawl(((Globe) this).rd, ((Globe) this).opname, 207,
			   ((Globe) this).opy + 7, true)) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			(((Globe) this).opname,
			 267 - ((Globe) this).ftm
				   .stringWidth(((Globe) this).opname) / 2,
			 ((Globe) this).opy + 26);
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawRect(207, ((Globe) this).opy + 7,
					       119, 29);
		}
		((Globe) this).opy += ((Globe) this).addopy;
		((Globe) this).oph += 36;
		((Globe) this).openc++;
	    }
	}
	if (((Globe) this).itab == 1) {
	    if (((Globe) this).litab != ((Globe) this).itab) {
		((Globe) this).spos3 = 0;
		((GameSparker) ((Globe) this).gs).senditem.hide();
		((GameSparker) ((Globe) this).gs).datat.hide();
		((GameSparker) ((Globe) this).gs).sendtyp.removeAll();
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Write a Message");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Share a Relative Date");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Battle over Stage");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Battle over Car");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Declare War");
		if (!((Globe) this).redif)
		    ((GameSparker) ((Globe) this).gs).sendtyp.select(0);
		else {
		    ((GameSparker) ((Globe) this).gs).sendtyp
			.select(((Globe) this).intsel);
		    if (((Globe) this).intsel == 4)
			((Globe) this).redif = false;
		}
		if (((Globe) this).sendwarnum)
		    ((Smenu) ((GameSparker) ((Globe) this).gs).sendtyp).sel
			= ((Globe) this).intsel;
		((Globe) this).intsel = 0;
		((Globe) this).litab = ((Globe) this).itab;
	    }
	    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		if (((Globe) this).openi != 10) {
		    ((Globe) this).rd.setColor(color2k(230, 230, 230));
		    ((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
		    if (((Globe) this).loadinter != 0
			&& ((Globe) this).loadinter != -2
			&& ((Globe) this).loadinter != -1) {
			((Globe) this).sdist = (((Globe) this).ni - 10) * 31;
			if (((Globe) this).sdist < 0)
			    ((Globe) this).sdist = 0;
			((Globe) this).scro
			    = (int) ((float) ((Globe) this).spos3 / 268.0F
				     * (float) ((Globe) this).sdist);
			int i_237_ = 0;
			for (int i_238_ = 0; i_238_ < ((Globe) this).ni;
			     i_238_++) {
			    if (76 + 31 * i_237_ - ((Globe) this).scro < 408
				&& (107 + 31 * i_237_ - ((Globe) this).scro
				    > 76)) {
				boolean bool_239_ = false;
				if (i > 207 && i < 770
				    && i_197_ > (76 + 31 * i_237_
						 - ((Globe) this).scro)
				    && i_197_ < (106 + 31 * i_237_
						 - ((Globe) this).scro)) {
				    bool_239_ = true;
				    ((Globe) this).cur = 12;
				    if (bool && ((Globe) this).openc == 0) {
					((Globe) this).opy
					    = (70 + 31 * i_237_
					       - ((Globe) this).scro);
					((Globe) this).addopy
					    = (40 - ((Globe) this).opy) / 10;
					((Globe) this).oph = 44;
					((Globe) this).openi = 1;
					if (!((Globe) this).intclan.equals
					     (((Globe) this).iclan[i_238_])) {
					    ((Globe) this).intclan
						= ((Globe) this).iclan[i_238_];
					    ((Globe) this).dispi = 0;
					    ((Globe) this).nil = 0;
					    ((Globe) this).lastint = "";
					    ((Globe) this).readint = 1;
					}
				    }
				}
				if ((((Globe) this).icheck[i_238_].toLowerCase
					 ().indexOf
				     (((xtGraphics) ((Globe) this).xt)
					  .nickname.toLowerCase()))
				    == -1) {
				    ((Globe) this).rd
					.setColor(color2k(240, 240, 240));
				    ((Globe) this).rd.fillRect(207,
							       (77
								+ 31 * i_237_
								- ((Globe)
								   this).scro),
							       564, 30);
				}
				if (bool_239_) {
				    ((Globe) this).rd
					.setColor(color2k(250, 250, 250));
				    ((Globe) this).rd.fillRect(207,
							       (77
								+ 31 * i_237_
								- ((Globe)
								   this).scro),
							       564, 30);
				}
				boolean bool_240_
				    = drawl(((Globe) this).rd,
					    new StringBuilder().append("#")
						.append
						(((Globe) this).iclan[i_238_])
						.append
						("#").toString(),
					    207,
					    (77 + 31 * i_237_
					     - ((Globe) this).scro),
					    bool_239_);
				if (!bool_239_ || !bool_240_) {
				    ((Globe) this).rd.setFont(new Font("Arial",
								       1, 12));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd.drawString
					(((Globe) this).iclan[i_238_],
					 382 - (((Globe) this).ftm.stringWidth
						(((Globe) this).iclan
						 [i_238_])) / 2,
					 (96 + 31 * i_237_
					  - ((Globe) this).scro));
				}
				((Globe) this).rd.setFont(new Font("Tahoma", 0,
								   11));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.setColor(color2k(125, 125,
								   125));
				((Globe) this).rd.drawString
				    (((Globe) this).itime[i_238_],
				     760 - (((Globe) this).ftm.stringWidth
					    (((Globe) this).itime[i_238_])),
				     102 + 31 * i_237_ - ((Globe) this).scro);
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				((Globe) this).rd.drawString
				    (((Globe) this).isub[i_238_], 565,
				     89 + 31 * i_237_ - ((Globe) this).scro);
				((Globe) this).rd.setFont(new Font("Arial", 1,
								   11));
				((Globe) this).rd.setColor(new Color(117, 67,
								     0));
				((Globe) this).rd.drawString
				    (((Globe) this).istat[i_238_], 565,
				     102 + 31 * i_237_ - ((Globe) this).scro);
				((Globe) this).rd.setColor(color2k(150, 150,
								   150));
				((Globe) this).rd.drawLine
				    (207,
				     107 + 31 * i_237_ - ((Globe) this).scro,
				     770,
				     107 + 31 * i_237_ - ((Globe) this).scro);
			    }
			    i_237_++;
			}
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 46, 582, 30);
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			String[] strings
			    = { "Player Interaction", "Clan Interaction",
				"Your Clan's Discussion" };
			int[] is = { 207, 390, 368, 207 };
			int[] is_241_ = { 73, 73, 51, 51 };
			for (int i_242_ = 0; i_242_ < 3; i_242_++) {
			    if (((Globe) this).itab == i_242_) {
				((Globe) this).rd.setColor(color2k(230, 230,
								   230));
				((Globe) this).rd.fillPolygon(is, is_241_, 4);
			    } else if (i > is[0] && i < is[2] && i_197_ > 51
				       && i_197_ < 73) {
				((Globe) this).rd.setColor(color2k(217, 217,
								   217));
				((Globe) this).rd.fillPolygon(is, is_241_, 4);
				if (bool)
				    ((Globe) this).itab = i_242_;
			    }
			    ((Globe) this).rd.setColor(color2k(150, 150, 150));
			    ((Globe) this).rd.drawPolygon(is, is_241_, 4);
			    ((Globe) this).rd.setColor(color2k(40, 40, 40));
			    ((Globe) this).rd.drawString
				(strings[i_242_],
				 (is[0] + 80
				  - ((Globe) this).ftm
					.stringWidth(strings[i_242_]) / 2),
				 67);
			    for (int i_243_ = 0; i_243_ < 4; i_243_++)
				is[i_243_] += 183;
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 73, 770, 73);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 409, 582, 30);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 411, 770, 411);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(772, 93, 17, 299);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(203, 46, 4, 393);
			if (((Globe) this).mscro3 == 831
			    || ((Globe) this).sdist == 0) {
			    if (((Globe) this).sdist == 0)
				((Globe) this).rd.setColor(color2k(205, 205,
								   205));
			    else
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fillRect(772, 76, 17, 17);
			} else {
			    ((Globe) this).rd.setColor(color2k(220, 220, 220));
			    ((Globe) this).rd.fill3DRect(772, 76, 17, 17,
							 true);
			}
			if (((Globe) this).sdist != 0)
			    ((Globe) this).rd.drawImage((((xtGraphics)
							  ((Globe) this).xt)
							 .asu),
							777, 82, null);
			if (((Globe) this).mscro3 == 832
			    || ((Globe) this).sdist == 0) {
			    if (((Globe) this).sdist == 0)
				((Globe) this).rd.setColor(color2k(205, 205,
								   205));
			    else
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fillRect(772, 392, 17, 17);
			} else {
			    ((Globe) this).rd.setColor(color2k(220, 220, 220));
			    ((Globe) this).rd.fill3DRect(772, 392, 17, 17,
							 true);
			}
			if (((Globe) this).sdist != 0)
			    ((Globe) this).rd.drawImage((((xtGraphics)
							  ((Globe) this).xt)
							 .asd),
							777, 399, null);
			if (((Globe) this).sdist != 0) {
			    if (((Globe) this).lspos3
				!= ((Globe) this).spos3) {
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
				((Globe) this).rd.fillRect(772,
							   93 + (((Globe) this)
								 .spos3),
							   17, 31);
			    } else {
				if (((Globe) this).mscro3 == 831)
				    ((Globe) this).rd
					.setColor(color2k(215, 215, 215));
				((Globe) this).rd.fill3DRect(772,
							     93 + ((Globe)
								   this).spos3,
							     17, 31, true);
			    }
			    ((Globe) this).rd.setColor(color2k(150, 150, 150));
			    ((Globe) this).rd.drawLine
				(777, 106 + ((Globe) this).spos3, 783,
				 106 + ((Globe) this).spos3);
			    ((Globe) this).rd.drawLine
				(777, 108 + ((Globe) this).spos3, 783,
				 108 + ((Globe) this).spos3);
			    ((Globe) this).rd.drawLine
				(777, 110 + ((Globe) this).spos3, 783,
				 110 + ((Globe) this).spos3);
			    if (((Globe) this).mscro3 > 800
				&& (((Globe) this).lspos3
				    != ((Globe) this).spos3))
				((Globe) this).lspos3 = ((Globe) this).spos3;
			    if (bool && ((Globe) this).openc == 0) {
				if (((Globe) this).mscro3 == 825 && i > 772
				    && i < 789
				    && i_197_ > 93 + ((Globe) this).spos3
				    && i_197_ < ((Globe) this).spos3 + 124)
				    ((Globe) this).mscro3
					= i_197_ - ((Globe) this).spos3;
				if (((Globe) this).mscro3 == 825 && i > 770
				    && i < 791 && i_197_ > 74 && i_197_ < 95)
				    ((Globe) this).mscro3 = 831;
				if (((Globe) this).mscro3 == 825 && i > 770
				    && i < 791 && i_197_ > 390 && i_197_ < 411)
				    ((Globe) this).mscro3 = 832;
				if (((Globe) this).mscro3 == 825 && i > 772
				    && i < 789 && i_197_ > 93
				    && i_197_ < 392) {
				    ((Globe) this).mscro3 = 108;
				    ((Globe) this).spos3
					= i_197_ - ((Globe) this).mscro3;
				}
				int i_244_ = 2670 / ((Globe) this).sdist;
				if (i_244_ < 1)
				    i_244_ = 1;
				if (((Globe) this).mscro3 == 831) {
				    ((Globe) this).spos3 -= i_244_;
				    if (((Globe) this).spos3 > 268)
					((Globe) this).spos3 = 268;
				    if (((Globe) this).spos3 < 0)
					((Globe) this).spos3 = 0;
				    ((Globe) this).lspos3
					= ((Globe) this).spos3;
				}
				if (((Globe) this).mscro3 == 832) {
				    ((Globe) this).spos3 += i_244_;
				    if (((Globe) this).spos3 > 268)
					((Globe) this).spos3 = 268;
				    if (((Globe) this).spos3 < 0)
					((Globe) this).spos3 = 0;
				    ((Globe) this).lspos3
					= ((Globe) this).spos3;
				}
				if (((Globe) this).mscro3 < 800) {
				    ((Globe) this).spos3
					= i_197_ - ((Globe) this).mscro3;
				    if (((Globe) this).spos3 > 268)
					((Globe) this).spos3 = 268;
				    if (((Globe) this).spos3 < 0)
					((Globe) this).spos3 = 0;
				}
				if (((Globe) this).mscro3 == 825)
				    ((Globe) this).mscro3 = 925;
			    } else if (((Globe) this).mscro3 != 825)
				((Globe) this).mscro3 = 825;
			}
		    } else {
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 46, 582, 30);
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			String[] strings
			    = { "Player Interaction", "Clan Interaction",
				"Your Clan's Discussion" };
			int[] is = { 207, 390, 368, 207 };
			int[] is_245_ = { 73, 73, 51, 51 };
			for (int i_246_ = 0; i_246_ < 3; i_246_++) {
			    if (((Globe) this).itab == i_246_) {
				((Globe) this).rd.setColor(color2k(230, 230,
								   230));
				((Globe) this).rd.fillPolygon(is, is_245_, 4);
			    } else if (i > is[0] && i < is[2] && i_197_ > 51
				       && i_197_ < 73) {
				((Globe) this).rd.setColor(color2k(217, 217,
								   217));
				((Globe) this).rd.fillPolygon(is, is_245_, 4);
				if (bool)
				    ((Globe) this).itab = i_246_;
			    }
			    ((Globe) this).rd.setColor(color2k(150, 150, 150));
			    ((Globe) this).rd.drawPolygon(is, is_245_, 4);
			    ((Globe) this).rd.setColor(color2k(40, 40, 40));
			    ((Globe) this).rd.drawString
				(strings[i_246_],
				 (is[0] + 80
				  - ((Globe) this).ftm
					.stringWidth(strings[i_246_]) / 2),
				 67);
			    for (int i_247_ = 0; i_247_ < 4; i_247_++)
				is[i_247_] += 183;
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 73, 770, 73);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(207, 409, 582, 30);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(207, 411, 770, 411);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(772, 76, 17, 333);
			((Globe) this).rd.setColor(color2k(205, 205, 205));
			((Globe) this).rd.fillRect(203, 46, 4, 393);
			if (((Globe) this).loadinter == 0) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("You have not started any interactions with other clans yet.",
				 (487
				  - ((((Globe) this).ftm.stringWidth
				      ("You have not started any interactions with other clans yet."))
				     / 2)),
				 200);
			}
			if (((Globe) this).loadinter == -2) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Failed to load interactions, will try again now...",
				 (487
				  - ((((Globe) this).ftm.stringWidth
				      ("Failed to load interactions, will try again now..."))
				     / 2)),
				 200);
			}
			if (((Globe) this).loadinter == -1) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Loading interactions, please wait...",
				 (487
				  - ((((Globe) this).ftm.stringWidth
				      ("Loading interactions, please wait..."))
				     / 2)),
				 200);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp.isShowing())
			((GameSparker) ((Globe) this).gs).sendtyp.hide();
		    if (((GameSparker) ((Globe) this).gs).senditem.isShowing())
			((GameSparker) ((Globe) this).gs).senditem.hide();
		    if (((GameSparker) ((Globe) this).gs).datat.isShowing())
			((GameSparker) ((Globe) this).gs).datat.hide();
		    ((GameSparker) ((Globe) this).gs).ilaps.hide();
		    ((GameSparker) ((Globe) this).gs).icars.hide();
		    ((GameSparker) ((Globe) this).gs).sclass.hide();
		    ((GameSparker) ((Globe) this).gs).sfix.hide();
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			!= 0) {
			((GameSparker) ((Globe) this).gs).sendtyp.select(0);
			((Globe) this).intsel = 0;
		    }
		} else {
		    ((Globe) this).rd.setColor(color2k(240, 240, 240));
		    ((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
		    ((Globe) this).rd.setColor(color2k(250, 250, 250));
		    ((Globe) this).rd.fillRect(207, 86, 577, 274);
		    if (((Globe) this).intclanlo.equals(((Globe) this).intclan)
			&& ((Globe) this).intclanbgloaded) {
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 0.1F));
			((Globe) this).rd.drawImage(((Globe) this).intclanbg,
						    207, 86, null);
			((Globe) this).rd
			    .setComposite(AlphaComposite.getInstance(3, 1.0F));
		    }
		    ((Globe) this).sdist = 0;
		    if ((((Globe) this).readint == 2
			 || ((Globe) this).readint == 1)
			&& ((Globe) this).viewgame2 == 0) {
			((Globe) this).sdist
			    = (int) (((float) ((Globe) this).nil - 14.75F)
				     * 17.0F);
			if (((Globe) this).sdist < 0)
			    ((Globe) this).sdist = 0;
			((Globe) this).scro
			    = (int) ((float) ((Globe) this).spos4 / 208.0F
				     * (float) ((Globe) this).sdist);
			if (((GameSparker) ((Globe) this).gs).openm)
			    ((Globe) this).blockb = 10;
			else if (((Globe) this).blockb != 0)
			    ((Globe) this).blockb--;
			for (int i_248_ = 0; i_248_ < ((Globe) this).nil;
			     i_248_++) {
			    if (86 + 17 * i_248_ - ((Globe) this).scro < 360
				&& 125 + 17 * i_248_ - ((Globe) this).scro > 86
				&& ((Globe) this).ilinetyp[i_248_] != 167) {
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				if (((Globe) this).ilinetyp[i_248_] != 20
				    && ((Globe) this).ilinetyp[i_248_] != 30
				    && ((Globe) this).ilinetyp[i_248_] != 40
				    && ((Globe) this).ilinetyp[i_248_] != 80
				    && ((Globe) this).ilinetyp[i_248_] != 90
				    && (((Globe) this).ilinetyp[i_248_]
					!= 100)) {
				    if (((Globe) this).ilinetyp[i_248_] >= 0)
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 1, 11));
				    else
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
				    ((Globe) this).rd.drawString
					(((Globe) this).iline[i_248_], 217,
					 (103 + 17 * i_248_
					  - ((Globe) this).scro));
				    if (((Globe) this).ilinetyp[i_248_] >= 0) {
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					((Globe) this).rd
					    .setColor(color2k(125, 125, 125));
					((Globe) this).rd.drawString
					    (((Globe) this).itimes[i_248_],
					     757 - (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).itimes
						     [i_248_])),
					     (103 + 17 * i_248_
					      - ((Globe) this).scro));
				    }
				} else {
				    if (((Globe) this).ilinetyp[i_248_]
					== 40) {
					if (stringbutton
					    (((Globe) this).rd,
					     "  View War Declaration  ", 300,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 4;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    1);
					    if (((Globe) this).iline
						    [i_248_].startsWith("I|"))
						((Globe) this).ichlng = true;
					    else
						((Globe) this).ichlng = false;
					}
					if (!((Globe) this).iline[i_248_]
						 .endsWith("|out|")) {
					    if (((Globe) this).iline
						    [i_248_].startsWith("Y|")
						&& (stringbutton
						    (((Globe) this).rd,
						     "  Accept War  ", 441,
						     (112 + 17 * i_248_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0))) {
						((Smenu) (((GameSparker)
							   ((Globe) this).gs)
							  .sendtyp)).sel
						    = 7;
						((Globe) this).sendwar
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								1);
					    }
					} else {
					    ((Globe) this).rd.setColor
						(color2k(170, 170, 170));
					    ((Globe) this).rd.drawString
						("[ Accepted or interaction replaced. ]",
						 (490
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("[ Accepted or interaction replaced. ]"))
						     / 2)),
						 (112 + 17 * i_248_
						  - ((Globe) this).scro));
					}
				    }
				    if (((Globe) this).ilinetyp[i_248_]
					== 30) {
					if (stringbutton(((Globe) this).rd,
							 "  View Car Battle  ",
							 282,
							 (112 + 17 * i_248_
							  - (((Globe) this)
							     .scro)),
							 0, i, i_197_, bool, 0,
							 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 2;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    3);
					    if (((Globe) this).iline
						    [i_248_].startsWith("I|"))
						((Globe) this).ichlng = true;
					    else
						((Globe) this).ichlng = false;
					}
					if (!((Globe) this).iline[i_248_]
						 .endsWith("|out|")) {
					    if (((Globe) this).iline
						    [i_248_].startsWith("Y|")
						&& (stringbutton
						    (((Globe) this).rd,
						     "  Accept Battle  ", 410,
						     (112 + 17 * i_248_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0))) {
						((Smenu) (((GameSparker)
							   ((Globe) this).gs)
							  .sendtyp)).sel
						    = 6;
						((Globe) this).itake
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								1);
						((Globe) this).igive
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								2);
						((Globe) this).sendwar
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								3);
					    }
					} else {
					    ((Globe) this).rd.setColor
						(color2k(170, 170, 170));
					    ((Globe) this).rd.drawString
						("[ Accepted or interaction replaced. ]",
						 (454
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("[ Accepted or interaction replaced. ]"))
						     / 2)),
						 (112 + 17 * i_248_
						  - ((Globe) this).scro));
					}
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (stringbutton
					    (((Globe) this).rd, "  View Car  ",
					     217 + (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).iline
						     [i_248_ + 2])) + 47,
					     (137 + 17 * i_248_
					      - ((Globe) this).scro),
					     6, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    1);
					    if (!((Globe) this).claname.equals
						 (((Globe) this).intclan)) {
						((Globe) this).claname
						    = ((Globe) this).intclan;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedcars = -1;
					    ((Globe) this).loadedcar = 0;
					    ((Globe) this).ctab = 2;
					    ((Globe) this).tab = 3;
					}
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (stringbutton
					    (((Globe) this).rd, "  View Car  ",
					     217 + (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).iline
						     [i_248_ + 3])) + 47,
					     (154 + 17 * i_248_
					      - ((Globe) this).scro),
					     6, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    2);
					    if (!((Globe) this).claname.equals
						 (((xtGraphics)
						   ((Globe) this).xt).clan)) {
						((Globe) this).claname
						    = ((xtGraphics)
						       ((Globe) this).xt).clan;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedcars = -1;
					    ((Globe) this).loadedcar = 0;
					    ((Globe) this).ctab = 2;
					    ((Globe) this).tab = 3;
					}
				    }
				    if (((Globe) this).ilinetyp[i_248_]
					== 20) {
					if (stringbutton
					    (((Globe) this).rd,
					     "  View Stage Battle  ", 289,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 2;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    3);
					    if (((Globe) this).iline
						    [i_248_].startsWith("I|"))
						((Globe) this).ichlng = true;
					    else
						((Globe) this).ichlng = false;
					}
					if (!((Globe) this).iline[i_248_]
						 .endsWith("|out|")) {
					    if (((Globe) this).iline
						    [i_248_].startsWith("Y|")
						&& (stringbutton
						    (((Globe) this).rd,
						     "  Accept Battle  ", 424,
						     (112 + 17 * i_248_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0))) {
						((Smenu) (((GameSparker)
							   ((Globe) this).gs)
							  .sendtyp)).sel
						    = 5;
						((Globe) this).itake
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								1);
						((Globe) this).igive
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								2);
						((Globe) this).sendwar
						    = getSvalue((((Globe) this)
								 .iline
								 [i_248_]),
								3);
					    }
					} else {
					    ((Globe) this).rd.setColor
						(color2k(170, 170, 170));
					    ((Globe) this).rd.drawString
						("[ Accepted or interaction replaced. ]",
						 (468
						  - ((((Globe) this).ftm
							  .stringWidth
						      ("[ Accepted or interaction replaced. ]"))
						     / 2)),
						 (112 + 17 * i_248_
						  - ((Globe) this).scro));
					}
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (stringbutton
					    (((Globe) this).rd,
					     "  View Stage  ",
					     217 + (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).iline
						     [i_248_ + 2])) + 54,
					     (137 + 17 * i_248_
					      - ((Globe) this).scro),
					     6, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    1);
					    if (!((Globe) this).claname.equals
						 (((Globe) this).intclan)) {
						((Globe) this).claname
						    = ((Globe) this).intclan;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedstages = -1;
					    ((Globe) this).loadedstage = 0;
					    ((Globe) this).ctab = 3;
					    ((Globe) this).tab = 3;
					}
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					if (stringbutton
					    (((Globe) this).rd,
					     "  View Stage  ",
					     217 + (((Globe) this).ftm
							.stringWidth
						    (((Globe) this).iline
						     [i_248_ + 3])) + 54,
					     (154 + 17 * i_248_
					      - ((Globe) this).scro),
					     6, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    2);
					    if (!((Globe) this).claname.equals
						 (((xtGraphics)
						   ((Globe) this).xt).clan)) {
						((Globe) this).claname
						    = ((xtGraphics)
						       ((Globe) this).xt).clan;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedstages = -1;
					    ((Globe) this).loadedstage = 0;
					    ((Globe) this).ctab = 3;
					    ((Globe) this).tab = 3;
					}
				    }
				    if (((Globe) this).ilinetyp[i_248_]
					== 80) {
					if (stringbutton
					    (((Globe) this).rd,
					     "        View War        ", 284,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 9;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    0);
					}
					if (stringbutton
					    (((Globe) this).rd,
					     "  View Championship  ", 432,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).cfase = 0;
					    ((Globe) this).ntab = 1;
					    ((Globe) this).loadwstat = 0;
					    ((Globe) this).tab = 3;
					}
				    }
				    if (((Globe) this).ilinetyp[i_248_]
					== 90) {
					if (stringbutton
					    (((Globe) this).rd,
					     "        View Battle        ",
					     284,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 5;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    0);
					}
					if (stringbutton
					    (((Globe) this).rd,
					     "        View Car        ", 424,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    1);
					    String string
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    2);
					    if (!((Globe) this).claname
						     .equals(string)) {
						((Globe) this).claname
						    = string;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedcars = -1;
					    ((Globe) this).loadedcar = 0;
					    ((Globe) this).ctab = 2;
					    ((Globe) this).tab = 3;
					}
				    }
				    if (((Globe) this).ilinetyp[i_248_]
					== 100) {
					if (stringbutton
					    (((Globe) this).rd,
					     "        View Battle        ",
					     284,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewgame2 = 1;
					    ((Globe) this).nvgames2 = 5;
					    ((Globe) this).viewwar2
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    0);
					}
					if (stringbutton
					    (((Globe) this).rd,
					     "        View Stage        ", 431,
					     (112 + 17 * i_248_
					      - ((Globe) this).scro),
					     0, i, i_197_, bool, 0, 0)) {
					    ((Globe) this).viewcar
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    1);
					    String string
						= getSvalue((((Globe) this)
							     .iline[i_248_]),
							    2);
					    if (!((Globe) this).claname
						     .equals(string)) {
						((Globe) this).claname
						    = string;
						((Globe) this).loadedc = false;
					    }
					    ((Globe) this).spos5 = 0;
					    ((Globe) this).lspos5 = 0;
					    ((Globe) this).cfase = 3;
					    ((Globe) this).loadedstages = -1;
					    ((Globe) this).loadedstage = 0;
					    ((Globe) this).ctab = 3;
					    ((Globe) this).tab = 3;
					}
				    }
				}
			    }
			}
		    }
		    if (((Globe) this).readint == 1) {
			((Globe) this).rd.setColor(color2k(240, 240, 240));
			((Globe) this).rd.fillRoundRect(387, 140, 200, 30, 20,
							20);
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawRoundRect(387, 140, 200, 30, 20,
							20);
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("Reading...",
			     487 - ((Globe) this).ftm
				       .stringWidth("Reading...") / 2,
			     160);
		    }
		    if (((Globe) this).readint == 3) {
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Failed to fetch and load interaction.",
			     487 - ((((Globe) this).ftm.stringWidth
				     ("Failed to fetch and load interaction."))
				    / 2),
			     200);
		    }
		    if (((Globe) this).readint == 4) {
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Failed to load interaction, server error, please try again later.",
			     (487
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to load interaction, server error, please try again later."))
				 / 2)),
			     200);
		    }
		    if (((Globe) this).readint == 5) {
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Failed to send interaction, please try again later.",
			     (487
			      - ((((Globe) this).ftm.stringWidth
				  ("Failed to send interaction, please try again later."))
				 / 2)),
			     200);
		    }
		    if (((Globe) this).readint == 6) {
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("The war or battle you are trying to engage has expired or was not found...",
			     (487
			      - ((((Globe) this).ftm.stringWidth
				  ("The war or battle you are trying to engage has expired or was not found..."))
				 / 2)),
			     200);
		    }
		    ((Globe) this).rd.setColor(color2k(240, 240, 240));
		    ((Globe) this).rd.fillRect(207, 47, 577, 39);
		    ((Globe) this).rd.fillRect(207, 360, 577, 70);
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		    ((Globe) this).rd.drawLine(207, 86, 783, 86);
		    ((Globe) this).rd.drawLine(207, 86, 207, 360);
		    ((Globe) this).rd.drawLine(207, 360, 783, 360);
		    ((Globe) this).rd.fillRect(767, 104, 17, 239);
		    if (((Globe) this).mscro4 == 831
			|| ((Globe) this).sdist == 0) {
			if (((Globe) this).sdist == 0)
			    ((Globe) this).rd.setColor(color2k(205, 205, 205));
			else
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fillRect(767, 87, 17, 17);
		    } else {
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fill3DRect(767, 87, 17, 17, true);
		    }
		    if (((Globe) this).sdist != 0)
			((Globe) this).rd.drawImage(((xtGraphics)
						     ((Globe) this).xt).asu,
						    772, 93, null);
		    if (((Globe) this).mscro4 == 832
			|| ((Globe) this).sdist == 0) {
			if (((Globe) this).sdist == 0)
			    ((Globe) this).rd.setColor(color2k(205, 205, 205));
			else
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			((Globe) this).rd.fillRect(767, 343, 17, 17);
		    } else {
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fill3DRect(767, 343, 17, 17, true);
		    }
		    if (((Globe) this).sdist != 0)
			((Globe) this).rd.drawImage(((xtGraphics)
						     ((Globe) this).xt).asd,
						    772, 350, null);
		    if (((Globe) this).sdist != 0) {
			if (((Globe) this).lspos4 != ((Globe) this).spos4) {
			    ((Globe) this).rd.setColor(color2k(215, 215, 215));
			    ((Globe) this).rd.fillRect(767,
						       104 + (((Globe) this)
							      .spos4),
						       17, 31);
			} else {
			    if (((Globe) this).mscro4 == 831)
				((Globe) this).rd.setColor(color2k(215, 215,
								   215));
			    ((Globe) this).rd.fill3DRect(767,
							 104 + (((Globe) this)
								.spos4),
							 17, 31, true);
			}
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawLine(772,
						   117 + ((Globe) this).spos4,
						   778,
						   117 + ((Globe) this).spos4);
			((Globe) this).rd.drawLine(772,
						   119 + ((Globe) this).spos4,
						   778,
						   119 + ((Globe) this).spos4);
			((Globe) this).rd.drawLine(772,
						   121 + ((Globe) this).spos4,
						   778,
						   121 + ((Globe) this).spos4);
			if (((Globe) this).mscro4 > 800
			    && ((Globe) this).lspos4 != ((Globe) this).spos4)
			    ((Globe) this).lspos4 = ((Globe) this).spos4;
			if (bool) {
			    if (((Globe) this).mscro4 == 825 && i > 767
				&& i < 784
				&& i_197_ > 104 + ((Globe) this).spos4
				&& i_197_ < ((Globe) this).spos4 + 135)
				((Globe) this).mscro4
				    = i_197_ - ((Globe) this).spos4;
			    if (((Globe) this).mscro4 == 825 && i > 765
				&& i < 786 && i_197_ > 85 && i_197_ < 106)
				((Globe) this).mscro4 = 831;
			    if (((Globe) this).mscro4 == 825 && i > 765
				&& i < 786 && i_197_ > 341 && i_197_ < 362)
				((Globe) this).mscro4 = 832;
			    if (((Globe) this).mscro4 == 825 && i > 767
				&& i < 784 && i_197_ > 104 && i_197_ < 343) {
				((Globe) this).mscro4 = 119;
				((Globe) this).spos4
				    = i_197_ - ((Globe) this).mscro4;
			    }
			    int i_249_ = 2670 / ((Globe) this).sdist;
			    if (i_249_ < 1)
				i_249_ = 1;
			    if (((Globe) this).mscro4 == 831) {
				((Globe) this).spos4 -= i_249_;
				if (((Globe) this).spos4 > 208)
				    ((Globe) this).spos4 = 208;
				if (((Globe) this).spos4 < 0)
				    ((Globe) this).spos4 = 0;
				((Globe) this).lspos4 = ((Globe) this).spos4;
			    }
			    if (((Globe) this).mscro4 == 832) {
				((Globe) this).spos4 += i_249_;
				if (((Globe) this).spos4 > 208)
				    ((Globe) this).spos4 = 208;
				if (((Globe) this).spos4 < 0)
				    ((Globe) this).spos4 = 0;
				((Globe) this).lspos4 = ((Globe) this).spos4;
			    }
			    if (((Globe) this).mscro4 < 800) {
				((Globe) this).spos4
				    = i_197_ - ((Globe) this).mscro4;
				if (((Globe) this).spos4 > 208)
				    ((Globe) this).spos4 = 208;
				if (((Globe) this).spos4 < 0)
				    ((Globe) this).spos4 = 0;
			    }
			    if (((Globe) this).mscro4 == 825)
				((Globe) this).mscro4 = 925;
			} else if (((Globe) this).mscro4 != 825)
			    ((Globe) this).mscro4 = 825;
		    }
		    if (((Globe) this).dispi != 0) {
			int i_250_ = 558;
			if (((Globe) this).viewgame2 != 0)
			    i_250_ = 577;
			((Globe) this).rd.setColor(color2k(220, 220, 220));
			((Globe) this).rd.fillRect(207, 86, i_250_, 41);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawRect(207, 86, i_250_, 41);
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			if (((Globe) this).dispi == 1) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Car battle with ").append
				     (((Globe) this).intclan).append
				     (" is on!").toString(),
				 215, 101);
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString(new StringBuilder
							     ().append
							     ("You win: [ ")
							     .append
							     (((Globe) this)
							      .dtcar)
							     .append
							     (" ]").toString(),
							 215, 118);
			    int i_251_
				= 215 + (((Globe) this).ftm.stringWidth
					 (new StringBuilder().append
					      ("You win: [ ").append
					      (((Globe) this).dtcar).append
					      (" ]").toString())) + 44;
			    if (stringbutton(((Globe) this).rd, "View Car",
					     i_251_, 119, 6, i, i_197_, bool,
					     0, 0)) {
				((Globe) this).viewcar = ((Globe) this).dtcar;
				if (!((Globe) this).claname
					 .equals(((Globe) this).intclan)) {
				    ((Globe) this).claname
					= ((Globe) this).intclan;
				    ((Globe) this).loadedc = false;
				}
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
				((Globe) this).cfase = 3;
				((Globe) this).loadedcars = -1;
				((Globe) this).loadedcar = 0;
				((Globe) this).ctab = 2;
				((Globe) this).tab = 3;
			    }
			    i_251_ += 44;
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString(new StringBuilder
							     ().append
							     ("You lose: [ ")
							     .append
							     (((Globe) this)
							      .dgcar)
							     .append
							     (" ]").toString(),
							 i_251_, 118);
			    i_251_ += (((Globe) this).ftm.stringWidth
				       (new StringBuilder().append
					    ("You lose: [ ").append
					    (((Globe) this).dgcar).append
					    (" ]").toString())) + 44;
			    if (stringbutton(((Globe) this).rd, "View Car",
					     i_251_, 119, 6, i, i_197_, bool,
					     0, 0)) {
				((Globe) this).viewcar = ((Globe) this).dgcar;
				if (!((Globe) this).claname.equals
				     (((xtGraphics) ((Globe) this).xt).clan)) {
				    ((Globe) this).claname
					= (((xtGraphics) ((Globe) this).xt)
					   .clan);
				    ((Globe) this).loadedc = false;
				}
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
				((Globe) this).cfase = 3;
				((Globe) this).loadedcars = -1;
				((Globe) this).loadedcar = 0;
				((Globe) this).ctab = 2;
				((Globe) this).tab = 3;
			    }
			    if (stringbutton(((Globe) this).rd, "View Battle",
					     714, 111, 0, i, i_197_, bool, 0,
					     0)) {
				((Globe) this).viewgame2 = 1;
				((Globe) this).nvgames2 = 5;
				((Globe) this).viewwar2 = ((Globe) this).dwarn;
			    }
			}
			if (((Globe) this).dispi == 2) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Stage battle with ").append
				     (((Globe) this).intclan).append
				     (" is on!").toString(),
				 215, 101);
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    String string = ((Globe) this).dtcar;
			    if (string.length() > 10)
				string = new StringBuilder().append("").append
					     (string.substring(0, 10)).append
					     ("...").toString();
			    ((Globe) this).rd.drawString(new StringBuilder
							     ().append
							     ("You win: [ ")
							     .append
							     (string).append
							     (" ]").toString(),
							 215, 118);
			    int i_252_ = 215 + (((Globe) this).ftm.stringWidth
						(new StringBuilder().append
						     ("You win: [ ").append
						     (string).append
						     (" ]").toString())) + 51;
			    if (stringbutton(((Globe) this).rd, "View Stage",
					     i_252_, 119, 6, i, i_197_, bool,
					     0, 0)) {
				((Globe) this).viewcar = ((Globe) this).dtcar;
				if (!((Globe) this).claname
					 .equals(((Globe) this).intclan)) {
				    ((Globe) this).claname
					= ((Globe) this).intclan;
				    ((Globe) this).loadedc = false;
				}
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
				((Globe) this).cfase = 3;
				((Globe) this).loadedstages = -1;
				((Globe) this).loadedstage = 0;
				((Globe) this).ctab = 3;
				((Globe) this).tab = 3;
			    }
			    i_252_ += 51;
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       11));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    string = ((Globe) this).dgcar;
			    if (string.length() > 10)
				string = new StringBuilder().append("").append
					     (string.substring(0, 10)).append
					     ("...").toString();
			    ((Globe) this).rd.drawString(new StringBuilder
							     ().append
							     ("You lose: [ ")
							     .append
							     (string).append
							     (" ]").toString(),
							 i_252_, 118);
			    i_252_ += (((Globe) this).ftm.stringWidth
				       (new StringBuilder().append
					    ("You lose: [ ").append
					    (string).append
					    (" ]").toString())) + 51;
			    if (stringbutton(((Globe) this).rd, "View Stage",
					     i_252_, 119, 6, i, i_197_, bool,
					     0, 0)) {
				((Globe) this).viewcar = ((Globe) this).dgcar;
				if (!((Globe) this).claname.equals
				     (((xtGraphics) ((Globe) this).xt).clan)) {
				    ((Globe) this).claname
					= (((xtGraphics) ((Globe) this).xt)
					   .clan);
				    ((Globe) this).loadedc = false;
				}
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
				((Globe) this).cfase = 3;
				((Globe) this).loadedstages = -1;
				((Globe) this).loadedstage = 0;
				((Globe) this).ctab = 3;
				((Globe) this).tab = 3;
			    }
			    if (stringbutton(((Globe) this).rd, "View Battle",
					     714, 111, 0, i, i_197_, bool, 0,
					     0)) {
				((Globe) this).viewgame2 = 1;
				((Globe) this).nvgames2 = 5;
				((Globe) this).viewwar2 = ((Globe) this).dwarn;
			    }
			}
			if (((Globe) this).dispi == 3) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("War between your clan and ").append
				     (((Globe) this).intclan).append
				     (" has started!").toString(),
				 227, 111);
			    if (stringbutton(((Globe) this).rd,
					     "         View War         ", 670,
					     111, 0, i, i_197_, bool, 0, 0)) {
				((Globe) this).viewgame2 = 1;
				((Globe) this).nvgames2 = 9;
				((Globe) this).viewwar2 = ((Globe) this).dwarn;
			    }
			}
		    }
		    if (((Globe) this).viewgame2 != 0) {
			((Globe) this).rd.setColor(color2k(210, 210, 210));
			((Globe) this).rd.fillRoundRect(204, 127, 583, 230, 20,
							20);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawRoundRect(204, 127, 583, 230, 20,
							20);
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			if (((Globe) this).nvgames2 == 4) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("War declaration, your clan ").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     (" versus ").append
				     (((Globe) this).intclan).append
				     (".").toString(),
				 215, 145);
			    if (((Globe) this).viewgame2 == 2) {
				if (((Globe) this).ichlng)
				    ((Globe) this).rd.drawString
					(new StringBuilder().append("").append
					     (((Globe) this).intclan).append
					     (" would create 5 more games and the first clan to win 5 games wins the war!")
					     .toString(),
					 215,
					 210 + ((Globe) this).nvgames2 * 18);
				else
				    ((Globe) this).rd.drawString
					("Your clan would create 5 more games and the first clan to win 5 games wins the war!",
					 215,
					 210 + ((Globe) this).nvgames2 * 18);
			    }
			}
			if (((Globe) this).nvgames2 == 2) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Battle, your clan ").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     (" versus ").append
				     (((Globe) this).intclan).append
				     (".").toString(),
				 215, 145);
			    if (((Globe) this).viewgame2 == 2) {
				if (((Globe) this).ichlng)
				    ((Globe) this).rd.drawString
					(new StringBuilder().append("").append
					     (((Globe) this).intclan).append
					     (" would create 3 more games and the first clan to win 3 games wins the battle!")
					     .toString(),
					 215,
					 210 + ((Globe) this).nvgames2 * 18);
				else
				    ((Globe) this).rd.drawString
					("Your clan would create 3 more games and the first clan to win 3 games wins the battle!",
					 215,
					 210 + ((Globe) this).nvgames2 * 18);
			    }
			}
			if ((((Globe) this).nvgames2 == 9
			     || ((Globe) this).nvgames2 == 5)
			    && ((Globe) this).viewgame2 == 2) {
			    ((Globe) this).rd.drawString
				(new StringBuilder().append("").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     ("  ").append
				     (((Globe) this).vwscorex).append
				     ("           |           ").append
				     (((Globe) this).intclan).append
				     ("  ").append
				     (((Globe) this).vwscorei).append
				     ("").toString(),
				 505 - (((Globe) this).ftm.stringWidth
					(new StringBuilder().append("").append
					     (((xtGraphics) ((Globe) this).xt)
					      .clan)
					     .append
					     ("  ").append
					     (((Globe) this).vwscorex).append
					     ("           |           ").append
					     (((Globe) this).intclan).append
					     ("  ").append
					     (((Globe) this).vwscorei).append
					     ("").toString())) / 2,
				 145);
			    ((Globe) this).rd.drawRect(320, 131, 370, 19);
			}
			if (stringbutton(((Globe) this).rd, "Close X", 749,
					 148, 3, i, i_197_, bool, 0, 0))
			    ((Globe) this).viewgame2 = 0;
			((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			if (((Globe) this).viewgame2 == 2) {
			    ((Globe) this).rd.drawString
				("Game",
				 246 - (((Globe) this).ftm.stringWidth("Game")
					/ 2),
				 175);
			    ((Globe) this).rd.drawString
				("Stage",
				 412 - (((Globe) this).ftm.stringWidth("Stage")
					/ 2),
				 175);
			    ((Globe) this).rd.drawString
				("Laps",
				 564 - (((Globe) this).ftm.stringWidth("Laps")
					/ 2),
				 175);
			    ((Globe) this).rd.drawString
				("Type of Cars",
				 653 - ((Globe) this).ftm
					   .stringWidth("Type of Cars") / 2,
				 175);
			    ((Globe) this).rd.drawString
				("Fixing",
				 751 - ((Globe) this).ftm
					   .stringWidth("Fixing") / 2,
				 175);
			    int i_253_ = 1;
			    int i_254_ = 1;
			    if (((Globe) this).nvgames2 == 4
				|| ((Globe) this).nvgames2 == 2) {
				i_253_ = 2;
				i_254_ = 2;
			    }
			    for (int i_255_ = 0;
				 i_255_ < ((Globe) this).nvgames2; i_255_++) {
				if (!((Globe) this).vwinner[i_255_]
					 .equals("")) {
				    ((Globe) this).rd
					.setColor(color2k(220, 220, 220));
				    ((Globe) this).rd.fillRect(213,
							       (180
								+ i_255_ * 18),
							       565, 18);
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				}
				((Globe) this).rd.setFont(new Font("Tahoma", 0,
								   11));
				((Globe) this).ftm
				    = ((Globe) this).rd.getFontMetrics();
				((Globe) this).rd.drawString
				    (new StringBuilder().append("# ").append
					 (i_253_).append
					 ("").toString(),
				     246 - (((Globe) this).ftm.stringWidth
					    (new StringBuilder().append
						 ("# ").append
						 (i_253_).append
						 ("").toString())) / 2,
				     193 + i_255_ * 18);
				i_253_ += i_254_;
				((Globe) this).rd.drawString
				    (((Globe) this).vwstages2[i_255_],
				     412 - (((Globe) this).ftm.stringWidth
					    (((Globe) this).vwstages2
					     [i_255_])) / 2,
				     193 + i_255_ * 18);
				((Globe) this).rd.drawString
				    (new StringBuilder().append("").append
					 (((Globe) this).vwlaps2[i_255_])
					 .append
					 ("").toString(),
				     (564
				      - (((Globe) this).ftm.stringWidth
					 (new StringBuilder().append("").append
					      (((Globe) this).vwlaps2[i_255_])
					      .append
					      ("").toString())) / 2),
				     193 + i_255_ * 18);
				String string = "All Cars";
				if (((Globe) this).vwcars2[i_255_] == 2)
				    string = "Clan Cars";
				if (((Globe) this).vwcars2[i_255_] == 3)
				    string = "Game Cars";
				if (((Globe) this).vwclass2[i_255_] == 0)
				    string = new StringBuilder().append
						 (string).append
						 (", All Classes").toString();
				if (((Globe) this).vwclass2[i_255_] == 1)
				    string = new StringBuilder().append
						 (string).append
						 (", Class C").toString();
				if (((Globe) this).vwclass2[i_255_] == 2)
				    string = new StringBuilder().append
						 (string).append
						 (", Class B & C").toString();
				if (((Globe) this).vwclass2[i_255_] == 3)
				    string = new StringBuilder().append
						 (string).append
						 (", Class B").toString();
				if (((Globe) this).vwclass2[i_255_] == 4)
				    string = new StringBuilder().append
						 (string).append
						 (", Class A & B").toString();
				if (((Globe) this).vwclass2[i_255_] == 5)
				    string = new StringBuilder().append
						 (string).append
						 (", Class A").toString();
				((Globe) this).rd.drawString
				    (string,
				     653 - ((Globe) this).ftm
					       .stringWidth(string) / 2,
				     193 + i_255_ * 18);
				String string_256_ = "Infinite";
				if (((Globe) this).vwfix2[i_255_] == 1)
				    string_256_ = "4 Fixes";
				if (((Globe) this).vwfix2[i_255_] == 2)
				    string_256_ = "3 Fixes";
				if (((Globe) this).vwfix2[i_255_] == 3)
				    string_256_ = "2 Fixes";
				if (((Globe) this).vwfix2[i_255_] == 4)
				    string_256_ = "1 Fix";
				if (((Globe) this).vwfix2[i_255_] == 5)
				    string_256_ = "No Fixing";
				((Globe) this).rd.drawString
				    (string_256_,
				     751 - ((Globe) this).ftm
					       .stringWidth(string_256_) / 2,
				     193 + i_255_ * 18);
				((Globe) this).rd
				    .drawRect(213, 180 + i_255_ * 18, 565, 18);
			    }
			    ((Globe) this).rd.drawLine(213, 162, 213,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    ((Globe) this).rd.drawLine(279, 162, 279,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    ((Globe) this).rd.drawLine(546, 162, 546,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    ((Globe) this).rd.drawLine(583, 162, 583,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    ((Globe) this).rd.drawLine(723, 162, 723,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    ((Globe) this).rd.drawLine(778, 162, 778,
						       180 + (((Globe) this)
							      .nvgames2) * 18);
			    for (int i_257_ = 0;
				 i_257_ < ((Globe) this).nvgames2; i_257_++) {
				if (i > 213 && i < 778
				    && i_197_ > 180 + i_257_ * 18
				    && i_197_ < 198 + i_257_ * 18
				    && !((Globe) this).vwinner[i_257_]
					    .equals("")) {
				    ((Globe) this).rd
					.setColor(color2k(230, 230, 230));
				    ((Globe) this).rd.fillRect(213,
							       (180
								+ i_257_ * 18),
							       565, 18);
				    ((Globe) this).rd.setColor(new Color(0, 0,
									 0));
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 1, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd.drawString
					(new StringBuilder().append("").append
					     (((Globe) this).vwinner[i_257_])
					     .append
					     ("  Wins!").toString(),
					 495 - ((((Globe) this).ftm.stringWidth
						 (new StringBuilder().append
						      ("").append
						      (((Globe) this).vwinner
						       [i_257_])
						      .append
						      ("  Wins!").toString()))
						/ 2),
					 193 + i_257_ * 18);
				    ((Globe) this).rd.drawRect(213,
							       (180
								+ i_257_ * 18),
							       565, 18);
				}
			    }
			}
			if (((Globe) this).viewgame2 == 1)
			    ((Globe) this).rd.drawString
				("Loading...",
				 495 - ((Globe) this).ftm
					   .stringWidth("Loading...") / 2,
				 242);
			if (((Globe) this).viewgame2 == 3) {
			    if (((Globe) this).nvgames2 == 4
				|| ((Globe) this).nvgames2 == 9)
				((Globe) this).rd.drawString
				    ("This war has expired and no longer exists.",
				     (495
				      - ((((Globe) this).ftm.stringWidth
					  ("This war has expired and no longer exists."))
					 / 2)),
				     232);
			    if (((Globe) this).nvgames2 == 2
				|| ((Globe) this).nvgames2 == 5)
				((Globe) this).rd.drawString
				    ("This battle has expired and no longer exists.",
				     (495
				      - ((((Globe) this).ftm.stringWidth
					  ("This battle has expired and no longer exists."))
					 / 2)),
				     232);
			    if (((Globe) this).nvgames2 == 9
				|| ((Globe) this).nvgames2 == 5)
				((Globe) this).rd.drawString
				    ("(Started/finished wars and battles expire after 180 days.)",
				     (495
				      - ((((Globe) this).ftm.stringWidth
					  ("(Started/finished wars and battles expire after 180 days.)"))
					 / 2)),
				     252);
			    else
				((Globe) this).rd.drawString
				    ("(Suggestions expire after 90 days.)",
				     (495
				      - ((((Globe) this).ftm.stringWidth
					  ("(Suggestions expire after 90 days.)"))
					 / 2)),
				     252);
			}
			if (((Globe) this).viewgame2 == 4)
			    ((Globe) this).rd.drawString
				("Error loading games, please try again later...",
				 (495
				  - ((((Globe) this).ftm.stringWidth
				      ("Error loading games, please try again later..."))
				     / 2)),
				 242);
		    }
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    if (!drawl(((Globe) this).rd,
			       new StringBuilder().append("#").append
				   (((Globe) this).intclan).append
				   ("#").toString(),
			       207, 47, true)) {
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    (((Globe) this).intclan,
			     382 - (((Globe) this).ftm
					.stringWidth(((Globe) this).intclan)
				    / 2),
			     66);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawRect(207, 47, 349, 29);
		    }
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString("::  Versus your clan", 566,
						 72);
		    if (i > 207 && i < 557 && i_197_ > 47 && i_197_ < 77) {
			((Globe) this).cur = 12;
			if (bool) {
			    if (!((Globe) this).claname
				     .equals(((Globe) this).intclan)) {
				((Globe) this).claname
				    = ((Globe) this).intclan;
				((Globe) this).loadedc = false;
			    }
			    ((Globe) this).spos5 = 0;
			    ((Globe) this).lspos5 = 0;
			    ((Globe) this).cfase = 3;
			    ((Globe) this).ctab = 0;
			    ((Globe) this).tab = 3;
			}
		    }
		    if (stringbutton(((Globe) this).rd, "Close X", 752, 66, 0,
				     i, i_197_, bool, 0, 0)) {
			((Globe) this).openi = 0;
			((Globe) this).readint = 0;
			((Globe) this).viewgame2 = 0;
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			< 5) {
			if (!((GameSparker) ((Globe) this).gs).sendtyp
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).sendtyp.show();
			((GameSparker) ((Globe) this).gs).sendtyp.move(207,
								       365);
		    } else {
			((GameSparker) ((Globe) this).gs).sendtyp.hide();
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex()
			    == 5)
			    ((Globe) this).rd.drawString
				("::  Accept Stage Battle", 207, 382);
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex()
			    == 6)
			    ((Globe) this).rd
				.drawString("::  Accept Car Battle", 207, 382);
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex()
			    == 7)
			    ((Globe) this).rd.drawString("::  Accept War", 207,
							 382);
			if (stringbutton(((Globe) this).rd, "  Cancel  ", 742,
					 382, 3, i, i_197_, bool, 0, 0))
			    ((GameSparker) ((Globe) this).gs).sendtyp
				.select(0);
		    }
		    if (((Globe) this).sendint != 0)
			((GameSparker) ((Globe) this).gs).sendtyp.disable();
		    else
			((GameSparker) ((Globe) this).gs).sendtyp.enable();
		    if (((Globe) this).intsel
			!= ((GameSparker) ((Globe) this).gs).sendtyp
			       .getSelectedIndex()) {
			((GameSparker) ((Globe) this).gs).senditem.hide();
			((GameSparker) ((Globe) this).gs).datat.hide();
			((GameSparker) ((Globe) this).gs).ilaps.hide();
			((GameSparker) ((Globe) this).gs).icars.hide();
			((GameSparker) ((Globe) this).gs).sclass.hide();
			((GameSparker) ((Globe) this).gs).sfix.hide();
			((GameSparker) ((Globe) this).gs).senditem.enable();
			((GameSparker) ((Globe) this).gs).datat.enable();
			((GameSparker) ((Globe) this).gs).ilaps.enable();
			((GameSparker) ((Globe) this).gs).icars.enable();
			((GameSparker) ((Globe) this).gs).sclass.enable();
			((GameSparker) ((Globe) this).gs).sfix.enable();
			((Globe) this).intsel
			    = ((GameSparker) ((Globe) this).gs).sendtyp
				  .getSelectedIndex();
			((Globe) this).inishsel = true;
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 0) {
			((Globe) this).dommsg = true;
			if (((Globe) this).sendint == 0) {
			    if (stringbutton(((Globe) this).rd, "   Send  >  ",
					     723, 408, 0, i, i_197_, bool, 0,
					     0)
				&& !((GameSparker) ((Globe) this).gs).mmsg
					.getText
					().trim
					().equals("")
				&& (((GameSparker) ((Globe) this).gs).mmsg
					.getText
					().toLowerCase
					().indexOf
				    (((GameSparker) ((Globe) this).gs)
					 .tpass.getText
					 ().toLowerCase())) == -1
				&& (((xtGraphics) ((Globe) this).xt).acexp
				    != -3)) {
				if (!((Globe) this).xt.msgcheck
				     (((GameSparker) ((Globe) this).gs)
					  .mmsg.getText()))
				    ((Globe) this).sendint = 1;
				else {
				    ((GameSparker) ((Globe) this).gs)
					.sendtyp.hide();
				    ((xtGraphics) ((Globe) this).xt).warning++;
				}
			    }
			} else {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 723 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 408);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 1) {
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			((Globe) this).rd.drawString
			    ("A date that gets converted to the local time of any person previewing it.",
			     376, 382);
			if (!((GameSparker) ((Globe) this).gs).senditem
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).senditem
				.removeAll();
			    Calendar calendar = Calendar.getInstance();
			    boolean bool_258_ = false;
			    for (int i_259_ = 0; i_259_ < 20; i_259_++) {
				String[] strings = ((Globe) this).wday;
				Calendar calendar_260_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				String string
				    = strings[calendar_260_.get(7) - 1];
				if (!bool_258_) {
				    string = "Today";
				    bool_258_ = true;
				}
				Smenu smenu
				    = (((GameSparker) ((Globe) this).gs)
				       .senditem);
				Graphics2D graphics2d = ((Globe) this).rd;
				StringBuilder stringbuilder
				    = new StringBuilder().append("").append
					  (string).append("  -  ");
				String[] strings_261_ = ((Globe) this).month;
				Calendar calendar_262_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				StringBuilder stringbuilder_263_
				    = stringbuilder.append
					  (strings_261_[calendar_262_.get(2)])
					  .append(" ");
				Calendar calendar_264_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				smenu.add(graphics2d,
					  stringbuilder_263_.append
					      (calendar_264_.get(5)).append
					      ("").toString());
				Calendar calendar_265_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				calendar_265_.roll(5, true);
			    }
			    ((GameSparker) ((Globe) this).gs).senditem
				.select(0);
			    ((GameSparker) ((Globe) this).gs).senditem.show();
			}
			if (!((GameSparker) ((Globe) this).gs).datat
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    int i_266_ = 12;
			    String string = "PM";
			    for (int i_267_ = 0; i_267_ < 24; i_267_++) {
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append("").append
					 (i_266_).append
					 (" ").append
					 (string).append
					 ("").toString());
				if (++i_266_ == 12)
				    string = "AM";
				if (i_266_ == 13)
				    i_266_ = 1;
			    }
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((GameSparker) ((Globe) this).gs).datat.show();
			}
			((GameSparker) ((Globe) this).gs).senditem.move(300,
									395);
			((GameSparker) ((Globe) this).gs).datat.move(491, 395);
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("Date is displayed based on your computer calendar's date/time, please make sure it is correct.",
			     207, 435);
			if (((Globe) this).sendint == 0) {
			    if (stringbutton(((Globe) this).rd, "   Send  >  ",
					     723, 408, 0, i, i_197_, bool, 0,
					     0))
				((Globe) this).sendint = 1;
			} else {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.drawString
				("Sending...",
				 723 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 408);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 2) {
			if (((Globe) this).inishsel) {
			    if (((Globe) this).redif) {
				((Globe) this).ifas = 1;
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				for (int i_268_ = 0;
				     i_268_ < ((GameSparker) ((Globe) this).gs)
						  .clcars.getItemCount();
				     i_268_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 ((GameSparker) ((Globe) this).gs)
					     .clcars.getItem(i_268_));
				((GameSparker) ((Globe) this).gs).datat.select
				    (((GameSparker) ((Globe) this).gs)
					 .clcars.getSelectedIndex());
				((Globe) this).redif = false;
			    } else {
				((Globe) this).ifas = 0;
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append("Loading ")
					 .append
					 (((Globe) this).intclan).append
					 ("'s stages, please wait...")
					 .toString());
			    }
			    ((Globe) this).imsg
				= new StringBuilder().append
				      ("Battle over a stage that belongs to ")
				      .append
				      (((Globe) this).intclan).append
				      (" to take it.").toString();
			    ((Globe) this).iflk = 0;
			    if (((Globe) this).sendwarnum) {
				((Globe) this).ifas = 4;
				((Globe) this).sendint = 1;
				((GameSparker) ((Globe) this).gs).senditem
				    .disable();
				((GameSparker) ((Globe) this).gs).datat
				    .disable();
				((GameSparker) ((Globe) this).gs).ilaps
				    .disable();
				((GameSparker) ((Globe) this).gs).icars
				    .disable();
				((GameSparker) ((Globe) this).gs).sclass
				    .disable();
				((GameSparker) ((Globe) this).gs).sfix
				    .disable();
			    }
			}
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			if (((Globe) this).iflk % 3 != 0
			    || ((Globe) this).iflk == 0)
			    ((Globe) this).rd.drawString(((Globe) this).imsg,
							 376, 382);
			if (((Globe) this).iflk != 0)
			    ((Globe) this).iflk--;
			if (((Globe) this).ifas == 0
			    || ((Globe) this).ifas == 1) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Choose the stage of ").append
				     (((Globe) this).intclan).append
				     (" you want to take to your clan, if you win!")
				     .toString(),
				 207, 402);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(495 - ((GameSparker) ((Globe) this).gs)
					   .datat.getWidth() / 2,
				 410);
			}
			if (((Globe) this).ifas == 2
			    || ((Globe) this).ifas == 3) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Choose a stage of your clan that you would give to ")
				     .append
				     (((Globe) this).intclan).append
				     (", if you lose!").toString(),
				 207, 402);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(495 - ((GameSparker) ((Globe) this).gs)
					   .datat.getWidth() / 2,
				 410);
			}
			if (((Globe) this).ifas == 4
			    || ((Globe) this).ifas == 5) {
			    if (((Globe) this).ifas == 4) {
				((Globe) this).isel = 0;
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd, " NFM Multiplayer ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " NFM 2     ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " NFM 1     ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " Clan Stages ");
				((GameSparker) ((Globe) this).gs).senditem
				    .select(0);
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_269_ = 0; i_269_ < 5; i_269_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_269_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((GameSparker) ((Globe) this).gs).ilaps.hide();
				((GameSparker) ((Globe) this).gs).icars.hide();
				((GameSparker) ((Globe) this).gs).sclass
				    .hide();
				((GameSparker) ((Globe) this).gs).sfix.hide();
				((Globe) this).ifas = 5;
			    }
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       12));
			    if (((Globe) this).iflk % 3 != 0
				|| ((Globe) this).iflk == 0)
				((Globe) this).rd
				    .drawString(((Globe) this).imsg, 376, 382);
			    if (((Globe) this).iflk != 0)
				((Globe) this).iflk--;
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append("Game #").append
				     (((Globe) this).wag * 2 + 2).append
				     (" :").toString(),
				 207, 407);
			    if (!((GameSparker) ((Globe) this).gs).senditem
				     .isShowing())
				((GameSparker) ((Globe) this).gs).senditem
				    .show();
			    ((GameSparker) ((Globe) this).gs).senditem
				.move(280, 390);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(286 + ((GameSparker) ((Globe) this).gs)
					   .senditem.getWidth(),
				 390);
			    int i_270_ = 207;
			    if (!((GameSparker) ((Globe) this).gs).ilaps
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).ilaps.show();
				((GameSparker) ((Globe) this).gs).ilaps
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).ilaps
				.move(i_270_, 415);
			    i_270_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .ilaps.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).icars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).icars.show();
				((GameSparker) ((Globe) this).gs).icars
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).icars
				.move(i_270_, 415);
			    i_270_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .icars.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).sclass
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).sclass
				    .show();
				((GameSparker) ((Globe) this).gs).sclass
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).sclass
				.move(i_270_, 415);
			    ((Smenu) ((GameSparker) ((Globe) this).gs).sclass)
				.revup
				= true;
			    i_270_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .sclass.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).sfix
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).sfix.show();
				((GameSparker) ((Globe) this).gs).sfix
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).sfix.move(i_270_,
									415);
			    ((Smenu) ((GameSparker) ((Globe) this).gs).sfix)
				.revup
				= true;
			    ((GameSparker) ((Globe) this).gs).datat.setSize
				((i_270_
				  + ((GameSparker) ((Globe) this).gs).sfix
					.getWidth()
				  - 286
				  - ((GameSparker) ((Globe) this).gs)
					.senditem.getWidth()),
				 22);
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 0
				&& ((Globe) this).isel != 0) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_271_ = 0; i_271_ < 5; i_271_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_271_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 0;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 1
				&& ((Globe) this).isel != 1) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_272_ = 0; i_272_ < 17; i_272_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_272_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 1;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 2
				&& ((Globe) this).isel != 2) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_273_ = 0; i_273_ < 10; i_273_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_273_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 2;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 3
				&& ((Globe) this).isel < 3) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     "Loading stages, please wait...");
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 3;
			    }
			}
			if (((Globe) this).sendint == 0) {
			    String string = "  Next >  ";
			    if (((Globe) this).ifas == 5
				&& ((Globe) this).wag == 1)
				string = "   Done   ";
			    if (stringbutton(((Globe) this).rd, string, 742,
					     417, 0, i, i_197_, bool, 0, 0)) {
				if (((Globe) this).ifas == 4
				    || ((Globe) this).ifas == 5) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					!= 0) {
					if (((GameSparker) ((Globe) this).gs)
						.ilaps.getSelectedIndex()
					    != 0) {
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .icars.getSelectedIndex()
						!= 0) {
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 0)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      ((((GameSparker)
								 ((Globe)
								  this).gs)
								    .datat
								    .getSelectedIndex
								()) + 27)
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 1)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      ((((GameSparker)
								 ((Globe)
								  this).gs)
								    .datat
								    .getSelectedIndex
								()) + 10)
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 2)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      (((GameSparker)
								(((Globe) this)
								 .gs))
								   .datat
								   .getSelectedIndex
							       ())
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 3)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("").append
							      (((GameSparker)
								(((Globe) this)
								 .gs))
								   .datat
								   .getSelectedItem
							       ())
							      .append
							      ("").toString();
						((Globe) this).wlaps
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .ilaps
							  .getSelectedIndex();
						((Globe) this).wcars
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .icars
							  .getSelectedIndex();
						((Globe) this).wclass
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .sclass
							  .getSelectedIndex();
						((Globe) this).wfix
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .sfix
							  .getSelectedIndex();
						((Globe) this).wag++;
						if (((Globe) this).wag < 2) {
						    ((Globe) this).ifas = 4;
						    ((Globe) this).imsg
							= "Create second game.";
						} else {
						    ((Globe) this).wag--;
						    ((Globe) this).sendint = 1;
						    ((GameSparker)
						     ((Globe) this).gs)
							.senditem.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.datat.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.ilaps.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.icars.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.sclass.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.sfix.disable();
						}
					    } else {
						((Globe) this).imsg
						    = "Please choose a type of cars for this game!";
						((Globe) this).iflk = 40;
					    }
					} else {
					    ((Globe) this).imsg
						= "Please select a number of laps!";
					    ((Globe) this).iflk = 40;
					}
				    } else {
					((Globe) this).imsg
					    = "Please select a stage!";
					((Globe) this).iflk = 40;
				    }
				}
				if (((Globe) this).ifas == 2
				    || ((Globe) this).ifas == 3) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					== 0) {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Please choose a stage to give to ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" if you lose!").toString();
					((Globe) this).iflk = 40;
				    } else {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Create 2 games and ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" will create another 3.")
						  .toString();
					((Globe) this).iflk = 0;
					((Globe) this).igive
					    = ((GameSparker) ((Globe) this).gs)
						  .datat.getSelectedItem();
					((Globe) this).ifas = 4;
					((Globe) this).wag = 0;
				    }
				}
				if (((Globe) this).ifas == 0
				    || ((Globe) this).ifas == 1) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					== 0) {
					((Globe) this).imsg
					    = "Please choose a stage to battle over!";
					((Globe) this).iflk = 40;
				    } else {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Battle over a stage that belongs to ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" to take it.").toString();
					((Globe) this).iflk = 0;
					((Globe) this).itake
					    = ((GameSparker) ((Globe) this).gs)
						  .datat.getSelectedItem();
					((GameSparker) ((Globe) this).gs)
					    .datat.removeAll();
					((GameSparker) ((Globe) this).gs)
					    .datat.add
					    (((Globe) this).rd,
					     "Loading your clan's stages, please wait...");
					((Globe) this).ifas = 2;
				    }
				}
			    }
			} else {
			    ((Globe) this).imsg
				= "Sending stage battle, pleas wait...";
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 742 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 417);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 3) {
			if (((Globe) this).inishsel) {
			    if (((Globe) this).redif) {
				((Globe) this).ifas = 1;
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				for (int i_274_ = 0;
				     i_274_ < ((GameSparker) ((Globe) this).gs)
						  .clcars.getItemCount();
				     i_274_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 ((GameSparker) ((Globe) this).gs)
					     .clcars.getItem(i_274_));
				((GameSparker) ((Globe) this).gs).datat.select
				    (((GameSparker) ((Globe) this).gs)
					 .clcars.getSelectedIndex());
				((Globe) this).redif = false;
			    } else {
				((Globe) this).ifas = 0;
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append("Loading ")
					 .append
					 (((Globe) this).intclan).append
					 ("'s cars, please wait...")
					 .toString());
			    }
			    ((Globe) this).imsg
				= new StringBuilder().append
				      ("Battle over a car that belongs to ")
				      .append
				      (((Globe) this).intclan).append
				      (" to take it.").toString();
			    ((Globe) this).iflk = 0;
			    if (((Globe) this).sendwarnum) {
				((Globe) this).ifas = 4;
				((Globe) this).sendint = 1;
				((GameSparker) ((Globe) this).gs).senditem
				    .disable();
				((GameSparker) ((Globe) this).gs).datat
				    .disable();
				((GameSparker) ((Globe) this).gs).ilaps
				    .disable();
				((GameSparker) ((Globe) this).gs).icars
				    .disable();
				((GameSparker) ((Globe) this).gs).sclass
				    .disable();
				((GameSparker) ((Globe) this).gs).sfix
				    .disable();
			    }
			}
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			if (((Globe) this).iflk % 3 != 0
			    || ((Globe) this).iflk == 0)
			    ((Globe) this).rd.drawString(((Globe) this).imsg,
							 376, 382);
			if (((Globe) this).iflk != 0)
			    ((Globe) this).iflk--;
			if (((Globe) this).ifas == 0
			    || ((Globe) this).ifas == 1) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Choose the car of ").append
				     (((Globe) this).intclan).append
				     (" you want to take to your clan, if you win!")
				     .toString(),
				 207, 402);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(495 - ((GameSparker) ((Globe) this).gs)
					   .datat.getWidth() / 2,
				 410);
			}
			if (((Globe) this).ifas == 2
			    || ((Globe) this).ifas == 3) {
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append
				     ("Choose a car of your clan that you would give to ")
				     .append
				     (((Globe) this).intclan).append
				     (", if you lose!").toString(),
				 207, 402);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(495 - ((GameSparker) ((Globe) this).gs)
					   .datat.getWidth() / 2,
				 410);
			}
			if (((Globe) this).ifas == 4
			    || ((Globe) this).ifas == 5) {
			    if (((Globe) this).ifas == 4) {
				((Globe) this).isel = 0;
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd, " NFM Multiplayer ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " NFM 2     ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " NFM 1     ");
				((GameSparker) ((Globe) this).gs).senditem
				    .add(((Globe) this).rd, " Clan Stages ");
				((GameSparker) ((Globe) this).gs).senditem
				    .select(0);
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_275_ = 0; i_275_ < 5; i_275_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_275_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((GameSparker) ((Globe) this).gs).ilaps.hide();
				((GameSparker) ((Globe) this).gs).icars.hide();
				((GameSparker) ((Globe) this).gs).sclass
				    .hide();
				((GameSparker) ((Globe) this).gs).sfix.hide();
				((Globe) this).ifas = 5;
			    }
			    ((Globe) this).rd.setFont(new Font("Arial", 0,
							       12));
			    if (((Globe) this).iflk % 3 != 0
				|| ((Globe) this).iflk == 0)
				((Globe) this).rd
				    .drawString(((Globe) this).imsg, 376, 382);
			    if (((Globe) this).iflk != 0)
				((Globe) this).iflk--;
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).rd.drawString
				(new StringBuilder().append("Game #").append
				     (((Globe) this).wag * 2 + 2).append
				     (" :").toString(),
				 207, 407);
			    if (!((GameSparker) ((Globe) this).gs).senditem
				     .isShowing())
				((GameSparker) ((Globe) this).gs).senditem
				    .show();
			    ((GameSparker) ((Globe) this).gs).senditem
				.move(280, 390);
			    if (!((GameSparker) ((Globe) this).gs).datat
				     .isShowing())
				((GameSparker) ((Globe) this).gs).datat.show();
			    ((GameSparker) ((Globe) this).gs).datat.move
				(286 + ((GameSparker) ((Globe) this).gs)
					   .senditem.getWidth(),
				 390);
			    int i_276_ = 207;
			    if (!((GameSparker) ((Globe) this).gs).ilaps
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).ilaps.show();
				((GameSparker) ((Globe) this).gs).ilaps
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).ilaps
				.move(i_276_, 415);
			    i_276_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .ilaps.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).icars
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).icars.show();
				((GameSparker) ((Globe) this).gs).icars
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).icars
				.move(i_276_, 415);
			    i_276_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .icars.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).sclass
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).sclass
				    .show();
				((GameSparker) ((Globe) this).gs).sclass
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).sclass
				.move(i_276_, 415);
			    ((Smenu) ((GameSparker) ((Globe) this).gs).sclass)
				.revup
				= true;
			    i_276_ += 6 + ((GameSparker) ((Globe) this).gs)
					      .sclass.getWidth();
			    if (!((GameSparker) ((Globe) this).gs).sfix
				     .isShowing()) {
				((GameSparker) ((Globe) this).gs).sfix.show();
				((GameSparker) ((Globe) this).gs).sfix
				    .select(0);
			    }
			    ((GameSparker) ((Globe) this).gs).sfix.move(i_276_,
									415);
			    ((Smenu) ((GameSparker) ((Globe) this).gs).sfix)
				.revup
				= true;
			    ((GameSparker) ((Globe) this).gs).datat.setSize
				((i_276_
				  + ((GameSparker) ((Globe) this).gs).sfix
					.getWidth()
				  - 286
				  - ((GameSparker) ((Globe) this).gs)
					.senditem.getWidth()),
				 22);
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 0
				&& ((Globe) this).isel != 0) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_277_ = 0; i_277_ < 5; i_277_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_277_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 0;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 1
				&& ((Globe) this).isel != 1) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_278_ = 0; i_278_ < 17; i_278_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_278_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 1;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 2
				&& ((Globe) this).isel != 2) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat
				    .add(((Globe) this).rd, "Select Stage");
				for (int i_279_ = 0; i_279_ < 10; i_279_++)
				    ((GameSparker) ((Globe) this).gs).datat.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     (" Stage ").append
					     (i_279_ + 1).append
					     ("").toString());
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 2;
			    }
			    if (((GameSparker) ((Globe) this).gs).senditem
				    .getSelectedIndex() == 3
				&& ((Globe) this).isel < 3) {
				((GameSparker) ((Globe) this).gs).datat
				    .removeAll();
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     "Loading stages, please wait...");
				((GameSparker) ((Globe) this).gs).datat
				    .select(0);
				((Globe) this).isel = 3;
			    }
			}
			if (((Globe) this).sendint == 0) {
			    String string = "  Next >  ";
			    if (((Globe) this).ifas == 5
				&& ((Globe) this).wag == 1)
				string = "   Done   ";
			    if (stringbutton(((Globe) this).rd, string, 742,
					     417, 0, i, i_197_, bool, 0, 0)) {
				if (((Globe) this).ifas == 4
				    || ((Globe) this).ifas == 5) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					!= 0) {
					if (((GameSparker) ((Globe) this).gs)
						.ilaps.getSelectedIndex()
					    != 0) {
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .icars.getSelectedIndex()
						!= 0) {
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 0)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      ((((GameSparker)
								 ((Globe)
								  this).gs)
								    .datat
								    .getSelectedIndex
								()) + 27)
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 1)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      ((((GameSparker)
								 ((Globe)
								  this).gs)
								    .datat
								    .getSelectedIndex
								()) + 10)
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 2)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("#").append
							      (((GameSparker)
								(((Globe) this)
								 .gs))
								   .datat
								   .getSelectedIndex
							       ())
							      .append
							      ("").toString();
						if (((GameSparker)
						     ((Globe) this).gs)
							.senditem
							.getSelectedIndex()
						    == 3)
						    ((Globe) this).wstages
							[((Globe) this).wag]
							= new StringBuilder
							      ().append
							      ("").append
							      (((GameSparker)
								(((Globe) this)
								 .gs))
								   .datat
								   .getSelectedItem
							       ())
							      .append
							      ("").toString();
						((Globe) this).wlaps
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .ilaps
							  .getSelectedIndex();
						((Globe) this).wcars
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .icars
							  .getSelectedIndex();
						((Globe) this).wclass
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .sclass
							  .getSelectedIndex();
						((Globe) this).wfix
						    [((Globe) this).wag]
						    = ((GameSparker)
						       ((Globe) this).gs)
							  .sfix
							  .getSelectedIndex();
						((Globe) this).wag++;
						if (((Globe) this).wag < 2) {
						    ((Globe) this).ifas = 4;
						    ((Globe) this).imsg
							= "Create second game.";
						} else {
						    ((Globe) this).wag--;
						    ((Globe) this).sendint = 1;
						    ((GameSparker)
						     ((Globe) this).gs)
							.senditem.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.datat.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.ilaps.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.icars.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.sclass.disable();
						    ((GameSparker)
						     ((Globe) this).gs)
							.sfix.disable();
						}
					    } else {
						((Globe) this).imsg
						    = "Please choose a type of cars for this game!";
						((Globe) this).iflk = 40;
					    }
					} else {
					    ((Globe) this).imsg
						= "Please select a number of laps!";
					    ((Globe) this).iflk = 40;
					}
				    } else {
					((Globe) this).imsg
					    = "Please select a stage!";
					((Globe) this).iflk = 40;
				    }
				}
				if (((Globe) this).ifas == 2
				    || ((Globe) this).ifas == 3) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					== 0) {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Please choose a car to give to ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" if you lose!").toString();
					((Globe) this).iflk = 40;
				    } else {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Create 2 games and ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" will create another 3.")
						  .toString();
					((Globe) this).iflk = 0;
					((Globe) this).igive
					    = ((GameSparker) ((Globe) this).gs)
						  .datat.getSelectedItem();
					((Globe) this).ifas = 4;
					((Globe) this).wag = 0;
				    }
				}
				if (((Globe) this).ifas == 0
				    || ((Globe) this).ifas == 1) {
				    if (((GameSparker) ((Globe) this).gs)
					    .datat.getSelectedIndex()
					== 0) {
					((Globe) this).imsg
					    = "Please choose a car to battle over!";
					((Globe) this).iflk = 40;
				    } else {
					((Globe) this).imsg
					    = new StringBuilder().append
						  ("Battle over a car that belongs to ")
						  .append
						  (((Globe) this).intclan)
						  .append
						  (" to take it.").toString();
					((Globe) this).iflk = 0;
					((Globe) this).itake
					    = ((GameSparker) ((Globe) this).gs)
						  .datat.getSelectedItem();
					((GameSparker) ((Globe) this).gs)
					    .datat.removeAll();
					((GameSparker) ((Globe) this).gs)
					    .datat.add
					    (((Globe) this).rd,
					     "Loading your clan's cars, please wait...");
					((Globe) this).ifas = 2;
				    }
				}
			    }
			} else {
			    ((Globe) this).imsg
				= "Sending car battle, pleas wait...";
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 742 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 417);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 4) {
			if (((Globe) this).inishsel || ((Globe) this).redif) {
			    ((Globe) this).isel = 0;
			    ((GameSparker) ((Globe) this).gs).senditem
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM Multiplayer ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 2     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 1     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " Clan Stages ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.select(0);
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_280_ = 0; i_280_ < 5; i_280_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_280_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    if (!((Globe) this).redif) {
				((Globe) this).wag = 0;
				((Globe) this).imsg
				    = new StringBuilder().append
					  ("Create 4 games and ").append
					  (((Globe) this).intclan).append
					  (" will create another 5.")
					  .toString();
				((Globe) this).iflk = 0;
			    } else {
				((Globe) this).imsg = "Create next game.";
				if (((Globe) this).wag == 3)
				    ((Globe) this).imsg = "Create last game.";
				((Globe) this).iflk = 0;
				((GameSparker) ((Globe) this).gs).ilaps.hide();
				((GameSparker) ((Globe) this).gs).icars.hide();
				((GameSparker) ((Globe) this).gs).sclass
				    .hide();
				((GameSparker) ((Globe) this).gs).sfix.hide();
			    }
			    if (((Globe) this).sendwarnum) {
				((Globe) this).sendint = 1;
				((GameSparker) ((Globe) this).gs).senditem
				    .disable();
				((GameSparker) ((Globe) this).gs).datat
				    .disable();
				((GameSparker) ((Globe) this).gs).ilaps
				    .disable();
				((GameSparker) ((Globe) this).gs).icars
				    .disable();
				((GameSparker) ((Globe) this).gs).sclass
				    .disable();
				((GameSparker) ((Globe) this).gs).sfix
				    .disable();
			    }
			    ((Globe) this).redif = false;
			}
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			if (((Globe) this).iflk % 3 != 0
			    || ((Globe) this).iflk == 0)
			    ((Globe) this).rd.drawString(((Globe) this).imsg,
							 376, 382);
			if (((Globe) this).iflk != 0)
			    ((Globe) this).iflk--;
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.drawString(new StringBuilder().append
							 ("Game #").append
							 ((((Globe) this).wag
							   * 2) + 2)
							 .append
							 (" :").toString(),
						     207, 407);
			if (!((GameSparker) ((Globe) this).gs).senditem
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).senditem.show();
			((GameSparker) ((Globe) this).gs).senditem.move(280,
									390);
			if (!((GameSparker) ((Globe) this).gs).datat
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).datat.show();
			((GameSparker) ((Globe) this).gs).datat.move
			    (286 + ((GameSparker) ((Globe) this).gs)
				       .senditem.getWidth(),
			     390);
			int i_281_ = 207;
			if (!((GameSparker) ((Globe) this).gs).ilaps
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).ilaps.show();
			    ((GameSparker) ((Globe) this).gs).ilaps.select(0);
			}
			((GameSparker) ((Globe) this).gs).ilaps.move(i_281_,
								     415);
			i_281_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .ilaps.getWidth();
			if (!((GameSparker) ((Globe) this).gs).icars
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).icars.show();
			    ((GameSparker) ((Globe) this).gs).icars.select(0);
			}
			((GameSparker) ((Globe) this).gs).icars.move(i_281_,
								     415);
			i_281_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .icars.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sclass
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sclass.show();
			    ((GameSparker) ((Globe) this).gs).sclass.select(0);
			}
			((GameSparker) ((Globe) this).gs).sclass.move(i_281_,
								      415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sclass)
			    .revup
			    = true;
			i_281_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .sclass.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sfix
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sfix.show();
			    ((GameSparker) ((Globe) this).gs).sfix.select(0);
			}
			((GameSparker) ((Globe) this).gs).sfix.move(i_281_,
								    415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sfix).revup
			    = true;
			((GameSparker) ((Globe) this).gs).datat.setSize
			    ((i_281_
			      + ((GameSparker) ((Globe) this).gs).sfix
				    .getWidth()
			      - 286
			      - ((GameSparker) ((Globe) this).gs).senditem
				    .getWidth()),
			     22);
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 0
			    && ((Globe) this).isel != 0) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_282_ = 0; i_282_ < 5; i_282_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_282_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 0;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 1
			    && ((Globe) this).isel != 1) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_283_ = 0; i_283_ < 17; i_283_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_283_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 1;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 2
			    && ((Globe) this).isel != 2) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_284_ = 0; i_284_ < 10; i_284_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_284_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 2;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 3
			    && ((Globe) this).isel < 3) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat.add
				(((Globe) this).rd,
				 "Loading stages, please wait...");
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 3;
			}
			if (((Globe) this).sendint == 0) {
			    String string = "  Next >  ";
			    if (((Globe) this).wag == 3)
				string = "   Done   ";
			    if (stringbutton(((Globe) this).rd, string, 742,
					     417, 0, i, i_197_, bool, 0, 0)) {
				if (((GameSparker) ((Globe) this).gs).datat
					.getSelectedIndex()
				    != 0) {
				    if (((GameSparker) ((Globe) this).gs)
					    .ilaps.getSelectedIndex()
					!= 0) {
					if (((GameSparker) ((Globe) this).gs)
						.icars.getSelectedIndex()
					    != 0) {
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 0)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 27)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 1)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 10)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 2)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedIndex
							   ())
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 3)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedItem
							   ())
							  .append
							  ("").toString();
					    ((Globe) this).wlaps
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .ilaps
						      .getSelectedIndex();
					    ((Globe) this).wcars
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .icars
						      .getSelectedIndex();
					    ((Globe) this).wclass
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sclass
						      .getSelectedIndex();
					    ((Globe) this).wfix[(((Globe) this)
								 .wag)]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sfix.getSelectedIndex();
					    ((Globe) this).wag++;
					    if (((Globe) this).wag < 4)
						((Globe) this).redif = true;
					    else {
						((Globe) this).wag--;
						((Globe) this).sendint = 1;
						((GameSparker)
						 ((Globe) this).gs)
						    .senditem.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .datat.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .ilaps.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .icars.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sclass.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sfix.disable();
					    }
					} else {
					    ((Globe) this).imsg
						= "Please choose a type of cars for this game!";
					    ((Globe) this).iflk = 40;
					}
				    } else {
					((Globe) this).imsg
					    = "Please select a number of laps!";
					((Globe) this).iflk = 40;
				    }
				} else {
				    ((Globe) this).imsg
					= "Please select a stage!";
				    ((Globe) this).iflk = 40;
				}
			    }
			} else {
			    ((Globe) this).imsg
				= "Sending war declaration, pleas wait...";
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 742 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 417);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex() == 5
			|| ((GameSparker) ((Globe) this).gs).sendtyp
			       .getSelectedIndex() == 6) {
			if (((Globe) this).inishsel || ((Globe) this).redif) {
			    ((Globe) this).isel = 0;
			    ((GameSparker) ((Globe) this).gs).senditem
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM Multiplayer ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 2     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 1     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " Clan Stages ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.select(0);
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_285_ = 0; i_285_ < 5; i_285_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_285_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    if (!((Globe) this).redif) {
				((Globe) this).wag = 0;
				((Globe) this).imsg
				    = "Create 3 games to be added to the battle.";
				((Globe) this).iflk = 0;
			    } else {
				((Globe) this).imsg = "Create next game.";
				if (((Globe) this).wag == 2)
				    ((Globe) this).imsg = "Create last game.";
				((Globe) this).iflk = 0;
				((GameSparker) ((Globe) this).gs).ilaps.hide();
				((GameSparker) ((Globe) this).gs).icars.hide();
				((GameSparker) ((Globe) this).gs).sclass
				    .hide();
				((GameSparker) ((Globe) this).gs).sfix.hide();
			    }
			    if (((Globe) this).sendwarnum) {
				((Globe) this).sendint = 1;
				((GameSparker) ((Globe) this).gs).senditem
				    .disable();
				((GameSparker) ((Globe) this).gs).datat
				    .disable();
				((GameSparker) ((Globe) this).gs).ilaps
				    .disable();
				((GameSparker) ((Globe) this).gs).icars
				    .disable();
				((GameSparker) ((Globe) this).gs).sclass
				    .disable();
				((GameSparker) ((Globe) this).gs).sfix
				    .disable();
			    }
			    ((Globe) this).redif = false;
			}
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			if (((Globe) this).iflk % 3 != 0
			    || ((Globe) this).iflk == 0)
			    ((Globe) this).rd.drawString(((Globe) this).imsg,
							 350, 382);
			if (((Globe) this).iflk != 0)
			    ((Globe) this).iflk--;
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.drawString(new StringBuilder().append
							 ("Game #").append
							 ((((Globe) this).wag
							   * 2) + 1)
							 .append
							 (" :").toString(),
						     207, 407);
			if (!((GameSparker) ((Globe) this).gs).senditem
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).senditem.show();
			((GameSparker) ((Globe) this).gs).senditem.move(280,
									390);
			if (!((GameSparker) ((Globe) this).gs).datat
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).datat.show();
			((GameSparker) ((Globe) this).gs).datat.move
			    (286 + ((GameSparker) ((Globe) this).gs)
				       .senditem.getWidth(),
			     390);
			int i_286_ = 207;
			if (!((GameSparker) ((Globe) this).gs).ilaps
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).ilaps.show();
			    ((GameSparker) ((Globe) this).gs).ilaps.select(0);
			}
			((GameSparker) ((Globe) this).gs).ilaps.move(i_286_,
								     415);
			i_286_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .ilaps.getWidth();
			if (!((GameSparker) ((Globe) this).gs).icars
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).icars.show();
			    ((GameSparker) ((Globe) this).gs).icars.select(0);
			}
			((GameSparker) ((Globe) this).gs).icars.move(i_286_,
								     415);
			i_286_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .icars.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sclass
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sclass.show();
			    ((GameSparker) ((Globe) this).gs).sclass.select(0);
			}
			((GameSparker) ((Globe) this).gs).sclass.move(i_286_,
								      415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sclass)
			    .revup
			    = true;
			i_286_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .sclass.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sfix
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sfix.show();
			    ((GameSparker) ((Globe) this).gs).sfix.select(0);
			}
			((GameSparker) ((Globe) this).gs).sfix.move(i_286_,
								    415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sfix).revup
			    = true;
			((GameSparker) ((Globe) this).gs).datat.setSize
			    ((i_286_
			      + ((GameSparker) ((Globe) this).gs).sfix
				    .getWidth()
			      - 286
			      - ((GameSparker) ((Globe) this).gs).senditem
				    .getWidth()),
			     22);
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 0
			    && ((Globe) this).isel != 0) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_287_ = 0; i_287_ < 5; i_287_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_287_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 0;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 1
			    && ((Globe) this).isel != 1) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_288_ = 0; i_288_ < 17; i_288_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_288_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 1;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 2
			    && ((Globe) this).isel != 2) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_289_ = 0; i_289_ < 10; i_289_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_289_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 2;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 3
			    && ((Globe) this).isel < 3) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat.add
				(((Globe) this).rd,
				 "Loading stages, please wait...");
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 3;
			}
			if (((Globe) this).sendint == 0) {
			    String string = "  Next >  ";
			    if (((Globe) this).wag == 2)
				string = "   Done   ";
			    if (stringbutton(((Globe) this).rd, string, 742,
					     417, 0, i, i_197_, bool, 0, 0)) {
				if (((GameSparker) ((Globe) this).gs).datat
					.getSelectedIndex()
				    != 0) {
				    if (((GameSparker) ((Globe) this).gs)
					    .ilaps.getSelectedIndex()
					!= 0) {
					if (((GameSparker) ((Globe) this).gs)
						.icars.getSelectedIndex()
					    != 0) {
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 0)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 27)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 1)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 10)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 2)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedIndex
							   ())
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 3)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedItem
							   ())
							  .append
							  ("").toString();
					    ((Globe) this).wlaps
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .ilaps
						      .getSelectedIndex();
					    ((Globe) this).wcars
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .icars
						      .getSelectedIndex();
					    ((Globe) this).wclass
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sclass
						      .getSelectedIndex();
					    ((Globe) this).wfix[(((Globe) this)
								 .wag)]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sfix.getSelectedIndex();
					    ((Globe) this).wag++;
					    if (((Globe) this).wag < 3)
						((Globe) this).redif = true;
					    else {
						((Globe) this).wag--;
						((Globe) this).sendint = 1;
						((GameSparker)
						 ((Globe) this).gs)
						    .senditem.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .datat.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .ilaps.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .icars.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sclass.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sfix.disable();
					    }
					} else {
					    ((Globe) this).imsg
						= "Please choose a type of cars for this game!";
					    ((Globe) this).iflk = 40;
					}
				    } else {
					((Globe) this).imsg
					    = "Please select a number of laps!";
					((Globe) this).iflk = 40;
				    }
				} else {
				    ((Globe) this).imsg
					= "Please select a stage!";
				    ((Globe) this).iflk = 40;
				}
			    }
			} else {
			    ((Globe) this).imsg
				= "Sending war declaration, pleas wait...";
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 742 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 417);
			}
		    }
		    if (((GameSparker) ((Globe) this).gs).sendtyp
			    .getSelectedIndex()
			== 7) {
			if (((Globe) this).inishsel || ((Globe) this).redif) {
			    ((Globe) this).isel = 0;
			    ((GameSparker) ((Globe) this).gs).senditem
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM Multiplayer ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 2     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " NFM 1     ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.add(((Globe) this).rd, " Clan Stages ");
			    ((GameSparker) ((Globe) this).gs).senditem
				.select(0);
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_290_ = 0; i_290_ < 5; i_290_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_290_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    if (!((Globe) this).redif) {
				((Globe) this).wag = 0;
				((Globe) this).imsg
				    = "Create 5 games to be added to the war.";
				((Globe) this).iflk = 0;
			    } else {
				((Globe) this).imsg = "Create next game.";
				if (((Globe) this).wag == 4)
				    ((Globe) this).imsg = "Create last game.";
				((Globe) this).iflk = 0;
				((GameSparker) ((Globe) this).gs).ilaps.hide();
				((GameSparker) ((Globe) this).gs).icars.hide();
				((GameSparker) ((Globe) this).gs).sclass
				    .hide();
				((GameSparker) ((Globe) this).gs).sfix.hide();
			    }
			    if (((Globe) this).sendwarnum) {
				((Globe) this).sendint = 1;
				((GameSparker) ((Globe) this).gs).senditem
				    .disable();
				((GameSparker) ((Globe) this).gs).datat
				    .disable();
				((GameSparker) ((Globe) this).gs).ilaps
				    .disable();
				((GameSparker) ((Globe) this).gs).icars
				    .disable();
				((GameSparker) ((Globe) this).gs).sclass
				    .disable();
				((GameSparker) ((Globe) this).gs).sfix
				    .disable();
			    }
			    ((Globe) this).redif = false;
			}
			((Globe) this).rd.setFont(new Font("Arial", 0, 12));
			if (((Globe) this).iflk % 3 != 0
			    || ((Globe) this).iflk == 0)
			    ((Globe) this).rd.drawString(((Globe) this).imsg,
							 350, 382);
			if (((Globe) this).iflk != 0)
			    ((Globe) this).iflk--;
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).rd.drawString(new StringBuilder().append
							 ("Game #").append
							 ((((Globe) this).wag
							   * 2) + 1)
							 .append
							 (" :").toString(),
						     207, 407);
			if (!((GameSparker) ((Globe) this).gs).senditem
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).senditem.show();
			((GameSparker) ((Globe) this).gs).senditem.move(280,
									390);
			if (!((GameSparker) ((Globe) this).gs).datat
				 .isShowing())
			    ((GameSparker) ((Globe) this).gs).datat.show();
			((GameSparker) ((Globe) this).gs).datat.move
			    (286 + ((GameSparker) ((Globe) this).gs)
				       .senditem.getWidth(),
			     390);
			int i_291_ = 207;
			if (!((GameSparker) ((Globe) this).gs).ilaps
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).ilaps.show();
			    ((GameSparker) ((Globe) this).gs).ilaps.select(0);
			}
			((GameSparker) ((Globe) this).gs).ilaps.move(i_291_,
								     415);
			i_291_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .ilaps.getWidth();
			if (!((GameSparker) ((Globe) this).gs).icars
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).icars.show();
			    ((GameSparker) ((Globe) this).gs).icars.select(0);
			}
			((GameSparker) ((Globe) this).gs).icars.move(i_291_,
								     415);
			i_291_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .icars.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sclass
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sclass.show();
			    ((GameSparker) ((Globe) this).gs).sclass.select(0);
			}
			((GameSparker) ((Globe) this).gs).sclass.move(i_291_,
								      415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sclass)
			    .revup
			    = true;
			i_291_ += 6 + ((GameSparker) ((Globe) this).gs)
					  .sclass.getWidth();
			if (!((GameSparker) ((Globe) this).gs).sfix
				 .isShowing()) {
			    ((GameSparker) ((Globe) this).gs).sfix.show();
			    ((GameSparker) ((Globe) this).gs).sfix.select(0);
			}
			((GameSparker) ((Globe) this).gs).sfix.move(i_291_,
								    415);
			((Smenu) ((GameSparker) ((Globe) this).gs).sfix).revup
			    = true;
			((GameSparker) ((Globe) this).gs).datat.setSize
			    ((i_291_
			      + ((GameSparker) ((Globe) this).gs).sfix
				    .getWidth()
			      - 286
			      - ((GameSparker) ((Globe) this).gs).senditem
				    .getWidth()),
			     22);
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 0
			    && ((Globe) this).isel != 0) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_292_ = 0; i_292_ < 5; i_292_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_292_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 0;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 1
			    && ((Globe) this).isel != 1) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_293_ = 0; i_293_ < 17; i_293_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_293_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 1;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 2
			    && ((Globe) this).isel != 2) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat
				.add(((Globe) this).rd, "Select Stage");
			    for (int i_294_ = 0; i_294_ < 10; i_294_++)
				((GameSparker) ((Globe) this).gs).datat.add
				    (((Globe) this).rd,
				     new StringBuilder().append(" Stage ")
					 .append
					 (i_294_ + 1).append
					 ("").toString());
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 2;
			}
			if (((GameSparker) ((Globe) this).gs).senditem
				.getSelectedIndex() == 3
			    && ((Globe) this).isel < 3) {
			    ((GameSparker) ((Globe) this).gs).datat
				.removeAll();
			    ((GameSparker) ((Globe) this).gs).datat.add
				(((Globe) this).rd,
				 "Loading stages, please wait...");
			    ((GameSparker) ((Globe) this).gs).datat.select(0);
			    ((Globe) this).isel = 3;
			}
			if (((Globe) this).sendint == 0) {
			    String string = "  Next >  ";
			    if (((Globe) this).wag == 4)
				string = "   Done   ";
			    if (stringbutton(((Globe) this).rd, string, 742,
					     417, 0, i, i_197_, bool, 0, 0)) {
				if (((GameSparker) ((Globe) this).gs).datat
					.getSelectedIndex()
				    != 0) {
				    if (((GameSparker) ((Globe) this).gs)
					    .ilaps.getSelectedIndex()
					!= 0) {
					if (((GameSparker) ((Globe) this).gs)
						.icars.getSelectedIndex()
					    != 0) {
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 0)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 27)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 1)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  ((((GameSparker)
							     ((Globe) this).gs)
								.datat
								.getSelectedIndex
							    ()) + 10)
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 2)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("#").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedIndex
							   ())
							  .append
							  ("").toString();
					    if (((GameSparker)
						 ((Globe) this).gs)
						    .senditem
						    .getSelectedIndex()
						== 3)
						((Globe) this).wstages
						    [((Globe) this).wag]
						    = new StringBuilder()
							  .append
							  ("").append
							  (((GameSparker)
							    ((Globe) this).gs)
							       .datat
							       .getSelectedItem
							   ())
							  .append
							  ("").toString();
					    ((Globe) this).wlaps
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .ilaps
						      .getSelectedIndex();
					    ((Globe) this).wcars
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .icars
						      .getSelectedIndex();
					    ((Globe) this).wclass
						[((Globe) this).wag]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sclass
						      .getSelectedIndex();
					    ((Globe) this).wfix[(((Globe) this)
								 .wag)]
						= ((GameSparker)
						   ((Globe) this).gs)
						      .sfix.getSelectedIndex();
					    ((Globe) this).wag++;
					    if (((Globe) this).wag < 5)
						((Globe) this).redif = true;
					    else {
						((Globe) this).wag--;
						((Globe) this).sendint = 1;
						((GameSparker)
						 ((Globe) this).gs)
						    .senditem.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .datat.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .ilaps.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .icars.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sclass.disable();
						((GameSparker)
						 ((Globe) this).gs)
						    .sfix.disable();
					    }
					} else {
					    ((Globe) this).imsg
						= "Please choose a type of cars for this game!";
					    ((Globe) this).iflk = 40;
					}
				    } else {
					((Globe) this).imsg
					    = "Please select a number of laps!";
					((Globe) this).iflk = 40;
				    }
				} else {
				    ((Globe) this).imsg
					= "Please select a stage!";
				    ((Globe) this).iflk = 40;
				}
			    }
			} else {
			    ((Globe) this).imsg
				= "Sending war declaration, pleas wait...";
			    ((Globe) this).rd.setFont(new Font("Arial", 1,
							       12));
			    ((Globe) this).ftm
				= ((Globe) this).rd.getFontMetrics();
			    ((Globe) this).rd.setColor(new Color(0, 0, 0));
			    ((Globe) this).rd.drawString
				("Sending...",
				 742 - ((Globe) this).ftm
					   .stringWidth("Sending...") / 2,
				 417);
			}
		    }
		    if (((Globe) this).inishsel)
			((Globe) this).inishsel = false;
		}
		if (((Globe) this).openi >= 1 && ((Globe) this).openi < 10) {
		    ((Globe) this).rd.setColor(color2k(240, 240, 230));
		    ((Globe) this).rd.fillRoundRect(197, ((Globe) this).opy,
						    597, ((Globe) this).oph,
						    20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(197, ((Globe) this).opy,
						    597, ((Globe) this).oph,
						    20, 20);
		    if (!drawl(((Globe) this).rd,
			       new StringBuilder().append("#").append
				   (((Globe) this).intclan).append
				   ("#").toString(),
			       207, ((Globe) this).opy + 7, true)) {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    (((Globe) this).intclan,
			     382 - (((Globe) this).ftm
					.stringWidth(((Globe) this).intclan)
				    / 2),
			     ((Globe) this).opy + 26);
			((Globe) this).rd.setColor(color2k(150, 150, 150));
			((Globe) this).rd.drawRect(207, ((Globe) this).opy + 7,
						   349, 29);
		    }
		    ((Globe) this).opy += ((Globe) this).addopy;
		    ((Globe) this).oph += 36;
		    ((Globe) this).openi++;
		}
	    } else {
		((Globe) this).rd.setColor(color2k(230, 230, 230));
		((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
		if (((xtGraphics) ((Globe) this).xt).logged) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("You are not a member of any clan.  You need to join a clan first to have access to this.",
			 (487
			  - ((((Globe) this).ftm.stringWidth
			      ("You are not a member of any clan.  You need to join a clan first to have access to this."))
			     / 2)),
			 200);
		    if (stringbutton(((Globe) this).rd,
				     "   Find a clan to join   ", 487, 230, 1,
				     i, i_197_, bool, 0, 0)) {
			((Globe) this).tab = 3;
			((Globe) this).cfase = 2;
			((Globe) this).em = 1;
			((Globe) this).msg = "Clan Search";
			((Globe) this).smsg
			    = "Listing clans with recent activity...";
			((Globe) this).nclns = 0;
			((Globe) this).spos5 = 0;
			((Globe) this).lspos5 = 0;
			((Globe) this).flko = 0;
		    }
		} else {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("You are currently using a trial account.",
			 495 - ((((Globe) this).ftm.stringWidth
				 ("You are currently using a trial account."))
				/ 2),
			 180);
		    ((Globe) this).rd.drawString
			("You need to upgrade to be able participate in NFM clan's activities.",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("You need to upgrade to be able participate in NFM clan's activities."))
			     / 2)),
			 200);
		    ((Globe) this).rd.setColor(new Color(206, 171, 98));
		    ((Globe) this).rd.fillRoundRect(405, 223, 180, 50, 20, 20);
		    if (drawbutton(((xtGraphics) ((Globe) this).xt).upgrade,
				   495, 248, i, i_197_, bool))
			((Globe) this).gs.editlink((((xtGraphics)
						     ((Globe) this).xt)
						    .nickname),
						   true);
		}
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.fillRect(207, 46, 582, 30);
		((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		String[] strings = { "Player Interaction", "Clan Interaction",
				     "Your Clan's Discussion" };
		int[] is = { 207, 390, 368, 207 };
		int[] is_295_ = { 73, 73, 51, 51 };
		for (int i_296_ = 0; i_296_ < 3; i_296_++) {
		    if (((Globe) this).itab == i_296_) {
			((Globe) this).rd.setColor(color2k(230, 230, 230));
			((Globe) this).rd.fillPolygon(is, is_295_, 4);
		    } else if (i > is[0] && i < is[2] && i_197_ > 51
			       && i_197_ < 73) {
			((Globe) this).rd.setColor(color2k(217, 217, 217));
			((Globe) this).rd.fillPolygon(is, is_295_, 4);
			if (bool)
			    ((Globe) this).itab = i_296_;
		    }
		    ((Globe) this).rd.setColor(color2k(150, 150, 150));
		    ((Globe) this).rd.drawPolygon(is, is_295_, 4);
		    ((Globe) this).rd.setColor(color2k(40, 40, 40));
		    ((Globe) this).rd.drawString
			(strings[i_296_],
			 is[0] + 80 - ((Globe) this).ftm
					  .stringWidth(strings[i_296_]) / 2,
			 67);
		    for (int i_297_ = 0; i_297_ < 4; i_297_++)
			is[i_297_] += 183;
		}
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawLine(207, 73, 770, 73);
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.fillRect(207, 409, 582, 30);
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawLine(207, 411, 770, 411);
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.fillRect(772, 76, 17, 333);
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.fillRect(203, 46, 4, 393);
	    }
	}
	if (((Globe) this).itab == 2) {
	    if (((Globe) this).litab != ((Globe) this).itab) {
		if (((Globe) this).readclan > 0)
		    ((Globe) this).spos3 = 219;
		((GameSparker) ((Globe) this).gs).senditem.hide();
		((GameSparker) ((Globe) this).gs).datat.hide();
		((GameSparker) ((Globe) this).gs).ilaps.hide();
		((GameSparker) ((Globe) this).gs).icars.hide();
		((GameSparker) ((Globe) this).gs).sclass.hide();
		((GameSparker) ((Globe) this).gs).sfix.hide();
		((GameSparker) ((Globe) this).gs).senditem.enable();
		((GameSparker) ((Globe) this).gs).datat.enable();
		((GameSparker) ((Globe) this).gs).ilaps.enable();
		((GameSparker) ((Globe) this).gs).icars.enable();
		((GameSparker) ((Globe) this).gs).sclass.enable();
		((GameSparker) ((Globe) this).gs).sfix.enable();
		((GameSparker) ((Globe) this).gs).sendtyp.removeAll();
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Write a Message");
		((GameSparker) ((Globe) this).gs).sendtyp
		    .add(((Globe) this).rd, "Share a Relative Date");
		((GameSparker) ((Globe) this).gs).sendtyp.select(0);
		((Globe) this).litab = ((Globe) this).itab;
	    }
	    ((Globe) this).rd.setColor(color2k(230, 230, 230));
	    ((Globe) this).rd.fillRoundRect(197, 40, 597, 404, 20, 20);
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).rd.drawRoundRect(197, 40, 597, 404, 20, 20);
	    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		((Globe) this).rd.setColor(color2k(250, 250, 250));
		((Globe) this).rd.fillRect(207, 76, 565, 300);
	    }
	    if (((Globe) this).loadedmyclanbg == 1) {
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 0.1F));
		((Globe) this).rd.drawImage(((Globe) this).myclanbg, 207, 76,
					    565, 300, null);
		((Globe) this).rd
		    .setComposite(AlphaComposite.getInstance(3, 1.0F));
	    }
	    ((Globe) this).rd.setColor(new Color(0, 0, 0));
	    ((Globe) this).sdist = 0;
	    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		if (((GameSparker) ((Globe) this).gs).openm)
		    ((Globe) this).blockb = 10;
		else if (((Globe) this).blockb != 0)
		    ((Globe) this).blockb--;
		if ((((Globe) this).readclan > 0
		     || ((Globe) this).readclan == -3)
		    && ((Globe) this).viewgame1 == 0) {
		    ((Globe) this).sdist
			= (int) (((float) ((Globe) this).cnml - 14.75F)
				 * 17.0F);
		    if (((Globe) this).sdist < 0)
			((Globe) this).sdist = 0;
		    ((Globe) this).scro
			= (int) ((float) ((Globe) this).spos3 / 219.0F
				 * (float) ((Globe) this).sdist);
		    for (int i_298_ = 0; i_298_ < ((Globe) this).cnml;
			 i_298_++) {
			if (86 + 17 * i_298_ - ((Globe) this).scro < 360
			    && 125 + 17 * i_298_ - ((Globe) this).scro > 76
			    && ((Globe) this).cmlinetyp[i_298_] != 167) {
			    if (((Globe) this).cmlinetyp[i_298_] != 20
				&& ((Globe) this).cmlinetyp[i_298_] != 30
				&& ((Globe) this).cmlinetyp[i_298_] != 40
				&& ((Globe) this).cmlinetyp[i_298_] != 50
				&& ((Globe) this).cmlinetyp[i_298_] != 60
				&& ((Globe) this).cmlinetyp[i_298_] != 70
				&& ((Globe) this).cmlinetyp[i_298_] != 80) {
				((Globe) this).rd.setColor(new Color(0, 0, 0));
				if (((Globe) this).cmlinetyp[i_298_] >= 0)
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 1, 11));
				else
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				((Globe) this).rd.drawString
				    (((Globe) this).cmline[i_298_], 217,
				     103 + 17 * i_298_ - ((Globe) this).scro);
				if (((Globe) this).cmlinetyp[i_298_] >= 0) {
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    ((Globe) this).rd
					.setColor(color2k(125, 125, 125));
				    ((Globe) this).rd.drawString
					(((Globe) this).cmtimes[i_298_],
					 757 - (((Globe) this).ftm.stringWidth
						(((Globe) this).cmtimes
						 [i_298_])),
					 (103 + 17 * i_298_
					  - ((Globe) this).scro));
				}
			    } else {
				if (((Globe) this).cmlinetyp[i_298_] == 20
				    || (((Globe) this).cmlinetyp[i_298_]
					== 50)) {
				    if (stringbutton(((Globe) this).rd,
						     "  View Clan  ", 267,
						     (112 + 17 * i_298_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0)) {
					String string
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					if (!((Globe) this).claname
						 .equals(string)) {
					    ((Globe) this).claname = string;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).ctab = 0;
					((Globe) this).tab = 3;
				    }
				    if (stringbutton(((Globe) this).rd,
						     "  View War Suggestion  ",
						     403,
						     (112 + 17 * i_298_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0)) {
					((Globe) this).viewgame1 = 1;
					if (((Globe) this).cmlinetyp[i_298_]
					    == 20)
					    ((Globe) this).nvgames1 = 4;
					else
					    ((Globe) this).nvgames1 = 9;
					((Globe) this).xclan
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					((Globe) this).viewwar1
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							1);
				    }
				    if (!((Globe) this).cmline[i_298_]
					     .endsWith("|out|")) {
					if (((Globe) this).cadmin == 1
					    && stringbutton(((Globe) this).rd,
							    "  Approve War  ",
							    548,
							    (112 + 17 * i_298_
							     - (((Globe) this)
								.scro)),
							    0, i, i_197_, bool,
							    0, 0)) {
					    ((Globe) this).tab = 2;
					    ((Globe) this).itab = 1;
					    ((Globe) this).litab = -1;
					    ((Globe) this).openi = 10;
					    String string
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    0);
					    if (!((Globe) this).intclan
						     .equals(string)) {
						((Globe) this).intclan
						    = string;
						((Globe) this).dispi = 0;
						((Globe) this).nil = 0;
						((Globe) this).lastint = "";
						((Globe) this).readint = 1;
					    }
					    ((Globe) this).warnum
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    1);
					    ((Globe) this).sendwarnum = true;
					    if ((((Globe) this).cmlinetyp
						 [i_298_])
						== 20)
						((Globe) this).intsel = 4;
					    else
						((Globe) this).intsel = 7;
					}
				    } else {
					((Globe) this).rd
					    .setColor(color2k(170, 170, 170));
					((Globe) this).rd.drawString
					    ("[ Approved or interaction replaced. ]",
					     (597
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("[ Approved or interaction replaced. ]"))
						 / 2)),
					     (112 + 17 * i_298_
					      - ((Globe) this).scro));
				    }
				}
				if (((Globe) this).cmlinetyp[i_298_] == 30
				    || (((Globe) this).cmlinetyp[i_298_]
					== 60)) {
				    if (stringbutton(((Globe) this).rd,
						     "  View Clan  ", 267,
						     (112 + 17 * i_298_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0)) {
					String string
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					if (!((Globe) this).claname
						 .equals(string)) {
					    ((Globe) this).claname = string;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).ctab = 0;
					((Globe) this).tab = 3;
				    }
				    if (stringbutton
					(((Globe) this).rd,
					 "  View Battle Suggestion  ", 407,
					 (112 + 17 * i_298_
					  - ((Globe) this).scro),
					 0, i, i_197_, bool, 0, 0)) {
					((Globe) this).viewgame1 = 1;
					if (((Globe) this).cmlinetyp[i_298_]
					    == 30)
					    ((Globe) this).nvgames1 = 2;
					else
					    ((Globe) this).nvgames1 = 5;
					((Globe) this).xclan
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					((Globe) this).viewwar1
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							3);
				    }
				    if (!((Globe) this).cmline[i_298_]
					     .endsWith("|out|")) {
					if (((Globe) this).cadmin == 1
					    && (stringbutton
						(((Globe) this).rd,
						 "  Approve Battle  ", 560,
						 (112 + 17 * i_298_
						  - ((Globe) this).scro),
						 0, i, i_197_, bool, 0, 0))) {
					    ((Globe) this).tab = 2;
					    ((Globe) this).itab = 1;
					    ((Globe) this).litab = -1;
					    ((Globe) this).openi = 10;
					    String string
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    0);
					    if (!((Globe) this).intclan
						     .equals(string)) {
						((Globe) this).intclan
						    = string;
						((Globe) this).dispi = 0;
						((Globe) this).nil = 0;
						((Globe) this).lastint = "";
						((Globe) this).readint = 1;
					    }
					    ((Globe) this).itake
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    1);
					    ((Globe) this).igive
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    2);
					    ((Globe) this).warnum
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    3);
					    ((Globe) this).sendwarnum = true;
					    if ((((Globe) this).cmlinetyp
						 [i_298_])
						== 30)
						((Globe) this).intsel = 3;
					    else
						((Globe) this).intsel = 6;
					}
				    } else {
					((Globe) this).rd
					    .setColor(color2k(170, 170, 170));
					((Globe) this).rd.drawString
					    ("[ Approved or interaction replaced. ]",
					     (604
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("[ Approved or interaction replaced. ]"))
						 / 2)),
					     (112 + 17 * i_298_
					      - ((Globe) this).scro));
				    }
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (stringbutton(((Globe) this).rd,
						     "  View Car  ",
						     (217
						      + (((Globe) this).ftm
							     .stringWidth
							 (((Globe) this).cmline
							  [i_298_ + 2]))
						      + 47),
						     (137 + 17 * i_298_
						      - ((Globe) this).scro),
						     6, i, i_197_, bool, 0,
						     0)) {
					((Globe) this).viewcar
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							1);
					String string
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					if (!((Globe) this).claname
						 .equals(string)) {
					    ((Globe) this).claname = string;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).loadedcars = -1;
					((Globe) this).loadedcar = 0;
					((Globe) this).ctab = 2;
					((Globe) this).tab = 3;
				    }
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (stringbutton(((Globe) this).rd,
						     "  View Car  ",
						     (217
						      + (((Globe) this).ftm
							     .stringWidth
							 (((Globe) this).cmline
							  [i_298_ + 3]))
						      + 47),
						     (154 + 17 * i_298_
						      - ((Globe) this).scro),
						     6, i, i_197_, bool, 0,
						     0)) {
					((Globe) this).viewcar
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							2);
					if (!((Globe) this).claname.equals
					     (((xtGraphics) ((Globe) this).xt)
					      .clan)) {
					    ((Globe) this).claname
						= ((xtGraphics)
						   ((Globe) this).xt).clan;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).loadedcars = -1;
					((Globe) this).loadedcar = 0;
					((Globe) this).ctab = 2;
					((Globe) this).tab = 3;
				    }
				}
				if (((Globe) this).cmlinetyp[i_298_] == 40
				    || (((Globe) this).cmlinetyp[i_298_]
					== 70)) {
				    if (stringbutton(((Globe) this).rd,
						     "  View Clan  ", 267,
						     (112 + 17 * i_298_
						      - ((Globe) this).scro),
						     0, i, i_197_, bool, 0,
						     0)) {
					String string
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					if (!((Globe) this).claname
						 .equals(string)) {
					    ((Globe) this).claname = string;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).ctab = 0;
					((Globe) this).tab = 3;
				    }
				    if (stringbutton
					(((Globe) this).rd,
					 "  View Battle Suggestion  ", 407,
					 (112 + 17 * i_298_
					  - ((Globe) this).scro),
					 0, i, i_197_, bool, 0, 0)) {
					((Globe) this).viewgame1 = 1;
					if (((Globe) this).cmlinetyp[i_298_]
					    == 40)
					    ((Globe) this).nvgames1 = 2;
					else
					    ((Globe) this).nvgames1 = 5;
					((Globe) this).xclan
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					((Globe) this).viewwar1
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							3);
				    }
				    if (!((Globe) this).cmline[i_298_]
					     .endsWith("|out|")) {
					if (((Globe) this).cadmin == 1
					    && (stringbutton
						(((Globe) this).rd,
						 "  Approve Battle  ", 560,
						 (112 + 17 * i_298_
						  - ((Globe) this).scro),
						 0, i, i_197_, bool, 0, 0))) {
					    ((Globe) this).tab = 2;
					    ((Globe) this).itab = 1;
					    ((Globe) this).litab = -1;
					    ((Globe) this).openi = 10;
					    String string
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    0);
					    if (!((Globe) this).intclan
						     .equals(string)) {
						((Globe) this).intclan
						    = string;
						((Globe) this).dispi = 0;
						((Globe) this).nil = 0;
						((Globe) this).lastint = "";
						((Globe) this).readint = 1;
					    }
					    ((Globe) this).itake
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    1);
					    ((Globe) this).igive
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    2);
					    ((Globe) this).warnum
						= getSvalue((((Globe) this)
							     .cmline[i_298_]),
							    3);
					    ((Globe) this).sendwarnum = true;
					    if ((((Globe) this).cmlinetyp
						 [i_298_])
						== 40)
						((Globe) this).intsel = 2;
					    else
						((Globe) this).intsel = 5;
					}
				    } else {
					((Globe) this).rd
					    .setColor(color2k(170, 170, 170));
					((Globe) this).rd.drawString
					    ("[ Approved or interaction replaced. ]",
					     (604
					      - ((((Globe) this).ftm
						      .stringWidth
						  ("[ Approved or interaction replaced. ]"))
						 / 2)),
					     (112 + 17 * i_298_
					      - ((Globe) this).scro));
				    }
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (stringbutton(((Globe) this).rd,
						     "  View Stage  ",
						     (217
						      + (((Globe) this).ftm
							     .stringWidth
							 (((Globe) this).cmline
							  [i_298_ + 2]))
						      + 54),
						     (137 + 17 * i_298_
						      - ((Globe) this).scro),
						     6, i, i_197_, bool, 0,
						     0)) {
					((Globe) this).viewcar
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							1);
					String string
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							0);
					if (!((Globe) this).claname
						 .equals(string)) {
					    ((Globe) this).claname = string;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).loadedstages = -1;
					((Globe) this).loadedstage = 0;
					((Globe) this).ctab = 3;
					((Globe) this).tab = 3;
				    }
				    ((Globe) this).rd
					.setFont(new Font("Tahoma", 0, 11));
				    ((Globe) this).ftm
					= ((Globe) this).rd.getFontMetrics();
				    if (stringbutton(((Globe) this).rd,
						     "  View Stage  ",
						     (217
						      + (((Globe) this).ftm
							     .stringWidth
							 (((Globe) this).cmline
							  [i_298_ + 3]))
						      + 54),
						     (154 + 17 * i_298_
						      - ((Globe) this).scro),
						     6, i, i_197_, bool, 0,
						     0)) {
					((Globe) this).viewcar
					    = getSvalue((((Globe) this).cmline
							 [i_298_]),
							2);
					if (!((Globe) this).claname.equals
					     (((xtGraphics) ((Globe) this).xt)
					      .clan)) {
					    ((Globe) this).claname
						= ((xtGraphics)
						   ((Globe) this).xt).clan;
					    ((Globe) this).loadedc = false;
					}
					((Globe) this).spos5 = 0;
					((Globe) this).lspos5 = 0;
					((Globe) this).cfase = 3;
					((Globe) this).loadedstages = -1;
					((Globe) this).loadedstage = 0;
					((Globe) this).ctab = 3;
					((Globe) this).tab = 3;
				    }
				}
				if (((Globe) this).cmlinetyp[i_298_] == 80
				    && stringbutton(((Globe) this).rd,
						    "  View Championship  ",
						    295,
						    (112 + 17 * i_298_
						     - ((Globe) this).scro),
						    0, i, i_197_, bool, 0,
						    0)) {
				    ((Globe) this).cfase = 0;
				    ((Globe) this).ntab = 1;
				    ((Globe) this).loadwstat = 0;
				    ((Globe) this).tab = 3;
				}
			    }
			}
		    }
		}
		if (((Globe) this).readclan == -3) {
		    ((Globe) this).rd.setColor(color2k(240, 240, 240));
		    ((Globe) this).rd.fillRoundRect(387, 140, 200, 30, 20, 20);
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawRoundRect(387, 140, 200, 30, 20, 20);
		    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Reading...",
			 (487
			  - ((Globe) this).ftm.stringWidth("Reading...") / 2),
			 160);
		}
		if (((Globe) this).readclan == -1) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Failed to load clan's conversation, please try again later...",
			 (487
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to load clan's conversation, please try again later..."))
			     / 2)),
			 200);
		}
		if (((Globe) this).readclan == -2) {
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 11));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("Failed to send data, please try again later...",
			 (487
			  - ((((Globe) this).ftm.stringWidth
			      ("Failed to send data, please try again later..."))
			     / 2)),
			 200);
		}
		((Globe) this).rd.setColor(color2k(205, 205, 205));
		((Globe) this).rd.fillRect(207, 76, 357, 36);
		if (!drawl(((Globe) this).rd,
			   new StringBuilder().append("#").append
			       (((xtGraphics) ((Globe) this).xt).clan).append
			       ("#").toString(),
			   209, 78, true)) {
		    ((Globe) this).rd.drawRect(209, 78, 349, 29);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("").append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     ("").toString(),
			 384 - (((Globe) this).ftm.stringWidth
				(new StringBuilder().append("").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     ("").toString())) / 2,
			 98);
		}
		if (i > 209 && i < 559 && i_197_ > 78 && i_197_ < 108
		    && ((Globe) this).blockb == 0) {
		    ((Globe) this).cur = 12;
		    if (bool) {
			if (!((Globe) this).claname.equals(((xtGraphics)
							    ((Globe) this).xt)
							   .clan)) {
			    ((Globe) this).claname
				= ((xtGraphics) ((Globe) this).xt).clan;
			    ((Globe) this).loadedc = false;
			}
			((Globe) this).spos5 = 0;
			((Globe) this).lspos5 = 0;
			((Globe) this).cfase = 3;
			((Globe) this).ctab = 0;
			((Globe) this).tab = 3;
		    }
		}
	    } else if (((xtGraphics) ((Globe) this).xt).logged) {
		((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		((Globe) this).rd.drawString
		    ("You are not a member of any clan.  You need to join a clan first to have access to this.",
		     (487
		      - ((((Globe) this).ftm.stringWidth
			  ("You are not a member of any clan.  You need to join a clan first to have access to this."))
			 / 2)),
		     170);
		if (stringbutton(((Globe) this).rd,
				 "   Find a clan to join   ", 487, 200, 1, i,
				 i_197_, bool, 0, 0)) {
		    ((Globe) this).tab = 3;
		    ((Globe) this).cfase = 2;
		    ((Globe) this).em = 1;
		    ((Globe) this).msg = "Clan Search";
		    ((Globe) this).smsg
			= "Listing clans with recent activity...";
		    ((Globe) this).nclns = 0;
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).flko = 0;
		}
	    } else {
		((Globe) this).rd.setFont(new Font("Arial", 1, 13));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		((Globe) this).rd.drawString
		    ("You are currently using a trial account.",
		     495 - (((Globe) this).ftm.stringWidth
			    ("You are currently using a trial account.")) / 2,
		     150);
		((Globe) this).rd.drawString
		    ("You need to upgrade to be able participate in NFM clan's activities.",
		     (495
		      - ((((Globe) this).ftm.stringWidth
			  ("You need to upgrade to be able participate in NFM clan's activities."))
			 / 2)),
		     170);
		((Globe) this).rd.setColor(new Color(206, 171, 98));
		((Globe) this).rd.fillRoundRect(405, 193, 180, 50, 20, 20);
		if (drawbutton(((xtGraphics) ((Globe) this).xt).upgrade, 495,
			       218, i, i_197_, bool))
		    ((Globe) this).gs.editlink(((xtGraphics)
						((Globe) this).xt).nickname,
					       true);
	    }
	    ((Globe) this).rd.setColor(color2k(205, 205, 205));
	    ((Globe) this).rd.fillRect(207, 46, 582, 30);
	    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    String[] strings = { "Player Interaction", "Clan Interaction",
				 "Your Clan's Discussion" };
	    int[] is = { 207, 390, 368, 207 };
	    int[] is_299_ = { 73, 73, 51, 51 };
	    for (int i_300_ = 0; i_300_ < 3; i_300_++) {
		if (((Globe) this).itab == i_300_) {
		    ((Globe) this).rd.setColor(color2k(230, 230, 230));
		    ((Globe) this).rd.fillPolygon(is, is_299_, 4);
		} else if (i > is[0] && i < is[2] && i_197_ > 51
			   && i_197_ < 73) {
		    ((Globe) this).rd.setColor(color2k(217, 217, 217));
		    ((Globe) this).rd.fillPolygon(is, is_299_, 4);
		    if (bool)
			((Globe) this).itab = i_300_;
		}
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawPolygon(is, is_299_, 4);
		((Globe) this).rd.setColor(color2k(40, 40, 40));
		((Globe) this).rd.drawString
		    (strings[i_300_],
		     (is[0] + 80
		      - ((Globe) this).ftm.stringWidth(strings[i_300_]) / 2),
		     67);
		for (int i_301_ = 0; i_301_ < 4; i_301_++)
		    is[i_301_] += 183;
	    }
	    ((Globe) this).rd.setColor(color2k(150, 150, 150));
	    ((Globe) this).rd.drawLine(207, 73, 770, 73);
	    ((Globe) this).rd.setColor(color2k(205, 205, 205));
	    ((Globe) this).rd.fillRect(207, 360, 582, 79);
	    ((Globe) this).rd.setColor(color2k(150, 150, 150));
	    ((Globe) this).rd.drawLine(207, 362, 770, 362);
	    ((Globe) this).rd.setColor(color2k(205, 205, 205));
	    ((Globe) this).rd.fillRect(772, 76, 17, 333);
	    ((Globe) this).rd.setColor(color2k(205, 205, 205));
	    ((Globe) this).rd.fillRect(203, 46, 4, 393);
	    if (((Globe) this).mscro3 == 831 || ((Globe) this).sdist == 0) {
		if (((Globe) this).sdist == 0)
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		else
		    ((Globe) this).rd.setColor(color2k(215, 215, 215));
		((Globe) this).rd.fillRect(772, 76, 17, 17);
	    } else {
		((Globe) this).rd.setColor(color2k(220, 220, 220));
		((Globe) this).rd.fill3DRect(772, 76, 17, 17, true);
	    }
	    if (((Globe) this).sdist != 0)
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .asu),
					    777, 82, null);
	    if (((Globe) this).mscro3 == 832 || ((Globe) this).sdist == 0) {
		if (((Globe) this).sdist == 0)
		    ((Globe) this).rd.setColor(color2k(205, 205, 205));
		else
		    ((Globe) this).rd.setColor(color2k(215, 215, 215));
		((Globe) this).rd.fillRect(772, 343, 17, 17);
	    } else {
		((Globe) this).rd.setColor(color2k(220, 220, 220));
		((Globe) this).rd.fill3DRect(772, 343, 17, 17, true);
	    }
	    if (((Globe) this).sdist != 0)
		((Globe) this).rd.drawImage((((xtGraphics) ((Globe) this).xt)
					     .asd),
					    777, 350, null);
	    if (((Globe) this).sdist != 0) {
		if (((Globe) this).lspos3 != ((Globe) this).spos3) {
		    ((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fillRect(772, 93 + ((Globe) this).spos3,
					       17, 31);
		} else {
		    if (((Globe) this).mscro3 == 831)
			((Globe) this).rd.setColor(color2k(215, 215, 215));
		    ((Globe) this).rd.fill3DRect(772,
						 93 + ((Globe) this).spos3, 17,
						 31, true);
		}
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawLine(777, 106 + ((Globe) this).spos3,
					   783, 106 + ((Globe) this).spos3);
		((Globe) this).rd.drawLine(777, 108 + ((Globe) this).spos3,
					   783, 108 + ((Globe) this).spos3);
		((Globe) this).rd.drawLine(777, 110 + ((Globe) this).spos3,
					   783, 110 + ((Globe) this).spos3);
		if (((Globe) this).mscro3 > 800
		    && ((Globe) this).lspos3 != ((Globe) this).spos3)
		    ((Globe) this).lspos3 = ((Globe) this).spos3;
		if (bool && ((Globe) this).openc == 0) {
		    if (((Globe) this).mscro3 == 825 && i > 772 && i < 789
			&& i_197_ > 93 + ((Globe) this).spos3
			&& i_197_ < ((Globe) this).spos3 + 124)
			((Globe) this).mscro3 = i_197_ - ((Globe) this).spos3;
		    if (((Globe) this).mscro3 == 825 && i > 770 && i < 791
			&& i_197_ > 74 && i_197_ < 95)
			((Globe) this).mscro3 = 831;
		    if (((Globe) this).mscro3 == 825 && i > 770 && i < 791
			&& i_197_ > 341 && i_197_ < 362)
			((Globe) this).mscro3 = 832;
		    if (((Globe) this).mscro3 == 825 && i > 772 && i < 789
			&& i_197_ > 93 && i_197_ < 343) {
			((Globe) this).mscro3 = 108;
			((Globe) this).spos3 = i_197_ - ((Globe) this).mscro3;
		    }
		    int i_302_ = 2670 / ((Globe) this).sdist;
		    if (i_302_ < 1)
			i_302_ = 1;
		    if (((Globe) this).mscro3 == 831) {
			((Globe) this).spos3 -= i_302_;
			if (((Globe) this).spos3 > 219)
			    ((Globe) this).spos3 = 219;
			if (((Globe) this).spos3 < 0)
			    ((Globe) this).spos3 = 0;
			((Globe) this).lspos3 = ((Globe) this).spos3;
		    }
		    if (((Globe) this).mscro3 == 832) {
			((Globe) this).spos3 += i_302_;
			if (((Globe) this).spos3 > 219)
			    ((Globe) this).spos3 = 219;
			if (((Globe) this).spos3 < 0)
			    ((Globe) this).spos3 = 0;
			((Globe) this).lspos3 = ((Globe) this).spos3;
		    }
		    if (((Globe) this).mscro3 < 800) {
			((Globe) this).spos3 = i_197_ - ((Globe) this).mscro3;
			if (((Globe) this).spos3 > 219)
			    ((Globe) this).spos3 = 219;
			if (((Globe) this).spos3 < 0)
			    ((Globe) this).spos3 = 0;
		    }
		    if (((Globe) this).mscro3 == 825)
			((Globe) this).mscro3 = 925;
		} else if (((Globe) this).mscro3 != 825)
		    ((Globe) this).mscro3 = 825;
	    }
	    if (((Globe) this).viewgame1 != 0) {
		((Globe) this).rd.setColor(color2k(210, 210, 210));
		((Globe) this).rd.fillRoundRect(204, 127, 583, 230, 20, 20);
		((Globe) this).rd.setColor(color2k(150, 150, 150));
		((Globe) this).rd.drawRoundRect(204, 127, 583, 230, 20, 20);
		((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		if (((Globe) this).nvgames1 == 4) {
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("War declaration, your clan ").append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     (" versus ").append
			     (((Globe) this).xclan).append
			     (".").toString(),
			 215, 145);
		    if (((Globe) this).viewgame1 == 2)
			((Globe) this).rd.drawString
			    (new StringBuilder().append("").append
				 (((Globe) this).xclan).append
				 (" would create 5 more games and the first clan to win 5 games wins the war!")
				 .toString(),
			     215, 210 + ((Globe) this).nvgames1 * 18);
		}
		if (((Globe) this).nvgames1 == 2) {
		    ((Globe) this).rd.drawString
			(new StringBuilder().append("Battle, your clan ")
			     .append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     (" versus ").append
			     (((Globe) this).xclan).append
			     (".").toString(),
			 215, 145);
		    if (((Globe) this).viewgame1 == 2)
			((Globe) this).rd.drawString
			    (new StringBuilder().append("").append
				 (((Globe) this).xclan).append
				 (" would create 3 more games and the first clan to win 3 games wins the battle!")
				 .toString(),
			     215, 210 + ((Globe) this).nvgames1 * 18);
		}
		if (((Globe) this).nvgames1 == 9)
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("Suggestion to accept war, your clan ").append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     (" versus ").append
			     (((Globe) this).xclan).append
			     (".").toString(),
			 215, 145);
		if (((Globe) this).nvgames1 == 5)
		    ((Globe) this).rd.drawString
			(new StringBuilder().append
			     ("Suggestion to accept to battle, your clan ")
			     .append
			     (((xtGraphics) ((Globe) this).xt).clan).append
			     (" versus ").append
			     (((Globe) this).xclan).append
			     (".").toString(),
			 215, 145);
		if (stringbutton(((Globe) this).rd, "Close X", 749, 148, 3, i,
				 i_197_, bool, 0, 0))
		    ((Globe) this).viewgame1 = 0;
		((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
		((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		((Globe) this).rd.setColor(new Color(0, 0, 0));
		if (((Globe) this).viewgame1 == 2) {
		    ((Globe) this).rd.drawString
			("Game",
			 246 - ((Globe) this).ftm.stringWidth("Game") / 2,
			 175);
		    ((Globe) this).rd.drawString
			("Stage",
			 412 - ((Globe) this).ftm.stringWidth("Stage") / 2,
			 175);
		    ((Globe) this).rd.drawString
			("Laps",
			 564 - ((Globe) this).ftm.stringWidth("Laps") / 2,
			 175);
		    ((Globe) this).rd.drawString
			("Type of Cars",
			 653 - (((Globe) this).ftm.stringWidth("Type of Cars")
				/ 2),
			 175);
		    ((Globe) this).rd.drawString
			("Fixing",
			 751 - ((Globe) this).ftm.stringWidth("Fixing") / 2,
			 175);
		    int i_303_ = 1;
		    int i_304_ = 1;
		    if (((Globe) this).nvgames1 == 4
			|| ((Globe) this).nvgames1 == 2) {
			i_303_ = 2;
			i_304_ = 2;
		    }
		    for (int i_305_ = 0; i_305_ < ((Globe) this).nvgames1;
			 i_305_++) {
			((Globe) this).rd.setFont(new Font("Tahoma", 0, 11));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    (new StringBuilder().append("# ").append
				 (i_303_).append
				 ("").toString(),
			     246 - (((Globe) this).ftm.stringWidth
				    (new StringBuilder().append("# ").append
					 (i_303_).append
					 ("").toString())) / 2,
			     193 + i_305_ * 18);
			i_303_ += i_304_;
			((Globe) this).rd.drawString
			    (((Globe) this).vwstages1[i_305_],
			     (412
			      - ((Globe) this).ftm.stringWidth(((Globe) this)
							       .vwstages1
							       [i_305_]) / 2),
			     193 + i_305_ * 18);
			((Globe) this).rd.drawString
			    (new StringBuilder().append("").append
				 (((Globe) this).vwlaps1[i_305_]).append
				 ("").toString(),
			     564 - (((Globe) this).ftm.stringWidth
				    (new StringBuilder().append("").append
					 (((Globe) this).vwlaps1[i_305_])
					 .append
					 ("").toString())) / 2,
			     193 + i_305_ * 18);
			String string = "All Cars";
			if (((Globe) this).vwcars1[i_305_] == 2)
			    string = "Clan Cars";
			if (((Globe) this).vwcars1[i_305_] == 3)
			    string = "Game Cars";
			if (((Globe) this).vwclass1[i_305_] == 0)
			    string = new StringBuilder().append(string).append
					 (", All Classes").toString();
			if (((Globe) this).vwclass1[i_305_] == 1)
			    string = new StringBuilder().append(string).append
					 (", Class C").toString();
			if (((Globe) this).vwclass1[i_305_] == 2)
			    string = new StringBuilder().append(string).append
					 (", Class B & C").toString();
			if (((Globe) this).vwclass1[i_305_] == 3)
			    string = new StringBuilder().append(string).append
					 (", Class B").toString();
			if (((Globe) this).vwclass1[i_305_] == 4)
			    string = new StringBuilder().append(string).append
					 (", Class A & B").toString();
			if (((Globe) this).vwclass1[i_305_] == 5)
			    string = new StringBuilder().append(string).append
					 (", Class A").toString();
			((Globe) this).rd.drawString
			    (string,
			     653 - ((Globe) this).ftm.stringWidth(string) / 2,
			     193 + i_305_ * 18);
			String string_306_ = "Infinite";
			if (((Globe) this).vwfix1[i_305_] == 1)
			    string_306_ = "4 Fixes";
			if (((Globe) this).vwfix1[i_305_] == 2)
			    string_306_ = "3 Fixes";
			if (((Globe) this).vwfix1[i_305_] == 3)
			    string_306_ = "2 Fixes";
			if (((Globe) this).vwfix1[i_305_] == 4)
			    string_306_ = "1 Fix";
			if (((Globe) this).vwfix1[i_305_] == 5)
			    string_306_ = "No Fixing";
			((Globe) this).rd.drawString
			    (string_306_,
			     751 - (((Globe) this).ftm.stringWidth(string_306_)
				    / 2),
			     193 + i_305_ * 18);
			((Globe) this).rd.drawRect(213, 180 + i_305_ * 18, 565,
						   18);
		    }
		    ((Globe) this).rd.drawLine(213, 162, 213,
					       180 + (((Globe) this).nvgames1
						      * 18));
		    ((Globe) this).rd.drawLine(279, 162, 279,
					       180 + (((Globe) this).nvgames1
						      * 18));
		    ((Globe) this).rd.drawLine(546, 162, 546,
					       180 + (((Globe) this).nvgames1
						      * 18));
		    ((Globe) this).rd.drawLine(583, 162, 583,
					       180 + (((Globe) this).nvgames1
						      * 18));
		    ((Globe) this).rd.drawLine(723, 162, 723,
					       180 + (((Globe) this).nvgames1
						      * 18));
		    ((Globe) this).rd.drawLine(778, 162, 778,
					       180 + (((Globe) this).nvgames1
						      * 18));
		}
		if (((Globe) this).viewgame1 == 1)
		    ((Globe) this).rd.drawString
			("Loading...",
			 (495
			  - ((Globe) this).ftm.stringWidth("Loading...") / 2),
			 242);
		if (((Globe) this).viewgame1 == 3) {
		    if (((Globe) this).nvgames1 == 4
			|| ((Globe) this).nvgames1 == 9)
			((Globe) this).rd.drawString
			    ("This war suggestion has expired and no longer exists.",
			     (495
			      - ((((Globe) this).ftm.stringWidth
				  ("This war suggestion has expired and no longer exists."))
				 / 2)),
			     232);
		    if (((Globe) this).nvgames1 == 2
			|| ((Globe) this).nvgames1 == 5)
			((Globe) this).rd.drawString
			    ("This battle suggestion has expired and no longer exists.",
			     (495
			      - ((((Globe) this).ftm.stringWidth
				  ("This battle suggestion has expired and no longer exists."))
				 / 2)),
			     232);
		    ((Globe) this).rd.drawString
			("(Suggestions expire after 90 days.)",
			 495 - (((Globe) this).ftm.stringWidth
				("(Suggestions expire after 90 days.)")) / 2,
			 252);
		}
		if (((Globe) this).viewgame1 == 4)
		    ((Globe) this).rd.drawString
			("Error loading suggestion, please try again later...",
			 (495
			  - ((((Globe) this).ftm.stringWidth
			      ("Error loading suggestion, please try again later..."))
			     / 2)),
			 242);
	    }
	    if (!((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		if (!((GameSparker) ((Globe) this).gs).sendtyp.isShowing()) {
		    ((GameSparker) ((Globe) this).gs).sendtyp.show();
		    ((GameSparker) ((Globe) this).gs).sendtyp.select(0);
		}
		((GameSparker) ((Globe) this).gs).sendtyp.move(207, 365);
		if (((Globe) this).sendcmsg != 0)
		    ((GameSparker) ((Globe) this).gs).sendtyp.disable();
		else
		    ((GameSparker) ((Globe) this).gs).sendtyp.enable();
		((Globe) this).darker = true;
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 0) {
		    ((Globe) this).dommsg = true;
		    if (((Globe) this).sendcmsg == 0) {
			if (stringbutton(((Globe) this).rd, "   Send  >  ",
					 723, 408, 0, i, i_197_, bool, 0, 0)
			    && !((GameSparker) ((Globe) this).gs).mmsg.getText
				    ().trim
				    ().equals("")
			    && (((GameSparker) ((Globe) this).gs).mmsg.getText
				    ().toLowerCase
				    ().indexOf
				(((GameSparker) ((Globe) this).gs).tpass
				     .getText
				     ().toLowerCase())) == -1
			    && ((xtGraphics) ((Globe) this).xt).acexp != -3) {
			    if (!((Globe) this).xt.msgcheck(((GameSparker)
							     ((Globe) this).gs)
								.mmsg
								.getText())) {
				((Globe) this).sendcmsg = 1;
				((Globe) this).viewgame1 = 0;
			    } else {
				((GameSparker) ((Globe) this).gs).sendtyp
				    .hide();
				((xtGraphics) ((Globe) this).xt).warning++;
			    }
			}
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.setColor(new Color(0, 0, 0));
			((Globe) this).rd.drawString
			    ("Sending...",
			     723 - ((Globe) this).ftm
				       .stringWidth("Sending...") / 2,
			     408);
		    }
		}
		if (((GameSparker) ((Globe) this).gs).sendtyp
			.getSelectedIndex()
		    == 1) {
		    ((Globe) this).rd.setFont(new Font("Arial", 0, 12));
		    ((Globe) this).rd.setColor(new Color(0, 0, 0));
		    ((Globe) this).rd.drawString
			("A date that gets converted to the local time of any person previewing it.",
			 376, 382);
		    if (!((GameSparker) ((Globe) this).gs).senditem
			     .isShowing()) {
			((GameSparker) ((Globe) this).gs).senditem.removeAll();
			Calendar calendar = Calendar.getInstance();
			boolean bool_307_ = false;
			for (int i_308_ = 0; i_308_ < 20; i_308_++) {
			    String[] strings_309_ = ((Globe) this).wday;
			    Calendar calendar_310_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    String string
				= strings_309_[calendar_310_.get(7) - 1];
			    if (!bool_307_) {
				string = "Today";
				bool_307_ = true;
			    }
			    Smenu smenu
				= ((GameSparker) ((Globe) this).gs).senditem;
			    Graphics2D graphics2d = ((Globe) this).rd;
			    StringBuilder stringbuilder
				= new StringBuilder().append("").append
				      (string).append("  -  ");
			    String[] strings_311_ = ((Globe) this).month;
			    Calendar calendar_312_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    StringBuilder stringbuilder_313_
				= stringbuilder.append
				      (strings_311_[calendar_312_.get(2)])
				      .append(" ");
			    Calendar calendar_314_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    smenu.add(graphics2d,
				      stringbuilder_313_.append
					  (calendar_314_.get(5)).append
					  ("").toString());
			    Calendar calendar_315_ = calendar;
			    if (calendar != null) {
				/* empty */
			    }
			    calendar_315_.roll(5, true);
			}
			((GameSparker) ((Globe) this).gs).senditem.select(0);
			((GameSparker) ((Globe) this).gs).senditem.show();
		    }
		    if (!((GameSparker) ((Globe) this).gs).datat.isShowing()) {
			((GameSparker) ((Globe) this).gs).datat.removeAll();
			int i_316_ = 12;
			String string = "PM";
			for (int i_317_ = 0; i_317_ < 24; i_317_++) {
			    ((GameSparker) ((Globe) this).gs).datat.add
				(((Globe) this).rd,
				 new StringBuilder().append("").append
				     (i_316_).append
				     (" ").append
				     (string).append
				     ("").toString());
			    if (++i_316_ == 12)
				string = "AM";
			    if (i_316_ == 13)
				i_316_ = 1;
			}
			((GameSparker) ((Globe) this).gs).datat.select(0);
			((GameSparker) ((Globe) this).gs).datat.show();
		    }
		    ((GameSparker) ((Globe) this).gs).senditem.move(300, 395);
		    ((GameSparker) ((Globe) this).gs).datat.move(491, 395);
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    ((Globe) this).rd.drawString
			("Date is displayed based on your computer calendar's date/time, please make sure it is correct.",
			 207, 435);
		    if (((Globe) this).sendcmsg == 0) {
			if (stringbutton(((Globe) this).rd, "   Send  >  ",
					 723, 408, 0, i, i_197_, bool, 0, 0)) {
			    ((Globe) this).sendcmsg = 1;
			    ((Globe) this).viewgame1 = 0;
			}
		    } else {
			((Globe) this).rd.setFont(new Font("Arial", 1, 12));
			((Globe) this).ftm
			    = ((Globe) this).rd.getFontMetrics();
			((Globe) this).rd.drawString
			    ("Sending...",
			     723 - ((Globe) this).ftm
				       .stringWidth("Sending...") / 2,
			     408);
		    }
		} else {
		    if (((GameSparker) ((Globe) this).gs).senditem.isShowing())
			((GameSparker) ((Globe) this).gs).senditem.hide();
		    if (((GameSparker) ((Globe) this).gs).datat.isShowing())
			((GameSparker) ((Globe) this).gs).datat.hide();
		}
		((Globe) this).darker = false;
	    }
	}
    }
    
    public void run() {
	try {
	    ((Globe) this).socket
		= new Socket(((Login) ((Globe) this).lg).servers[0], 7061);
	    ((Globe) this).din
		= new BufferedReader(new InputStreamReader
				     (((Globe) this).socket.getInputStream()));
	    ((Globe) this).dout
		= new PrintWriter(((Globe) this).socket.getOutputStream(),
				  true);
	} catch (Exception exception) {
	    ((Globe) this).domon = false;
	}
	while (((Globe) this).domon) {
	    String string = "";
	    String string_318_ = "";
	    string = new StringBuilder().append("101|0|").append
			 (((xtGraphics) ((Globe) this).xt).nickname).append
			 (":").append
			 (((xtGraphics) ((Globe) this).xt).nickey).append
			 ("|").toString();
	    try {
		((Globe) this).dout.println(string);
		string_318_ = ((Globe) this).din.readLine();
		if (string_318_ == null)
		    ((Globe) this).domon = false;
	    } catch (Exception exception) {
		((Globe) this).domon = false;
	    }
	    if (((Globe) this).domon) {
		((Globe) this).ntime = getLvalue(string_318_, 0);
		((Globe) this).maxclans = getvalue(string_318_, 1);
		for (int i = 0; i < 3; i++) {
		    for (int i_319_ = 0; i_319_ < 5; i_319_++)
			((Globe) this).roomf[i][i_319_] = 0;
		}
		int i = 0;
		int i_320_ = 2;
		boolean bool = false;
		while (!bool) {
		    String string_321_ = getSvalue(string_318_, i_320_);
		    if (!string_321_.equals("")) {
			int i_322_ = getvalue(string_318_, i_320_ + 1);
			int i_323_ = getvalue(string_318_, i_320_ + 2);
			if ((i_322_ == -1 || i_323_ == -1) && i < 900) {
			    ((Globe) this).pname[i] = string_321_;
			    ((Globe) this).proom[i] = i_322_;
			    ((Globe) this).pserver[i] = i_323_;
			    i++;
			}
		    } else
			bool = true;
		    i_320_ += 3;
		}
		i_320_ = 2;
		bool = false;
		while (!bool) {
		    String string_324_ = getSvalue(string_318_, i_320_);
		    if (!string_324_.equals("")) {
			int i_325_ = getvalue(string_318_, i_320_ + 1);
			int i_326_ = getvalue(string_318_, i_320_ + 2);
			if (i_325_ >= 0 && i_325_ <= 4 && i_326_ >= 0
			    && i_326_ <= 2) {
			    ((Globe) this).roomf[i_326_][i_325_]++;
			    if (i < 900) {
				((Globe) this).pname[i] = string_324_;
				((Globe) this).proom[i] = i_325_;
				((Globe) this).pserver[i] = i_326_;
				i++;
			    }
			}
		    } else
			bool = true;
		    i_320_ += 3;
		}
		((Globe) this).npo = i;
	    }
	    if (((Globe) this).ptab == 1) {
		if (((Globe) this).freq == 2) {
		    string
			= new StringBuilder().append("101|14|").append
			      (((xtGraphics) ((Globe) this).xt).nickname)
			      .append
			      ("|").append
			      (((xtGraphics) ((Globe) this).xt).nickey).append
			      ("|").append
			      (((Globe) this).freqname).append
			      ("|").toString();
		    try {
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
		    } catch (Exception exception) {
			/* empty */
		    }
		    if (string_318_.equals("OK")) {
			((Globe) this).freq = 0;
			((Globe) this).npf = -1;
		    } else {
			((Globe) this).freq = -1;
			((Globe) this).cntf = 40;
		    }
		}
		if (((Globe) this).freq == 3) {
		    string
			= new StringBuilder().append("101|15|").append
			      (((xtGraphics) ((Globe) this).xt).nickname)
			      .append
			      ("|").append
			      (((xtGraphics) ((Globe) this).xt).nickey).append
			      ("|").append
			      (((Globe) this).freqname).append
			      ("|").toString();
		    try {
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
		    } catch (Exception exception) {
			/* empty */
		    }
		    if (string_318_.equals("OK")) {
			((Globe) this).freq = 0;
			((Globe) this).npf = -1;
		    } else {
			((Globe) this).freq = -2;
			((Globe) this).cntf = 40;
		    }
		}
		if (((Globe) this).freq == -6) {
		    string
			= new StringBuilder().append("101|18|").append
			      (((xtGraphics) ((Globe) this).xt).nickname)
			      .append
			      ("|").append
			      (((xtGraphics) ((Globe) this).xt).nickey).append
			      ("|").toString();
		    try {
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
		    } catch (Exception exception) {
			/* empty */
		    }
		    ((Globe) this).freq = 0;
		}
		loadfriends();
	    }
	    if (((Globe) this).sfreq == 1) {
		string = new StringBuilder().append("101|16|").append
			     (((xtGraphics) ((Globe) this).xt).nickname).append
			     ("|").append
			     (((xtGraphics) ((Globe) this).xt).nickey).append
			     ("|").append
			     (((Globe) this).proname).append
			     ("|").toString();
		try {
		    ((Globe) this).dout.println(string);
		    string_318_ = ((Globe) this).din.readLine();
		} catch (Exception exception) {
		    /* empty */
		}
		if (string_318_.equals("OK"))
		    ((Globe) this).sfreq = 2;
		else
		    ((Globe) this).sfreq = 3;
	    }
	    if (((Globe) this).sfreq == 4) {
		string = new StringBuilder().append("101|17|").append
			     (((xtGraphics) ((Globe) this).xt).nickname).append
			     ("|").append
			     (((xtGraphics) ((Globe) this).xt).nickey).append
			     ("|").append
			     (((Globe) this).proname).append
			     ("|").toString();
		try {
		    ((Globe) this).dout.println(string);
		    string_318_ = ((Globe) this).din.readLine();
		} catch (Exception exception) {
		    /* empty */
		}
		if (string_318_.equals("OK")) {
		    ((Globe) this).sfreq = 5;
		    ((Globe) this).npf = -1;
		} else
		    ((Globe) this).sfreq = 6;
	    }
	    if (((Globe) this).sentchange == 2 && ((Globe) this).domon) {
		string
		    = new StringBuilder().append("101|5|").append
			  (((GameSparker) ((Globe) this).gs).tnick.getText())
			  .append
			  ("|").append
			  (((GameSparker) ((Globe) this).gs).tpass.getText())
			  .append
			  ("|").append
			  (((Globe) this).sentance).append
			  ("|").toString();
		try {
		    ((Globe) this).dout.println(string);
		    string_318_ = ((Globe) this).din.readLine();
		} catch (Exception exception) {
		    /* empty */
		}
		((Globe) this).sentchange = 0;
	    }
	    if (((Globe) this).tab == 2 && ((Globe) this).domon) {
		if (((Globe) this).itab == 0) {
		    if (!((Globe) this).blockname.equals("")) {
			for (int i = 0; i < ((Globe) this).nm; i++) {
			    if (((Globe) this).mname[i]
				    .equals(((Globe) this).blockname)) {
				((Globe) this).mtyp[i] = 3;
				break;
			    }
			}
			try {
			    string
				= new StringBuilder().append("101|11|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).blockname).append
				      ("|").toString();
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    /* empty */
			}
			((Globe) this).blockname = "";
		    }
		    if (!((Globe) this).unblockname.equals("")) {
			for (int i = 0; i < ((Globe) this).nm; i++) {
			    if (((Globe) this).mname[i]
				    .equals(((Globe) this).unblockname)) {
				((Globe) this).mtyp[i] = 0;
				break;
			    }
			}
			try {
			    string
				= new StringBuilder().append("101|12|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).unblockname).append
				      ("|").toString();
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    /* empty */
			}
			((Globe) this).unblockname = "";
		    }
		    try {
			string
			    = new StringBuilder().append("101|13|").append
				  (((xtGraphics) ((Globe) this).xt).nickname)
				  .append
				  ("|").append
				  (((xtGraphics) ((Globe) this).xt).nickey)
				  .append
				  ("|").append
				  (((Globe) this).loadmsgs).append
				  ("|").toString();
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
			if (string_318_.startsWith("MSGS")) {
			    ((Globe) this).loadmsgs = getvalue(string_318_, 1);
			    DataInputStream datainputstream
				= new DataInputStream(((Globe) this).socket
							  .getInputStream());
			    byte[] is = new byte[((Globe) this).loadmsgs];
			    datainputstream.readFully(is);
			    string_318_ = ((Globe) this).din.readLine();
			    datainputstream = (new DataInputStream
					       (new ByteArrayInputStream(is)));
			    String string_327_ = "";
			    for (((Globe) this).nm = 0;
				 (((string_327_ = datainputstream.readLine())
				   != null)
				  && ((Globe) this).nm < 200);
				 ((Globe) this).nm++) {
				((Globe) this).mname[((Globe) this).nm]
				    = getSvalue(string_327_, 0);
				((Globe) this).mtyp[((Globe) this).nm]
				    = getvalue(string_327_, 1);
				((Globe) this).mconvo[((Globe) this).nm]
				    = getSvalue(string_327_, 2);
				((Globe) this).msub[((Globe) this).nm]
				    = getSvalue(string_327_, 3);
				((Globe) this).mctime[((Globe) this).nm]
				    = getLvalue(string_327_, 4);
				((Globe) this).mtime[((Globe) this).nm] = "";
			    }
			} else if (string_318_.equals("NOMSGS"))
			    ((Globe) this).loadmsgs = 0;
		    } catch (Exception exception) {
			((Globe) this).loadmsgs = -2;
		    }
		    if (((Globe) this).loadmsgs > 0) {
			for (int i = 0; i < ((Globe) this).nm; i++) {
			    if (((Globe) this).mctime[i] > 0L) {
				try {
				    long l = (((Globe) this).ntime
					      - ((Globe) this).mctime[i]);
				    String string_328_ = "Received";
				    if (((Globe) this).mtyp[i] == 2)
					string_328_ = "Sent";
				    if (l >= 1000L && l < 60000L)
					((Globe) this).mtime[i]
					    = new StringBuilder().append
						  ("").append
						  (string_328_).append
						  (" seconds ago").toString();
				    if (l >= 60000L && l < 3600000L) {
					int i_329_ = (int) (l / 60000L);
					String string_330_ = "s";
					if (i_329_ == 1)
					    string_330_ = "";
					((Globe) this).mtime[i]
					    = new StringBuilder().append
						  ("").append
						  (string_328_).append
						  (" ").append
						  (i_329_).append
						  (" minute").append
						  (string_330_).append
						  (" ago").toString();
				    }
				    if (l >= 3600000L && l < 86400000L) {
					int i_331_ = (int) (l / 3600000L);
					String string_332_ = "s";
					if (i_331_ == 1)
					    string_332_ = "";
					((Globe) this).mtime[i]
					    = new StringBuilder().append
						  ("").append
						  (string_328_).append
						  (" ").append
						  (i_331_).append
						  (" hour").append
						  (string_332_).append
						  (" ago").toString();
				    }
				    if (l >= 86400000L) {
					int i_333_ = (int) (l / 86400000L);
					String string_334_ = "s";
					if (i_333_ == 1)
					    string_334_ = "";
					((Globe) this).mtime[i]
					    = new StringBuilder().append
						  ("").append
						  (string_328_).append
						  (" ").append
						  (i_333_).append
						  (" day").append
						  (string_334_).append
						  (" ago").toString();
				    }
				} catch (Exception exception) {
				    ((Globe) this).mtime[i] = "";
				}
			    } else
				((Globe) this).mtime[i] = "";
			}
		    }
		    if (((Globe) this).openc != 0) {
			boolean bool = false;
			int i = -1;
			for (int i_335_ = 0; i_335_ < ((Globe) this).nm;
			     i_335_++) {
			    if (((Globe) this).mname[i_335_]
				    .equals(((Globe) this).opname)) {
				i = i_335_;
				break;
			    }
			}
			if (i != -1 && ((Globe) this).readmsg != 3
			    && ((Globe) this).readmsg != 4
			    && ((Globe) this).readmsg != 5) {
			    if (!((Globe) this).lastsub.equals
				 (new StringBuilder().append("").append
				      (((Globe) this).mctime[i]).toString())) {
				bool = true;
				((Globe) this).readmsg = 1;
			    } else
				((Globe) this).readmsg = 2;
			} else {
			    ((Globe) this).lastsub = "";
			    if (((Globe) this).readmsg == 1) {
				((Globe) this).readmsg = 0;
				((Globe) this).nml = 0;
			    }
			}
			if (bool) {
			    try {
				string = new StringBuilder().append
					     ("101|8|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickname)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickey)
					     .append
					     ("|").append
					     (((Globe) this).mconvo[i]).append
					     ("").toString();
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
				if (string_318_.startsWith("RECIVE")) {
				    for (int i_336_ = 0;
					 i_336_ < ((Globe) this).nml;
					 i_336_++) {
					((Globe) this).mline[i_336_] = null;
					((Globe) this).mlinetyp[i_336_] = 0;
					((Globe) this).mctimes[i_336_] = 0L;
					((Globe) this).mtimes[i_336_] = null;
				    }
				    ((Globe) this).nml = 0;
				    ((CarDefine) ((Globe) this).cd).acname
					= "";
				    ((CarDefine) ((Globe) this).cd).action = 0;
				    ((CarDefine) ((Globe) this).cd).onstage
					= "";
				    ((Globe) this).addstage = 0;
				    ((Globe) this).nclns = 0;
				    int i_337_ = getvalue(string_318_, 1);
				    DataInputStream datainputstream
					= (new DataInputStream
					   (((Globe) this).socket
						.getInputStream()));
				    byte[] is = new byte[i_337_];
				    datainputstream.readFully(is);
				    string_318_
					= ((Globe) this).din.readLine();
				    datainputstream
					= (new DataInputStream
					   (new ByteArrayInputStream(is)));
				    String string_338_ = "";
				    while ((string_338_
					    = datainputstream.readLine())
					   != null) {
					if (string_338_.startsWith("|")) {
					    if (((Globe) this).nml != 0) {
						((Globe) this).mline
						    [((Globe) this).nml]
						    = "";
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 167;
						((Globe) this).nml++;
					    }
					    String string_339_
						= getSvalue(string_338_, 1);
					    if (string_339_.toLowerCase()
						    .equals
						(((xtGraphics)
						  ((Globe) this).xt)
						     .nickname.toLowerCase()))
						string_339_ = "You";
					    ((Globe) this).mlinetyp
						[((Globe) this).nml]
						= getvalue(string_338_, 2);
					    int i_340_
						= (((Globe) this).mlinetyp
						   [((Globe) this).nml]);
					    if (i_340_ == 0) {
						((Globe) this).mline
						    [((Globe) this).nml]
						    = new StringBuilder()
							  .append
							  ("").append
							  (string_339_).append
							  (" wrote:")
							  .toString();
						((Globe) this).mctimes
						    [((Globe) this).nml]
						    = getLvalue(string_338_,
								3);
						((Globe) this).mtimes
						    [((Globe) this).nml]
						    = "";
						((Globe) this).nml++;
					    }
					    if (i_340_ == 1) {
						((Globe) this).mline
						    [((Globe) this).nml]
						    = new StringBuilder()
							  .append
							  ("").append
							  (string_339_).append
							  (" shared a car:")
							  .toString();
						((Globe) this).mctimes
						    [((Globe) this).nml]
						    = getLvalue(string_338_,
								3);
						((Globe) this).mtimes
						    [((Globe) this).nml]
						    = "";
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = getSvalue(string_338_,
								4);
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 10;
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = "";
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 167;
						((Globe) this).nml++;
					    }
					    if (i_340_ == 2) {
						((Globe) this).mline
						    [((Globe) this).nml]
						    = new StringBuilder()
							  .append
							  ("").append
							  (string_339_).append
							  (" shared a stage:")
							  .toString();
						((Globe) this).mctimes
						    [((Globe) this).nml]
						    = getLvalue(string_338_,
								3);
						((Globe) this).mtimes
						    [((Globe) this).nml]
						    = "";
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = getSvalue(string_338_,
								4);
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 20;
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = "";
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 167;
						((Globe) this).nml++;
					    }
					    if (i_340_ == 3) {
						if (string_339_.equals("You"))
						    ((Globe) this).mline
							[((Globe) this).nml]
							= new StringBuilder
							      ().append
							      ("You have invited ")
							      .append
							      (((Globe) this)
							       .mname[i])
							      .append
							      (" to join your clan:")
							      .toString();
						else
						    ((Globe) this).mline
							[((Globe) this).nml]
							= new StringBuilder
							      ().append
							      ("").append
							      (string_339_)
							      .append
							      (" has invited you to join clan:")
							      .toString();
						((Globe) this).mctimes
						    [((Globe) this).nml]
						    = getLvalue(string_338_,
								3);
						((Globe) this).mtimes
						    [((Globe) this).nml]
						    = "";
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = getSvalue(string_338_,
								4);
						if (((Globe) this).nclns
						    < 20) {
						    ((Globe) this).clanlo
							[((Globe) this).nclns]
							= (((Globe) this).mline
							   [(((Globe) this)
							     .nml)]);
						    ((Globe) this).nclns++;
						}
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 30;
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = "";
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = 167;
						((Globe) this).nml++;
						if (!string_339_
							 .equals("You")) {
						    if (((xtGraphics)
							 ((Globe) this).xt)
							    .clan.equals(""))
							((Globe) this)
							    .mline
							    [(((Globe) this)
							      .nml)]
							    = "(If you would like join this clan, visit that clan's page and click 'Request to Join..'.)";
						    else
							((Globe) this)
							    .mline
							    [(((Globe) this)
							      .nml)]
							    = new StringBuilder
								  ().append
								  ("(You will need to leave your clan ")
								  .append
								  (((xtGraphics)
								    ((Globe)
								     this).xt)
								   .clan)
								  .append
								  (" first before being able to join...)")
								  .toString();
						    ((Globe) this).mlinetyp
							[((Globe) this).nml]
							= -1;
						    ((Globe) this).nml++;
						}
					    }
					    if (i_340_ == 4) {
						if (string_339_.equals("You"))
						    ((Globe) this).mline
							[((Globe) this).nml]
							= "You have shared the following date:";
						else
						    ((Globe) this).mline
							[((Globe) this).nml]
							= new StringBuilder
							      ().append
							      ("").append
							      (string_339_)
							      .append
							      (" has shared the following date:")
							      .toString();
						((Globe) this).mctimes
						    [((Globe) this).nml]
						    = getLvalue(string_338_,
								3);
						((Globe) this).mtimes
						    [((Globe) this).nml]
						    = "";
						Calendar calendar
						    = Calendar.getInstance();
						long l
						    = (calendar
							   .getTimeInMillis()
						       - (((Globe) this).ntime
							  - (((Globe) this)
							     .mctimes
							     [(((Globe) this)
							       .nml)]))
						       + getLvalue(string_338_,
								   4));
						if (l > 0L)
						    calendar
							.setTimeInMillis(l);
						((Globe) this).nml++;
						Calendar calendar_341_
						    = calendar;
						if (calendar != null) {
						    /* empty */
						}
						int i_342_
						    = calendar_341_.get(11);
						String string_343_ = "AM";
						Calendar calendar_344_
						    = calendar;
						if (calendar != null) {
						    /* empty */
						}
						if (calendar_344_.get(12) > 30
						    && ++i_342_ == 24)
						    i_342_ -= 24;
						if (i_342_ >= 12)
						    string_343_ = "PM";
						if (i_342_ > 12)
						    i_342_ -= 12;
						if (i_342_ == 0)
						    i_342_ = 12;
						try {
						    String[] strings
							= ((Globe) this).mline;
						    int i_345_
							= ((Globe) this).nml;
						    StringBuilder stringbuilder
							= new StringBuilder
							      ().append("[  ");
						    String[] strings_346_
							= ((Globe) this).wday;
						    Calendar calendar_347_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    StringBuilder stringbuilder_348_
							= stringbuilder.append
							      (strings_346_
							       [(calendar_347_
								     .get(7)
								 - 1)])
							      .append("  -  ");
						    String[] strings_349_
							= ((Globe) this).month;
						    Calendar calendar_350_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    StringBuilder stringbuilder_351_
							= stringbuilder_348_
							      .append
							      (strings_349_
							       [calendar_350_
								    .get(2)])
							      .append(" ");
						    Calendar calendar_352_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    strings[i_345_]
							= stringbuilder_351_
							      .append
							      (calendar_352_
								   .get(5))
							      .append
							      (",  ").append
							      (i_342_).append
							      (" ").append
							      (string_343_)
							      .append
							      ("  ]")
							      .toString();
						} catch (Exception exception) {
						    ((Globe) this).mline
							[((Globe) this).nml]
							= "Error occurred while calculating this date.";
						}
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = -1;
						((Globe) this).nml++;
						((Globe) this).mline
						    [((Globe) this).nml]
						    = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
						((Globe) this).mlinetyp
						    [((Globe) this).nml]
						    = -1;
						((Globe) this).nml++;
					    }
					} else {
					    ((Globe) this).mline
						[((Globe) this).nml]
						= string_338_;
					    try {
						((Globe) this).rd.setFont
						    (new Font("Tahoma", 0,
							      11));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						int i_353_ = 0;
						String string_354_ = "";
						for (/**/;
						     (i_353_
						      < string_338_.length());
						     i_353_++) {
						    string_354_
							= new StringBuilder
							      ().append
							      (string_354_)
							      .append
							      (string_338_
								   .charAt
							       (i_353_))
							      .toString();
						    if ((((Globe) this).ftm
							     .stringWidth
							 (string_354_))
							> 540) {
							if ((string_354_
								 .lastIndexOf
							     (" "))
							    != -1) {
							    ((Globe) this)
								.mline
								[((Globe)
								  this).nml]
								= (string_354_
								       .substring
								   (0,
								    (string_354_
									 .lastIndexOf
								     (" "))));
							    string_354_
								= (string_354_
								       .substring
								   ((string_354_
									 .lastIndexOf
								     (" ")) + 1,
								    (string_354_
									 .length
								     ())));
							} else {
							    ((Globe) this)
								.mline
								[((Globe)
								  this).nml]
								= string_354_;
							    string_354_ = "";
							}
							((Globe) this)
							    .mlinetyp
							    [(((Globe) this)
							      .nml)]
							    = -1;
							((Globe) this).nml++;
						    }
						}
						((Globe) this).mline
						    [((Globe) this).nml]
						    = string_354_;
					    } catch (Exception exception) {
						/* empty */
					    }
					    ((Globe) this).mlinetyp
						[((Globe) this).nml]
						= -1;
					    ((Globe) this).nml++;
					}
				    }
				    ((Globe) this).readmsg = 2;
				    ((Globe) this).lastsub
					= new StringBuilder().append("").append
					      (((Globe) this).mctime[i])
					      .toString();
				    if (((Globe) this).mtyp[i] == 1) {
					((Globe) this).mtyp[i] = 0;
					try {
					    ((Globe) this).dout.println
						(new StringBuilder().append
						     ("101|10|").append
						     (((xtGraphics)
						       ((Globe) this).xt)
						      .nickname)
						     .append
						     ("|").append
						     (((Globe) this).opname)
						     .append
						     ("|").toString());
					    string_318_ = ((Globe) this)
							      .din.readLine();
					} catch (Exception exception) {
					    /* empty */
					}
				    }
				    ((Globe) this).spos4 = 208;
				} else
				    ((Globe) this).readmsg = 3;
			    } catch (Exception exception) {
				((Globe) this).readmsg = 4;
			    }
			}
			if (((Globe) this).readmsg == 2) {
			    for (int i_355_ = 0; i_355_ < ((Globe) this).nml;
				 i_355_++) {
				if ((((Globe) this).mlinetyp[i_355_] == 0
				     || ((Globe) this).mlinetyp[i_355_] == 1
				     || ((Globe) this).mlinetyp[i_355_] == 2
				     || ((Globe) this).mlinetyp[i_355_] == 3
				     || ((Globe) this).mlinetyp[i_355_] == 4)
				    && ((Globe) this).mctimes[i_355_] > 0L) {
				    try {
					long l = (((Globe) this).ntime
						  - (((Globe) this).mctimes
						     [i_355_]));
					if (l >= 1000L && l < 60000L)
					    ((Globe) this).mtimes[i_355_]
						= "seconds ago";
					if (l >= 60000L && l < 3600000L) {
					    int i_356_ = (int) (l / 60000L);
					    String string_357_ = "s";
					    if (i_356_ == 1)
						string_357_ = "";
					    ((Globe) this).mtimes[i_355_]
						= new StringBuilder().append
						      ("").append
						      (i_356_).append
						      (" minute").append
						      (string_357_).append
						      (" ago").toString();
					}
					if (l >= 3600000L && l < 86400000L) {
					    int i_358_ = (int) (l / 3600000L);
					    String string_359_ = "s";
					    if (i_358_ == 1)
						string_359_ = "";
					    ((Globe) this).mtimes[i_355_]
						= new StringBuilder().append
						      ("").append
						      (i_358_).append
						      (" hour").append
						      (string_359_).append
						      (" ago").toString();
					}
					if (l >= 86400000L) {
					    int i_360_ = (int) (l / 86400000L);
					    String string_361_ = "s";
					    if (i_360_ == 1)
						string_361_ = "";
					    ((Globe) this).mtimes[i_355_]
						= new StringBuilder().append
						      ("").append
						      (i_360_).append
						      (" day").append
						      (string_361_).append
						      (" ago").toString();
					}
				    } catch (Exception exception) {
					((Globe) this).mtimes[i_355_] = "";
				    }
				} else
				    ((Globe) this).mtimes[i_355_] = "";
			    }
			}
		    }
		    if (((Globe) this).sendmsg == 2) {
			((GameSparker) ((Globe) this).gs).mmsg.setText(" ");
			((Globe) this).sendmsg = 0;
		    }
		    if (((Globe) this).openc == 10) {
			if (((Globe) this).loaditem == 1) {
			    int i = 0;
			    String[] strings = new String[700];
			    try {
				URL url
				    = (new URL
				       (new StringBuilder().append
					    ("http://multiplayer.needformadness.com/cars/lists/")
					    .append
					    (((GameSparker) ((Globe) this).gs)
						 .tnick.getText())
					    .append
					    (".txt?reqlo=").append
					    ((int) (Math.random() * 1000.0))
					    .append
					    ("").toString()));
				url.openConnection().setConnectTimeout(2000);
				String string_362_ = "";
				DataInputStream datainputstream
				    = new DataInputStream(url.openStream());
				while ((string_362_
					= datainputstream.readLine())
				       != null) {
				    string_362_
					= new StringBuilder().append("").append
					      (string_362_.trim()).toString();
				    if (string_362_.startsWith("mycars")) {
					boolean bool = true;
					while (bool && i < 700) {
					    strings[i]
						= getfuncSvalue("mycars",
								string_362_,
								i);
					    if (strings[i].equals(""))
						bool = false;
					    else
						i++;
					}
				    }
				}
				datainputstream.close();
			    } catch (Exception exception) {
				String string_363_
				    = new StringBuilder().append("").append
					  (exception).toString();
				if (string_363_.indexOf("FileNotFound") != -1)
				    i = 0;
				else
				    i = -1;
			    }
			    if (i == -1) {
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd,
				     "Failed to load your cars, please try again later.");
				((Globe) this).loaditem = 0;
			    }
			    if (i == 0) {
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd,
				     "You have no added or published cars to load.");
				((Globe) this).loaditem = 0;
			    }
			    if (i > 0) {
				String[] strings_364_ = new String[700];
				int i_365_ = 0;
				for (int i_366_ = 0; i_366_ < i; i_366_++) {
				    ((GameSparker) ((Globe) this).gs)
					.senditem.removeAll();
				    ((GameSparker) ((Globe) this).gs)
					.senditem.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     ("Loading shareable cars,  ")
					     .append
					     ((int) ((float) i_366_ / (float) i
						     * 100.0F))
					     .append
					     (" %").toString());
				    try {
					String string_367_
					    = new StringBuilder().append
						  ("http://multiplayer.needformadness.com/cars/")
						  .append
						  (strings[i_366_]).append
						  (".txt?reqlo=").append
						  ((int) (Math.random()
							  * 1000.0))
						  .append
						  ("").toString();
					string_367_
					    = string_367_.replace(' ', '_');
					URL url = new URL(string_367_);
					url.openConnection()
					    .setConnectTimeout(2000);
					String string_368_ = "";
					DataInputStream datainputstream
					    = (new DataInputStream
					       (url.openStream()));
					while ((string_368_
						= datainputstream.readLine())
					       != null) {
					    string_368_
						= new StringBuilder().append
						      ("").append
						      (string_368_.trim())
						      .toString();
					    if (string_368_
						    .startsWith("details")) {
						String string_369_
						    = (getfuncSvalue
						       ("details", string_368_,
							0));
						int i_370_
						    = getfuncvalue("details",
								   string_368_,
								   1);
						if (i_370_ > 0
						    || (string_369_.toLowerCase
							    ().equals
							(((GameSparker)
							  ((Globe) this).gs)
							     .tnick.getText
							     ().toLowerCase
							 ()))) {
						    strings_364_[i_365_]
							= strings[i_366_];
						    i_365_++;
						}
					    }
					}
					datainputstream.close();
				    } catch (Exception exception) {
					/* empty */
				    }
				}
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				if (i_365_ > 0) {
				    for (int i_371_ = 0; i_371_ < i_365_;
					 i_371_++)
					((GameSparker) ((Globe) this).gs)
					    .senditem.add
					    (((Globe) this).rd,
					     strings_364_[i_371_]);
				    ((Globe) this).loaditem = 10;
				} else {
				    ((GameSparker) ((Globe) this).gs)
					.senditem.add
					(((Globe) this).rd,
					 "You have no cars that can be shared.");
				    ((Globe) this).loaditem = 0;
				}
			    }
			}
			if (((Globe) this).loaditem == 2) {
			    int i = 0;
			    String[] strings = new String[700];
			    try {
				URL url
				    = (new URL
				       (new StringBuilder().append
					    ("http://multiplayer.needformadness.com/tracks/lists/")
					    .append
					    (((GameSparker) ((Globe) this).gs)
						 .tnick.getText())
					    .append
					    (".txt?reqlo=").append
					    ((int) (Math.random() * 1000.0))
					    .append
					    ("").toString()));
				url.openConnection().setConnectTimeout(2000);
				String string_372_ = "";
				DataInputStream datainputstream
				    = new DataInputStream(url.openStream());
				while ((string_372_
					= datainputstream.readLine())
				       != null) {
				    string_372_
					= new StringBuilder().append("").append
					      (string_372_.trim()).toString();
				    if (string_372_.startsWith("mystages")) {
					boolean bool = true;
					while (bool && i < 700) {
					    strings[i]
						= getfuncSvalue("mystages",
								string_372_,
								i);
					    if (strings[i].equals(""))
						bool = false;
					    else
						i++;
					}
				    }
				}
				datainputstream.close();
			    } catch (Exception exception) {
				String string_373_
				    = new StringBuilder().append("").append
					  (exception).toString();
				if (string_373_.indexOf("FileNotFound") != -1)
				    i = 0;
				else
				    i = -1;
			    }
			    if (i == -1) {
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd,
				     "Failed to load your stages, please try again later.");
				((Globe) this).loaditem = 0;
			    }
			    if (i == 0) {
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				((GameSparker) ((Globe) this).gs).senditem.add
				    (((Globe) this).rd,
				     "You have no added or published stages to load.");
				((Globe) this).loaditem = 0;
			    }
			    if (i > 0) {
				String[] strings_374_ = new String[700];
				int i_375_ = 0;
				for (int i_376_ = 0; i_376_ < i; i_376_++) {
				    ((GameSparker) ((Globe) this).gs)
					.senditem.removeAll();
				    ((GameSparker) ((Globe) this).gs)
					.senditem.add
					(((Globe) this).rd,
					 new StringBuilder().append
					     ("Loading shareable stages,  ")
					     .append
					     ((int) ((float) i_376_ / (float) i
						     * 100.0F))
					     .append
					     (" %").toString());
				    try {
					String string_377_
					    = new StringBuilder().append
						  ("http://multiplayer.needformadness.com/tracks/")
						  .append
						  (strings[i_376_]).append
						  (".txt?reqlo=").append
						  ((int) (Math.random()
							  * 1000.0))
						  .append
						  ("").toString();
					string_377_
					    = string_377_.replace(' ', '_');
					URL url = new URL(string_377_);
					url.openConnection()
					    .setConnectTimeout(2000);
					String string_378_ = "";
					DataInputStream datainputstream
					    = (new DataInputStream
					       (url.openStream()));
					while ((string_378_
						= datainputstream.readLine())
					       != null) {
					    string_378_
						= new StringBuilder().append
						      ("").append
						      (string_378_.trim())
						      .toString();
					    if (string_378_
						    .startsWith("details")) {
						String string_379_
						    = (getfuncSvalue
						       ("details", string_378_,
							0));
						int i_380_
						    = getfuncvalue("details",
								   string_378_,
								   1);
						if (i_380_ > 0
						    || (string_379_.toLowerCase
							    ().equals
							(((GameSparker)
							  ((Globe) this).gs)
							     .tnick.getText
							     ().toLowerCase
							 ()))) {
						    strings_374_[i_375_]
							= strings[i_376_];
						    i_375_++;
						}
					    }
					}
					datainputstream.close();
				    } catch (Exception exception) {
					/* empty */
				    }
				}
				((GameSparker) ((Globe) this).gs).senditem
				    .removeAll();
				if (i_375_ > 0) {
				    for (int i_381_ = 0; i_381_ < i_375_;
					 i_381_++)
					((GameSparker) ((Globe) this).gs)
					    .senditem.add
					    (((Globe) this).rd,
					     strings_374_[i_381_]);
				    ((Globe) this).loaditem = 20;
				} else {
				    ((GameSparker) ((Globe) this).gs)
					.senditem.add
					(((Globe) this).rd,
					 "You have no stages that can be shared.");
				    ((Globe) this).loaditem = 0;
				}
			    }
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 3
			    && !((xtGraphics) ((Globe) this).xt).clan
				    .equals(""))
			    clanlogopng(((xtGraphics) ((Globe) this).xt).clan);
			if (((Globe) this).sendmsg == 1) {
			    try {
				String string_382_ = "#nada#";
				for (int i = 0; i < ((Globe) this).nm; i++) {
				    if (((Globe) this).mname[i]
					    .equals(((Globe) this).opname)) {
					string_382_ = ((Globe) this).mconvo[i];
					break;
				    }
				}
				string = new StringBuilder().append
					     ("101|9|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickname)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickey)
					     .append
					     ("|").append
					     (((Globe) this).opname).append
					     ("|").append
					     (string_382_).append
					     ("|").append
					     (((GameSparker) ((Globe) this).gs)
						  .sendtyp.getSelectedIndex())
					     .append
					     ("|").toString();
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 0) {
				    String string_383_
					= ((GameSparker) ((Globe) this).gs)
					      .mmsg.getText
					      ().replace("|", ":");
				    string_383_
					= string_383_.replaceAll("[\\t\\n\\r]",
								 "|");
				    String string_384_ = "";
				    int i = 0;
				    int i_385_ = 0;
				    for (/**/; i < string_383_.length(); i++) {
					String string_386_
					    = new StringBuilder().append
						  ("").append
						  (string_383_.charAt(i))
						  .toString();
					if (string_386_.equals("|"))
					    i_385_++;
					else
					    i_385_ = 0;
					if (i_385_ <= 1)
					    string_384_
						= new StringBuilder().append
						      (string_384_).append
						      (string_386_).toString();
				    }
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (string_384_).append
						 ("||").toString();
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex() == 1
				    || ((GameSparker) ((Globe) this).gs)
					   .sendtyp.getSelectedIndex() == 2)
				    string
					= new StringBuilder().append
					      (string).append
					      ("").append
					      (((GameSparker)
						((Globe) this).gs)
						   .senditem.getSelectedItem())
					      .append
					      ("|").toString();
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 3)
				    string
					= new StringBuilder().append
					      (string).append
					      ("").append
					      (((xtGraphics) ((Globe) this).xt)
					       .clan)
					      .append
					      ("|").toString();
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 4) {
				    Calendar calendar = Calendar.getInstance();
				    long l = calendar.getTimeInMillis();
				    Calendar calendar_387_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    calendar_387_.roll
					(5, ((GameSparker) ((Globe) this).gs)
						.senditem.getSelectedIndex());
				    int i = (((GameSparker) ((Globe) this).gs)
						 .datat.getSelectedIndex()
					     + 12);
				    if (i >= 24)
					i -= 24;
				    Calendar calendar_388_ = calendar;
				    Calendar calendar_389_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    int i_390_ = calendar_389_.get(1);
				    Calendar calendar_391_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    int i_392_ = calendar_391_.get(2);
				    Calendar calendar_393_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    calendar_388_.set(i_390_, i_392_,
						      calendar_393_.get(5), i,
						      0);
				    l = calendar.getTimeInMillis() - l;
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (l).append
						 ("|").toString();
				}
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
				if (string_318_.equals("OK"))
				    ((Globe) this).sendmsg = 2;
				else {
				    ((Globe) this).readmsg = 5;
				    ((Globe) this).sendmsg = 0;
				}
			    } catch (Exception exception) {
				((Globe) this).readmsg = 5;
				((Globe) this).sendmsg = 0;
			    }
			}
		    }
		}
		if (((Globe) this).itab == 1
		    && !((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		    try {
			string = new StringBuilder().append("101|38|").append
				     (((xtGraphics) ((Globe) this).xt).clan)
				     .append
				     ("|").append
				     (((xtGraphics) ((Globe) this).xt).clankey)
				     .append
				     ("|").append
				     (((Globe) this).loadinter).append
				     ("|").toString();
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
			if (string_318_.startsWith("INTER")) {
			    ((Globe) this).loadinter
				= getvalue(string_318_, 1);
			    DataInputStream datainputstream
				= new DataInputStream(((Globe) this).socket
							  .getInputStream());
			    byte[] is = new byte[((Globe) this).loadinter];
			    datainputstream.readFully(is);
			    string_318_ = ((Globe) this).din.readLine();
			    datainputstream = (new DataInputStream
					       (new ByteArrayInputStream(is)));
			    String string_394_ = "";
			    for (((Globe) this).ni = 0;
				 (((string_394_ = datainputstream.readLine())
				   != null)
				  && ((Globe) this).ni < 200);
				 ((Globe) this).ni++) {
				((Globe) this).iclan[((Globe) this).ni]
				    = getSvalue(string_394_, 0);
				((Globe) this).icheck[((Globe) this).ni]
				    = getSvalue(string_394_, 1);
				((Globe) this).iconvo[((Globe) this).ni]
				    = getSvalue(string_394_, 2);
				((Globe) this).isub[((Globe) this).ni]
				    = getSvalue(string_394_, 3);
				((Globe) this).ictime[((Globe) this).ni]
				    = getLvalue(string_394_, 4);
				((Globe) this).itime[((Globe) this).ni] = "";
				((Globe) this).istat[((Globe) this).ni]
				    = getSvalue(string_394_, 5);
				if (((Globe) this).istat[((Globe) this).ni]
					.equals("War"))
				    ((Globe) this).iwarn[((Globe) this).ni]
					= getSvalue(string_394_, 6);
				if (((Globe) this).istat[((Globe) this).ni]
					.equals("Car Battle")
				    || ((Globe) this).istat
					   [((Globe) this).ni]
					   .equals("Stage Battle")) {
				    ((Globe) this).iwarn[((Globe) this).ni]
					= getSvalue(string_394_, 6);
				    ((Globe) this).itcar[((Globe) this).ni]
					= getSvalue(string_394_, 7);
				    ((Globe) this).igcar[((Globe) this).ni]
					= getSvalue(string_394_, 8);
				}
			    }
			} else if (string_318_.equals("NOINTER"))
			    ((Globe) this).loadinter = 0;
		    } catch (Exception exception) {
			((Globe) this).loadmsgs = -2;
		    }
		    if (((Globe) this).loadinter > 0) {
			for (int i = 0; i < ((Globe) this).ni; i++) {
			    if (((Globe) this).ictime[i] > 0L) {
				try {
				    long l = (((Globe) this).ntime
					      - ((Globe) this).ictime[i]);
				    if (l >= 1000L && l < 60000L)
					((Globe) this).itime[i]
					    = "Seconds ago";
				    if (l >= 60000L && l < 3600000L) {
					int i_395_ = (int) (l / 60000L);
					String string_396_ = "s";
					if (i_395_ == 1)
					    string_396_ = "";
					((Globe) this).itime[i]
					    = new StringBuilder().append
						  ("").append
						  (i_395_).append
						  (" minute").append
						  (string_396_).append
						  (" ago").toString();
				    }
				    if (l >= 3600000L && l < 86400000L) {
					int i_397_ = (int) (l / 3600000L);
					String string_398_ = "s";
					if (i_397_ == 1)
					    string_398_ = "";
					((Globe) this).itime[i]
					    = new StringBuilder().append
						  ("").append
						  (i_397_).append
						  (" hour").append
						  (string_398_).append
						  (" ago").toString();
				    }
				    if (l >= 86400000L) {
					int i_399_ = (int) (l / 86400000L);
					String string_400_ = "s";
					if (i_399_ == 1)
					    string_400_ = "";
					((Globe) this).itime[i]
					    = new StringBuilder().append
						  ("").append
						  (i_399_).append
						  (" day").append
						  (string_400_).append
						  (" ago").toString();
				    }
				} catch (Exception exception) {
				    ((Globe) this).itime[i] = "";
				}
			    } else
				((Globe) this).itime[i] = "";
			}
		    }
		    if (((Globe) this).loadwstat == 0)
			loadchamps();
		    if (((Globe) this).openi != 0) {
			boolean bool = false;
			int i = -1;
			for (int i_401_ = 0; i_401_ < ((Globe) this).ni;
			     i_401_++) {
			    if (((Globe) this).iclan[i_401_]
				    .equals(((Globe) this).intclan)) {
				i = i_401_;
				break;
			    }
			}
			if (((Globe) this).readint == 6) {
			    try {
				if (((Globe) this).connector != null) {
				    /* empty */
				}
				Thread.sleep(2000L);
			    } catch (InterruptedException interruptedexception) {
				/* empty */
			    }
			}
			if (i != -1 && ((Globe) this).readint != 3
			    && ((Globe) this).readint != 4
			    && ((Globe) this).readint != 5) {
			    if (!((Globe) this).lastint.equals
				 (new StringBuilder().append("").append
				      (((Globe) this).ictime[i]).toString())) {
				bool = true;
				((Globe) this).readint = 1;
			    } else
				((Globe) this).readint = 2;
			} else {
			    ((Globe) this).lastint = "";
			    if (((Globe) this).readint == 1) {
				((Globe) this).readint = 0;
				((Globe) this).nil = 0;
			    }
			}
			if (bool && ((Globe) this).sendint != 1) {
			    try {
				string = new StringBuilder().append
					     ("101|40|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .clan)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .clankey)
					     .append
					     ("|").append
					     (((Globe) this).iconvo[i]).append
					     ("|").toString();
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
				if (string_318_.startsWith("RECIVE")) {
				    if (((Globe) this).istat[i]
					    .equals("Car Battle")) {
					((Globe) this).dispi = 1;
					((Globe) this).dwarn
					    = ((Globe) this).iwarn[i];
					((Globe) this).dtcar
					    = ((Globe) this).itcar[i];
					((Globe) this).dgcar
					    = ((Globe) this).igcar[i];
				    }
				    if (((Globe) this).istat[i]
					    .equals("Stage Battle")) {
					((Globe) this).dispi = 2;
					((Globe) this).dwarn
					    = ((Globe) this).iwarn[i];
					((Globe) this).dtcar
					    = ((Globe) this).itcar[i];
					((Globe) this).dgcar
					    = ((Globe) this).igcar[i];
				    }
				    if (((Globe) this).istat[i]
					    .equals("War")) {
					((Globe) this).dispi = 3;
					((Globe) this).dwarn
					    = ((Globe) this).iwarn[i];
				    }
				    int i_402_ = 0;
				    String[] strings = new String[1000];
				    int[] is = new int[1000];
				    long[] ls = new long[1000];
				    String[] strings_403_ = new String[1000];
				    if (((Globe) this).dispi != 0) {
					strings[i_402_] = "";
					is[i_402_] = 167;
					i_402_++;
					strings[i_402_] = "";
					is[i_402_] = 167;
					i_402_++;
				    }
				    int i_404_ = getvalue(string_318_, 1);
				    DataInputStream datainputstream
					= (new DataInputStream
					   (((Globe) this).socket
						.getInputStream()));
				    byte[] is_405_ = new byte[i_404_];
				    datainputstream.readFully(is_405_);
				    string_318_
					= ((Globe) this).din.readLine();
				    datainputstream
					= (new DataInputStream
					   (new ByteArrayInputStream
					    (is_405_)));
				    String string_406_ = "";
				    while ((string_406_
					    = datainputstream.readLine())
					   != null) {
					if (string_406_.startsWith("|")) {
					    if (i_402_ != 0) {
						strings[i_402_] = "";
						is[i_402_] = 167;
						i_402_++;
					    }
					    String string_407_
						= getSvalue(string_406_, 1);
					    if (string_407_.toLowerCase()
						    .equals
						(((xtGraphics)
						  ((Globe) this).xt)
						     .nickname.toLowerCase()))
						string_407_ = "You";
					    is[i_402_]
						= getvalue(string_406_, 2);
					    int i_408_ = is[i_402_];
					    if (i_408_ == 0) {
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("").append
							  (string_407_).append
							  (" wrote:")
							  .toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						i_402_++;
					    }
					    if (i_408_ == 1) {
						if (string_407_.equals("You"))
						    strings[i_402_]
							= "You have shared the following date:";
						else
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (string_407_)
							      .append
							      (" has shared the following date:")
							      .toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						Calendar calendar
						    = Calendar.getInstance();
						long l
						    = (calendar
							   .getTimeInMillis()
						       - (((Globe) this).ntime
							  - ls[i_402_])
						       + getLvalue(string_406_,
								   4));
						if (l > 0L)
						    calendar
							.setTimeInMillis(l);
						i_402_++;
						Calendar calendar_409_
						    = calendar;
						if (calendar != null) {
						    /* empty */
						}
						int i_410_
						    = calendar_409_.get(11);
						String string_411_ = "AM";
						Calendar calendar_412_
						    = calendar;
						if (calendar != null) {
						    /* empty */
						}
						if (calendar_412_.get(12) > 30
						    && ++i_410_ == 24)
						    i_410_ -= 24;
						if (i_410_ >= 12)
						    string_411_ = "PM";
						if (i_410_ > 12)
						    i_410_ -= 12;
						if (i_410_ == 0)
						    i_410_ = 12;
						try {
						    String[] strings_413_
							= strings;
						    int i_414_ = i_402_;
						    StringBuilder stringbuilder
							= new StringBuilder
							      ().append("[  ");
						    String[] strings_415_
							= ((Globe) this).wday;
						    Calendar calendar_416_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    StringBuilder stringbuilder_417_
							= stringbuilder.append
							      (strings_415_
							       [(calendar_416_
								     .get(7)
								 - 1)])
							      .append("  -  ");
						    String[] strings_418_
							= ((Globe) this).month;
						    Calendar calendar_419_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    StringBuilder stringbuilder_420_
							= stringbuilder_417_
							      .append
							      (strings_418_
							       [calendar_419_
								    .get(2)])
							      .append(" ");
						    Calendar calendar_421_
							= calendar;
						    if (calendar != null) {
							/* empty */
						    }
						    strings_413_[i_414_]
							= stringbuilder_420_
							      .append
							      (calendar_421_
								   .get(5))
							      .append
							      (",  ").append
							      (i_410_).append
							      (" ").append
							      (string_411_)
							      .append
							      ("  ]")
							      .toString();
						} catch (Exception exception) {
						    strings[i_402_]
							= "Error occurred while calculating this date.";
						}
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
						is[i_402_] = -1;
						i_402_++;
					    }
					    if (i_408_ == 4) {
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan
							 .toLowerCase())) {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has declared war on ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (":").toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("I|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").toString();
						    is[i_402_] = 40;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    if ((((Globe) this)
							 .loadwstat) == 1
							&& !(string_406_
								 .endsWith
							     ("|out|"))) {
							int i_422_ = -1;
							int i_423_ = 0;
							int i_424_ = -1;
							int i_425_ = 0;
							for (int i_426_ = 0;
							     (i_426_
							      < (((Globe) this)
								 .ncc));
							     i_426_++) {
							    if (((xtGraphics)
								 ((Globe)
								  this).xt)
								    .clan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .conclan
								     [i_426_]
								     .toLowerCase
								 ())) {
								i_423_
								    = (((Globe)
									this)
								       .totp
								       [i_426_]);
								i_422_
								    = i_426_;
							    }
							    if (((Globe) this)
								    .intclan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .conclan
								     [i_426_]
								     .toLowerCase
								 ())) {
								i_425_
								    = (((Globe)
									this)
								       .totp
								       [i_426_]);
								i_424_
								    = i_426_;
							    }
							}
							int i_427_
							    = i_425_ + 1;
							int i_428_
							    = i_423_ + 1;
							if (i_428_ > i_425_)
							    i_428_ = i_425_;
							if (i_422_ != -1) {
							    for (int i_429_
								     = 0;
								 (i_429_
								  < (((Globe)
								      this)
								     .nvc
								     [i_422_]));
								 i_429_++) {
								if (((Globe)
								     this)
									.intclan
									.toLowerCase
									()
									.equals
								    (((Globe)
								      this)
									 .verclan
									 [i_422_]
									 [i_429_]
									 .toLowerCase
								     ())) {
								    i_427_
									-= (((Globe)
									     this)
									    .points
									    [i_422_]
									    [i_429_]);
								    if (i_427_
									< 0)
									i_427_
									    = 0;
								    break;
								}
							    }
							}
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("If you win this war, your clan would get:  [ ")
								  .append
								  (i_427_)
								  .append
								  (" points ]   &  ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" would lose:  [ ")
								  .append
								  (i_428_)
								  .append
								  (" points ]")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
							i_427_ = i_423_ + 1;
							i_428_ = i_425_ + 1;
							if (i_428_ > i_423_)
							    i_428_ = i_423_;
							if (i_424_ != -1) {
							    for (int i_430_
								     = 0;
								 (i_430_
								  < (((Globe)
								      this)
								     .nvc
								     [i_424_]));
								 i_430_++) {
								if (((xtGraphics)
								     ((Globe)
								      this).xt)
									.clan
									.toLowerCase
									()
									.equals
								    (((Globe)
								      this)
									 .verclan
									 [i_424_]
									 [i_430_]
									 .toLowerCase
								     ())) {
								    i_427_
									-= (((Globe)
									     this)
									    .points
									    [i_424_]
									    [i_430_]);
								    if (i_427_
									< 0)
									i_427_
									    = 0;
								    break;
								}
							    }
							}
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("If you lose this war, your clan would lose:  [ ")
								  .append
								  (i_428_)
								  .append
								  (" points ]   &  ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" would get:  [ ")
								  .append
								  (i_427_)
								  .append
								  (" points ]")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
						    }
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("(Waiting for ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" to accept this war declaration and create 5 more games.)")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
						    }
						} else {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" has declaring war on your clan:")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Y|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").toString();
						    is[i_402_] = 40;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    if ((((Globe) this)
							 .loadwstat) == 1
							&& !(string_406_
								 .endsWith
							     ("|out|"))) {
							int i_431_ = -1;
							int i_432_ = 0;
							int i_433_ = -1;
							int i_434_ = 0;
							for (int i_435_ = 0;
							     (i_435_
							      < (((Globe) this)
								 .ncc));
							     i_435_++) {
							    if (((xtGraphics)
								 ((Globe)
								  this).xt)
								    .clan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .conclan
								     [i_435_]
								     .toLowerCase
								 ())) {
								i_432_
								    = (((Globe)
									this)
								       .totp
								       [i_435_]);
								i_431_
								    = i_435_;
							    }
							    if (((Globe) this)
								    .intclan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .conclan
								     [i_435_]
								     .toLowerCase
								 ())) {
								i_434_
								    = (((Globe)
									this)
								       .totp
								       [i_435_]);
								i_433_
								    = i_435_;
							    }
							}
							int i_436_
							    = i_434_ + 1;
							int i_437_
							    = i_432_ + 1;
							if (i_437_ > i_434_)
							    i_437_ = i_434_;
							if (i_431_ != -1) {
							    for (int i_438_
								     = 0;
								 (i_438_
								  < (((Globe)
								      this)
								     .nvc
								     [i_431_]));
								 i_438_++) {
								if (((Globe)
								     this)
									.intclan
									.toLowerCase
									()
									.equals
								    (((Globe)
								      this)
									 .verclan
									 [i_431_]
									 [i_438_]
									 .toLowerCase
								     ())) {
								    i_436_
									-= (((Globe)
									     this)
									    .points
									    [i_431_]
									    [i_438_]);
								    if (i_436_
									< 0)
									i_436_
									    = 0;
								    break;
								}
							    }
							}
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("If you win this war, your clan would get:  [ ")
								  .append
								  (i_436_)
								  .append
								  (" points ]   &  ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" would lose:  [ ")
								  .append
								  (i_437_)
								  .append
								  (" points ]")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
							i_436_ = i_432_ + 1;
							i_437_ = i_434_ + 1;
							if (i_437_ > i_432_)
							    i_437_ = i_432_;
							if (i_433_ != -1) {
							    for (int i_439_
								     = 0;
								 (i_439_
								  < (((Globe)
								      this)
								     .nvc
								     [i_433_]));
								 i_439_++) {
								if (((xtGraphics)
								     ((Globe)
								      this).xt)
									.clan
									.toLowerCase
									()
									.equals
								    (((Globe)
								      this)
									 .verclan
									 [i_433_]
									 [i_439_]
									 .toLowerCase
								     ())) {
								    i_436_
									-= (((Globe)
									     this)
									    .points
									    [i_433_]
									    [i_439_]);
								    if (i_436_
									< 0)
									i_436_
									    = 0;
								    break;
								}
							    }
							}
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("If you lose this war, your clan would lose:  [ ")
								  .append
								  (i_437_)
								  .append
								  (" points ]   &  ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" would get:  [ ")
								  .append
								  (i_436_)
								  .append
								  (" points ]")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
						    }
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = "(You accept this war declaration by creating 5 more games to be added to it.)";
							is[i_402_] = -1;
							i_402_++;
						    }
						}
					    }
					    if (i_408_ == 3) {
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan
							 .toLowerCase())) {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has challenged ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" to a car battle:")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("I|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								7))
							      .append
							      ("|").toString();
						    is[i_402_] = 30;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you win you will take ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you lose you will give ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" your clan's car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("(Waiting for ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" to accept this car battle and create 3 more games.)")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
						    }
						} else {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" has challenged your clan to a car battle:")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Y|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								7))
							      .append
							      ("|").toString();
						    is[i_402_] = 30;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you win you will take ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you lose you will give ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" your clan's car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = "(You accept this car battle by creating 3 more games to be added to it.)";
							is[i_402_] = -1;
							i_402_++;
						    }
						}
					    }
					    if (i_408_ == 2) {
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan
							 .toLowerCase())) {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has challenged ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" to a stage battle:")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("I|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								7))
							      .append
							      ("|").toString();
						    is[i_402_] = 20;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    String string_440_
							= (getSvalue
							   (string_406_, 4));
						    if (string_440_.length()
							> 20)
							string_440_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_440_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you win you will take ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s stage :  [ ")
							      .append
							      (string_440_)
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_440_
							= (getSvalue
							   (string_406_, 5));
						    if (string_440_.length()
							> 20)
							string_440_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_440_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you lose you will give ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" your clan's stage :  [ ")
							      .append
							      (string_440_)
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = new StringBuilder
								  ().append
								  ("(Waiting for ")
								  .append
								  (((Globe)
								    this)
								   .intclan)
								  .append
								  (" to accept this stage battle and create 3 more games.)")
								  .toString();
							is[i_402_] = -1;
							i_402_++;
						    }
						} else {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" has challenged your clan to a stage battle:")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Y|").append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								4))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      ("|").append
							      (getSvalue
							       (string_406_,
								7))
							      .append
							      ("|").toString();
						    is[i_402_] = 20;
						    i_402_++;
						    strings[i_402_] = "";
						    is[i_402_] = 167;
						    i_402_++;
						    String string_441_
							= (getSvalue
							   (string_406_, 5));
						    if (string_441_.length()
							> 20)
							string_441_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_441_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you win you will take ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s stage :  [ ")
							      .append
							      (string_441_)
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_441_
							= (getSvalue
							   (string_406_, 4));
						    if (string_441_.length()
							> 20)
							string_441_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_441_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you lose you will give ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" your clan's stage :  [ ")
							      .append
							      (string_441_)
							      .append
							      (" ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    if (!string_406_.endsWith
							 ("|out|")) {
							strings[i_402_]
							    = "(You accept this stage battle by creating 3 more games to be added to it.)";
							is[i_402_] = -1;
							i_402_++;
						    }
						}
					    }
					    if (i_408_ == 5) {
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("A stage battle has now started between your clan and ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" !").toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						i_402_++;
						strings[i_402_]
						    = "(See the bar at the top of the page for more details.)";
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("Arrange to meet ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" at a chosen room in a server on a specific date to play the battle.")
							  .toString();
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
						is[i_402_] = -1;
						i_402_++;
					    }
					    if (i_408_ == 6) {
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("A car battle has now started between your clan and ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" !").toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						i_402_++;
						strings[i_402_]
						    = "(See the bar at the top of the page for more details.)";
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("Arrange to meet ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" at a chosen room in a server on a specific date to play the battle.")
							  .toString();
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
						is[i_402_] = -1;
						i_402_++;
					    }
					    if (i_408_ == 7) {
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("A war has now started between your clan and ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" !").toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						i_402_++;
						if (((Globe) this).loadwstat
						    == 1) {
						    int i_442_ = -1;
						    int i_443_ = 0;
						    int i_444_ = -1;
						    int i_445_ = 0;
						    for (int i_446_ = 0;
							 (i_446_
							  < (((Globe) this)
							     .ncc));
							 i_446_++) {
							if (((xtGraphics)
							     ((Globe) this).xt)
								.clan
								.toLowerCase
								().equals
							    (((Globe) this)
								 .conclan
								 [i_446_]
								 .toLowerCase
							     ())) {
							    i_443_
								= (((Globe)
								    this)
								   .totp
								   [i_446_]);
							    i_442_ = i_446_;
							}
							if (((Globe) this)
								.intclan
								.toLowerCase
								().equals
							    (((Globe) this)
								 .conclan
								 [i_446_]
								 .toLowerCase
							     ())) {
							    i_445_
								= (((Globe)
								    this)
								   .totp
								   [i_446_]);
							    i_444_ = i_446_;
							}
						    }
						    int i_447_ = i_445_ + 1;
						    int i_448_ = i_443_ + 1;
						    if (i_448_ > i_445_)
							i_448_ = i_445_;
						    if (i_442_ != -1) {
							for (int i_449_ = 0;
							     (i_449_
							      < (((Globe) this)
								 .nvc
								 [i_442_]));
							     i_449_++) {
							    if (((Globe) this)
								    .intclan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .verclan
								     [i_442_]
								     [i_449_]
								     .toLowerCase
								 ())) {
								i_447_
								    -= (((Globe)
									 this)
									.points
									[i_442_]
									[i_449_]);
								if (i_447_ < 0)
								    i_447_ = 0;
								break;
							    }
							}
						    }
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you win this war, your clan would get:  [ ")
							      .append
							      (i_447_).append
							      (" points ]   &  ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" would lose:  [ ")
							      .append
							      (i_448_).append
							      (" points ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    i_447_ = i_443_ + 1;
						    i_448_ = i_445_ + 1;
						    if (i_448_ > i_443_)
							i_448_ = i_443_;
						    if (i_444_ != -1) {
							for (int i_450_ = 0;
							     (i_450_
							      < (((Globe) this)
								 .nvc
								 [i_444_]));
							     i_450_++) {
							    if (((xtGraphics)
								 ((Globe)
								  this).xt)
								    .clan
								    .toLowerCase
								    ().equals
								(((Globe) this)
								     .verclan
								     [i_444_]
								     [i_450_]
								     .toLowerCase
								 ())) {
								i_447_
								    -= (((Globe)
									 this)
									.points
									[i_444_]
									[i_450_]);
								if (i_447_ < 0)
								    i_447_ = 0;
								break;
							    }
							}
						    }
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("If you lose this war, your clan would lose:  [ ")
							      .append
							      (i_448_).append
							      (" points ]   &  ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" would get:  [ ")
							      .append
							      (i_447_).append
							      (" points ]")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						}
						strings[i_402_]
						    = "(See the bar at the top of the page for more details.)";
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("Arrange to meet ")
							  .append
							  (((Globe) this)
							   .intclan)
							  .append
							  (" at a chosen room in a server on a specific date to play the war.")
							  .toString();
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
						is[i_402_] = -1;
						i_402_++;
					    }
					    if (i_408_ == 8) {
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan.toLowerCase()))
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has defeated ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" in the war, congratulations!")
							      .toString();
						else
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has lost the war against ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (".").toString();
						ls[i_402_]
						    = getLvalue(string_406_,
								3);
						strings_403_[i_402_] = "";
						i_402_++;
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan.toLowerCase()))
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan won:  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" points ]   &  ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" lost:  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      (" points ]")
							      .toString();
						else
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan lost:  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								6))
							      .append
							      (" points ]   &  ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" won:  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" points ]")
							      .toString();
						is[i_402_] = -1;
						i_402_++;
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("").append
							  (getSvalue
							   (string_406_, 4))
							  .append
							  ("|").toString();
						is[i_402_] = 80;
						i_402_++;
						strings[i_402_] = "";
						is[i_402_] = 167;
						i_402_++;
					    }
					    if (i_408_ == 9) {
						String string_451_ = "";
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan
							 .toLowerCase())) {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has defeated ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" in the car battle, congratulations!")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("You took ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" ] !")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_451_
							= (((xtGraphics)
							    ((Globe) this).xt)
							   .clan);
						} else {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has lost the car battle against ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (".").toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" took your car :  [ ")
							      .append
							      (getSvalue
							       (string_406_,
								5))
							      .append
							      (" ] !")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_451_
							= (((Globe) this)
							   .intclan);
						}
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("").append
							  (getSvalue
							   (string_406_, 4))
							  .append
							  ("|").append
							  (getSvalue
							   (string_406_, 5))
							  .append
							  ("|").append
							  (string_451_).append
							  ("|").toString();
						is[i_402_] = 90;
						i_402_++;
						strings[i_402_] = "";
						is[i_402_] = 167;
						i_402_++;
					    }
					    if (i_408_ == 10) {
						String string_452_ = "";
						if (string_407_.toLowerCase
							().equals
						    (((xtGraphics)
						      ((Globe) this).xt)
							 .clan
							 .toLowerCase())) {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has defeated ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" in the stage battle, congratulations!")
							      .toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    String string_453_
							= (getSvalue
							   (string_406_, 5));
						    if (string_453_.length()
							> 20)
							string_453_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_453_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("You took ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      ("'s stage :  [ ")
							      .append
							      (string_453_)
							      .append
							      (" ] !")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_452_
							= (((xtGraphics)
							    ((Globe) this).xt)
							   .clan);
						} else {
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("Your clan has lost the stage battle against ")
							      .append
							      (((Globe) this)
							       .intclan)
							      .append
							      (".").toString();
						    ls[i_402_]
							= (getLvalue
							   (string_406_, 3));
						    strings_403_[i_402_] = "";
						    i_402_++;
						    String string_454_
							= (getSvalue
							   (string_406_, 5));
						    if (string_454_.length()
							> 20)
							string_454_
							    = new StringBuilder
								  ().append
								  ("").append
								  (string_454_
								       .substring
								   (0, 20))
								  .append
								  ("...")
								  .toString();
						    strings[i_402_]
							= new StringBuilder
							      ().append
							      ("").append
							      (((Globe) this)
							       .intclan)
							      .append
							      (" took your stage :  [ ")
							      .append
							      (string_454_)
							      .append
							      (" ] !")
							      .toString();
						    is[i_402_] = -1;
						    i_402_++;
						    string_452_
							= (((Globe) this)
							   .intclan);
						}
						strings[i_402_]
						    = new StringBuilder()
							  .append
							  ("").append
							  (getSvalue
							   (string_406_, 4))
							  .append
							  ("|").append
							  (getSvalue
							   (string_406_, 5))
							  .append
							  ("|").append
							  (string_452_).append
							  ("|").toString();
						is[i_402_] = 100;
						i_402_++;
						strings[i_402_] = "";
						is[i_402_] = 167;
						i_402_++;
					    }
					} else {
					    strings[i_402_] = string_406_;
					    try {
						((Globe) this).rd.setFont
						    (new Font("Tahoma", 0,
							      11));
						((Globe) this).ftm
						    = ((Globe) this).rd
							  .getFontMetrics();
						int i_455_ = 0;
						String string_456_ = "";
						for (/**/;
						     (i_455_
						      < string_406_.length());
						     i_455_++) {
						    string_456_
							= new StringBuilder
							      ().append
							      (string_456_)
							      .append
							      (string_406_
								   .charAt
							       (i_455_))
							      .toString();
						    if ((((Globe) this).ftm
							     .stringWidth
							 (string_456_))
							> 540) {
							if ((string_456_
								 .lastIndexOf
							     (" "))
							    != -1) {
							    strings[i_402_]
								= (string_456_
								       .substring
								   (0,
								    (string_456_
									 .lastIndexOf
								     (" "))));
							    string_456_
								= (string_456_
								       .substring
								   ((string_456_
									 .lastIndexOf
								     (" ")) + 1,
								    (string_456_
									 .length
								     ())));
							} else {
							    strings[i_402_]
								= string_456_;
							    string_456_ = "";
							}
							is[i_402_] = -1;
							i_402_++;
						    }
						}
						strings[i_402_] = string_456_;
					    } catch (Exception exception) {
						/* empty */
					    }
					    is[i_402_] = -1;
					    i_402_++;
					}
				    }
				    for (int i_457_ = 0; i_457_ < i_402_;
					 i_457_++) {
					((Globe) this).iline[i_457_]
					    = strings[i_457_];
					((Globe) this).ilinetyp[i_457_]
					    = is[i_457_];
					((Globe) this).ictimes[i_457_]
					    = ls[i_457_];
					((Globe) this).itimes[i_457_]
					    = strings_403_[i_457_];
				    }
				    ((Globe) this).nil = i_402_;
				    ((Globe) this).readint = 2;
				    ((Globe) this).lastint
					= new StringBuilder().append("").append
					      (((Globe) this).ictime[i])
					      .toString();
				    if ((((Globe) this).icheck[i].toLowerCase
					     ().indexOf
					 (((xtGraphics) ((Globe) this).xt)
					      .nickname.toLowerCase()))
					== -1) {
					StringBuilder stringbuilder
					    = new StringBuilder();
					String[] strings_458_
					    = ((Globe) this).icheck;
					int i_459_ = i;
					strings_458_[i_459_]
					    = stringbuilder.append
						  (strings_458_[i_459_]).append
						  ("#").append
						  (((xtGraphics)
						    ((Globe) this).xt)
						   .nickname)
						  .append
						  ("#").toString();
					try {
					    ((Globe) this).dout.println
						(new StringBuilder().append
						     ("101|41|").append
						     (((xtGraphics)
						       ((Globe) this).xt)
						      .nickname)
						     .append
						     ("|").append
						     (((xtGraphics)
						       ((Globe) this).xt).clan)
						     .append
						     ("|").append
						     (((Globe) this).intclan)
						     .append
						     ("|").toString());
					    string_318_ = ((Globe) this)
							      .din.readLine();
					} catch (Exception exception) {
					    /* empty */
					}
				    }
				    ((Globe) this).spos4 = 208;
				} else
				    ((Globe) this).readint = 3;
			    } catch (Exception exception) {
				((Globe) this).readint = 4;
			    }
			}
			if (((Globe) this).readint == 2) {
			    for (int i_460_ = 0; i_460_ < ((Globe) this).nil;
				 i_460_++) {
				if (((Globe) this).ilinetyp[i_460_] >= 0
				    && ((Globe) this).ilinetyp[i_460_] != 167
				    && ((Globe) this).ictimes[i_460_] > 0L) {
				    try {
					long l = (((Globe) this).ntime
						  - (((Globe) this).ictimes
						     [i_460_]));
					if (l >= 1000L && l < 60000L)
					    ((Globe) this).itimes[i_460_]
						= "seconds ago";
					if (l >= 60000L && l < 3600000L) {
					    int i_461_ = (int) (l / 60000L);
					    String string_462_ = "s";
					    if (i_461_ == 1)
						string_462_ = "";
					    ((Globe) this).itimes[i_460_]
						= new StringBuilder().append
						      ("").append
						      (i_461_).append
						      (" minute").append
						      (string_462_).append
						      (" ago").toString();
					}
					if (l >= 3600000L && l < 86400000L) {
					    int i_463_ = (int) (l / 3600000L);
					    String string_464_ = "s";
					    if (i_463_ == 1)
						string_464_ = "";
					    ((Globe) this).itimes[i_460_]
						= new StringBuilder().append
						      ("").append
						      (i_463_).append
						      (" hour").append
						      (string_464_).append
						      (" ago").toString();
					}
					if (l >= 86400000L) {
					    int i_465_ = (int) (l / 86400000L);
					    String string_466_ = "s";
					    if (i_465_ == 1)
						string_466_ = "";
					    ((Globe) this).itimes[i_460_]
						= new StringBuilder().append
						      ("").append
						      (i_465_).append
						      (" day").append
						      (string_466_).append
						      (" ago").toString();
					}
				    } catch (Exception exception) {
					((Globe) this).itimes[i_460_] = "";
				    }
				} else
				    ((Globe) this).itimes[i_460_] = "";
			    }
			}
			intclanbgpng(((Globe) this).intclan);
		    }
		    if (((Globe) this).sendint == 2) {
			((GameSparker) ((Globe) this).gs).mmsg.setText(" ");
			((Globe) this).sendint = 0;
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex()
			    > 1)
			    ((GameSparker) ((Globe) this).gs).sendtyp
				.select(0);
		    }
		    if (((Globe) this).openi == 10) {
			if (((Globe) this).viewgame2 == 1) {
			    ((Globe) this).vwscorex = 0;
			    ((Globe) this).vwscorei = 0;
			    String string_467_ = "pending_war";
			    if (((Globe) this).nvgames2 == 2)
				string_467_ = "pending_battle";
			    if (((Globe) this).nvgames2 == 9)
				string_467_ = "war";
			    if (((Globe) this).nvgames2 == 5)
				string_467_ = "battle";
			    try {
				URL url
				    = (new URL
				       (new StringBuilder().append
					    ("http://multiplayer.needformadness.com/interact/")
					    .append
					    (string_467_).append
					    ("/").append
					    (((Globe) this).viewwar2).append
					    (".txt").toString()));
				url.openConnection().setConnectTimeout(2000);
				String string_468_
				    = url.openConnection().getContentType();
				if (string_468_.equals("text/plain")) {
				    DataInputStream datainputstream
					= (new DataInputStream
					   (url.openStream()));
				    String string_469_ = "";
				    int i;
				    for (i = 0;
					 (((string_469_
					    = datainputstream.readLine())
					   != null)
					  && i < ((Globe) this).nvgames2);
					 i++) {
					String string_470_
					    = getSvalue(string_469_, 0);
					if (string_470_.startsWith("#")) {
					    boolean bool = true;
					    int i_471_;
					    try {
						i_471_
						    = Integer.valueOf
							  (string_470_
							       .substring(1))
							  .intValue();
					    } catch (Exception exception) {
						i_471_ = 1;
					    }
					    string_470_
						= new StringBuilder().append
						      ("NFM 1  -  Stage ")
						      .append
						      (i_471_).append
						      ("").toString();
					    if (i_471_ > 10)
						string_470_
						    = new StringBuilder()
							  .append
							  ("NFM 2  -  Stage ")
							  .append
							  (i_471_ - 10).append
							  ("").toString();
					    if (i_471_ > 27)
						string_470_
						    = new StringBuilder()
							  .append
							  ("NFM Multiplayer  -  Stage ")
							  .append
							  (i_471_ - 27).append
							  ("").toString();
					}
					((Globe) this).vwstages2[i]
					    = string_470_;
					((Globe) this).vwlaps2[i]
					    = getvalue(string_469_, 1);
					((Globe) this).vwcars2[i]
					    = getvalue(string_469_, 2);
					((Globe) this).vwclass2[i]
					    = getvalue(string_469_, 3);
					((Globe) this).vwfix2[i]
					    = getvalue(string_469_, 4);
					((Globe) this).vwinner[i]
					    = getSvalue(string_469_, 5);
					if (((Globe) this).vwinner[i]
						.toLowerCase
						().equals
					    (((xtGraphics) ((Globe) this).xt)
						 .clan.toLowerCase()))
					    ((Globe) this).vwscorex++;
					if (((Globe) this).vwinner[i]
						.toLowerCase
						().equals
					    (((Globe) this).intclan
						 .toLowerCase()))
					    ((Globe) this).vwscorei++;
				    }
				    datainputstream.close();
				    if (i != 0)
					((Globe) this).viewgame2 = 2;
				    else
					((Globe) this).viewgame2 = 4;
				} else
				    ((Globe) this).viewgame2 = 3;
			    } catch (Exception exception) {
				((Globe) this).viewgame2 = 4;
			    }
			}
			if ((((GameSparker) ((Globe) this).gs).sendtyp
				 .getSelectedIndex() == 4
			     || ((GameSparker) ((Globe) this).gs).sendtyp
				    .getSelectedIndex() == 5
			     || ((GameSparker) ((Globe) this).gs).sendtyp
				    .getSelectedIndex() == 6
			     || ((GameSparker) ((Globe) this).gs).sendtyp
				    .getSelectedIndex() == 7)
			    && ((GameSparker) ((Globe) this).gs).senditem
				   .getSelectedIndex() == 3
			    && ((Globe) this).isel == 3) {
			    loadiclanstages(((xtGraphics) ((Globe) this).xt)
					    .clan);
			    ((Globe) this).isel = 4;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 3
			    && ((Globe) this).ifas == 0) {
			    loadiclancars(((Globe) this).intclan);
			    ((Globe) this).ifas = 1;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 3
			    && ((Globe) this).ifas == 2) {
			    loadiclancars(((xtGraphics) ((Globe) this).xt)
					  .clan);
			    ((Globe) this).ifas = 3;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 3
			    && ((GameSparker) ((Globe) this).gs).senditem
				   .getSelectedIndex() == 3
			    && ((Globe) this).ifas == 5
			    && ((Globe) this).isel == 3) {
			    loadiclanstages(((xtGraphics) ((Globe) this).xt)
					    .clan);
			    ((Globe) this).isel = 4;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 2
			    && ((Globe) this).ifas == 0) {
			    loadiclanstages(((Globe) this).intclan);
			    ((Globe) this).ifas = 1;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 2
			    && ((Globe) this).ifas == 2) {
			    loadiclanstages(((xtGraphics) ((Globe) this).xt)
					    .clan);
			    ((Globe) this).ifas = 3;
			}
			if (((GameSparker) ((Globe) this).gs).sendtyp
				.getSelectedIndex() == 2
			    && ((GameSparker) ((Globe) this).gs).senditem
				   .getSelectedIndex() == 3
			    && ((Globe) this).ifas == 5
			    && ((Globe) this).isel == 3) {
			    loadiclanstages(((xtGraphics) ((Globe) this).xt)
					    .clan);
			    ((Globe) this).isel = 4;
			}
			if (((Globe) this).sendint == 1) {
			    try {
				String string_472_ = "#nada#";
				for (int i = 0; i < ((Globe) this).ni; i++) {
				    if (((Globe) this).iclan[i]
					    .equals(((Globe) this).intclan)) {
					string_472_ = ((Globe) this).iconvo[i];
					break;
				    }
				}
				string = new StringBuilder().append
					     ("101|39|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickname)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .nickey)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .clan)
					     .append
					     ("|").append
					     (((xtGraphics) ((Globe) this).xt)
					      .clankey)
					     .append
					     ("|").append
					     (((Globe) this).intclan).append
					     ("|").append
					     (string_472_).append
					     ("|").append
					     (((GameSparker) ((Globe) this).gs)
						  .sendtyp.getSelectedIndex())
					     .append
					     ("|").toString();
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 0) {
				    String string_473_
					= ((GameSparker) ((Globe) this).gs)
					      .mmsg.getText
					      ().replace("|", ":");
				    string_473_
					= string_473_.replaceAll("[\\t\\n\\r]",
								 "|");
				    String string_474_ = "";
				    int i = 0;
				    int i_475_ = 0;
				    for (/**/; i < string_473_.length(); i++) {
					String string_476_
					    = new StringBuilder().append
						  ("").append
						  (string_473_.charAt(i))
						  .toString();
					if (string_476_.equals("|"))
					    i_475_++;
					else
					    i_475_ = 0;
					if (i_475_ <= 1)
					    string_474_
						= new StringBuilder().append
						      (string_474_).append
						      (string_476_).toString();
				    }
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (string_474_).append
						 ("||").toString();
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 1) {
				    Calendar calendar = Calendar.getInstance();
				    long l = calendar.getTimeInMillis();
				    Calendar calendar_477_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    calendar_477_.roll
					(5, ((GameSparker) ((Globe) this).gs)
						.senditem.getSelectedIndex());
				    int i = (((GameSparker) ((Globe) this).gs)
						 .datat.getSelectedIndex()
					     + 12);
				    if (i >= 24)
					i -= 24;
				    Calendar calendar_478_ = calendar;
				    Calendar calendar_479_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    int i_480_ = calendar_479_.get(1);
				    Calendar calendar_481_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    int i_482_ = calendar_481_.get(2);
				    Calendar calendar_483_ = calendar;
				    if (calendar != null) {
					/* empty */
				    }
				    calendar_478_.set(i_480_, i_482_,
						      calendar_483_.get(5), i,
						      0);
				    l = calendar.getTimeInMillis() - l;
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (l).append
						 ("|").toString();
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex() == 2
				    || ((GameSparker) ((Globe) this).gs)
					   .sendtyp.getSelectedIndex() == 3) {
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (((Globe) this).itake).append
						 ("|").append
						 (((Globe) this).igive).append
						 ("|").toString();
				    if (!((Globe) this).sendwarnum) {
					for (int i = 0; i < 2; i++)
					    string
						= new StringBuilder().append
						      (string).append
						      ("").append
						      (((Globe) this).wstages
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wlaps[i])
						      .append
						      ("|").append
						      (((Globe) this).wcars[i])
						      .append
						      ("|").append
						      (((Globe) this).wclass
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wfix[i])
						      .append
						      ("|").toString();
				    } else {
					string = new StringBuilder().append
						     (string).append
						     ("warnum#|").append
						     (((Globe) this).warnum)
						     .append
						     ("|").toString();
					((Globe) this).sendwarnum = false;
				    }
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 4) {
				    if (!((Globe) this).sendwarnum) {
					for (int i = 0; i < 4; i++)
					    string
						= new StringBuilder().append
						      (string).append
						      ("").append
						      (((Globe) this).wstages
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wlaps[i])
						      .append
						      ("|").append
						      (((Globe) this).wcars[i])
						      .append
						      ("|").append
						      (((Globe) this).wclass
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wfix[i])
						      .append
						      ("|").toString();
				    } else {
					string = new StringBuilder().append
						     (string).append
						     ("warnum#|").append
						     (((Globe) this).warnum)
						     .append
						     ("|").toString();
					((Globe) this).sendwarnum = false;
				    }
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex() == 5
				    || ((GameSparker) ((Globe) this).gs)
					   .sendtyp.getSelectedIndex() == 6) {
				    string = new StringBuilder().append
						 (string).append
						 ("").append
						 (((Globe) this).itake).append
						 ("|").append
						 (((Globe) this).igive).append
						 ("|").toString();
				    if (!((Globe) this).sendwarnum) {
					string = new StringBuilder().append
						     (string).append
						     ("").append
						     (((Globe) this).sendwar)
						     .append
						     ("|").toString();
					for (int i = 0; i < 3; i++)
					    string
						= new StringBuilder().append
						      (string).append
						      ("").append
						      (((Globe) this).wstages
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wlaps[i])
						      .append
						      ("|").append
						      (((Globe) this).wcars[i])
						      .append
						      ("|").append
						      (((Globe) this).wclass
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wfix[i])
						      .append
						      ("|").toString();
				    } else {
					string = new StringBuilder().append
						     (string).append
						     ("warnum#|").append
						     (((Globe) this).warnum)
						     .append
						     ("|").toString();
					((Globe) this).sendwarnum = false;
				    }
				}
				if (((GameSparker) ((Globe) this).gs)
					.sendtyp.getSelectedIndex()
				    == 7) {
				    if (!((Globe) this).sendwarnum) {
					string = new StringBuilder().append
						     (string).append
						     ("").append
						     (((Globe) this).sendwar)
						     .append
						     ("|").toString();
					for (int i = 0; i < 5; i++)
					    string
						= new StringBuilder().append
						      (string).append
						      ("").append
						      (((Globe) this).wstages
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wlaps[i])
						      .append
						      ("|").append
						      (((Globe) this).wcars[i])
						      .append
						      ("|").append
						      (((Globe) this).wclass
						       [i])
						      .append
						      ("|").append
						      (((Globe) this).wfix[i])
						      .append
						      ("|").toString();
				    } else {
					string = new StringBuilder().append
						     (string).append
						     ("warnum#|").append
						     (((Globe) this).warnum)
						     .append
						     ("|").toString();
					((Globe) this).sendwarnum = false;
				    }
				}
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
				if (string_318_.equals("OK"))
				    ((Globe) this).sendint = 2;
				else if (string_318_.equals("SUJ")) {
				    ((Globe) this).itab = 2;
				    ((Globe) this).sendint = 0;
				    ((Globe) this).openi = 0;
				    ((Globe) this).readint = 0;
				} else if (string_318_.equals("failfile")) {
				    ((Globe) this).readint = 6;
				    ((Globe) this).sendint = 0;
				    ((GameSparker) ((Globe) this).gs).mmsg
					.setText(" ");
				    ((GameSparker) ((Globe) this).gs)
					.sendtyp.select(0);
				} else {
				    ((Globe) this).readint = 5;
				    ((Globe) this).sendint = 0;
				}
			    } catch (Exception exception) {
				((Globe) this).readint = 5;
				((Globe) this).sendint = 0;
			    }
			}
		    }
		}
		if (((Globe) this).itab == 2
		    && !((xtGraphics) ((Globe) this).xt).clan.equals("")) {
		    try {
			string
			    = new StringBuilder().append("101|36|").append
				  (((xtGraphics) ((Globe) this).xt).clan)
				  .append
				  ("|").append
				  (((xtGraphics) ((Globe) this).xt).clankey)
				  .append
				  ("|").append
				  (((Globe) this).readclan).append
				  ("|").append
				  (((xtGraphics) ((Globe) this).xt).nickname)
				  .append
				  ("|").toString();
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
			if (string_318_.startsWith("RECIVE")) {
			    ((Globe) this).readclan = -3;
			    if (((Globe) this).loadwstat == 0)
				loadchamps();
			    int i = getvalue(string_318_, 1);
			    ((Globe) this).cadmin = getvalue(string_318_, 2);
			    int i_484_ = 0;
			    String[] strings = new String[1000];
			    int[] is = new int[1000];
			    long[] ls = new long[1000];
			    String[] strings_485_ = new String[1000];
			    strings[i_484_] = "";
			    is[i_484_] = 167;
			    i_484_++;
			    DataInputStream datainputstream
				= new DataInputStream(((Globe) this).socket
							  .getInputStream());
			    byte[] is_486_ = new byte[i];
			    datainputstream.readFully(is_486_);
			    string_318_ = ((Globe) this).din.readLine();
			    datainputstream
				= (new DataInputStream
				   (new ByteArrayInputStream(is_486_)));
			    String string_487_ = "";
			    while ((string_487_ = datainputstream.readLine())
				   != null) {
				if (string_487_.startsWith("|")) {
				    strings[i_484_] = "";
				    is[i_484_] = 167;
				    i_484_++;
				    String string_488_
					= getSvalue(string_487_, 1);
				    if (string_488_.toLowerCase().equals
					(((xtGraphics) ((Globe) this).xt)
					     .nickname.toLowerCase()))
					string_488_ = "You";
				    is[i_484_] = getvalue(string_487_, 2);
				    int i_489_ = is[i_484_];
				    if (i_489_ == 0) {
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_488_).append
						  (" wrote:").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
				    }
				    if (i_489_ == 1) {
					if (string_488_.equals("You"))
					    strings[i_484_]
						= "You have shared the following date:";
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" has shared the following date:")
						      .toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					Calendar calendar
					    = Calendar.getInstance();
					long l = (calendar.getTimeInMillis()
						  - (((Globe) this).ntime
						     - ls[i_484_])
						  + getLvalue(string_487_, 4));
					if (l > 0L)
					    calendar.setTimeInMillis(l);
					i_484_++;
					Calendar calendar_490_ = calendar;
					if (calendar != null) {
					    /* empty */
					}
					int i_491_ = calendar_490_.get(11);
					String string_492_ = "AM";
					Calendar calendar_493_ = calendar;
					if (calendar != null) {
					    /* empty */
					}
					if (calendar_493_.get(12) > 30
					    && ++i_491_ == 24)
					    i_491_ -= 24;
					if (i_491_ >= 12)
					    string_492_ = "PM";
					if (i_491_ > 12)
					    i_491_ -= 12;
					if (i_491_ == 0)
					    i_491_ = 12;
					try {
					    String[] strings_494_ = strings;
					    int i_495_ = i_484_;
					    StringBuilder stringbuilder
						= new StringBuilder()
						      .append("[  ");
					    String[] strings_496_
						= ((Globe) this).wday;
					    Calendar calendar_497_ = calendar;
					    if (calendar != null) {
						/* empty */
					    }
					    StringBuilder stringbuilder_498_
						= stringbuilder.append
						      (strings_496_
						       [(calendar_497_.get(7)
							 - 1)])
						      .append("  -  ");
					    String[] strings_499_
						= ((Globe) this).month;
					    Calendar calendar_500_ = calendar;
					    if (calendar != null) {
						/* empty */
					    }
					    StringBuilder stringbuilder_501_
						= stringbuilder_498_.append
						      (strings_499_
						       [calendar_500_.get(2)])
						      .append(" ");
					    Calendar calendar_502_ = calendar;
					    if (calendar != null) {
						/* empty */
					    }
					    strings_494_[i_495_]
						= stringbuilder_501_.append
						      (calendar_502_.get(5))
						      .append
						      (",  ").append
						      (i_491_).append
						      (" ").append
						      (string_492_).append
						      ("  ]").toString();
					} catch (Exception exception) {
					    strings[i_484_]
						= "Error occurred while calculating this date.";
					}
					is[i_484_] = -1;
					i_484_++;
					strings[i_484_]
					    = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
					is[i_484_] = -1;
					i_484_++;
				    }
				    if (i_489_ == 2) {
					String string_503_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested declaring war on [ ")
						      .append
						      (string_503_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested declaring war on [ ")
						      .append
						      (string_503_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_503_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").toString();
					is[i_484_] = 20;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					if (((Globe) this).loadwstat == 1
					    && !string_487_
						    .endsWith("|out|")) {
					    int i_504_ = -1;
					    int i_505_ = 0;
					    int i_506_ = -1;
					    int i_507_ = 0;
					    for (int i_508_ = 0;
						 i_508_ < ((Globe) this).ncc;
						 i_508_++) {
						if (((xtGraphics)
						     ((Globe) this).xt)
							.clan.toLowerCase
							().equals
						    (((Globe) this).conclan
							 [i_508_]
							 .toLowerCase())) {
						    i_505_ = (((Globe) this)
							      .totp[i_508_]);
						    i_504_ = i_508_;
						}
						if (string_503_.toLowerCase
							().equals
						    (((Globe) this).conclan
							 [i_508_]
							 .toLowerCase())) {
						    i_507_ = (((Globe) this)
							      .totp[i_508_]);
						    i_506_ = i_508_;
						}
					    }
					    int i_509_ = i_507_ + 1;
					    int i_510_ = i_505_ + 1;
					    if (i_510_ > i_507_)
						i_510_ = i_507_;
					    if (i_504_ != -1) {
						for (int i_511_ = 0;
						     i_511_ < (((Globe) this)
							       .nvc[i_504_]);
						     i_511_++) {
						    if (string_503_.toLowerCase
							    ().equals
							(((Globe) this)
							     .verclan[i_504_]
							     [i_511_]
							     .toLowerCase())) {
							i_509_
							    -= (((Globe) this)
								.points[i_504_]
								[i_511_]);
							if (i_509_ < 0)
							    i_509_ = 0;
							break;
						    }
						}
					    }
					    strings[i_484_]
						= new StringBuilder().append
						      ("If you win this war, your clan would get:  [ ")
						      .append
						      (i_509_).append
						      (" points ]   &  ")
						      .append
						      (string_503_).append
						      (" would lose:  [ ")
						      .append
						      (i_510_).append
						      (" points ]").toString();
					    is[i_484_] = -1;
					    i_484_++;
					    i_509_ = i_505_ + 1;
					    i_510_ = i_507_ + 1;
					    if (i_510_ > i_505_)
						i_510_ = i_505_;
					    if (i_506_ != -1) {
						for (int i_512_ = 0;
						     i_512_ < (((Globe) this)
							       .nvc[i_506_]);
						     i_512_++) {
						    if (((xtGraphics)
							 ((Globe) this).xt)
							    .clan.toLowerCase
							    ().equals
							(((Globe) this)
							     .verclan[i_506_]
							     [i_512_]
							     .toLowerCase())) {
							i_509_
							    -= (((Globe) this)
								.points[i_506_]
								[i_512_]);
							if (i_509_ < 0)
							    i_509_ = 0;
							break;
						    }
						}
					    }
					    strings[i_484_]
						= new StringBuilder().append
						      ("If you lose this war, your clan would lose:  [ ")
						      .append
						      (i_510_).append
						      (" points ]   &  ")
						      .append
						      (string_503_).append
						      (" would get:  [ ")
						      .append
						      (i_509_).append
						      (" points ]").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be declared on ")
						      .append
						      (string_503_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 3) {
					String string_513_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested to car battle with [ ")
						      .append
						      (string_513_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested to car battle with [ ")
						      .append
						      (string_513_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_513_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 7))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 8))
						  .append
						  ("|").toString();
					is[i_484_] = 30;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you win you will take ")
						  .append
						  (string_513_).append
						  ("'s car :  [ ").append
						  (getSvalue(string_487_, 5))
						  .append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you lose you will give ")
						  .append
						  (string_513_).append
						  (" your clan's car :  [ ")
						  .append
						  (getSvalue(string_487_, 6))
						  .append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be sent to ")
						      .append
						      (string_513_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 4) {
					String string_514_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested to stage battle with [ ")
						      .append
						      (string_514_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested to stage battle with [ ")
						      .append
						      (string_514_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_514_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 7))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 8))
						  .append
						  ("|").toString();
					is[i_484_] = 40;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					String string_515_
					    = getSvalue(string_487_, 5);
					if (string_515_.length() > 20)
					    string_515_
						= new StringBuilder().append
						      ("").append
						      (string_515_
							   .substring(0, 20))
						      .append
						      ("...").toString();
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you win you will take ")
						  .append
						  (string_514_).append
						  ("'s stage :  [ ").append
						  (string_515_).append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					string_515_
					    = getSvalue(string_487_, 6);
					if (string_515_.length() > 20)
					    string_515_
						= new StringBuilder().append
						      ("").append
						      (string_515_
							   .substring(0, 20))
						      .append
						      ("...").toString();
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you lose you will give ")
						  .append
						  (string_514_).append
						  (" your clan's stage :  [ ")
						  .append
						  (string_515_).append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be sent to ")
						      .append
						      (string_514_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 5) {
					String string_516_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested accepting to go to war with [ ")
						      .append
						      (string_516_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested accepting to go to war with [ ")
						      .append
						      (string_516_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_516_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").toString();
					is[i_484_] = 50;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					if (((Globe) this).loadwstat == 1
					    && !string_487_
						    .endsWith("|out|")) {
					    int i_517_ = -1;
					    int i_518_ = 0;
					    int i_519_ = -1;
					    int i_520_ = 0;
					    for (int i_521_ = 0;
						 i_521_ < ((Globe) this).ncc;
						 i_521_++) {
						if (((xtGraphics)
						     ((Globe) this).xt)
							.clan.toLowerCase
							().equals
						    (((Globe) this).conclan
							 [i_521_]
							 .toLowerCase())) {
						    i_518_ = (((Globe) this)
							      .totp[i_521_]);
						    i_517_ = i_521_;
						}
						if (string_516_.toLowerCase
							().equals
						    (((Globe) this).conclan
							 [i_521_]
							 .toLowerCase())) {
						    i_520_ = (((Globe) this)
							      .totp[i_521_]);
						    i_519_ = i_521_;
						}
					    }
					    int i_522_ = i_520_ + 1;
					    int i_523_ = i_518_ + 1;
					    if (i_523_ > i_520_)
						i_523_ = i_520_;
					    if (i_517_ != -1) {
						for (int i_524_ = 0;
						     i_524_ < (((Globe) this)
							       .nvc[i_517_]);
						     i_524_++) {
						    if (string_516_.toLowerCase
							    ().equals
							(((Globe) this)
							     .verclan[i_517_]
							     [i_524_]
							     .toLowerCase())) {
							i_522_
							    -= (((Globe) this)
								.points[i_517_]
								[i_524_]);
							if (i_522_ < 0)
							    i_522_ = 0;
							break;
						    }
						}
					    }
					    strings[i_484_]
						= new StringBuilder().append
						      ("If you win this war, your clan would get:  [ ")
						      .append
						      (i_522_).append
						      (" points ]   &  ")
						      .append
						      (string_516_).append
						      (" would lose:  [ ")
						      .append
						      (i_523_).append
						      (" points ]").toString();
					    is[i_484_] = -1;
					    i_484_++;
					    i_522_ = i_518_ + 1;
					    i_523_ = i_520_ + 1;
					    if (i_523_ > i_518_)
						i_523_ = i_518_;
					    if (i_519_ != -1) {
						for (int i_525_ = 0;
						     i_525_ < (((Globe) this)
							       .nvc[i_519_]);
						     i_525_++) {
						    if (((xtGraphics)
							 ((Globe) this).xt)
							    .clan.toLowerCase
							    ().equals
							(((Globe) this)
							     .verclan[i_519_]
							     [i_525_]
							     .toLowerCase())) {
							i_522_
							    -= (((Globe) this)
								.points[i_519_]
								[i_525_]);
							if (i_522_ < 0)
							    i_522_ = 0;
							break;
						    }
						}
					    }
					    strings[i_484_]
						= new StringBuilder().append
						      ("If you lose this war, your clan would lose:  [ ")
						      .append
						      (i_523_).append
						      (" points ]   &  ")
						      .append
						      (string_516_).append
						      (" would get:  [ ")
						      .append
						      (i_522_).append
						      (" points ]").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be declared on ")
						      .append
						      (string_516_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 6) {
					String string_526_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested accepting to car battle with [ ")
						      .append
						      (string_526_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested accepting to car battle with [ ")
						      .append
						      (string_526_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_526_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 7))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 8))
						  .append
						  ("|").toString();
					is[i_484_] = 60;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you win you will take ")
						  .append
						  (string_526_).append
						  ("'s car :  [ ").append
						  (getSvalue(string_487_, 5))
						  .append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you lose you will give ")
						  .append
						  (string_526_).append
						  (" your clan's car :  [ ")
						  .append
						  (getSvalue(string_487_, 6))
						  .append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be sent to ")
						      .append
						      (string_526_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 7) {
					String string_527_
					    = getSvalue(string_487_, 4);
					if (string_488_.equals("You"))
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have suggested accepting to stage battle with [ ")
						      .append
						      (string_527_).append
						      (" ] :").toString();
					else
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (string_488_).append
						      (" suggested accepting to stage battle with [ ")
						      .append
						      (string_527_).append
						      (" ] :").toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					strings[i_484_]
					    = new StringBuilder().append
						  ("").append
						  (string_527_).append
						  ("|").append
						  (getSvalue(string_487_, 5))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 6))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 7))
						  .append
						  ("|").append
						  (getSvalue(string_487_, 8))
						  .append
						  ("|").toString();
					is[i_484_] = 70;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
					String string_528_
					    = getSvalue(string_487_, 5);
					if (string_528_.length() > 20)
					    string_528_
						= new StringBuilder().append
						      ("").append
						      (string_528_
							   .substring(0, 20))
						      .append
						      ("...").toString();
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you win you will take ")
						  .append
						  (string_527_).append
						  ("'s stage :  [ ").append
						  (string_528_).append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					string_528_
					    = getSvalue(string_487_, 6);
					if (string_528_.length() > 20)
					    string_528_
						= new StringBuilder().append
						      ("").append
						      (string_528_
							   .substring(0, 20))
						      .append
						      ("...").toString();
					strings[i_484_]
					    = new StringBuilder().append
						  ("If you lose you will give ")
						  .append
						  (string_527_).append
						  (" your clan's stage :  [ ")
						  .append
						  (string_528_).append
						  (" ]").toString();
					is[i_484_] = -1;
					i_484_++;
					if (!string_487_.endsWith("|out|")) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("(This needs to be approved by the Clan Leader or an Admin to be sent to ")
						      .append
						      (string_527_).append
						      (".)").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
				    }
				    if (i_489_ == 8) {
					int i_529_ = getvalue(string_487_, 4);
					String string_530_ = "taken";
					if (i_529_ == 2)
					    string_530_ = "re-claimed";
					strings[i_484_]
					    = new StringBuilder().append
						  ("Congratulations!!  Your clan has ")
						  .append
						  (string_530_).append
						  (" the clan wars world championship title!")
						  .toString();
					ls[i_484_] = getLvalue(string_487_, 3);
					strings_485_[i_484_] = "";
					i_484_++;
					if (i_529_ == 1) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("Your recent win in the war against ")
						      .append
						      (getSvalue(string_487_,
								 6))
						      .append
						      (" has given you the championship title!")
						      .toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (i_529_ == 2) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("You have successfully defended your championship title against ")
						      .append
						      (getSvalue(string_487_,
								 6))
						      .append
						      ("!").toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (i_529_ == 3) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("A recent war between ")
						      .append
						      (getSvalue(string_487_,
								 5))
						      .append
						      (" and ").append
						      (getSvalue(string_487_,
								 6))
						      .append
						      (" has resulted in a change of points!")
						      .toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (i_529_ == 4) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("Clan ").append
						      (getSvalue(string_487_,
								 5))
						      .append
						      (" removed itself from the game which resulted in a change of points, giving you the title!")
						      .toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					if (i_529_ != 2) {
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (((xtGraphics)
							((Globe) this).xt)
						       .clan)
						      .append
						      (" is now the new champion of the world in Need for Madness!")
						      .toString();
					    is[i_484_] = -1;
					    i_484_++;
					} else {
					    strings[i_484_]
						= new StringBuilder().append
						      ("").append
						      (((xtGraphics)
							((Globe) this).xt)
						       .clan)
						      .append
						      (" still remains the champion of the world in Need for Madness!")
						      .toString();
					    is[i_484_] = -1;
					    i_484_++;
					}
					is[i_484_] = 80;
					i_484_++;
					strings[i_484_] = "";
					is[i_484_] = 167;
					i_484_++;
				    }
				} else {
				    strings[i_484_] = string_487_;
				    try {
					((Globe) this).rd.setFont
					    (new Font("Tahoma", 0, 11));
					((Globe) this).ftm
					    = ((Globe) this).rd
						  .getFontMetrics();
					int i_531_ = 0;
					String string_532_ = "";
					for (/**/;
					     i_531_ < string_487_.length();
					     i_531_++) {
					    string_532_
						= new StringBuilder().append
						      (string_532_).append
						      (string_487_
							   .charAt(i_531_))
						      .toString();
					    if (((Globe) this).ftm
						    .stringWidth(string_532_)
						> 540) {
						if (string_532_
							.lastIndexOf(" ")
						    != -1) {
						    strings[i_484_]
							= (string_532_
							       .substring
							   (0,
							    (string_532_
								 .lastIndexOf
							     (" "))));
						    string_532_
							= (string_532_
							       .substring
							   ((string_532_
								 .lastIndexOf
							     (" ")) + 1,
							    string_532_
								.length()));
						} else {
						    strings[i_484_]
							= string_532_;
						    string_532_ = "";
						}
						is[i_484_] = -1;
						i_484_++;
					    }
					}
					strings[i_484_] = string_532_;
				    } catch (Exception exception) {
					/* empty */
				    }
				    is[i_484_] = -1;
				    i_484_++;
				}
			    }
			    for (int i_533_ = 0; i_533_ < i_484_; i_533_++) {
				((Globe) this).cmline[i_533_]
				    = strings[i_533_];
				((Globe) this).cmlinetyp[i_533_] = is[i_533_];
				((Globe) this).cmctimes[i_533_] = ls[i_533_];
				((Globe) this).cmtimes[i_533_]
				    = strings_485_[i_533_];
			    }
			    ((Globe) this).cnml = i_484_;
			    ((Globe) this).readclan = i;
			    ((Globe) this).spos3 = 219;
			}
		    } catch (Exception exception) {
			((Globe) this).readclan = -1;
		    }
		    if (((Globe) this).readclan > 0) {
			for (int i = 0; i < ((Globe) this).cnml; i++) {
			    if (((Globe) this).cmlinetyp[i] >= 0
				&& ((Globe) this).cmlinetyp[i] != 167
				&& ((Globe) this).cmctimes[i] > 0L) {
				try {
				    long l = (((Globe) this).ntime
					      - ((Globe) this).cmctimes[i]);
				    if (l >= 1000L && l < 60000L)
					((Globe) this).cmtimes[i]
					    = "seconds ago";
				    if (l >= 60000L && l < 3600000L) {
					int i_534_ = (int) (l / 60000L);
					String string_535_ = "s";
					if (i_534_ == 1)
					    string_535_ = "";
					((Globe) this).cmtimes[i]
					    = new StringBuilder().append
						  ("").append
						  (i_534_).append
						  (" minute").append
						  (string_535_).append
						  (" ago").toString();
				    }
				    if (l >= 3600000L && l < 86400000L) {
					int i_536_ = (int) (l / 3600000L);
					String string_537_ = "s";
					if (i_536_ == 1)
					    string_537_ = "";
					((Globe) this).cmtimes[i]
					    = new StringBuilder().append
						  ("").append
						  (i_536_).append
						  (" hour").append
						  (string_537_).append
						  (" ago").toString();
				    }
				    if (l >= 86400000L) {
					int i_538_ = (int) (l / 86400000L);
					String string_539_ = "s";
					if (i_538_ == 1)
					    string_539_ = "";
					((Globe) this).cmtimes[i]
					    = new StringBuilder().append
						  ("").append
						  (i_538_).append
						  (" day").append
						  (string_539_).append
						  (" ago").toString();
				    }
				} catch (Exception exception) {
				    ((Globe) this).cmtimes[i] = "";
				}
			    } else
				((Globe) this).cmtimes[i] = "";
			}
		    }
		    clanlogopng(((xtGraphics) ((Globe) this).xt).clan);
		    if (((Globe) this).sendcmsg == 2) {
			((GameSparker) ((Globe) this).gs).mmsg.setText(" ");
			((Globe) this).sendcmsg = 0;
		    }
		    if (((Globe) this).viewgame1 == 1) {
			try {
			    String string_540_ = "pending_war";
			    if (((Globe) this).nvgames1 == 2
				|| ((Globe) this).nvgames1 == 5)
				string_540_ = "pending_battle";
			    URL url
				= (new URL
				   (new StringBuilder().append
					("http://multiplayer.needformadness.com/interact/")
					.append
					(string_540_).append
					("/").append
					(((Globe) this).viewwar1).append
					(".txt").toString()));
			    url.openConnection().setConnectTimeout(2000);
			    String string_541_
				= url.openConnection().getContentType();
			    if (string_541_.equals("text/plain")) {
				DataInputStream datainputstream
				    = new DataInputStream(url.openStream());
				String string_542_ = "";
				int i;
				for (i = 0;
				     ((string_542_
				       = datainputstream.readLine()) != null
				      && i < ((Globe) this).nvgames1);
				     i++) {
				    String string_543_
					= getSvalue(string_542_, 0);
				    if (string_543_.startsWith("#")) {
					boolean bool = true;
					int i_544_;
					try {
					    i_544_ = Integer.valueOf
							 (string_543_
							      .substring(1))
							 .intValue();
					} catch (Exception exception) {
					    i_544_ = 1;
					}
					string_543_
					    = new StringBuilder().append
						  ("NFM 1  -  Stage ").append
						  (i_544_).append
						  ("").toString();
					if (i_544_ > 10)
					    string_543_
						= new StringBuilder().append
						      ("NFM 2  -  Stage ")
						      .append
						      (i_544_ - 10).append
						      ("").toString();
					if (i_544_ > 27)
					    string_543_
						= new StringBuilder().append
						      ("NFM Multiplayer  -  Stage ")
						      .append
						      (i_544_ - 27).append
						      ("").toString();
				    }
				    ((Globe) this).vwstages1[i] = string_543_;
				    ((Globe) this).vwlaps1[i]
					= getvalue(string_542_, 1);
				    ((Globe) this).vwcars1[i]
					= getvalue(string_542_, 2);
				    ((Globe) this).vwclass1[i]
					= getvalue(string_542_, 3);
				    ((Globe) this).vwfix1[i]
					= getvalue(string_542_, 4);
				}
				datainputstream.close();
				if (i != 0)
				    ((Globe) this).viewgame1 = 2;
				else
				    ((Globe) this).viewgame1 = 4;
			    } else
				((Globe) this).viewgame1 = 3;
			} catch (Exception exception) {
			    ((Globe) this).viewgame1 = 4;
			}
		    }
		    if (((Globe) this).sendcmsg == 1) {
			try {
			    string
				= new StringBuilder().append("101|37|").append
				      (((xtGraphics) ((Globe) this).xt)
				       .nickname)
				      .append
				      ("|").append
				      (((xtGraphics) ((Globe) this).xt).nickey)
				      .append
				      ("|").append
				      (((xtGraphics) ((Globe) this).xt).clan)
				      .append
				      ("|").append
				      (((xtGraphics) ((Globe) this).xt)
				       .clankey)
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .sendtyp.getSelectedIndex())
				      .append
				      ("|").toString();
			    if (((GameSparker) ((Globe) this).gs).sendtyp
				    .getSelectedIndex()
				== 0) {
				String string_545_
				    = ((GameSparker) ((Globe) this).gs)
					  .mmsg.getText
					  ().replace("|", ":");
				string_545_
				    = string_545_.replaceAll("[\\t\\n\\r]",
							     "|");
				String string_546_ = "";
				int i = 0;
				int i_547_ = 0;
				for (/**/; i < string_545_.length(); i++) {
				    String string_548_
					= new StringBuilder().append("").append
					      (string_545_.charAt(i))
					      .toString();
				    if (string_548_.equals("|"))
					i_547_++;
				    else
					i_547_ = 0;
				    if (i_547_ <= 1)
					string_546_
					    = new StringBuilder().append
						  (string_546_).append
						  (string_548_).toString();
				}
				string
				    = new StringBuilder().append(string).append
					  ("").append
					  (string_546_).append
					  ("||").toString();
			    }
			    if (((GameSparker) ((Globe) this).gs).sendtyp
				    .getSelectedIndex()
				== 1) {
				Calendar calendar = Calendar.getInstance();
				long l = calendar.getTimeInMillis();
				Calendar calendar_549_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				calendar_549_.roll(5, ((GameSparker)
						       ((Globe) this).gs)
							  .senditem
							  .getSelectedIndex());
				int i = (((GameSparker) ((Globe) this).gs)
					     .datat.getSelectedIndex()
					 + 12);
				if (i >= 24)
				    i -= 24;
				Calendar calendar_550_ = calendar;
				Calendar calendar_551_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				int i_552_ = calendar_551_.get(1);
				Calendar calendar_553_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				int i_554_ = calendar_553_.get(2);
				Calendar calendar_555_ = calendar;
				if (calendar != null) {
				    /* empty */
				}
				calendar_550_.set(i_552_, i_554_,
						  calendar_555_.get(5), i, 0);
				l = calendar.getTimeInMillis() - l;
				string
				    = new StringBuilder().append(string).append
					  ("").append
					  (l).append
					  ("|").toString();
			    }
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			    if (string_318_.equals("OK"))
				((Globe) this).sendcmsg = 2;
			    else {
				((Globe) this).readclan = -2;
				((Globe) this).sendcmsg = 0;
			    }
			} catch (Exception exception) {
			    ((Globe) this).readclan = -2;
			    ((Globe) this).sendcmsg = 0;
			}
		    }
		    loadmyclanbg();
		}
	    }
	    if (((Login) ((Globe) this).lg).nmsgs != 0
		|| ((Login) ((Globe) this).lg).nfreq != 0
		|| ((Login) ((Globe) this).lg).nconf != 0
		|| ((Login) ((Globe) this).lg).ncreq != 0
		|| !((Login) ((Globe) this).lg).clanapv.equals("")) {
		string = new StringBuilder().append("101|19|").append
			     (((xtGraphics) ((Globe) this).xt).nickname).append
			     ("|").append
			     (((xtGraphics) ((Globe) this).xt).nickey).append
			     ("|").toString();
		try {
		    ((Globe) this).dout.println(string);
		    string_318_ = ((Globe) this).din.readLine();
		} catch (Exception exception) {
		    /* empty */
		}
		((Login) ((Globe) this).lg).nmsgs = 0;
		((Login) ((Globe) this).lg).nfreq = 0;
		((Login) ((Globe) this).lg).nconf = 0;
		((Login) ((Globe) this).lg).ncreq = 0;
		((Login) ((Globe) this).lg).clanapv = "";
	    }
	    if (((Globe) this).tab == 0 && ((Globe) this).domon) {
		string = new StringBuilder().append("101|101|").append
			     (((Globe) this).updatec).append
			     ("|").toString();
		if (((Globe) this).updatec <= -11) {
		    for (int i = 0; i < -((Globe) this).updatec - 10; i++)
			string = new StringBuilder().append(string).append
				     ("").append
				     (((Globe) this).cnames[20 - i]).append
				     ("|").append
				     (((Globe) this).sentn[20 - i]).append
				     ("|").toString();
		    ((Globe) this).updatec = -2;
		}
		try {
		    ((Globe) this).dout.println(string);
		    string_318_ = ((Globe) this).din.readLine();
		    if (string_318_ == null)
			((Globe) this).domon = false;
		} catch (Exception exception) {
		    ((Globe) this).domon = false;
		}
		if (((Globe) this).domon) {
		    int i = getvalue(string_318_, 0);
		    if (((Globe) this).updatec != i
			&& ((Globe) this).updatec >= -2) {
			for (int i_556_ = 0; i_556_ < 21; i_556_++) {
			    ((Globe) this).cnames[i_556_]
				= getSvalue(string_318_, 1 + i_556_ * 3);
			    ((Globe) this).sentn[i_556_]
				= getSvalue(string_318_, 2 + i_556_ * 3);
			    ((Globe) this).nctime[i_556_]
				= getLvalue(string_318_, 3 + i_556_ * 3);
			}
			((Globe) this).updatec = i;
		    }
		    for (int i_557_ = 0; i_557_ < 21; i_557_++) {
			if (((Globe) this).nctime[i_557_] > 0L) {
			    long l = (((Globe) this).ntime
				      - ((Globe) this).nctime[i_557_]);
			    if (l < 1000L)
				((Globe) this).ctime[i_557_] = "- just now";
			    if (l >= 1000L && l < 60000L)
				((Globe) this).ctime[i_557_] = "- seconds ago";
			    if (l >= 60000L && l < 3600000L) {
				int i_558_ = (int) (l / 60000L);
				String string_559_ = "s";
				if (i_558_ == 1)
				    string_559_ = "";
				((Globe) this).ctime[i_557_]
				    = new StringBuilder().append("- ").append
					  (i_558_).append
					  (" minute").append
					  (string_559_).append
					  (" ago").toString();
			    }
			    if (l >= 3600000L && l < 86400000L) {
				int i_560_ = (int) (l / 3600000L);
				String string_561_ = "s";
				if (i_560_ == 1)
				    string_561_ = "";
				((Globe) this).ctime[i_557_]
				    = new StringBuilder().append("- ").append
					  (i_560_).append
					  (" hour").append
					  (string_561_).append
					  (" ago").toString();
			    }
			    if (l >= 86400000L) {
				int i_562_ = (int) (l / 86400000L);
				String string_563_ = "s";
				if (i_562_ == 1)
				    string_563_ = "";
				((Globe) this).ctime[i_557_]
				    = new StringBuilder().append("- ").append
					  (i_562_).append
					  (" day").append
					  (string_563_).append
					  (" ago").toString();
			    }
			} else
			    ((Globe) this).ctime[i_557_] = "";
		    }
		}
	    }
	    if (((Globe) this).tab == 1) {
		if (((Globe) this).upload == 5) {
		    ((Globe) this).upload = 0;
		    ((Globe) this).loadedp = false;
		    ((Globe) this).edit = 0;
		    ((Globe) this).refresh = true;
		}
		if (!((Globe) this).loadedp) {
		    if (!((Globe) this).refresh) {
			loadproinfo();
			trunsent();
		    }
		    logopng();
		    avatarpng();
		    clanlogopng(((Globe) this).proclan);
		    ((Globe) this).refresh = false;
		    ((Globe) this).protab = 0;
		    ((Globe) this).loadedp = true;
		}
		if (((Globe) this).protab == 2) {
		    if (((Globe) this).loadpst == 0)
			loadprostages();
		    if (((Globe) this).loadpst == 1
			&& !((GameSparker) ((Globe) this).gs).proitem
				.getSelectedItem
				().equals(((Globe) this).loadpstage)
			&& (((Smenu) ((GameSparker) ((Globe) this).gs).proitem)
			    .sel) != 0) {
			((Globe) this).addstage = 0;
			if (((Globe) this).gs.loadstagePreview
			    (-2,
			     ((GameSparker) ((Globe) this).gs).proitem
				 .getSelectedItem(),
			     ((Globe) this).co, ((Globe) this).bco,
			     ((Globe) this).m, ((Globe) this).cp)) {
			    ((Globe) this).loadedpstage = true;
			    ((Medium) ((Globe) this).m).hit = 20000;
			    ((Medium) ((Globe) this).m).fallen = 0;
			} else
			    ((Globe) this).loadedpstage = false;
			((Globe) this).loadpstage
			    = ((GameSparker) ((Globe) this).gs).proitem
				  .getSelectedItem();
		    }
		}
	    }
	    if (((Globe) this).ptab == 2
		&& !((xtGraphics) ((Globe) this).xt).clan.equals("")
		&& !((Globe) this).loadedcm) {
		loadfclan();
		((Globe) this).loadedcm = true;
	    }
	    if (((Globe) this).tab == 3) {
		if (((Globe) this).cfase == 0) {
		    if (!((xtGraphics) ((Globe) this).xt).clan.equals(""))
			clanlogopng(((xtGraphics) ((Globe) this).xt).clan);
		    if (((Globe) this).ntab == 0
			&& ((Globe) this).loadednews == 0)
			loadnews();
		    if (((Globe) this).ntab == 1
			&& ((Globe) this).loadwstat == 0)
			loadchamps();
		}
		if (((Globe) this).cfase == 1 && ((Globe) this).em == 1) {
		    String string_564_
			= ((GameSparker) ((Globe) this).gs).temail.getText();
		    string = new StringBuilder().append("101|26|").append
				 (((GameSparker) ((Globe) this).gs).tnick
				      .getText())
				 .append
				 ("|").append
				 (((GameSparker) ((Globe) this).gs).tpass
				      .getText())
				 .append
				 ("|").append
				 (string_564_).append
				 ("|").toString();
		    try {
			((Globe) this).dout.println(string);
			string_318_ = ((Globe) this).din.readLine();
		    } catch (Exception exception) {
			string_318_ = "fail";
		    }
		    if (string_318_.startsWith("OK")) {
			((xtGraphics) ((Globe) this).xt).clan = string_564_;
			((xtGraphics) ((Globe) this).xt).clankey
			    = getSvalue(string_318_, 1);
			((Globe) this).spos5 = 0;
			((Globe) this).lspos5 = 0;
			((Globe) this).cfase = 3;
			((Globe) this).claname = string_564_;
			((Globe) this).loadedc = false;
			((Globe) this).ctab = 0;
			((Globe) this).em = 0;
		    } else if (string_318_.equals("FOUND")) {
			((Globe) this).msg
			    = new StringBuilder().append("The name '").append
				  (string_564_).append
				  ("' is already used by another clan!")
				  .toString();
			((Globe) this).flko = 45;
			((Globe) this).em = 0;
		    } else {
			((Globe) this).msg
			    = "Server error authorizing clan creation, please try again later...";
			((Globe) this).flko = 45;
			((Globe) this).em = 0;
		    }
		}
		if (((Globe) this).cfase == 2) {
		    if (((Globe) this).em == 1) {
			string = "101|27|";
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "";
			}
			((Globe) this).nclns = 0;
			for (String string_565_
				 = getSvalue(string_318_,
					     ((Globe) this).nclns);
			     (!string_565_.equals("")
			      && ((Globe) this).nclns < 20);
			     string_565_ = getSvalue(string_318_,
						     ((Globe) this).nclns)) {
			    ((Globe) this).clanlo[((Globe) this).nclns]
				= string_565_;
			    ((Globe) this).nclns++;
			}
			if (((Globe) this).nclns != 0)
			    ((Globe) this).smsg
				= "Clans with recent activity:";
			else
			    ((Globe) this).smsg
				= "Found no clans with recent activity.";
			((Globe) this).em = 0;
		    }
		    if (((Globe) this).em == 2) {
			string = new StringBuilder().append("101|28|").append
				     (((GameSparker) ((Globe) this).gs)
					  .temail.getText())
				     .append
				     ("").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "";
			}
			((Globe) this).nclns = 0;
			for (String string_566_
				 = getSvalue(string_318_,
					     ((Globe) this).nclns);
			     (!string_566_.equals("")
			      && ((Globe) this).nclns < 20);
			     string_566_ = getSvalue(string_318_,
						     ((Globe) this).nclns)) {
			    ((Globe) this).clanlo[((Globe) this).nclns]
				= string_566_;
			    ((Globe) this).nclns++;
			}
			if (((Globe) this).nclns != 0)
			    ((Globe) this).smsg
				= new StringBuilder().append
				      ("Search result for '").append
				      (((GameSparker) ((Globe) this).gs)
					   .temail.getText())
				      .append
				      ("' in clans:").toString();
			else
			    ((Globe) this).smsg
				= new StringBuilder().append
				      ("Found no clans with the phrase '")
				      .append
				      (((GameSparker) ((Globe) this).gs)
					   .temail.getText())
				      .append
				      ("' in them.").toString();
			((Globe) this).em = 0;
		    }
		}
		if (((Globe) this).cfase == 3) {
		    if (((Globe) this).editc == 33) {
			string = new StringBuilder().append("101|24|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tnick.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tpass.getText())
				     .append
				     ("|").append
				     (((Globe) this).claname).append
				     ("|").append
				     (((Globe) this).member[((Globe) this).em])
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .clanlev.getSelectedIndex() + 1)
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .cmsg.getText())
				     .append
				     ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    ((Globe) this).loadedc = false;
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).editc == 66) {
			string
			    = new StringBuilder().append("101|24|").append
				  (((GameSparker) ((Globe) this).gs).tnick
				       .getText())
				  .append
				  ("|").append
				  (((GameSparker) ((Globe) this).gs).tpass
				       .getText())
				  .append
				  ("|").append
				  (((Globe) this).claname).append
				  ("|").append
				  (((Globe) this).rmember[((Globe) this).em])
				  .append
				  ("|1|New member - just approved.|")
				  .toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    if (((Globe) this).nrmb == 1) {
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
			    }
			    ((Globe) this).loadedc = false;
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).editc == 44) {
			string = new StringBuilder().append("101|25|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tnick.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tpass.getText())
				     .append
				     ("|").append
				     (((Globe) this).claname).append
				     ("|").append
				     (((Globe) this).member[((Globe) this).em])
				     .append
				     ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    ((Globe) this).loadedc = false;
			    if (((Globe) this).member[((Globe) this).em]
				    .toLowerCase
				    ().equals
				(((xtGraphics) ((Globe) this).xt).nickname
				     .toLowerCase())) {
				if (((Globe) this).proname.equals(((xtGraphics)
								   ((Globe)
								    this).xt)
								  .nickname))
				    ((Globe) this).proclan = "";
				((xtGraphics) ((Globe) this).xt).clan = "";
				((xtGraphics) ((Globe) this).xt).clankey = "";
				if (((Globe) this).nmb == 1)
				    ((Globe) this).cfase = 0;
			    }
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).editc == 77) {
			string
			    = new StringBuilder().append("101|25|").append
				  (((GameSparker) ((Globe) this).gs).tnick
				       .getText())
				  .append
				  ("|").append
				  (((GameSparker) ((Globe) this).gs).tpass
				       .getText())
				  .append
				  ("|").append
				  (((Globe) this).claname).append
				  ("|").append
				  (((Globe) this).rmember[((Globe) this).em])
				  .append
				  ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    if (((Globe) this).nrmb == 1) {
				((Globe) this).spos5 = 0;
				((Globe) this).lspos5 = 0;
			    }
			    ((Globe) this).loadedc = false;
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).editc == 99) {
			string = new StringBuilder().append("101|30|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tnick.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tpass.getText())
				     .append
				     ("|").append
				     (((Globe) this).claname).append
				     ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    ((Globe) this).loadedc = false;
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).upload == 5) {
			((Globe) this).upload = 0;
			((Globe) this).loadedc = false;
			if (((Globe) this).editc == 2)
			    ((Globe) this).loadedmyclanbg = -1;
			((Globe) this).editc = 0;
			((Globe) this).refresh = true;
		    }
		    if (!((Globe) this).loadedc) {
			if (!((Globe) this).refresh)
			    loadclan();
			clanlogopng(((Globe) this).claname);
			clanbgpng();
			((Globe) this).refresh = false;
			((Globe) this).loadedc = true;
		    }
		    if (((Globe) this).attachetoclan) {
			string = new StringBuilder().append("101|29|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tnick.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tpass.getText())
				     .append
				     ("|").append
				     (((Globe) this).claname).append
				     ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.indexOf("|") != -1) {
			    ((xtGraphics) ((Globe) this).xt).clan
				= getSvalue(string_318_, 0);
			    ((xtGraphics) ((Globe) this).xt).clankey
				= getSvalue(string_318_, 1);
			}
			((Globe) this).attachetoclan = false;
		    }
		    if (((Globe) this).editc == 55) {
			string = new StringBuilder().append("101|31|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tnick.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .tpass.getText())
				     .append
				     ("|").append
				     (((Globe) this).claname).append
				     ("|").append
				     (((Globe) this).sltit).append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .cmsg.getText())
				     .append
				     ("|").append
				     (((GameSparker) ((Globe) this).gs)
					  .temail.getText())
				     .append
				     ("|").toString();
			try {
			    ((Globe) this).dout.println(string);
			    string_318_ = ((Globe) this).din.readLine();
			} catch (Exception exception) {
			    string_318_ = "fail";
			}
			if (string_318_.equals("OK")) {
			    ((Globe) this).editc = 0;
			    ((Globe) this).loadedlink = false;
			} else
			    ((Globe) this).editc = 5;
		    }
		    if (((Globe) this).ctab == 2) {
			if (((Globe) this).loadedcars == 6) {
			    string
				= new StringBuilder().append("101|32|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).claname).append
				      ("|").append
				      (((Globe) this).selcar).append
				      ("|").toString();
			    try {
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
			    } catch (Exception exception) {
				string_318_ = "fail";
			    }
			    if (string_318_.equals("OK"))
				((Globe) this).loadedcars = -1;
			    else
				((Globe) this).loadedcars = 7;
			}
			if (((Globe) this).loadedcars == 8) {
			    string
				= new StringBuilder().append("101|33|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).claname).append
				      ("|").append
				      (((Globe) this).selcar).append
				      ("|").toString();
			    try {
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
			    } catch (Exception exception) {
				string_318_ = "fail";
			    }
			    if (string_318_.equals("OK"))
				((Globe) this).loadedcars = -1;
			    else
				((Globe) this).loadedcars = 9;
			}
			if (((Globe) this).loadedcars == -1)
			    ((Globe) this).loadedcars = loadclancars();
			if (((Globe) this).loadedcars == 1
			    && !((Globe) this).selcar.equals("Select Car")
			    && ((Globe) this).loadedcar == 0) {
			    if (((xtGraphics) ((Globe) this).xt).sc[0] != 36
				|| (((xtGraphics) ((Globe) this).xt).clan
					.toLowerCase
					().equals
				    (((Globe) this).claname.toLowerCase())))
				((CarDefine) ((Globe) this).cd).haltload = 1;
			    else
				((CarDefine) ((Globe) this).cd).haltload = 2;
			    while (((CarDefine) ((Globe) this).cd).haltload
				   == (((CarDefine) ((Globe) this).cd)
				       .onloadingcar)) {
				/* empty */
			    }
			    ((Globe) this).loadedcar
				= (((Globe) this).cd.loadonlinecar
				   (((Globe) this).selcar,
				    35 + (((CarDefine) ((Globe) this).cd)
					  .haltload)));
			    if (((xtGraphics) ((Globe) this).xt).sc[0] == 36
				&& (((CarDefine) ((Globe) this).cd).haltload
				    == 1)
				&& ((Globe) this).loadedcar > 0) {
				boolean bool = false;
				for (int i = 0;
				     (i < ((ContO) ((Globe) this).bco[36]).npl
				      && !bool);
				     i++) {
				    if (((Plane) ((ContO) (((Globe) this).bco
							   [36])).p[i]).colnum
					== 1) {
					float[] fs = new float[3];
					Color.RGBtoHSB
					    (((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[0],
					     ((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[1],
					     ((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[2],
					     fs);
					((xtGraphics) ((Globe) this).xt)
					    .arnp[0]
					    = fs[0];
					((xtGraphics) ((Globe) this).xt)
					    .arnp[1]
					    = fs[1];
					((xtGraphics) ((Globe) this).xt)
					    .arnp[2]
					    = 1.0F - fs[2];
					bool = true;
				    }
				}
				bool = false;
				for (int i = 0;
				     (i < ((ContO) ((Globe) this).bco[36]).npl
				      && !bool);
				     i++) {
				    if (((Plane) ((ContO) (((Globe) this).bco
							   [36])).p[i]).colnum
					== 2) {
					float[] fs = new float[3];
					Color.RGBtoHSB
					    (((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[0],
					     ((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[1],
					     ((Plane)
					      (((ContO) ((Globe) this).bco[36])
					       .p[i])).c[2],
					     fs);
					((xtGraphics) ((Globe) this).xt)
					    .arnp[3]
					    = fs[0];
					((xtGraphics) ((Globe) this).xt)
					    .arnp[4]
					    = fs[1];
					((xtGraphics) ((Globe) this).xt)
					    .arnp[5]
					    = 1.0F - fs[2];
					bool = true;
				    }
				}
			    }
			}
			if (((Globe) this).loadedcars == 2)
			    ((Globe) this).loadedcars = loadaddcars();
		    }
		    if (((Globe) this).ctab == 3) {
			if (((Globe) this).loadedstages == 6) {
			    string
				= new StringBuilder().append("101|34|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).claname).append
				      ("|").append
				      (((Globe) this).selstage).append
				      ("|").toString();
			    try {
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
			    } catch (Exception exception) {
				string_318_ = "fail";
			    }
			    if (string_318_.equals("OK"))
				((Globe) this).loadedstages = -1;
			    else
				((Globe) this).loadedstages = 7;
			}
			if (((Globe) this).loadedstages == 8) {
			    string
				= new StringBuilder().append("101|35|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tnick.getText())
				      .append
				      ("|").append
				      (((GameSparker) ((Globe) this).gs)
					   .tpass.getText())
				      .append
				      ("|").append
				      (((Globe) this).claname).append
				      ("|").append
				      (((Globe) this).selstage).append
				      ("|").toString();
			    try {
				((Globe) this).dout.println(string);
				string_318_ = ((Globe) this).din.readLine();
			    } catch (Exception exception) {
				string_318_ = "fail";
			    }
			    if (string_318_.equals("OK"))
				((Globe) this).loadedstages = -1;
			    else
				((Globe) this).loadedstages = 9;
			}
			if (((Globe) this).loadedstages == -1)
			    ((Globe) this).loadedstages = loadclanstages();
			if (((Globe) this).loadedstages == 1
			    && !((Globe) this).selstage.equals("Select Stage")
			    && ((Globe) this).loadedstage == 0) {
			    ((Trackers) ((CarDefine) ((Globe) this).cd).t).nt
				= 0;
			    if (((Globe) this).gs.loadstagePreview
				(-2, ((Globe) this).selstage,
				 ((Globe) this).co, ((Globe) this).bco,
				 ((Globe) this).m, ((Globe) this).cp)) {
				((Globe) this).loadedstage = 1;
				((Medium) ((Globe) this).m).ptr = 0;
				((Medium) ((Globe) this).m).ptcnt = -10;
				((Medium) ((Globe) this).m).hit = 45000;
				((Medium) ((Globe) this).m).fallen = 0;
				((Medium) ((Globe) this).m).nrnd = 0;
			    } else
				((Globe) this).loadedstage = -1;
			}
			if (((Globe) this).loadedstages == 2)
			    ((Globe) this).loadedstages = loadaddstages();
		    }
		    if (((Globe) this).ctab == 4
			&& !((Globe) this).loadedlink) {
			loadclanlink();
			((Globe) this).loadedlink = true;
		    }
		}
	    }
	    if (((Globe) this).upload != 0) {
		if (((Globe) this).filename.toLowerCase().endsWith(".gif")
		    || ((Globe) this).filename.toLowerCase().endsWith(".jpg")
		    || ((Globe) this).filename.toLowerCase().endsWith(".jpeg")
		    || ((Globe) this).filename.toLowerCase()
			   .endsWith(".png")) {
		    File file = new File(((Globe) this).filename);
		    if (file.exists()) {
			int i = (int) file.length();
			if (i < 1048576) {
			    if (((Globe) this).upload != 0) {
				((Globe) this).upload = 2;
				try {
				    int i_567_ = 2;
				    if (((Globe) this).tab == 1
					&& ((Globe) this).edit == 2)
					i_567_ = 3;
				    String string_568_ = "";
				    if (((Globe) this).tab == 3) {
					if (((Globe) this).editc == 1)
					    i_567_ = 22;
					if (((Globe) this).editc == 2)
					    i_567_ = 23;
					string_568_
					    = new StringBuilder().append
						  ("").append
						  (((Globe) this).claname)
						  .append
						  ("|").toString();
				    }
				    string = new StringBuilder().append
						 ("101|").append
						 (i_567_).append
						 ("|").append
						 (((GameSparker)
						   ((Globe) this).gs)
						      .tnick.getText())
						 .append
						 ("|").append
						 (((GameSparker)
						   ((Globe) this).gs)
						      .tpass.getText())
						 .append
						 ("|").append
						 (i).append
						 ("|").append
						 (string_568_).append
						 ("").toString();
				    ((Globe) this).dout.println(string);
				    string_318_
					= ((Globe) this).din.readLine();
				    if (string_318_.equals("OK")) {
					FileInputStream fileinputstream
					    = new FileInputStream(file);
					byte[] is = new byte[i];
					fileinputstream.read(is);
					fileinputstream.close();
					DataOutputStream dataoutputstream
					    = (new DataOutputStream
					       (((Globe) this).socket
						    .getOutputStream()));
					if (((Globe) this).upload != 0)
					    ((Globe) this).upload = 3;
					((Globe) this).perc = 0;
					int i_569_ = 0;
					while (i_569_ < i
					       && ((Globe) this).upload != 0) {
					    int i_570_ = 10240;
					    if (i_569_ + i_570_ > i)
						i_570_ = i - i_569_;
					    dataoutputstream.write(is, i_569_,
								   i_570_);
					    i_569_ += i_570_;
					    ((Globe) this).perc
						= (int) ((float) i_569_
							 / (float) i * 100.0F);
					}
					if (((Globe) this).upload != 0) {
					    string_318_ = ((Globe) this)
							      .din.readLine();
					    if (string_318_.equals("CR"))
						((Globe) this).upload = 4;
					    else {
						((Globe) this).msg
						    = "Failed to create image online, server error!";
						((Globe) this).flko = 45;
						((Globe) this).upload = 0;
					    }
					    string_318_ = ((Globe) this)
							      .din.readLine();
					    if (string_318_.equals("OK"))
						((Globe) this).upload = 5;
					} else {
					    try {
						((Globe) this).socket.close();
						((Globe) this).socket = null;
						((Globe) this).din.close();
						((Globe) this).din = null;
						((Globe) this).dout.close();
						((Globe) this).dout = null;
						((Globe) this).connector
						    = null;
					    } catch (Exception exception) {
						/* empty */
					    }
					    try {
						((Globe) this).socket
						    = new Socket((((Login)
								   ((Globe)
								    this).lg)
								  .servers[0]),
								 7061);
						((Globe) this).din
						    = (new BufferedReader
						       (new InputStreamReader
							(((Globe) this)
							     .socket
							     .getInputStream
							 ())));
						((Globe) this).dout
						    = (new PrintWriter
						       (((Globe) this)
							    .socket
							    .getOutputStream(),
							true));
					    } catch (Exception exception) {
						/* empty */
					    }
					}
				    } else {
					((Globe) this).msg
					    = "Failed to authenticate to start an uploading connection!";
					((Globe) this).flko = 45;
					((Globe) this).upload = 0;
				    }
				} catch (Exception exception) {
				    ((Globe) this).msg
					= "Failed to upload image, unknown error!";
				    ((Globe) this).flko = 45;
				    ((Globe) this).upload = 0;
				    try {
					((Globe) this).socket.close();
					((Globe) this).socket = null;
					((Globe) this).din.close();
					((Globe) this).din = null;
					((Globe) this).dout.close();
					((Globe) this).dout = null;
					((Globe) this).connector = null;
				    } catch (Exception exception_571_) {
					/* empty */
				    }
				    try {
					((Globe) this).socket
					    = new Socket((((Login)
							   ((Globe) this).lg)
							  .servers[0]),
							 7061);
					((Globe) this).din
					    = (new BufferedReader
					       (new InputStreamReader
						(((Globe) this).socket
						     .getInputStream())));
					((Globe) this).dout
					    = (new PrintWriter
					       (((Globe) this).socket
						    .getOutputStream(),
						true));
				    } catch (Exception exception_572_) {
					/* empty */
				    }
				}
			    }
			} else {
			    ((Globe) this).msg
				= "Uploaded image must be less than 1MB in size!";
			    ((Globe) this).flko = 45;
			    ((Globe) this).upload = 0;
			}
		    } else {
			((Globe) this).msg
			    = "The file chosen is invalid or does not exist!";
			((Globe) this).flko = 45;
			((Globe) this).upload = 0;
		    }
		} else {
		    ((Globe) this).msg
			= "Uploaded image must be JPEG, GIF or PNG!";
		    ((Globe) this).flko = 45;
		    ((Globe) this).upload = 0;
		}
	    }
	    if (((Globe) this).uploadt == 5) {
		((Globe) this).uploadt = 0;
		((Globe) this).msg = "";
	    }
	    if (((Globe) this).uploadt != 0) {
		File file = new File(((Globe) this).filename);
		if (file.exists()) {
		    int i = (int) file.length();
		    if (i < 716800) {
			((xtGraphics) ((Globe) this).xt).strack
			    = new RadicalMod(((Globe) this).filename, true);
			if (((RadicalMod)
			     ((xtGraphics) ((Globe) this).xt).strack).loaded
			    == 2) {
			    ((Globe) this).trackvol
				= (int) (220.0F
					 / ((float) ((RadicalMod)
						     (((xtGraphics)
						       ((Globe) this).xt)
						      .strack)).rvol
					    / 3750.0F));
			    ((xtGraphics) ((Globe) this).xt).strack.unload();
			    if (((Globe) this).uploadt != 0) {
				((Globe) this).uploadt = 2;
				try {
				    string
					= new StringBuilder().append
					      ("101|4|").append
					      (((GameSparker)
						((Globe) this).gs)
						   .tnick.getText())
					      .append
					      ("|").append
					      (((GameSparker)
						((Globe) this).gs)
						   .tpass.getText())
					      .append
					      ("|").append
					      (((Globe) this).trackname).append
					      ("|").append
					      (((Globe) this).trackvol).append
					      ("|").append
					      (i).append
					      ("|").toString();
				    ((Globe) this).dout.println(string);
				    string_318_
					= ((Globe) this).din.readLine();
				    if (string_318_.equals("OK")) {
					string_318_
					    = ((Globe) this).din.readLine();
					if (((Globe) this).uploadt != 0) {
					    if (string_318_.equals("UPLOAD")) {
						((Globe) this).uploadt = 3;
						FileInputStream fileinputstream
						    = (new FileInputStream
						       (file));
						byte[] is = new byte[i];
						fileinputstream.read(is);
						fileinputstream.close();
						DataOutputStream dataoutputstream
						    = (new DataOutputStream
						       (((Globe) this)
							    .socket
							    .getOutputStream
							()));
						dataoutputstream.write(is, 0,
								       i);
						((Globe) this).uploadt = 4;
						string_318_
						    = ((Globe) this).din
							  .readLine();
					    }
					    if (string_318_.equals("FOUND")) {
						((Globe) this).uploadt = 4;
						string_318_
						    = ((Globe) this).din
							  .readLine();
					    }
					    if (string_318_.equals("OK")) {
						((Globe) this).themesong
						    = ((Globe) this).trackname;
						((Globe) this).uploadt = 5;
					    } else if (string_318_
							   .equals("EXIST")) {
						((Globe) this).msg
						    = "Another track with the same name already exists, please rename you file!";
						((Globe) this).flko = 45;
						((Globe) this).uploadt = 0;
					    } else {
						((Globe) this).msg
						    = "Failed to add MOD Track to your profile, unknown error!";
						((Globe) this).flko = 45;
						((Globe) this).uploadt = 0;
					    }
					} else {
					    try {
						((Globe) this).socket.close();
						((Globe) this).socket = null;
						((Globe) this).din.close();
						((Globe) this).din = null;
						((Globe) this).dout.close();
						((Globe) this).dout = null;
						((Globe) this).connector
						    = null;
					    } catch (Exception exception) {
						/* empty */
					    }
					    try {
						((Globe) this).socket
						    = new Socket((((Login)
								   ((Globe)
								    this).lg)
								  .servers[0]),
								 7061);
						((Globe) this).din
						    = (new BufferedReader
						       (new InputStreamReader
							(((Globe) this)
							     .socket
							     .getInputStream
							 ())));
						((Globe) this).dout
						    = (new PrintWriter
						       (((Globe) this)
							    .socket
							    .getOutputStream(),
							true));
					    } catch (Exception exception) {
						/* empty */
					    }
					}
				    } else {
					((Globe) this).msg
					    = "Failed to authenticate to start an uploading connection!";
					((Globe) this).flko = 45;
					((Globe) this).uploadt = 0;
				    }
				} catch (Exception exception) {
				    ((Globe) this).msg
					= "Failed to upload track, unknown error!";
				    ((Globe) this).flko = 45;
				    ((Globe) this).uploadt = 0;
				    try {
					((Globe) this).socket.close();
					((Globe) this).socket = null;
					((Globe) this).din.close();
					((Globe) this).din = null;
					((Globe) this).dout.close();
					((Globe) this).dout = null;
					((Globe) this).connector = null;
				    } catch (Exception exception_573_) {
					/* empty */
				    }
				    try {
					((Globe) this).socket
					    = new Socket((((Login)
							   ((Globe) this).lg)
							  .servers[0]),
							 7061);
					((Globe) this).din
					    = (new BufferedReader
					       (new InputStreamReader
						(((Globe) this).socket
						     .getInputStream())));
					((Globe) this).dout
					    = (new PrintWriter
					       (((Globe) this).socket
						    .getOutputStream(),
						true));
				    } catch (Exception exception_574_) {
					/* empty */
				    }
				}
			    }
			} else {
			    ((xtGraphics) ((Globe) this).xt).strack.unload();
			    ((Globe) this).msg
				= "The file choosen is not a valid MOD Track!";
			    ((Globe) this).flko = 45;
			    ((Globe) this).uploadt = 0;
			}
		    } else {
			((Globe) this).msg
			    = "Uploaded file must be less than 250KB in size!";
			((Globe) this).flko = 45;
			((Globe) this).uploadt = 0;
		    }
		} else {
		    ((Globe) this).msg
			= "The file chosen is invalid or does not exist!";
		    ((Globe) this).flko = 45;
		    ((Globe) this).uploadt = 0;
		}
	    }
	    if (((Globe) this).playt == 1) {
		((xtGraphics) ((Globe) this).xt).strack
		    = new RadicalMod(((Globe) this).themesong,
				     ((Globe) this).trackvol, 8000, 125, false,
				     true);
		((xtGraphics) ((Globe) this).xt).strack.play();
		((Globe) this).playt = 2;
	    }
	    domelogos();
	    try {
		if (((Globe) this).connector != null) {
		    /* empty */
		}
		Thread.sleep(600L);
	    } catch (InterruptedException interruptedexception) {
		/* empty */
	    }
	}
	onexit();
    }
    
    public void onexit() {
	onexitpro();
	((Globe) this).gs.hidefields();
	((CarDefine) ((Globe) this).cd).acname = "";
	((CarDefine) ((Globe) this).cd).action = 0;
	((CarDefine) ((Globe) this).cd).staction = 0;
	((CarDefine) ((Globe) this).cd).onstage = "";
	((Globe) this).addstage = 0;
	((Globe) this).npf = -1;
	((Globe) this).editc = 0;
	((Globe) this).openc = 0;
	((Globe) this).readmsg = 0;
	((Globe) this).loadmsgs = -1;
	((Globe) this).readclan = 0;
	if (((CarDefine) ((Globe) this).cd).haltload == 2) {
	    ((CarDefine) ((Globe) this).cd).haltload = 1;
	    ((CarDefine) ((Globe) this).cd).lcardate[1] = 0;
	}
	if (((CarDefine) ((Globe) this).cd).haltload == 1) {
	    if (((xtGraphics) ((Globe) this).xt).sc[0] == 36) {
		if (!((xtGraphics) ((Globe) this).xt).clan.toLowerCase()
			 .equals(((Globe) this).claname.toLowerCase()))
		    ((Globe) this).loadedcars = -1;
	    } else {
		((CarDefine) ((Globe) this).cd).haltload = 0;
		((CarDefine) ((Globe) this).cd).lcardate[0] = 0;
	    }
	}
	((Medium) ((Globe) this).m).crs = true;
	((Medium) ((Globe) this).m).focus_point = 400;
	((Medium) ((Globe) this).m).x = -335;
	((Medium) ((Globe) this).m).y = 0;
	((Medium) ((Globe) this).m).z = -50;
	((Medium) ((Globe) this).m).xz = 0;
	((Medium) ((Globe) this).m).zy = 20;
	((Medium) ((Globe) this).m).ground = -2000;
	try {
	    ((Globe) this).socket.close();
	    ((Globe) this).socket = null;
	    ((Globe) this).din.close();
	    ((Globe) this).din = null;
	    ((Globe) this).dout.close();
	    ((Globe) this).dout = null;
	    ((Globe) this).connector = null;
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public void onexitpro() {
	((Globe) this).edit = 0;
	((Globe) this).upload = 0;
	((Globe) this).uploadt = 0;
	((Globe) this).sfreq = 0;
	if (((Globe) this).playt == 2) {
	    ((xtGraphics) ((Globe) this).xt).strack.unload();
	    ((Globe) this).playt = 0;
	}
	((Globe) this).protab = 0;
	((Smenu) ((GameSparker) ((Globe) this).gs).proitem).show = false;
	((Globe) this).addstage = 0;
    }
    
    public void stopallnow() {
	if (((Globe) this).connector != null) {
	    ((Globe) this).connector.stop();
	    ((Globe) this).connector = null;
	}
	try {
	    ((Globe) this).socket.close();
	    ((Globe) this).socket = null;
	    ((Globe) this).din.close();
	    ((Globe) this).din = null;
	    ((Globe) this).dout.close();
	    ((Globe) this).dout = null;
	    ((Globe) this).connector = null;
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public void trunsent() {
	for (int i = 0; i < 3; i++)
	    ((Globe) this).aboutxt[i] = "";
	if (!((Globe) this).sentance.equals("")) {
	    ((Globe) this).rd.setFont(new Font("Tahoma", 1, 11));
	    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
	    int i = 0;
	    int i_575_ = 0;
	    int i_576_ = 0;
	    int i_577_ = 0;
	    boolean bool = false;
	    for (/**/; i_575_ < ((Globe) this).sentance.length(); i_575_++) {
		String string
		    = new StringBuilder().append("").append
			  (((Globe) this).sentance.charAt(i_575_)).toString();
		if (string.equals(" "))
		    i_576_ = i_575_;
		if (i < 3) {
		    StringBuilder stringbuilder = new StringBuilder();
		    String[] strings = ((Globe) this).aboutxt;
		    int i_578_ = i;
		    strings[i_578_]
			= stringbuilder.append(strings[i_578_]).append
			      (string).toString();
		    if (((Globe) this).ftm
			    .stringWidth(((Globe) this).aboutxt[i])
			> 276) {
			if (i_576_ != i_577_) {
			    ((Globe) this).aboutxt[i]
				= ((Globe) this).sentance.substring(i_577_,
								    i_576_);
			    i_575_ = i_576_;
			    i_577_ = i_575_;
			} else if (i == 2)
			    bool = true;
			i++;
		    }
		} else {
		    if (bool)
			((Globe) this).aboutxt[2]
			    = (((Globe) this).aboutxt[2].substring
			       (0, ((Globe) this).aboutxt[2].length() - 3));
		    StringBuilder stringbuilder = new StringBuilder();
		    String[] strings = ((Globe) this).aboutxt;
		    int i_579_ = 2;
		    strings[i_579_]
			= stringbuilder.append(strings[i_579_]).append
			      ("...").toString();
		    i_575_ = ((Globe) this).sentance.length();
		}
	    }
	}
	((Globe) this).nab = 0;
	for (int i = 0; i < 3 && !((Globe) this).aboutxt[i].equals(""); i++) {
	    ((Globe) this).aboutxt[i] = ((Globe) this).aboutxt[i].trim();
	    ((Globe) this).nab++;
	}
    }
    
    public void roomlogos(String[] strings, int i) {
	for (int i_580_ = 0; i_580_ < 2; i_580_++) {
	    boolean bool = true;
	    String string = "";
	    for (int i_581_ = 0; i_581_ < i; i_581_++) {
		bool = false;
		for (int i_582_ = 0; i_582_ < ((Globe) this).nlg; i_582_++) {
		    if (strings[i_581_].toLowerCase().equals
			(((Globe) this).logos[i_582_].toLowerCase())) {
			bool = true;
			break;
		    }
		}
		if (!bool) {
		    string = strings[i_581_].toLowerCase();
		    break;
		}
	    }
	    if (bool)
		break;
	    ((Globe) this).logos[((Globe) this).nlg] = string;
	    ((Globe) this).logon[((Globe) this).nlg] = false;
	    try {
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/profiles/")
			    .append
			    (((Globe) this).logos[((Globe) this).nlg]).append
			    ("/logo.png").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string_583_ = url.openConnection().getContentType();
		if (string_583_.equals("image/png")) {
		    ((Globe) this).logoi[((Globe) this).nlg]
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).mt.addImage((((Globe) this).logoi
						[((Globe) this).nlg]),
					       ((Globe) this).nlg);
		    ((Globe) this).logon[((Globe) this).nlg] = true;
		}
	    } catch (Exception exception) {
		/* empty */
	    }
	    ((Globe) this).nlg++;
	    if (((Globe) this).nlg == 200)
		((Globe) this).nlg = 0;
	}
    }
    
    public void domelogos() {
	for (int i = 0; i < 5; i++) {
	    boolean bool = true;
	    boolean bool_584_ = false;
	    String string = "";
	    String string_585_ = "";
	    if (((Globe) this).freq == 1) {
		bool = false;
		for (int i_586_ = 0; i_586_ < ((Globe) this).nlg; i_586_++) {
		    if (((Globe) this).freqname.toLowerCase().equals
			(((Globe) this).logos[i_586_].toLowerCase())) {
			bool = true;
			break;
		    }
		}
		if (!bool)
		    string = ((Globe) this).freqname.toLowerCase();
	    }
	    if (bool && ((Globe) this).loadednews == 1) {
		for (int i_587_ = 0; i_587_ < 4; i_587_++) {
		    if (!((Globe) this).newplayers[i_587_].equals("")) {
			bool = false;
			for (int i_588_ = 0; i_588_ < ((Globe) this).nlg;
			     i_588_++) {
			    if (((Globe) this).newplayers[i_587_].toLowerCase
				    ().equals
				(((Globe) this).logos[i_588_].toLowerCase())) {
				bool = true;
				break;
			    }
			}
			if (!bool) {
			    string = ((Globe) this).newplayers[i_587_]
					 .toLowerCase();
			    break;
			}
		    }
		}
	    }
	    if (bool && ((Globe) this).loadednews == 1) {
		for (int i_589_ = 0; i_589_ < 5; i_589_++) {
		    if (((Globe) this).nwarbs[i_589_] > 0) {
			bool = false;
			String string_590_
			    = new StringBuilder().append("#").append
				  (((Globe) this).nwclan[i_589_]).append
				  ("#").toString();
			for (int i_591_ = 0; i_591_ < ((Globe) this).nlg;
			     i_591_++) {
			    if (string_590_.toLowerCase().equals
				(((Globe) this).logos[i_591_].toLowerCase())) {
				bool = true;
				break;
			    }
			}
			if (!bool) {
			    string = string_590_.toLowerCase();
			    bool_584_ = true;
			    string_585_ = ((Globe) this).nwclan[i_589_];
			    break;
			}
		    }
		}
	    }
	    if (bool && ((Globe) this).loadwstat == 1) {
		for (int i_592_ = 0; i_592_ < 5; i_592_++) {
		    if (((Globe) this).ncc > 0) {
			bool = false;
			String string_593_
			    = new StringBuilder().append("#").append
				  (((Globe) this).conclan[i_592_]).append
				  ("#").toString();
			for (int i_594_ = 0; i_594_ < ((Globe) this).nlg;
			     i_594_++) {
			    if (string_593_.toLowerCase().equals
				(((Globe) this).logos[i_594_].toLowerCase())) {
				bool = true;
				break;
			    }
			}
			if (!bool) {
			    string = string_593_.toLowerCase();
			    bool_584_ = true;
			    string_585_ = ((Globe) this).conclan[i_592_];
			    break;
			}
		    }
		}
	    }
	    if (bool && ((Globe) this).ni > 0) {
		for (int i_595_ = 0; i_595_ < ((Globe) this).ni; i_595_++) {
		    bool = false;
		    String string_596_
			= new StringBuilder().append("#").append
			      (((Globe) this).iclan[i_595_]).append
			      ("#").toString();
		    for (int i_597_ = 0; i_597_ < ((Globe) this).nlg;
			 i_597_++) {
			if (string_596_.toLowerCase().equals
			    (((Globe) this).logos[i_597_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = string_596_.toLowerCase();
			bool_584_ = true;
			string_585_ = ((Globe) this).iclan[i_595_];
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).nclns > 0) {
		for (int i_598_ = 0; i_598_ < ((Globe) this).nclns; i_598_++) {
		    bool = false;
		    String string_599_
			= new StringBuilder().append("#").append
			      (((Globe) this).clanlo[i_598_]).append
			      ("#").toString();
		    for (int i_600_ = 0; i_600_ < ((Globe) this).nlg;
			 i_600_++) {
			if (string_599_.toLowerCase().equals
			    (((Globe) this).logos[i_600_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = string_599_.toLowerCase();
			bool_584_ = true;
			string_585_ = ((Globe) this).clanlo[i_598_];
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).nrmb > 0 && ((Globe) this).showreqs) {
		for (int i_601_ = 0; i_601_ < ((Globe) this).nrmb; i_601_++) {
		    bool = false;
		    for (int i_602_ = 0; i_602_ < ((Globe) this).nlg;
			 i_602_++) {
			if (((Globe) this).rmember[i_601_].toLowerCase().equals
			    (((Globe) this).logos[i_602_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).rmember[i_601_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).nmb > 0) {
		for (int i_603_ = 0; i_603_ < ((Globe) this).nmb; i_603_++) {
		    bool = false;
		    for (int i_604_ = 0; i_604_ < ((Globe) this).nlg;
			 i_604_++) {
			if (((Globe) this).member[i_603_].toLowerCase().equals
			    (((Globe) this).logos[i_604_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).member[i_603_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).nclns > 0) {
		for (int i_605_ = 0; i_605_ < ((Globe) this).ncln; i_605_++) {
		    bool = false;
		    for (int i_606_ = 0; i_606_ < ((Globe) this).nlg;
			 i_606_++) {
			if (((Globe) this).clname[i_605_].toLowerCase().equals
			    (((Globe) this).logos[i_606_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).clname[i_605_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).npf > 0) {
		for (int i_607_ = 0; i_607_ < ((Globe) this).npf; i_607_++) {
		    bool = false;
		    for (int i_608_ = 0; i_608_ < ((Globe) this).nlg;
			 i_608_++) {
			if (((Globe) this).fname[i_607_].toLowerCase().equals
			    (((Globe) this).logos[i_608_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).fname[i_607_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool && ((Globe) this).nm > 0) {
		for (int i_609_ = 0; i_609_ < ((Globe) this).nm; i_609_++) {
		    bool = false;
		    for (int i_610_ = 0; i_610_ < ((Globe) this).nlg;
			 i_610_++) {
			if (((Globe) this).mname[i_609_].toLowerCase().equals
			    (((Globe) this).logos[i_610_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).mname[i_609_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool) {
		for (int i_611_ = 0; i_611_ < ((Globe) this).npo; i_611_++) {
		    bool = false;
		    for (int i_612_ = 0; i_612_ < ((Globe) this).nlg;
			 i_612_++) {
			if (((Globe) this).pname[i_611_].toLowerCase().equals
			    (((Globe) this).logos[i_612_].toLowerCase())) {
			    bool = true;
			    break;
			}
		    }
		    if (!bool) {
			string = ((Globe) this).pname[i_611_].toLowerCase();
			break;
		    }
		}
	    }
	    if (bool)
		break;
	    ((Globe) this).logos[((Globe) this).nlg] = string;
	    ((Globe) this).logon[((Globe) this).nlg] = false;
	    try {
		String string_613_
		    = new StringBuilder().append
			  ("http://multiplayer.needformadness.com/profiles/")
			  .append
			  (((Globe) this).logos[((Globe) this).nlg]).append
			  ("/logo.png").toString();
		if (bool_584_)
		    string_613_
			= new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (string_585_).append
			      ("/logo.png").toString();
		URL url = new URL(string_613_);
		url.openConnection().setConnectTimeout(2000);
		String string_614_ = url.openConnection().getContentType();
		if (string_614_.equals("image/png")) {
		    ((Globe) this).logoi[((Globe) this).nlg]
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).mt.addImage((((Globe) this).logoi
						[((Globe) this).nlg]),
					       ((Globe) this).nlg);
		    ((Globe) this).logon[((Globe) this).nlg] = true;
		}
	    } catch (Exception exception) {
		/* empty */
	    }
	    ((Globe) this).nlg++;
	    if (((Globe) this).nlg == 200)
		((Globe) this).nlg = 0;
	}
    }
    
    public boolean drawl(Graphics2D graphics2d, String string, int i,
			 int i_615_, boolean bool) {
	boolean bool_616_ = false;
	int i_617_ = -1;
	for (int i_618_ = 0; i_618_ < ((Globe) this).nlg; i_618_++) {
	    if (string.toLowerCase()
		    .equals(((Globe) this).logos[i_618_].toLowerCase())) {
		i_617_ = i_618_;
		break;
	    }
	}
	if (i_617_ != -1 && ((Globe) this).logon[i_617_]) {
	    if (!bool)
		graphics2d.setComposite(AlphaComposite.getInstance(3, 0.1F));
	    graphics2d.drawImage(((Globe) this).logoi[i_617_], i, i_615_,
				 null);
	    bool_616_ = ((Globe) this).mt.checkID(i_617_);
	    if (!bool)
		graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
	}
	return bool_616_;
    }
    
    public void logopng() {
	int i = -1;
	boolean bool = false;
	for (int i_619_ = 0; i_619_ < ((Globe) this).nlg; i_619_++) {
	    if (((Globe) this).proname.toLowerCase()
		    .equals(((Globe) this).logos[i_619_].toLowerCase())) {
		i = i_619_;
		if (((Globe) this).logon[i] && !((Globe) this).refresh) {
		    bool = true;
		    ((Globe) this).logol = true;
		}
		break;
	    }
	}
	if (!bool) {
	    if (i == -1) {
		i = ((Globe) this).nlg;
		((Globe) this).nlg++;
		if (((Globe) this).nlg == 200)
		    ((Globe) this).nlg = 0;
	    }
	    ((Globe) this).logos[i] = ((Globe) this).proname.toLowerCase();
	    try {
		String string = "";
		if (((Globe) this).refresh)
		    string = new StringBuilder().append("?req=").append
				 ((int) (Math.random() * 1000.0)).append
				 ("").toString();
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/profiles/")
			    .append
			    (((Globe) this).proname).append
			    ("/logo.png").append
			    (string).append
			    ("").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string_620_ = url.openConnection().getContentType();
		if (string_620_.equals("image/png")) {
		    ((Globe) this).logoi[i]
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).mt.addImage(((Globe) this).logoi[i], i);
		    ((Globe) this).logon[i] = true;
		} else
		    ((Globe) this).logon[i] = false;
	    } catch (Exception exception) {
		/* empty */
	    }
	    ((Globe) this).logol = ((Globe) this).logon[i];
	}
    }
    
    public void clanlogopng(String string) {
	int i = -1;
	boolean bool = false;
	String string_621_ = new StringBuilder().append("#").append
				 (string.toLowerCase()).append
				 ("#").toString();
	for (int i_622_ = 0; i_622_ < ((Globe) this).nlg; i_622_++) {
	    if (string_621_.equals(((Globe) this).logos[i_622_])) {
		i = i_622_;
		if (((Globe) this).logon[i] && !((Globe) this).refresh)
		    bool = true;
		break;
	    }
	}
	if (!bool) {
	    if (i == -1) {
		i = ((Globe) this).nlg;
		((Globe) this).nlg++;
		if (((Globe) this).nlg == 200)
		    ((Globe) this).nlg = 0;
	    }
	    ((Globe) this).logos[i] = string_621_;
	    try {
		String string_623_ = "";
		if (((Globe) this).refresh)
		    string_623_ = new StringBuilder().append("?req=").append
				      ((int) (Math.random() * 1000.0)).append
				      ("").toString();
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/clans/")
			    .append
			    (string).append
			    ("/logo.png").append
			    (string_623_).append
			    ("").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string_624_ = url.openConnection().getContentType();
		if (string_624_.equals("image/png")) {
		    ((Globe) this).logoi[i]
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).mt.addImage(((Globe) this).logoi[i], i);
		    ((Globe) this).logon[i] = true;
		} else
		    ((Globe) this).logon[i] = false;
	    } catch (Exception exception) {
		/* empty */
	    }
	}
    }
    
    public void avatarpng() {
	((Globe) this).avatarl = false;
	String string = "";
	if (((Globe) this).refresh)
	    string = new StringBuilder().append("?req=").append
			 ((int) (Math.random() * 1000.0)).append
			 ("").toString();
	try {
	    URL url = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/profiles/")
			    .append
			    (((Globe) this).proname).append
			    ("/avatar.png").append
			    (string).append
			    ("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    String string_625_ = url.openConnection().getContentType();
	    if (string_625_.equals("image/png")) {
		((Globe) this).avatar
		    = Toolkit.getDefaultToolkit().createImage(url);
		((Globe) this).avatarl = true;
	    }
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public void clanbgpng() {
	((Globe) this).clanbgl = false;
	String string = "";
	if (((Globe) this).refresh)
	    string = new StringBuilder().append("?req=").append
			 ((int) (Math.random() * 1000.0)).append
			 ("").toString();
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((Globe) this).claname).append
			      ("/bg.jpg").append
			      (string).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string_626_ = url.openConnection().getContentType();
	    if (string_626_.equals("image/jpeg")) {
		((Globe) this).clanbg
		    = Toolkit.getDefaultToolkit().createImage(url);
		((Globe) this).clanbgl = true;
	    }
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public void intclanbgpng(String string) {
	if (!((Globe) this).intclanlo.equals(string)) {
	    ((Globe) this).intclanbgloaded = false;
	    try {
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/clans/")
			    .append
			    (string).append
			    ("/bg.jpg").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string_627_ = url.openConnection().getContentType();
		if (string_627_.equals("image/jpeg")) {
		    ((Globe) this).intclanbg
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).intclanbgloaded = true;
		}
	    } catch (Exception exception) {
		/* empty */
	    }
	    ((Globe) this).intclanlo = string;
	}
    }
    
    public void loadmyclanbg() {
	if (((Globe) this).loadedmyclanbg <= 0) {
	    String string = "";
	    if (((Globe) this).loadedmyclanbg == -1)
		string = new StringBuilder().append("?req=").append
			     ((int) (Math.random() * 1000.0)).append
			     ("").toString();
	    ((Globe) this).loadedmyclanbg = 2;
	    try {
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/clans/")
			    .append
			    (((xtGraphics) ((Globe) this).xt).clan).append
			    ("/bg.jpg").append
			    (string).append
			    ("").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string_628_ = url.openConnection().getContentType();
		if (string_628_.equals("image/jpeg")) {
		    ((Globe) this).myclanbg
			= Toolkit.getDefaultToolkit().createImage(url);
		    ((Globe) this).loadedmyclanbg = 1;
		}
	    } catch (Exception exception) {
		/* empty */
	    }
	}
    }
    
    public void loadclan() {
	((Globe) this).notclan = false;
	int i = 0;
	String[] strings = new String[20];
	int[] is = new int[20];
	String[] strings_629_ = new String[20];
	((Globe) this).showreqs = false;
	((Globe) this).nrmb = 0;
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((Globe) this).claname).append
			      ("/members.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string = url.openConnection().getContentType();
	    if (string.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_630_ = "";
		while ((string_630_ = datainputstream.readLine()) != null
		       && i < 20) {
		    string_630_ = string_630_.trim();
		    String string_631_ = getSvalue(string_630_, 0);
		    if (!string_631_.equals("")) {
			int i_632_ = getvalue(string_630_, 1);
			if (i_632_ != 0) {
			    strings[i] = string_631_;
			    is[i] = i_632_;
			    strings_629_[i] = getSvalue(string_630_, 2);
			    i++;
			} else if (((Globe) this).nrmb < 100) {
			    ((Globe) this).rmember[((Globe) this).nrmb]
				= string_631_;
			    ((Globe) this).nrmb++;
			}
		    }
		}
		datainputstream.close();
	    } else
		((Globe) this).notclan = true;
	} catch (Exception exception) {
	    /* empty */
	}
	((Globe) this).nmb = 0;
	if (!((Globe) this).notclan) {
	    for (int i_633_ = 7; i_633_ > 0; i_633_--) {
		for (int i_634_ = 0; i_634_ < i; i_634_++) {
		    if (is[i_634_] == i_633_) {
			((Globe) this).member[((Globe) this).nmb]
			    = strings[i_634_];
			((Globe) this).mrank[((Globe) this).nmb]
			    = strings_629_[i_634_];
			((Globe) this).mlevel[((Globe) this).nmb] = is[i_634_];
			((Globe) this).nmb++;
		    }
		}
	    }
	    for (int i_635_ = 0; i_635_ < ((Globe) this).nmb; i_635_++) {
		if (((xtGraphics) ((Globe) this).xt).nickname.toLowerCase()
			.equals(((Globe) this).member[i_635_].toLowerCase())) {
		    if ((((Globe) this).mlevel[i_635_] == 7 || i_635_ == 0)
			&& ((Globe) this).nrmb != 0)
			((Globe) this).showreqs = true;
		    if (!((xtGraphics) ((Globe) this).xt).clan.toLowerCase
			     ().equals(((Globe) this).claname.toLowerCase()))
			((Globe) this).attachetoclan = true;
		}
	    }
	    if (((xtGraphics) ((Globe) this).xt).clan.toLowerCase()
		    .equals(((Globe) this).claname.toLowerCase())) {
		for (int i_636_ = 0; i_636_ < i; i_636_++)
		    ((Globe) this).clname[i_636_] = strings[i_636_];
		((Globe) this).ncln = i;
		((Globe) this).loadedcm = true;
	    }
	}
    }
    
    public void loadclanlink() {
	((Globe) this).ltit = "";
	((Globe) this).ldes = "";
	((Globe) this).lurl = "";
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((Globe) this).claname).append
			      ("/link.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string = url.openConnection().getContentType();
	    if (string.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_637_ = "";
		for (int i = 0;
		     ((string_637_ = datainputstream.readLine()) != null
		      && i < 3);
		     i++) {
		    string_637_ = string_637_.trim();
		    if (i == 0)
			((Globe) this).ltit = string_637_;
		    if (i == 1)
			((Globe) this).ldes = string_637_;
		    if (i == 2)
			((Globe) this).lurl = string_637_;
		}
		datainputstream.close();
	    }
	} catch (Exception exception) {
	    ((Globe) this).ltit = "";
	    ((Globe) this).ldes = "";
	    ((Globe) this).lurl = "";
	}
    }
    
    public void loadfclan() {
	((Globe) this).ncln = 0;
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((xtGraphics) ((Globe) this).xt).clan).append
			      ("/members.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    String string = "";
	    while ((string = datainputstream.readLine()) != null
		   && ((Globe) this).ncln < 20) {
		string = string.trim();
		String string_638_ = getSvalue(string, 0);
		if (!string_638_.equals("") && getvalue(string, 1) != 0) {
		    ((Globe) this).clname[((Globe) this).ncln] = string_638_;
		    ((Globe) this).ncln++;
		}
	    }
	    datainputstream.close();
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public int loadclancars() {
	((Medium) ((Globe) this).m).csky[0] = 170;
	((Medium) ((Globe) this).m).csky[1] = 220;
	((Medium) ((Globe) this).m).csky[2] = 255;
	((Medium) ((Globe) this).m).cfade[0] = 255;
	((Medium) ((Globe) this).m).cfade[1] = 220;
	((Medium) ((Globe) this).m).cfade[2] = 220;
	((Medium) ((Globe) this).m).snap[0] = 0;
	((Medium) ((Globe) this).m).snap[1] = 0;
	((Medium) ((Globe) this).m).snap[2] = 0;
	int i = 0;
	((GameSparker) ((Globe) this).gs).clcars.removeAll();
	((GameSparker) ((Globe) this).gs).clcars.add(((Globe) this).rd,
						     "Select Car");
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((Globe) this).claname).append
			      ("/cars.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string = url.openConnection().getContentType();
	    if (string.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_639_ = "";
		int i_640_ = 0;
		while ((string_639_ = datainputstream.readLine()) != null
		       && i_640_ < 700) {
		    ((GameSparker) ((Globe) this).gs).clcars
			.add(((Globe) this).rd, string_639_);
		    i_640_++;
		    if (i != 1)
			i = 1;
		}
		datainputstream.close();
	    }
	} catch (Exception exception) {
	    i = -2;
	}
	if (i == 1) {
	    if (((Globe) this).viewcar.equals(""))
		((GameSparker) ((Globe) this).gs).clcars.select(0);
	    else {
		((GameSparker) ((Globe) this).gs).clcars
		    .select(((Globe) this).viewcar);
		((Globe) this).viewcar = "";
	    }
	    ((Globe) this).selcar
		= ((GameSparker) ((Globe) this).gs).clcars.getSelectedItem();
	}
	return i;
    }
    
    public int loadaddcars() {
	int i = 3;
	int i_641_ = 0;
	String[] strings = new String[700];
	try {
	    URL url
		= (new URL
		   (new StringBuilder().append
			("http://multiplayer.needformadness.com/cars/lists/")
			.append
			(((GameSparker) ((Globe) this).gs).tnick.getText())
			.append
			(".txt?reqlo=").append
			((int) (Math.random() * 1000.0)).append
			("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    String string = "";
	    while ((string = datainputstream.readLine()) != null) {
		string = new StringBuilder().append("").append
			     (string.trim()).toString();
		if (string.startsWith("mycars")) {
		    boolean bool = true;
		    while (bool && i_641_ < 700) {
			strings[i_641_]
			    = getfuncSvalue("mycars", string, i_641_);
			if (strings[i_641_].equals(""))
			    bool = false;
			else
			    i_641_++;
		    }
		}
	    }
	    datainputstream.close();
	} catch (Exception exception) {
	    String string
		= new StringBuilder().append("").append(exception).toString();
	    if (string.indexOf("FileNotFound") != -1) {
		i_641_ = 0;
		i = 3;
	    } else {
		i_641_ = -1;
		i = 4;
	    }
	}
	if (i_641_ > 0) {
	    String[] strings_642_ = new String[700];
	    int i_643_ = 0;
	    for (int i_644_ = 0; i_644_ < i_641_; i_644_++) {
		((Globe) this).perry
		    = new StringBuilder().append("").append
			  ((int) ((float) i_644_ / (float) i_641_ * 100.0F))
			  .append
			  (" %").toString();
		try {
		    String string
			= new StringBuilder().append
			      ("http://multiplayer.needformadness.com/cars/")
			      .append
			      (strings[i_644_]).append
			      (".txt?reqlo=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString();
		    string = string.replace(' ', '_');
		    URL url = new URL(string);
		    url.openConnection().setConnectTimeout(2000);
		    DataInputStream datainputstream
			= new DataInputStream(url.openStream());
		    String string_645_ = "";
		    while ((string_645_ = datainputstream.readLine())
			   != null) {
			string_645_ = new StringBuilder().append("").append
					  (string_645_.trim()).toString();
			if (string_645_.startsWith("details")) {
			    String string_646_
				= getfuncSvalue("details", string_645_, 0);
			    if ((string_646_.toLowerCase().equals
				 (((GameSparker) ((Globe) this).gs).tnick
				      .getText
				      ().toLowerCase()))
				&& string_645_.indexOf("Clan#") == -1) {
				strings_642_[i_643_] = strings[i_644_];
				i_643_++;
			    }
			}
		    }
		    datainputstream.close();
		} catch (Exception exception) {
		    /* empty */
		}
	    }
	    if (i_643_ > 0) {
		((GameSparker) ((Globe) this).gs).clcars.removeAll();
		for (int i_647_ = 0; i_647_ < i_643_; i_647_++)
		    ((GameSparker) ((Globe) this).gs).clcars
			.add(((Globe) this).rd, strings_642_[i_647_]);
		i = 5;
	    } else
		i = 3;
	}
	return i;
    }
    
    public void loadiclancars(String string) {
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (string).append
			      ("/cars.txt").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string_648_ = url.openConnection().getContentType();
	    if (string_648_.equals("text/plain")) {
		((GameSparker) ((Globe) this).gs).datat.removeAll();
		((GameSparker) ((Globe) this).gs).datat.add(((Globe) this).rd,
							    "Select Car");
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_649_ = "";
		for (int i = 0;
		     ((string_649_ = datainputstream.readLine()) != null
		      && i < 700);
		     i++)
		    ((GameSparker) ((Globe) this).gs).datat
			.add(((Globe) this).rd, string_649_);
		datainputstream.close();
	    } else {
		((GameSparker) ((Globe) this).gs).datat.removeAll();
		((GameSparker) ((Globe) this).gs).datat
		    .add(((Globe) this).rd, "No clan cars where found.");
	    }
	} catch (Exception exception) {
	    ((GameSparker) ((Globe) this).gs).datat.removeAll();
	    ((GameSparker) ((Globe) this).gs).datat.add
		(((Globe) this).rd, "Failed to load cars, try again later...");
	}
	((GameSparker) ((Globe) this).gs).datat.select(0);
    }
    
    public int loadclanstages() {
	int i = 0;
	((GameSparker) ((Globe) this).gs).clcars.removeAll();
	((GameSparker) ((Globe) this).gs).clcars.add(((Globe) this).rd,
						     "Select Stage");
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((Globe) this).claname).append
			      ("/stages.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string = url.openConnection().getContentType();
	    if (string.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_650_ = "";
		int i_651_ = 0;
		while ((string_650_ = datainputstream.readLine()) != null
		       && i_651_ < 700) {
		    ((GameSparker) ((Globe) this).gs).clcars
			.add(((Globe) this).rd, string_650_);
		    i_651_++;
		    if (i != 1)
			i = 1;
		}
		datainputstream.close();
	    }
	} catch (Exception exception) {
	    i = -2;
	}
	if (i == 1) {
	    if (((Globe) this).viewcar.equals(""))
		((GameSparker) ((Globe) this).gs).clcars.select(0);
	    else {
		((GameSparker) ((Globe) this).gs).clcars
		    .select(((Globe) this).viewcar);
		((Globe) this).viewcar = "";
	    }
	    ((Globe) this).selstage
		= ((GameSparker) ((Globe) this).gs).clcars.getSelectedItem();
	}
	return i;
    }
    
    public int loadaddstages() {
	int i = 3;
	int i_652_ = 0;
	String[] strings = new String[700];
	try {
	    URL url
		= (new URL
		   (new StringBuilder().append
			("http://multiplayer.needformadness.com/tracks/lists/")
			.append
			(((GameSparker) ((Globe) this).gs).tnick.getText())
			.append
			(".txt?reqlo=").append
			((int) (Math.random() * 1000.0)).append
			("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    String string = "";
	    while ((string = datainputstream.readLine()) != null) {
		string = new StringBuilder().append("").append
			     (string.trim()).toString();
		if (string.startsWith("mystages")) {
		    boolean bool = true;
		    while (bool && i_652_ < 700) {
			strings[i_652_]
			    = getfuncSvalue("mystages", string, i_652_);
			if (strings[i_652_].equals(""))
			    bool = false;
			else
			    i_652_++;
		    }
		}
	    }
	    datainputstream.close();
	} catch (Exception exception) {
	    String string
		= new StringBuilder().append("").append(exception).toString();
	    if (string.indexOf("FileNotFound") != -1) {
		i_652_ = 0;
		i = 3;
	    } else {
		i_652_ = -1;
		i = 4;
	    }
	}
	if (i_652_ > 0) {
	    String[] strings_653_ = new String[700];
	    int i_654_ = 0;
	    for (int i_655_ = 0; i_655_ < i_652_; i_655_++) {
		((Globe) this).perry
		    = new StringBuilder().append("").append
			  ((int) ((float) i_655_ / (float) i_652_ * 100.0F))
			  .append
			  (" %").toString();
		try {
		    String string
			= new StringBuilder().append
			      ("http://multiplayer.needformadness.com/tracks/")
			      .append
			      (strings[i_655_]).append
			      (".txt?reqlo=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString();
		    string = string.replace(' ', '_');
		    URL url = new URL(string);
		    url.openConnection().setConnectTimeout(2000);
		    DataInputStream datainputstream
			= new DataInputStream(url.openStream());
		    String string_656_ = "";
		    while ((string_656_ = datainputstream.readLine())
			   != null) {
			string_656_ = new StringBuilder().append("").append
					  (string_656_.trim()).toString();
			if (string_656_.startsWith("details")) {
			    String string_657_
				= getfuncSvalue("details", string_656_, 0);
			    if ((string_657_.toLowerCase().equals
				 (((GameSparker) ((Globe) this).gs).tnick
				      .getText
				      ().toLowerCase()))
				&& string_656_.indexOf("Clan#") == -1) {
				strings_653_[i_654_] = strings[i_655_];
				i_654_++;
			    }
			}
		    }
		    datainputstream.close();
		} catch (Exception exception) {
		    /* empty */
		}
	    }
	    if (i_654_ > 0) {
		((GameSparker) ((Globe) this).gs).clcars.removeAll();
		for (int i_658_ = 0; i_658_ < i_654_; i_658_++)
		    ((GameSparker) ((Globe) this).gs).clcars
			.add(((Globe) this).rd, strings_653_[i_658_]);
		i = 5;
	    } else
		i = 3;
	}
	return i;
    }
    
    public void loadiclanstages(String string) {
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (string).append
			      ("/stages.txt").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string_659_ = url.openConnection().getContentType();
	    if (string_659_.equals("text/plain")) {
		((GameSparker) ((Globe) this).gs).datat.removeAll();
		((GameSparker) ((Globe) this).gs).datat.add(((Globe) this).rd,
							    "Select Stage");
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_660_ = "";
		for (int i = 0;
		     ((string_660_ = datainputstream.readLine()) != null
		      && i < 700);
		     i++)
		    ((GameSparker) ((Globe) this).gs).datat
			.add(((Globe) this).rd, string_660_);
		datainputstream.close();
	    } else {
		((GameSparker) ((Globe) this).gs).datat.removeAll();
		((GameSparker) ((Globe) this).gs).datat
		    .add(((Globe) this).rd, "No clan stages where found.");
	    }
	} catch (Exception exception) {
	    ((GameSparker) ((Globe) this).gs).datat.removeAll();
	    ((GameSparker) ((Globe) this).gs).datat.add
		(((Globe) this).rd,
		 "Failed to load stages, try again later...");
	}
	((GameSparker) ((Globe) this).gs).datat.select(0);
    }
    
    public void loadproinfo() {
	if (!((Globe) this).proname
		 .equals(((xtGraphics) ((Globe) this).xt).nickname)
	    && ((Globe) this).npf == -1)
	    loadfriends();
	((Globe) this).racing = 0;
	((Globe) this).wasting = 0;
	((Globe) this).themesong = "";
	((Globe) this).trackvol = 0;
	((Globe) this).sentance = "";
	((Globe) this).proclan = "";
	try {
	    String string = "";
	    if (((Globe) this).proname
		    .equals(((xtGraphics) ((Globe) this).xt).nickname))
		string = new StringBuilder().append("?req=").append
			     ((int) (Math.random() * 1000.0)).append
			     ("").toString();
	    URL url = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/profiles/")
			    .append
			    (((Globe) this).proname).append
			    ("/info.txt").append
			    (string).append
			    ("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    String string_661_ = url.openConnection().getContentType();
	    if (string_661_.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_662_ = "";
		for (int i = 0;
		     ((string_662_ = datainputstream.readLine()) != null
		      && i < 9);
		     i++) {
		    string_662_ = string_662_.trim();
		    if (i == 0)
			((Globe) this).themesong = string_662_;
		    if (i == 1) {
			boolean bool = false;
			int i_663_;
			try {
			    i_663_ = Integer.valueOf(string_662_).intValue();
			} catch (Exception exception) {
			    i_663_ = 0;
			}
			((Globe) this).trackvol = i_663_;
		    }
		    if (i == 2) {
			boolean bool = false;
			int i_664_;
			try {
			    i_664_ = Integer.valueOf(string_662_).intValue();
			} catch (Exception exception) {
			    i_664_ = 0;
			}
			((Globe) this).racing = i_664_;
		    }
		    if (i == 3) {
			boolean bool = false;
			int i_665_;
			try {
			    i_665_ = Integer.valueOf(string_662_).intValue();
			} catch (Exception exception) {
			    i_665_ = 0;
			}
			((Globe) this).wasting = i_665_;
		    }
		    if (i == 4)
			((Globe) this).proclan = string_662_;
		    if (i == 8)
			((Globe) this).sentance = string_662_;
		}
		datainputstream.close();
	    }
	} catch (Exception exception) {
	    ((Globe) this).sentance
		= "Failed to load profile info, server error!";
	}
    }
    
    public void loadprostages() {
	String[] strings = new String[700];
	int i = 0;
	String string = "";
	try {
	    URL url
		= (new URL
		   (new StringBuilder().append
			("http://multiplayer.needformadness.com/tracks/lists/")
			.append
			(((Globe) this).proname).append
			(".txt?reqlo=").append
			((int) (Math.random() * 1000.0)).append
			("").toString()));
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    while ((string = datainputstream.readLine()) != null) {
		string = new StringBuilder().append("").append
			     (string.trim()).toString();
		if (string.startsWith("mystages")) {
		    boolean bool = true;
		    while (bool && i < 700) {
			strings[i] = getfuncSvalue("mystages", string, i);
			if (strings[i].equals(""))
			    bool = false;
			else
			    i++;
		    }
		}
	    }
	    if (i > 0)
		((Globe) this).loadpst = 1;
	    else
		((Globe) this).loadpst = -2;
	    datainputstream.close();
	} catch (Exception exception) {
	    String string_666_
		= new StringBuilder().append("").append(exception).toString();
	    if (string_666_.indexOf("FileNotFound") != -1)
		((Globe) this).loadpst = -2;
	    else
		((Globe) this).loadpst = -1;
	}
	if (((Globe) this).loadpst == 1) {
	    ((GameSparker) ((Globe) this).gs).proitem.removeAll();
	    ((GameSparker) ((Globe) this).gs).proitem
		.add(((GameSparker) ((Globe) this).gs).rd, "Select Stage");
	    for (int i_667_ = 0; i_667_ < i; i_667_++)
		((GameSparker) ((Globe) this).gs).proitem.add
		    (((GameSparker) ((Globe) this).gs).rd, strings[i_667_]);
	    ((GameSparker) ((Globe) this).gs).proitem.select(0);
	    ((Globe) this).loadpstage = "Select Stage";
	    ((GameSparker) ((Globe) this).gs).proitem.show();
	}
	if (((Globe) this).loadpst == -2) {
	    ((GameSparker) ((Globe) this).gs).proitem.removeAll();
	    ((GameSparker) ((Globe) this).gs).proitem.add
		(((GameSparker) ((Globe) this).gs).rd,
		 "No published or added stages found...");
	    ((GameSparker) ((Globe) this).gs).proitem.select(0);
	    ((GameSparker) ((Globe) this).gs).proitem.show();
	}
	if (((Globe) this).loadpst == -1) {
	    ((GameSparker) ((Globe) this).gs).proitem.removeAll();
	    ((GameSparker) ((Globe) this).gs).proitem.add
		(((GameSparker) ((Globe) this).gs).rd,
		 "Failed to load stages, please try again later.");
	    ((GameSparker) ((Globe) this).gs).proitem.select(0);
	    ((GameSparker) ((Globe) this).gs).proitem.show();
	}
	System.gc();
    }
    
    public void loadfriends() {
	if (((Globe) this).npf == -1) {
	    ((Globe) this).freq = 0;
	    try {
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/profiles/")
			    .append
			    (((xtGraphics) ((Globe) this).xt).nickname).append
			    ("/friends.txt?req=").append
			    ((int) (Math.random() * 1000.0)).append
			    ("").toString()));
		url.openConnection().setConnectTimeout(2000);
		String string = url.openConnection().getContentType();
		if (string.equals("text/plain")) {
		    int i = 0;
		    DataInputStream datainputstream
			= new DataInputStream(url.openStream());
		    String string_668_ = "";
		    for (int i_669_ = 0;
			 ((string_668_ = datainputstream.readLine()) != null
			  && i_669_ < 3);
			 i_669_++) {
			string_668_ = string_668_.trim();
			if (i_669_ == 0) {
			    for (String string_670_ = getSvalue(string_668_,
								i);
				 (!string_670_.equals("")
				  && ((Globe) this).npf < 900);
				 string_670_ = getSvalue(string_668_, i)) {
				((Globe) this).fname[i] = string_670_;
				i++;
			    }
			}
			if (i_669_ == 1) {
			    ((Globe) this).freqname
				= getSvalue(string_668_, 0);
			    if (!((Globe) this).freqname.equals(""))
				((Globe) this).freq = 1;
			}
			if (i_669_ == 2 && ((Globe) this).freq != 1) {
			    ((Globe) this).ncnf = 0;
			    for (String string_671_
				     = getSvalue(string_668_,
						 ((Globe) this).ncnf);
				 (!string_671_.equals("")
				  && ((Globe) this).ncnf < 10);
				 string_671_
				     = getSvalue(string_668_,
						 ((Globe) this).ncnf)) {
				((Globe) this).cnfname[((Globe) this).ncnf]
				    = string_671_;
				((Globe) this).ncnf++;
			    }
			    if (((Globe) this).ncnf != 0)
				((Globe) this).freq = 6;
			}
		    }
		    datainputstream.close();
		    ((Globe) this).npf = i;
		} else
		    ((Globe) this).npf = 0;
	    } catch (Exception exception) {
		((Globe) this).npf = -2;
	    }
	}
    }
    
    public void loadnews() {
	try {
	    URL url
		= (new URL
		   (new StringBuilder().append
			("http://multiplayer.needformadness.com/interact/news.txt?req=")
			.append
			((int) (Math.random() * 1000.0)).append
			("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    String string = "";
	    int i = 0;
	    String string_672_ = "";
	    ((Globe) this).il = 0;
	    for (/**/;
		 (string = datainputstream.readLine()) != null && i < 300;
		 i++) {
		string = string.trim();
		if (i == 0) {
		    for (int i_673_ = 0; i_673_ < 4; i_673_++)
			((Globe) this).newplayers[i_673_]
			    = getSvalue(string, i_673_);
		}
		if (i >= 1 && i <= 5) {
		    ((Globe) this).nwtime[i - 1]
			= contime(getLvalue(string, 0));
		    ((Globe) this).nwarbs[i - 1] = getvalue(string, 1);
		    ((Globe) this).nwclan[i - 1] = getSvalue(string, 2);
		    ((Globe) this).nlclan[i - 1] = getSvalue(string, 3);
		    ((Globe) this).nwinob[i - 1] = getSvalue(string, 4);
		    ((Globe) this).nwinp[i - 1] = getvalue(string, 5);
		    ((Globe) this).nlosp[i - 1] = getvalue(string, 6);
		}
		if (i >= 6 && ((Globe) this).il < 300) {
		    ((Globe) this).nttime[((Globe) this).il]
			= contime(getLvalue(string, 0));
		    int i_674_ = getvalue(string, 1);
		    if (i_674_ == 4) {
			int i_675_ = getvalue(string, 4);
			if (i_675_ <= 0)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("").append
				      (getSvalue(string, 2)).append
				      (" has joined clan ").append
				      (getSvalue(string, 3)).append
				      (".").toString();
			else {
			    int i_676_ = getvalue(string, 5);
			    if (i_676_ == i_675_)
				((Globe) this).text[((Globe) this).il]
				    = new StringBuilder().append("").append
					  (getSvalue(string, 2)).append
					  (" got a new rank in clan ").append
					  (getSvalue(string, 3)).append
					  (".").toString();
			    else {
				String string_677_ = "promoted";
				if (i_676_ - i_675_ < 0)
				    string_677_ = "demoted";
				if (i_676_ != 7)
				    ((Globe) this).text[((Globe) this).il]
					= new StringBuilder().append("").append
					      (getSvalue(string, 2)).append
					      (" has been ").append
					      (string_677_).append
					      (" in clan ").append
					      (getSvalue(string, 3)).append
					      (" to a level ").append
					      (i_676_).append
					      (" member.").toString();
				else
				    ((Globe) this).text[((Globe) this).il]
					= new StringBuilder().append("").append
					      (getSvalue(string, 2)).append
					      (" has been ").append
					      (string_677_).append
					      (" in clan ").append
					      (getSvalue(string, 3)).append
					      (" to Clan Admin!").toString();
			    }
			}
			((Globe) this).nln[((Globe) this).il] = 2;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("0|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = getSvalue(string, 3);
			((Globe) this).link[((Globe) this).il][1][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).il++;
		    }
		    if (i_674_ == 5) {
			String string_678_ = getSvalue(string, 2);
			String string_679_ = getSvalue(string, 4);
			String string_680_ = "left";
			if (!string_678_.toLowerCase()
				 .equals(string_679_.toLowerCase()))
			    string_680_ = "been removed from";
			((Globe) this).text[((Globe) this).il]
			    = new StringBuilder().append("").append
				  (string_678_).append
				  (" has ").append
				  (string_680_).append
				  (" clan ").append
				  (getSvalue(string, 3)).append
				  (".").toString();
			((Globe) this).nln[((Globe) this).il] = 2;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("0|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = getSvalue(string, 3);
			((Globe) this).link[((Globe) this).il][1][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).il++;
		    }
		    if (i_674_ == 6) {
			((Globe) this).text[((Globe) this).il]
			    = new StringBuilder().append("").append
				  (getSvalue(string, 2)).append
				  (" has updated clan ").append
				  (getSvalue(string, 3)).append
				  ("'s web presence.").toString();
			((Globe) this).nln[((Globe) this).il] = 3;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("0|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = getSvalue(string, 3);
			((Globe) this).link[((Globe) this).il][1][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][2][0]
			    = "web presence";
			((Globe) this).link[((Globe) this).il][2][1]
			    = new StringBuilder().append("2|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).il++;
		    }
		    if (i_674_ == 7
			&& string_672_.indexOf(new StringBuilder().append
						   ("#").append
						   (getSvalue(string, 4))
						   .append
						   ("#").toString()) == -1) {
			((Globe) this).text[((Globe) this).il]
			    = new StringBuilder().append("").append
				  (getSvalue(string, 2)).append
				  (" has added car ").append
				  (getSvalue(string, 4)).append
				  (" to clan ").append
				  (getSvalue(string, 3)).append
				  (".").toString();
			((Globe) this).nln[((Globe) this).il] = 3;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("0|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = getSvalue(string, 3);
			((Globe) this).link[((Globe) this).il][1][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][2][0]
			    = getSvalue(string, 4);
			((Globe) this).link[((Globe) this).il][2][1]
			    = new StringBuilder().append("3|").append
				  (getSvalue(string, 4)).append
				  ("|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			string_672_
			    = new StringBuilder().append(string_672_).append
				  ("#").append
				  (getSvalue(string, 4)).append
				  ("#").toString();
			((Globe) this).il++;
		    }
		    if (i_674_ == 8
			&& string_672_.indexOf(new StringBuilder().append
						   ("#").append
						   (getSvalue(string, 4))
						   .append
						   ("#").toString()) == -1) {
			String string_681_ = getSvalue(string, 4);
			if (string_681_.length() > 20)
			    string_681_
				= new StringBuilder().append("").append
				      (string_681_.substring(0, 20)).append
				      ("...").toString();
			((Globe) this).text[((Globe) this).il]
			    = new StringBuilder().append("").append
				  (getSvalue(string, 2)).append
				  (" has added stage ").append
				  (string_681_).append
				  (" to clan ").append
				  (getSvalue(string, 3)).append
				  (".").toString();
			((Globe) this).nln[((Globe) this).il] = 3;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("0|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = getSvalue(string, 3);
			((Globe) this).link[((Globe) this).il][1][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][2][0]
			    = string_681_;
			((Globe) this).link[((Globe) this).il][2][1]
			    = new StringBuilder().append("4|").append
				  (getSvalue(string, 4)).append
				  ("|").append
				  (getSvalue(string, 3)).append
				  ("|").toString();
			string_672_
			    = new StringBuilder().append(string_672_).append
				  ("#").append
				  (getSvalue(string, 4)).append
				  ("#").toString();
			((Globe) this).il++;
		    }
		    if (i_674_ == 9) {
			String string_682_ = getSvalue(string, 2);
			if (string_682_.startsWith("War")) {
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("Clans ").append
				      (getSvalue(string, 7)).append
				      (" & ").append
				      (getSvalue(string, 8)).append
				      (" have now started a war!").toString();
			    ((Globe) this).nln[((Globe) this).il] = 2;
			    ((Globe) this).link[((Globe) this).il][0][0]
				= getSvalue(string, 7);
			    ((Globe) this).link[((Globe) this).il][0][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 7)).append
				      ("|").toString();
			    ((Globe) this).link[((Globe) this).il][1][0]
				= getSvalue(string, 8);
			    ((Globe) this).link[((Globe) this).il][1][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 8)).append
				      ("|").toString();
			    ((Globe) this).il++;
			}
			if (string_682_.startsWith("Car")) {
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("Clans ").append
				      (getSvalue(string, 7)).append
				      (" & ").append
				      (getSvalue(string, 8)).append
				      (" have started a car battle!")
				      .toString();
			    ((Globe) this).nln[((Globe) this).il] = 2;
			    ((Globe) this).link[((Globe) this).il][0][0]
				= getSvalue(string, 7);
			    ((Globe) this).link[((Globe) this).il][0][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 7)).append
				      ("|").toString();
			    ((Globe) this).link[((Globe) this).il][1][0]
				= getSvalue(string, 8);
			    ((Globe) this).link[((Globe) this).il][1][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 8)).append
				      ("|").toString();
			    ((Globe) this).il++;
			    if (((Globe) this).il < 300) {
				((Globe) this).text[((Globe) this).il]
				    = new StringBuilder().append
					  ("Battle over cars: [").append
					  (getSvalue(string, 4)).append
					  ("] & [").append
					  (getSvalue(string, 5)).append
					  ("]").toString();
				((Globe) this).nln[((Globe) this).il] = 2;
				((Globe) this).link[((Globe) this).il][0][0]
				    = getSvalue(string, 4);
				((Globe) this).link[((Globe) this).il][0][1]
				    = new StringBuilder().append("3|").append
					  (getSvalue(string, 4)).append
					  ("|").append
					  (getSvalue(string, 8)).append
					  ("|").toString();
				((Globe) this).link[((Globe) this).il][1][0]
				    = getSvalue(string, 5);
				((Globe) this).link[((Globe) this).il][1][1]
				    = new StringBuilder().append("3|").append
					  (getSvalue(string, 5)).append
					  ("|").append
					  (getSvalue(string, 7)).append
					  ("|").toString();
				((Globe) this).nttime[((Globe) this).il] = "";
				((Globe) this).il++;
			    }
			}
			if (string_682_.startsWith("Stage")) {
			    String string_683_ = getSvalue(string, 4);
			    if (string_683_.length() > 20)
				string_683_
				    = new StringBuilder().append("").append
					  (string_683_.substring(0, 20)).append
					  ("...").toString();
			    String string_684_ = getSvalue(string, 5);
			    if (string_684_.length() > 20)
				string_684_
				    = new StringBuilder().append("").append
					  (string_684_.substring(0, 20)).append
					  ("...").toString();
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("Clans ").append
				      (getSvalue(string, 7)).append
				      (" & ").append
				      (getSvalue(string, 8)).append
				      (" have started a stage battle!")
				      .toString();
			    ((Globe) this).nln[((Globe) this).il] = 2;
			    ((Globe) this).link[((Globe) this).il][0][0]
				= getSvalue(string, 7);
			    ((Globe) this).link[((Globe) this).il][0][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 7)).append
				      ("|").toString();
			    ((Globe) this).link[((Globe) this).il][1][0]
				= getSvalue(string, 8);
			    ((Globe) this).link[((Globe) this).il][1][1]
				= new StringBuilder().append("1|").append
				      (getSvalue(string, 8)).append
				      ("|").toString();
			    ((Globe) this).il++;
			    if (((Globe) this).il < 300) {
				((Globe) this).text[((Globe) this).il]
				    = new StringBuilder().append
					  ("Battle over stages: [").append
					  (string_683_).append
					  ("] & [").append
					  (string_684_).append
					  ("]").toString();
				((Globe) this).nln[((Globe) this).il] = 2;
				((Globe) this).link[((Globe) this).il][0][0]
				    = string_683_;
				((Globe) this).link[((Globe) this).il][0][1]
				    = new StringBuilder().append("4|").append
					  (getSvalue(string, 4)).append
					  ("|").append
					  (getSvalue(string, 8)).append
					  ("|").toString();
				((Globe) this).link[((Globe) this).il][1][0]
				    = string_684_;
				((Globe) this).link[((Globe) this).il][1][1]
				    = new StringBuilder().append("4|").append
					  (getSvalue(string, 5)).append
					  ("|").append
					  (getSvalue(string, 7)).append
					  ("|").toString();
				((Globe) this).nttime[((Globe) this).il] = "";
				((Globe) this).il++;
			    }
			}
		    }
		    if (i_674_ == 10 || i_674_ == 11 || i_674_ == 12
			|| i_674_ == 13) {
			if (i_674_ == 11)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("").append
				      (getSvalue(string, 2)).append
				      (" has re-claimed its title as clan wars world champion!")
				      .toString();
			else
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("").append
				      (getSvalue(string, 2)).append
				      (" has now become the new clan wars world champion!")
				      .toString();
			((Globe) this).nln[((Globe) this).il] = 2;
			((Globe) this).link[((Globe) this).il][0][0]
			    = getSvalue(string, 2);
			((Globe) this).link[((Globe) this).il][0][1]
			    = new StringBuilder().append("1|").append
				  (getSvalue(string, 2)).append
				  ("|").toString();
			((Globe) this).link[((Globe) this).il][1][0]
			    = "clan wars world champion";
			((Globe) this).link[((Globe) this).il][1][1]
			    = "5|championship|";
			if (getSvalue(string, 2).equals("")) {
			    ((Globe) this).text[((Globe) this).il]
				= "No one is currently the clan wars world champion!";
			    ((Globe) this).nln[((Globe) this).il] = 1;
			    ((Globe) this).link[((Globe) this).il][0][0]
				= "clan wars world champion";
			    ((Globe) this).link[((Globe) this).il][0][1]
				= "5|championship|";
			}
			((Globe) this).il++;
			if (i_674_ == 10)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("").append
				      (getSvalue(string, 2)).append
				      (" recent win against ").append
				      (getSvalue(string, 4)).append
				      (" has given it the championship title!")
				      .toString();
			if (i_674_ == 11)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("").append
				      (getSvalue(string, 2)).append
				      (" has successfully defended its championship title against ")
				      .append
				      (getSvalue(string, 4)).append
				      ("!").toString();
			if (i_674_ == 12)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append
				      ("A recent war between ").append
				      (getSvalue(string, 3)).append
				      (" and ").append
				      (getSvalue(string, 4)).append
				      (" has resulted in a change of points!")
				      .toString();
			if (i_674_ == 13)
			    ((Globe) this).text[((Globe) this).il]
				= new StringBuilder().append("Clan ").append
				      (getSvalue(string, 3)).append
				      (" removed itself from the game which resulted in a change of points!")
				      .toString();
			((Globe) this).nttime[((Globe) this).il] = "";
			((Globe) this).nln[((Globe) this).il] = 0;
			((Globe) this).il++;
		    }
		}
	    }
	    datainputstream.close();
	    ((Globe) this).spos6 = 0;
	    ((Globe) this).loadednews = 1;
	} catch (Exception exception) {
	    ((Globe) this).loadednews = -1;
	}
    }
    
    public void loadchamps() {
	((Globe) this).eng = -1;
	((Globe) this).engo = 0;
	if (((Globe) this).maxclans <= 0)
	    ((Globe) this).maxclans = 1000;
	((Globe) this).ncc = 0;
	((Globe) this).champ = -1;
	int i = 0;
	((Globe) this).conclan = new String[((Globe) this).maxclans];
	((Globe) this).totp = new int[((Globe) this).maxclans];
	((Globe) this).nvc = new int[((Globe) this).maxclans];
	((Globe) this).points
	    = new int[((Globe) this).maxclans][((Globe) this).maxclans];
	((Globe) this).verclan
	    = new String[((Globe) this).maxclans][((Globe) this).maxclans];
	try {
	    URL url
		= (new URL
		   (new StringBuilder().append
			("http://multiplayer.needformadness.com/interact/clanstat.txt?req=")
			.append
			((int) (Math.random() * 1000.0)).append
			("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    DataInputStream datainputstream
		= new DataInputStream(url.openStream());
	    String string = "";
	    while ((string = datainputstream.readLine()) != null
		   && ((Globe) this).ncc < ((Globe) this).maxclans) {
		((Globe) this).conclan[((Globe) this).ncc]
		    = getSvalue(string, 0);
		if (!((Globe) this).conclan[((Globe) this).ncc].equals("")) {
		    ((Globe) this).totp[((Globe) this).ncc] = 0;
		    ((Globe) this).nvc[((Globe) this).ncc] = 0;
		    for (int i_685_ = getpvalue(string, 1);
			 i_685_ != 0 && (((Globe) this).nvc[((Globe) this).ncc]
					 < ((Globe) this).maxclans);
			 i_685_ = getpvalue(string,
					    1 + (((Globe) this).nvc
						 [((Globe) this).ncc]) * 2)) {
			((Globe) this).totp[((Globe) this).ncc] += i_685_;
			((Globe) this).points[((Globe) this).ncc]
			    [((Globe) this).nvc[((Globe) this).ncc]]
			    = i_685_;
			((Globe) this).verclan[((Globe) this).ncc]
			    [((Globe) this).nvc[((Globe) this).ncc]]
			    = getSvalue(string,
					2 + (((Globe) this).nvc
					     [((Globe) this).ncc]) * 2);
			((Globe) this).nvc[((Globe) this).ncc]++;
		    }
		    if (((Globe) this).totp[((Globe) this).ncc] >= i
			&& ((Globe) this).totp[((Globe) this).ncc] >= 3) {
			if (((Globe) this).totp[((Globe) this).ncc] == i)
			    ((Globe) this).champ = -2;
			else {
			    i = ((Globe) this).totp[((Globe) this).ncc];
			    ((Globe) this).champ = ((Globe) this).ncc;
			}
		    }
		    ((Globe) this).ncc++;
		}
	    }
	    datainputstream.close();
	    ((Globe) this).ord = new int[((Globe) this).ncc];
	    int[] is = new int[((Globe) this).ncc];
	    ((Globe) this).leadsby = i;
	    for (int i_686_ = 0; i_686_ < ((Globe) this).ncc; i_686_++) {
		if (i_686_ != ((Globe) this).champ
		    && (i - ((Globe) this).totp[i_686_]
			< ((Globe) this).leadsby))
		    ((Globe) this).leadsby = i - ((Globe) this).totp[i_686_];
		is[i_686_] = 0;
	    }
	    for (int i_687_ = 0; i_687_ < ((Globe) this).ncc; i_687_++) {
		for (int i_688_ = i_687_ + 1; i_688_ < ((Globe) this).ncc;
		     i_688_++) {
		    if (((Globe) this).totp[i_687_]
			< ((Globe) this).totp[i_688_])
			is[i_687_]++;
		    else
			is[i_688_]++;
		}
		((Globe) this).ord[is[i_687_]] = i_687_;
	    }
	    ((Globe) this).spos6 = 0;
	    ((Globe) this).loadwstat = 1;
	} catch (Exception exception) {
	    String string
		= new StringBuilder().append("").append(exception).toString();
	    if (string.indexOf("java.io.FileNotFoundException") != -1)
		((Globe) this).loadwstat = 1;
	    else
		((Globe) this).loadwstat = -1;
	}
    }
    
    public String contime(long l) {
	String string = "";
	if (l != -1L) {
	    try {
		long l_689_ = ((Globe) this).ntime - l;
		if (l_689_ >= 1000L && l_689_ < 60000L)
		    string = "seconds ago";
		if (l_689_ >= 60000L && l_689_ < 3600000L) {
		    int i = (int) (l_689_ / 60000L);
		    String string_690_ = "s";
		    if (i == 1)
			string_690_ = "";
		    string = new StringBuilder().append("").append(i).append
				 (" minute").append
				 (string_690_).append
				 (" ago").toString();
		}
		if (l_689_ >= 3600000L && l_689_ < 86400000L) {
		    int i = (int) (l_689_ / 3600000L);
		    String string_691_ = "s";
		    if (i == 1)
			string_691_ = "";
		    string = new StringBuilder().append("").append(i).append
				 (" hour").append
				 (string_691_).append
				 (" ago").toString();
		}
		if (l_689_ >= 86400000L) {
		    int i = (int) (l_689_ / 86400000L);
		    String string_692_ = "s";
		    if (i == 1)
			string_692_ = "";
		    string = new StringBuilder().append("").append(i).append
				 (" day").append
				 (string_692_).append
				 (" ago").toString();
		}
	    } catch (Exception exception) {
		string = "";
	    }
	}
	return string;
    }
    
    public void tlink(Graphics2D graphics2d, int i, int i_693_, String string,
		      String string_694_, int i_695_, int i_696_, boolean bool,
		      int i_697_, int i_698_, int i_699_, String string_700_,
		      String string_701_) {
	((Globe) this).ftm = ((Globe) this).rdo.getFontMetrics();
	int i_702_ = 0;
	int i_703_ = 0;
	int i_704_ = string.indexOf(string_694_);
	if (i_704_ != -1) {
	    i_702_
		= (((Globe) this).ftm.stringWidth(string.substring(0, i_704_))
		   + i);
	    i_703_ = i_702_ + ((Globe) this).ftm.stringWidth(string_694_) - 2;
	}
	((Globe) this).rdo.drawLine(i_702_, i_693_ + 1, i_703_, i_693_ + 1);
	if (i_695_ > i_702_ + i_697_ && i_695_ < i_703_ + i_697_
	    && i_696_ > i_693_ - 11 + i_698_ && i_696_ < i_693_ + 1 + i_698_) {
	    ((Globe) this).cur = 12;
	    if (bool) {
		if (i_699_ == 0) {
		    ((Globe) this).tab = 1;
		    if (!((Globe) this).proname.equals(string_700_)) {
			((Globe) this).proname = string_700_;
			((Globe) this).loadedp = false;
			onexitpro();
		    }
		}
		if (i_699_ == 1) {
		    if (!((Globe) this).claname.equals(string_700_)) {
			((Globe) this).claname = string_700_;
			((Globe) this).loadedc = false;
		    }
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).ctab = 0;
		    ((Globe) this).tab = 3;
		}
		if (i_699_ == 2) {
		    if (!((Globe) this).claname.equals(string_700_)) {
			((Globe) this).claname = string_700_;
			((Globe) this).loadedc = false;
		    }
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).loadedlink = false;
		    ((Globe) this).ctab = 4;
		    ((Globe) this).tab = 3;
		}
		if (i_699_ == 3) {
		    ((Globe) this).viewcar = string_700_;
		    if (!((Globe) this).claname.equals(string_701_)) {
			((Globe) this).claname = string_701_;
			((Globe) this).loadedc = false;
		    }
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).loadedcars = -1;
		    ((Globe) this).loadedcar = 0;
		    ((Globe) this).ctab = 2;
		    ((Globe) this).tab = 3;
		}
		if (i_699_ == 4) {
		    ((Globe) this).viewcar = string_700_;
		    if (!((Globe) this).claname.equals(string_701_)) {
			((Globe) this).claname = string_701_;
			((Globe) this).loadedc = false;
		    }
		    ((Globe) this).spos5 = 0;
		    ((Globe) this).lspos5 = 0;
		    ((Globe) this).cfase = 3;
		    ((Globe) this).loadedstages = -1;
		    ((Globe) this).loadedstage = 0;
		    ((Globe) this).ctab = 3;
		    ((Globe) this).tab = 3;
		}
		if (i_699_ == 5) {
		    ((Globe) this).loadwstat = 0;
		    ((Globe) this).ntab = 1;
		}
	    }
	}
    }
    
    public void loadwarb() {
	try {
	    URL url
		= new URL(new StringBuilder().append
			      ("http://multiplayer.needformadness.com/clans/")
			      .append
			      (((xtGraphics) ((Globe) this).xt).clan).append
			      ("/inter.txt?req=").append
			      ((int) (Math.random() * 1000.0)).append
			      ("").toString());
	    url.openConnection().setConnectTimeout(2000);
	    String string = url.openConnection().getContentType();
	    ((GameSparker) ((Globe) this).gs).warb.removeAll();
	    ((GameSparker) ((Globe) this).gs).warb
		.add(((Globe) this).rd, " Select  War / Battle");
	    if (string.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_705_ = "";
		int i = 0;
		boolean bool = false;
		for (/**/; ((string_705_ = datainputstream.readLine()) != null
			    && i < 100); i++) {
		    string_705_ = string_705_.trim();
		    String string_706_ = getSvalue(string_705_, 5);
		    if (string_706_.equals("War")) {
			((GameSparker) ((Globe) this).gs).warb.addw
			    (new StringBuilder().append(" War with ").append
				 (getSvalue(string_705_, 0)).append
				 ("").toString(),
			     new StringBuilder().append("").append
				 (getSvalue(string_705_, 6)).append
				 ("|").append
				 (getSvalue(string_705_, 0)).append
				 ("|").toString());
			bool = true;
		    }
		    if (string_706_.equals("Car Battle")) {
			((GameSparker) ((Globe) this).gs).warb.addw
			    (new StringBuilder().append
				 (" Car battle with ").append
				 (getSvalue(string_705_, 0)).append
				 ("").toString(),
			     new StringBuilder().append("").append
				 (getSvalue(string_705_, 6)).append
				 ("|").append
				 (getSvalue(string_705_, 0)).append
				 ("|").toString());
			bool = true;
		    }
		    if (string_706_.equals("Stage Battle")) {
			((GameSparker) ((Globe) this).gs).warb.addw
			    (new StringBuilder().append
				 (" Stage battle with ").append
				 (getSvalue(string_705_, 0)).append
				 ("").toString(),
			     new StringBuilder().append("").append
				 (getSvalue(string_705_, 6)).append
				 ("|").append
				 (getSvalue(string_705_, 0)).append
				 ("|").toString());
			bool = true;
		    }
		}
		datainputstream.close();
		if (!bool) {
		    ((GameSparker) ((Globe) this).gs).warb.removeAll();
		    ((GameSparker) ((Globe) this).gs).warb.add
			(((Globe) this).rd,
			 "Your clan has not started any new wars or battles.");
		}
	    } else {
		((GameSparker) ((Globe) this).gs).warb.removeAll();
		((GameSparker) ((Globe) this).gs).warb.add
		    (((Globe) this).rd,
		     "Your clan has not started any wars or battles yet.");
	    }
	} catch (Exception exception) {
	    ((GameSparker) ((Globe) this).gs).warb.removeAll();
	    ((GameSparker) ((Globe) this).gs).warb.add
		(((Globe) this).rd,
		 "Error occurred while loading, please try again later.");
	}
	((GameSparker) ((Globe) this).gs).warb.select(0);
    }
    
    public void loadwgames() {
	((Globe) this).canredo = false;
	((Globe) this).gameturn = -1;
	((Globe) this).lwbwinner = "";
	((Globe) this).ascore = 0;
	((Globe) this).vscore = 0;
	((GameSparker) ((Globe) this).gs).pgame.removeAll();
	((GameSparker) ((Globe) this).gs).pgame.add(((Globe) this).rd,
						    " Select Game");
	int i = 5;
	String string = "battle";
	((Globe) this).warb = 2;
	if (((Smenu) ((GameSparker) ((Globe) this).gs).warb).sopts
		[((Smenu) ((GameSparker) ((Globe) this).gs).warb).sel]
		.startsWith(" War with")) {
	    i = 9;
	    string = "war";
	    ((Globe) this).warb = 1;
	}
	if (((Smenu) ((GameSparker) ((Globe) this).gs).warb).sopts
		[((Smenu) ((GameSparker) ((Globe) this).gs).warb).sel]
		.startsWith(" Stage battle with"))
	    ((Globe) this).warb = 3;
	((Globe) this).warbnum
	    = getSvalue((((Smenu) ((GameSparker) ((Globe) this).gs).warb).opts
			 [(((Smenu) ((GameSparker) ((Globe) this).gs).warb)
			   .sel)]),
			0);
	((Globe) this).vclan
	    = getSvalue((((Smenu) ((GameSparker) ((Globe) this).gs).warb).opts
			 [(((Smenu) ((GameSparker) ((Globe) this).gs).warb)
			   .sel)]),
			1);
	try {
	    URL url = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/interact/")
			    .append
			    (string).append
			    ("/").append
			    (((Globe) this).warbnum).append
			    (".txt?req=").append
			    ((int) (Math.random() * 1000.0)).append
			    ("").toString()));
	    url.openConnection().setConnectTimeout(2000);
	    String string_707_ = url.openConnection().getContentType();
	    if (string_707_.equals("text/plain")) {
		DataInputStream datainputstream
		    = new DataInputStream(url.openStream());
		String string_708_ = "";
		int i_709_;
		for (i_709_ = 0;
		     ((string_708_ = datainputstream.readLine()) != null
		      && i_709_ < i);
		     i_709_++) {
		    String string_710_ = getSvalue(string_708_, 0);
		    if (string_710_.startsWith("#")) {
			boolean bool = true;
			int i_711_;
			try {
			    i_711_ = Integer.valueOf
					 (string_710_.substring(1)).intValue();
			} catch (Exception exception) {
			    i_711_ = 1;
			}
			((Globe) this).wbstage[i_709_] = i_711_;
			string_710_ = new StringBuilder().append
					  ("NFM 1 - Stage ").append
					  (i_711_).append
					  ("").toString();
			if (i_711_ > 10)
			    string_710_ = new StringBuilder().append
					      ("NFM 2 - Stage ").append
					      (i_711_ - 10).append
					      ("").toString();
			if (i_711_ > 27)
			    string_710_
				= new StringBuilder().append
				      ("NFM Multiplayer - Stage ").append
				      (i_711_ - 27).append
				      ("").toString();
		    } else
			((Globe) this).wbstage[i_709_] = 101;
		    ((Globe) this).wbstages[i_709_] = string_710_;
		    ((Globe) this).wblaps[i_709_] = getvalue(string_708_, 1);
		    ((Globe) this).wbcars[i_709_] = getvalue(string_708_, 2);
		    ((Globe) this).wbclass[i_709_] = getvalue(string_708_, 3);
		    ((Globe) this).wbfix[i_709_] = getvalue(string_708_, 4);
		    String string_712_ = getSvalue(string_708_, 5);
		    String string_713_ = "";
		    if (((Globe) this).wbcars[i_709_] == 2)
			string_713_ = ",  Clan Cars";
		    if (((Globe) this).wbcars[i_709_] == 3)
			string_713_ = ",  Game Cars";
		    if (((Globe) this).wbclass[i_709_] == 1)
			string_713_
			    = new StringBuilder().append(string_713_).append
				  (",  Class C").toString();
		    if (((Globe) this).wbclass[i_709_] == 2)
			string_713_
			    = new StringBuilder().append(string_713_).append
				  (",  Class B & C").toString();
		    if (((Globe) this).wbclass[i_709_] == 3)
			string_713_
			    = new StringBuilder().append(string_713_).append
				  (",  Class B").toString();
		    if (((Globe) this).wbclass[i_709_] == 4)
			string_713_
			    = new StringBuilder().append(string_713_).append
				  (",  Class A & B").toString();
		    if (((Globe) this).wbclass[i_709_] == 5)
			string_713_
			    = new StringBuilder().append(string_713_).append
				  (",  Class A").toString();
		    String string_714_ = "";
		    if (((Globe) this).wbfix[i_709_] == 1)
			string_714_ = ",  4 Fixes";
		    if (((Globe) this).wbfix[i_709_] == 2)
			string_714_ = ",  3 Fixes";
		    if (((Globe) this).wbfix[i_709_] == 3)
			string_714_ = ",  2 Fixes";
		    if (((Globe) this).wbfix[i_709_] == 4)
			string_714_ = ",  1 Fix";
		    if (((Globe) this).wbfix[i_709_] == 5)
			string_714_ = ",  No Fixing";
		    ((Globe) this).rd.setFont(new Font("Arial", 1, 12));
		    ((Globe) this).ftm = ((Globe) this).rd.getFontMetrics();
		    String string_715_ = ((Globe) this).wbstages[i_709_];
		    String string_716_;
		    for (string_716_
			     = new StringBuilder().append("Game #").append
				   (i_709_ + 1).append
				   (":  ").append
				   (string_715_).append
				   ("").append
				   (string_713_).append
				   ("").append
				   (string_714_).append
				   (",  ").append
				   (((Globe) this).wblaps[i_709_]).append
				   (" Laps").toString();
			 ((Globe) this).ftm.stringWidth(string_716_) > 400;
			 string_716_
			     = new StringBuilder().append("Game #").append
				   (i_709_ + 1).append
				   (":  ").append
				   (string_715_).append
				   ("...").append
				   (string_713_).append
				   ("").append
				   (string_714_).append
				   (",  ").append
				   (((Globe) this).wblaps[i_709_]).append
				   (" Laps").toString())
			string_715_
			    = string_715_.substring(0,
						    string_715_.length() - 1);
		    if (((Globe) this).gameturn == -1) {
			if (string_712_.equals("")
			    || string_712_.equals("#redo#")) {
			    if (!string_712_.equals("#redo#") && i_709_ > 0)
				((Globe) this).canredo = true;
			    ((Globe) this).gameturn = i_709_;
			    ((Globe) this).gameturndisp = string_716_;
			} else {
			    if (string_712_.toLowerCase().equals
				(((xtGraphics) ((Globe) this).xt).clan
				     .toLowerCase()))
				((Globe) this).ascore++;
			    if (string_712_.toLowerCase().equals
				(((Globe) this).vclan.toLowerCase()))
				((Globe) this).vscore++;
			    ((Globe) this).lwbwinner = string_712_;
			}
		    }
		    ((GameSparker) ((Globe) this).gs).pgame.add
			(((Globe) this).rd,
			 new StringBuilder().append(" ").append
			     (string_716_).append
			     ("").toString());
		}
		datainputstream.close();
		if (i_709_ != 0)
		    ((Globe) this).loadwbgames = 2;
		else
		    ((Globe) this).loadwbgames = 3;
	    } else
		((Globe) this).loadwbgames = 4;
	} catch (Exception exception) {
	    ((Globe) this).loadwbgames = 3;
	}
    }
    
    public void redogame() {
	try {
	    ((Globe) this).socket
		= new Socket(((Login) ((Globe) this).lg).servers[0], 7061);
	    ((Globe) this).din
		= new BufferedReader(new InputStreamReader
				     (((Globe) this).socket.getInputStream()));
	    ((Globe) this).dout
		= new PrintWriter(((Globe) this).socket.getOutputStream(),
				  true);
	    String string = new StringBuilder().append("101|43|").append
				(((Globe) this).warb).append
				("|").append
				(((Globe) this).warbnum).append
				("|").toString();
	    ((Globe) this).dout.println(string);
	    String string_717_ = ((Globe) this).din.readLine();
	    if (!string_717_.equals("OK"))
		((Globe) this).loadwbgames = 6;
	    ((Globe) this).socket.close();
	    ((Globe) this).socket = null;
	    ((Globe) this).din.close();
	    ((Globe) this).din = null;
	    ((Globe) this).dout.close();
	    ((Globe) this).dout = null;
	} catch (Exception exception) {
	    ((Globe) this).loadwbgames = 6;
	}
	if (((Globe) this).loadwbgames != 6)
	    loadwgames();
    }
    
    public boolean drawbutton(Image image, int i, int i_718_, int i_719_,
			      int i_720_, boolean bool) {
	boolean bool_721_ = false;
	boolean bool_722_ = false;
	int i_723_ = image.getWidth(((Globe) this).ob);
	if (Math.abs(i_719_ - i) < i_723_ / 2 + 12
	    && Math.abs(i_720_ - i_718_) < 14 && bool)
	    bool_722_ = true;
	if (Math.abs(i_719_ - i) < i_723_ / 2 + 12
	    && Math.abs(i_720_ - i_718_) < 14
	    && ((GameSparker) ((Globe) this).gs).mouses <= -1) {
	    bool_721_ = true;
	    ((GameSparker) ((Globe) this).gs).mouses = 0;
	}
	if (!bool_722_) {
	    ((Globe) this).rd.drawImage(image, i - i_723_ / 2,
					i_718_ - image.getHeight(((Globe) this)
								 .ob) / 2,
					null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bols,
					i - i_723_ / 2 - 15, i_718_ - 13,
					null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bors,
					i + i_723_ / 2 + 9, i_718_ - 13, null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bot,
					i - i_723_ / 2 - 9, i_718_ - 13,
					i_723_ + 18, 3, null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bob,
					i - i_723_ / 2 - 9, i_718_ + 10,
					i_723_ + 18, 3, null);
	} else {
	    ((Globe) this).rd.drawImage(image, i - i_723_ / 2 + 1,
					i_718_ - image.getHeight(((Globe) this)
								 .ob) / 2 + 1,
					null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bolps,
					i - i_723_ / 2 - 15, i_718_ - 13,
					null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).borps,
					i + i_723_ / 2 + 9, i_718_ - 13, null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bob,
					i - i_723_ / 2 - 9, i_718_ - 13,
					i_723_ + 18, 3, null);
	    ((Globe) this).rd.drawImage(((xtGraphics) ((Globe) this).xt).bot,
					i - i_723_ / 2 - 9, i_718_ + 10,
					i_723_ + 18, 3, null);
	}
	return bool_721_;
    }
    
    public boolean stringbutton(Graphics2D graphics2d, String string, int i,
				int i_724_, int i_725_, int i_726_, int i_727_,
				boolean bool, int i_728_, int i_729_) {
	boolean bool_730_ = false;
	boolean bool_731_ = false;
	graphics2d.setFont(new Font("Arial", 1, 12));
	((Globe) this).ftm = graphics2d.getFontMetrics();
	if (i_725_ == 6) {
	    graphics2d.setFont(new Font("Arial", 1, 11));
	    ((Globe) this).ftm = graphics2d.getFontMetrics();
	}
	int i_732_ = ((Globe) this).ftm.stringWidth(string);
	if (Math.abs(i_726_ - i_728_ - i) < i_732_ / 2 + 12
	    && Math.abs(i_727_ - i_729_ - i_724_) < 14 && bool)
	    bool_731_ = true;
	if (Math.abs(i_726_ - i_728_ - i) < i_732_ / 2 + 12
	    && Math.abs(i_727_ - i_729_ - i_724_) < 14
	    && ((GameSparker) ((Globe) this).gs).mouses <= -1
	    && ((Globe) this).blocknote == 0 && ((Globe) this).blockb == 0
	    && !((GameSparker) ((Globe) this).gs).openm
	    && (((Globe) this).editc == 0 || i_728_ == 0)) {
	    bool_730_ = true;
	    ((GameSparker) ((Globe) this).gs).mouses = 0;
	}
	if (((Globe) this).blocknote != 0)
	    ((Globe) this).blocknote--;
	boolean bool_733_ = false;
	if (i_725_ < 0) {
	    i_725_ *= -1;
	    bool_733_ = true;
	}
	if (bool_733_)
	    ((Globe) this).rdo.setComposite(AlphaComposite.getInstance(3,
								       0.7F));
	if (!bool_731_) {
	    graphics2d.setColor(colorb2k(bool_733_, 220, 220, 220));
	    graphics2d.fillRect(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i_732_ + 20, 25 - i_725_ * 2);
	    graphics2d.setColor(colorb2k(bool_733_, 240, 240, 240));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 10, i_724_ - (17 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (18 - i_725_),
				i + i_732_ / 2 + 10, i_724_ - (18 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 9, i_724_ - (19 - i_725_),
				i + i_732_ / 2 + 9, i_724_ - (19 - i_725_));
	    graphics2d.setColor(colorb2k(bool_733_, 200, 200, 200));
	    graphics2d.drawLine(i + i_732_ / 2 + 10, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i + i_732_ / 2 + 11, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 11, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i + i_732_ / 2 + 12, i_724_ - (16 - i_725_),
				i + i_732_ / 2 + 12, i_724_ + (6 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ + (7 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ + (8 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (8 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 9, i_724_ + (9 - i_725_),
				i + i_732_ / 2 + 9, i_724_ + (9 - i_725_));
	    graphics2d.setColor(colorb2k(bool_733_, 240, 240, 240));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i - i_732_ / 2 - 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 11, i_724_ - (17 - i_725_),
				i - i_732_ / 2 - 11, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 12, i_724_ - (16 - i_725_),
				i - i_732_ / 2 - 12, i_724_ + (6 - i_725_));
	    if (bool_733_)
		((Globe) this).rdo
		    .setComposite(AlphaComposite.getInstance(3, 1.0F));
	    graphics2d.setColor(new Color(0, 0, 0));
	    graphics2d.drawString(string, i - i_732_ / 2, i_724_);
	} else {
	    graphics2d.setColor(colorb2k(bool_733_, 210, 210, 210));
	    graphics2d.fillRect(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i_732_ + 20, 25 - i_725_ * 2);
	    graphics2d.setColor(colorb2k(bool_733_, 200, 200, 200));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 10, i_724_ - (17 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (18 - i_725_),
				i + i_732_ / 2 + 10, i_724_ - (18 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 9, i_724_ - (19 - i_725_),
				i + i_732_ / 2 + 9, i_724_ - (19 - i_725_));
	    graphics2d.drawLine(i + i_732_ / 2 + 10, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i + i_732_ / 2 + 11, i_724_ - (17 - i_725_),
				i + i_732_ / 2 + 11, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i + i_732_ / 2 + 12, i_724_ - (16 - i_725_),
				i + i_732_ / 2 + 12, i_724_ + (6 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ + (7 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ + (8 - i_725_),
				i + i_732_ / 2 + 10, i_724_ + (8 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 9, i_724_ + (9 - i_725_),
				i + i_732_ / 2 + 9, i_724_ + (9 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 10, i_724_ - (17 - i_725_),
				i - i_732_ / 2 - 10, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 11, i_724_ - (17 - i_725_),
				i - i_732_ / 2 - 11, i_724_ + (7 - i_725_));
	    graphics2d.drawLine(i - i_732_ / 2 - 12, i_724_ - (16 - i_725_),
				i - i_732_ / 2 - 12, i_724_ + (6 - i_725_));
	    if (bool_733_)
		((Globe) this).rdo
		    .setComposite(AlphaComposite.getInstance(3, 1.0F));
	    graphics2d.setColor(new Color(0, 0, 0));
	    graphics2d.drawString(string, i - i_732_ / 2 + 1, i_724_);
	}
	return bool_730_;
    }
    
    public Color color2k(int i, int i_734_, int i_735_) {
	Color color = new Color(i, i_734_, i_735_);
	float[] fs = new float[3];
	Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
	fs[0] = 0.13F;
	fs[1] = 0.35F;
	return Color.getHSBColor(fs[0], fs[1], fs[2]);
    }
    
    public Color colorb2k(boolean bool, int i, int i_736_, int i_737_) {
	Color color = new Color(i, i_736_, i_737_);
	if (!bool) {
	    float[] fs = new float[3];
	    Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(),
			   fs);
	    fs[0] = 0.13F;
	    fs[1] = 0.35F;
	    if (((Globe) this).darker)
		fs[2] *= 0.9F;
	    color = Color.getHSBColor(fs[0], fs[1], fs[2]);
	} else
	    color = new Color((int) ((float) i * 0.9F),
			      (int) ((float) i_736_ * 0.9F),
			      (int) ((float) i_737_ * 0.9F));
	return color;
    }
    
    public int getvalue(String string, int i) {
	int i_738_ = -1;
	try {
	    int i_739_ = 0;
	    int i_740_ = 0;
	    int i_741_ = 0;
	    String string_742_ = "";
	    String string_743_ = "";
	    for (/**/; i_739_ < string.length() && i_741_ != 2; i_739_++) {
		string_742_ = new StringBuilder().append("").append
				  (string.charAt(i_739_)).toString();
		if (string_742_.equals("|")) {
		    i_740_++;
		    if (i_741_ == 1 || i_740_ > i)
			i_741_ = 2;
		} else if (i_740_ == i) {
		    string_743_
			= new StringBuilder().append(string_743_).append
			      (string_742_).toString();
		    i_741_ = 1;
		}
	    }
	    if (string_743_.equals(""))
		string_743_ = "-1";
	    i_738_ = Integer.valueOf(string_743_).intValue();
	} catch (Exception exception) {
	    /* empty */
	}
	return i_738_;
    }
    
    public String getSvalue(String string, int i) {
	String string_744_ = "";
	try {
	    int i_745_ = 0;
	    int i_746_ = 0;
	    int i_747_ = 0;
	    String string_748_ = "";
	    String string_749_ = "";
	    for (/**/; i_745_ < string.length() && i_747_ != 2; i_745_++) {
		string_748_ = new StringBuilder().append("").append
				  (string.charAt(i_745_)).toString();
		if (string_748_.equals("|")) {
		    i_746_++;
		    if (i_747_ == 1 || i_746_ > i)
			i_747_ = 2;
		} else if (i_746_ == i) {
		    string_749_
			= new StringBuilder().append(string_749_).append
			      (string_748_).toString();
		    i_747_ = 1;
		}
	    }
	    string_744_ = string_749_;
	} catch (Exception exception) {
	    /* empty */
	}
	return string_744_;
    }
    
    public long getLvalue(String string, int i) {
	long l = -1L;
	try {
	    int i_750_ = 0;
	    int i_751_ = 0;
	    int i_752_ = 0;
	    String string_753_ = "";
	    String string_754_ = "";
	    for (/**/; i_750_ < string.length() && i_752_ != 2; i_750_++) {
		string_753_ = new StringBuilder().append("").append
				  (string.charAt(i_750_)).toString();
		if (string_753_.equals("|")) {
		    i_751_++;
		    if (i_752_ == 1 || i_751_ > i)
			i_752_ = 2;
		} else if (i_751_ == i) {
		    string_754_
			= new StringBuilder().append(string_754_).append
			      (string_753_).toString();
		    i_752_ = 1;
		}
	    }
	    if (string_754_.equals(""))
		string_754_ = "-1";
	    l = Long.valueOf(string_754_).longValue();
	} catch (Exception exception) {
	    /* empty */
	}
	return l;
    }
    
    public int getpvalue(String string, int i) {
	int i_755_ = 0;
	try {
	    int i_756_ = 0;
	    int i_757_ = 0;
	    int i_758_ = 0;
	    String string_759_ = "";
	    String string_760_ = "";
	    for (/**/; i_756_ < string.length() && i_758_ != 2; i_756_++) {
		string_759_ = new StringBuilder().append("").append
				  (string.charAt(i_756_)).toString();
		if (string_759_.equals("|")) {
		    i_757_++;
		    if (i_758_ == 1 || i_757_ > i)
			i_758_ = 2;
		} else if (i_757_ == i) {
		    string_760_
			= new StringBuilder().append(string_760_).append
			      (string_759_).toString();
		    i_758_ = 1;
		}
	    }
	    if (string_760_.equals(""))
		string_760_ = "0";
	    i_755_ = Integer.valueOf(string_760_).intValue();
	} catch (Exception exception) {
	    /* empty */
	}
	return i_755_;
    }
    
    public int getfuncvalue(String string, String string_761_, int i) {
	int i_762_ = 0;
	String string_763_ = "";
	for (int i_764_ = string.length() + 1; i_764_ < string_761_.length();
	     i_764_++) {
	    String string_765_ = new StringBuilder().append("").append
				     (string_761_.charAt(i_764_)).toString();
	    if (string_765_.equals(",") || string_765_.equals(")")) {
		i_762_++;
		i_764_++;
	    }
	    if (i_762_ == i)
		string_763_ = new StringBuilder().append(string_763_).append
				  (string_761_.charAt(i_764_)).toString();
	}
	return Float.valueOf(string_763_).intValue();
    }
    
    public String getfuncSvalue(String string, String string_766_, int i) {
	String string_767_ = "";
	int i_768_ = 0;
	for (int i_769_ = string.length() + 1;
	     i_769_ < string_766_.length() && i_768_ <= i; i_769_++) {
	    String string_770_ = new StringBuilder().append("").append
				     (string_766_.charAt(i_769_)).toString();
	    if (string_770_.equals(",") || string_770_.equals(")"))
		i_768_++;
	    else if (i_768_ == i)
		string_767_ = new StringBuilder().append(string_767_).append
				  (string_770_).toString();
	}
	return string_767_;
    }
}
