/* soundClip - Decompiled by JODE extended
 * DragShot Software
 * JODE (c) 1998-2001 Jochen Hoenicke
 */
import java.io.ByteArrayInputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
public class soundClip
{
    Clip clip = null;
    AudioInputStream sound;
    boolean loaded = false;
    int lfrpo = -1;
    int cntcheck = 0;
    int rollBackPos;
    int rollBackTrig;
    
    public soundClip(byte[] is) {
        try {
            ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(is);
            ((soundClip) this).sound = AudioSystem.getAudioInputStream(bytearrayinputstream);
            ((soundClip) this).sound.mark(is.length);
            ((soundClip) this).clip = AudioSystem.getClip();
            ((soundClip) this).loaded = true;
        } catch (Exception exception) {
            System.out.println(new StringBuilder().append("Loading Clip error: ").append(exception).toString());
            ((soundClip) this).loaded = false;
        }
    }
    
    public void play() {
        if (((soundClip) this).loaded) {
            if (!((soundClip) this).clip.isOpen()) {
                try {
                    ((soundClip) this).clip.open(((soundClip) this).sound);
                } catch (Exception exception) {
                    /* empty */
                }
                ((soundClip) this).clip.loop(0);
            } else
                ((soundClip) this).clip.loop(1);
            ((soundClip) this).lfrpo = -1;
            ((soundClip) this).cntcheck = 5;
        }
    }
    
    public void loop() {
        if (((soundClip) this).loaded) {
            if (!((soundClip) this).clip.isOpen()) {
                try {
                    ((soundClip) this).clip.open(((soundClip) this).sound);
                } catch (Exception exception) {
                    /* empty */
                }
            }
            ((soundClip) this).clip.loop(70);
            ((soundClip) this).lfrpo = -2;
            ((soundClip) this).cntcheck = 0;
        }
    }
    
    public void stop() {
        if (((soundClip) this).loaded) {
            ((soundClip) this).clip.stop();
            ((soundClip) this).lfrpo = -1;
        }
    }
    
    public void checkopen() {
        if (((soundClip) this).loaded && ((soundClip) this).clip.isOpen() && ((soundClip) this).lfrpo != -2) {
            if (((soundClip) this).cntcheck == 0) {
                int i = ((soundClip) this).clip.getFramePosition();
                if (((soundClip) this).lfrpo == i && !((soundClip) this).clip.isRunning()) {
                    try {
                        ((soundClip) this).clip.close();
                        ((soundClip) this).sound.reset();
                    } catch (Exception exception) {
                        /* empty */
                    }
                    ((soundClip) this).lfrpo = -1;
                } else
                    ((soundClip) this).lfrpo = i;
            } else
                ((soundClip) this).cntcheck--;
        }
    }
}
