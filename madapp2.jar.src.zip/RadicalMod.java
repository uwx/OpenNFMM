/* RadicalMod - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.net.URL;

import ds.nfm.Module;
import ds.nfm.ModuleLoader;
import ds.nfm.ModuleSlayer;

public class RadicalMod
{
    SuperClip sClip;
    boolean playing = false;
    int loaded = 0;
    int rvol = 0;
    String imod = "";
    String pmod = "";
    
    public RadicalMod() {
	((RadicalMod) this).loaded = 0;
	System.gc();
    }
    
    public RadicalMod(String string, int i, int i_0_, int i_1_, boolean bool,
		      boolean bool_2_) {
	int i_3_ = 22000;
	i_0_ = (int) ((float) i_0_ / 8000.0F * 2.0F * (float) i_3_);
	i *= 0.8F;
	try {
	    Object object = null;
	    Module module;
	    if (!bool_2_)
		module = ModuleLoader.loadMod(new StringBuilder().append
						  ("").append
						  (Madness.fpath).append
						  ("").append
						  (string).append
						  ("").toString());
	    else {
		string = string.replace(' ', '_');
		URL url
		    = (new URL
		       (new StringBuilder().append
			    ("http://multiplayer.needformadness.com/tracks/music/")
			    .append
			    (string).append
			    (".zip").toString()));
		module = ModuleLoader.loadMod(url);
	    }
	    if (module.isLoaded()) {
		ModuleSlayer moduleslayer
		    = ModuleLoader.prepareSlayer(module, i_0_, i, i_1_);
		byte[] is = moduleslayer.turnbytesNorm(bool);
		
		if (bool)
		    ((RadicalMod) this).rvol = moduleslayer.olav;
		/*
		((RadicalMod) this).sClip
		    = new SuperClip(is, moduleslayer.oln, i_3_);
		((SuperClip) ((RadicalMod) this).sClip).rollBackPos
		    = moduleslayer.rollBackPos;
		((SuperClip) ((RadicalMod) this).sClip).rollBackTrig
		    = moduleslayer.oln - moduleslayer.rollBackTrig;*/
		Object object_4_ = null;
		object = null;
		Object object_5_ = null;
		((RadicalMod) this).loaded = 2;
	    }
	} catch (Exception exception) {
	    System.out.println(new StringBuilder().append
				   ("Error downloading and making Mod: ")
				   .append
				   (exception.toString()).toString());
	    ((RadicalMod) this).loaded = 0;
	}
	System.runFinalization();
	System.gc();
    }
    
    public RadicalMod(String string) {
	((RadicalMod) this).loaded = 1;
	((RadicalMod) this).imod
	    = new StringBuilder().append("").append(Madness.fpath).append
		  ("").append
		  (string).append
		  ("").toString();
    }
    
    public void loadimod(boolean bool) {
	if (((RadicalMod) this).loaded == 1) {
	    int i = 44000;
	    int i_6_ = 160;
	    if (bool)
		i_6_ = 300;
	    int i_7_ = 125;
	    try {
		Module module = ModuleLoader.loadMod(((RadicalMod) this).imod);
		if (module.isLoaded()) {
		    ModuleSlayer moduleslayer
			= ModuleLoader.prepareSlayer(module, i, i_6_, i_7_);
		    byte[] is = moduleslayer.turnbytesNorm(bool);
		    if (bool)
			((RadicalMod) this).rvol = moduleslayer.olav;
		    /*((RadicalMod) this).sClip
		    
			= new SuperClip(is, moduleslayer.oln, 22000);
		    ((SuperClip) ((RadicalMod) this).sClip).rollBackPos
			= moduleslayer.rollBackPos;
		    ((SuperClip) ((RadicalMod) this).sClip).rollBackTrig
			= moduleslayer.oln - moduleslayer.rollBackTrig;*/
		    Object object = null;
		    Object object_8_ = null;
		    Object object_9_ = null;
		    ((RadicalMod) this).loaded = 2;
		}
	    } catch (Exception exception) {
		System.out.println(new StringBuilder().append
				       ("Error making a imod: ").append
				       (exception.toString()).toString());
		((RadicalMod) this).loaded = 0;
	    }
	    System.runFinalization();
	    System.gc();
	}
    }
    
    public void loadpmod(boolean bool) {
	if (((RadicalMod) this).loaded == 1) {
	    int i = 44000;
	    int i_10_ = 160;
	    if (bool)
		i_10_ = 300;
	    int i_11_ = 125;
	    try {
		Module module = ModuleLoader.loadMod(((RadicalMod) this).pmod);
		if (module.isLoaded()) {
		    ModuleSlayer moduleslayer
			= ModuleLoader.prepareSlayer(module, i, i_10_, i_11_);
		    byte[] is = moduleslayer.turnbytesNorm(bool);
		    if (bool)
			((RadicalMod) this).rvol = moduleslayer.olav;
		    /*((RadicalMod) this).sClip
			= new SuperClip(is, moduleslayer.oln, 22000);
		    ((SuperClip) ((RadicalMod) this).sClip).rollBackPos
			= moduleslayer.rollBackPos;
		    ((SuperClip) ((RadicalMod) this).sClip).rollBackTrig
			= moduleslayer.oln - moduleslayer.rollBackTrig;*/
		    Object object = null;
		    Object object_12_ = null;
		    Object object_13_ = null;
		    ((RadicalMod) this).loaded = 2;
		}
	    } catch (Exception exception) {
		System.out.println(new StringBuilder().append
				       ("Error making a imod: ").append
				       (exception.toString()).toString());
		((RadicalMod) this).loaded = 0;
	    }
	    System.runFinalization();
	    System.gc();
	}
    }
    
    public RadicalMod(String string, boolean bool) {
	((RadicalMod) this).loaded = 1;
	((RadicalMod) this).pmod = string;
	loadpmod(true);
    }
    
    public void play() {
	if (!((RadicalMod) this).playing && ((RadicalMod) this).loaded == 2) {
	    ((RadicalMod) this).sClip.play();
	    if (((SuperClip) ((RadicalMod) this).sClip).stoped == 0)
		((RadicalMod) this).playing = true;
	}
    }
    
    public void resume() {
	if (!((RadicalMod) this).playing && ((RadicalMod) this).loaded == 2) {
	    ((RadicalMod) this).sClip.resume();
	    if (((SuperClip) ((RadicalMod) this).sClip).stoped == 0)
		((RadicalMod) this).playing = true;
	}
    }
    
    public void stop() {
	if (((RadicalMod) this).playing && ((RadicalMod) this).loaded == 2) {
	    ((RadicalMod) this).sClip.stop();
	    ((RadicalMod) this).playing = false;
	}
    }
    
    protected void unloadimod() {
	if (((RadicalMod) this).loaded == 2) {
	    if (((RadicalMod) this).playing) {
		((RadicalMod) this).sClip.stop();
		((RadicalMod) this).playing = false;
	    }
	    try {
		((RadicalMod) this).sClip.close();
		((RadicalMod) this).sClip = null;
	    } catch (Exception exception) {
		/* empty */
	    }
	    System.gc();
	    ((RadicalMod) this).loaded = 1;
	}
    }
    
    protected void unload() {
	if (((RadicalMod) this).playing && ((RadicalMod) this).loaded == 2) {
	    ((RadicalMod) this).sClip.stop();
	    ((RadicalMod) this).playing = false;
	}
	try {
	    ((RadicalMod) this).sClip.close();
	    ((RadicalMod) this).sClip = null;
	} catch (Exception exception) {
	    /* empty */
	}
	try {
	    ((RadicalMod) this).imod = null;
	} catch (Exception exception) {
	    /* empty */
	}
	System.gc();
	((RadicalMod) this).loaded = 0;
    }
}
