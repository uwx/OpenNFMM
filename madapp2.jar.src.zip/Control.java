/* Control - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Control
{
    boolean left = false;
    boolean right = false;
    boolean up = false;
    boolean down = false;
    boolean handb = false;
    int lookback = 0;
    boolean enter = false;
    boolean exit = false;
    boolean arrace = false;
    boolean mutem = false;
    boolean mutes = false;
    boolean radar = false;
    int chatup = 0;
    int multion = 0;
    Medium m;
    int pan = 0;
    int attack = 0;
    int acr = 0;
    boolean afta = false;
    int[] fpnt = new int[5];
    int trfix = 0;
    boolean forget = false;
    boolean bulistc = false;
    int runbul = 0;
    int acuracy = 0;
    int upwait = 0;
    boolean agressed = false;
    float skiplev = 1.0F;
    int clrnce = 5;
    int rampp = 0;
    int turntyp = 0;
    float aim = 0.0F;
    int saftey = 30;
    boolean perfection = false;
    float mustland = 0.5F;
    boolean usebounce = false;
    float trickprf = 0.5F;
    int stuntf = 0;
    boolean zyinv = false;
    boolean lastl = false;
    boolean wlastl = false;
    int hold = 0;
    int wall = -1;
    int lwall = -1;
    int stcnt = 0;
    int statusque = 0;
    int turncnt = 0;
    int randtcnt = 0;
    int upcnt = 0;
    int trickfase = 0;
    int swat = 0;
    boolean udcomp = false;
    boolean lrcomp = false;
    boolean udbare = false;
    boolean lrbare = false;
    boolean onceu = false;
    boolean onced = false;
    boolean oncel = false;
    boolean oncer = false;
    int lrdirect = 0;
    int uddirect = 0;
    int lrstart = 0;
    int udstart = 0;
    int oxy = 0;
    int ozy = 0;
    int flycnt = 0;
    boolean lrswt = false;
    boolean udswt = false;
    boolean gowait = false;
    int actwait = 0;
    int cntrn = 0;
    int revstart = 0;
    int oupnt = 0;
    int wtz = 0;
    int wtx = 0;
    int frx = 0;
    int frz = 0;
    int frad = 0;
    int apunch = 0;
    boolean exitattack = false;
    int avoidnlev = 0;
    
    public Control(Medium medium) {
	((Control) this).m = medium;
    }
    
    public void falseo(int i) {
	((Control) this).left = false;
	((Control) this).right = false;
	((Control) this).up = false;
	((Control) this).down = false;
	((Control) this).handb = false;
	((Control) this).lookback = 0;
	((Control) this).enter = false;
	((Control) this).exit = false;
	if (i != 1) {
	    ((Control) this).radar = false;
	    ((Control) this).arrace = false;
	    ((Control) this).chatup = 0;
	    if (i != 2)
		((Control) this).multion = 0;
	    if (i != 3) {
		((Control) this).mutem = false;
		((Control) this).mutes = false;
	    }
	}
    }
    
    public void reset(CheckPoints checkpoints, int i) {
	((Control) this).pan = 0;
	((Control) this).attack = 0;
	((Control) this).acr = 0;
	((Control) this).afta = false;
	((Control) this).trfix = 0;
	((Control) this).acuracy = 0;
	((Control) this).upwait = 0;
	((Control) this).forget = false;
	((Control) this).bulistc = false;
	((Control) this).runbul = 0;
	((Control) this).revstart = 0;
	((Control) this).oupnt = 0;
	((Control) this).gowait = false;
	((Control) this).apunch = 0;
	((Control) this).exitattack = false;
	if (((CheckPoints) checkpoints).stage == 16
	    || ((CheckPoints) checkpoints).stage == 18)
	    ((Control) this).hold = 50;
	if (((CheckPoints) checkpoints).stage == 17)
	    ((Control) this).hold = 10;
	if (((CheckPoints) checkpoints).stage == 20)
	    ((Control) this).hold = 30;
	if (((CheckPoints) checkpoints).stage == 21) {
	    if (i != 13) {
		((Control) this).hold = 35;
		((Control) this).revstart = 25;
	    } else
		((Control) this).hold = 5;
	    ((Control) this).statusque = 0;
	}
	if (((CheckPoints) checkpoints).stage == 22) {
	    if (i != 13) {
		((Control) this).hold
		    = (int) (20.0F + 10.0F * ((Control) this).m.random());
		((Control) this).revstart
		    = (int) (10.0F + 10.0F * ((Control) this).m.random());
	    } else
		((Control) this).hold = 5;
	    ((Control) this).statusque = 0;
	}
	if (((CheckPoints) checkpoints).stage == 24) {
	    ((Control) this).hold = 30;
	    ((Control) this).statusque = 0;
	    if (i != 14)
		((Control) this).revstart = 1;
	}
	if (((CheckPoints) checkpoints).stage == 25)
	    ((Control) this).hold = 40;
	if (((CheckPoints) checkpoints).stage == 26)
	    ((Control) this).hold = 20;
	if (((CheckPoints) checkpoints).stage != 19
	    && ((CheckPoints) checkpoints).stage != 26) {
	    for (int i_0_ = 0; i_0_ < ((CheckPoints) checkpoints).fn; i_0_++) {
		int i_1_ = -10;
		for (int i_2_ = 0; i_2_ < ((CheckPoints) checkpoints).n;
		     i_2_++) {
		    if (py(((CheckPoints) checkpoints).fx[i_0_] / 100,
			   ((CheckPoints) checkpoints).x[i_2_] / 100,
			   ((CheckPoints) checkpoints).fz[i_0_] / 100,
			   ((CheckPoints) checkpoints).z[i_2_] / 100) < i_1_
			|| i_1_ == -10) {
			i_1_ = py(((CheckPoints) checkpoints).fx[i_0_] / 100,
				  ((CheckPoints) checkpoints).x[i_2_] / 100,
				  ((CheckPoints) checkpoints).fz[i_0_] / 100,
				  ((CheckPoints) checkpoints).z[i_2_] / 100);
			((Control) this).fpnt[i_0_] = i_2_;
		    }
		}
	    }
	    for (int i_3_ = 0; i_3_ < ((CheckPoints) checkpoints).fn; i_3_++) {
		((Control) this).fpnt[i_3_] -= 4;
		if (((Control) this).fpnt[i_3_] < 0)
		    ((Control) this).fpnt[i_3_]
			+= ((CheckPoints) checkpoints).nsp;
	    }
	} else {
	    if (((CheckPoints) checkpoints).stage == 19) {
		((Control) this).fpnt[0] = 14;
		((Control) this).fpnt[1] = 36;
	    }
	    if (((CheckPoints) checkpoints).stage == 26)
		((Control) this).fpnt[3] = 39;
	}
	((Control) this).left = false;
	((Control) this).right = false;
	((Control) this).up = false;
	((Control) this).down = false;
	((Control) this).handb = false;
	((Control) this).lookback = 0;
	((Control) this).arrace = false;
	((Control) this).mutem = false;
	((Control) this).mutes = false;
    }
    
    public void preform(Mad mad, ContO conto, CheckPoints checkpoints,
			Trackers trackers) {
	((Control) this).left = false;
	((Control) this).right = false;
	((Control) this).up = false;
	((Control) this).down = false;
	((Control) this).handb = false;
	if (!((Mad) mad).dest) {
	    if (((Mad) mad).mtouch) {
		if (((Control) this).stcnt > ((Control) this).statusque) {
		    int i = ((CheckPoints) checkpoints).stage;
		    if (i > 10)
			i -= 10;
		    ((Control) this).acuracy
			= ((7
			    - ((CheckPoints) checkpoints).pos[((Mad) mad).im])
			   * ((CheckPoints) checkpoints).pos[0] * (6 - i * 2));
		    if (((Control) this).acuracy < 0
			|| ((CheckPoints) checkpoints).stage == -1)
			((Control) this).acuracy = 0;
		    ((Control) this).clrnce = 5;
		    if (((CheckPoints) checkpoints).stage == 16
			|| ((CheckPoints) checkpoints).stage == 21)
			((Control) this).clrnce = 2;
		    if (((CheckPoints) checkpoints).stage == 22
			&& (((Mad) mad).pcleared == 27
			    || ((Mad) mad).pcleared == 17))
			((Control) this).clrnce = 3;
		    if (((CheckPoints) checkpoints).stage == 26
			&& ((Mad) mad).pcleared == 33)
			((Control) this).clrnce = 3;
		    float f = 0.0F;
		    if (((CheckPoints) checkpoints).stage == 1)
			f = 2.0F;
		    if (((CheckPoints) checkpoints).stage == 2)
			f = 1.5F;
		    if (((CheckPoints) checkpoints).stage == 3
			&& ((Mad) mad).cn != 6)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 4)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 11)
			f = 2.0F;
		    if (((CheckPoints) checkpoints).stage == 12)
			f = 1.5F;
		    if (((CheckPoints) checkpoints).stage == 13
			&& ((Mad) mad).cn != 9)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 14)
			f = 0.5F;
		    ((Control) this).upwait
			= (int) ((float) ((((CheckPoints) checkpoints).pos[0]
					   - (((CheckPoints) checkpoints).pos
					      [((Mad) mad).im]))
					  * (((CheckPoints) checkpoints).pos[0]
					     - (((CheckPoints) checkpoints).pos
						[((Mad) mad).im]))
					  * (((CheckPoints) checkpoints).pos[0]
					     - (((CheckPoints) checkpoints).pos
						[((Mad) mad).im])))
				 * f);
		    if (((Control) this).upwait > 80)
			((Control) this).upwait = 80;
		    if ((((CheckPoints) checkpoints).stage == 11
			 || ((CheckPoints) checkpoints).stage == 1)
			&& ((Control) this).upwait < 20)
			((Control) this).upwait = 20;
		    f = 0.0F;
		    if (((CheckPoints) checkpoints).stage == 1
			|| ((CheckPoints) checkpoints).stage == 2)
			f = 1.0F;
		    if (((CheckPoints) checkpoints).stage == 4)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 7)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 10)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 11
			|| ((CheckPoints) checkpoints).stage == 12)
			f = 1.0F;
		    if (((CheckPoints) checkpoints).stage == 13)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 14)
			f = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 15)
			f = 0.2F;
		    if ((((CheckPoints) checkpoints).pos[((Mad) mad).im]
			 - ((CheckPoints) checkpoints).pos[0])
			>= -1) {
			((Control) this).skiplev -= 0.1;
			if (((Control) this).skiplev < 0.0F)
			    ((Control) this).skiplev = 0.0F;
		    } else {
			((Control) this).skiplev += 0.2;
			if (((Control) this).skiplev > f)
			    ((Control) this).skiplev = f;
		    }
		    if (((CheckPoints) checkpoints).stage == 18) {
			if (((Mad) mad).pcleared >= 10
			    && ((Mad) mad).pcleared <= 24)
			    ((Control) this).skiplev = 1.0F;
			else
			    ((Control) this).skiplev = 0.0F;
		    }
		    if (((CheckPoints) checkpoints).stage == 21) {
			((Control) this).skiplev = 0.0F;
			if (((Mad) mad).pcleared == 5)
			    ((Control) this).skiplev = 1.0F;
			if (((Mad) mad).pcleared == 28
			    || ((Mad) mad).pcleared == 35)
			    ((Control) this).skiplev = 0.5F;
		    }
		    if (((CheckPoints) checkpoints).stage == 23)
			((Control) this).skiplev = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 24
			|| ((CheckPoints) checkpoints).stage == 22)
			((Control) this).skiplev = 1.0F;
		    if (((CheckPoints) checkpoints).stage == 26
			|| ((CheckPoints) checkpoints).stage == 25
			|| ((CheckPoints) checkpoints).stage == 20)
			((Control) this).skiplev = 0.0F;
		    ((Control) this).rampp
			= (int) (((Control) this).m.random() * 4.0F - 2.0F);
		    if (((Mad) mad).power == 98.0F)
			((Control) this).rampp = -1;
		    if (((Mad) mad).power < 75.0F
			&& ((Control) this).rampp == -1)
			((Control) this).rampp = 0;
		    if (((Mad) mad).power < 60.0F)
			((Control) this).rampp = 1;
		    if (((CheckPoints) checkpoints).stage == 6)
			((Control) this).rampp = 2;
		    if (((CheckPoints) checkpoints).stage == 18
			&& ((Mad) mad).pcleared >= 45)
			((Control) this).rampp = 2;
		    if (((CheckPoints) checkpoints).stage == 22
			&& ((Mad) mad).pcleared == 17)
			((Control) this).rampp = 2;
		    if (((CheckPoints) checkpoints).stage == 25
			|| ((CheckPoints) checkpoints).stage == 26)
			((Control) this).rampp = 0;
		    if (((Control) this).cntrn == 0) {
			((Control) this).agressed = false;
			((Control) this).turntyp
			    = (int) (((Control) this).m.random() * 4.0F);
			if (((CheckPoints) checkpoints).stage == 3
			    && ((Mad) mad).cn == 6) {
			    ((Control) this).turntyp = 1;
			    if (((Control) this).attack == 0)
				((Control) this).agressed = true;
			}
			if (((CheckPoints) checkpoints).stage == 9
			    && ((Mad) mad).cn == 15) {
			    ((Control) this).turntyp = 1;
			    if (((Control) this).attack == 0)
				((Control) this).agressed = true;
			}
			if (((CheckPoints) checkpoints).stage == 13
			    && ((Mad) mad).cn == 9) {
			    ((Control) this).turntyp = 1;
			    if (((Control) this).attack == 0)
				((Control) this).agressed = true;
			}
			if ((((CheckPoints) checkpoints).pos[0]
			     - ((CheckPoints) checkpoints).pos[((Mad) mad).im])
			    < 0)
			    ((Control) this).turntyp
				= (int) (((Control) this).m.random() * 2.0F);
			if (((CheckPoints) checkpoints).stage == 10)
			    ((Control) this).turntyp = 2;
			if (((CheckPoints) checkpoints).stage == 18)
			    ((Control) this).turntyp = 2;
			if (((CheckPoints) checkpoints).stage == 20)
			    ((Control) this).turntyp = 0;
			if (((CheckPoints) checkpoints).stage == 23)
			    ((Control) this).turntyp = 1;
			if (((CheckPoints) checkpoints).stage == 24)
			    ((Control) this).turntyp = 0;
			if (((Control) this).attack != 0) {
			    ((Control) this).turntyp = 2;
			    if (((CheckPoints) checkpoints).stage == 9
				|| ((CheckPoints) checkpoints).stage == 10
				|| ((CheckPoints) checkpoints).stage == 19
				|| ((CheckPoints) checkpoints).stage == 21
				|| ((CheckPoints) checkpoints).stage == 23
				|| ((CheckPoints) checkpoints).stage == 27)
				((Control) this).turntyp
				    = (int) (((Control) this).m.random()
					     * 3.0F);
			    if (((CheckPoints) checkpoints).stage == 26
				&& (((((CheckPoints) checkpoints).clear
				      [((Mad) mad).im])
				     - ((CheckPoints) checkpoints).clear[0])
				    >= 5))
				((Control) this).turntyp = 0;
			}
			if (((CheckPoints) checkpoints).stage == 6) {
			    ((Control) this).turntyp = 1;
			    ((Control) this).agressed = true;
			}
			if (((CheckPoints) checkpoints).stage == 7
			    || ((CheckPoints) checkpoints).stage == 9
			    || ((CheckPoints) checkpoints).stage == 10
			    || ((CheckPoints) checkpoints).stage == 16
			    || ((CheckPoints) checkpoints).stage == 17
			    || ((CheckPoints) checkpoints).stage == 19
			    || ((CheckPoints) checkpoints).stage == 20
			    || ((CheckPoints) checkpoints).stage == 21
			    || ((CheckPoints) checkpoints).stage == 22
			    || ((CheckPoints) checkpoints).stage == 24
			    || ((CheckPoints) checkpoints).stage == 26
			    || ((CheckPoints) checkpoints).stage == 27)
			    ((Control) this).agressed = true;
			if (((CheckPoints) checkpoints).stage == -1) {
			    if (((Control) this).m.random()
				> ((Control) this).m.random())
				((Control) this).agressed = true;
			    else
				((Control) this).agressed = false;
			}
			((Control) this).cntrn = 5;
		    } else
			((Control) this).cntrn--;
		    ((Control) this).saftey
			= (int) ((double) ((98.0F - ((Mad) mad).power) / 2.0F)
				 * ((double) (((Control) this).m.random()
					      / 2.0F)
				    + 0.5));
		    if (((Control) this).saftey > 20)
			((Control) this).saftey = 20;
		    f = 0.0F;
		    if (((CheckPoints) checkpoints).stage == 1
			|| ((CheckPoints) checkpoints).stage == 11)
			f = 0.9F;
		    if (((CheckPoints) checkpoints).stage == 2
			|| ((CheckPoints) checkpoints).stage == 12)
			f = 0.7F;
		    if (((CheckPoints) checkpoints).stage == 4
			|| ((CheckPoints) checkpoints).stage == 13)
			f = 0.4F;
		    ((Control) this).mustland
			= f + (float) ((double) (((Control) this).m.random()
						 / 2.0F)
				       - 0.25);
		    f = 1.0F;
		    if (((CheckPoints) checkpoints).stage == 1
			|| ((CheckPoints) checkpoints).stage == 11)
			f = 5.0F;
		    if (((CheckPoints) checkpoints).stage == 2
			|| ((CheckPoints) checkpoints).stage == 12)
			f = 2.0F;
		    if (((CheckPoints) checkpoints).stage == 4
			|| ((CheckPoints) checkpoints).stage == 13)
			f = 1.5F;
		    if (((Mad) mad).power > 50.0F) {
			if ((((CheckPoints) checkpoints).pos[0]
			     - ((CheckPoints) checkpoints).pos[((Mad) mad).im])
			    > 0)
			    ((Control) this).saftey *= f;
			else
			    ((Control) this).mustland = 0.0F;
		    } else
			((Control) this).mustland -= 0.5F;
		    if (((CheckPoints) checkpoints).stage == 18
			|| ((CheckPoints) checkpoints).stage == 20
			|| ((CheckPoints) checkpoints).stage == 22
			|| ((CheckPoints) checkpoints).stage == 24)
			((Control) this).mustland = 0.0F;
		    ((Control) this).stuntf = 0;
		    if (((CheckPoints) checkpoints).stage == 8)
			((Control) this).stuntf = 17;
		    if (((CheckPoints) checkpoints).stage == 18
			&& ((Mad) mad).pcleared == 57)
			((Control) this).stuntf = 1;
		    if (((CheckPoints) checkpoints).stage == 19
			&& ((Mad) mad).pcleared == 3)
			((Control) this).stuntf = 2;
		    if (((CheckPoints) checkpoints).stage == 20) {
			if ((((CheckPoints) checkpoints).pos[0]
			     < ((CheckPoints) checkpoints).pos[((Mad) mad).im])
			    || Math.abs(((CheckPoints) checkpoints).clear[0]
					- ((Mad) mad).clear) >= 2
			    || ((Mad) mad).clear < 2) {
			    ((Control) this).stuntf = 4;
			    ((Control) this).saftey = 10;
			} else
			    ((Control) this).stuntf = 3;
		    }
		    if (((CheckPoints) checkpoints).stage == 21
			&& ((Mad) mad).pcleared == 21)
			((Control) this).stuntf = 1;
		    if (((CheckPoints) checkpoints).stage == 24) {
			((Control) this).saftey = 10;
			if (((Mad) mad).pcleared >= 4
			    && ((Mad) mad).pcleared < 70)
			    ((Control) this).stuntf = 4;
			else if (((Mad) mad).cn == 12 || ((Mad) mad).cn == 8)
			    ((Control) this).stuntf = 2;
			if (((Mad) mad).cn == 14)
			    ((Control) this).stuntf = 6;
		    }
		    if (((CheckPoints) checkpoints).stage == 26) {
			((Control) this).mustland = 0.0F;
			((Control) this).saftey = 10;
			if ((((Mad) mad).pcleared == 15
			     || ((Mad) mad).pcleared == 51)
			    && ((double) ((Control) this).m.random() > 0.4
				|| ((Control) this).trfix != 0))
			    ((Control) this).stuntf = 7;
			if (((Mad) mad).pcleared == 42)
			    ((Control) this).stuntf = 1;
			if (((Mad) mad).pcleared == 77)
			    ((Control) this).stuntf = 7;
			((Control) this).avoidnlev
			    = (int) (2700.0F * ((Control) this).m.random());
		    }
		    ((Control) this).trickprf
			= ((((Mad) mad).power - 38.0F) / 50.0F
			   - ((Control) this).m.random() / 2.0F);
		    if (((Mad) mad).power < 60.0F)
			((Control) this).trickprf = -1.0F;
		    if (((CheckPoints) checkpoints).stage == 6
			&& (double) ((Control) this).trickprf > 0.5)
			((Control) this).trickprf = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 3
			&& ((Mad) mad).cn == 6
			&& (double) ((Control) this).trickprf > 0.7)
			((Control) this).trickprf = 0.7F;
		    if (((CheckPoints) checkpoints).stage == 13
			&& ((Mad) mad).cn == 9
			&& (double) ((Control) this).trickprf > 0.7)
			((Control) this).trickprf = 0.7F;
		    if (((CheckPoints) checkpoints).stage == 16
			&& (double) ((Control) this).trickprf > 0.3)
			((Control) this).trickprf = 0.3F;
		    if (((CheckPoints) checkpoints).stage == 18
			&& (double) ((Control) this).trickprf > 0.2)
			((Control) this).trickprf = 0.2F;
		    if (((CheckPoints) checkpoints).stage == 19) {
			if ((double) ((Control) this).trickprf > 0.5)
			    ((Control) this).trickprf = 0.5F;
			if ((((Mad) mad).im == 6 || ((Mad) mad).im == 5)
			    && (double) ((Control) this).trickprf > 0.3)
			    ((Control) this).trickprf = 0.3F;
		    }
		    if (((CheckPoints) checkpoints).stage == 21
			&& ((Control) this).trickprf != -1.0F)
			((Control) this).trickprf *= 0.75F;
		    if (((CheckPoints) checkpoints).stage == 22
			&& (((Mad) mad).pcleared == 55
			    || ((Mad) mad).pcleared == 7)) {
			((Control) this).trickprf = -1.0F;
			((Control) this).stuntf = 5;
		    }
		    if (((CheckPoints) checkpoints).stage == 23
			&& (double) ((Control) this).trickprf > 0.4)
			((Control) this).trickprf = 0.4F;
		    if (((CheckPoints) checkpoints).stage == 24
			&& (double) ((Control) this).trickprf > 0.5)
			((Control) this).trickprf = 0.5F;
		    if (((CheckPoints) checkpoints).stage == 27)
			((Control) this).trickprf = -1.0F;
		    if (((Control) this).m.random()
			> ((Mad) mad).power / 100.0F)
			((Control) this).usebounce = true;
		    else
			((Control) this).usebounce = false;
		    if (((CheckPoints) checkpoints).stage == 9)
			((Control) this).usebounce = false;
		    if (((CheckPoints) checkpoints).stage == 14
			|| ((CheckPoints) checkpoints).stage == 16)
			((Control) this).usebounce = true;
		    if (((CheckPoints) checkpoints).stage == 20
			|| ((CheckPoints) checkpoints).stage == 24)
			((Control) this).usebounce = false;
		    if (((Control) this).m.random()
			> ((float) ((Mad) mad).hitmag
			   / (float) (((CarDefine) ((Mad) mad).cd).maxmag
				      [((Mad) mad).cn])))
			((Control) this).perfection = false;
		    else
			((Control) this).perfection = true;
		    if ((100.0F * (float) ((Mad) mad).hitmag
			 / (float) (((CarDefine) ((Mad) mad).cd).maxmag
				    [((Mad) mad).cn]))
			> 60.0F)
			((Control) this).perfection = true;
		    if (((CheckPoints) checkpoints).stage == 3
			&& ((Mad) mad).cn == 6)
			((Control) this).perfection = true;
		    if (((CheckPoints) checkpoints).stage == 6
			|| ((CheckPoints) checkpoints).stage == 8
			|| ((CheckPoints) checkpoints).stage == 9
			|| ((CheckPoints) checkpoints).stage == 10
			|| ((CheckPoints) checkpoints).stage == 16
			|| ((CheckPoints) checkpoints).stage == 18
			|| ((CheckPoints) checkpoints).stage == 19
			|| ((CheckPoints) checkpoints).stage == 20
			|| ((CheckPoints) checkpoints).stage == 21
			|| ((CheckPoints) checkpoints).stage == 22
			|| ((CheckPoints) checkpoints).stage == 24
			|| ((CheckPoints) checkpoints).stage == 26
			|| ((CheckPoints) checkpoints).stage == 27)
			((Control) this).perfection = true;
		    if (((Control) this).attack == 0) {
			boolean bool = true;
			if (((CheckPoints) checkpoints).stage == 3
			    || ((CheckPoints) checkpoints).stage == 1
			    || ((CheckPoints) checkpoints).stage == 4
			    || ((CheckPoints) checkpoints).stage == 9
			    || ((CheckPoints) checkpoints).stage == 13
			    || ((CheckPoints) checkpoints).stage == 11
			    || ((CheckPoints) checkpoints).stage == 14
			    || ((CheckPoints) checkpoints).stage == 19
			    || ((CheckPoints) checkpoints).stage == 23
			    || ((CheckPoints) checkpoints).stage == 26)
			    bool = ((Control) this).afta;
			if (((CheckPoints) checkpoints).stage == 8
			    || ((CheckPoints) checkpoints).stage == 6
			    || ((CheckPoints) checkpoints).stage == 18
			    || ((CheckPoints) checkpoints).stage == 16
			    || ((CheckPoints) checkpoints).stage == 20
			    || ((CheckPoints) checkpoints).stage == 24)
			    bool = false;
			if (((CheckPoints) checkpoints).stage == 3
			    && ((Mad) mad).cn == 6)
			    bool = false;
			if (((CheckPoints) checkpoints).stage == -1
			    && (((Control) this).m.random()
				> ((Control) this).m.random()))
			    bool = false;
			boolean bool_4_ = false;
			if (((CheckPoints) checkpoints).stage == 13
			    && ((Mad) mad).cn == 9)
			    bool_4_ = true;
			if (((CheckPoints) checkpoints).stage == 18
			    && ((Mad) mad).cn == 11)
			    bool_4_ = true;
			if (((CheckPoints) checkpoints).stage == 19
			    && ((CheckPoints) checkpoints).clear[0] >= 20)
			    bool_4_ = true;
			if (((CheckPoints) checkpoints).stage == 4
			    || ((CheckPoints) checkpoints).stage == 10
			    || ((CheckPoints) checkpoints).stage == 21
			    || ((CheckPoints) checkpoints).stage == 22
			    || ((CheckPoints) checkpoints).stage == 23
			    || ((CheckPoints) checkpoints).stage == 25
			    || ((CheckPoints) checkpoints).stage == 26)
			    bool_4_ = true;
			if (((CheckPoints) checkpoints).stage == 3
			    && ((Mad) mad).cn == 6)
			    bool_4_ = true;
			int i_5_ = 60;
			if (((CheckPoints) checkpoints).stage == 5)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 6
			    && ((Control) this).bulistc)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 9
			    && ((Control) this).bulistc)
			    i_5_ = 30;
			if (((CheckPoints) checkpoints).stage == 3
			    || ((CheckPoints) checkpoints).stage == 13
			    || ((CheckPoints) checkpoints).stage == 21
			    || ((CheckPoints) checkpoints).stage == 27
			    || ((CheckPoints) checkpoints).stage == 20
			    || ((CheckPoints) checkpoints).stage == 18)
			    i_5_ = 30;
			if ((((CheckPoints) checkpoints).stage == 12
			     || ((CheckPoints) checkpoints).stage == 23)
			    && ((Mad) mad).cn == 13)
			    i_5_ = 50;
			if (((CheckPoints) checkpoints).stage == 14)
			    i_5_ = 20;
			if (((CheckPoints) checkpoints).stage == 15
			    && ((Mad) mad).im != 6)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 17)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 18
			    && ((Mad) mad).cn == 11)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 19 && bool_4_)
			    i_5_ = 30;
			if (((CheckPoints) checkpoints).stage == 21
			    && ((Control) this).bulistc)
			    i_5_ = 30;
			if (((CheckPoints) checkpoints).stage == 22)
			    i_5_ = 50;
			if (((CheckPoints) checkpoints).stage == 25
			    && ((Control) this).bulistc)
			    i_5_ = 40;
			if (((CheckPoints) checkpoints).stage == 26) {
			    if (((Mad) mad).cn == 11
				&& ((CheckPoints) checkpoints).clear[0] == 27)
				i_5_ = 0;
			    if (((Mad) mad).cn == 15 || ((Mad) mad).cn == 9)
				i_5_ = 50;
			    if (((Mad) mad).cn == 11)
				i_5_ = 40;
			    if (((CheckPoints) checkpoints).pos[0]
				> (((CheckPoints) checkpoints).pos
				   [((Mad) mad).im]))
				i_5_ = 80;
			}
			for (int i_6_ = 0; i_6_ < 7; i_6_++) {
			    if (i_6_ != ((Mad) mad).im
				&& (((CheckPoints) checkpoints).clear[i_6_]
				    != -1)) {
				int i_7_ = ((ContO) conto).xz;
				if (((Control) this).zyinv)
				    i_7_ += 180;
				for (/**/; i_7_ < 0; i_7_ += 360) {
				    /* empty */
				}
				for (/**/; i_7_ > 180; i_7_ -= 360) {
				    /* empty */
				}
				int i_8_ = 0;
				if ((((CheckPoints) checkpoints).opx[i_6_]
				     - ((ContO) conto).x)
				    >= 0)
				    i_8_ = 180;
				int i_9_;
				for (i_9_
					 = (int) ((double) (90 + i_8_)
						  + ((Math.atan
						      ((double) ((((CheckPoints)
								   checkpoints)
								  .opz[i_6_])
								 - ((ContO)
								    conto).z)
						       / (double) ((((CheckPoints)
								     checkpoints)
								    .opx[i_6_])
								   - (((ContO)
								       conto)
								      .x))))
						     / 0.017453292519943295));
				     i_9_ < 0; i_9_ += 360) {
				    /* empty */
				}
				for (/**/; i_9_ > 180; i_9_ -= 360) {
				    /* empty */
				}
				int i_10_ = Math.abs(i_7_ - i_9_);
				if (i_10_ > 180)
				    i_10_ = Math.abs(i_10_ - 360);
				int i_11_
				    = (2000
				       * (Math.abs((((CheckPoints) checkpoints)
						    .clear[i_6_])
						   - ((Mad) mad).clear)
					  + 1));
				if ((((CheckPoints) checkpoints).stage == 6
				     || ((CheckPoints) checkpoints).stage == 9)
				    && ((Control) this).bulistc)
				    i_11_ = 6000;
				if (((CheckPoints) checkpoints).stage == 3
				    && ((Mad) mad).cn == 6
				    && ((CheckPoints) checkpoints).wasted < 2
				    && i_11_ > 4000)
				    i_11_ = 4000;
				if (((CheckPoints) checkpoints).stage == 13
				    && ((Mad) mad).cn == 9 && i_11_ < 12000)
				    i_11_ = 12000;
				if (((CheckPoints) checkpoints).stage == 14
				    && i_11_ < 4000)
				    i_11_ = 4000;
				if (((CheckPoints) checkpoints).stage == 18
				    && ((Mad) mad).cn == 11) {
				    if (i_11_ < 12000)
					i_11_ = 12000;
				    i_10_ = 10;
				}
				if (((CheckPoints) checkpoints).stage == 19
				    && (((Mad) mad).pcleared == 13
					|| ((Mad) mad).pcleared == 33
					|| bool_4_)
				    && i_11_ < 12000)
				    i_11_ = 12000;
				if (((CheckPoints) checkpoints).stage == 21) {
				    if (((Control) this).bulistc) {
					i_11_ = 8000;
					i_10_ = 10;
					((Control) this).afta = true;
				    } else if (i_11_ < 6000)
					i_11_ = 6000;
				}
				if (((CheckPoints) checkpoints).stage == 22
				    && ((Control) this).bulistc) {
				    i_11_ = 6000;
				    i_10_ = 10;
				}
				if (((CheckPoints) checkpoints).stage == 23)
				    i_11_ = 21000;
				if (((CheckPoints) checkpoints).stage == 25) {
				    i_11_ *= Math.abs(((CheckPoints)
						       checkpoints).clear[i_6_]
						      - ((Mad) mad).clear) + 1;
				    if (((Control) this).bulistc) {
					i_11_
					    = (4000
					       * (Math.abs((((CheckPoints)
							     checkpoints)
							    .clear[i_6_])
							   - ((Mad) mad).clear)
						  + 1));
					i_10_ = 10;
				    }
				}
				if (((CheckPoints) checkpoints).stage == 20)
				    i_11_ = 16000;
				if (((CheckPoints) checkpoints).stage == 26) {
				    if (((Mad) mad).cn == 13
					&& ((Control) this).bulistc) {
					if (((Control) this).oupnt == 33)
					    i_11_ = 17000;
					if (((Control) this).oupnt == 51)
					    i_11_ = 30000;
					if (((Control) this).oupnt == 15
					    && (((CheckPoints) checkpoints)
						.clear[0]) >= 14)
					    i_11_ = 60000;
					i_10_ = 10;
				    }
				    if (((Mad) mad).cn == 15
					|| ((Mad) mad).cn == 9)
					i_11_ *= (Math.abs((((CheckPoints)
							     checkpoints)
							    .clear[i_6_])
							   - ((Mad) mad).clear)
						  + 1);
				    if (((Mad) mad).cn == 11)
					i_11_
					    = (4000
					       * (Math.abs((((CheckPoints)
							     checkpoints)
							    .clear[i_6_])
							   - ((Mad) mad).clear)
						  + 1));
				}
				int i_12_
				    = 85 + 15 * (Math.abs((((CheckPoints)
							    checkpoints)
							   .clear[i_6_])
							  - ((Mad) mad).clear)
						 + 1);
				if (((CheckPoints) checkpoints).stage == 23)
				    i_12_ = 45;
				if (((CheckPoints) checkpoints).stage == 26
				    && (((Mad) mad).cn == 15
					|| ((Mad) mad).cn == 9
					|| ((Mad) mad).cn == 11
					|| ((Mad) mad).cn == 14))
				    i_12_ = 50 + 70 * Math.abs((((CheckPoints)
								 checkpoints)
								.clear[i_6_])
							       - (((Mad) mad)
								  .clear));
				if (i_10_ < i_12_
				    && py(((ContO) conto).x / 100,
					  (((CheckPoints) checkpoints).opx
					   [i_6_]) / 100,
					  ((ContO) conto).z / 100,
					  (((CheckPoints) checkpoints).opz
					   [i_6_]) / 100) < i_11_
				    && ((Control) this).afta
				    && ((Mad) mad).power > (float) i_5_) {
				    float f_13_
					= (float) (35
						   - (Math.abs((((CheckPoints)
								 checkpoints)
								.clear[i_6_])
							       - (((Mad) mad)
								  .clear))
						      * 10));
				    if (f_13_ < 1.0F)
					f_13_ = 1.0F;
				    float f_14_
					= ((float) (((((CheckPoints)
						       checkpoints)
						      .pos[((Mad) mad).im])
						     + 1)
						    * (5 - (((CheckPoints)
							     checkpoints)
							    .pos[i_6_])))
					   / f_13_);
				    if (((CheckPoints) checkpoints).stage != 27
					&& (double) f_14_ > 0.7)
					f_14_ = 0.7F;
				    if (i_6_ != 0
					&& (((CheckPoints) checkpoints).pos[0]
					    < (((CheckPoints) checkpoints).pos
					       [((Mad) mad).im])))
					f_14_ = 0.0F;
				    if (i_6_ != 0 && bool_4_)
					f_14_ = 0.0F;
				    if (bool_4_
					&& (((CheckPoints) checkpoints).stage
					    == 3)
					&& i_6_ == 0) {
					if (((CheckPoints) checkpoints).wasted
					    >= 2)
					    f_14_ *= 0.5F;
					else
					    f_14_ = 0.0F;
				    }
				    if ((((CheckPoints) checkpoints).stage == 3
					 || (((CheckPoints) checkpoints).stage
					     == 9))
					&& i_6_ == 4)
					f_14_ = 0.0F;
				    if (((CheckPoints) checkpoints).stage
					== 6) {
					f_14_ = 0.0F;
					if (((Control) this).bulistc
					    && i_6_ == 0)
					    f_14_ = 1.0F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 8) {
					f_14_ = 0.0F;
					if (((Control) this).bulistc
					    && ((Mad) mad).cn != 11
					    && ((Mad) mad).cn != 13)
					    f_14_ = 1.0F;
				    }
				    if (((CheckPoints) checkpoints).stage == 9
					&& ((Mad) mad).cn == 15)
					f_14_ = 0.0F;
				    if (((CheckPoints) checkpoints).stage == 9
					&& ((Control) this).bulistc) {
					if (i_6_ == 0)
					    f_14_ = 1.0F;
					else
					    f_14_ = 0.0F;
				    }
				    if (((CheckPoints) checkpoints).stage == 9
					&& ((((CheckPoints) checkpoints).pos
					     [i_6_]) == 4
					    || (((CheckPoints) checkpoints).pos
						[i_6_]) == 3))
					f_14_ = 0.0F;
				    if (((CheckPoints) checkpoints).stage
					== 13) {
					if (((Mad) mad).cn == 9
					    || (((Mad) mad).cn == 13
						&& ((Control) this).bulistc))
					    f_14_ *= 2.0F;
					else
					    f_14_ *= 0.5F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 16)
					f_14_ = 0.0F;
				    if (((CheckPoints) checkpoints).stage == 17
					&& ((Mad) mad).im == 6 && i_6_ == 0)
					f_14_ *= 1.5;
				    if (((CheckPoints) checkpoints).stage
					== 18) {
					if (((Mad) mad).cn == 11
					    || (((Mad) mad).cn == 13
						&& ((Control) this).bulistc))
					    f_14_ *= 1.5F;
					else
					    f_14_ = 0.0F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 19) {
					if (i_6_ != 0)
					    f_14_ *= 0.5;
					if (((Mad) mad).pcleared != 13
					    && ((Mad) mad).pcleared != 33
					    && !bool_4_)
					    f_14_ *= 0.5F;
					if ((((Mad) mad).im == 6
					     || ((Mad) mad).im == 5)
					    && i_6_ != 0)
					    f_14_ = 0.0F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 20) {
					f_14_ = 0.0F;
					if (((Control) this).bulistc
					    && ((Mad) mad).cn != 11
					    && ((Mad) mad).cn != 13)
					    f_14_ = 1.0F;
				    }
				    if (((CheckPoints) checkpoints).stage == 21
					&& ((Control) this).bulistc
					&& i_6_ == 0)
					f_14_ = 1.0F;
				    if (((CheckPoints) checkpoints).stage
					== 22) {
					if (((Mad) mad).cn != 11
					    && ((Mad) mad).cn != 13)
					    f_14_ = 0.0F;
					if (((Mad) mad).cn == 13 && i_6_ == 0)
					    f_14_ = 1.0F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 24)
					f_14_ = 0.0F;
				    if (((CheckPoints) checkpoints).stage
					== 25) {
					if ((((CheckPoints) checkpoints).pos
					     [((Mad) mad).im])
					    == 0)
					    f_14_ *= 0.5;
					if (((CheckPoints) checkpoints).pos[0]
					    < (((CheckPoints) checkpoints).pos
					       [((Mad) mad).im]))
					    f_14_ *= 2.0F;
					if (((Control) this).bulistc
					    && i_6_ == 0)
					    f_14_ = 1.0F;
				    }
				    if (((CheckPoints) checkpoints).stage
					== 26) {
					if (((Mad) mad).cn != 14) {
					    if (((((CheckPoints) checkpoints)
						  .pos[0])
						 < (((CheckPoints) checkpoints)
						    .pos[((Mad) mad).im]))
						&& (((CheckPoints)
						     checkpoints).clear[0]
						    - (((CheckPoints)
							checkpoints)
						       .clear
						       [((Mad) mad).im])) != 1)
						f_14_ *= 2.0F;
					} else
					    f_14_ *= 0.5;
					if (((Mad) mad).cn == 13 && i_6_ == 0)
					    f_14_ = 1.0F;
					if ((((CheckPoints) checkpoints).pos
					     [((Mad) mad).im]) == 0
					    || ((((CheckPoints) checkpoints)
						 .pos[((Mad) mad).im]) == 1
						&& (((CheckPoints) checkpoints)
						    .pos[0]) == 0))
					    f_14_ = 0.0F;
					if (((((CheckPoints) checkpoints).clear
					      [((Mad) mad).im])
					     - (((CheckPoints) checkpoints)
						.clear[0])) >= 5
					    && i_6_ == 0)
					    f_14_ = 1.0F;
					if (((Mad) mad).cn == 10
					    || ((Mad) mad).cn == 12)
					    f_14_ = 0.0F;
				    }
				    if (((Control) this).m.random() < f_14_) {
					((Control) this).attack
					    = (40
					       * (Math.abs((((CheckPoints)
							     checkpoints)
							    .clear[i_6_])
							   - ((Mad) mad).clear)
						  + 1));
					if (((Control) this).attack > 500)
					    ((Control) this).attack = 500;
					((Control) this).aim = 0.0F;
					if ((((CheckPoints) checkpoints).stage
					     == 13)
					    && ((Mad) mad).cn == 9
					    && (((Control) this).m.random()
						> ((Control) this).m.random()))
					    ((Control) this).aim = 1.0F;
					if (((CheckPoints) checkpoints).stage
					    == 14) {
					    if (i_6_ == 0
						&& (((CheckPoints)
						     checkpoints).pos[0]
						    < (((CheckPoints)
							checkpoints)
						       .pos[((Mad) mad).im])))
						((Control) this).aim = 1.5F;
					    else
						((Control) this).aim
						    = ((Control) this).m
							  .random();
					}
					if (((CheckPoints) checkpoints).stage
					    == 15)
					    ((Control) this).aim
						= (((Control) this).m.random()
						   * 1.5F);
					if ((((CheckPoints) checkpoints).stage
					     == 17)
					    && ((Mad) mad).im != 6
					    && ((((Control) this).m.random()
						 > ((Control) this).m.random())
						|| (((CheckPoints)
						     checkpoints).pos[0]
						    < (((CheckPoints)
							checkpoints)
						       .pos[((Mad) mad).im]))))
					    ((Control) this).aim = 1.0F;
					if ((((CheckPoints) checkpoints).stage
					     == 18)
					    && ((Mad) mad).cn == 11
					    && (((Control) this).m.random()
						> ((Control) this).m.random()))
					    ((Control) this).aim
						= 0.76F + (((Control) this)
							       .m.random()
							   * 0.76F);
					if ((((CheckPoints) checkpoints).stage
					     == 19)
					    && (((Mad) mad).pcleared == 13
						|| ((Mad) mad).pcleared == 33))
					    ((Control) this).aim = 1.0F;
					if (((CheckPoints) checkpoints).stage
					    == 21) {
					    if (((Control) this).bulistc) {
						((Control) this).aim = 0.7F;
						if (((Control) this).attack
						    > 150)
						    ((Control) this).attack
							= 150;
					    } else
						((Control) this).aim
						    = ((Control) this).m
							  .random();
					}
					if (((CheckPoints) checkpoints).stage
					    == 22) {
					    if (((Control) this).m.random()
						> ((Control) this).m.random())
						((Control) this).aim = 0.7F;
					    if (((Control) this).bulistc
						&& (((Control) this).attack
						    > 150))
						((Control) this).attack = 150;
					}
					if ((((CheckPoints) checkpoints).stage
					     == 23)
					    && ((Control) this).attack > 60)
					    ((Control) this).attack = 60;
					if (((CheckPoints) checkpoints).stage
					    == 25) {
					    ((Control) this).aim
						= (((Control) this).m.random()
						   * 1.5F);
					    ((Control) this).attack
						= ((Control) this).attack / 2;
					    if (((Control) this).m.random()
						> ((Control) this).m.random())
						((Control) this).exitattack
						    = true;
					    else
						((Control) this).exitattack
						    = false;
					}
					if (((CheckPoints) checkpoints).stage
					    == 26) {
					    if (((Mad) mad).cn == 13) {
						((Control) this).aim = 0.76F;
						((Control) this).attack = 150;
					    } else {
						((Control) this).aim
						    = ((Control) this).m
							  .random() * 1.5F;
						if (Math.abs((((CheckPoints)
							       checkpoints)
							      .clear[i_6_])
							     - (((Mad) mad)
								.clear)) <= 2
						    || ((Mad) mad).cn == 14)
						    ((Control) this).attack
							= (((Control) this)
							   .attack) / 3;
					    }
					}
					if ((((CheckPoints) checkpoints).stage
					     == -1)
					    && (((Control) this).m.random()
						> ((Control) this).m.random()))
					    ((Control) this).aim
						= (((Control) this).m.random()
						   * 1.5F);
					((Control) this).acr = i_6_;
					((Control) this).turntyp
					    = (int) (1.0F
						     + ((Control) this).m
							   .random() * 2.0F);
				    }
				}
				if (bool && i_10_ > 100
				    && py(((ContO) conto).x / 100,
					  (((CheckPoints) checkpoints).opx
					   [i_6_]) / 100,
					  ((ContO) conto).z / 100,
					  (((CheckPoints) checkpoints).opz
					   [i_6_]) / 100) < 300
				    && ((double) ((Control) this).m.random()
					> (0.6
					   - (double) ((float) (((CheckPoints)
								 checkpoints)
								.pos
								[(((Mad) mad)
								  .im)])
						       / 10.0F)))) {
				    ((Control) this).clrnce = 0;
				    ((Control) this).acuracy = 0;
				}
			    }
			}
		    }
		    boolean bool = false;
		    if (((CheckPoints) checkpoints).stage == 6
			|| ((CheckPoints) checkpoints).stage == 8)
			bool = true;
		    if (((CheckPoints) checkpoints).stage == 9
			&& ((Mad) mad).cn == 15)
			bool = true;
		    if (((CheckPoints) checkpoints).stage == 16
			|| ((CheckPoints) checkpoints).stage == 20
			|| ((CheckPoints) checkpoints).stage == 21
			|| ((CheckPoints) checkpoints).stage == 27)
			bool = true;
		    if (((CheckPoints) checkpoints).stage == 18
			&& ((Mad) mad).pcleared != 73)
			bool = true;
		    if (((CheckPoints) checkpoints).stage == -1
			&& (((Control) this).m.random()
			    > ((Control) this).m.random()))
			bool = true;
		    if (((Control) this).trfix != 3) {
			((Control) this).trfix = 0;
			int i_15_ = 50;
			if (((CheckPoints) checkpoints).stage == 26)
			    i_15_ = 40;
			if ((100.0F * (float) ((Mad) mad).hitmag
			     / (float) (((CarDefine) ((Mad) mad).cd).maxmag
					[((Mad) mad).cn]))
			    > (float) i_15_)
			    ((Control) this).trfix = 1;
			if (!bool) {
			    int i_16_ = 80;
			    if (((CheckPoints) checkpoints).stage == 18
				&& ((Mad) mad).cn != 11)
				i_16_ = 50;
			    if (((CheckPoints) checkpoints).stage == 19)
				i_16_ = 70;
			    if (((CheckPoints) checkpoints).stage == 25
				&& ((Mad) mad).pcleared == 91)
				i_16_ = 50;
			    if (((CheckPoints) checkpoints).stage == 26
				&& (((((CheckPoints) checkpoints).clear
				      [((Mad) mad).im])
				     - ((CheckPoints) checkpoints).clear[0])
				    >= 5)
				&& ((Mad) mad).cn != 10
				&& ((Mad) mad).cn != 12)
				i_16_ = 50;
			    if ((100.0F * (float) ((Mad) mad).hitmag
				 / (float) (((CarDefine) ((Mad) mad).cd).maxmag
					    [((Mad) mad).cn]))
				> (float) i_16_)
				((Control) this).trfix = 2;
			}
		    } else {
			((Control) this).upwait = 0;
			((Control) this).acuracy = 0;
			((Control) this).skiplev = 1.0F;
			((Control) this).clrnce = 2;
		    }
		    if (!((Control) this).bulistc) {
			if (((CheckPoints) checkpoints).stage == 18
			    && ((Mad) mad).cn == 11
			    && ((Mad) mad).pcleared == 35) {
			    ((Mad) mad).pcleared = 73;
			    ((Mad) mad).clear = 0;
			    ((Control) this).bulistc = true;
			    ((Control) this).runbul
				= (int) (100.0F * ((Control) this).m.random());
			}
			if (((CheckPoints) checkpoints).stage == 21
			    && ((Mad) mad).cn == 13)
			    ((Control) this).bulistc = true;
			if (((CheckPoints) checkpoints).stage == 22
			    && ((Mad) mad).cn == 13)
			    ((Control) this).bulistc = true;
			if (((CheckPoints) checkpoints).stage == 25
			    && (((CheckPoints) checkpoints).clear[0]
				- ((Mad) mad).clear) >= 3
			    && ((Control) this).trfix == 0) {
			    ((Control) this).bulistc = true;
			    ((Control) this).oupnt = -1;
			}
			if (((CheckPoints) checkpoints).stage == 26) {
			    if (((Mad) mad).cn == 13
				&& ((CheckPoints) checkpoints).pcleared == 8) {
				((Control) this).bulistc = true;
				((Control) this).attack = 0;
			    }
			    if (((Mad) mad).cn == 11
				&& (((CheckPoints) checkpoints).clear[0]
				    - ((Mad) mad).clear) >= 2
				&& ((Control) this).trfix == 0) {
				((Control) this).bulistc = true;
				((Control) this).oupnt = -1;
			    }
			}
			if ((((CheckPoints) checkpoints).stage == 6
			     || ((CheckPoints) checkpoints).stage == 8
			     || ((CheckPoints) checkpoints).stage == 12
			     || ((CheckPoints) checkpoints).stage == 13
			     || ((CheckPoints) checkpoints).stage == 14
			     || ((CheckPoints) checkpoints).stage == 15
			     || ((CheckPoints) checkpoints).stage == 18
			     || ((CheckPoints) checkpoints).stage == 20
			     || ((CheckPoints) checkpoints).stage == 23)
			    && ((Mad) mad).cn == 13
			    && Math.abs(((CheckPoints) checkpoints).clear[0]
					- ((Mad) mad).clear) >= 2)
			    ((Control) this).bulistc = true;
			if ((((CheckPoints) checkpoints).stage == 8
			     || ((CheckPoints) checkpoints).stage == 20)
			    && ((Mad) mad).cn == 11
			    && Math.abs(((CheckPoints) checkpoints).clear[0]
					- ((Mad) mad).clear) >= 1)
			    ((Control) this).bulistc = true;
			if (((CheckPoints) checkpoints).stage == 6
			    && ((Mad) mad).cn == 11)
			    ((Control) this).bulistc = true;
			if (((CheckPoints) checkpoints).stage == 9
			    && ((Control) this).afta
			    && ((((CheckPoints) checkpoints).pos
				 [((Mad) mad).im]) == 4
				|| (((CheckPoints) checkpoints).pos
				    [((Mad) mad).im]) == 3)
			    && ((Mad) mad).cn != 15
			    && ((Control) this).trfix != 0)
			    ((Control) this).bulistc = true;
		    } else if (((CheckPoints) checkpoints).stage == 18) {
			((Control) this).runbul--;
			if (((Mad) mad).pcleared == 10)
			    ((Control) this).runbul = 0;
			if (((Control) this).runbul <= 0)
			    ((Control) this).bulistc = false;
		    }
		    ((Control) this).stcnt = 0;
		    ((Control) this).statusque
			= (int) (20.0F * ((Control) this).m.random());
		} else
		    ((Control) this).stcnt++;
	    }
	    boolean bool = false;
	    if (((Control) this).usebounce)
		bool = ((Mad) mad).wtouch;
	    else
		bool = ((Mad) mad).mtouch;
	    if (bool) {
		if (((Control) this).trickfase != 0)
		    ((Control) this).trickfase = 0;
		if (((Control) this).trfix == 2 || ((Control) this).trfix == 3)
		    ((Control) this).attack = 0;
		if (((Control) this).attack == 0) {
		    if (((Control) this).upcnt < 30) {
			if (((Control) this).revstart <= 0)
			    ((Control) this).up = true;
			else {
			    ((Control) this).down = true;
			    ((Control) this).revstart--;
			}
		    }
		    if (((Control) this).upcnt < 25 + ((Control) this).actwait)
			((Control) this).upcnt++;
		    else {
			((Control) this).upcnt = 0;
			((Control) this).actwait = ((Control) this).upwait;
		    }
		    int i = ((Mad) mad).point;
		    int i_17_ = 50;
		    if (((CheckPoints) checkpoints).stage == 9)
			i_17_ = 20;
		    if (((CheckPoints) checkpoints).stage == 18)
			i_17_ = 20;
		    if (((CheckPoints) checkpoints).stage == 25)
			i_17_ = 40;
		    if (((CheckPoints) checkpoints).stage == 26)
			i_17_ = 20;
		    if (!((Control) this).bulistc
			|| ((Control) this).trfix == 2
			|| ((Control) this).trfix == 3
			|| ((Control) this).trfix == 4
			|| ((Mad) mad).power < (float) i_17_) {
			if (((Control) this).rampp == 1
			    && ((CheckPoints) checkpoints).typ[i] <= 0) {
			    int i_18_ = i + 1;
			    if (i_18_ >= ((CheckPoints) checkpoints).n)
				i_18_ = 0;
			    if (((CheckPoints) checkpoints).typ[i_18_] == -2)
				i = i_18_;
			}
			if (((Control) this).rampp == -1
			    && ((CheckPoints) checkpoints).typ[i] == -2
			    && ++i >= ((CheckPoints) checkpoints).n)
			    i = 0;
			if (((Control) this).m.random()
			    > ((Control) this).skiplev) {
			    int i_19_ = i;
			    boolean bool_20_ = false;
			    if (((CheckPoints) checkpoints).typ[i_19_] > 0) {
				int i_21_ = 0;
				for (int i_22_ = 0;
				     i_22_ < ((CheckPoints) checkpoints).n;
				     i_22_++) {
				    if ((((CheckPoints) checkpoints).typ[i_22_]
					 > 0)
					&& i_22_ < i_19_)
					i_21_++;
				}
				bool_20_ = (((Mad) mad).clear
					    != i_21_ + (((Mad) mad).nlaps
							* ((CheckPoints)
							   checkpoints).nsp));
			    }
			    while (((CheckPoints) checkpoints).typ[i_19_] == 0
				   || (((CheckPoints) checkpoints).typ[i_19_]
				       == -1)
				   || (((CheckPoints) checkpoints).typ[i_19_]
				       == -3)
				   || bool_20_) {
				i = i_19_;
				if (++i_19_ >= ((CheckPoints) checkpoints).n)
				    i_19_ = 0;
				bool_20_ = false;
				if (((CheckPoints) checkpoints).typ[i_19_]
				    > 0) {
				    int i_23_ = 0;
				    for (int i_24_ = 0;
					 i_24_ < ((CheckPoints) checkpoints).n;
					 i_24_++) {
					if ((((CheckPoints) checkpoints).typ
					     [i_24_]) > 0
					    && i_24_ < i_19_)
					    i_23_++;
				    }
				    bool_20_
					= (((Mad) mad).clear
					   != i_23_ + (((Mad) mad).nlaps
						       * ((CheckPoints)
							  checkpoints).nsp));
				}
			    }
			} else if (((Control) this).m.random()
				   > ((Control) this).skiplev) {
			    while (((CheckPoints) checkpoints).typ[i] == -1) {
				if (++i >= ((CheckPoints) checkpoints).n)
				    i = 0;
			    }
			}
			if (((CheckPoints) checkpoints).stage == 18
			    && ((Mad) mad).pcleared == 73
			    && ((Control) this).trfix == 0
			    && ((Mad) mad).clear != 0)
			    i = 10;
			if (((CheckPoints) checkpoints).stage == 19
			    && ((Mad) mad).pcleared == 18
			    && ((Control) this).trfix == 0)
			    i = 27;
			if (((CheckPoints) checkpoints).stage == 21) {
			    if (((Mad) mad).pcleared == 5
				&& ((Control) this).trfix == 0
				&& ((Mad) mad).power < 70.0F) {
				if (i <= 16)
				    i = 16;
				else
				    i = 21;
			    }
			    if (((Mad) mad).pcleared == 50)
				i = 57;
			}
			if (((CheckPoints) checkpoints).stage == 22
			    && (((Mad) mad).pcleared == 27
				|| ((Mad) mad).pcleared == 37)) {
			    while (((CheckPoints) checkpoints).typ[i] == -1) {
				if (++i >= ((CheckPoints) checkpoints).n)
				    i = 0;
			    }
			}
			if (((CheckPoints) checkpoints).stage == 23) {
			    while (((CheckPoints) checkpoints).typ[i] == -1) {
				if (++i >= ((CheckPoints) checkpoints).n)
				    i = 0;
			    }
			}
			if (((CheckPoints) checkpoints).stage == 24) {
			    while (((CheckPoints) checkpoints).typ[i] == -1) {
				if (++i >= ((CheckPoints) checkpoints).n)
				    i = 0;
			    }
			    if (!((Mad) mad).gtouch) {
				while (((CheckPoints) checkpoints).typ[i]
				       == -2) {
				    if (++i >= ((CheckPoints) checkpoints).n)
					i = 0;
				}
			    }
			    if (((Control) this).oupnt >= 68)
				i = 70;
			    else
				((Control) this).oupnt = i;
			}
			if (((CheckPoints) checkpoints).stage == 25) {
			    if ((((Mad) mad).pcleared != 91
				 && (((CheckPoints) checkpoints).pos[0]
				     < (((CheckPoints) checkpoints).pos
					[((Mad) mad).im]))
				 && ((Mad) mad).cn != 13)
				|| ((((CheckPoints) checkpoints).pos
				     [((Mad) mad).im]) == 0
				    && (((Mad) mad).clear == 12
					|| ((Mad) mad).clear == 20))) {
				while (((CheckPoints) checkpoints).typ[i]
				       == -4) {
				    if (++i >= ((CheckPoints) checkpoints).n)
					i = 0;
				}
			    }
			    if (((Mad) mad).pcleared == 9) {
				if (py(((ContO) conto).x / 100, 297,
				       ((ContO) conto).z / 100, 347)
				    < 400)
				    ((Control) this).oupnt = 1;
				if (((Control) this).oupnt == 1 && i < 22)
				    i = 22;
			    }
			    if (((Mad) mad).pcleared == 67) {
				if (py(((ContO) conto).x / 100, 28,
				       ((ContO) conto).z / 100, 494)
				    < 4000)
				    ((Control) this).oupnt = 2;
				if (((Control) this).oupnt == 2)
				    i = 76;
			    }
			    if (((Mad) mad).pcleared == 76) {
				if (py(((ContO) conto).x / 100, -50,
				       ((ContO) conto).z / 100, 0)
				    < 2000)
				    ((Control) this).oupnt = 3;
				if (((Control) this).oupnt == 3)
				    i = 91;
				else
				    i = 89;
			    }
			}
			if (((CheckPoints) checkpoints).stage == 26) {
			    if (((Mad) mad).pcleared == 128) {
				if (py(((ContO) conto).x / 100, 0,
				       ((ContO) conto).z / 100, 229) < 1500
				    || ((ContO) conto).z > 23000)
				    ((Control) this).oupnt = 128;
				if (((Control) this).oupnt != 128)
				    i = 3;
			    }
			    if (((Mad) mad).pcleared == 8) {
				if (py(((ContO) conto).x / 100, -207,
				       ((ContO) conto).z / 100, 549) < 1500
				    || ((ContO) conto).x < -20700)
				    ((Control) this).oupnt = 8;
				if (((Control) this).oupnt != 8)
				    i = 12;
			    }
			    if (((Mad) mad).pcleared == 33) {
				if (py(((ContO) conto).x / 100, -60,
				       ((ContO) conto).z / 100, 168) < 250
				    || ((ContO) conto).z > 17000)
				    ((Control) this).oupnt = 331;
				if (py(((ContO) conto).x / 100, -112,
				       ((ContO) conto).z / 100, 414) < 10000
				    || ((ContO) conto).z > 40000)
				    ((Control) this).oupnt = 332;
				if (((Control) this).oupnt != 331
				    && ((Control) this).oupnt != 332) {
				    if (((Control) this).trfix != 1)
					i = 38;
				    else
					i = 39;
				}
				if (((Control) this).oupnt == 331)
				    i = 71;
			    }
			    if (((Mad) mad).pcleared == 42) {
				if (py(((ContO) conto).x / 100, -269,
				       ((ContO) conto).z / 100, 493) < 100
				    || ((ContO) conto).x < -27000)
				    ((Control) this).oupnt = 142;
				if (((Control) this).oupnt != 142)
				    i = 47;
			    }
			    if (((Mad) mad).pcleared == 51) {
				if (py(((ContO) conto).x / 100, -352,
				       ((ContO) conto).z / 100, 260) < 100
				    || ((ContO) conto).z < 25000)
				    ((Control) this).oupnt = 511;
				if (py(((ContO) conto).x / 100, -325,
				       ((ContO) conto).z / 100, 10) < 2000
				    || ((ContO) conto).x > -32000)
				    ((Control) this).oupnt = 512;
				if (((Control) this).oupnt != 511
				    && ((Control) this).oupnt != 512)
				    i = 80;
				if (((Control) this).oupnt == 511)
				    i = 61;
			    }
			    if (((Mad) mad).pcleared == 77) {
				if (py(((ContO) conto).x / 100, -371,
				       ((ContO) conto).z / 100, 319) < 100
				    || ((ContO) conto).z < 31000)
				    ((Control) this).oupnt = 77;
				if (((Control) this).oupnt != 77) {
				    i = 78;
				    ((Mad) mad).nofocus = true;
				}
			    }
			    if (((Mad) mad).pcleared == 105) {
				if (py(((ContO) conto).x / 100, -179,
				       ((ContO) conto).z / 100, 10) < 2300
				    || ((ContO) conto).z < 1050)
				    ((Control) this).oupnt = 105;
				if (((Control) this).oupnt != 105)
				    i = 65;
				else
				    i = 125;
			    }
			    if (((Control) this).trfix == 3) {
				if (py(((ContO) conto).x / 100, -52,
				       ((ContO) conto).z / 100, 448) < 100
				    || ((ContO) conto).z > 45000)
				    ((Control) this).oupnt = 176;
				if (((Control) this).oupnt != 176)
				    i = 41;
				else
				    i = 43;
			    }
			    if (((((CheckPoints) checkpoints).clear
				  [((Mad) mad).im])
				 - ((CheckPoints) checkpoints).clear[0]) >= 2
				&& (py(((ContO) conto).x / 100,
				       (((CheckPoints) checkpoints).opx[0]
					/ 100),
				       ((ContO) conto).z / 100,
				       (((CheckPoints) checkpoints).opz[0]
					/ 100))
				    < 1000 + ((Control) this).avoidnlev)) {
				int i_25_ = ((ContO) conto).xz;
				if (((Control) this).zyinv)
				    i_25_ += 180;
				for (/**/; i_25_ < 0; i_25_ += 360) {
				    /* empty */
				}
				for (/**/; i_25_ > 180; i_25_ -= 360) {
				    /* empty */
				}
				int i_26_ = 0;
				if ((((CheckPoints) checkpoints).opx[0]
				     - ((ContO) conto).x)
				    >= 0)
				    i_26_ = 180;
				int i_27_;
				for (i_27_
					 = (int) ((double) (90 + i_26_)
						  + ((Math.atan
						      ((double) ((((CheckPoints)
								   checkpoints)
								  .opz[0])
								 - ((ContO)
								    conto).z)
						       / (double) ((((CheckPoints)
								     checkpoints)
								    .opx[0])
								   - (((ContO)
								       conto)
								      .x))))
						     / 0.017453292519943295));
				     i_27_ < 0; i_27_ += 360) {
				    /* empty */
				}
				for (/**/; i_27_ > 180; i_27_ -= 360) {
				    /* empty */
				}
				int i_28_ = Math.abs(i_25_ - i_27_);
				if (i_28_ > 180)
				    i_28_ = Math.abs(i_28_ - 360);
				if (i_28_ < 90)
				    ((Control) this).wall = 0;
			    }
			}
			if (((Control) this).rampp == 2) {
			    int i_29_ = i + 1;
			    if (i_29_ >= ((CheckPoints) checkpoints).n)
				i_29_ = 0;
			    if (((CheckPoints) checkpoints).typ[i_29_] == -2
				&& i != ((Mad) mad).point && --i < 0)
				i += ((CheckPoints) checkpoints).n;
			}
			if (((Control) this).bulistc) {
			    ((Mad) mad).nofocus = true;
			    if (((Control) this).gowait)
				((Control) this).gowait = false;
			}
		    } else {
			if ((((CheckPoints) checkpoints).stage != 25
			     && ((CheckPoints) checkpoints).stage != 26)
			    || ((Control) this).runbul == 0) {
			    i -= 2;
			    if (i < 0)
				i += ((CheckPoints) checkpoints).n;
			    if (((CheckPoints) checkpoints).stage == 9
				&& i > 76)
				i = 76;
			    while (((CheckPoints) checkpoints).typ[i] == -4) {
				if (--i < 0)
				    i += ((CheckPoints) checkpoints).n;
			    }
			}
			if (((CheckPoints) checkpoints).stage == 21) {
			    if (i >= 14 && i <= 19)
				i = 13;
			    if (((Control) this).oupnt == 72 && i != 56)
				i = 57;
			    else if (((Control) this).oupnt == 54 && i != 52)
				i = 53;
			    else if (((Control) this).oupnt == 39 && i != 37)
				i = 38;
			    else
				((Control) this).oupnt = i;
			}
			if (((CheckPoints) checkpoints).stage == 22) {
			    if (!((Control) this).gowait) {
				if (((CheckPoints) checkpoints).clear[0]
				    == 0) {
				    ((Control) this).wtx = -3500;
				    ((Control) this).wtz = 19000;
				    ((Control) this).frx = -3500;
				    ((Control) this).frz = 39000;
				    ((Control) this).frad = 12000;
				    ((Control) this).oupnt = 37;
				    ((Control) this).gowait = true;
				    ((Control) this).afta = false;
				}
				if (((CheckPoints) checkpoints).clear[0]
				    == 7) {
				    ((Control) this).wtx = -44800;
				    ((Control) this).wtz = 40320;
				    ((Control) this).frx = -44800;
				    ((Control) this).frz = 34720;
				    ((Control) this).frad = 30000;
				    ((Control) this).oupnt = 27;
				    ((Control) this).gowait = true;
				    ((Control) this).afta = false;
				}
				if (((CheckPoints) checkpoints).clear[0]
				    == 10) {
				    ((Control) this).wtx = 0;
				    ((Control) this).wtz = 48739;
				    ((Control) this).frx = 0;
				    ((Control) this).frz = 38589;
				    ((Control) this).frad = 90000;
				    ((Control) this).oupnt = 55;
				    ((Control) this).gowait = true;
				    ((Control) this).afta = false;
				}
				if (((CheckPoints) checkpoints).clear[0]
				    == 14) {
				    ((Control) this).wtx = -3500;
				    ((Control) this).wtz = 19000;
				    ((Control) this).frx = -14700;
				    ((Control) this).frz = 39000;
				    ((Control) this).frad = 45000;
				    ((Control) this).oupnt = 37;
				    ((Control) this).gowait = true;
				    ((Control) this).afta = false;
				}
				if (((CheckPoints) checkpoints).clear[0]
				    == 18) {
				    ((Control) this).wtx = -48300;
				    ((Control) this).wtz = -4550;
				    ((Control) this).frx = -48300;
				    ((Control) this).frz = 5600;
				    ((Control) this).frad = 90000;
				    ((Control) this).oupnt = 17;
				    ((Control) this).gowait = true;
				    ((Control) this).afta = false;
				}
			    }
			    if (((Control) this).gowait) {
				if (py(((ContO) conto).x / 100,
				       ((Control) this).wtx / 100,
				       ((ContO) conto).z / 100,
				       ((Control) this).wtz / 100) < 10000
				    && ((Mad) mad).speed > 50.0F)
				    ((Control) this).up = false;
				if (py(((ContO) conto).x / 100,
				       ((Control) this).wtx / 100,
				       ((ContO) conto).z / 100,
				       ((Control) this).wtz / 100)
				    < 200) {
				    ((Control) this).up = false;
				    ((Control) this).handb = true;
				}
				if ((((CheckPoints) checkpoints).pcleared
				     == ((Control) this).oupnt)
				    && (py((((CheckPoints) checkpoints).opx[0]
					    / 100),
					   ((Control) this).frx / 100,
					   (((CheckPoints) checkpoints).opz[0]
					    / 100),
					   ((Control) this).frz / 100)
					< ((Control) this).frad)) {
				    ((Control) this).afta = true;
				    ((Control) this).gowait = false;
				}
				if (py(((ContO) conto).x / 100,
				       (((CheckPoints) checkpoints).opx[0]
					/ 100),
				       ((ContO) conto).z / 100,
				       (((CheckPoints) checkpoints).opz[0]
					/ 100))
				    < 25) {
				    ((Control) this).afta = true;
				    ((Control) this).gowait = false;
				    ((Control) this).attack = 200;
				    ((Control) this).acr = 0;
				}
			    }
			}
			if (((CheckPoints) checkpoints).stage == 25) {
			    if (((Control) this).oupnt == -1) {
				int i_30_ = -10;
				for (int i_31_ = 0;
				     i_31_ < ((CheckPoints) checkpoints).n;
				     i_31_++) {
				    if (((((CheckPoints) checkpoints).typ
					  [i_31_]) == -2
					 || (((CheckPoints) checkpoints).typ
					     [i_31_]) == -4)
					&& (i_31_ < 50 || i_31_ > 54)
					&& (py(((ContO) conto).x / 100,
					       (((CheckPoints) checkpoints).x
						[i_31_]) / 100,
					       ((ContO) conto).z / 100,
					       (((CheckPoints) checkpoints).z
						[i_31_]) / 100) < i_30_
					    || i_30_ == -10)) {
					i_30_ = py(((ContO) conto).x / 100,
						   (((CheckPoints) checkpoints)
						    .x[i_31_]) / 100,
						   ((ContO) conto).z / 100,
						   (((CheckPoints) checkpoints)
						    .z[i_31_]) / 100);
					((Control) this).oupnt = i_31_;
				    }
				}
				((Control) this).oupnt--;
				if (i < 0)
				    ((Control) this).oupnt
					+= ((CheckPoints) checkpoints).n;
			    }
			    if (((Control) this).oupnt >= 0
				&& (((Control) this).oupnt
				    < ((CheckPoints) checkpoints).n)) {
				i = ((Control) this).oupnt;
				if (py(((ContO) conto).x / 100,
				       ((CheckPoints) checkpoints).x[i] / 100,
				       ((ContO) conto).z / 100,
				       ((CheckPoints) checkpoints).z[i] / 100)
				    < 800) {
				    ((Control) this).oupnt
					= -(int) (75.0F
						  + ((Control) this).m
							.random() * 200.0F);
				    ((Control) this).runbul
					= (int) (50.0F
						 + (((Control) this).m.random()
						    * 100.0F));
				}
			    }
			    if (((Control) this).oupnt < -1)
				((Control) this).oupnt++;
			    if (((Control) this).runbul != 0)
				((Control) this).runbul--;
			}
			if (((CheckPoints) checkpoints).stage == 26) {
			    boolean bool_32_ = false;
			    if (((Mad) mad).cn == 13) {
				if (!((Control) this).gowait) {
				    if (((CheckPoints) checkpoints).clear[0]
					== 1) {
					if ((double) ((Control) this).m
							 .random()
					    > 0.5) {
					    ((Control) this).wtx = -14000;
					    ((Control) this).wtz = 48000;
					    ((Control) this).frx = -5600;
					    ((Control) this).frz = 47600;
					    ((Control) this).frad = 88000;
					    ((Control) this).oupnt = 33;
					} else {
					    ((Control) this).wtx = -5600;
					    ((Control) this).wtz = 8000;
					    ((Control) this).frx = -7350;
					    ((Control) this).frz = -4550;
					    ((Control) this).frad = 22000;
					    ((Control) this).oupnt = 15;
					}
					((Control) this).gowait = true;
					((Control) this).afta = false;
				    }
				    if (((CheckPoints) checkpoints).clear[0]
					== 4) {
					((Control) this).wtx = -12700;
					((Control) this).wtz = 14000;
					((Control) this).frx = -31000;
					((Control) this).frz = 1050;
					((Control) this).frad = 11000;
					((Control) this).oupnt = 51;
					((Control) this).gowait = true;
					((Control) this).afta = false;
				    }
				    if (((CheckPoints) checkpoints).clear[0]
					== 14) {
					((Control) this).wtx = -35350;
					((Control) this).wtz = 6650;
					((Control) this).frx = -48300;
					((Control) this).frz = 54950;
					((Control) this).frad = 11000;
					((Control) this).oupnt = 15;
					((Control) this).gowait = true;
					((Control) this).afta = false;
				    }
				    if (((CheckPoints) checkpoints).clear[0]
					== 17) {
					((Control) this).wtx = -42700;
					((Control) this).wtz = 41000;
					((Control) this).frx = -40950;
					((Control) this).frz = 49350;
					((Control) this).frad = 7000;
					((Control) this).oupnt = 42;
					((Control) this).gowait = true;
					((Control) this).afta = false;
				    }
				    if (((CheckPoints) checkpoints).clear[0]
					== 21) {
					((Control) this).wtx = -1750;
					((Control) this).wtz = -15750;
					((Control) this).frx = -25900;
					((Control) this).frz = -14000;
					((Control) this).frad = 11000;
					((Control) this).oupnt = 125;
					((Control) this).gowait = true;
					((Control) this).afta = false;
				    }
				}
				if (((Control) this).gowait) {
				    if (py(((ContO) conto).x / 100,
					   ((Control) this).wtx / 100,
					   ((ContO) conto).z / 100,
					   ((Control) this).wtz / 100) < 10000
					&& ((Mad) mad).speed > 50.0F)
					((Control) this).up = false;
				    if (py(((ContO) conto).x / 100,
					   ((Control) this).wtx / 100,
					   ((ContO) conto).z / 100,
					   ((Control) this).wtz / 100)
					< 200) {
					((Control) this).up = false;
					((Control) this).handb = true;
				    }
				    if ((((CheckPoints) checkpoints).pcleared
					 == ((Control) this).oupnt)
					&& (py((((CheckPoints) checkpoints).opx
						[0]) / 100,
					       ((Control) this).frx / 100,
					       (((CheckPoints) checkpoints).opz
						[0]) / 100,
					       ((Control) this).frz / 100)
					    < ((Control) this).frad)) {
					((Control) this).runbul = 0;
					((Control) this).afta = true;
					((Control) this).gowait = false;
				    }
				    if (py(((ContO) conto).x / 100,
					   (((CheckPoints) checkpoints).opx[0]
					    / 100),
					   ((ContO) conto).z / 100,
					   (((CheckPoints) checkpoints).opz[0]
					    / 100))
					< 25) {
					((Control) this).afta = true;
					((Control) this).gowait = false;
					((Control) this).attack = 200;
					((Control) this).acr = 0;
				    }
				    if ((((CheckPoints) checkpoints).clear[0]
					 == 21)
					&& ((Control) this).oupnt != 125)
					((Control) this).gowait = false;
				}
				if ((((CheckPoints) checkpoints).clear[0] >= 11
				     && !((Control) this).gowait)
				    || (((Mad) mad).power < 60.0F
					&& (((CheckPoints) checkpoints).clear
					    [0]) < 21)) {
				    bool_32_ = true;
				    if (!((Control) this).exitattack) {
					((Control) this).oupnt = -1;
					((Control) this).exitattack = true;
				    }
				} else if (((Control) this).exitattack)
				    ((Control) this).exitattack = false;
			    }
			    if (((Mad) mad).cn == 11)
				bool_32_ = true;
			    if (bool_32_) {
				if (((Control) this).oupnt == -1) {
				    int i_33_ = -10;
				    for (int i_34_ = 0;
					 i_34_ < ((CheckPoints) checkpoints).n;
					 i_34_++) {
					if ((((CheckPoints) checkpoints).typ
					     [i_34_]) == -4
					    && ((py(((ContO) conto).x / 100,
						    (((CheckPoints)
						      checkpoints).x[i_34_]
						     / 100),
						    ((ContO) conto).z / 100,
						    (((CheckPoints)
						      checkpoints).z[i_34_]
						     / 100)) < i_33_
						 && ((double) ((Control) this)
								  .m.random()
						     > 0.6))
						|| i_33_ == -10)) {
					    i_33_ = py(((ContO) conto).x / 100,
						       (((CheckPoints)
							 checkpoints).x[i_34_]
							/ 100),
						       ((ContO) conto).z / 100,
						       (((CheckPoints)
							 checkpoints).z[i_34_]
							/ 100));
					    ((Control) this).oupnt = i_34_;
					}
				    }
				    ((Control) this).oupnt--;
				    if (i < 0)
					((Control) this).oupnt
					    += ((CheckPoints) checkpoints).n;
				}
				if (((Control) this).oupnt >= 0
				    && (((Control) this).oupnt
					< ((CheckPoints) checkpoints).n)) {
				    i = ((Control) this).oupnt;
				    if (py(((ContO) conto).x / 100,
					   (((CheckPoints) checkpoints).x[i]
					    / 100),
					   ((ContO) conto).z / 100,
					   (((CheckPoints) checkpoints).z[i]
					    / 100))
					< 800) {
					((Control) this).oupnt
					    = -(int) (75.0F + (((Control) this)
								   .m.random()
							       * 200.0F));
					((Control) this).runbul
					    = (int) (50.0F
						     + ((Control) this).m
							   .random() * 100.0F);
				    }
				}
				if (((Control) this).oupnt < -1)
				    ((Control) this).oupnt++;
				if (((Control) this).runbul != 0)
				    ((Control) this).runbul--;
			    }
			}
			((Mad) mad).nofocus = true;
		    }
		    if (((CheckPoints) checkpoints).stage != 27) {
			if (((CheckPoints) checkpoints).stage == 10
			    || ((CheckPoints) checkpoints).stage == 19
			    || (((CheckPoints) checkpoints).stage == 18
				&& ((Mad) mad).pcleared == 73)
			    || ((CheckPoints) checkpoints).stage == 26)
			    ((Control) this).forget = true;
			if ((((Mad) mad).missedcp == 0
			     || ((Control) this).forget
			     || ((Control) this).trfix == 4)
			    && ((Control) this).trfix != 0) {
			    int i_35_ = 0;
			    if (((CheckPoints) checkpoints).stage == 25
				|| ((CheckPoints) checkpoints).stage == 26)
				i_35_ = 3;
			    if (((Control) this).trfix == 2) {
				int i_36_ = -10;
				int i_37_ = 0;
				for (int i_38_ = i_35_;
				     i_38_ < ((CheckPoints) checkpoints).fn;
				     i_38_++) {
				    if (py(((ContO) conto).x / 100,
					   ((((CheckPoints) checkpoints).x
					     [((Control) this).fpnt[i_38_]])
					    / 100),
					   ((ContO) conto).z / 100,
					   ((((CheckPoints) checkpoints).z
					     [((Control) this).fpnt[i_38_]])
					    / 100)) < i_36_
					|| i_36_ == -10) {
					i_36_
					    = py(((ContO) conto).x / 100,
						 (((CheckPoints) checkpoints).x
						  [(((Control) this).fpnt
						    [i_38_])]) / 100,
						 ((ContO) conto).z / 100,
						 (((CheckPoints) checkpoints).z
						  [(((Control) this).fpnt
						    [i_38_])]) / 100);
					i_37_ = i_38_;
				    }
				}
				if (((CheckPoints) checkpoints).stage == 18
				    || ((CheckPoints) checkpoints).stage == 22)
				    i_37_ = 1;
				i = ((Control) this).fpnt[i_37_];
				if (((CheckPoints) checkpoints).special[i_37_])
				    ((Control) this).forget = true;
				else
				    ((Control) this).forget = false;
			    }
			    for (int i_39_ = i_35_;
				 i_39_ < ((CheckPoints) checkpoints).fn;
				 i_39_++) {
				if (py(((ContO) conto).x / 100,
				       (((CheckPoints) checkpoints).x
					[((Control) this).fpnt[i_39_]]) / 100,
				       ((ContO) conto).z / 100,
				       (((CheckPoints) checkpoints).z
					[((Control) this).fpnt[i_39_]]) / 100)
				    < 2000) {
				    ((Control) this).forget = false;
				    ((Control) this).actwait = 0;
				    ((Control) this).upwait = 0;
				    ((Control) this).turntyp = 2;
				    ((Control) this).randtcnt = -1;
				    ((Control) this).acuracy = 0;
				    ((Control) this).rampp = 0;
				    ((Control) this).trfix = 3;
				}
			    }
			    if (((Control) this).trfix == 3)
				((Mad) mad).nofocus = true;
			}
		    }
		    if (((Control) this).turncnt > ((Control) this).randtcnt) {
			if (!((Control) this).gowait) {
			    int i_40_ = 0;
			    if ((((CheckPoints) checkpoints).x[i]
				 - ((ContO) conto).x)
				>= 0)
				i_40_ = 180;
			    ((Control) this).pan
				= (int) ((double) (90 + i_40_)
					 + ((Math.atan
					     ((double) (((CheckPoints)
							 checkpoints).z[i]
							- ((ContO) conto).z)
					      / (double) (((CheckPoints)
							   checkpoints).x[i]
							  - (((ContO) conto)
							     .x))))
					    / 0.017453292519943295));
			} else {
			    int i_41_ = 0;
			    if (((Control) this).wtx - ((ContO) conto).x >= 0)
				i_41_ = 180;
			    ((Control) this).pan
				= (int) ((double) (90 + i_41_)
					 + ((Math.atan
					     ((double) (((Control) this).wtz
							- ((ContO) conto).z)
					      / (double) (((Control) this).wtx
							  - (((ContO) conto)
							     .x))))
					    / 0.017453292519943295));
			}
			((Control) this).turncnt = 0;
			((Control) this).randtcnt
			    = (int) ((float) ((Control) this).acuracy
				     * ((Control) this).m.random());
		    } else
			((Control) this).turncnt++;
		} else {
		    ((Control) this).up = true;
		    int i = 0;
		    int i_42_
			= (int) ((float) pys(((ContO) conto).x,
					     (((CheckPoints) checkpoints).opx
					      [((Control) this).acr]),
					     ((ContO) conto).z,
					     (((CheckPoints) checkpoints).opz
					      [((Control) this).acr]))
				 / 2.0F * ((Control) this).aim);
		    int i_43_
			= (int) ((float) (((CheckPoints) checkpoints).opx
					  [((Control) this).acr])
				 - ((float) i_42_
				    * ((Control) this).m.sin(((CheckPoints)
							      checkpoints)
							     .omxz
							     [(((Control) this)
							       .acr)])));
		    int i_44_
			= (int) ((float) (((CheckPoints) checkpoints).opz
					  [((Control) this).acr])
				 + ((float) i_42_
				    * ((Control) this).m.cos(((CheckPoints)
							      checkpoints)
							     .omxz
							     [(((Control) this)
							       .acr)])));
		    if (i_43_ - ((ContO) conto).x >= 0)
			i = 180;
		    ((Control) this).pan
			= (int) ((double) (90 + i)
				 + (Math.atan((double) (i_44_
							- ((ContO) conto).z)
					      / (double) (i_43_
							  - ((ContO) conto).x))
				    / 0.017453292519943295));
		    ((Control) this).attack--;
		    if (((Control) this).attack <= 0)
			((Control) this).attack = 0;
		    if (((CheckPoints) checkpoints).stage == 25
			&& ((Control) this).exitattack
			&& !((Control) this).bulistc
			&& ((Mad) mad).missedcp != 0)
			((Control) this).attack = 0;
		    if (((CheckPoints) checkpoints).stage == 26
			&& ((Mad) mad).cn == 13
			&& (((CheckPoints) checkpoints).clear[0] == 4
			    || ((CheckPoints) checkpoints).clear[0] == 13
			    || ((CheckPoints) checkpoints).clear[0] == 21))
			((Control) this).attack = 0;
		    if (((CheckPoints) checkpoints).stage == 26
			&& ((Mad) mad).missedcp != 0
			&& ((((CheckPoints) checkpoints).pos[((Mad) mad).im]
			     == 0)
			    || ((((CheckPoints) checkpoints).pos
				 [((Mad) mad).im]) == 1
				&& ((CheckPoints) checkpoints).pos[0] == 0)))
			((Control) this).attack = 0;
		    if (((CheckPoints) checkpoints).stage == 26
			&& (((CheckPoints) checkpoints).pos[0]
			    > ((CheckPoints) checkpoints).pos[((Mad) mad).im])
			&& ((Mad) mad).power < 80.0F)
			((Control) this).attack = 0;
		}
		int i = ((ContO) conto).xz;
		if (((Control) this).zyinv)
		    i += 180;
		for (/**/; i < 0; i += 360) {
		    /* empty */
		}
		for (/**/; i > 180; i -= 360) {
		    /* empty */
		}
		for (/**/; ((Control) this).pan < 0;
		     ((Control) this).pan += 360) {
		    /* empty */
		}
		for (/**/; ((Control) this).pan > 180;
		     ((Control) this).pan -= 360) {
		    /* empty */
		}
		if (((Control) this).wall != -1 && ((Control) this).hold == 0)
		    ((Control) this).clrnce = 0;
		if (((Control) this).hold == 0) {
		    if (Math.abs(i - ((Control) this).pan) < 180) {
			if (Math.abs(i - ((Control) this).pan)
			    > ((Control) this).clrnce) {
			    if (i < ((Control) this).pan) {
				((Control) this).left = true;
				((Control) this).lastl = true;
			    } else {
				((Control) this).right = true;
				((Control) this).lastl = false;
			    }
			    if (Math.abs(i - ((Control) this).pan) > 50
				&& (((Mad) mad).speed
				    > (float) (((CarDefine) ((Mad) mad).cd)
					       .swits[((Mad) mad).cn][0]))
				&& ((Control) this).turntyp != 0) {
				if (((Control) this).turntyp == 1)
				    ((Control) this).down = true;
				if (((Control) this).turntyp == 2)
				    ((Control) this).handb = true;
				if (!((Control) this).agressed)
				    ((Control) this).up = false;
			    }
			}
		    } else if (Math.abs(i - ((Control) this).pan)
			       < 360 - ((Control) this).clrnce) {
			if (i < ((Control) this).pan) {
			    ((Control) this).right = true;
			    ((Control) this).lastl = false;
			} else {
			    ((Control) this).left = true;
			    ((Control) this).lastl = true;
			}
			if (Math.abs(i - ((Control) this).pan) < 310
			    && (((Mad) mad).speed
				> (float) (((CarDefine) ((Mad) mad).cd).swits
					   [((Mad) mad).cn][0]))
			    && ((Control) this).turntyp != 0) {
			    if (((Control) this).turntyp == 1)
				((Control) this).down = true;
			    if (((Control) this).turntyp == 2)
				((Control) this).handb = true;
			    if (!((Control) this).agressed)
				((Control) this).up = false;
			}
		    }
		}
		if (((CheckPoints) checkpoints).stage == 24
		    && ((Control) this).wall != -1) {
		    if (((Trackers) trackers).dam[((Control) this).wall] == 0
			|| ((Mad) mad).pcleared == 45)
			((Control) this).wall = -1;
		    if (((Mad) mad).pcleared == 58
			&& (((CheckPoints) checkpoints).opz[((Mad) mad).im]
			    < 36700)) {
			((Control) this).wall = -1;
			((Control) this).hold = 0;
		    }
		}
		if (((Control) this).wall != -1) {
		    if (((Control) this).lwall != ((Control) this).wall) {
			if (((Control) this).lastl)
			    ((Control) this).left = true;
			else
			    ((Control) this).right = true;
			((Control) this).wlastl = ((Control) this).lastl;
			((Control) this).lwall = ((Control) this).wall;
		    } else if (((Control) this).wlastl)
			((Control) this).left = true;
		    else
			((Control) this).right = true;
		    if (((Trackers) trackers).dam[((Control) this).wall]
			!= 0) {
			int i_45_ = 1;
			if (((Trackers) trackers).skd[((Control) this).wall]
			    == 1)
			    i_45_ = 3;
			((Control) this).hold += i_45_;
			if (((Control) this).hold > 10 * i_45_)
			    ((Control) this).hold = 10 * i_45_;
		    } else
			((Control) this).hold = 1;
		    ((Control) this).wall = -1;
		} else if (((Control) this).hold != 0)
		    ((Control) this).hold--;
	    } else {
		if (((Control) this).trickfase == 0) {
		    int i = (int) ((((Mad) mad).scy[0] + ((Mad) mad).scy[1]
				    + ((Mad) mad).scy[2] + ((Mad) mad).scy[3])
				   * (float) (((ContO) conto).y - 300)
				   / 4000.0F);
		    int i_46_ = 3;
		    if (((CheckPoints) checkpoints).stage == 25)
			i_46_ = 10;
		    if (i > 7
			&& ((((Control) this).m.random()
			     > ((Control) this).trickprf / (float) i_46_)
			    || ((Control) this).stuntf == 4
			    || ((Control) this).stuntf == 3
			    || ((Control) this).stuntf == 5
			    || ((Control) this).stuntf == 6
			    || ((CheckPoints) checkpoints).stage == 26)) {
			((Control) this).oxy = ((Mad) mad).pxy;
			((Control) this).ozy = ((Mad) mad).pzy;
			((Control) this).flycnt = 0;
			((Control) this).uddirect = 0;
			((Control) this).lrdirect = 0;
			((Control) this).udswt = false;
			((Control) this).lrswt = false;
			((Control) this).trickfase = 1;
			if (i < 16) {
			    if (((Control) this).stuntf != 6) {
				((Control) this).uddirect = -1;
				((Control) this).udstart = 0;
				((Control) this).udswt = false;
			    } else if (((Control) this).oupnt != 70) {
				((Control) this).uddirect = 1;
				((Control) this).udstart = 0;
				((Control) this).udswt = false;
			    }
			} else if (((((Control) this).m.random()
				     > ((Control) this).m.random())
				    && ((Control) this).stuntf != 1)
				   || ((Control) this).stuntf == 4
				   || ((Control) this).stuntf == 6
				   || ((Control) this).stuntf == 7
				   || ((Control) this).stuntf == 17) {
			    if (((((Control) this).m.random()
				  > ((Control) this).m.random())
				 || ((Control) this).stuntf == 2
				 || ((Control) this).stuntf == 7)
				&& ((Control) this).stuntf != 4
				&& ((Control) this).stuntf != 6)
				((Control) this).uddirect = -1;
			    else
				((Control) this).uddirect = 1;
			    ((Control) this).udstart
				= (int) (10.0F * ((Control) this).m.random()
					 * ((Control) this).trickprf);
			    if (((Control) this).stuntf == 6)
				((Control) this).udstart = 0;
			    if (((CheckPoints) checkpoints).stage == 26)
				((Control) this).udstart = 0;
			    if (((CheckPoints) checkpoints).stage == 24
				&& (((Control) this).oupnt == 68
				    || ((Control) this).oupnt == 69)) {
				((Control) this).apunch = 20;
				((Control) this).oupnt = 70;
			    }
			    if ((double) ((Control) this).m.random() > 0.85
				&& ((Control) this).stuntf != 4
				&& ((Control) this).stuntf != 3
				&& ((Control) this).stuntf != 6
				&& ((Control) this).stuntf != 17
				&& ((CheckPoints) checkpoints).stage != 26)
				((Control) this).udswt = true;
			    if ((((Control) this).m.random()
				 > ((Control) this).trickprf + 0.3F)
				&& ((Control) this).stuntf != 4
				&& ((Control) this).stuntf != 6) {
				if (((Control) this).m.random()
				    > ((Control) this).m.random())
				    ((Control) this).lrdirect = -1;
				else
				    ((Control) this).lrdirect = 1;
				((Control) this).lrstart
				    = (int) (30.0F
					     * ((Control) this).m.random());
				if ((double) ((Control) this).m.random()
				    > 0.75)
				    ((Control) this).lrswt = true;
			    }
			} else {
			    if (((Control) this).m.random()
				> ((Control) this).m.random())
				((Control) this).lrdirect = -1;
			    else
				((Control) this).lrdirect = 1;
			    ((Control) this).lrstart
				= (int) (10.0F * ((Control) this).m.random()
					 * ((Control) this).trickprf);
			    if ((double) ((Control) this).m.random() > 0.75
				&& ((CheckPoints) checkpoints).stage != 26)
				((Control) this).lrswt = true;
			    if (((Control) this).m.random()
				> ((Control) this).trickprf + 0.3F) {
				if (((Control) this).m.random()
				    > ((Control) this).m.random())
				    ((Control) this).uddirect = -1;
				else
				    ((Control) this).uddirect = 1;
				((Control) this).udstart
				    = (int) (30.0F
					     * ((Control) this).m.random());
				if ((double) ((Control) this).m.random()
				    > 0.85)
				    ((Control) this).udswt = true;
			    }
			}
			if (((Control) this).trfix == 3
			    || ((Control) this).trfix == 4) {
			    if (((CheckPoints) checkpoints).stage != 18
				&& ((CheckPoints) checkpoints).stage != 8) {
				if (((CheckPoints) checkpoints).stage != 25
				    && ((Control) this).lrdirect == -1) {
				    if (((CheckPoints) checkpoints).stage
					!= 19)
					((Control) this).uddirect = -1;
				    else
					((Control) this).uddirect = 1;
				}
				((Control) this).lrdirect = 0;
				if ((((CheckPoints) checkpoints).stage == 19
				     || (((CheckPoints) checkpoints).stage
					 == 25))
				    && ((Control) this).uddirect == -1)
				    ((Control) this).uddirect = 1;
				if (((Mad) mad).power < 60.0F)
				    ((Control) this).uddirect = -1;
			    } else {
				if (((Control) this).uddirect != 0)
				    ((Control) this).uddirect = -1;
				((Control) this).lrdirect = 0;
			    }
			    if (((CheckPoints) checkpoints).stage == 20) {
				((Control) this).uddirect = 1;
				((Control) this).lrdirect = 0;
			    }
			    if (((CheckPoints) checkpoints).stage == 26) {
				((Control) this).uddirect = -1;
				((Control) this).lrdirect = 0;
				if (((Mad) mad).cn != 11
				    && ((Mad) mad).cn != 13) {
				    ((Control) this).udstart = 7;
				    if (((Mad) mad).cn == 14
					&& ((Mad) mad).power > 30.0F)
					((Control) this).udstart = 14;
				} else
				    ((Control) this).udstart = 0;
				if (((Mad) mad).cn == 11) {
				    ((Control) this).lrdirect = -1;
				    ((Control) this).lrstart = 0;
				}
			    }
			}
		    } else
			((Control) this).trickfase = -1;
		    if (!((Control) this).afta)
			((Control) this).afta = true;
		    if (((Control) this).trfix == 3) {
			((Control) this).trfix = 4;
			((Control) this).statusque += 30;
		    }
		}
		if (((Control) this).trickfase == 1) {
		    ((Control) this).flycnt++;
		    if (((Control) this).lrdirect != 0
			&& (((Control) this).flycnt
			    > ((Control) this).lrstart)) {
			if (((Control) this).lrswt
			    && Math.abs(((Mad) mad).pxy
					- ((Control) this).oxy) > 180) {
			    if (((Control) this).lrdirect == -1)
				((Control) this).lrdirect = 1;
			    else
				((Control) this).lrdirect = -1;
			    ((Control) this).lrswt = false;
			}
			if (((Control) this).lrdirect == -1) {
			    ((Control) this).handb = true;
			    ((Control) this).left = true;
			} else {
			    ((Control) this).handb = true;
			    ((Control) this).right = true;
			}
		    }
		    if (((Control) this).uddirect != 0
			&& (((Control) this).flycnt
			    > ((Control) this).udstart)) {
			if (((Control) this).udswt
			    && Math.abs(((Mad) mad).pzy
					- ((Control) this).ozy) > 180) {
			    if (((Control) this).uddirect == -1)
				((Control) this).uddirect = 1;
			    else
				((Control) this).uddirect = -1;
			    ((Control) this).udswt = false;
			}
			if (((Control) this).uddirect == -1) {
			    ((Control) this).handb = true;
			    ((Control) this).down = true;
			} else {
			    ((Control) this).handb = true;
			    ((Control) this).up = true;
			    if (((Control) this).apunch > 0) {
				((Control) this).down = true;
				((Control) this).apunch--;
			    }
			}
		    }
		    if (((((Mad) mad).scy[0] + ((Mad) mad).scy[1]
			  + ((Mad) mad).scy[2] + ((Mad) mad).scy[3])
			 * 100.0F / (float) (((ContO) conto).y - 300))
			< (float) -((Control) this).saftey) {
			((Control) this).onceu = false;
			((Control) this).onced = false;
			((Control) this).oncel = false;
			((Control) this).oncer = false;
			((Control) this).lrcomp = false;
			((Control) this).udcomp = false;
			((Control) this).udbare = false;
			((Control) this).lrbare = false;
			((Control) this).trickfase = 2;
			((Control) this).swat = 0;
		    }
		}
		if (((Control) this).trickfase == 2) {
		    if (((Control) this).swat == 0) {
			if (((Mad) mad).dcomp != 0.0F
			    || ((Mad) mad).ucomp != 0.0F)
			    ((Control) this).udbare = true;
			if (((Mad) mad).lcomp != 0.0F
			    || ((Mad) mad).rcomp != 0.0F)
			    ((Control) this).lrbare = true;
			((Control) this).swat = 1;
		    }
		    if (((Mad) mad).wtouch) {
			if (((Control) this).swat == 1)
			    ((Control) this).swat = 2;
		    } else if (((Control) this).swat == 2) {
			if (((Mad) mad).capsized
			    && (((Control) this).m.random()
				> ((Control) this).mustland)) {
			    if (((Control) this).udbare) {
				((Control) this).lrbare = true;
				((Control) this).udbare = false;
			    } else if (((Control) this).lrbare) {
				((Control) this).udbare = true;
				((Control) this).lrbare = false;
			    }
			}
			((Control) this).swat = 3;
		    }
		    if (((Control) this).udbare) {
			int i;
			for (i = ((Mad) mad).pzy + 90; i < 0; i += 360) {
			    /* empty */
			}
			for (/**/; i > 180; i -= 360) {
			    /* empty */
			}
			i = Math.abs(i);
			if (((Mad) mad).lcomp - ((Mad) mad).rcomp < 5.0F
			    && (((Control) this).onced
				|| ((Control) this).onceu))
			    ((Control) this).udcomp = true;
			if (((Mad) mad).dcomp > ((Mad) mad).ucomp) {
			    if (((Mad) mad).capsized) {
				if (((Control) this).udcomp) {
				    if (i > 90)
					((Control) this).up = true;
				    else
					((Control) this).down = true;
				} else if (!((Control) this).onced)
				    ((Control) this).down = true;
			    } else {
				if (((Control) this).udcomp) {
				    if (((Control) this).perfection
					&& Math.abs(i - 90) > 30) {
					if (i > 90)
					    ((Control) this).up = true;
					else
					    ((Control) this).down = true;
				    }
				} else if (((Control) this).m.random()
					   > ((Control) this).mustland)
				    ((Control) this).up = true;
				((Control) this).onced = true;
			    }
			} else if (((Mad) mad).capsized) {
			    if (((Control) this).udcomp) {
				if (i > 90)
				    ((Control) this).up = true;
				else
				    ((Control) this).down = true;
			    } else if (!((Control) this).onceu)
				((Control) this).up = true;
			} else {
			    if (((Control) this).udcomp) {
				if (((Control) this).perfection
				    && Math.abs(i - 90) > 30) {
				    if (i > 90)
					((Control) this).up = true;
				    else
					((Control) this).down = true;
				}
			    } else if (((Control) this).m.random()
				       > ((Control) this).mustland)
				((Control) this).down = true;
			    ((Control) this).onceu = true;
			}
		    }
		    if (((Control) this).lrbare) {
			int i = ((Mad) mad).pxy + 90;
			if (((Control) this).zyinv)
			    i += 180;
			for (/**/; i < 0; i += 360) {
			    /* empty */
			}
			for (/**/; i > 180; i -= 360) {
			    /* empty */
			}
			i = Math.abs(i);
			if (((Mad) mad).lcomp - ((Mad) mad).rcomp < 10.0F
			    && (((Control) this).oncel
				|| ((Control) this).oncer))
			    ((Control) this).lrcomp = true;
			if (((Mad) mad).lcomp > ((Mad) mad).rcomp) {
			    if (((Mad) mad).capsized) {
				if (((Control) this).lrcomp) {
				    if (i > 90)
					((Control) this).left = true;
				    else
					((Control) this).right = true;
				} else if (!((Control) this).oncel)
				    ((Control) this).left = true;
			    } else {
				if (((Control) this).lrcomp) {
				    if (((Control) this).perfection
					&& Math.abs(i - 90) > 30) {
					if (i > 90)
					    ((Control) this).left = true;
					else
					    ((Control) this).right = true;
				    }
				} else if (((Control) this).m.random()
					   > ((Control) this).mustland)
				    ((Control) this).right = true;
				((Control) this).oncel = true;
			    }
			} else if (((Mad) mad).capsized) {
			    if (((Control) this).lrcomp) {
				if (i > 90)
				    ((Control) this).left = true;
				else
				    ((Control) this).right = true;
			    } else if (!((Control) this).oncer)
				((Control) this).right = true;
			} else {
			    if (((Control) this).lrcomp) {
				if (((Control) this).perfection
				    && Math.abs(i - 90) > 30) {
				    if (i > 90)
					((Control) this).left = true;
				    else
					((Control) this).right = true;
				}
			    } else if (((Control) this).m.random()
				       > ((Control) this).mustland)
				((Control) this).left = true;
			    ((Control) this).oncer = true;
			}
		    }
		}
	    }
	}
    }
    
    public int py(int i, int i_47_, int i_48_, int i_49_) {
	return (i - i_47_) * (i - i_47_) + (i_48_ - i_49_) * (i_48_ - i_49_);
    }
    
    public int pys(int i, int i_50_, int i_51_, int i_52_) {
	return (int) Math.sqrt((double) ((i - i_50_) * (i - i_50_)
					 + (i_51_ - i_52_) * (i_51_ - i_52_)));
    }
}
