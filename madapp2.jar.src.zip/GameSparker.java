/* GameSparker - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.applet.Applet;
import java.awt.AlphaComposite;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Event;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.TextArea;
import java.awt.TextField;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URI;
import java.net.URL;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class GameSparker extends Applet implements Runnable {
	Settings settings = new Settings();
	Graphics2D rd;
	Image offImage;
	Thread gamer;
	int mload = 1;
	boolean exwist = false;
	int apx = 0;
	int apy = 0;
	float apmult = 1.0F;
	float reqmult = 0.0F;
	int smooth = 1;
	int moto = 1;
	int lastw = 0;
	int lasth = 0;
	boolean onbar = false;
	boolean oncarm = false;
	boolean onstgm = false;
	boolean onfulls = false;
	Image sizebar;
	Image blb;
	Image fulls;
	Image[] chkbx = new Image[2];
	Image[] carmaker = new Image[2];
	Image[] stagemaker = new Image[2];
	int showsize = 0;
	Control[] u = new Control[8];
	int mouses = 0;
	int xm = 0;
	int ym = 0;
	int mousew = 0;
	boolean lostfcs = false;
	boolean moused = false;
	int fcscnt = 0;
	int nob = 0;
	int notb = 0;
	int view = 0;
	int mvect = 100;
	int lmxz = 0;
	int shaka = 0;
	boolean applejava = false;
	TextField tnick;
	TextField tpass;
	TextField temail;
	TextField cmsg;
	TextArea mmsg;
	Checkbox mycar;
	Checkbox notp;
	Checkbox keplo;
	boolean openm = false;
	Smenu sgame = new Smenu(8);
	Smenu wgame = new Smenu(4);
	Smenu warb = new Smenu(102);
	Smenu pgame = new Smenu(11);
	Smenu vnpls = new Smenu(5);
	Smenu vtyp = new Smenu(6);
	Smenu snfmm = new Smenu(12);
	Smenu snfm1 = new Smenu(12);
	Smenu snfm2 = new Smenu(19);
	Smenu mstgs = new Smenu(707);
	Smenu mcars = new Smenu(707);
	Smenu slaps = new Smenu(17);
	Smenu snpls = new Smenu(9);
	Smenu snbts = new Smenu(8);
	Smenu swait = new Smenu(6);
	Smenu sclass = new Smenu(7);
	Smenu scars = new Smenu(4);
	Smenu sfix = new Smenu(7);
	Smenu gmode = new Smenu(3);
	Smenu rooms = new Smenu(7);
	Smenu sendtyp = new Smenu(6);
	Smenu senditem = new Smenu(707);
	Smenu clanlev = new Smenu(8);
	Smenu clcars = new Smenu(707);
	Smenu datat = new Smenu(26);
	Smenu ilaps = new Smenu(18);
	Smenu icars = new Smenu(5);
	Smenu proitem = new Smenu(707);

	public void run() {
		((GameSparker) this).rd.setColor(new Color(0, 0, 0));
		((GameSparker) this).rd.fillRect(0, 0, 800, 450);
		repaint();
		requestFocus();
		if (System.getProperty("java.vendor").toLowerCase().indexOf("apple") != -1)
		((GameSparker) this).applejava = true;
		Medium medium = new Medium();
		Trackers trackers = new Trackers();
		CheckPoints checkpoints = new CheckPoints();
		ContO[] contos = new ContO[124];
		CarDefine cardefine = new CarDefine(contos, medium, trackers, this);
		xtGraphics var_xtGraphics = new xtGraphics(medium, cardefine, ((GameSparker) this).rd, this);
		settings.initclasses(this, var_xtGraphics, cardefine, contos, checkpoints, trackers, medium);
		((GameSparker) this).sizebar = var_xtGraphics.getImage("data/sizebar.gif");
		((GameSparker) this).blb = var_xtGraphics.getImage("data/b.gif");
		((GameSparker) this).fulls = var_xtGraphics.getImage("data/fullscreen.gif");
		((GameSparker) this).chkbx[0] = var_xtGraphics.getImage("data/checkbox1.gif");
		((GameSparker) this).chkbx[1] = var_xtGraphics.getImage("data/checkbox2.gif");
		((GameSparker) this).carmaker[0] = var_xtGraphics.getImage("data/carmaker1.gif");
		((GameSparker) this).carmaker[1] = var_xtGraphics.getImage("data/carmaker2.gif");
		((GameSparker) this).stagemaker[0] = var_xtGraphics.getImage("data/stagemaker1.gif");
		((GameSparker) this).stagemaker[1] = var_xtGraphics.getImage("data/stagemaker2.gif");
		var_xtGraphics.loaddata();
		Login login = null;
		Lobby lobby = null;
		Globe globe = null;
		boolean bool = false;
		UDPMistro udpmistro = new UDPMistro();
		Record record = new Record(medium);
		loadbase(contos, medium, trackers, var_xtGraphics, false);
		ContO[] contos_0_ = new ContO[10000];
		Mad[] mads = new Mad[8];
		settings.initmads(mads);
		for (int i = 0; i < 8; i++) {
			mads[i] = new Mad(cardefine, medium, record, var_xtGraphics, i);
			((GameSparker) this).u[i] = new Control(medium);
		}
		float f = 47.0F;
		readcookies(var_xtGraphics, cardefine, contos);
		((xtGraphics) var_xtGraphics).testdrive = Madness.testdrive;
		if (((xtGraphics) var_xtGraphics).testdrive != 0) {
			if (((xtGraphics) var_xtGraphics).testdrive <= 2) {
				((xtGraphics) var_xtGraphics).sc[0] = cardefine.loadcar(Madness.testcar, 16);
				if (((xtGraphics) var_xtGraphics).sc[0] != -1)
				((xtGraphics) var_xtGraphics).fase = -9;
				else {
					Madness.testcar = "Failx12";
					Madness.carmaker();
				}
			} else {
				((CheckPoints) checkpoints).name = Madness.testcar;
				((xtGraphics) var_xtGraphics).fase = -9;
			}
		}
		var_xtGraphics.stoploading();
		requestFocus();
		if (((xtGraphics) var_xtGraphics).testdrive == 0 && ((xtGraphics) var_xtGraphics).firstime) setupini();
		System.gc();
		Date date = new Date();
		long l = 0L;
		long l_1_ = date.getTime();
		float f_2_ = 30.0F;
		boolean bool_3_ = false;
		int i = 30;
		int i_4_ = 530;
		int i_5_ = 0;
		int i_6_ = 0;
		int i_7_ = 0;
		int i_8_ = 0;
		int i_9_ = 0;
		boolean bool_10_ = false;
		for (;;) {
			date = new Date();
			long l_11_ = date.getTime();
			if (((xtGraphics) var_xtGraphics).fase == 111) {
				if (((GameSparker) this).mouses == 1) i_7_ = 800;
				if (i_7_ < 800) {
					var_xtGraphics.clicknow();
					i_7_++;
				} else {
					i_7_ = 0;
					if (!((GameSparker) this).exwist)
					((xtGraphics) var_xtGraphics).fase = 9;
					((GameSparker) this).mouses = 0;
					((GameSparker) this).lostfcs = false;
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 9) {
				if (i_7_ < 76) {
					var_xtGraphics.rad(i_7_);
					catchlink();
					if (((GameSparker) this).mouses == 2)
					((GameSparker) this).mouses = 0;
					if (((GameSparker) this).mouses == 1)
					((GameSparker) this).mouses = 2;
					i_7_++;
				} else {
					i_7_ = 0;
					((xtGraphics) var_xtGraphics).fase = 10;
					((GameSparker) this).mouses = 0;
					((GameSparker) this).u[0].falseo(0);
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == -9) {
				if (((xtGraphics) var_xtGraphics).loadedt) {
					var_xtGraphics.mainbg(-101);
					((GameSparker) this).rd.setColor(new Color(0, 0, 0));
					((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					repaint();
					((xtGraphics) var_xtGraphics).strack.unload();
					((xtGraphics) var_xtGraphics).strack = null;
					((xtGraphics) var_xtGraphics).flexpix = null;
					((xtGraphics) var_xtGraphics).fleximg = null;
					System.gc();
					((xtGraphics) var_xtGraphics).loadedt = false;
				}
				if (i_7_ < 2) {
					var_xtGraphics.mainbg(-101);
					((GameSparker) this).rd.setColor(new Color(0, 0, 0));
					((GameSparker) this).rd.fillRect(65, 25, 670, 400);
					i_7_++;
				} else {
					checkmemory(var_xtGraphics);
					var_xtGraphics.inishcarselect(contos);
					i_7_ = 0;
					((xtGraphics) var_xtGraphics).fase = 7;
					((GameSparker) this).mvect = 50;
					((GameSparker) this).mouses = 0;
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 8) {
				var_xtGraphics.credits(((GameSparker) this).u[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((xtGraphics) var_xtGraphics).flipo <= 100) catchlink();
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == 10) {
				((GameSparker) this).mvect = 100;
				var_xtGraphics.maini(((GameSparker) this).u[0]);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == 102) {
				((GameSparker) this).mvect = 100;
				if (((xtGraphics) var_xtGraphics).loadedt) {
					((GameSparker) this).rd.setColor(new Color(0, 0, 0));
					((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					repaint();
					checkmemory(var_xtGraphics);
					((xtGraphics) var_xtGraphics).strack.unload();
					((xtGraphics) var_xtGraphics).strack = null;
					((xtGraphics) var_xtGraphics).flexpix = null;
					((xtGraphics) var_xtGraphics).fleximg = null;
					System.gc();
					((xtGraphics) var_xtGraphics).loadedt = false;
				}
				if (((xtGraphics) var_xtGraphics).testdrive == 1 || ((xtGraphics) var_xtGraphics).testdrive == 2) Madness.carmaker();
				if (((xtGraphics) var_xtGraphics).testdrive == 3 || ((xtGraphics) var_xtGraphics).testdrive == 4) Madness.stagemaker();
				var_xtGraphics.maini2(((GameSparker) this).u[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == -22) {
				((CheckPoints) checkpoints).name = Madness.testcar;
				((CheckPoints) checkpoints).stage = -1;
				loadstage(contos_0_, contos, medium, trackers, checkpoints,
				var_xtGraphics, mads, record);
				if (((CheckPoints) checkpoints).stage == -3) {
					Madness.testcar = "Failx12";
					Madness.stagemaker();
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 11) {
				var_xtGraphics.inst(((GameSparker) this).u[0]);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == -5) {
				((GameSparker) this).mvect = 100;
				var_xtGraphics.finish(checkpoints, contos, ((GameSparker) this).u[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == 7) {
				var_xtGraphics.carselect(((GameSparker) this).u[0], contos,
				mads[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
				drawms();
			}
			if (((xtGraphics) var_xtGraphics).fase == 6) {
				var_xtGraphics.musicomp(((CheckPoints) checkpoints).stage, ((GameSparker) this).u[0]);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == 5) {
				((GameSparker) this).mvect = 100;
				var_xtGraphics.loadmusic(((CheckPoints) checkpoints).stage, ((CheckPoints) checkpoints).trackname, ((CheckPoints) checkpoints).trackvol);
			}
			if (((xtGraphics) var_xtGraphics).fase == 4) {
				var_xtGraphics.cantgo(((GameSparker) this).u[0]);
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == 3) {
				((GameSparker) this).rd.setColor(new Color(0, 0, 0));
				((GameSparker) this).rd.fillRect(65, 25, 670, 400);
				repaint();
				var_xtGraphics.inishstageselect(checkpoints);
			}
			if (((xtGraphics) var_xtGraphics).fase == 2) {
				((GameSparker) this).mvect = 100;
				var_xtGraphics.loadingstage(((CheckPoints) checkpoints).stage,
				true);
				((CheckPoints) checkpoints).nfix = 0;
				((CheckPoints) checkpoints).notb = false;
				loadstage(contos_0_, contos, medium, trackers, checkpoints,
				var_xtGraphics, mads, record);
				((GameSparker) this).u[0].falseo(0);
				((UDPMistro) udpmistro).freg = 0.0F;
				((GameSparker) this).mvect = 20;
			}
			if (((xtGraphics) var_xtGraphics).fase == 1) {
				var_xtGraphics.trackbg(false);
				((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
				if (((CheckPoints) checkpoints).stage != -3) {
					medium.aroundtrack(checkpoints);
					if (((Medium) medium).hit == 5000 && ((GameSparker) this).mvect < 40)
					((GameSparker) this).mvect++;
					int i_12_ = 0;
					int[] is = new int[1000];
					for (int i_13_ = ((xtGraphics) var_xtGraphics).nplayers;
					i_13_ < ((GameSparker) this).notb; i_13_++) {
						if (((ContO) contos_0_[i_13_]).dist != 0) {
							is[i_12_] = i_13_;
							i_12_++;
						} else contos_0_[i_13_].d(((GameSparker) this).rd);
					}
					int[] is_14_ = new int[i_12_];
					for (int i_15_ = 0; i_15_ < i_12_; i_15_++)
					is_14_[i_15_] = 0;
					for (int i_16_ = 0; i_16_ < i_12_; i_16_++) {
						for (int i_17_ = i_16_ + 1; i_17_ < i_12_; i_17_++) {
							if (((ContO) contos_0_[is[i_16_]]).dist != ((ContO) contos_0_[is[i_17_]]).dist) {
								if (((ContO) contos_0_[is[i_16_]]).dist < ((ContO) contos_0_[is[i_17_]]).dist) is_14_[i_16_]++;
								else is_14_[i_17_]++;
							} else if (i_17_ > i_16_) is_14_[i_16_]++;
							else is_14_[i_17_]++;
						}
					}
					for (int i_18_ = 0; i_18_ < i_12_; i_18_++) {
						for (int i_19_ = 0; i_19_ < i_12_; i_19_++) {
							if (is_14_[i_19_] == i_18_) contos_0_[is[i_19_]].d(((GameSparker) this).rd);
						}
					}
				}
				if (!((GameSparker) this).openm) var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
				((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
				var_xtGraphics.stageselect(checkpoints, ((GameSparker) this).u[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused);
				drawms();
			}
			if (((xtGraphics) var_xtGraphics).fase == 1177) {
				((GameSparker) this).mvect = 100;
				if (!bool) {
					if (((xtGraphics) var_xtGraphics).loadedt) {
						((GameSparker) this).rd.setColor(new Color(0, 0, 0));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
						repaint();
						checkmemory(var_xtGraphics);
						((xtGraphics) var_xtGraphics).strack.unload();
						((xtGraphics) var_xtGraphics).strack = null;
						((xtGraphics) var_xtGraphics).flexpix = null;
						((xtGraphics) var_xtGraphics).fleximg = null;
						System.gc();
						((xtGraphics) var_xtGraphics).loadedt = false;
					}
					((xtGraphics) var_xtGraphics).intertrack.unloadimod();
					((GameSparker) this).rd.setColor(new Color(0, 0, 0));
					((GameSparker) this).rd.fillRect(65, 25, 670, 400);
					if (((GameSparker) this).mload > 0)
					((GameSparker) this).rd.drawImage((((xtGraphics)
					var_xtGraphics)
						.mload),
					259, 195, this);
					repaint();
					if (((GameSparker) this).mload == 2) {
						cardefine.loadready();
						loadbase(contos, medium, trackers, var_xtGraphics,
						true);
						readcookies(var_xtGraphics, cardefine, contos);
						((GameSparker) this).mload = -1;
					}
					System.gc();
					login = new Login(medium, ((GameSparker) this).rd,
					var_xtGraphics, this);
					globe = new Globe(((GameSparker) this).rd, var_xtGraphics,
					medium, login, cardefine, checkpoints,
					contos, contos_0_, this);
					lobby = new Lobby(medium, ((GameSparker) this).rd, login,
					globe, var_xtGraphics, cardefine, this);
					bool = true;
				}
				if (((Login) login).fase != 18) {
					boolean bool_20_ = false;
					if (((Login) login).fase == 0) login.inishmulti();
					if (((Login) login).fase >= 1 && ((Login) login).fase <= 11) login.multistart(contos, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused);
					if (((Login) login).fase >= 12 && ((Login) login).fase <= 17) {
						if (((Globe) globe).open != 452) login.multimode(contos);
						else bool_20_ = true;
						globe.dome(0, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, ((GameSparker) this).u[0]);
					}
					if (((Login) login).justlog) {
						if (!((xtGraphics) var_xtGraphics).clan.equals(""))
						((Globe) globe).itab = 2;
						((Login) login).justlog = false;
					}
					if (!bool_20_) {
						login.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0], lobby);
						((GameSparker) this).mvect = 50;
					} else {
						drawms();
						((GameSparker) this).mvect = 100;
					}
					if (((GameSparker) this).mouses == 1)
					((GameSparker) this).mouses = 11;
					if (((GameSparker) this).mouses <= -1) {
						((GameSparker) this).mouses--;
						if (((GameSparker) this).mouses == -4)
						((GameSparker) this).mouses = 0;
					}
					if (((GameSparker) this).mousew != 0) {
						if (((GameSparker) this).mousew > 0)
						((GameSparker) this).mousew--;
						else((GameSparker) this).mousew++;
					}
				} else {
					boolean bool_21_ = false;
					if (((Lobby) lobby).fase == 0) {
						lobby.inishlobby();
						((GameSparker) this).mvect = 100;
					}
					if (((Lobby) lobby).fase == 1) {
						if (((Globe) globe).open >= 2 && ((Globe) globe).open < 452)
						((GameSparker) this).openm = true;
						if (((Globe) globe).open != 452) lobby.lobby(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, ((GameSparker) this).mousew,
						checkpoints, ((GameSparker) this).u[0],
						contos);
						else bool_21_ = true;
						globe.dome(((Lobby) lobby).conon, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, ((GameSparker) this).u[0]);
						if (((Lobby) lobby).loadstage > 0) {
							setCursor(new Cursor(3));
							drawms();
							repaint();
							((Trackers) trackers).nt = 0;
							if (loadstagePreview(((Lobby) lobby).loadstage, "",
							contos_0_, contos, medium,
							checkpoints)) {
								((Lobby) lobby).gstagename = ((CheckPoints) checkpoints).name;
								((Lobby) lobby).gstagelaps = ((CheckPoints) checkpoints).nlaps;
								((Lobby) lobby).loadstage = -((Lobby) lobby).loadstage;
							} else {
								((Lobby) lobby).loadstage = 0;
								((CheckPoints) checkpoints).name = "";
							}
							setCursor(new Cursor(0));
						}
						if (((Lobby) lobby).msload != 0) {
							setCursor(new Cursor(3));
							drawms();
							repaint();
							if (((Lobby) lobby).msload == 1) cardefine.loadmystages(checkpoints);
							if (((Lobby) lobby).msload == 7) cardefine.loadclanstages(((xtGraphics)
							var_xtGraphics)
								.clan);
							if (((Lobby) lobby).msload == 3 || ((Lobby) lobby).msload == 4) cardefine.loadtop20(((Lobby) lobby).msload);
							((Lobby) lobby).msload = 0;
							setCursor(new Cursor(0));
						}
					}
					if (((Lobby) lobby).fase == 3) {
						var_xtGraphics.trackbg(false);
						((Medium) medium).trk = 0;
						((Medium) medium).focus_point = 400;
						((Medium) medium).crs = true;
						((Medium) medium).x = -335;
						((Medium) medium).y = 0;
						((Medium) medium).z = -50;
						((Medium) medium).xz = 0;
						((Medium) medium).zy = 20;
						((Medium) medium).ground = -2000;
						((GameSparker) this).mvect = 100;
						((Lobby) lobby).fase = 1;
					}
					if (((Lobby) lobby).fase == 4) {
						((GameSparker) this).mvect = 50;
						((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
						RenderingHints.VALUE_ANTIALIAS_OFF);
						medium.d(((GameSparker) this).rd);
						medium.aroundtrack(checkpoints);
						int i_22_ = 0;
						int[] is = new int[1000];
						for (int i_23_ = 0; i_23_ < ((GameSparker) this).nob;
						i_23_++) {
							if (((ContO) contos_0_[i_23_]).dist != 0) {
								is[i_22_] = i_23_;
								i_22_++;
							} else contos_0_[i_23_].d(((GameSparker) this).rd);
						}
						int[] is_24_ = new int[i_22_];
						for (int i_25_ = 0; i_25_ < i_22_; i_25_++)
						is_24_[i_25_] = 0;
						for (int i_26_ = 0; i_26_ < i_22_; i_26_++) {
							for (int i_27_ = i_26_ + 1; i_27_ < i_22_;
							i_27_++) {
								if (((ContO) contos_0_[is[i_26_]]).dist != ((ContO) contos_0_[is[i_27_]]).dist) {
									if (((ContO) contos_0_[is[i_26_]]).dist < ((ContO) contos_0_[is[i_27_]]).dist) is_24_[i_26_]++;
									else is_24_[i_27_]++;
								} else if (i_27_ > i_26_) is_24_[i_26_]++;
								else is_24_[i_27_]++;
							}
						}
						for (int i_28_ = 0; i_28_ < i_22_; i_28_++) {
							for (int i_29_ = 0; i_29_ < i_22_; i_29_++) {
								if (is_24_[i_29_] == i_28_) contos_0_[is[i_29_]].d(((GameSparker) this).rd);
							}
						}
						((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
						RenderingHints.VALUE_ANTIALIAS_ON);
						lobby.stageselect(checkpoints, ((GameSparker) this).u[0], ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused);
						if (((Lobby) lobby).plsndt == 1) {
							((GameSparker) this).mvect = 70;
							repaint();
							setCursor(new Cursor(3));
							var_xtGraphics.loadstrack(((CheckPoints) checkpoints).stage, ((CheckPoints) checkpoints).trackname, ((CheckPoints) checkpoints).trackvol);
							((xtGraphics) var_xtGraphics).strack.play();
							((Lobby) lobby).plsndt = 2;
							((GameSparker) this).moused = false;
							((GameSparker) this).mouses = 0;
						}
					}
					if (((Lobby) lobby).fase == 2) {
						int i_30_ = 0;
						for (int i_31_ = 0; i_31_ < ((Lobby) lobby).ngm;
						i_31_++) {
							if (((Lobby) lobby).ongame == ((Lobby) lobby).gnum[i_31_]) i_30_ = i_31_;
						}
						boolean bool_32_ = false;
						if (((Lobby) lobby).gstgn[i_30_] > 0) {
							if (((Lobby) lobby).gstgn[i_30_] == -((Lobby) lobby).loadstage) bool_32_ = true;
						} else if (((Lobby) lobby).gstages[i_30_].equals(((CheckPoints) checkpoints).name)) bool_32_ = true;
						if (bool_32_) {
							((Lobby) lobby).fase = 4;
							((Lobby) lobby).addstage = 0;
						} else {
							var_xtGraphics.loadingstage((((Lobby) lobby).gstgn[i_30_]),
							false);
							((Trackers) trackers).nt = 0;
							if (loadstagePreview(((Lobby) lobby).gstgn[i_30_], (((Lobby) lobby).gstages[i_30_]),
							contos_0_, contos, medium,
							checkpoints)) {
								((Lobby) lobby).loadstage = -((Lobby) lobby).gstgn[i_30_];
								((Lobby) lobby).fase = 4;
								((Lobby) lobby).addstage = 0;
							} else {
								((Lobby) lobby).loadstage = 0;
								((CheckPoints) checkpoints).name = "";
								((Lobby) lobby).fase = 3;
							}
						}
					}
					if (((Lobby) lobby).fase == 76) {
						((CheckPoints) checkpoints).nlaps = ((Lobby) lobby).laps;
						((CheckPoints) checkpoints).stage = ((Lobby) lobby).stage;
						((CheckPoints) checkpoints).name = ((Lobby) lobby).stagename;
						((CheckPoints) checkpoints).nfix = ((Lobby) lobby).nfix;
						((CheckPoints) checkpoints).notb = ((Lobby) lobby).notb;
						((xtGraphics) var_xtGraphics).fase = 21;
						((Control)((GameSparker) this).u[0]).multion = ((xtGraphics) var_xtGraphics).multion;
					}
					if (((Globe) globe).loadwbgames == 7) {
						repaint();
						globe.redogame();
					}
					if (!((GameSparker) this).openm) {
						if (!bool_21_) lobby.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
					} else((GameSparker) this).mouses = 0;
					drawms();
					if (((Lobby) lobby).fase == 1) lobby.preforma(((GameSparker) this).xm, ((GameSparker) this).ym);
					if (((Lobby) lobby).loadwarb) {
						repaint();
						globe.loadwarb();
						((Lobby) lobby).loadwarb = false;
					}
					if (((Globe) globe).loadwbgames == 1) {
						repaint();
						globe.loadwgames();
					}
					if (((GameSparker) this).mouses == 1)
					((GameSparker) this).mouses = 11;
					if (((GameSparker) this).mouses <= -1) {
						((GameSparker) this).mouses--;
						if (((GameSparker) this).mouses == -4)
						((GameSparker) this).mouses = 0;
					}
					if (((GameSparker) this).mousew != 0) {
						if (((GameSparker) this).mousew > 0)
						((GameSparker) this).mousew--;
						else((GameSparker) this).mousew++;
						if (!((Lobby) lobby).zeromsw)
						((GameSparker) this).mousew = 0;
					}
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 24) {
				login.endcons();
				login = null;
				lobby = null;
				globe = null;
				bool = false;
				System.gc();
				System.runFinalization();
				if (!((xtGraphics) var_xtGraphics).mtop) {
					((xtGraphics) var_xtGraphics).fase = 102;
					((xtGraphics) var_xtGraphics).opselect = 2;
				} else {
					((xtGraphics) var_xtGraphics).fase = 10;
					((xtGraphics) var_xtGraphics).opselect = 1;
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 23) {
				if (((Login) login).fase == 18)
				((xtGraphics) var_xtGraphics).playingame = -101;
				login.stopallnow();
				lobby.stopallnow();
				globe.stopallnow();
				login = null;
				lobby = null;
				globe = null;
				hidefields();
				bool = false;
				System.gc();
				System.runFinalization();
				((xtGraphics) var_xtGraphics).fase = -9;
			}
			if (((xtGraphics) var_xtGraphics).fase == 22) {
				loadstage(contos_0_, contos, medium, trackers, checkpoints,
				var_xtGraphics, mads, record);
				if (((CheckPoints) checkpoints).stage != -3) {
					if (((xtGraphics) var_xtGraphics).lan && ((xtGraphics) var_xtGraphics).im == 0) udpmistro.UDPLanServer(((xtGraphics) var_xtGraphics).nplayers, ((xtGraphics) var_xtGraphics).server, ((xtGraphics) var_xtGraphics).servport, ((xtGraphics) var_xtGraphics).playingame);
					((GameSparker) this).u[0].falseo(2);
					requestFocus();
				} else((xtGraphics) var_xtGraphics).fase = 1177;
			}
			if (((xtGraphics) var_xtGraphics).fase == 21) {
				login.endcons();
				login = null;
				lobby = null;
				globe = null;
				bool = false;
				System.gc();
				System.runFinalization();
				((xtGraphics) var_xtGraphics).fase = 22;
			}
			if (((xtGraphics) var_xtGraphics).fase == 0) {
				for (int i_33_ = 0;
				i_33_ < ((xtGraphics) var_xtGraphics).nplayers; i_33_++) {
					if (((Mad) mads[i_33_]).newcar) {
						int i_34_ = ((ContO) contos_0_[i_33_]).xz;
						int i_35_ = ((ContO) contos_0_[i_33_]).xy;
						int i_36_ = ((ContO) contos_0_[i_33_]).zy;
						contos_0_[i_33_] = new ContO(contos[((Mad) mads[i_33_]).cn], ((ContO) contos_0_[i_33_]).x, ((ContO) contos_0_[i_33_]).y, ((ContO) contos_0_[i_33_]).z, 0);
						((ContO) contos_0_[i_33_]).xz = i_34_;
						((ContO) contos_0_[i_33_]).xy = i_35_;
						((ContO) contos_0_[i_33_]).zy = i_36_;
						((Mad) mads[i_33_]).newcar = false;
					}
				}
				medium.d(((GameSparker) this).rd);
				int i_37_ = 0;
				int[] is = new int[10000];
				for (int i_38_ = 0; i_38_ < ((GameSparker) this).nob;
				i_38_++) {
					if (((ContO) contos_0_[i_38_]).dist != 0) {
						is[i_37_] = i_38_;
						i_37_++;
					} else contos_0_[i_38_].d(((GameSparker) this).rd);
				}
				int[] is_39_ = new int[i_37_];
				int[] is_40_ = new int[i_37_];
				for (int i_41_ = 0; i_41_ < i_37_; i_41_++)
				is_39_[i_41_] = 0;
				for (int i_42_ = 0; i_42_ < i_37_; i_42_++) {
					for (int i_43_ = i_42_ + 1; i_43_ < i_37_; i_43_++) {
						if (((ContO) contos_0_[is[i_42_]]).dist < ((ContO) contos_0_[is[i_43_]]).dist) is_39_[i_42_]++;
						else is_39_[i_43_]++;
					}
					is_40_[is_39_[i_42_]] = i_42_;
				}
				for (int i_44_ = 0; i_44_ < i_37_; i_44_++)
				contos_0_[is[is_40_[i_44_]]].d(((GameSparker) this).rd);
				if (((xtGraphics) var_xtGraphics).starcnt == 0) {
					for (int i_45_ = 0;
					i_45_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_45_++) {
						for (int i_46_ = 0;
						i_46_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_46_++) {
							if (i_46_ != i_45_) mads[i_45_].colide(contos_0_[i_45_],
							mads[i_46_],
							contos_0_[i_46_]);
						}
					}
					for (int i_47_ = 0;
					i_47_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_47_++)
					mads[i_47_].drive(((GameSparker) this).u[i_47_],
					contos_0_[i_47_], trackers,
					checkpoints);
					for (int i_48_ = 0;
					i_48_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_48_++)
					record.rec(contos_0_[i_48_], i_48_, ((Mad) mads[i_48_]).squash, ((Mad) mads[i_48_]).lastcolido, ((Mad) mads[i_48_]).cntdest, 0);
					checkpoints.checkstat(mads, contos_0_, record, (((xtGraphics) var_xtGraphics)
						.nplayers), ((xtGraphics) var_xtGraphics).im, 0);
					for (int i_49_ = 1;
					i_49_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_49_++)
					((GameSparker) this).u[i_49_].preform(mads[i_49_],
					contos_0_[i_49_],
					checkpoints,
					trackers);
				} else {
					if (((xtGraphics) var_xtGraphics).starcnt == 130) {
						((Medium) medium).adv = 1900;
						((Medium) medium).zy = 40;
						((Medium) medium).vxz = 70;
						((GameSparker) this).rd.setColor(new Color(255, 255,
						255));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					}
					if (((xtGraphics) var_xtGraphics).starcnt != 0)
					((xtGraphics) var_xtGraphics).starcnt--;
				}
				if (((xtGraphics) var_xtGraphics).starcnt < 38) {
					if (((GameSparker) this).view == 0) {
						medium.follow(contos_0_[0], ((Mad) mads[0]).cxz, (((Control)((GameSparker) this).u[0])
							.lookback));
						var_xtGraphics.stat(mads[0], contos_0_[0], checkpoints, ((GameSparker) this).u[0], true);
						if (((Mad) mads[0]).outshakedam > 0) {
							((GameSparker) this).shaka = ((Mad) mads[0]).outshakedam / 20;
							if (((GameSparker) this).shaka > 25)
							((GameSparker) this).shaka = 25;
						}
						((GameSparker) this).mvect = 65 + Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100;
						if (((GameSparker) this).mvect > 90)
						((GameSparker) this).mvect = 90;
						((GameSparker) this).lmxz = ((Medium) medium).xz;
					}
					if (((GameSparker) this).view == 1) {
						medium.around(contos_0_[0], false);
						var_xtGraphics.stat(mads[0], contos_0_[0], checkpoints, ((GameSparker) this).u[0], false);
						((GameSparker) this).mvect = 80;
					}
					if (((GameSparker) this).view == 2) {
						medium.watch(contos_0_[0], ((Mad) mads[0]).mxz);
						var_xtGraphics.stat(mads[0], contos_0_[0], checkpoints, ((GameSparker) this).u[0], false);
						((GameSparker) this).mvect = 65 + Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100;
						if (((GameSparker) this).mvect > 90)
						((GameSparker) this).mvect = 90;
						((GameSparker) this).lmxz = ((Medium) medium).xz;
					}
					if (((GameSparker) this).mouses == 1) {
						((Control)((GameSparker) this).u[0]).enter = true;
						((GameSparker) this).mouses = 0;
					}
				} else {
					int i_50_ = 3;
					if (((xtGraphics) var_xtGraphics).nplayers == 1) i_50_ = 0;
					medium.around(contos_0_[i_50_], true);
					((GameSparker) this).mvect = 80;
					if (((Control)((GameSparker) this).u[0]).enter || ((Control)((GameSparker) this).u[0]).handb) {
						((xtGraphics) var_xtGraphics).starcnt = 38;
						((Control)((GameSparker) this).u[0]).enter = false;
						((Control)((GameSparker) this).u[0]).handb = false;
					}
					if (((xtGraphics) var_xtGraphics).starcnt == 38) {
						((GameSparker) this).mouses = 0;
						((Medium) medium).vert = false;
						((Medium) medium).adv = 900;
						((Medium) medium).vxz = 180;
						checkpoints.checkstat(mads, contos_0_, record, (((xtGraphics) var_xtGraphics)
							.nplayers), ((xtGraphics) var_xtGraphics).im,
						0);
						medium.follow(contos_0_[0], ((Mad) mads[0]).cxz, 0);
						var_xtGraphics.stat(mads[0], contos_0_[0], checkpoints, ((GameSparker) this).u[0], true);
						((GameSparker) this).rd.setColor(new Color(255, 255,
						255));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					}
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == 7001) {
				for (int i_51_ = 0;
				i_51_ < ((xtGraphics) var_xtGraphics).nplayers; i_51_++) {
					if (((Mad) mads[i_51_]).newedcar == 0 && ((Mad) mads[i_51_]).newcar) {
						int i_52_ = ((ContO) contos_0_[i_51_]).xz;
						int i_53_ = ((ContO) contos_0_[i_51_]).xy;
						int i_54_ = ((ContO) contos_0_[i_51_]).zy;
						var_xtGraphics.colorCar(contos[((Mad) mads[i_51_]).cn],
						i_51_);
						contos_0_[i_51_] = new ContO(contos[((Mad) mads[i_51_]).cn], ((ContO) contos_0_[i_51_]).x, ((ContO) contos_0_[i_51_]).y, ((ContO) contos_0_[i_51_]).z, 0);
						((ContO) contos_0_[i_51_]).xz = i_52_;
						((ContO) contos_0_[i_51_]).xy = i_53_;
						((ContO) contos_0_[i_51_]).zy = i_54_;
						((Mad) mads[i_51_]).newedcar = 20;
					}
				}
				medium.d(((GameSparker) this).rd);
				int i_55_ = 0;
				int[] is = new int[10000];
				for (int i_56_ = 0; i_56_ < ((GameSparker) this).nob;
				i_56_++) {
					if (((ContO) contos_0_[i_56_]).dist != 0) {
						is[i_55_] = i_56_;
						i_55_++;
					} else contos_0_[i_56_].d(((GameSparker) this).rd);
				}
				int[] is_57_ = new int[i_55_];
				int[] is_58_ = new int[i_55_];
				for (int i_59_ = 0; i_59_ < i_55_; i_59_++)
				is_57_[i_59_] = 0;
				for (int i_60_ = 0; i_60_ < i_55_; i_60_++) {
					for (int i_61_ = i_60_ + 1; i_61_ < i_55_; i_61_++) {
						if (((ContO) contos_0_[is[i_60_]]).dist < ((ContO) contos_0_[is[i_61_]]).dist) is_57_[i_60_]++;
						else is_57_[i_61_]++;
					}
					is_58_[is_57_[i_60_]] = i_60_;
				}
				for (int i_62_ = 0; i_62_ < i_55_; i_62_++) {
					if ((is[is_58_[i_62_]] < ((xtGraphics) var_xtGraphics).nplayers) && (is[is_58_[i_62_]] != ((xtGraphics) var_xtGraphics).im)) udpmistro.readContOinfo(contos_0_[is[is_58_[i_62_]]],
					is[is_58_[i_62_]]);
					contos_0_[is[is_58_[i_62_]]].d(((GameSparker) this).rd);
				}
				if (((xtGraphics) var_xtGraphics).starcnt == 0) {
					if (((xtGraphics) var_xtGraphics).multion == 1) {
						int i_63_ = 1;
						for (int i_64_ = 0;
						i_64_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_64_++) {
							if (((xtGraphics) var_xtGraphics).im != i_64_) {
								udpmistro.readinfo(mads[i_64_], contos_0_[i_64_], ((GameSparker) this).u[i_63_], i_64_, ((CheckPoints) checkpoints).dested);
								i_63_++;
							}
						}
					} else {
						for (int i_65_ = 0;
						i_65_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_65_++)
						udpmistro.readinfo(mads[i_65_], contos_0_[i_65_], ((GameSparker) this).u[i_65_],
						i_65_, (((CheckPoints) checkpoints)
							.dested));
					}
					for (int i_66_ = 0;
					i_66_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_66_++) {
						for (int i_67_ = 0;
						i_67_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_67_++) {
							if (i_67_ != i_66_) mads[i_66_].colide(contos_0_[i_66_],
							mads[i_67_],
							contos_0_[i_67_]);
						}
					}
					if (((xtGraphics) var_xtGraphics).multion == 1) {
						int i_68_ = 1;
						for (int i_69_ = 0;
						i_69_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_69_++) {
							if (((xtGraphics) var_xtGraphics).im != i_69_) {
								mads[i_69_].drive((((GameSparker) this).u[i_68_]),
								contos_0_[i_69_], trackers,
								checkpoints);
								i_68_++;
							} else mads[i_69_].drive(((GameSparker) this).u[0],
							contos_0_[i_69_], trackers,
							checkpoints);
						}
						for (int i_70_ = 0;
						i_70_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_70_++)
						record.rec(contos_0_[i_70_], i_70_, ((Mad) mads[i_70_]).squash, ((Mad) mads[i_70_]).lastcolido, ((Mad) mads[i_70_]).cntdest, ((xtGraphics) var_xtGraphics).im);
					} else {
						for (int i_71_ = 0;
						i_71_ < ((xtGraphics) var_xtGraphics).nplayers;
						i_71_++)
						mads[i_71_].drive(((GameSparker) this).u[i_71_],
						contos_0_[i_71_], trackers,
						checkpoints);
					}
					checkpoints.checkstat(mads, contos_0_, record, (((xtGraphics) var_xtGraphics)
						.nplayers), ((xtGraphics) var_xtGraphics).im, (((xtGraphics) var_xtGraphics)
						.multion));
				} else {
					if (((xtGraphics) var_xtGraphics).starcnt == 130) {
						((Medium) medium).adv = 1900;
						((Medium) medium).zy = 40;
						((Medium) medium).vxz = 70;
						((GameSparker) this).rd.setColor(new Color(255, 255,
						255));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
						repaint();
						if (((xtGraphics) var_xtGraphics).lan) {
							udpmistro.UDPConnectLan(((xtGraphics) var_xtGraphics).localserver, ((xtGraphics) var_xtGraphics).nplayers, ((xtGraphics) var_xtGraphics).im);
							if (((xtGraphics) var_xtGraphics).im == 0) var_xtGraphics.setbots((((UDPMistro) udpmistro)
								.isbot), (((UDPMistro) udpmistro)
								.frame));
						} else udpmistro.UDPConnectOnline(((xtGraphics) var_xtGraphics).server, ((xtGraphics) var_xtGraphics).gameport, ((xtGraphics) var_xtGraphics).nplayers, ((xtGraphics) var_xtGraphics).im);
						if (((xtGraphics) var_xtGraphics).multion >= 2) {
							((xtGraphics) var_xtGraphics).im = (int)(Math.random() * (double)((xtGraphics)
							var_xtGraphics).nplayers);
							((xtGraphics) var_xtGraphics).starcnt = 0;
						}
					}
					if (((xtGraphics) var_xtGraphics).starcnt == 50)
					((UDPMistro) udpmistro).frame[((UDPMistro) udpmistro).im][0] = 0;
					if (((xtGraphics) var_xtGraphics).starcnt != 39 && ((xtGraphics) var_xtGraphics).starcnt != 0)
					((xtGraphics) var_xtGraphics).starcnt--;
					if (((UDPMistro) udpmistro).go && ((xtGraphics) var_xtGraphics).starcnt >= 39) {
						((xtGraphics) var_xtGraphics).starcnt = 38;
						if (((xtGraphics) var_xtGraphics).lan) {
							int i_72_ = ((CheckPoints) checkpoints).stage;
							if (i_72_ < 0) i_72_ = 33;
							if (((xtGraphics) var_xtGraphics).loadedt)
							((xtGraphics) var_xtGraphics).strack.play();
						}
					}
				}
				if (((xtGraphics) var_xtGraphics).lan && ((UDPMistro) udpmistro).im == 0) {
					for (int i_73_ = 2;
					i_73_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_73_++) {
						if (((UDPMistro) udpmistro).isbot[i_73_]) {
							((GameSparker) this).u[i_73_].preform(mads[i_73_], (contos_0_[i_73_]),
							checkpoints,
							trackers);
							udpmistro.setinfo(mads[i_73_], contos_0_[i_73_], ((GameSparker) this).u[i_73_], (((CheckPoints) checkpoints).pos[i_73_]), (((CheckPoints) checkpoints)
								.magperc[i_73_]),
							false, i_73_);
						}
					}
				}
				if (((xtGraphics) var_xtGraphics).starcnt < 38) {
					if (((xtGraphics) var_xtGraphics).multion == 1) {
						udpmistro.setinfo((mads[((xtGraphics) var_xtGraphics).im]), (contos_0_[((xtGraphics) var_xtGraphics).im]), ((GameSparker) this).u[0], (((CheckPoints) checkpoints).pos[((xtGraphics) var_xtGraphics).im]), (((CheckPoints) checkpoints).magperc[((xtGraphics) var_xtGraphics).im]), ((xtGraphics) var_xtGraphics).holdit, ((xtGraphics) var_xtGraphics).im);
						if (((GameSparker) this).view == 0) {
							medium.follow((contos_0_[((xtGraphics) var_xtGraphics).im]), (((Mad) mads[((xtGraphics)
							var_xtGraphics).im])
								.cxz), ((Control)(((GameSparker) this).u[0])).lookback);
							var_xtGraphics.stat(mads[((xtGraphics) var_xtGraphics).im],
							contos_0_[((xtGraphics) var_xtGraphics).im],
							checkpoints, ((GameSparker) this).u[0], true);
							if ((((Mad) mads[((xtGraphics) var_xtGraphics).im])
								.outshakedam) > 0) {
								((GameSparker) this).shaka = (((Mad)
								mads[((xtGraphics) var_xtGraphics).im])
									.outshakedam) / 20;
								if (((GameSparker) this).shaka > 25)
								((GameSparker) this).shaka = 25;
							}
							((GameSparker) this).mvect = 65 + (Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100);
							if (((GameSparker) this).mvect > 90)
							((GameSparker) this).mvect = 90;
							((GameSparker) this).lmxz = ((Medium) medium).xz;
						}
						if (((GameSparker) this).view == 1) {
							medium.around((contos_0_[((xtGraphics) var_xtGraphics).im]),
							false);
							var_xtGraphics.stat(mads[((xtGraphics) var_xtGraphics).im],
							contos_0_[((xtGraphics) var_xtGraphics).im],
							checkpoints, ((GameSparker) this).u[0],
							false);
							((GameSparker) this).mvect = 80;
						}
						if (((GameSparker) this).view == 2) {
							medium.watch((contos_0_[((xtGraphics) var_xtGraphics).im]), (((Mad) mads[((xtGraphics)
							var_xtGraphics).im])
								.mxz));
							var_xtGraphics.stat(mads[((xtGraphics) var_xtGraphics).im],
							contos_0_[((xtGraphics) var_xtGraphics).im],
							checkpoints, ((GameSparker) this).u[0],
							false);
							((GameSparker) this).mvect = 65 + (Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100);
							if (((GameSparker) this).mvect > 90)
							((GameSparker) this).mvect = 90;
							((GameSparker) this).lmxz = ((Medium) medium).xz;
						}
					} else {
						if (((GameSparker) this).view == 0) {
							medium.getaround(contos_0_[((xtGraphics)
							var_xtGraphics).im]);
							((GameSparker) this).mvect = 80;
						}
						if (((GameSparker) this).view == 1) {
							medium.getfollow(contos_0_[((xtGraphics) var_xtGraphics).im], ((Mad)
							mads[((xtGraphics) var_xtGraphics).im]).cxz, (((Control)((GameSparker) this).u[0])
								.lookback));
							((GameSparker) this).mvect = 65 + (Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100);
							if (((GameSparker) this).mvect > 90)
							((GameSparker) this).mvect = 90;
							((GameSparker) this).lmxz = ((Medium) medium).xz;
						}
						if (((GameSparker) this).view == 2) {
							medium.watch((contos_0_[((xtGraphics) var_xtGraphics).im]), (((Mad) mads[((xtGraphics)
							var_xtGraphics).im])
								.mxz));
							((GameSparker) this).mvect = 65 + (Math.abs(((GameSparker) this).lmxz - ((Medium) medium).xz) / 5 * 100);
							if (((GameSparker) this).mvect > 90)
							((GameSparker) this).mvect = 90;
							((GameSparker) this).lmxz = ((Medium) medium).xz;
						}
						var_xtGraphics.stat(mads[((xtGraphics) var_xtGraphics).im],
						contos_0_[((xtGraphics) var_xtGraphics).im],
						checkpoints, ((GameSparker) this).u[0], true);
					}
					if (((GameSparker) this).mouses == 1) {
						if (((xtGraphics) var_xtGraphics).holdit && ((xtGraphics) var_xtGraphics).exitm != 4 && ((xtGraphics) var_xtGraphics).multion == 1)
						((Control)((GameSparker) this).u[0]).enter = true;
						((GameSparker) this).mouses = 0;
					}
				} else {
					medium.around(contos_0_[((xtGraphics) var_xtGraphics).im],
					true);
					((GameSparker) this).mvect = 80;
					if (((xtGraphics) var_xtGraphics).starcnt == 39) var_xtGraphics.waitenter();
					if (((xtGraphics) var_xtGraphics).starcnt == 38) {
						((xtGraphics) var_xtGraphics).forstart = 0;
						((GameSparker) this).mouses = 0;
						((Medium) medium).vert = false;
						((Medium) medium).adv = 900;
						((Medium) medium).vxz = 180;
						checkpoints.checkstat(mads, contos_0_, record, (((xtGraphics) var_xtGraphics)
							.nplayers), ((xtGraphics) var_xtGraphics).im, (((xtGraphics) var_xtGraphics)
							.multion));
						medium.follow((contos_0_[((xtGraphics) var_xtGraphics).im]), (((Mad)
						mads[((xtGraphics) var_xtGraphics).im])
							.cxz),
						0);
						var_xtGraphics.stat(mads[((xtGraphics) var_xtGraphics).im],
						contos_0_[((xtGraphics) var_xtGraphics).im],
						checkpoints, ((GameSparker) this).u[0], true);
						((GameSparker) this).rd.setColor(new Color(255, 255,
						255));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					}
				}
				var_xtGraphics.multistat(((GameSparker) this).u[0],
				checkpoints, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused,
				udpmistro);
			}
			if (((xtGraphics) var_xtGraphics).fase == -1) {
				if (i_6_ == 0) {
					for (int i_74_ = 0;
					i_74_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_74_++) {
						((Record) record).ocar[i_74_] = new ContO(contos_0_[i_74_], 0, 0, 0, 0);
						contos_0_[i_74_] = new ContO(((Record) record).car[0][i_74_], 0, 0,
						0, 0);
					}
				}
				medium.d(((GameSparker) this).rd);
				int i_75_ = 0;
				int[] is = new int[10000];
				for (int i_76_ = 0; i_76_ < ((GameSparker) this).nob;
				i_76_++) {
					if (((ContO) contos_0_[i_76_]).dist != 0) {
						is[i_75_] = i_76_;
						i_75_++;
					} else contos_0_[i_76_].d(((GameSparker) this).rd);
				}
				int[] is_77_ = new int[i_75_];
				for (int i_78_ = 0; i_78_ < i_75_; i_78_++)
				is_77_[i_78_] = 0;
				for (int i_79_ = 0; i_79_ < i_75_; i_79_++) {
					for (int i_80_ = i_79_ + 1; i_80_ < i_75_; i_80_++) {
						if (((ContO) contos_0_[is[i_79_]]).dist != ((ContO) contos_0_[is[i_80_]]).dist) {
							if (((ContO) contos_0_[is[i_79_]]).dist < ((ContO) contos_0_[is[i_80_]]).dist) is_77_[i_79_]++;
							else is_77_[i_80_]++;
						} else if (i_80_ > i_79_) is_77_[i_79_]++;
						else is_77_[i_80_]++;
					}
				}
				for (int i_81_ = 0; i_81_ < i_75_; i_81_++) {
					for (int i_82_ = 0; i_82_ < i_75_; i_82_++) {
						if (is_77_[i_82_] == i_81_) contos_0_[is[i_82_]].d(((GameSparker) this).rd);
					}
				}
				if (((Control)((GameSparker) this).u[0]).enter || ((Control)((GameSparker) this).u[0]).handb || ((GameSparker) this).mouses == 1) {
					i_6_ = 299;
					((Control)((GameSparker) this).u[0]).enter = false;
					((Control)((GameSparker) this).u[0]).handb = false;
					((GameSparker) this).mouses = 0;
				}
				for (int i_83_ = 0;
				i_83_ < ((xtGraphics) var_xtGraphics).nplayers; i_83_++) {
					if (((Record) record).fix[i_83_] == i_6_) {
						if (((ContO) contos_0_[i_83_]).dist == 0)
						((ContO) contos_0_[i_83_]).fcnt = 8;
						else((ContO) contos_0_[i_83_]).fix = true;
					}
					if (((ContO) contos_0_[i_83_]).fcnt == 7 || ((ContO) contos_0_[i_83_]).fcnt == 8) {
						contos_0_[i_83_] = new ContO(contos[((Mad) mads[i_83_]).cn], 0, 0,
						0, 0);
						((Record) record).cntdest[i_83_] = 0;
					}
					if (i_6_ == 299) contos_0_[i_83_] = new ContO(((Record) record).ocar[i_83_], 0, 0, 0,
					0);
					record.play(contos_0_[i_83_], mads[i_83_], i_83_, i_6_);
				}
				if (++i_6_ == 300) {
					i_6_ = 0;
					((xtGraphics) var_xtGraphics).fase = -6;
				} else var_xtGraphics.replyn();
				medium.around(contos_0_[0], false);
			}
			if (((xtGraphics) var_xtGraphics).fase == -2) {
				if (((xtGraphics) var_xtGraphics).multion >= 2)
				((Record) record).hcaught = false;
				((GameSparker) this).u[0].falseo(3);
				if (((Record) record).hcaught && ((Record) record).wasted == 0 && ((Record) record).whenwasted != 229 && (((CheckPoints) checkpoints).stage == 1 || ((CheckPoints) checkpoints).stage == 2) && ((xtGraphics) var_xtGraphics).looped != 0)
				((Record) record).hcaught = false;
				if (((Record) record).hcaught) {
					((GameSparker) this).rd.setColor(new Color(0, 0, 0));
					((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					repaint();
				}
				if (((xtGraphics) var_xtGraphics).multion != 0) {
					udpmistro.UDPquit();
					var_xtGraphics.stopchat();
					if (((GameSparker) this).cmsg.isShowing())
					((GameSparker) this).cmsg.hide();
					((GameSparker) this).cmsg.setText("");
					requestFocus();
				}
				if (((Record) record).hcaught) {
					if ((double) medium.random() > 0.45)
					((Medium) medium).vert = false;
					else((Medium) medium).vert = true;
					((Medium) medium).adv = (int)(900.0F * medium.random());
					((Medium) medium).vxz = (int)(360.0F * medium.random());
					i_6_ = 0;
					((xtGraphics) var_xtGraphics).fase = -3;
					i_7_ = 0;
					i_8_ = 0;
				} else {
					i_6_ = -2;
					((xtGraphics) var_xtGraphics).fase = -4;
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == -3) {
				if (i_6_ == 0) {
					if (((Record) record).wasted == 0) {
						if (((Record) record).whenwasted == 229) {
							i_9_ = 67;
							((Medium) medium).vxz += 90;
						} else {
							i_9_ = (int)(medium.random() * 4.0F);
							if (i_9_ == 1 || i_9_ == 3) i_9_ = 69;
							if (i_9_ == 2 || i_9_ == 4) i_9_ = 30;
						}
					} else if (((Record) record).closefinish != 0 && i_8_ != 0)
					((Medium) medium).vxz += 90;
					for (int i_84_ = 0;
					i_84_ < ((xtGraphics) var_xtGraphics).nplayers;
					i_84_++)
					contos_0_[i_84_] = new ContO(((Record) record).starcar[i_84_], 0, 0,
					0, 0);
				}
				medium.d(((GameSparker) this).rd);
				int i_85_ = 0;
				int[] is = new int[10000];
				for (int i_86_ = 0; i_86_ < ((GameSparker) this).nob;
				i_86_++) {
					if (((ContO) contos_0_[i_86_]).dist != 0) {
						is[i_85_] = i_86_;
						i_85_++;
					} else contos_0_[i_86_].d(((GameSparker) this).rd);
				}
				int[] is_87_ = new int[i_85_];
				for (int i_88_ = 0; i_88_ < i_85_; i_88_++)
				is_87_[i_88_] = 0;
				for (int i_89_ = 0; i_89_ < i_85_; i_89_++) {
					for (int i_90_ = i_89_ + 1; i_90_ < i_85_; i_90_++) {
						if (((ContO) contos_0_[is[i_89_]]).dist != ((ContO) contos_0_[is[i_90_]]).dist) {
							if (((ContO) contos_0_[is[i_89_]]).dist < ((ContO) contos_0_[is[i_90_]]).dist) is_87_[i_89_]++;
							else is_87_[i_90_]++;
						} else if (i_90_ > i_89_) is_87_[i_89_]++;
						else is_87_[i_90_]++;
					}
				}
				for (int i_91_ = 0; i_91_ < i_85_; i_91_++) {
					for (int i_92_ = 0; i_92_ < i_85_; i_92_++) {
						if (is_87_[i_92_] == i_91_) contos_0_[is[i_92_]].d(((GameSparker) this).rd);
					}
				}
				for (int i_93_ = 0;
				i_93_ < ((xtGraphics) var_xtGraphics).nplayers; i_93_++) {
					if (((Record) record).hfix[i_93_] == i_6_) {
						if (((ContO) contos_0_[i_93_]).dist == 0)
						((ContO) contos_0_[i_93_]).fcnt = 8;
						else((ContO) contos_0_[i_93_]).fix = true;
					}
					if (((ContO) contos_0_[i_93_]).fcnt == 7 || ((ContO) contos_0_[i_93_]).fcnt == 8) {
						contos_0_[i_93_] = new ContO(contos[((Mad) mads[i_93_]).cn], 0, 0,
						0, 0);
						((Record) record).cntdest[i_93_] = 0;
					}
					record.playh(contos_0_[i_93_], mads[i_93_], i_93_, i_6_, ((xtGraphics) var_xtGraphics).im);
				}
				if (i_8_ == 2 && i_6_ == 299)
				((Control)((GameSparker) this).u[0]).enter = true;
				if (((Control)((GameSparker) this).u[0]).enter || ((Control)((GameSparker) this).u[0]).handb) {
					((xtGraphics) var_xtGraphics).fase = -4;
					((Control)((GameSparker) this).u[0]).enter = false;
					((Control)((GameSparker) this).u[0]).handb = false;
					i_6_ = -7;
				} else {
					var_xtGraphics.levelhigh(((Record) record).wasted, ((Record) record).whenwasted, ((Record) record).closefinish,
					i_6_, (((CheckPoints) checkpoints)
						.stage));
					if (i_6_ == 0 || i_6_ == 1 || i_6_ == 2) {
						((GameSparker) this).rd.setColor(new Color(0, 0, 0));
						((GameSparker) this).rd.fillRect(0, 0, 800, 450);
					}
					if (((Record) record).wasted != ((xtGraphics) var_xtGraphics).im) {
						if (((Record) record).closefinish == 0) {
							if (i_7_ == 9 || i_7_ == 11) {
								((GameSparker) this).rd.setColor(new Color(255, 255, 255));
								((GameSparker) this).rd.fillRect(0, 0, 800,
								450);
							}
							if (i_7_ == 0) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_7_ > 0 && i_7_ < 20) medium.transaround(contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							contos_0_[(((Record) record)
								.wasted)],
							i_7_);
							if (i_7_ == 20) medium.around((contos_0_[((Record) record).wasted]),
							false);
							if (i_6_ > ((Record) record).whenwasted && i_7_ != 20) i_7_++;
							if ((i_7_ == 0 || i_7_ == 20) && ++i_6_ == 300) {
								i_6_ = 0;
								i_7_ = 0;
								i_8_++;
							}
						} else if (((Record) record).closefinish == 1) {
							if (i_7_ == 0) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_7_ > 0 && i_7_ < 20) medium.transaround(contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							contos_0_[(((Record) record)
								.wasted)],
							i_7_);
							if (i_7_ == 20) medium.around((contos_0_[((Record) record).wasted]),
							false);
							if (i_7_ > 20 && i_7_ < 40) medium.transaround(contos_0_[(((Record) record)
								.wasted)],
							contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							i_7_ - 20);
							if (i_7_ == 40) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_7_ > 40 && i_7_ < 60) medium.transaround(contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							contos_0_[(((Record) record)
								.wasted)],
							i_7_ - 40);
							if (i_7_ == 60) medium.around((contos_0_[((Record) record).wasted]),
							false);
							if (i_6_ > 160 && i_7_ < 20) i_7_++;
							if (i_6_ > 230 && i_7_ < 40) i_7_++;
							if (i_6_ > 280 && i_7_ < 60) i_7_++;
							if ((i_7_ == 0 || i_7_ == 20 || i_7_ == 40 || i_7_ == 60) && ++i_6_ == 300) {
								i_6_ = 0;
								i_7_ = 0;
								i_8_++;
							}
						} else {
							if (i_7_ == 0) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_7_ > 0 && i_7_ < 20) medium.transaround(contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							contos_0_[(((Record) record)
								.wasted)],
							i_7_);
							if (i_7_ == 20) medium.around((contos_0_[((Record) record).wasted]),
							false);
							if (i_7_ > 20 && i_7_ < 40) medium.transaround(contos_0_[(((Record) record)
								.wasted)],
							contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							i_7_ - 20);
							if (i_7_ == 40) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_7_ > 40 && i_7_ < 60) medium.transaround(contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							contos_0_[(((Record) record)
								.wasted)],
							i_7_ - 40);
							if (i_7_ == 60) medium.around((contos_0_[((Record) record).wasted]),
							false);
							if (i_7_ > 60 && i_7_ < 80) medium.transaround(contos_0_[(((Record) record)
								.wasted)],
							contos_0_[(((xtGraphics)
							var_xtGraphics)
								.im)],
							i_7_ - 60);
							if (i_7_ == 80) medium.around(contos_0_[((xtGraphics)
							var_xtGraphics).im],
							false);
							if (i_6_ > 90 && i_7_ < 20) i_7_++;
							if (i_6_ > 160 && i_7_ < 40) i_7_++;
							if (i_6_ > 230 && i_7_ < 60) i_7_++;
							if (i_6_ > 280 && i_7_ < 80) i_7_++;
							if ((i_7_ == 0 || i_7_ == 20 || i_7_ == 40 || i_7_ == 60 || i_7_ == 80) && ++i_6_ == 300) {
								i_6_ = 0;
								i_7_ = 0;
								i_8_++;
							}
						}
					} else {
						if (i_9_ == 67 && (i_7_ == 3 || i_7_ == 31 || i_7_ == 66)) {
							((GameSparker) this).rd.setColor(new Color(255, 255, 255));
							((GameSparker) this).rd.fillRect(0, 0, 800, 450);
						}
						if (i_9_ == 69 && (i_7_ == 3 || i_7_ == 5 || i_7_ == 31 || i_7_ == 33 || i_7_ == 66 || i_7_ == 68)) {
							((GameSparker) this).rd.setColor(new Color(255, 255, 255));
							((GameSparker) this).rd.fillRect(0, 0, 800, 450);
						}
						if (i_9_ == 30 && i_7_ >= 1 && i_7_ < 30) {
							if ((i_7_ % (int)(2.0F + medium.random() * 3.0F) == 0) && !bool_10_) {
								((GameSparker) this).rd.setColor(new Color(255, 255, 255));
								((GameSparker) this).rd.fillRect(0, 0, 800,
								450);
								bool_10_ = true;
							} else bool_10_ = false;
						}
						if (i_6_ > ((Record) record).whenwasted && i_7_ != i_9_) i_7_++;
						medium.around((contos_0_[((xtGraphics) var_xtGraphics).im]),
						false);
						if ((i_7_ == 0 || i_7_ == i_9_) && ++i_6_ == 300) {
							i_6_ = 0;
							i_7_ = 0;
							i_8_++;
						}
					}
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == -4) {
				if (i_6_ == 0) {
					var_xtGraphics.sendwin(checkpoints);
					if (((xtGraphics) var_xtGraphics).winner && ((xtGraphics) var_xtGraphics).multion == 0 && ((xtGraphics) var_xtGraphics).gmode != 0 && ((CheckPoints) checkpoints).stage != 27 && (((CheckPoints) checkpoints).stage == ((((xtGraphics) var_xtGraphics).unlocked[((xtGraphics) var_xtGraphics).gmode - 1]) + ((((xtGraphics) var_xtGraphics).gmode - 1) * 10)))) {
						((xtGraphics) var_xtGraphics).unlocked[((xtGraphics) var_xtGraphics).gmode - 1]++;
						setcarcookie(((xtGraphics) var_xtGraphics).sc[0], (((CarDefine) cardefine).names[((xtGraphics) var_xtGraphics).sc[0]]), ((xtGraphics) var_xtGraphics).arnp, ((xtGraphics) var_xtGraphics).gmode, ((xtGraphics) var_xtGraphics).unlocked,
						false);
						((xtGraphics) var_xtGraphics).unlocked[((xtGraphics) var_xtGraphics).gmode - 1]--;
					}
				}
				if (i_6_ <= 0) {
					((GameSparker) this).rd.drawImage(((xtGraphics)
					var_xtGraphics).mdness,
					289, 30, null);
					((GameSparker) this).rd.drawImage(((xtGraphics)
					var_xtGraphics).dude[0],
					135, 10, null);
				}
				if (i_6_ >= 0) var_xtGraphics.fleximage(((GameSparker) this).offImage,
				i_6_, (((CheckPoints) checkpoints)
					.stage));
				if (++i_6_ == 7) {
					((xtGraphics) var_xtGraphics).fase = -5;
					((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
					((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
				}
			}
			if (((xtGraphics) var_xtGraphics).fase == -6) {
				repaint();
				var_xtGraphics.pauseimage(((GameSparker) this).offImage);
				((xtGraphics) var_xtGraphics).fase = -7;
				((GameSparker) this).mouses = 0;
			}
			if (((xtGraphics) var_xtGraphics).fase == -7) {
				var_xtGraphics.pausedgame(((CheckPoints) checkpoints).stage, ((GameSparker) this).u[0], record);
				if (i_6_ != 0) i_6_ = 0;
				var_xtGraphics.ctachm(((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).mouses, ((GameSparker) this).u[0]);
				if (((GameSparker) this).mouses == 2)
				((GameSparker) this).mouses = 0;
				if (((GameSparker) this).mouses == 1)
				((GameSparker) this).mouses = 2;
			}
			if (((xtGraphics) var_xtGraphics).fase == -8) {
				var_xtGraphics.cantreply();
				if (++i_6_ == 150 || ((Control)((GameSparker) this).u[0]).enter || ((Control)((GameSparker) this).u[0]).handb || ((GameSparker) this).mouses == 1) {
					((xtGraphics) var_xtGraphics).fase = -7;
					((GameSparker) this).mouses = 0;
					((Control)((GameSparker) this).u[0]).enter = false;
					((Control)((GameSparker) this).u[0]).handb = false;
				}
			}
			if (((GameSparker) this).lostfcs && ((xtGraphics) var_xtGraphics).fase == 7001) {
				if (((GameSparker) this).fcscnt == 0) {
					if (((Control)((GameSparker) this).u[0]).chatup == 0) requestFocus();
					((GameSparker) this).fcscnt = 10;
				} else((GameSparker) this).fcscnt--;
			}
			repaint();
			if (((xtGraphics) var_xtGraphics).im > -1 && ((xtGraphics) var_xtGraphics).im < 8) {
				int i_94_ = 0;
				if (((xtGraphics) var_xtGraphics).multion == 2 || ((xtGraphics) var_xtGraphics).multion == 3) {
					i_94_ = ((xtGraphics) var_xtGraphics).im;
					((Control)((GameSparker) this).u[i_94_]).mutem = ((Control)((GameSparker) this).u[0]).mutem;
					((Control)((GameSparker) this).u[i_94_]).mutes = ((Control)((GameSparker) this).u[0]).mutes;
				}
				var_xtGraphics.playsounds((mads[((xtGraphics) var_xtGraphics).im]), ((GameSparker) this).u[i_94_], ((CheckPoints) checkpoints).stage);
			}
			date = new Date();
			long l_95_ = date.getTime();
			if (((xtGraphics) var_xtGraphics).fase == 0 || ((xtGraphics) var_xtGraphics).fase == -1 || ((xtGraphics) var_xtGraphics).fase == -3 || ((xtGraphics) var_xtGraphics).fase == 7001) {
				if (!bool_3_) {
					i = 15;
					f_2_ = f;
					if (f_2_ < 30.0F) f_2_ = 30.0F;
					bool_3_ = true;
					i_5_ = 0;
				}
				if (i_5_ == 10) {
					float f_96_ = (((float) i_4_ + ((UDPMistro) udpmistro).freg - (float)(l_95_ - l_1_)) / 20.0F);
					if (f_96_ > 40.0F) f_96_ = 40.0F;
					if (f_96_ < -40.0F) f_96_ = -40.0F;
					f_2_ += f_96_;
					if (f_2_ < 5.0F) f_2_ = 5.0F;
					medium.adjstfade(f_2_, f_96_, ((xtGraphics) var_xtGraphics).starcnt,
					this);
					l_1_ = l_95_;
					i_5_ = 0;
				} else i_5_++;
			} else {
				if (bool_3_) {
					i = 30;
					f = f_2_;
					bool_3_ = false;
					i_5_ = 0;
				}
				if (i_5_ == 10) {
					if (l_95_ - l_1_ < 400L) f_2_ += 3.5;
					else {
						f_2_ -= 3.5;
						if (f_2_ < 5.0F) f_2_ = 5.0F;
					}
					l_1_ = l_95_;
					i_5_ = 0;
				} else i_5_++;
			}
			if (((GameSparker) this).exwist) {
				((GameSparker) this).rd.dispose();
				var_xtGraphics.stopallnow();
				cardefine.stopallnow();
				udpmistro.UDPquit();
				if (bool) {
					lobby.stopallnow();
					login.stopallnow();
					globe.stopallnow();
				}
				System.gc();
				if (Madness.endadv == 2) Madness.advopen();
				((GameSparker) this).gamer.stop();
				((GameSparker) this).gamer = null;
			}
			l = (long) Math.round(f_2_) - (l_95_ - l_11_);
			if (l < (long) i) l = (long) i;
			try {
				if (((GameSparker) this).gamer != null) {
					/* empty */
				}
				Thread.sleep(l);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
	}

	public void checkmemory(xtGraphics var_xtGraphics) {
		if (((GameSparker) this).applejava || Runtime.getRuntime().freeMemory() / 1048576L < 50L)
		((xtGraphics) var_xtGraphics).badmac = true;
	}

	public void paint(Graphics graphics) {
		Graphics2D graphics2d = (Graphics2D) graphics;
		if (((GameSparker) this).lastw != getWidth() || ((GameSparker) this).lasth != getHeight()) {
			((GameSparker) this).lastw = getWidth();
			((GameSparker) this).lasth = getHeight();
			((GameSparker) this).showsize = 100;
			if (((GameSparker) this).lastw <= 800 || ((GameSparker) this).lasth <= 550)
			((GameSparker) this).reqmult = 0.0F;
			if (Madness.fullscreen) {
				((GameSparker) this).apx = (int)((float)(getWidth() / 2) - 400.0F * ((GameSparker) this).apmult);
				((GameSparker) this).apy = (int)((float)(getHeight() / 2) - 225.0F * ((GameSparker) this).apmult);
			}
		}
		int i = 0;
		int i_97_ = 0;
		if (((GameSparker) this).moto == 1 && ((GameSparker) this).shaka > 0) {
			i = (int)((((double)(((GameSparker) this).shaka * 2) * Math.random()) - (double)((GameSparker) this).shaka) * (double)((GameSparker) this).apmult);
			i_97_ = (int)((((double)(((GameSparker) this).shaka * 2) * Math.random()) - (double)((GameSparker) this).shaka) * (double)((GameSparker) this).apmult);
			((GameSparker) this).shaka--;
		}
		if (!Madness.fullscreen) {
			if (((GameSparker) this).showsize != 0) {
				if (((GameSparker) this).showsize == 100 || ((GameSparker) this).showsize == 70) graphics2d.clearRect(0, 0, getWidth(), getHeight());
				float f = (float)(getWidth() - 40) / 800.0F - 1.0F;
				if (f > (float)(getHeight() - 70) / 450.0F - 1.0F) f = (float)(getHeight() - 70) / 450.0F - 1.0F;
				if (f > 1.0F) f = 1.0F;
				if (f < 0.0F) f = 0.0F;
				((GameSparker) this).apmult = 1.0F + f * ((GameSparker) this).reqmult;
				if (!((GameSparker) this).oncarm) graphics2d.drawImage(((GameSparker) this).carmaker[0], 50,
				14, this);
				else graphics2d.drawImage(((GameSparker) this).carmaker[1], 50,
				14, this);
				if (!((GameSparker) this).onstgm) graphics2d.drawImage(((GameSparker) this).stagemaker[0],
				getWidth() - 208, 14, this);
				else graphics2d.drawImage(((GameSparker) this).stagemaker[1],
				getWidth() - 208, 14, this);
				graphics2d.drawImage(((GameSparker) this).sizebar,
				getWidth() / 2 - 230, 23, this);
				graphics2d.drawImage(((GameSparker) this).blb, (int)((float)(getWidth() / 2 - 222) + 141.0F * (((GameSparker) this)
					.reqmult)),
				23, this);
				graphics2d.drawImage((((GameSparker) this).chkbx[((GameSparker) this).smooth]),
				getWidth() / 2 - 53, 23, this);
				graphics2d.setFont(new Font("Arial", 1, 11));
				graphics2d.setColor(new Color(74, 99, 125));
				graphics2d.drawString("Screen Size:", getWidth() / 2 - 224,
				17);
				graphics2d.drawString("Smooth", getWidth() / 2 - 36, 34);
				graphics2d.drawImage(((GameSparker) this).fulls,
				getWidth() / 2 + 27, 15, this);
				graphics2d.setColor(new Color(94, 126, 159));
				graphics2d.drawString("Fullscreen", getWidth() / 2 + 63, 30);
				graphics2d.drawImage(((GameSparker) this).chkbx[Madness.anti],
				getWidth() / 2 + 135, 9, this);
				graphics2d.drawString("Antialiasing", getWidth() / 2 + 152,
				20);
				graphics2d.drawImage((((GameSparker) this).chkbx[((GameSparker) this).moto]),
				getWidth() / 2 + 135, 26, this);
				graphics2d.drawString("Motion Effects", getWidth() / 2 + 152,
				37);
				graphics2d.setColor(new Color(0, 0, 0));
				graphics2d.fillRect(getWidth() / 2 - 153, 5, 80, 16);
				graphics2d.setColor(new Color(121, 135, 152));
				String string = new StringBuilder().append("").append((int)(((GameSparker) this).apmult * 100.0F)).append("%").toString();
				if (((GameSparker) this).reqmult == 0.0F) string = "Original";
				if (((GameSparker) this).reqmult == 1.0F) string = "Maximum";
				graphics2d.drawString(string, getWidth() / 2 - 150, 17);
				if (!((GameSparker) this).oncarm && !((GameSparker) this).onstgm)
				((GameSparker) this).showsize--;
				if (((GameSparker) this).showsize == 0) {
					graphics2d.setColor(new Color(0, 0, 0));
					graphics2d.fillRect(getWidth() / 2 - 260, 0, 520, 40);
					graphics2d.fillRect(50, 14, 142, 23);
					graphics2d.fillRect(getWidth() - 208, 14, 158, 23);
				}
			}
			((GameSparker) this).apx = (int)((float)(getWidth() / 2) - 400.0F * ((GameSparker) this).apmult);
			((GameSparker) this).apy = (int)((float)(getHeight() / 2) - 225.0F * ((GameSparker) this).apmult - 50.0F);
			if (((GameSparker) this).apy < 50)
			((GameSparker) this).apy = 50;
			if (((GameSparker) this).apmult > 1.0F) {
				if (((GameSparker) this).smooth == 1) {
					graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
					RenderingHints.VALUE_INTERPOLATION_BILINEAR);
					if (((GameSparker) this).moto == 1) {
						graphics2d.setComposite(AlphaComposite.getInstance(3, (float)(((GameSparker) this)
							.mvect) / 100.0F));
						((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
						RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
						graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx + i, ((GameSparker) this).apy + i_97_, (int)(800.0F * ((GameSparker) this).apmult), (int)(450.0F * ((GameSparker) this).apmult),
						this);
						cropit(graphics2d, i, i_97_);
					} else graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx, ((GameSparker) this).apy, (int)(800.0F * ((GameSparker) this).apmult), (int)(450.0F * ((GameSparker) this).apmult),
					this);
				} else if (((GameSparker) this).moto == 1) {
					graphics2d.setComposite(AlphaComposite.getInstance(3, (float)(((GameSparker) this)
						.mvect) / 100.0F));
					((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
					RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
					graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx + i, ((GameSparker) this).apy + i_97_, (int)(800.0F * ((GameSparker) this).apmult), (int)(450.0F * ((GameSparker) this).apmult),
					this);
					cropit(graphics2d, i, i_97_);
				} else graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx, ((GameSparker) this).apy, (int)(800.0F * ((GameSparker) this).apmult), (int)(450.0F * ((GameSparker) this).apmult),
				this);
			} else if (((GameSparker) this).moto == 1) {
				graphics2d.setComposite(AlphaComposite.getInstance(3, ((float)((GameSparker) this).mvect / 100.0F)));
				((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
				RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
				graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx + i, ((GameSparker) this).apy + i_97_, this);
				cropit(graphics2d, i, i_97_);
			} else graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx, ((GameSparker) this).apy, this);
		} else if (((GameSparker) this).moto == 1) {
			graphics2d.setComposite(AlphaComposite.getInstance(3, ((float)((GameSparker) this).mvect / 100.0F)));
			((GameSparker) this).rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
			RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
			graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx + i, ((GameSparker) this).apy + i_97_, this);
			cropit(graphics2d, i, i_97_);
		} else graphics2d.drawImage(((GameSparker) this).offImage, ((GameSparker) this).apx, ((GameSparker) this).apy, this);
	}

	public void cropit(Graphics2D graphics2d, int i, int i_98_) {
		if (i != 0 || i_98_ != 0) {
			graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
			graphics2d.setColor(new Color(0, 0, 0));
		}
		if (i != 0) {
			if (i < 0) graphics2d.fillRect(((GameSparker) this).apx + i, (((GameSparker) this).apy - (int)(25.0F * ((GameSparker) this).apmult)),
			Math.abs(i), (int)(500.0F * ((GameSparker) this).apmult));
			else graphics2d.fillRect((((GameSparker) this).apx + (int)(800.0F * ((GameSparker) this).apmult)), (((GameSparker) this).apy - (int)(25.0F * ((GameSparker) this).apmult)),
			i, (int)(500.0F * ((GameSparker) this).apmult));
		}
		if (i_98_ != 0) {
			if (i_98_ < 0) graphics2d.fillRect((((GameSparker) this).apx - (int)(25.0F * ((GameSparker) this).apmult)), ((GameSparker) this).apy + i_98_, (int)(850.0F * ((GameSparker) this).apmult),
			Math.abs(i_98_));
			else graphics2d.fillRect((((GameSparker) this).apx - (int)(25.0F * ((GameSparker) this).apmult)), (((GameSparker) this).apy + (int)(450.0F * ((GameSparker) this).apmult)), (int)(850.0F * ((GameSparker) this).apmult),
			i_98_);
		}
	}

	public void update(Graphics graphics) {
		paint(graphics);
	}

	public void init() {
		setBackground(new Color(0, 0, 0));
		((GameSparker) this).offImage = createImage(800, 450);
		if (((GameSparker) this).offImage != null)
		((GameSparker) this).rd = (Graphics2D)((GameSparker) this).offImage.getGraphics();
		((GameSparker) this).rd.setRenderingHint((RenderingHints.KEY_TEXT_ANTIALIASING), (RenderingHints.VALUE_TEXT_ANTIALIAS_ON));
		((GameSparker) this).rd.setRenderingHint((RenderingHints.KEY_ANTIALIASING), (RenderingHints.VALUE_ANTIALIAS_ON));
		setLayout(null);
		((GameSparker) this).tnick = new TextField("Nickbname");
		((GameSparker) this).tnick.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).tpass = new TextField("");
		((GameSparker) this).tpass.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).tpass.setEchoCharacter('*');
		((GameSparker) this).temail = new TextField("");
		((GameSparker) this).temail.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).cmsg = new TextField("");
		if (System.getProperty("java.vendor").toLowerCase().indexOf("oracle") != -1)
		((GameSparker) this).cmsg.addKeyListener( /*TYPE_ERROR*/ new GameSparker$1(this));
		((GameSparker) this).mmsg = new TextArea("", 200, 20, 3);
		((GameSparker) this).cmsg.setFont(new Font("Tahoma", 0, 11));
		((GameSparker) this).mmsg.setFont(new Font("Tahoma", 0, 11));
		((GameSparker) this).mycar = new Checkbox("Sword of Justice Game!");
		((GameSparker) this).notp = new Checkbox("No Trees & Piles");
		((GameSparker) this).keplo = new Checkbox("Stay logged in");
		((GameSparker) this).keplo.setState(true);
		add(((GameSparker) this).tnick);
		add(((GameSparker) this).tpass);
		add(((GameSparker) this).temail);
		add(((GameSparker) this).cmsg);
		add(((GameSparker) this).mmsg);
		add(((GameSparker) this).mycar);
		add(((GameSparker) this).notp);
		add(((GameSparker) this).keplo);
		((GameSparker) this).sgame.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).wgame.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).warb.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).pgame.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).vnpls.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).vtyp.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).snfmm.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).snfm1.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).snfm2.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).mstgs.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).mcars.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).slaps.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).snpls.setFont(new Font("Arial", 0, 13));
		((GameSparker) this).snbts.setFont(new Font("Arial", 0, 13));
		((GameSparker) this).swait.setFont(new Font("Arial", 0, 12));
		((GameSparker) this).sclass.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).scars.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).sfix.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).mycar.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).notp.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).keplo.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).gmode.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).rooms.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).sendtyp.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).senditem.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).datat.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).clanlev.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).clcars.setFont(new Font("Arial", 1, 12));
		((Smenu)((GameSparker) this).clcars).alphad = true;
		((GameSparker) this).ilaps.setFont(new Font("Arial", 1, 13));
		((GameSparker) this).icars.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).proitem.setFont(new Font("Arial", 1, 12));
		((GameSparker) this).sgame.add(((GameSparker) this).rd, " NFM 1     ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd, " NFM 2     ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd, " My Stages ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd,
			" Weekly Top20 ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd,
			" Monthly Top20 ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd,
			" All Time Top20 ");
		((GameSparker) this).sgame.add(((GameSparker) this).rd,
			" Stage Maker ");
		((GameSparker) this).wgame.add(((GameSparker) this).rd,
			" Normal Game");
		((GameSparker) this).wgame.add(((GameSparker) this).rd,
			" War / Battle");
		((GameSparker) this).wgame.add(((GameSparker) this).rd,
			" War / Battle - Practice");
		((GameSparker) this).warb.add(((GameSparker) this).rd,
			" Loading your clan's wars and battles, please wait...");
		((GameSparker) this).pgame.add(((GameSparker) this).rd, " Select the game you want to practice");
		((GameSparker) this).vnpls.add(((GameSparker) this).rd, "Players");
		((GameSparker) this).vnpls.add(((GameSparker) this).rd, " 2 VS 2");
		((GameSparker) this).vnpls.add(((GameSparker) this).rd, " 3 VS 3");
		((GameSparker) this).vnpls.add(((GameSparker) this).rd, " 4 VS 4");
		((GameSparker) this).vtyp.add(((GameSparker) this).rd,
			"Normal clan game");
		((GameSparker) this).vtyp.add(((GameSparker) this).rd, "Racing only");
		((GameSparker) this).vtyp.add(((GameSparker) this).rd, "Wasting only");
		((GameSparker) this).vtyp.add(((GameSparker) this).rd,
			"Racers VS Wasters - my clan wastes");
		((GameSparker) this).vtyp.add(((GameSparker) this).rd,
			"Racers VS Wasters - my clan races");
		((GameSparker) this).snfmm.add(((GameSparker) this).rd,
			"Select Stage");
		((GameSparker) this).snfm1.add(((GameSparker) this).rd,
			"Select Stage");
		((GameSparker) this).snfm2.add(((GameSparker) this).rd,
			"Select Stage");
		((GameSparker) this).mstgs.add(((GameSparker) this).rd,
			"Suddenly the King becomes Santa's Little Helper");
		((GameSparker) this).mcars.add(((GameSparker) this).rd,
			"Sword of Justice");
		((GameSparker) this).snpls.add(((GameSparker) this).rd, "Select");
		((GameSparker) this).swait.add(((GameSparker) this).rd, "1 Minute");
		((GameSparker) this).ilaps.add(((GameSparker) this).rd, "Laps");
		((GameSparker) this).ilaps.add(((GameSparker) this).rd, "1 Lap");
		for (int i = 0; i < 5; i++)
		((GameSparker) this).snfmm.add(((GameSparker) this).rd,
		new StringBuilder().append(" Stage ").append(i + 1).append("").toString());
		for (int i = 0; i < 10; i++)
		((GameSparker) this).snfm1.add(((GameSparker) this).rd,
		new StringBuilder().append(" Stage ").append(i + 1).append("").toString());
		for (int i = 0; i < 17; i++)
		((GameSparker) this).snfm2.add(((GameSparker) this).rd,
		new StringBuilder().append(" Stage ").append(i + 1).append("").toString());
		for (int i = 0; i < 7; i++)
		((GameSparker) this).snpls.add(((GameSparker) this).rd,
		new StringBuilder().append("    ").append(i + 2).append("").toString());
		for (int i = 0; i < 7; i++)
		((GameSparker) this).snbts.add(((GameSparker) this).rd,
		new StringBuilder().append("    ").append(i).append("    ").toString());
		for (int i = 0; i < 2; i++)
		((GameSparker) this).swait.add(((GameSparker) this).rd,
		new StringBuilder().append("")
			.append(i + 2).append(" Minutes").toString());
		for (int i = 0; i < 15; i++)
		((GameSparker) this).slaps.add(((GameSparker) this).rd,
		new StringBuilder().append("")
			.append(i + 1).append("").toString());
		for (int i = 0; i < 14; i++)
		((GameSparker) this).ilaps.add(((GameSparker) this).rd,
		new StringBuilder().append("")
			.append(i + 2).append(" Laps").toString());
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"All Classes");
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"Class C Cars");
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"Class B & C Cars");
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"Class B Cars");
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"Class A & B Cars");
		((GameSparker) this).sclass.add(((GameSparker) this).rd,
			"Class A Cars");
		((GameSparker) this).scars.add(((GameSparker) this).rd, "All Cars");
		((GameSparker) this).scars.add(((GameSparker) this).rd, "Custom Cars");
		((GameSparker) this).scars.add(((GameSparker) this).rd, "Game Cars");
		((GameSparker) this).sfix.add(((GameSparker) this).rd,
			"Unlimited Fixing");
		((GameSparker) this).sfix.add(((GameSparker) this).rd, "4 Fixes");
		((GameSparker) this).sfix.add(((GameSparker) this).rd, "3 Fixes");
		((GameSparker) this).sfix.add(((GameSparker) this).rd, "2 Fixes");
		((GameSparker) this).sfix.add(((GameSparker) this).rd, "1 Fix");
		((GameSparker) this).sfix.add(((GameSparker) this).rd, "No Fixing");
		((GameSparker) this).icars.add(((GameSparker) this).rd,
			"Type of Cars");
		((GameSparker) this).icars.add(((GameSparker) this).rd, "All Cars");
		((GameSparker) this).icars.add(((GameSparker) this).rd, "Clan Cars");
		((GameSparker) this).icars.add(((GameSparker) this).rd, "Game Cars");
		((Smenu)((GameSparker) this).icars).w = 140;
		((GameSparker) this).gmode.add(((GameSparker) this).rd,
			" Normal Game ");
		((GameSparker) this).gmode.add(((GameSparker) this).rd,
			" Practice Game ");
		((Smenu)((GameSparker) this).rooms).rooms = true;
		((GameSparker) this).rooms.add(((GameSparker) this).rd,
			"Ghostrider :: 1");
		((GameSparker) this).sendtyp.add(((GameSparker) this).rd,
			"Write a Message");
		((GameSparker) this).sendtyp.add(((GameSparker) this).rd,
			"Share a Custom Car");
		((GameSparker) this).sendtyp.add(((GameSparker) this).rd,
			"Share a Custom Stage");
		((GameSparker) this).sendtyp.add(((GameSparker) this).rd,
			"Send a Clan Invitation");
		((GameSparker) this).sendtyp.add(((GameSparker) this).rd,
			"Share a Relative Date");
		((GameSparker) this).senditem.add(((GameSparker) this).rd,
			"Suddenly the King becomes Santa's Little Helper");
		for (int i = 0; i < 6; i++)
		((GameSparker) this).clanlev.add(((GameSparker) this).rd,
		new StringBuilder().append("")
			.append(i + 1).append("").toString());
		((GameSparker) this).clanlev.add(((GameSparker) this).rd, "7 - Admin");
		hidefields();
	}

	public void hidefields() {
		((GameSparker) this).ilaps.hide();
		((GameSparker) this).icars.hide();
		((GameSparker) this).proitem.hide();
		((GameSparker) this).clcars.hide();
		((GameSparker) this).clanlev.hide();
		((GameSparker) this).mmsg.hide();
		((GameSparker) this).datat.hide();
		((GameSparker) this).senditem.hide();
		((GameSparker) this).sendtyp.hide();
		((GameSparker) this).rooms.hide();
		((GameSparker) this).mcars.hide();
		((GameSparker) this).mstgs.hide();
		((GameSparker) this).gmode.hide();
		((GameSparker) this).sclass.hide();
		((GameSparker) this).scars.hide();
		((GameSparker) this).sfix.hide();
		((GameSparker) this).mycar.hide();
		((GameSparker) this).notp.hide();
		((GameSparker) this).keplo.hide();
		((GameSparker) this).tnick.hide();
		((GameSparker) this).tpass.hide();
		((GameSparker) this).temail.hide();
		((GameSparker) this).cmsg.hide();
		((GameSparker) this).sgame.hide();
		((GameSparker) this).wgame.hide();
		((GameSparker) this).pgame.hide();
		((GameSparker) this).vnpls.hide();
		((GameSparker) this).vtyp.hide();
		((GameSparker) this).warb.hide();
		((GameSparker) this).slaps.hide();
		((GameSparker) this).snfm1.hide();
		((GameSparker) this).snfmm.hide();
		((GameSparker) this).snfm2.hide();
		((GameSparker) this).snpls.hide();
		((GameSparker) this).snbts.hide();
		((GameSparker) this).swait.hide();
	}

	public void drawms() {
		((GameSparker) this).openm = false;
		if (((GameSparker) this).gmode.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).swait.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).slaps.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).snpls.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).snbts.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).scars.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).sgame.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).snfm1.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).snfm2.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).snfmm.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).mstgs.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).mcars.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).pgame.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).vnpls.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).vtyp.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).warb.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).wgame.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).rooms.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).sendtyp.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).senditem.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused,
		450, true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).datat.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).clanlev.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).clcars.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).ilaps.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).icars.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		true))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).proitem.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).sfix.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
		if (((GameSparker) this).sclass.draw(((GameSparker) this).rd, ((GameSparker) this).xm, ((GameSparker) this).ym, ((GameSparker) this).moused, 450,
		false))
		((GameSparker) this).openm = true;
	}

	public void movefield(Component component, int i, int i_99_, int i_100_,
	int i_101_) {
		if (i_100_ == 360 || i_100_ == 576) {
			i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx + ((float)(component.getWidth() / 2) * (((GameSparker) this).apmult - 1.0F)));
			i_99_ = (int)((float) i_99_ * ((GameSparker) this).apmult + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
		} else {
			i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx);
			i_99_ = (int)((float) i_99_ * ((GameSparker) this).apmult + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
		}
		if (component.getX() != i || component.getY() != i_99_) component.setBounds(i, i_99_, i_100_, i_101_);
	}

	public void movefieldd(TextField textfield, int i, int i_102_, int i_103_,
	int i_104_, boolean bool) {
		if (((GameSparker) this).applejava) {
			if (bool) {
				if ((((GameSparker) this).xm > i && ((GameSparker) this).xm < i + i_103_ && ((GameSparker) this).ym > i_102_ && ((GameSparker) this).ym < i_102_ + i_104_) || !textfield.getText().equals("")) {
					if (!textfield.isShowing()) {
						textfield.show();
						textfield.requestFocus();
					}
					if (i_103_ == 360 || i_103_ == 576) {
						i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx + ((float)(textfield.getWidth() / 2) * (((GameSparker) this).apmult - 1.0F)));
						i_102_ = (int)(((float) i_102_ * ((GameSparker) this).apmult) + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
					} else {
						i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx);
						i_102_ = (int)(((float) i_102_ * ((GameSparker) this).apmult) + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
					}
					if (textfield.getX() != i || textfield.getY() != i_102_) textfield.setBounds(i, i_102_, i_103_, i_104_);
				} else {
					if (textfield.isShowing()) {
						textfield.hide();
						requestFocus();
					}
					((GameSparker) this).rd.setColor(textfield.getBackground());
					((GameSparker) this).rd.fillRect(i, i_102_, i_103_ - 1,
					i_104_ - 1);
					((GameSparker) this).rd.setColor(textfield.getBackground().darker());
					((GameSparker) this).rd.drawRect(i, i_102_, i_103_ - 1,
					i_104_ - 1);
				}
			}
		} else {
			if (bool && !textfield.isShowing()) textfield.show();
			movefield(textfield, i, i_102_, i_103_, i_104_);
		}
	}

	public void movefielda(TextArea textarea, int i, int i_105_, int i_106_,
	int i_107_) {
		if (((GameSparker) this).applejava) {
			if ((((GameSparker) this).xm > i && ((GameSparker) this).xm < i + i_106_ && ((GameSparker) this).ym > i_105_ && ((GameSparker) this).ym < i_105_ + i_107_) || !textarea.getText().equals(" ")) {
				if (!textarea.isShowing()) {
					textarea.show();
					textarea.requestFocus();
				}
				if (i_106_ == 360 || i_106_ == 576) {
					i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx + ((float)(textarea.getWidth() / 2) * (((GameSparker) this).apmult - 1.0F)));
					i_105_ = (int)((float) i_105_ * ((GameSparker) this).apmult + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
				} else {
					i = (int)((float) i * ((GameSparker) this).apmult + (float)((GameSparker) this).apx);
					i_105_ = (int)((float) i_105_ * ((GameSparker) this).apmult + (float)((GameSparker) this).apy + 12.0F * (((GameSparker) this).apmult - 1.0F));
				}
				if (textarea.getX() != i || textarea.getY() != i_105_) textarea.setBounds(i, i_105_, i_106_, i_107_);
			} else {
				if (textarea.isShowing()) {
					textarea.hide();
					requestFocus();
				}
				((GameSparker) this).rd.setColor(textarea.getBackground());
				((GameSparker) this).rd.fillRect(i, i_105_, i_106_ - 1,
				i_107_ - 1);
				((GameSparker) this).rd.setColor(textarea.getBackground().darker());
				((GameSparker) this).rd.drawRect(i, i_105_, i_106_ - 1,
				i_107_ - 1);
			}
		} else {
			if (!textarea.isShowing()) textarea.show();
			movefield(textarea, i, i_105_, i_106_, i_107_);
		}
	}

	public void loadstage(ContO[] contos, ContO[] contos_108_, Medium medium,
	Trackers trackers, CheckPoints checkpoints,
	xtGraphics var_xtGraphics, Mad[] mads,
	Record record) {
		if (((xtGraphics) var_xtGraphics).testdrive == 2 || ((xtGraphics) var_xtGraphics).testdrive == 4)
		((xtGraphics) var_xtGraphics).nplayers = 1;
		if (((xtGraphics) var_xtGraphics).gmode == 1) {
			((xtGraphics) var_xtGraphics).nplayers = 5;
			((xtGraphics) var_xtGraphics).xstart[4] = 0;
			((xtGraphics) var_xtGraphics).zstart[4] = 760;
		}
		((Trackers) trackers).nt = 0;
		((GameSparker) this).nob = ((xtGraphics) var_xtGraphics).nplayers;
		((GameSparker) this).notb = 0;
		((CheckPoints) checkpoints).n = 0;
		((CheckPoints) checkpoints).nsp = 0;
		((CheckPoints) checkpoints).fn = 0;
		((CheckPoints) checkpoints).trackname = "";
		((CheckPoints) checkpoints).haltall = false;
		((CheckPoints) checkpoints).wasted = 0;
		((CheckPoints) checkpoints).catchfin = 0;
		((Medium) medium).resdown = 0;
		((Medium) medium).rescnt = 5;
		((Medium) medium).lightson = false;
		((Medium) medium).noelec = 0;
		((Medium) medium).ground = 250;
		((Medium) medium).trk = 0;
		((GameSparker) this).view = 0;
		int i = 0;
		int i_109_ = 100;
		int i_110_ = 0;
		int i_111_ = 100;
		((xtGraphics) var_xtGraphics).newparts = false;
		String string = "";
		try {
			Object object = null;
			DataInputStream datainputstream;
			if (((xtGraphics) var_xtGraphics).multion == 0 && ((CheckPoints) checkpoints).stage != -2) {
				String string_112_ = new StringBuilder().append("stages/").append(((CheckPoints) checkpoints).stage).append("").toString();
				if (((CheckPoints) checkpoints).stage == -1) string_112_ = new StringBuilder().append("mystages/").append(((CheckPoints) checkpoints).name).append("").toString();
				File file = new File(new StringBuilder().append("").append(Madness.fpath).append("").append(string_112_).append(".txt").toString());
				datainputstream = new DataInputStream(new FileInputStream(file));
			} else if (((CheckPoints) checkpoints).stage > 0) {
				URL url = (new URL(new StringBuilder().append("http://multiplayer.needformadness.com/stages/")
					.append(((CheckPoints) checkpoints).stage).append(".txt").toString()));
				datainputstream = new DataInputStream(url.openStream());
			} else {
				String string_113_ = new StringBuilder().append("http://multiplayer.needformadness.com/tracks/")
					.append(((CheckPoints) checkpoints).name).append(".radq").toString();
				string_113_ = string_113_.replace(' ', '_');
				URL url = new URL(string_113_);
				int i_114_ = url.openConnection().getContentLength();
				DataInputStream datainputstream_115_ = new DataInputStream(url.openStream());
				byte[] is = new byte[i_114_];
				datainputstream_115_.readFully(is);
				ZipInputStream zipinputstream;
				if (is[0] == 80 && is[1] == 75 && is[2] == 3) zipinputstream = new ZipInputStream(new ByteArrayInputStream(is));
				else {
					byte[] is_116_ = new byte[i_114_ - 40];
					for (int i_117_ = 0; i_117_ < i_114_ - 40; i_117_++) {
						int i_118_ = 20;
						if (i_117_ >= 500) i_118_ = 40;
						is_116_[i_117_] = is[i_117_ + i_118_];
					}
					zipinputstream = (new ZipInputStream(new ByteArrayInputStream(is_116_)));
				}
				ZipEntry zipentry = zipinputstream.getNextEntry();
				int i_119_ = Integer.valueOf(zipentry.getName()).intValue();
				byte[] is_120_ = new byte[i_119_];
				int i_121_ = 0;
				int i_122_;
				for ( /**/ ; i_119_ > 0; i_119_ -= i_122_) {
					i_122_ = zipinputstream.read(is_120_, i_121_, i_119_);
					i_121_ += i_122_;
				}
				zipinputstream.close();
				datainputstream_115_.close();
				datainputstream = new DataInputStream(new ByteArrayInputStream(is_120_));
			}
			String string_123_;
			while ((string_123_ = datainputstream.readLine()) != null) {
				string = new StringBuilder().append("").append(string_123_.trim()).toString();
				if (string.startsWith("snap")) medium.setsnap(getint("snap", string, 0),
				getint("snap", string, 1),
				getint("snap", string, 2));
				if (string.startsWith("sky")) {
					medium.setsky(getint("sky", string, 0),
					getint("sky", string, 1),
					getint("sky", string, 2));
					var_xtGraphics.snap(((CheckPoints) checkpoints).stage);
				}
				if (string.startsWith("ground")) medium.setgrnd(getint("ground", string, 0),
				getint("ground", string, 1),
				getint("ground", string, 2));
				if (string.startsWith("polys")) medium.setpolys(getint("polys", string, 0),
				getint("polys", string, 1),
				getint("polys", string, 2));
				if (string.startsWith("fog")) medium.setfade(getint("fog", string, 0),
				getint("fog", string, 1),
				getint("fog", string, 2));
				if (string.startsWith("texture")) medium.setexture(getint("texture", string, 0),
				getint("texture", string, 1),
				getint("texture", string, 2),
				getint("texture", string, 3));
				if (string.startsWith("clouds")) medium.setcloads(getint("clouds", string, 0),
				getint("clouds", string, 1),
				getint("clouds", string, 2),
				getint("clouds", string, 3),
				getint("clouds", string, 4));
				if (string.startsWith("density")) {
					((Medium) medium).fogd = (getint("density", string, 0) + 1) * 2 - 1;
					if (((Medium) medium).fogd < 1)
					((Medium) medium).fogd = 1;
					if (((Medium) medium).fogd > 30)
					((Medium) medium).fogd = 30;
				}
				if (string.startsWith("fadefrom")) medium.fadfrom(getint("fadefrom", string, 0));
				if (string.startsWith("lightson"))
				((Medium) medium).lightson = true;
				if (string.startsWith("mountains"))
				((Medium) medium).mgen = getint("mountains", string, 0);
				if (string.startsWith("set")) {
					int i_124_ = getint("set", string, 0);
					if (((xtGraphics) var_xtGraphics).nplayers == 8) {
						if (i_124_ == 47) i_124_ = 76;
						if (i_124_ == 48) i_124_ = 77;
					}
					boolean bool = true;
					if (i_124_ >= 65 && i_124_ <= 75 && ((CheckPoints) checkpoints).notb) bool = false;
					if (bool) {
						if (i_124_ == 49 || i_124_ == 64 || i_124_ >= 56 && i_124_ <= 61)
						((xtGraphics) var_xtGraphics).newparts = true;
						if ((((CheckPoints) checkpoints).stage < 0 || ((CheckPoints) checkpoints).stage >= 28) && i_124_ >= 10 && i_124_ <= 25)
						((Medium) medium).loadnew = true;
						i_124_ += 46;
						contos[((GameSparker) this).nob] = new ContO(contos_108_[i_124_],
						getint("set", string, 1), (((Medium) medium).ground - ((ContO) contos_108_[i_124_]).grat),
						getint("set", string, 2),
						getint("set", string, 3));
						if (string.indexOf(")p") != -1) {
							((CheckPoints) checkpoints).x[((CheckPoints) checkpoints).n] = getint("set", string, 1);
							((CheckPoints) checkpoints).z[((CheckPoints) checkpoints).n] = getint("set", string, 2);
							((CheckPoints) checkpoints).y[((CheckPoints) checkpoints).n] = 0;
							((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 0;
							if (string.indexOf(")pt") != -1)
							((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -1;
							if (string.indexOf(")pr") != -1)
							((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -2;
							if (string.indexOf(")po") != -1)
							((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -3;
							if (string.indexOf(")ph") != -1)
							((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -4;
							if (string.indexOf("out") != -1) System.out.println(new StringBuilder().append("out: ").append(((CheckPoints)
							checkpoints).n)
								.toString());
							((CheckPoints) checkpoints).n++;
							((GameSparker) this).notb = ((GameSparker) this).nob + 1;
						}
						((GameSparker) this).nob++;
						if (((Medium) medium).loadnew)
						((Medium) medium).loadnew = false;
					}
				}
				if (string.startsWith("chk")) {
					int i_125_ = getint("chk", string, 0);
					i_125_ += 46;
					int i_126_ = (((Medium) medium).ground - ((ContO) contos_108_[i_125_]).grat);
					if (i_125_ == 110) i_126_ = getint("chk", string, 4);
					contos[((GameSparker) this).nob] = new ContO(contos_108_[i_125_],
					getint("chk", string, 1), i_126_,
					getint("chk", string, 2),
					getint("chk", string, 3));
					((CheckPoints) checkpoints).x[(((CheckPoints) checkpoints)
						.n)] = getint("chk", string, 1);
					((CheckPoints) checkpoints).z[(((CheckPoints) checkpoints)
						.n)] = getint("chk", string, 2);
					((CheckPoints) checkpoints).y[(((CheckPoints) checkpoints)
						.n)] = i_126_;
					if (getint("chk", string, 3) == 0)
					((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 1;
					else((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 2;
					((CheckPoints) checkpoints).pcs = ((CheckPoints) checkpoints).n;
					((CheckPoints) checkpoints).n++;
					((ContO) contos[((GameSparker) this).nob]).checkpoint = ((CheckPoints) checkpoints).nsp + 1;
					((CheckPoints) checkpoints).nsp++;
					((GameSparker) this).nob++;
					((GameSparker) this).notb = ((GameSparker) this).nob;
				}
				if (((CheckPoints) checkpoints).nfix != 5 && string.startsWith("fix")) {
					int i_127_ = getint("fix", string, 0);
					i_127_ += 46;
					contos[((GameSparker) this).nob] = new ContO(contos_108_[i_127_],
					getint("fix", string, 1),
					getint("fix", string, 3),
					getint("fix", string, 2),
					getint("fix", string, 4));
					((CheckPoints) checkpoints).fx[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string, 1);
					((CheckPoints) checkpoints).fz[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string, 2);
					((CheckPoints) checkpoints).fy[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string, 3);
					((ContO) contos[((GameSparker) this).nob]).elec = true;
					if (getint("fix", string, 4) != 0) {
						((CheckPoints) checkpoints).roted[((CheckPoints) checkpoints).fn] = true;
						((ContO) contos[((GameSparker) this).nob]).roted = true;
					} else((CheckPoints) checkpoints).roted[((CheckPoints) checkpoints).fn] = false;
					if (string.indexOf(")s") != -1)
					((CheckPoints) checkpoints).special[((CheckPoints) checkpoints).fn] = true;
					else((CheckPoints) checkpoints).special[((CheckPoints) checkpoints).fn] = false;
					((CheckPoints) checkpoints).fn++;
					((GameSparker) this).nob++;
					((GameSparker) this).notb = ((GameSparker) this).nob;
				}
				if (!((CheckPoints) checkpoints).notb && string.startsWith("pile")) {
					contos[((GameSparker) this).nob] = new ContO(getint("pile", string, 0),
					getint("pile", string, 1),
					getint("pile", string, 2), medium,
					trackers, getint("pile", string, 3),
					getint("pile", string, 4), ((Medium) medium).ground);
					((GameSparker) this).nob++;
				}
				if (((xtGraphics) var_xtGraphics).multion == 0 && string.startsWith("nlaps")) {
					((CheckPoints) checkpoints).nlaps = getint("nlaps", string, 0);
					if (((CheckPoints) checkpoints).nlaps < 1)
					((CheckPoints) checkpoints).nlaps = 1;
					if (((CheckPoints) checkpoints).nlaps > 15)
					((CheckPoints) checkpoints).nlaps = 15;
				}
				if (((CheckPoints) checkpoints).stage > 0 && string.startsWith("name"))
				((CheckPoints) checkpoints).name = getstring("name", string, 0).replace('|', ',');
				if (string.startsWith("stagemaker"))
				((CheckPoints) checkpoints).maker = getstring("stagemaker", string, 0);
				if (string.startsWith("publish"))
				((CheckPoints) checkpoints).pubt = getint("publish", string, 0);
				if (string.startsWith("soundtrack")) {
					((CheckPoints) checkpoints).trackname = getstring("soundtrack", string, 0);
					((CheckPoints) checkpoints).trackvol = getint("soundtrack", string, 1);
					if (((CheckPoints) checkpoints).trackvol < 50)
					((CheckPoints) checkpoints).trackvol = 50;
					if (((CheckPoints) checkpoints).trackvol > 300)
					((CheckPoints) checkpoints).trackvol = 300;
					((xtGraphics) var_xtGraphics).sndsize[32] = getint("soundtrack", string, 2);
				}
				if (string.startsWith("maxr")) {
					int i_128_ = getint("maxr", string, 0);
					int i_129_ = getint("maxr", string, 1);
					i = i_129_;
					int i_130_ = getint("maxr", string, 2);
					for (int i_131_ = 0; i_131_ < i_128_; i_131_++) {
						contos[((GameSparker) this).nob] = new ContO(contos_108_[85], i_129_, (((Medium) medium).ground - ((ContO) contos_108_[85]).grat),
						i_131_ * 4800 + i_130_, 0);
						((GameSparker) this).nob++;
					}
					((Trackers) trackers).y[((Trackers) trackers).nt] = -5000;
					((Trackers) trackers).rady[((Trackers) trackers).nt] = 7100;
					((Trackers) trackers).x[((Trackers) trackers).nt] = i_129_ + 500;
					((Trackers) trackers).radx[((Trackers) trackers).nt] = 600;
					((Trackers) trackers).z[((Trackers) trackers).nt] = i_128_ * 4800 / 2 + i_130_ - 2400;
					((Trackers) trackers).radz[((Trackers) trackers).nt] = i_128_ * 4800 / 2;
					((Trackers) trackers).xy[((Trackers) trackers).nt] = 90;
					((Trackers) trackers).zy[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).dam[((Trackers) trackers).nt] = 167;
					((Trackers) trackers).decor[((Trackers) trackers).nt] = false;
					((Trackers) trackers).skd[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).nt++;
				}
				if (string.startsWith("maxl")) {
					int i_132_ = getint("maxl", string, 0);
					int i_133_ = getint("maxl", string, 1);
					i_109_ = i_133_;
					int i_134_ = getint("maxl", string, 2);
					for (int i_135_ = 0; i_135_ < i_132_; i_135_++) {
						contos[((GameSparker) this).nob] = new ContO(contos_108_[85], i_133_, (((Medium) medium).ground - ((ContO) contos_108_[85]).grat),
						i_135_ * 4800 + i_134_, 180);
						((GameSparker) this).nob++;
					}
					((Trackers) trackers).y[((Trackers) trackers).nt] = -5000;
					((Trackers) trackers).rady[((Trackers) trackers).nt] = 7100;
					((Trackers) trackers).x[((Trackers) trackers).nt] = i_133_ - 500;
					((Trackers) trackers).radx[((Trackers) trackers).nt] = 600;
					((Trackers) trackers).z[((Trackers) trackers).nt] = i_132_ * 4800 / 2 + i_134_ - 2400;
					((Trackers) trackers).radz[((Trackers) trackers).nt] = i_132_ * 4800 / 2;
					((Trackers) trackers).xy[((Trackers) trackers).nt] = -90;
					((Trackers) trackers).zy[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).dam[((Trackers) trackers).nt] = 167;
					((Trackers) trackers).decor[((Trackers) trackers).nt] = false;
					((Trackers) trackers).skd[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).nt++;
				}
				if (string.startsWith("maxt")) {
					int i_136_ = getint("maxt", string, 0);
					int i_137_ = getint("maxt", string, 1);
					i_110_ = i_137_;
					int i_138_ = getint("maxt", string, 2);
					for (int i_139_ = 0; i_139_ < i_136_; i_139_++) {
						contos[((GameSparker) this).nob] = new ContO(contos_108_[85],
						i_139_ * 4800 + i_138_, (((Medium) medium).ground - ((ContO) contos_108_[85]).grat),
						i_137_, 90);
						((GameSparker) this).nob++;
					}
					((Trackers) trackers).y[((Trackers) trackers).nt] = -5000;
					((Trackers) trackers).rady[((Trackers) trackers).nt] = 7100;
					((Trackers) trackers).z[((Trackers) trackers).nt] = i_137_ + 500;
					((Trackers) trackers).radz[((Trackers) trackers).nt] = 600;
					((Trackers) trackers).x[((Trackers) trackers).nt] = i_136_ * 4800 / 2 + i_138_ - 2400;
					((Trackers) trackers).radx[((Trackers) trackers).nt] = i_136_ * 4800 / 2;
					((Trackers) trackers).zy[((Trackers) trackers).nt] = 90;
					((Trackers) trackers).xy[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).dam[((Trackers) trackers).nt] = 167;
					((Trackers) trackers).decor[((Trackers) trackers).nt] = false;
					((Trackers) trackers).skd[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).nt++;
				}
				if (string.startsWith("maxb")) {
					int i_140_ = getint("maxb", string, 0);
					int i_141_ = getint("maxb", string, 1);
					i_111_ = i_141_;
					int i_142_ = getint("maxb", string, 2);
					for (int i_143_ = 0; i_143_ < i_140_; i_143_++) {
						contos[((GameSparker) this).nob] = new ContO(contos_108_[85],
						i_143_ * 4800 + i_142_, (((Medium) medium).ground - ((ContO) contos_108_[85]).grat),
						i_141_, -90);
						((GameSparker) this).nob++;
					}
					((Trackers) trackers).y[((Trackers) trackers).nt] = -5000;
					((Trackers) trackers).rady[((Trackers) trackers).nt] = 7100;
					((Trackers) trackers).z[((Trackers) trackers).nt] = i_141_ - 500;
					((Trackers) trackers).radz[((Trackers) trackers).nt] = 600;
					((Trackers) trackers).x[((Trackers) trackers).nt] = i_140_ * 4800 / 2 + i_142_ - 2400;
					((Trackers) trackers).radx[((Trackers) trackers).nt] = i_140_ * 4800 / 2;
					((Trackers) trackers).zy[((Trackers) trackers).nt] = -90;
					((Trackers) trackers).xy[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).dam[((Trackers) trackers).nt] = 167;
					((Trackers) trackers).decor[((Trackers) trackers).nt] = false;
					((Trackers) trackers).skd[((Trackers) trackers).nt] = 0;
					((Trackers) trackers).nt++;
				}
			}
			datainputstream.close();
			medium.newpolys(i_109_, i - i_109_, i_111_, i_110_ - i_111_,
			trackers, ((GameSparker) this).notb);
			medium.newclouds(i_109_, i, i_111_, i_110_);
			medium.newmountains(i_109_, i, i_111_, i_110_);
			medium.newstars();
			trackers.devidetrackers(i_109_, i - i_109_, i_111_,
			i_110_ - i_111_);
		} catch (Exception exception) {
			((CheckPoints) checkpoints).stage = -3;
			System.out.println(new StringBuilder().append("Error in stage ").append(((CheckPoints) checkpoints).stage)
				.toString());
			System.out.println(new StringBuilder().append("").append(exception).toString());
			System.out.println(new StringBuilder().append("At line: ").append(string).toString());
		}
		if (((CheckPoints) checkpoints).nsp < 2)
		((CheckPoints) checkpoints).stage = -3;
		if (((Medium) medium).nrw * ((Medium) medium).ncl >= 16000)
		((CheckPoints) checkpoints).stage = -3;
		if (((CheckPoints) checkpoints).stage != -3) {
			((CheckPoints) checkpoints).top20 = Math.abs(((CheckPoints) checkpoints).top20);
			if (((CheckPoints) checkpoints).stage == 26)
			((Medium) medium).lightn = 0;
			else((Medium) medium).lightn = -1;
			if (((CheckPoints) checkpoints).stage == 1 || ((CheckPoints) checkpoints).stage == 11)
			((Medium) medium).nochekflk = false;
			else((Medium) medium).nochekflk = true;
			for (int i_144_ = 0;
			i_144_ < ((xtGraphics) var_xtGraphics).nplayers; i_144_++)
			((GameSparker) this).u[i_144_].reset(checkpoints, (((xtGraphics)
			var_xtGraphics)
				.sc[i_144_]));
			var_xtGraphics.resetstat(((CheckPoints) checkpoints).stage);
			checkpoints.calprox();
			for (int i_145_ = 0;
			i_145_ < ((xtGraphics) var_xtGraphics).nplayers; i_145_++) {
				if (((xtGraphics) var_xtGraphics).fase == 22) var_xtGraphics.colorCar((contos_108_[(((xtGraphics) var_xtGraphics).sc[i_145_])]),
				i_145_);
				contos[i_145_] = new ContO((contos_108_[((xtGraphics) var_xtGraphics).sc[i_145_]]), ((xtGraphics) var_xtGraphics).xstart[i_145_],
				250 - ((ContO)(contos_108_[(((xtGraphics) var_xtGraphics)
					.sc[i_145_])])).grat, ((xtGraphics) var_xtGraphics).zstart[i_145_],
				0);
				mads[i_145_].reseto(((xtGraphics) var_xtGraphics).sc[i_145_],
				contos[i_145_], checkpoints);
			}
			if (((xtGraphics) var_xtGraphics).fase == 2 || ((xtGraphics) var_xtGraphics).fase == -22) {
				((Medium) medium).trx = (long)((i_109_ + i) / 2);
				((Medium) medium).trz = (long)((i_110_ + i_111_) / 2);
				((Medium) medium).ptr = 0;
				((Medium) medium).ptcnt = -10;
				((Medium) medium).hit = 45000;
				((Medium) medium).fallen = 0;
				((Medium) medium).nrnd = 0;
				((Medium) medium).trk = 1;
				((Medium) medium).ih = 25;
				((Medium) medium).iw = 65;
				((Medium) medium).h = 425;
				((Medium) medium).w = 735;
				((xtGraphics) var_xtGraphics).fase = 1;
				((GameSparker) this).mouses = 0;
			}
			if (((xtGraphics) var_xtGraphics).fase == 22) {
				((Medium) medium).crs = false;
				((xtGraphics) var_xtGraphics).fase = 5;
			}
			if (((CheckPoints) checkpoints).stage > 0) {
				int i_146_ = ((CheckPoints) checkpoints).stage;
				if (i_146_ > 27) i_146_ -= 27;
				else if (i_146_ > 10) i_146_ -= 10;
				((xtGraphics) var_xtGraphics).asay = new StringBuilder().append("Stage ").append(i_146_)
					.append(":  ").append(((CheckPoints) checkpoints).name).append(" ").toString();
			} else((xtGraphics) var_xtGraphics).asay = new StringBuilder().append("Custom Stage:  ").append(((CheckPoints) checkpoints).name).append(" ").toString();
			record.reset(contos);
		} else if (((xtGraphics) var_xtGraphics).fase == 2)
		((xtGraphics) var_xtGraphics).fase = 1;
		System.gc();
	}

	public boolean loadstagePreview(int i, String string, ContO[] contos,
	ContO[] contos_147_, Medium medium,
	CheckPoints checkpoints) {
		boolean bool = true;
		if (i < 100) {
			((CheckPoints) checkpoints).stage = i;
			if (((CheckPoints) checkpoints).stage < 0)
			((CheckPoints) checkpoints).name = string;
		} else {
			((CheckPoints) checkpoints).stage = -2;
			if (((GameSparker) this).sgame.getSelectedIndex() == 3 || ((GameSparker) this).sgame.getSelectedIndex() == 4)
			((CheckPoints) checkpoints).name = ((GameSparker) this).mstgs.getSelectedItem();
			else {
				int i_148_ = (((GameSparker) this).mstgs.getSelectedItem()
					.indexOf(" ") + 1);
				if (i_148_ > 0)
				((CheckPoints) checkpoints).name = ((GameSparker) this).mstgs.getSelectedItem()
					.substring(i_148_);
			}
		}
		((GameSparker) this).nob = 0;
		((CheckPoints) checkpoints).n = 0;
		((CheckPoints) checkpoints).nsp = 0;
		((CheckPoints) checkpoints).fn = 0;
		((CheckPoints) checkpoints).haltall = false;
		((CheckPoints) checkpoints).wasted = 0;
		((CheckPoints) checkpoints).catchfin = 0;
		((Medium) medium).ground = 250;
		((GameSparker) this).view = 0;
		((Medium) medium).trx = 0L;
		((Medium) medium).trz = 0L;
		int i_149_ = 0;
		int i_150_ = 100;
		int i_151_ = 0;
		int i_152_ = 100;
		String string_153_ = "";
		try {
			Object object = null;
			DataInputStream datainputstream;
			if (((CheckPoints) checkpoints).stage > 0) {
				URL url = (new URL(new StringBuilder().append("http://multiplayer.needformadness.com/stages/")
					.append(((CheckPoints) checkpoints).stage).append(".txt").toString()));
				datainputstream = new DataInputStream(url.openStream());
			} else {
				String string_154_ = new StringBuilder().append("http://multiplayer.needformadness.com/tracks/")
					.append(((CheckPoints) checkpoints).name).append(".radq").toString();
				string_154_ = string_154_.replace(' ', '_');
				URL url = new URL(string_154_);
				int i_155_ = url.openConnection().getContentLength();
				DataInputStream datainputstream_156_ = new DataInputStream(url.openStream());
				byte[] is = new byte[i_155_];
				datainputstream_156_.readFully(is);
				ZipInputStream zipinputstream;
				if (is[0] == 80 && is[1] == 75 && is[2] == 3) zipinputstream = new ZipInputStream(new ByteArrayInputStream(is));
				else {
					byte[] is_157_ = new byte[i_155_ - 40];
					for (int i_158_ = 0; i_158_ < i_155_ - 40; i_158_++) {
						int i_159_ = 20;
						if (i_158_ >= 500) i_159_ = 40;
						is_157_[i_158_] = is[i_158_ + i_159_];
					}
					zipinputstream = (new ZipInputStream(new ByteArrayInputStream(is_157_)));
				}
				ZipEntry zipentry = zipinputstream.getNextEntry();
				int i_160_ = Integer.valueOf(zipentry.getName()).intValue();
				byte[] is_161_ = new byte[i_160_];
				int i_162_ = 0;
				int i_163_;
				for ( /**/ ; i_160_ > 0; i_160_ -= i_163_) {
					i_163_ = zipinputstream.read(is_161_, i_162_, i_160_);
					i_162_ += i_163_;
				}
				zipinputstream.close();
				datainputstream_156_.close();
				datainputstream = new DataInputStream(new ByteArrayInputStream(is_161_));
			}
			String string_164_;
			while ((string_164_ = datainputstream.readLine()) != null) {
				string_153_ = new StringBuilder().append("").append(string_164_.trim()).toString();
				if (string_153_.startsWith("snap")) medium.setsnap(getint("snap", string_153_, 0),
				getint("snap", string_153_, 1),
				getint("snap", string_153_, 2));
				if (string_153_.startsWith("sky")) medium.setsky(getint("sky", string_153_, 0),
				getint("sky", string_153_, 1),
				getint("sky", string_153_, 2));
				if (string_153_.startsWith("ground")) medium.setgrnd(getint("ground", string_153_, 0),
				getint("ground", string_153_, 1),
				getint("ground", string_153_, 2));
				if (string_153_.startsWith("polys")) medium.setpolys(getint("polys", string_153_, 0),
				getint("polys", string_153_, 1),
				getint("polys", string_153_, 2));
				if (string_153_.startsWith("fog")) medium.setfade(getint("fog", string_153_, 0),
				getint("fog", string_153_, 1),
				getint("fog", string_153_, 2));
				if (string_153_.startsWith("texture")) medium.setexture(getint("texture", string_153_, 0),
				getint("texture", string_153_, 1),
				getint("texture", string_153_, 2),
				getint("texture", string_153_, 3));
				if (string_153_.startsWith("clouds")) medium.setcloads(getint("clouds", string_153_, 0),
				getint("clouds", string_153_, 1),
				getint("clouds", string_153_, 2),
				getint("clouds", string_153_, 3),
				getint("clouds", string_153_, 4));
				if (string_153_.startsWith("density")) {
					((Medium) medium).fogd = (getint("density", string_153_, 0) + 1) * 2 - 1;
					if (((Medium) medium).fogd < 1)
					((Medium) medium).fogd = 1;
					if (((Medium) medium).fogd > 30)
					((Medium) medium).fogd = 30;
				}
				if (string_153_.startsWith("fadefrom")) medium.fadfrom(getint("fadefrom", string_153_, 0));
				if (string_153_.startsWith("lightson"))
				((Medium) medium).lightson = true;
				if (string_153_.startsWith("mountains"))
				((Medium) medium).mgen = getint("mountains", string_153_, 0);
				if (string_153_.startsWith("soundtrack")) {
					((CheckPoints) checkpoints).trackname = getstring("soundtrack", string_153_, 0);
					((CheckPoints) checkpoints).trackvol = getint("soundtrack", string_153_, 1);
					if (((CheckPoints) checkpoints).trackvol < 50)
					((CheckPoints) checkpoints).trackvol = 50;
					if (((CheckPoints) checkpoints).trackvol > 300)
					((CheckPoints) checkpoints).trackvol = 300;
				}
				if (string_153_.startsWith("set")) {
					int i_165_ = getint("set", string_153_, 0);
					i_165_ += 46;
					contos[((GameSparker) this).nob] = new ContO(contos_147_[i_165_],
					getint("set", string_153_, 1), (((Medium) medium).ground - ((ContO) contos_147_[i_165_]).grat),
					getint("set", string_153_, 2),
					getint("set", string_153_, 3));
					((Trackers)((ContO) contos[((GameSparker) this).nob]).t)
						.nt = 0;
					if (string_153_.indexOf(")p") != -1) {
						((CheckPoints) checkpoints).x[((CheckPoints) checkpoints).n] = getint("chk", string_153_, 1);
						((CheckPoints) checkpoints).z[((CheckPoints) checkpoints).n] = getint("chk", string_153_, 2);
						((CheckPoints) checkpoints).y[((CheckPoints) checkpoints).n] = 0;
						((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 0;
						if (string_153_.indexOf(")pt") != -1)
						((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -1;
						if (string_153_.indexOf(")pr") != -1)
						((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -2;
						if (string_153_.indexOf(")po") != -1)
						((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -3;
						if (string_153_.indexOf(")ph") != -1)
						((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = -4;
						if (string_153_.indexOf("out") != -1) System.out.println(new StringBuilder().append("out: ").append(((CheckPoints) checkpoints)
							.n)
							.toString());
						((CheckPoints) checkpoints).n++;
					}
					((GameSparker) this).nob++;
				}
				if (string_153_.startsWith("chk")) {
					int i_166_ = getint("chk", string_153_, 0);
					i_166_ += 46;
					int i_167_ = (((Medium) medium).ground - ((ContO) contos_147_[i_166_]).grat);
					if (i_166_ == 110) i_167_ = getint("chk", string_153_, 4);
					contos[((GameSparker) this).nob] = new ContO(contos_147_[i_166_],
					getint("chk", string_153_, 1), i_167_,
					getint("chk", string_153_, 2),
					getint("chk", string_153_, 3));
					((CheckPoints) checkpoints).x[(((CheckPoints) checkpoints)
						.n)] = getint("chk", string_153_, 1);
					((CheckPoints) checkpoints).z[(((CheckPoints) checkpoints)
						.n)] = getint("chk", string_153_, 2);
					((CheckPoints) checkpoints).y[(((CheckPoints) checkpoints)
						.n)] = i_167_;
					if (getint("chk", string_153_, 3) == 0)
					((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 1;
					else((CheckPoints) checkpoints).typ[((CheckPoints) checkpoints).n] = 2;
					((CheckPoints) checkpoints).pcs = ((CheckPoints) checkpoints).n;
					((CheckPoints) checkpoints).n++;
					((ContO) contos[((GameSparker) this).nob]).checkpoint = ((CheckPoints) checkpoints).nsp + 1;
					((CheckPoints) checkpoints).nsp++;
					((GameSparker) this).nob++;
				}
				if (string_153_.startsWith("fix")) {
					int i_168_ = getint("fix", string_153_, 0);
					i_168_ += 46;
					contos[((GameSparker) this).nob] = new ContO(contos_147_[i_168_],
					getint("fix", string_153_, 1),
					getint("fix", string_153_, 3),
					getint("fix", string_153_, 2),
					getint("fix", string_153_, 4));
					((CheckPoints) checkpoints).fx[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string_153_, 1);
					((CheckPoints) checkpoints).fz[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string_153_, 2);
					((CheckPoints) checkpoints).fy[(((CheckPoints) checkpoints)
						.fn)] = getint("fix", string_153_, 3);
					((ContO) contos[((GameSparker) this).nob]).elec = true;
					if (getint("fix", string_153_, 4) != 0) {
						((CheckPoints) checkpoints).roted[((CheckPoints) checkpoints).fn] = true;
						((ContO) contos[((GameSparker) this).nob]).roted = true;
					} else((CheckPoints) checkpoints).roted[((CheckPoints) checkpoints).fn] = false;
					if (string_153_.indexOf(")s") != -1)
					((CheckPoints) checkpoints).special[((CheckPoints) checkpoints).fn] = true;
					else((CheckPoints) checkpoints).special[((CheckPoints) checkpoints).fn] = false;
					((CheckPoints) checkpoints).fn++;
					((GameSparker) this).nob++;
				}
				if (string_153_.startsWith("nlaps")) {
					((CheckPoints) checkpoints).nlaps = getint("nlaps", string_153_, 0);
					if (((CheckPoints) checkpoints).nlaps < 1)
					((CheckPoints) checkpoints).nlaps = 1;
					if (((CheckPoints) checkpoints).nlaps > 15)
					((CheckPoints) checkpoints).nlaps = 15;
				}
				if (((CheckPoints) checkpoints).stage > 0 && string_153_.startsWith("name"))
				((CheckPoints) checkpoints).name = getstring("name", string_153_, 0).replace('|', ',');
				if (string_153_.startsWith("stagemaker"))
				((CheckPoints) checkpoints).maker = getstring("stagemaker", string_153_, 0);
				if (string_153_.startsWith("publish"))
				((CheckPoints) checkpoints).pubt = getint("publish", string_153_, 0);
				if (string_153_.startsWith("maxr")) {
					int i_169_ = getint("maxr", string_153_, 1);
					i_149_ = i_169_;
				}
				if (string_153_.startsWith("maxl")) {
					int i_170_ = getint("maxl", string_153_, 1);
					i_150_ = i_170_;
				}
				if (string_153_.startsWith("maxt")) {
					int i_171_ = getint("maxt", string_153_, 1);
					i_151_ = i_171_;
				}
				if (string_153_.startsWith("maxb")) {
					int i_172_ = getint("maxb", string_153_, 1);
					i_152_ = i_172_;
				}
			}
			datainputstream.close();
			medium.newpolys(i_150_, i_149_ - i_150_, i_152_, i_151_ - i_152_,
			null, ((GameSparker) this).notb);
			medium.newclouds(i_150_, i_149_, i_152_, i_151_);
			medium.newmountains(i_150_, i_149_, i_152_, i_151_);
			medium.newstars();
		} catch (Exception exception) {
			bool = false;
			System.out.println(new StringBuilder().append("Error in stage ").append(((CheckPoints) checkpoints).stage)
				.toString());
			System.out.println(new StringBuilder().append("").append(exception).toString());
			System.out.println(new StringBuilder().append("At line: ").append(string_153_).toString());
		}
		if (((CheckPoints) checkpoints).nsp < 2) bool = false;
		if (((Medium) medium).nrw * ((Medium) medium).ncl >= 16000) bool = false;
		((Medium) medium).trx = (long)((i_150_ + i_149_) / 2);
		((Medium) medium).trz = (long)((i_151_ + i_152_) / 2);
		System.gc();
		return bool;
	}

	public void loadbase(ContO[] contos, Medium medium, Trackers trackers,
	xtGraphics var_xtGraphics, boolean bool) {
		String[] strings = {
			"2000tornados", "formula7", "canyenaro", "lescrab", "nimi",
				"maxrevenge", "leadoxide", "koolkat", "drifter", "policecops",
				"mustang", "king", "audir8", "masheen", "radicalone",
				"drmonster"
		};
		String[] strings_173_ = {
			"road", "froad", "twister2", "twister1", "turn", "offroad",
				"bumproad", "offturn", "nroad", "nturn", "roblend", "noblend",
				"rnblend", "roadend", "offroadend", "hpground", "ramp30",
				"cramp35", "dramp15", "dhilo15", "slide10", "takeoff",
				"sramp22", "offbump", "offramp", "sofframp", "halfpipe",
				"spikes", "rail", "thewall", "checkpoint", "fixpoint",
				"offcheckpoint", "sideoff", "bsideoff", "uprise", "riseroad",
				"sroad", "soffroad", "tside", "launchpad", "thenet",
				"speedramp", "offhill", "slider", "uphill", "roll1", "roll2",
				"roll3", "roll4", "roll5", "roll6", "opile1", "opile2",
				"aircheckpoint", "tree1", "tree2", "tree3", "tree4", "tree5",
				"tree6", "tree7", "tree8", "cac1", "cac2", "cac3", "8sroad",
				"8soffroad"
		};
		int i = 0;
		((xtGraphics) var_xtGraphics).dnload += 6;
		try {
			Object object = null;
			ZipInputStream zipinputstream;
			if (!bool) {
				File file = new File(new StringBuilder().append("").append(Madness.fpath).append("data/models.zip").toString());
				zipinputstream = new ZipInputStream(new FileInputStream(file));
			} else {
				URL url = (new URL("http://multiplayer.needformadness.com/data/models.zip"));
				zipinputstream = new ZipInputStream(url.openStream());
			}
			ZipEntry zipentry = zipinputstream.getNextEntry();
			Object object_174_ = null;
			for ( /**/ ; zipentry != null;
			zipentry = zipinputstream.getNextEntry()) {
				int i_175_ = 0;
				for (int i_176_ = 0; i_176_ < 16; i_176_++) {
					if (zipentry.getName().startsWith(strings[i_176_])) i_175_ = i_176_;
				}
				for (int i_177_ = 0; i_177_ < 68; i_177_++) {
					if (zipentry.getName().startsWith(strings_173_[i_177_])) i_175_ = i_177_ + 56;
				}
				int i_178_ = (int) zipentry.getSize();
				i += i_178_;
				byte[] is = new byte[i_178_];
				int i_179_ = 0;
				int i_180_;
				for ( /**/ ; i_178_ > 0; i_178_ -= i_180_) {
					i_180_ = zipinputstream.read(is, i_179_, i_178_);
					i_179_ += i_180_;
				}
				contos[i_175_] = new ContO(is, medium, trackers);
				((xtGraphics) var_xtGraphics).dnload++;
			}
			zipinputstream.close();
		} catch (Exception exception) {
			System.out.println(new StringBuilder().append("Error Reading Models: ").append(exception).toString());
		}
		System.gc();
		if (((GameSparker) this).mload != -1 && i != 615671)
		((GameSparker) this).mload = 2;
	}

	public int getint(String string, String string_181_, int i) {
		int i_182_ = 0;
		String string_183_ = "";
		for (int i_184_ = string.length() + 1; i_184_ < string_181_.length();
		i_184_++) {
			String string_185_ = new StringBuilder().append("").append(string_181_.charAt(i_184_)).toString();
			if (string_185_.equals(",") || string_185_.equals(")")) {
				i_182_++;
				i_184_++;
			}
			if (i_182_ == i) string_183_ = new StringBuilder().append(string_183_).append(string_181_.charAt(i_184_)).toString();
		}
		return Integer.valueOf(string_183_).intValue();
	}

	public String getstring(String string, String string_186_, int i) {
		int i_187_ = 0;
		String string_188_ = "";
		for (int i_189_ = string.length() + 1; i_189_ < string_186_.length();
		i_189_++) {
			String string_190_ = new StringBuilder().append("").append(string_186_.charAt(i_189_)).toString();
			if (string_190_.equals(",") || string_190_.equals(")")) {
				i_187_++;
				i_189_++;
			}
			if (i_187_ == i) string_188_ = new StringBuilder().append(string_188_).append(string_186_.charAt(i_189_)).toString();
		}
		return string_188_;
	}

	public void start() {
		if (((GameSparker) this).gamer == null)
		((GameSparker) this).gamer = new Thread(this);
		((GameSparker) this).gamer.start();
	}

	public void stop() {
		if (((GameSparker) this).exwist && ((GameSparker) this).gamer != null) {
			System.gc();
			((GameSparker) this).gamer.stop();
			((GameSparker) this).gamer = null;
		}
		((GameSparker) this).exwist = true;
	}

	public void setcarcookie(int i, String string, float[] fs, int i_191_,
	int[] is, boolean bool) {
		try {
			File file = new File(new StringBuilder().append("").append(Madness.fpath).append("data/user.data").toString());
			String[] strings = {
				"", "", "", "", ""
			};
			if (file.exists()) {
				BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
				Object object = null;
				String string_192_;
				for (int i_193_ = 0;
				((string_192_ = bufferedreader.readLine()) != null && i_193_ < 5);
				i_193_++)
				strings[i_193_] = string_192_;
				bufferedreader.close();
				Object object_194_ = null;
			}
			if (i_191_ == 0) strings[1] = new StringBuilder().append("lastcar(").append(i).append(",").append((int)(fs[0] * 100.0F)).append(",").append((int)(fs[1] * 100.0F)).append(",").append((int)(fs[2] * 100.0F)).append(",").append((int)(fs[3] * 100.0F)).append(",").append((int)(fs[4] * 100.0F)).append(",").append((int)(fs[5] * 100.0F)).append(",").append(string).append(")").toString();
			if (i_191_ == 1) strings[2] = new StringBuilder().append("NFM1(").append(i).append(",").append(is[0]).append(")").toString();
			if (i_191_ == 2) strings[3] = new StringBuilder().append("NFM2(").append(i).append(",").append(is[1]).append(")").toString();
			strings[4] = new StringBuilder().append("graphics(").append(((GameSparker) this).moto).append(",").append(Madness.anti).append(")").toString();
			BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
			for (int i_195_ = 0; i_195_ < 5; i_195_++) {
				bufferedwriter.write(strings[i_195_]);
				bufferedwriter.newLine();
			}
			bufferedwriter.close();
			Object object = null;
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void setloggedcookie() {
		try {
			File file = new File(new StringBuilder().append("").append(Madness.fpath).append("data/user.data").toString());
			String[] strings = {
				"", "", "", "", ""
			};
			if (file.exists()) {
				BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
				Object object = null;
				String string;
				for (int i = 0;
				(string = bufferedreader.readLine()) != null && i < 5;
				i++)
				strings[i] = string;
				bufferedreader.close();
				Object object_196_ = null;
			}
			if (((GameSparker) this).keplo.getState()) strings[0] = new StringBuilder().append("lastuser(").append(((GameSparker) this).tnick.getText()).append(",").append(((GameSparker) this).tpass.getText()).append(")").toString();
			else strings[0] = new StringBuilder().append("lastuser(").append(((GameSparker) this).tnick.getText()).append(")").toString();
			BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < 5; i++) {
				bufferedwriter.write(strings[i]);
				bufferedwriter.newLine();
			}
			bufferedwriter.close();
			Object object = null;
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void readcookies(xtGraphics var_xtGraphics, CarDefine cardefine,
	ContO[] contos) {
		((xtGraphics) var_xtGraphics).nickname = "";
		try {
			File file = new File(new StringBuilder().append("").append(Madness.fpath).append("data/user.data").toString());
			String[] strings = {
				"", "", "", "", ""
			};
			if (file.exists()) {
				BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
				Object object = null;
				String string;
				for (int i = 0;
				(string = bufferedreader.readLine()) != null && i < 5;
				i++)
				strings[i] = string;
				bufferedreader.close();
				Object object_197_ = null;
			}
			if (strings[0].startsWith("lastuser")) {
				((xtGraphics) var_xtGraphics).nickname = getstring("lastuser", strings[0], 0);
				if (!((xtGraphics) var_xtGraphics).nickname.equals(""))
				((xtGraphics) var_xtGraphics).opselect = 1;
				String string = "";
				try {
					string = getstring("lastuser", strings[0], 1);
				} catch (Exception exception) {
					string = "";
				}
				if (!string.equals("")) {
					((GameSparker) this).tnick.setText(((xtGraphics) var_xtGraphics).nickname);
					((GameSparker) this).tpass.setText(string);
					((xtGraphics) var_xtGraphics).autolog = true;
				}
			}
			if (strings[2].startsWith("NFM1")) {
				int i = getint("NFM1", strings[2], 0);
				if (i >= 0 && i < 16) {
					((xtGraphics) var_xtGraphics).scm[0] = i;
					((xtGraphics) var_xtGraphics).firstime = false;
				}
				i = getint("NFM1", strings[2], 1);
				if (i >= 1 && i <= 11)
				((xtGraphics) var_xtGraphics).unlocked[0] = i;
			}
			if (strings[3].startsWith("NFM2")) {
				int i = getint("NFM2", strings[3], 0);
				if (i >= 0 && i < 16) {
					((xtGraphics) var_xtGraphics).scm[1] = i;
					((xtGraphics) var_xtGraphics).firstime = false;
				}
				i = getint("NFM2", strings[3], 1);
				if (i >= 1 && i <= 17)
				((xtGraphics) var_xtGraphics).unlocked[1] = i;
			}
			if (strings[4].startsWith("graphics")) {
				int i = getint("graphics", strings[4], 0);
				if (i >= 0 && i <= 1)
				((GameSparker) this).moto = i;
				i = getint("graphics", strings[4], 1);
				if (i >= 0 && i <= 1) Madness.anti = i;
			}
			if (strings[1].startsWith("lastcar")) {
				int i = getint("lastcar", strings[1], 0);
				((CarDefine) cardefine).lastcar = getstring("lastcar", strings[1], 7);
				if (i >= 0 && i < 36) {
					((xtGraphics) var_xtGraphics).osc = i;
					((xtGraphics) var_xtGraphics).firstime = false;
				}
				int i_198_ = 0;
				for (int i_199_ = 0; i_199_ < 6; i_199_++) {
					i = getint("lastcar", strings[1], i_199_ + 1);
					if (i >= 0 && i <= 100) {
						((xtGraphics) var_xtGraphics).arnp[i_199_] = (float) i / 100.0F;
						i_198_++;
					}
				}
				if (i_198_ == 6 && ((xtGraphics) var_xtGraphics).osc >= 0 && ((xtGraphics) var_xtGraphics).osc <= 15) {
					Color color = (Color.getHSBColor(((xtGraphics) var_xtGraphics).arnp[0], ((xtGraphics) var_xtGraphics).arnp[1],
					1.0F - ((xtGraphics) var_xtGraphics).arnp[2]));
					Color color_200_ = (Color.getHSBColor(((xtGraphics) var_xtGraphics).arnp[3], ((xtGraphics) var_xtGraphics).arnp[4],
					1.0F - ((xtGraphics) var_xtGraphics).arnp[5]));
					for (int i_201_ = 0;
					(i_201_ < ((ContO)
					contos[((xtGraphics) var_xtGraphics).osc]).npl);
					i_201_++) {
						if (((Plane)
						((ContO) contos[(((xtGraphics) var_xtGraphics)
							.osc)]).p[i_201_]).colnum == 1) {
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_201_]).c[0] = color.getRed();
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_201_]).c[1] = color.getGreen();
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_201_]).c[2] = color.getBlue();
						}
					}
					for (int i_202_ = 0;
					(i_202_ < ((ContO)
					contos[((xtGraphics) var_xtGraphics).osc]).npl);
					i_202_++) {
						if (((Plane)
						((ContO) contos[(((xtGraphics) var_xtGraphics)
							.osc)]).p[i_202_]).colnum == 2) {
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_202_]).c[0] = color_200_.getRed();
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_202_]).c[1] = color_200_.getGreen();
							((Plane)
							((ContO) contos[(((xtGraphics) var_xtGraphics)
								.osc)]).p[i_202_]).c[2] = color_200_.getBlue();
						}
					}
				}
			}
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void regprom() {
		/* empty */
	}

	public boolean mouseUp(Event event, int i, int i_203_) {
		if (!((GameSparker) this).exwist) {
			if (((GameSparker) this).mouses == 11) {
				((GameSparker) this).xm = (int)((float)(i - ((GameSparker) this).apx) / ((GameSparker) this).apmult);
				((GameSparker) this).ym = (int)((float)(i_203_ - ((GameSparker) this).apy) / ((GameSparker) this).apmult);
				((GameSparker) this).mouses = -1;
			}
			((GameSparker) this).moused = false;
		}
		if (!Madness.fullscreen) {
			if (i > getWidth() / 2 - 55 && i < getWidth() / 2 + 7 && i_203_ > 21 && i_203_ < 38 && !((GameSparker) this).onbar) {
				if (((GameSparker) this).smooth == 1)
				((GameSparker) this).smooth = 0;
				else((GameSparker) this).smooth = 1;
				((GameSparker) this).showsize = 60;
			}
			if (i > getWidth() / 2 + 133 && i < getWidth() / 2 + 231 && i_203_ > 7 && i_203_ < 24 && !((GameSparker) this).onbar) {
				if (Madness.anti == 0) Madness.anti = 1;
				else Madness.anti = 0;
				((GameSparker) this).showsize = 60;
			}
			if (i > getWidth() / 2 + 133 && i < getWidth() / 2 + 231 && i_203_ > 24 && i_203_ < 41 && !((GameSparker) this).onbar) {
				if (((GameSparker) this).moto == 0)
				((GameSparker) this).moto = 1;
				else((GameSparker) this).moto = 0;
				((GameSparker) this).showsize = 60;
			}
			if (((GameSparker) this).oncarm) Madness.carmaker();
			if (((GameSparker) this).onstgm) Madness.stagemaker();
			if (((GameSparker) this).onfulls) Madness.gofullscreen();
			((GameSparker) this).onbar = false;
		}
		return false;
	}

	public boolean mouseDown(Event event, int i, int i_204_) {
		requestFocus();
		if (!((GameSparker) this).exwist) {
			if (((GameSparker) this).mouses == 0) {
				((GameSparker) this).xm = (int)((float)(i - ((GameSparker) this).apx) / ((GameSparker) this).apmult);
				((GameSparker) this).ym = (int)((float)(i_204_ - ((GameSparker) this).apy) / ((GameSparker) this).apmult);
				((GameSparker) this).mouses = 1;
			}
			((GameSparker) this).moused = true;
		}
		if (!Madness.fullscreen) sizescreen(i, i_204_);
		return false;
	}

	public boolean mouseMove(Event event, int i, int i_205_) {
		if (!((GameSparker) this).exwist && !((GameSparker) this).lostfcs) {
			((GameSparker) this).xm = (int)((float)(i - ((GameSparker) this).apx) / ((GameSparker) this).apmult);
			((GameSparker) this).ym = (int)((float)(i_205_ - ((GameSparker) this).apy) / ((GameSparker) this).apmult);
		}
		if (!Madness.fullscreen) {
			if (((GameSparker) this).showsize < 20)
			((GameSparker) this).showsize = 20;
			if (i > 50 && i < 192 && i_205_ > 14 && i_205_ < 37) {
				if (!((GameSparker) this).oncarm) {
					((GameSparker) this).oncarm = true;
					setCursor(new Cursor(12));
				}
			} else if (((GameSparker) this).oncarm) {
				((GameSparker) this).oncarm = false;
				setCursor(new Cursor(0));
			}
			if (i > getWidth() - 208 && i < getWidth() - 50 && i_205_ > 14 && i_205_ < 37) {
				if (!((GameSparker) this).onstgm) {
					((GameSparker) this).onstgm = true;
					setCursor(new Cursor(12));
				}
			} else if (((GameSparker) this).onstgm) {
				((GameSparker) this).onstgm = false;
				setCursor(new Cursor(0));
			}
			if (i > getWidth() / 2 + 22 && i < getWidth() / 2 + 122 && i_205_ > 14 && i_205_ < 37) {
				if (!((GameSparker) this).onfulls) {
					((GameSparker) this).onfulls = true;
					setCursor(new Cursor(12));
				}
			} else if (((GameSparker) this).onfulls) {
				((GameSparker) this).onfulls = false;
				setCursor(new Cursor(0));
			}
		}
		return false;
	}

	public boolean mouseDrag(Event event, int i, int i_206_) {
		if (!((GameSparker) this).exwist && !((GameSparker) this).lostfcs) {
			((GameSparker) this).xm = (int)((float)(i - ((GameSparker) this).apx) / ((GameSparker) this).apmult);
			((GameSparker) this).ym = (int)((float)(i_206_ - ((GameSparker) this).apy) / ((GameSparker) this).apmult);
		}
		if (!Madness.fullscreen) sizescreen(i, i_206_);
		return false;
	}

	public boolean lostFocus(Event event, Object object) {
		if (!((GameSparker) this).exwist && !((GameSparker) this).lostfcs) {
			((GameSparker) this).lostfcs = true;
			((GameSparker) this).fcscnt = 10;
			if (((GameSparker) this).u[0] != null) {
				if (((Control)((GameSparker) this).u[0]).multion == 0)
				((GameSparker) this).u[0].falseo(1);
				else if (((Control)((GameSparker) this).u[0]).chatup == 0) requestFocus();
				setCursor(new Cursor(0));
			}
		}
		return false;
	}

	public boolean gotFocus(Event event, Object object) {
		if (!((GameSparker) this).exwist && ((GameSparker) this).lostfcs)
		((GameSparker) this).lostfcs = false;
		return false;
	}

	public void mouseW(int i) {
		if (!((GameSparker) this).exwist)
		((GameSparker) this).mousew += i * 4;
	}

	public void sizescreen(int i, int i_207_) {
		if ((i > getWidth() / 2 - 230 && i < getWidth() / 2 - 68 && i_207_ > 21 && i_207_ < 39) || ((GameSparker) this).onbar) {
			((GameSparker) this).reqmult = (float)(i - (getWidth() / 2 - 222)) / 141.0F;
			if ((double)((GameSparker) this).reqmult < 0.1)
			((GameSparker) this).reqmult = 0.0F;
			if (((GameSparker) this).reqmult > 1.0F)
			((GameSparker) this).reqmult = 1.0F;
			((GameSparker) this).onbar = true;
			((GameSparker) this).showsize = 100;
		}
	}

	public void catchlink() {
		if (!((GameSparker) this).lostfcs) {
			if ((((GameSparker) this).xm > 65 && ((GameSparker) this).xm < 735 && ((GameSparker) this).ym > 135 && ((GameSparker) this).ym < 194) || (((GameSparker) this).xm > 275 && ((GameSparker) this).xm < 525 && ((GameSparker) this).ym > 265 && ((GameSparker) this).ym < 284)) {
				setCursor(new Cursor(12));
				if (((GameSparker) this).mouses == 2) openurl("http://www.radicalplay.com/");
			} else setCursor(new Cursor(0));
		}
	}

	public void musiclink() {
		openurl("http://multiplayer.needformadness.com/music.html");
	}

	public void reglink() {
		openurl("http://multiplayer.needformadness.com/register.html?ref=game");
	}

	public void madlink() {
		openurl("http://www.needformadness.com/");
	}

	public void editlink(String string, boolean bool) {
		String string_208_ = "";
		if (bool) string_208_ = "?display=upgrade";
		openurl(new StringBuilder().append("http://multiplayer.needformadness.com/edit.pl").append(string_208_).append("#").append(string).append("").toString());
	}

	public void regnew() {
		openurl("http://multiplayer.needformadness.com/registernew.pl");
	}

	public void multlink() {
		openurl("http://multiplayer.needformadness.com/");
	}

	public void setupini() {
		Madness.inisetup = true;
		try {
			File file = new File(new StringBuilder().append("").append(Madness.fpath).append("Madness.ini").toString());
			if (file.exists()) {
				String[] strings = new String[40];
				int i = 0;
				BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
				Object object = null;
				String string;
				for ( /**/ ;
				(string = bufferedreader.readLine()) != null && i < 40;
				i++) {
					strings[i] = string;
					if (strings[i].startsWith("Class Path")) {
						if (strings[i].indexOf("madapps.jar") != -1) strings[i] = "Class Path=\\data\\madapps.jar;";
						else strings[i] = "Class Path=\\data\\madapp.jar;";
					}
					if (strings[i].startsWith("JRE Path")) strings[i] = "JRE Path=data\\jre\\";
				}
				bufferedreader.close();
				Object object_209_ = null;
				BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
				for (int i_210_ = 0; i_210_ < i; i_210_++) {
					bufferedwriter.write(strings[i_210_]);
					bufferedwriter.newLine();
				}
				bufferedwriter.close();
				Object object_211_ = null;
			}
		} catch (Exception exception) {
			/* empty */
		}
		Madness.inisetup = false;
	}

	public void openurl(String string) {
		if (Desktop.isDesktopSupported()) {
			try {
				Desktop.getDesktop().browse(new URI(string));
			} catch (Exception exception) {
				/* empty */
			}
		} else {
			try {
				Runtime.getRuntime().exec(new StringBuilder().append("").append(Madness.urlopen()).append(" ").append(string).append("").toString());
			} catch (Exception exception) {
				/* empty */
			}
		}
	}

	public boolean keyDown(Event event, int i) {
		if (!((GameSparker) this).exwist) {
			if (((Control)((GameSparker) this).u[0]).multion < 2) {
				if (i == 1004)
				((Control)((GameSparker) this).u[0]).up = true;
				if (i == 1005)
				((Control)((GameSparker) this).u[0]).down = true;
				if (i == 1007)
				((Control)((GameSparker) this).u[0]).right = true;
				if (i == 1006)
				((Control)((GameSparker) this).u[0]).left = true;
				if (i == 32)
				((Control)((GameSparker) this).u[0]).handb = true;
			}
			if (i == 10)
			((Control)((GameSparker) this).u[0]).enter = true;
			if (i == 27) {
				((Control)((GameSparker) this).u[0]).exit = true;
				if (((Control)((GameSparker) this).u[0]).chatup != 0)
				((Control)((GameSparker) this).u[0]).chatup = 0;
			}
			if ((i == 67 || i == 99) && ((Control)((GameSparker) this).u[0]).multion != 0 && ((Control)((GameSparker) this).u[0]).chatup == 0) {
				((Control)((GameSparker) this).u[0]).chatup = 2;
				((GameSparker) this).view = 0;
			}
			if (((Control)((GameSparker) this).u[0]).chatup == 0) {
				if (i == 120 || i == 88)
				((Control)((GameSparker) this).u[0]).lookback = -1;
				if (i == 122 || i == 90)
				((Control)((GameSparker) this).u[0]).lookback = 1;
				if (i == 77 || i == 109) {
					if (((Control)((GameSparker) this).u[0]).mutem)
					((Control)((GameSparker) this).u[0]).mutem = false;
					else((Control)((GameSparker) this).u[0]).mutem = true;
				}
				if (i == 78 || i == 110) {
					if (((Control)((GameSparker) this).u[0]).mutes)
					((Control)((GameSparker) this).u[0]).mutes = false;
					else((Control)((GameSparker) this).u[0]).mutes = true;
				}
				if (i == 97 || i == 65) {
					if (((Control)((GameSparker) this).u[0]).arrace)
					((Control)((GameSparker) this).u[0]).arrace = false;
					else((Control)((GameSparker) this).u[0]).arrace = true;
				}
				if (i == 115 || i == 83) {
					if (((Control)((GameSparker) this).u[0]).radar)
					((Control)((GameSparker) this).u[0]).radar = false;
					else((Control)((GameSparker) this).u[0]).radar = true;
				}
				if (i == 118 || i == 86) {
					((GameSparker) this).view++;
					if (((GameSparker) this).view == 3)
					((GameSparker) this).view = 0;
				}
			}
		}
		return false;
	}

	public boolean keyUp(Event event, int i) {
		if (!((GameSparker) this).exwist) {
			if (((Control)((GameSparker) this).u[0]).multion < 2) {
				if (i == 1004)
				((Control)((GameSparker) this).u[0]).up = false;
				if (i == 1005)
				((Control)((GameSparker) this).u[0]).down = false;
				if (i == 1007)
				((Control)((GameSparker) this).u[0]).right = false;
				if (i == 1006)
				((Control)((GameSparker) this).u[0]).left = false;
				if (i == 32)
				((Control)((GameSparker) this).u[0]).handb = false;
			}
			if (i == 27) {
				((Control)((GameSparker) this).u[0]).exit = false;
				if (Madness.fullscreen) Madness.exitfullscreen();
			}
			if (i == 120 || i == 88 || i == 122 || i == 90)
			((Control)((GameSparker) this).u[0]).lookback = 0;
		}
		return false;
	}
}