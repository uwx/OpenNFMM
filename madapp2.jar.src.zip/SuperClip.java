/* SuperClip - Decompiled by JODE extended
 * DragShot Software
 * JODE (c) 1998-2001 Jochen Hoenicke
 */
import java.io.ByteArrayInputStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
public class SuperClip implements Runnable
{
    int skiprate = 0;
    Thread cliper;
    int stoped = 1;
    SourceDataLine source = null;
    ByteArrayInputStream stream;
    
    public SuperClip(byte[] is, int i, int i_0_) {
        ((SuperClip) this).stoped = 2;
        ((SuperClip) this).skiprate = i_0_;
        ((SuperClip) this).stream = new ByteArrayInputStream(is, 0, i);
    }
    
    public void run() {
        boolean bool = false;
        try {
            AudioFormat audioformat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, (float) ((SuperClip) this).skiprate, 16, 1, 2, (float) ((SuperClip) this).skiprate, false);
            DataLine.Info info = new DataLine.Info(null, audioformat);
            ((SuperClip) this).source = (SourceDataLine) AudioSystem.getLine(info);
            ((SuperClip) this).source.open(audioformat);
            ((SuperClip) this).source.start();
        } catch (Exception exception) {
            ((SuperClip) this).stoped = 1;
        }
        while (((SuperClip) this).stoped == 0) {
            try {
                if (((SuperClip) this).source.available() < ((SuperClip) this).skiprate || !bool) {
                    byte[] is = new byte[((SuperClip) this).skiprate * 2];
                    int i = ((SuperClip) this).stream.read(is, 0, is.length);
                    if (i == -1) {
                        ((SuperClip) this).stream.reset();
                        ((SuperClip) this).stream.read(is, 0, is.length);
                    }
                    ((SuperClip) this).source.write(is, 0, is.length);
                    bool = true;
                }
            } catch (Exception exception) {
                System.out.println(new StringBuilder().append("Play error: ").append(exception).toString());
                ((SuperClip) this).stoped = 1;
            }
            try {
                if (((SuperClip) this).cliper != null) {
                    /* empty */
                }
                Thread.sleep(200L);
            } catch (InterruptedException interruptedexception) {
                /* empty */
            }
        }
        ((SuperClip) this).source.stop();
        ((SuperClip) this).source.close();
        ((SuperClip) this).source = null;
        ((SuperClip) this).stoped = 2;
    }
    
    public void play() {
        if (((SuperClip) this).stoped == 2) {
            ((SuperClip) this).stoped = 0;
            try {
                ((SuperClip) this).stream.reset();
            } catch (Exception exception) {
                /* empty */
            }
            ((SuperClip) this).cliper = new Thread(this);
            ((SuperClip) this).cliper.start();
        }
    }
    
    public void resume() {
        if (((SuperClip) this).stoped == 2) {
            ((SuperClip) this).stoped = 0;
            ((SuperClip) this).cliper = new Thread(this);
            ((SuperClip) this).cliper.start();
        }
    }
    
    public void stop() {
        if (((SuperClip) this).stoped == 0) {
            ((SuperClip) this).stoped = 1;
            if (((SuperClip) this).source != null)
                ((SuperClip) this).source.stop();
        }
    }
    
    public void close() {
        try {
            ((SuperClip) this).stream.close();
            ((SuperClip) this).stream = null;
        } catch (Exception exception) {
            /* empty */
        }
    }
}
