/* Smenu - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;

public class Smenu
{
    int sel = 0;
    String[] opts;
    String[] sopts;
    int no = 0;
    int x = 0;
    int y = 0;
    Font font = new Font("Arial", 1, 13);
    Color bcol = new Color(255, 255, 255);
    Color fcol = new Color(0, 0, 0);
    int w = 0;
    int h = 0;
    FontMetrics ftm;
    boolean show = false;
    boolean open = false;
    boolean dis = false;
    int maxl = 0;
    boolean rooms = false;
    int[] iroom;
    int kmoused = 0;
    boolean alphad = false;
    boolean revup = false;
    boolean carsel = false;
    boolean flksel = false;
    boolean om = false;
    boolean onsc = false;
    int scro = 0;
    int scra = 0;
    
    public Smenu(int i) {
	((Smenu) this).opts = new String[i];
	((Smenu) this).sopts = new String[i];
    }
    
    public void add(Graphics2D graphics2d, String string) {
	graphics2d.setFont(((Smenu) this).font);
	((Smenu) this).ftm = graphics2d.getFontMetrics();
	if ((!((Smenu) this).rooms || ((Smenu) this).no == 0)
	    && ((Smenu) this).ftm.stringWidth(string) + 30 > ((Smenu) this).w)
	    ((Smenu) this).w = ((Smenu) this).ftm.stringWidth(string) + 30;
	if (((Smenu) this).rooms) {
	    ((Smenu) this).iroom = new int[7];
	    for (int i = 0; i < 7; i++)
		((Smenu) this).iroom[i] = 0;
	}
	((Smenu) this).opts[((Smenu) this).no] = string;
	if (((Smenu) this).maxl != 0) {
	    int i;
	    for (i = string.length();
		 (((Smenu) this).ftm.stringWidth(string.substring(0, i)) + 30
		  > ((Smenu) this).maxl);
		 i--) {
		/* empty */
	    }
	    if (i != string.length()) {
		string = string.substring(0, i - 3);
		string = new StringBuilder().append(string).append("...")
			     .toString();
	    }
	}
	((Smenu) this).sopts[((Smenu) this).no] = string;
	if (((Smenu) this).no < ((Smenu) this).opts.length - 1)
	    ((Smenu) this).no++;
    }
    
    public void addw(String string, String string_0_) {
	((Smenu) this).w = 300;
	((Smenu) this).opts[((Smenu) this).no] = string_0_;
	((Smenu) this).sopts[((Smenu) this).no] = string;
	if (((Smenu) this).no < ((Smenu) this).opts.length - 1)
	    ((Smenu) this).no++;
    }
    
    public void addstg(String string) {
	if (((Smenu) this).ftm.stringWidth(string) + 30 > ((Smenu) this).w)
	    ((Smenu) this).w = ((Smenu) this).ftm.stringWidth(string) + 30;
	((Smenu) this).no++;
	if (((Smenu) this).no > 701)
	    ((Smenu) this).no = 701;
	for (int i = ((Smenu) this).no - 1; i > 1; i--) {
	    ((Smenu) this).opts[i] = ((Smenu) this).opts[i - 1];
	    ((Smenu) this).sopts[i] = ((Smenu) this).sopts[i - 1];
	}
	((Smenu) this).opts[1] = string;
	((Smenu) this).sopts[1] = string;
    }
    
    public void removeAll() {
	((Smenu) this).no = 0;
	((Smenu) this).w = 0;
	((Smenu) this).sel = 0;
    }
    
    public void select(int i) {
	if (i >= 0 && i < ((Smenu) this).no)
	    ((Smenu) this).sel = i;
    }
    
    public void select(String string) {
	for (int i = 0; i < ((Smenu) this).no; i++) {
	    if (((Smenu) this).opts[i].equals(string)) {
		((Smenu) this).sel = i;
		break;
	    }
	}
    }
    
    public int getSelectedIndex() {
	return ((Smenu) this).sel;
    }
    
    public String getSelectedItem() {
	return ((Smenu) this).opts[((Smenu) this).sel];
    }
    
    public String getItem(int i) {
	String string = "";
	if (i >= 0 && i < ((Smenu) this).no)
	    string = ((Smenu) this).opts[i];
	return string;
    }
    
    public int getItemCount() {
	return ((Smenu) this).no;
    }
    
    public void remove(String string) {
	for (int i = 0; i < ((Smenu) this).no; i++) {
	    if (((Smenu) this).opts[i].equals(string)) {
		for (int i_1_ = i; i_1_ < ((Smenu) this).no; i_1_++) {
		    if (i_1_ != ((Smenu) this).no - 1) {
			((Smenu) this).opts[i_1_]
			    = ((Smenu) this).opts[i_1_ + 1];
			((Smenu) this).sopts[i_1_]
			    = ((Smenu) this).sopts[i_1_ + 1];
		    }
		}
		((Smenu) this).no--;
		break;
	    }
	}
    }
    
    public void setSize(int i, int i_2_) {
	((Smenu) this).w = i;
	((Smenu) this).h = i_2_;
    }
    
    public int getWidth() {
	return ((Smenu) this).w;
    }
    
    public void setFont(Font font) {
	((Smenu) this).font = font;
    }
    
    public void setBackground(Color color) {
	((Smenu) this).bcol = color;
    }
    
    public void setForeground(Color color) {
	((Smenu) this).fcol = color;
    }
    
    public Color getBackground() {
	return ((Smenu) this).bcol;
    }
    
    public Color getForeground() {
	return ((Smenu) this).fcol;
    }
    
    public void hide() {
	((Smenu) this).show = false;
	((Smenu) this).open = false;
    }
    
    public void show() {
	((Smenu) this).show = true;
    }
    
    public boolean isShowing() {
	return ((Smenu) this).show;
    }
    
    public void move(int i, int i_3_) {
	((Smenu) this).x = i;
	((Smenu) this).y = i_3_;
    }
    
    public boolean hasFocus() {
	return false;
    }
    
    public void disable() {
	((Smenu) this).dis = true;
    }
    
    public void enable() {
	((Smenu) this).dis = false;
    }
    
    public boolean isEnabled() {
	return !((Smenu) this).dis;
    }
    
    public boolean draw(Graphics2D graphics2d, int i, int i_4_, boolean bool,
			int i_5_, boolean bool_6_) {
	boolean bool_7_ = false;
	if (((Smenu) this).revup) {
	    if (bool_6_)
		bool_6_ = false;
	    else
		bool_6_ = true;
	    ((Smenu) this).revup = false;
	}
	if (((Smenu) this).show) {
	    if (((Smenu) this).alphad)
		graphics2d.setComposite(AlphaComposite.getInstance(3, 0.7F));
	    boolean bool_8_ = false;
	    if (bool) {
		if (!((Smenu) this).om) {
		    ((Smenu) this).om = true;
		    bool_8_ = true;
		}
	    } else if (((Smenu) this).om)
		((Smenu) this).om = false;
	    boolean bool_9_ = false;
	    if ((((Smenu) this).bcol.getRed() + ((Smenu) this).bcol.getGreen()
		 + ((Smenu) this).bcol.getBlue()) / 3
		> (((Smenu) this).fcol.getRed()
		   + ((Smenu) this).fcol.getGreen()
		   + ((Smenu) this).fcol.getBlue()) / 3)
		bool_9_ = true;
	    boolean bool_10_ = false;
	    if (i > ((Smenu) this).x && i < ((Smenu) this).x + ((Smenu) this).w
		&& i_4_ > ((Smenu) this).y + 1 && i_4_ < ((Smenu) this).y + 22
		&& !((Smenu) this).open && !((Smenu) this).dis)
		bool_10_ = true;
	    if (!((Smenu) this).open && bool_10_ && bool_8_
		&& !((Smenu) this).dis) {
		((Smenu) this).open = true;
		bool_8_ = false;
	    }
	    graphics2d.setFont(((Smenu) this).font);
	    ((Smenu) this).ftm = graphics2d.getFontMetrics();
	    if (((Smenu) this).open) {
		int i_11_ = 4 + ((((Smenu) this).ftm.getHeight() + 2)
				 * ((Smenu) this).no);
		if (!bool_6_) {
		    int i_12_ = 0;
		    graphics2d.setColor(((Smenu) this).bcol);
		    graphics2d.fillRect(((Smenu) this).x,
					((Smenu) this).y + 23,
					((Smenu) this).w, i_11_);
		    graphics2d.setColor
			(new Color((((Smenu) this).fcol.getRed()
				    + ((Smenu) this).bcol.getRed()) / 2,
				   (((Smenu) this).fcol.getGreen()
				    + ((Smenu) this).bcol.getGreen()) / 2,
				   (((Smenu) this).fcol.getBlue()
				    + ((Smenu) this).bcol.getBlue()) / 2));
		    graphics2d.drawRect(((Smenu) this).x,
					((Smenu) this).y + 23,
					((Smenu) this).w, i_11_);
		    if (((Smenu) this).y + 23 + i_11_ > i_5_) {
			graphics2d.drawLine((((Smenu) this).x
					     + ((Smenu) this).w - 18),
					    ((Smenu) this).y + 17,
					    (((Smenu) this).x
					     + ((Smenu) this).w - 18),
					    i_5_);
			if (bool_9_)
			    graphics2d.setColor
				(new Color((((Smenu) this).bcol.getRed()
					    + 510) / 3,
					   (((Smenu) this).bcol.getGreen()
					    + 510) / 3,
					   (((Smenu) this).bcol.getBlue()
					    + 510) / 3));
			else
			    graphics2d.setColor
				(new Color((((Smenu) this).fcol.getRed()
					    + 510) / 3,
					   (((Smenu) this).fcol.getGreen()
					    + 510) / 3,
					   (((Smenu) this).fcol.getBlue()
					    + 510) / 3));
			graphics2d.fillRect((((Smenu) this).x
					     + ((Smenu) this).w - 15),
					    (((Smenu) this).y + 25
					     + ((Smenu) this).scra),
					    13, 30);
			graphics2d.setColor(((Smenu) this).fcol);
			graphics2d.drawRect((((Smenu) this).x
					     + ((Smenu) this).w - 15),
					    (((Smenu) this).y + 25
					     + ((Smenu) this).scra),
					    12, 30);
			graphics2d.setColor(new Color(0, 0, 0));
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 12,
			     ((Smenu) this).y + 9 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 12,
			     ((Smenu) this).y + 10 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 11,
			     ((Smenu) this).y + 10 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 11,
			     ((Smenu) this).y + 11 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 10,
			     ((Smenu) this).y + 11 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 10,
			     ((Smenu) this).y + 12 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 9,
			     ((Smenu) this).y + 12 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 9,
			     ((Smenu) this).y + 13 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 8,
			     ((Smenu) this).y + 11 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 8,
			     ((Smenu) this).y + 12 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 7,
			     ((Smenu) this).y + 10 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 7,
			     ((Smenu) this).y + 11 + 29 + ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 6,
			     ((Smenu) this).y + 9 + 29 + ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 6,
			     ((Smenu) this).y + 10 + 29 + ((Smenu) this).scra);
			i_12_ = -18;
			if (bool) {
			    if (i > ((Smenu) this).x + ((Smenu) this).w - 18
				&& i < ((Smenu) this).x + ((Smenu) this).w
				&& i_4_ > ((Smenu) this).y + 25
				&& i_4_ < i_5_) {
				bool_8_ = false;
				((Smenu) this).onsc = true;
			    }
			} else if (((Smenu) this).onsc)
			    ((Smenu) this).onsc = false;
			if (((Smenu) this).onsc) {
			    ((Smenu) this).scra
				= i_4_ - (((Smenu) this).y + 25) - 15;
			    if (((Smenu) this).scra < 0)
				((Smenu) this).scra = 0;
			    int i_13_ = i_5_ - (((Smenu) this).y + 25) - 33;
			    if (((Smenu) this).scra > i_13_)
				((Smenu) this).scra = i_13_;
			    int i_14_
				= ((((Smenu) this).no
				    * (((Smenu) this).ftm.getHeight() + 2))
				   - i_13_
				   - ((Smenu) this).ftm.getHeight() / 2);
			    ((Smenu) this).scro
				= -(int) ((float) ((Smenu) this).scra
					  * ((float) i_14_ / (float) i_13_));
			}
		    }
		    for (int i_15_ = 0; i_15_ < ((Smenu) this).no; i_15_++) {
			if (Math.abs(((Smenu) this).scro)
			    < (i_15_ + 1) * (((Smenu) this).ftm.getHeight()
					     + 2)) {
			    graphics2d.setColor(((Smenu) this).fcol);
			    if (i > ((Smenu) this).x
				&& i < ((Smenu) this).x + ((Smenu) this).w
				&& i_4_ > (((Smenu) this).y + 25
					   + ((Smenu) this).scro
					   + (i_15_
					      * (((Smenu) this).ftm.getHeight()
						 + 2)))
				&& i_4_ < (((Smenu) this).y + 25
					   + ((Smenu) this).scro
					   + ((i_15_ + 1)
					      * (((Smenu) this).ftm.getHeight()
						 + 2)))) {
				if (bool_9_)
				    graphics2d.setColor
					(new Color
					 ((((Smenu) this).fcol.getRed()
					   + ((Smenu) this).bcol.getRed()) / 2,
					  ((((Smenu) this).fcol.getGreen()
					    + ((Smenu) this).bcol.getGreen())
					   / 2),
					  ((((Smenu) this).fcol.getBlue()
					    + ((Smenu) this).bcol.getBlue())
					   / 2)));
				else
				    graphics2d.setColor(((Smenu) this).fcol);
				graphics2d.fillRect
				    (((Smenu) this).x + 1,
				     (((Smenu) this).y + 25
				      + ((Smenu) this).scro
				      + i_15_ * (((Smenu) this).ftm.getHeight()
						 + 2)),
				     ((Smenu) this).w - 1 + i_12_,
				     ((Smenu) this).ftm.getHeight() + 2);
				graphics2d.setColor(((Smenu) this).bcol);
				if (bool_8_) {
				    if (!((Smenu) this).rooms
					|| !((Smenu) this).opts[i_15_]
						.equals("full")) {
					((Smenu) this).sel = i_15_;
					if (((Smenu) this).rooms && i_15_ != 0)
					    ((Smenu) this).sopts[i_15_] = " ";
				    } else
					((Smenu) this).kmoused = 20;
				    ((Smenu) this).open = false;
				}
			    }
			    if (((Smenu) this).rooms
				&& ((Smenu) this).sopts[i_15_]
				       .indexOf("10 / 10") != -1)
				graphics2d.setColor(new Color(255, 0, 0));
			    graphics2d.drawString(((Smenu) this).sopts[i_15_],
						  ((Smenu) this).x + 4,
						  (((Smenu) this).y + 38
						   + ((Smenu) this).scro
						   + i_15_ * (((Smenu) this)
								  .ftm
								  .getHeight()
							      + 2)));
			}
		    }
		    if (i_12_ != 0) {
			graphics2d.setColor
			    (new Color((((Smenu) this).fcol.getRed()
					+ ((Smenu) this).bcol.getRed()) / 2,
				       (((Smenu) this).fcol.getGreen()
					+ ((Smenu) this).bcol.getGreen()) / 2,
				       (((Smenu) this).fcol.getBlue()
					+ ((Smenu) this).bcol.getBlue()) / 2));
			graphics2d.drawLine(((Smenu) this).x, i_5_ - 1,
					    (((Smenu) this).x
					     + ((Smenu) this).w),
					    i_5_ - 1);
		    }
		} else {
		    int i_16_ = 0;
		    graphics2d.setColor(((Smenu) this).bcol);
		    graphics2d.fillRect(((Smenu) this).x,
					((Smenu) this).y - i_11_,
					((Smenu) this).w, i_11_);
		    graphics2d.setColor
			(new Color((((Smenu) this).fcol.getRed()
				    + ((Smenu) this).bcol.getRed()) / 2,
				   (((Smenu) this).fcol.getGreen()
				    + ((Smenu) this).bcol.getGreen()) / 2,
				   (((Smenu) this).fcol.getBlue()
				    + ((Smenu) this).bcol.getBlue()) / 2));
		    graphics2d.drawRect(((Smenu) this).x,
					((Smenu) this).y - i_11_,
					((Smenu) this).w, i_11_);
		    if (((Smenu) this).y - i_11_ < 0) {
			graphics2d.drawLine((((Smenu) this).x
					     + ((Smenu) this).w - 18),
					    0,
					    (((Smenu) this).x
					     + ((Smenu) this).w - 18),
					    ((Smenu) this).y);
			if (bool_9_)
			    graphics2d.setColor
				(new Color((((Smenu) this).bcol.getRed()
					    + 510) / 3,
					   (((Smenu) this).bcol.getGreen()
					    + 510) / 3,
					   (((Smenu) this).bcol.getBlue()
					    + 510) / 3));
			else
			    graphics2d.setColor
				(new Color((((Smenu) this).fcol.getRed()
					    + 510) / 3,
					   (((Smenu) this).fcol.getGreen()
					    + 510) / 3,
					   (((Smenu) this).fcol.getBlue()
					    + 510) / 3));
			graphics2d.fillRect((((Smenu) this).x
					     + ((Smenu) this).w - 15),
					    (((Smenu) this).y
					     - ((Smenu) this).scra - 33),
					    13, 30);
			graphics2d.setColor(((Smenu) this).fcol);
			graphics2d.drawRect((((Smenu) this).x
					     + ((Smenu) this).w - 15),
					    (((Smenu) this).y
					     - ((Smenu) this).scra - 33),
					    12, 30);
			graphics2d.setColor(new Color(0, 0, 0));
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 12,
			     ((Smenu) this).y + 13 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 12,
			     ((Smenu) this).y + 12 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 11,
			     ((Smenu) this).y + 12 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 11,
			     ((Smenu) this).y + 11 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 10,
			     ((Smenu) this).y + 11 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 10,
			     ((Smenu) this).y + 10 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 9,
			     ((Smenu) this).y + 10 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 9,
			     ((Smenu) this).y + 9 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 8,
			     ((Smenu) this).y + 11 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 8,
			     ((Smenu) this).y + 10 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 7,
			     ((Smenu) this).y + 12 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 7,
			     ((Smenu) this).y + 11 - 29 - ((Smenu) this).scra);
			graphics2d.drawLine
			    (((Smenu) this).x + ((Smenu) this).w - 6,
			     ((Smenu) this).y + 13 - 29 - ((Smenu) this).scra,
			     ((Smenu) this).x + ((Smenu) this).w - 6,
			     ((Smenu) this).y + 12 - 29 - ((Smenu) this).scra);
			i_16_ = -18;
			if (bool) {
			    if (i > ((Smenu) this).x + ((Smenu) this).w - 18
				&& i < ((Smenu) this).x + ((Smenu) this).w
				&& i_4_ > 0 && i_4_ < ((Smenu) this).y - 3) {
				bool_8_ = false;
				((Smenu) this).onsc = true;
			    }
			} else if (((Smenu) this).onsc)
			    ((Smenu) this).onsc = false;
			if (((Smenu) this).onsc) {
			    ((Smenu) this).scra
				= ((Smenu) this).y - 3 - 15 - i_4_;
			    if (((Smenu) this).scra < 0)
				((Smenu) this).scra = 0;
			    int i_17_ = ((Smenu) this).y - 35;
			    if (((Smenu) this).scra > i_17_)
				((Smenu) this).scra = i_17_;
			    int i_18_
				= ((((Smenu) this).no
				    * (((Smenu) this).ftm.getHeight() + 2))
				   - i_17_
				   - ((Smenu) this).ftm.getHeight() / 2);
			    ((Smenu) this).scro
				= (int) ((float) ((Smenu) this).scra
					 * ((float) i_18_ / (float) i_17_));
			}
		    }
		    for (int i_19_ = 0; i_19_ < ((Smenu) this).no; i_19_++) {
			if (Math.abs(((Smenu) this).scro)
			    < (i_19_ + 1) * (((Smenu) this).ftm.getHeight()
					     + 2)) {
			    graphics2d.setColor(((Smenu) this).fcol);
			    if (i > ((Smenu) this).x
				&& i < ((Smenu) this).x + ((Smenu) this).w
				&& i_4_ < (((Smenu) this).y - 18
					   + ((Smenu) this).scro
					   - ((i_19_ - 1)
					      * (((Smenu) this).ftm.getHeight()
						 + 2)))
				&& i_4_ > (((Smenu) this).y - 18
					   + ((Smenu) this).scro
					   - (i_19_
					      * (((Smenu) this).ftm.getHeight()
						 + 2)))) {
				if (bool_9_)
				    graphics2d.setColor
					(new Color
					 ((((Smenu) this).fcol.getRed()
					   + ((Smenu) this).bcol.getRed()) / 2,
					  ((((Smenu) this).fcol.getGreen()
					    + ((Smenu) this).bcol.getGreen())
					   / 2),
					  ((((Smenu) this).fcol.getBlue()
					    + ((Smenu) this).bcol.getBlue())
					   / 2)));
				else
				    graphics2d.setColor(((Smenu) this).fcol);
				graphics2d.fillRect
				    (((Smenu) this).x + 1,
				     (((Smenu) this).y - 18
				      + ((Smenu) this).scro
				      - i_19_ * (((Smenu) this).ftm.getHeight()
						 + 2)),
				     ((Smenu) this).w - 1 + i_16_,
				     ((Smenu) this).ftm.getHeight() + 2);
				graphics2d.setColor(((Smenu) this).bcol);
				if (bool_8_) {
				    ((Smenu) this).sel = i_19_;
				    ((Smenu) this).open = false;
				}
			    }
			    graphics2d.drawString(((Smenu) this).sopts[i_19_],
						  ((Smenu) this).x + 4,
						  (((Smenu) this).y - 5
						   + ((Smenu) this).scro
						   - i_19_ * (((Smenu) this)
								  .ftm
								  .getHeight()
							      + 2)));
			}
		    }
		    if (i_16_ != 0) {
			graphics2d.setColor
			    (new Color((((Smenu) this).fcol.getRed()
					+ ((Smenu) this).bcol.getRed()) / 2,
				       (((Smenu) this).fcol.getGreen()
					+ ((Smenu) this).bcol.getGreen()) / 2,
				       (((Smenu) this).fcol.getBlue()
					+ ((Smenu) this).bcol.getBlue()) / 2));
			graphics2d.drawLine(((Smenu) this).x, 0,
					    (((Smenu) this).x
					     + ((Smenu) this).w),
					    0);
		    }
		}
		bool_7_ = true;
		if (bool_8_)
		    ((Smenu) this).open = false;
	    } else {
		if (((Smenu) this).scro != 0)
		    ((Smenu) this).scro = 0;
		if (((Smenu) this).scra != 0)
		    ((Smenu) this).scra = 0;
	    }
	    if (bool_10_) {
		if (bool_9_)
		    graphics2d.setColor
			(new Color((((Smenu) this).fcol.getRed()
				    + ((Smenu) this).bcol.getRed()) / 2,
				   (((Smenu) this).fcol.getGreen()
				    + ((Smenu) this).bcol.getGreen()) / 2,
				   (((Smenu) this).fcol.getBlue()
				    + ((Smenu) this).bcol.getBlue()) / 2));
		else
		    graphics2d.setColor(((Smenu) this).fcol);
	    } else
		graphics2d.setColor(((Smenu) this).bcol);
	    graphics2d.fillRect(((Smenu) this).x, ((Smenu) this).y + 1,
				((Smenu) this).w, 21);
	    graphics2d.setColor(new Color((((Smenu) this).fcol.getRed()
					   + ((Smenu) this).bcol.getRed()) / 2,
					  ((((Smenu) this).fcol.getGreen()
					    + ((Smenu) this).bcol.getGreen())
					   / 2),
					  ((((Smenu) this).fcol.getBlue()
					    + ((Smenu) this).bcol.getBlue())
					   / 2)));
	    graphics2d.drawRect(((Smenu) this).x, ((Smenu) this).y + 1,
				((Smenu) this).w, 21);
	    if (bool_9_)
		graphics2d.setColor
		    (new Color((((Smenu) this).bcol.getRed() + 255) / 2,
			       (((Smenu) this).bcol.getGreen() + 255) / 2,
			       (((Smenu) this).bcol.getBlue() + 255) / 2));
	    else
		graphics2d.setColor
		    (new Color((((Smenu) this).fcol.getRed() + 255) / 2,
			       (((Smenu) this).fcol.getGreen() + 255) / 2,
			       (((Smenu) this).fcol.getBlue() + 255) / 2));
	    graphics2d.drawRect(((Smenu) this).x + 1, ((Smenu) this).y + 2,
				((Smenu) this).w - 2, 19);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 17,
				((Smenu) this).y + 3,
				((Smenu) this).x + ((Smenu) this).w - 17,
				((Smenu) this).y + 20);
	    graphics2d.setColor(((Smenu) this).fcol);
	    if (((Smenu) this).dis)
		graphics2d.setColor
		    (new Color((((Smenu) this).fcol.getRed()
				+ ((Smenu) this).bcol.getRed() * 2) / 3,
			       (((Smenu) this).fcol.getGreen()
				+ ((Smenu) this).bcol.getGreen() * 2) / 3,
			       (((Smenu) this).fcol.getBlue()
				+ ((Smenu) this).bcol.getBlue() * 2) / 3));
	    graphics2d.drawRect(((Smenu) this).x + ((Smenu) this).w - 16,
				((Smenu) this).y + 3, 14, 17);
	    if (bool_9_)
		graphics2d.setColor
		    (new Color((((Smenu) this).bcol.getRed() + 510) / 3,
			       (((Smenu) this).bcol.getGreen() + 510) / 3,
			       (((Smenu) this).bcol.getBlue() + 510) / 3));
	    else
		graphics2d.setColor
		    (new Color((((Smenu) this).fcol.getRed() + 510) / 3,
			       (((Smenu) this).fcol.getGreen() + 510) / 3,
			       (((Smenu) this).fcol.getBlue() + 510) / 3));
	    graphics2d.fillRect(((Smenu) this).x + ((Smenu) this).w - 15,
				((Smenu) this).y + 4, 13, 16);
	    graphics2d.setColor(new Color(0, 0, 0));
	    if (((Smenu) this).dis)
		graphics2d.setColor
		    (new Color((((Smenu) this).fcol.getRed()
				+ ((Smenu) this).bcol.getRed() * 2) / 3,
			       (((Smenu) this).fcol.getGreen()
				+ ((Smenu) this).bcol.getGreen() * 2) / 3,
			       (((Smenu) this).fcol.getBlue()
				+ ((Smenu) this).bcol.getBlue() * 2) / 3));
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 12,
				((Smenu) this).y + 9,
				((Smenu) this).x + ((Smenu) this).w - 12,
				((Smenu) this).y + 10);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 11,
				((Smenu) this).y + 10,
				((Smenu) this).x + ((Smenu) this).w - 11,
				((Smenu) this).y + 11);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 10,
				((Smenu) this).y + 11,
				((Smenu) this).x + ((Smenu) this).w - 10,
				((Smenu) this).y + 12);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 9,
				((Smenu) this).y + 12,
				((Smenu) this).x + ((Smenu) this).w - 9,
				((Smenu) this).y + 13);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 8,
				((Smenu) this).y + 11,
				((Smenu) this).x + ((Smenu) this).w - 8,
				((Smenu) this).y + 12);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 7,
				((Smenu) this).y + 10,
				((Smenu) this).x + ((Smenu) this).w - 7,
				((Smenu) this).y + 11);
	    graphics2d.drawLine(((Smenu) this).x + ((Smenu) this).w - 6,
				((Smenu) this).y + 9,
				((Smenu) this).x + ((Smenu) this).w - 6,
				((Smenu) this).y + 10);
	    if (bool_10_)
		graphics2d.setColor(((Smenu) this).bcol);
	    else
		graphics2d.setColor(((Smenu) this).fcol);
	    if (((Smenu) this).dis)
		graphics2d.setColor
		    (new Color((((Smenu) this).fcol.getRed()
				+ ((Smenu) this).bcol.getRed() * 2) / 3,
			       (((Smenu) this).fcol.getGreen()
				+ ((Smenu) this).bcol.getGreen() * 2) / 3,
			       (((Smenu) this).fcol.getBlue()
				+ ((Smenu) this).bcol.getBlue() * 2) / 3));
	    if (((Smenu) this).carsel && !bool_10_) {
		if (((Smenu) this).flksel) {
		    graphics2d.setColor(new Color(240, 240, 240));
		    ((Smenu) this).flksel = false;
		} else
		    ((Smenu) this).flksel = true;
	    }
	    graphics2d.drawString(((Smenu) this).sopts[((Smenu) this).sel],
				  ((Smenu) this).x + 4,
				  (((Smenu) this).y
				   + (((Smenu) this).ftm.getHeight() + 2)));
	    if (((Smenu) this).alphad)
		graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
	} else {
	    if (((Smenu) this).scro != 0)
		((Smenu) this).scro = 0;
	    if (((Smenu) this).scra != 0)
		((Smenu) this).scra = 0;
	}
	return bool_7_;
    }
}
