/* Record - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Color;

public class Record
{
    Medium m;
    int caught = 0;
    boolean hcaught = false;
    boolean prepit = true;
    ContO[] ocar = new ContO[8];
    int cntf = 50;
    ContO[][] car = new ContO[6][8];
    int[][] squash = new int[6][8];
    int[] fix = new int[8];
    int[] dest = new int[8];
    int[][] x = new int[300][8];
    int[][] y = new int[300][8];
    int[][] z = new int[300][8];
    int[][] xy = new int[300][8];
    int[][] zy = new int[300][8];
    int[][] xz = new int[300][8];
    int[][] wxz = new int[300][8];
    int[][] wzy = new int[300][8];
    int[][] ns = new int[8][20];
    int[][][] sspark = new int[8][20][30];
    int[][][] sx = new int[8][20][30];
    int[][][] sy = new int[8][20][30];
    int[][][] sz = new int[8][20][30];
    float[][][] smag = new float[8][20][30];
    int[][][] scx = new int[8][20][30];
    int[][][] scz = new int[8][20][30];
    int[] nr = new int[8];
    int[][] rspark = new int[8][200];
    int[][] sprk = new int[8][200];
    int[][] srx = new int[8][200];
    int[][] sry = new int[8][200];
    int[][] srz = new int[8][200];
    float[][] rcx = new float[8][200];
    float[][] rcy = new float[8][200];
    float[][] rcz = new float[8][200];
    int[][] nry = new int[8][4];
    int[][][] ry = new int[8][4][7];
    int[][][] magy = new int[8][4][7];
    boolean[][] mtouch = new boolean[8][7];
    int[][] nrx = new int[8][4];
    int[][][] rx = new int[8][4][7];
    int[][][] magx = new int[8][4][7];
    int[][] nrz = new int[8][4];
    int[][][] rz = new int[8][4][7];
    int[][][] magz = new int[8][4][7];
    int[] checkpoint = new int[300];
    boolean[] lastcheck = new boolean[300];
    int wasted = 0;
    int whenwasted = 0;
    int powered = 0;
    int closefinish = 0;
    ContO[] starcar = new ContO[8];
    int[] hsquash = { 0, 0, 0, 0, 0, 0, 0, 0 };
    int[] hfix = { -1, -1, -1, -1, -1, -1, -1, -1 };
    int[] hdest = { -1, -1, -1, -1, -1, -1, -1, -1 };
    int[][] hx = new int[300][8];
    int[][] hy = new int[300][8];
    int[][] hz = new int[300][8];
    int[][] hxy = new int[300][8];
    int[][] hzy = new int[300][8];
    int[][] hxz = new int[300][8];
    int[][] hwxz = new int[300][8];
    int[][] hwzy = new int[300][8];
    int[][][] hsspark = new int[8][20][30];
    int[][][] hsx = new int[8][20][30];
    int[][][] hsy = new int[8][20][30];
    int[][][] hsz = new int[8][20][30];
    float[][][] hsmag = new float[8][20][30];
    int[][][] hscx = new int[8][20][30];
    int[][][] hscz = new int[8][20][30];
    int[][] hrspark = new int[8][200];
    int[][] hsprk = new int[8][200];
    int[][] hsrx = new int[8][200];
    int[][] hsry = new int[8][200];
    int[][] hsrz = new int[8][200];
    float[][] hrcx = new float[8][200];
    float[][] hrcy = new float[8][200];
    float[][] hrcz = new float[8][200];
    int[][][] hry = new int[8][4][7];
    int[][][] hmagy = new int[8][4][7];
    int[][][] hrx = new int[8][4][7];
    int[][][] hmagx = new int[8][4][7];
    int[][][] hrz = new int[8][4][7];
    int[][][] hmagz = new int[8][4][7];
    boolean[][] hmtouch = new boolean[8][7];
    int[] hcheckpoint = new int[300];
    boolean[] hlastcheck = new boolean[300];
    int[] cntdest = new int[8];
    int lastfr = 0;
    
    public Record(Medium medium) {
	((Record) this).m = medium;
	((Record) this).caught = 0;
	cotchinow(0);
    }
    
    public void reset(ContO[] contos) {
	((Record) this).caught = 0;
	((Record) this).hcaught = false;
	((Record) this).wasted = 0;
	((Record) this).whenwasted = 0;
	((Record) this).closefinish = 0;
	((Record) this).powered = 0;
	for (int i = 0; i < 8; i++) {
	    if (((Record) this).prepit)
		((Record) this).starcar[i] = new ContO(contos[i], 0, 0, 0, 0);
	    ((Record) this).fix[i] = -1;
	    ((Record) this).dest[i] = -1;
	    ((Record) this).cntdest[i] = 0;
	}
	for (int i = 0; i < 6; i++) {
	    for (int i_0_ = 0; i_0_ < 8; i_0_++) {
		((Record) this).car[i][i_0_]
		    = new ContO(contos[i_0_], 0, 0, 0, 0);
		((Record) this).squash[i][i_0_] = 0;
	    }
	}
	for (int i = 0; i < 8; i++) {
	    ((Record) this).nr[i] = 0;
	    for (int i_1_ = 0; i_1_ < 200; i_1_++)
		((Record) this).rspark[i][i_1_] = -1;
	    for (int i_2_ = 0; i_2_ < 20; i_2_++) {
		((Record) this).ns[i][i_2_] = 0;
		for (int i_3_ = 0; i_3_ < 30; i_3_++)
		    ((Record) this).sspark[i][i_2_][i_3_] = -1;
	    }
	    for (int i_4_ = 0; i_4_ < 4; i_4_++) {
		((Record) this).nry[i][i_4_] = 0;
		((Record) this).nrx[i][i_4_] = 0;
		((Record) this).nrz[i][i_4_] = 0;
		for (int i_5_ = 0; i_5_ < 7; i_5_++) {
		    ((Record) this).ry[i][i_4_][i_5_] = -1;
		    ((Record) this).rx[i][i_4_][i_5_] = -1;
		    ((Record) this).rz[i][i_4_][i_5_] = -1;
		}
	    }
	}
	((Record) this).prepit = false;
    }
    
    public void cotchinow(int i) {
	if (((Record) this).caught >= 300) {
	    ((Record) this).wasted = i;
	    for (int i_6_ = 0; i_6_ < 8; i_6_++) {
		((Record) this).starcar[i_6_]
		    = new ContO(((Record) this).car[0][i_6_], 0, 0, 0, 0);
		((Record) this).hsquash[i_6_]
		    = ((Record) this).squash[0][i_6_];
		((Record) this).hfix[i_6_] = ((Record) this).fix[i_6_];
		((Record) this).hdest[i_6_] = ((Record) this).dest[i_6_];
	    }
	    for (int i_7_ = 0; i_7_ < 300; i_7_++) {
		for (int i_8_ = 0; i_8_ < 8; i_8_++) {
		    ((Record) this).hx[i_7_][i_8_]
			= ((Record) this).x[i_7_][i_8_];
		    ((Record) this).hy[i_7_][i_8_]
			= ((Record) this).y[i_7_][i_8_];
		    ((Record) this).hz[i_7_][i_8_]
			= ((Record) this).z[i_7_][i_8_];
		    ((Record) this).hxy[i_7_][i_8_]
			= ((Record) this).xy[i_7_][i_8_];
		    ((Record) this).hzy[i_7_][i_8_]
			= ((Record) this).zy[i_7_][i_8_];
		    ((Record) this).hxz[i_7_][i_8_]
			= ((Record) this).xz[i_7_][i_8_];
		    ((Record) this).hwxz[i_7_][i_8_]
			= ((Record) this).wxz[i_7_][i_8_];
		    ((Record) this).hwzy[i_7_][i_8_]
			= ((Record) this).wzy[i_7_][i_8_];
		}
		((Record) this).hcheckpoint[i_7_]
		    = ((Record) this).checkpoint[i_7_];
		((Record) this).hlastcheck[i_7_]
		    = ((Record) this).lastcheck[i_7_];
	    }
	    for (int i_9_ = 0; i_9_ < 8; i_9_++) {
		for (int i_10_ = 0; i_10_ < 20; i_10_++) {
		    for (int i_11_ = 0; i_11_ < 30; i_11_++) {
			((Record) this).hsspark[i_9_][i_10_][i_11_]
			    = ((Record) this).sspark[i_9_][i_10_][i_11_];
			((Record) this).hsx[i_9_][i_10_][i_11_]
			    = ((Record) this).sx[i_9_][i_10_][i_11_];
			((Record) this).hsy[i_9_][i_10_][i_11_]
			    = ((Record) this).sy[i_9_][i_10_][i_11_];
			((Record) this).hsz[i_9_][i_10_][i_11_]
			    = ((Record) this).sz[i_9_][i_10_][i_11_];
			((Record) this).hsmag[i_9_][i_10_][i_11_]
			    = ((Record) this).smag[i_9_][i_10_][i_11_];
			((Record) this).hscx[i_9_][i_10_][i_11_]
			    = ((Record) this).scx[i_9_][i_10_][i_11_];
			((Record) this).hscz[i_9_][i_10_][i_11_]
			    = ((Record) this).scz[i_9_][i_10_][i_11_];
		    }
		}
		for (int i_12_ = 0; i_12_ < 200; i_12_++) {
		    ((Record) this).hrspark[i_9_][i_12_]
			= ((Record) this).rspark[i_9_][i_12_];
		    ((Record) this).hsprk[i_9_][i_12_]
			= ((Record) this).sprk[i_9_][i_12_];
		    ((Record) this).hsrx[i_9_][i_12_]
			= ((Record) this).srx[i_9_][i_12_];
		    ((Record) this).hsry[i_9_][i_12_]
			= ((Record) this).sry[i_9_][i_12_];
		    ((Record) this).hsrz[i_9_][i_12_]
			= ((Record) this).srz[i_9_][i_12_];
		    ((Record) this).hrcx[i_9_][i_12_]
			= ((Record) this).rcx[i_9_][i_12_];
		    ((Record) this).hrcy[i_9_][i_12_]
			= ((Record) this).rcy[i_9_][i_12_];
		    ((Record) this).hrcz[i_9_][i_12_]
			= ((Record) this).rcz[i_9_][i_12_];
		}
	    }
	    for (int i_13_ = 0; i_13_ < 8; i_13_++) {
		for (int i_14_ = 0; i_14_ < 4; i_14_++) {
		    for (int i_15_ = 0; i_15_ < 7; i_15_++) {
			((Record) this).hry[i_13_][i_14_][i_15_]
			    = ((Record) this).ry[i_13_][i_14_][i_15_];
			((Record) this).hmagy[i_13_][i_14_][i_15_]
			    = ((Record) this).magy[i_13_][i_14_][i_15_];
			((Record) this).hrx[i_13_][i_14_][i_15_]
			    = ((Record) this).rx[i_13_][i_14_][i_15_];
			((Record) this).hmagx[i_13_][i_14_][i_15_]
			    = ((Record) this).magx[i_13_][i_14_][i_15_];
			((Record) this).hrz[i_13_][i_14_][i_15_]
			    = ((Record) this).rz[i_13_][i_14_][i_15_];
			((Record) this).hmagz[i_13_][i_14_][i_15_]
			    = ((Record) this).magz[i_13_][i_14_][i_15_];
		    }
		}
	    }
	    for (int i_16_ = 0; i_16_ < 8; i_16_++) {
		for (int i_17_ = 0; i_17_ < 7; i_17_++)
		    ((Record) this).hmtouch[i_16_][i_17_]
			= ((Record) this).mtouch[i_16_][i_17_];
	    }
	    ((Record) this).hcaught = true;
	}
    }
    
    public void rec(ContO conto, int i, int i_18_, int i_19_, int i_20_,
		    int i_21_) {
	if (i == i_21_)
	    ((Record) this).caught++;
	if (((Record) this).cntf == 50) {
	    for (int i_22_ = 0; i_22_ < 5; i_22_++) {
		((Record) this).car[i_22_][i]
		    = new ContO(((Record) this).car[i_22_ + 1][i], 0, 0, 0, 0);
		((Record) this).squash[i_22_][i]
		    = ((Record) this).squash[i_22_ + 1][i];
	    }
	    ((Record) this).car[5][i] = new ContO(conto, 0, 0, 0, 0);
	    ((Record) this).squash[5][i] = i_18_;
	    ((Record) this).cntf = 0;
	} else
	    ((Record) this).cntf++;
	((Record) this).fix[i]--;
	if (i_20_ != 0)
	    ((Record) this).dest[i]--;
	if (((Record) this).dest[i] == 230) {
	    if (i == i_21_) {
		cotchinow(i_21_);
		((Record) this).whenwasted = 229;
	    } else if (i_19_ != 0) {
		cotchinow(i);
		((Record) this).whenwasted = 165 + i_19_;
	    }
	}
	for (int i_23_ = 0; i_23_ < 299; i_23_++) {
	    ((Record) this).x[i_23_][i] = ((Record) this).x[i_23_ + 1][i];
	    ((Record) this).y[i_23_][i] = ((Record) this).y[i_23_ + 1][i];
	    ((Record) this).z[i_23_][i] = ((Record) this).z[i_23_ + 1][i];
	    ((Record) this).zy[i_23_][i] = ((Record) this).zy[i_23_ + 1][i];
	    ((Record) this).xy[i_23_][i] = ((Record) this).xy[i_23_ + 1][i];
	    ((Record) this).xz[i_23_][i] = ((Record) this).xz[i_23_ + 1][i];
	    ((Record) this).wxz[i_23_][i] = ((Record) this).wxz[i_23_ + 1][i];
	    ((Record) this).wzy[i_23_][i] = ((Record) this).wzy[i_23_ + 1][i];
	}
	((Record) this).x[299][i] = ((ContO) conto).x;
	((Record) this).y[299][i] = ((ContO) conto).y;
	((Record) this).z[299][i] = ((ContO) conto).z;
	((Record) this).xy[299][i] = ((ContO) conto).xy;
	((Record) this).zy[299][i] = ((ContO) conto).zy;
	((Record) this).xz[299][i] = ((ContO) conto).xz;
	((Record) this).wxz[299][i] = ((ContO) conto).wxz;
	((Record) this).wzy[299][i] = ((ContO) conto).wzy;
	if (i == i_21_) {
	    for (int i_24_ = 0; i_24_ < 299; i_24_++) {
		((Record) this).checkpoint[i_24_]
		    = ((Record) this).checkpoint[i_24_ + 1];
		((Record) this).lastcheck[i_24_]
		    = ((Record) this).lastcheck[i_24_ + 1];
	    }
	    ((Record) this).checkpoint[299]
		= ((Medium) ((ContO) conto).m).checkpoint;
	    ((Record) this).lastcheck[299]
		= ((Medium) ((ContO) conto).m).lastcheck;
	}
	for (int i_25_ = 0; i_25_ < 20; i_25_++) {
	    if (((ContO) conto).stg[i_25_] == 1) {
		((Record) this).sspark[i][i_25_][((Record) this).ns[i][i_25_]]
		    = 300;
		((Record) this).sx[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).sx[i_25_];
		((Record) this).sy[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).sy[i_25_];
		((Record) this).sz[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).sz[i_25_];
		((Record) this).smag[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).osmag[i_25_];
		((Record) this).scx[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).scx[i_25_];
		((Record) this).scz[i][i_25_][((Record) this).ns[i][i_25_]]
		    = ((ContO) conto).scz[i_25_];
		((Record) this).ns[i][i_25_]++;
		if (((Record) this).ns[i][i_25_] == 30)
		    ((Record) this).ns[i][i_25_] = 0;
	    }
	    for (int i_26_ = 0; i_26_ < 30; i_26_++)
		((Record) this).sspark[i][i_25_][i_26_]--;
	}
	if (((ContO) conto).sprk != 0) {
	    ((Record) this).rspark[i][((Record) this).nr[i]] = 300;
	    ((Record) this).sprk[i][((Record) this).nr[i]]
		= ((ContO) conto).sprk;
	    ((Record) this).srx[i][((Record) this).nr[i]]
		= ((ContO) conto).srx;
	    ((Record) this).sry[i][((Record) this).nr[i]]
		= ((ContO) conto).sry;
	    ((Record) this).srz[i][((Record) this).nr[i]]
		= ((ContO) conto).srz;
	    ((Record) this).rcx[i][((Record) this).nr[i]]
		= ((ContO) conto).rcx;
	    ((Record) this).rcy[i][((Record) this).nr[i]]
		= ((ContO) conto).rcy;
	    ((Record) this).rcz[i][((Record) this).nr[i]]
		= ((ContO) conto).rcz;
	    ((Record) this).nr[i]++;
	    if (((Record) this).nr[i] == 200)
		((Record) this).nr[i] = 0;
	}
	for (int i_27_ = 0; i_27_ < 200; i_27_++)
	    ((Record) this).rspark[i][i_27_]--;
	for (int i_28_ = 0; i_28_ < 4; i_28_++) {
	    for (int i_29_ = 0; i_29_ < 7; i_29_++) {
		((Record) this).ry[i][i_28_][i_29_]--;
		((Record) this).rx[i][i_28_][i_29_]--;
		((Record) this).rz[i][i_28_][i_29_]--;
	    }
	}
    }
    
    public void play(ContO conto, Mad mad, int i, int i_30_) {
	((ContO) conto).x = ((Record) this).x[i_30_][i];
	((ContO) conto).y = ((Record) this).y[i_30_][i];
	((ContO) conto).z = ((Record) this).z[i_30_][i];
	((ContO) conto).zy = ((Record) this).zy[i_30_][i];
	((ContO) conto).xy = ((Record) this).xy[i_30_][i];
	((ContO) conto).xz = ((Record) this).xz[i_30_][i];
	((ContO) conto).wxz = ((Record) this).wxz[i_30_][i];
	((ContO) conto).wzy = ((Record) this).wzy[i_30_][i];
	if (i == 0) {
	    ((Medium) ((ContO) conto).m).checkpoint
		= ((Record) this).checkpoint[i_30_];
	    ((Medium) ((ContO) conto).m).lastcheck
		= ((Record) this).lastcheck[i_30_];
	}
	if (i_30_ == 0)
	    ((Record) this).cntdest[i] = 0;
	if (((Record) this).dest[i] == i_30_)
	    ((Record) this).cntdest[i] = 7;
	if (i_30_ == 0 && ((Record) this).dest[i] < -1) {
	    for (int i_31_ = 0; i_31_ < ((ContO) conto).npl; i_31_++) {
		if (((Plane) ((ContO) conto).p[i_31_]).wz == 0
		    || ((Plane) ((ContO) conto).p[i_31_]).gr == -17
		    || ((Plane) ((ContO) conto).p[i_31_]).gr == -16)
		    ((Plane) ((ContO) conto).p[i_31_]).embos = 13;
	    }
	}
	if (((Record) this).cntdest[i] != 0) {
	    for (int i_32_ = 0; i_32_ < ((ContO) conto).npl; i_32_++) {
		if (((Plane) ((ContO) conto).p[i_32_]).wz == 0
		    || ((Plane) ((ContO) conto).p[i_32_]).gr == -17
		    || ((Plane) ((ContO) conto).p[i_32_]).gr == -16)
		    ((Plane) ((ContO) conto).p[i_32_]).embos = 1;
	    }
	    ((Record) this).cntdest[i]--;
	}
	for (int i_33_ = 0; i_33_ < 20; i_33_++) {
	    for (int i_34_ = 0; i_34_ < 30; i_34_++) {
		if (((Record) this).sspark[i][i_33_][i_34_] == i_30_) {
		    ((ContO) conto).stg[i_33_] = 1;
		    ((ContO) conto).sx[i_33_]
			= ((Record) this).sx[i][i_33_][i_34_];
		    ((ContO) conto).sy[i_33_]
			= ((Record) this).sy[i][i_33_][i_34_];
		    ((ContO) conto).sz[i_33_]
			= ((Record) this).sz[i][i_33_][i_34_];
		    ((ContO) conto).osmag[i_33_]
			= ((Record) this).smag[i][i_33_][i_34_];
		    ((ContO) conto).scx[i_33_]
			= ((Record) this).scx[i][i_33_][i_34_];
		    ((ContO) conto).scz[i_33_]
			= ((Record) this).scz[i][i_33_][i_34_];
		}
	    }
	}
	for (int i_35_ = 0; i_35_ < 200; i_35_++) {
	    if (((Record) this).rspark[i][i_35_] == i_30_) {
		((ContO) conto).sprk = ((Record) this).sprk[i][i_35_];
		((ContO) conto).srx = ((Record) this).srx[i][i_35_];
		((ContO) conto).sry = ((Record) this).sry[i][i_35_];
		((ContO) conto).srz = ((Record) this).srz[i][i_35_];
		((ContO) conto).rcx = ((Record) this).rcx[i][i_35_];
		((ContO) conto).rcy = ((Record) this).rcy[i][i_35_];
		((ContO) conto).rcz = ((Record) this).rcz[i][i_35_];
	    }
	}
	for (int i_36_ = 0; i_36_ < 4; i_36_++) {
	    for (int i_37_ = 0; i_37_ < 7; i_37_++) {
		if (((Record) this).ry[i][i_36_][i_37_] == i_30_)
		    regy(i_36_, (float) ((Record) this).magy[i][i_36_][i_37_],
			 ((Record) this).mtouch[i][i_37_], conto, mad);
		if (((Record) this).rx[i][i_36_][i_37_] == i_30_)
		    regx(i_36_, (float) ((Record) this).magx[i][i_36_][i_37_],
			 conto, mad);
		if (((Record) this).rz[i][i_36_][i_37_] == i_30_)
		    regz(i_36_, (float) ((Record) this).magz[i][i_36_][i_37_],
			 conto, mad);
	    }
	}
    }
    
    public void playh(ContO conto, Mad mad, int i, int i_38_, int i_39_) {
	((ContO) conto).x = ((Record) this).hx[i_38_][i];
	((ContO) conto).y = ((Record) this).hy[i_38_][i];
	((ContO) conto).z = ((Record) this).hz[i_38_][i];
	((ContO) conto).zy = ((Record) this).hzy[i_38_][i];
	((ContO) conto).xy = ((Record) this).hxy[i_38_][i];
	((ContO) conto).xz = ((Record) this).hxz[i_38_][i];
	((ContO) conto).wxz = ((Record) this).hwxz[i_38_][i];
	((ContO) conto).wzy = ((Record) this).hwzy[i_38_][i];
	if (i == i_39_) {
	    ((Medium) ((ContO) conto).m).checkpoint
		= ((Record) this).hcheckpoint[i_38_];
	    ((Medium) ((ContO) conto).m).lastcheck
		= ((Record) this).hlastcheck[i_38_];
	}
	if (i_38_ == 0)
	    ((Record) this).cntdest[i] = 0;
	if (((Record) this).hdest[i] == i_38_)
	    ((Record) this).cntdest[i] = 7;
	if (i_38_ == 0 && ((Record) this).hdest[i] < -1) {
	    for (int i_40_ = 0; i_40_ < ((ContO) conto).npl; i_40_++) {
		if (((Plane) ((ContO) conto).p[i_40_]).wz == 0
		    || ((Plane) ((ContO) conto).p[i_40_]).gr == -17
		    || ((Plane) ((ContO) conto).p[i_40_]).gr == -16)
		    ((Plane) ((ContO) conto).p[i_40_]).embos = 13;
	    }
	}
	if (((Record) this).cntdest[i] != 0) {
	    for (int i_41_ = 0; i_41_ < ((ContO) conto).npl; i_41_++) {
		if (((Plane) ((ContO) conto).p[i_41_]).wz == 0
		    || ((Plane) ((ContO) conto).p[i_41_]).gr == -17
		    || ((Plane) ((ContO) conto).p[i_41_]).gr == -16)
		    ((Plane) ((ContO) conto).p[i_41_]).embos = 1;
	    }
	    ((Record) this).cntdest[i]--;
	}
	for (int i_42_ = 0; i_42_ < 20; i_42_++) {
	    for (int i_43_ = 0; i_43_ < 30; i_43_++) {
		if (((Record) this).hsspark[i][i_42_][i_43_] == i_38_) {
		    ((ContO) conto).stg[i_42_] = 1;
		    ((ContO) conto).sx[i_42_]
			= ((Record) this).hsx[i][i_42_][i_43_];
		    ((ContO) conto).sy[i_42_]
			= ((Record) this).hsy[i][i_42_][i_43_];
		    ((ContO) conto).sz[i_42_]
			= ((Record) this).hsz[i][i_42_][i_43_];
		    ((ContO) conto).osmag[i_42_]
			= ((Record) this).hsmag[i][i_42_][i_43_];
		    ((ContO) conto).scx[i_42_]
			= ((Record) this).hscx[i][i_42_][i_43_];
		    ((ContO) conto).scz[i_42_]
			= ((Record) this).hscz[i][i_42_][i_43_];
		}
	    }
	}
	for (int i_44_ = 0; i_44_ < 200; i_44_++) {
	    if (((Record) this).hrspark[i][i_44_] == i_38_) {
		((ContO) conto).sprk = ((Record) this).hsprk[i][i_44_];
		((ContO) conto).srx = ((Record) this).hsrx[i][i_44_];
		((ContO) conto).sry = ((Record) this).hsry[i][i_44_];
		((ContO) conto).srz = ((Record) this).hsrz[i][i_44_];
		((ContO) conto).rcx = ((Record) this).hrcx[i][i_44_];
		((ContO) conto).rcy = ((Record) this).hrcy[i][i_44_];
		((ContO) conto).rcz = ((Record) this).hrcz[i][i_44_];
	    }
	}
	for (int i_45_ = 0; i_45_ < 4; i_45_++) {
	    for (int i_46_ = 0; i_46_ < 7; i_46_++) {
		if (((Record) this).hry[i][i_45_][i_46_] == i_38_
		    && ((Record) this).lastfr != i_38_)
		    regy(i_45_, (float) ((Record) this).hmagy[i][i_45_][i_46_],
			 ((Record) this).hmtouch[i][i_46_], conto, mad);
		if (((Record) this).hrx[i][i_45_][i_46_] == i_38_) {
		    if (((Record) this).lastfr != i_38_)
			regx(i_45_,
			     (float) ((Record) this).hmagx[i][i_45_][i_46_],
			     conto, mad);
		    else
			chipx(i_45_,
			      (float) ((Record) this).hmagx[i][i_45_][i_46_],
			      conto, mad);
		}
		if (((Record) this).hrz[i][i_45_][i_46_] == i_38_) {
		    if (((Record) this).lastfr != i_38_)
			regz(i_45_,
			     (float) ((Record) this).hmagz[i][i_45_][i_46_],
			     conto, mad);
		    else
			chipz(i_45_,
			      (float) ((Record) this).hmagz[i][i_45_][i_46_],
			      conto, mad);
		}
	    }
	}
	((Record) this).lastfr = i_38_;
    }
    
    public void recy(int i, float f, boolean bool, int i_47_) {
	((Record) this).ry[i_47_][i][((Record) this).nry[i_47_][i]] = 300;
	((Record) this).magy[i_47_][i][((Record) this).nry[i_47_][i]]
	    = (int) f;
	((Record) this).mtouch[i_47_][((Record) this).nry[i_47_][i]] = bool;
	((Record) this).nry[i_47_][i]++;
	if (((Record) this).nry[i_47_][i] == 7)
	    ((Record) this).nry[i_47_][i] = 0;
    }
    
    public void recx(int i, float f, int i_48_) {
	((Record) this).rx[i_48_][i][((Record) this).nry[i_48_][i]] = 300;
	((Record) this).magx[i_48_][i][((Record) this).nry[i_48_][i]]
	    = (int) f;
	((Record) this).nrx[i_48_][i]++;
	if (((Record) this).nrx[i_48_][i] == 7)
	    ((Record) this).nrx[i_48_][i] = 0;
    }
    
    public void recz(int i, float f, int i_49_) {
	((Record) this).rz[i_49_][i][((Record) this).nry[i_49_][i]] = 300;
	((Record) this).magz[i_49_][i][((Record) this).nry[i_49_][i]]
	    = (int) f;
	((Record) this).nrz[i_49_][i]++;
	if (((Record) this).nrz[i_49_][i] == 7)
	    ((Record) this).nrz[i_49_][i] = 0;
    }
    
    public void regy(int i, float f, boolean bool, ContO conto, Mad mad) {
	if (f > 100.0F) {
	    f -= 100.0F;
	    int i_50_ = 0;
	    int i_51_ = 0;
	    int i_52_ = ((ContO) conto).zy;
	    int i_53_ = ((ContO) conto).xy;
	    for (/**/; i_52_ < 360; i_52_ += 360) {
		/* empty */
	    }
	    for (/**/; i_52_ > 360; i_52_ -= 360) {
		/* empty */
	    }
	    if (i_52_ < 210 && i_52_ > 150)
		i_50_ = -1;
	    if (i_52_ > 330 || i_52_ < 30)
		i_50_ = 1;
	    for (/**/; i_53_ < 360; i_53_ += 360) {
		/* empty */
	    }
	    for (/**/; i_53_ > 360; i_53_ -= 360) {
		/* empty */
	    }
	    if (i_53_ < 210 && i_53_ > 150)
		i_51_ = -1;
	    if (i_53_ > 330 || i_53_ < 30)
		i_51_ = 1;
	    if (i_51_ * i_50_ == 0 || bool) {
		for (int i_54_ = 0; i_54_ < ((ContO) conto).npl; i_54_++) {
		    float f_55_ = 0.0F;
		    for (int i_56_ = 0;
			 i_56_ < ((Plane) ((ContO) conto).p[i_54_]).n;
			 i_56_++) {
			if (((Plane) ((ContO) conto).p[i_54_]).wz == 0
			    && (py(((ContO) conto).keyx[i],
				   (((Plane) ((ContO) conto).p[i_54_]).ox
				    [i_56_]),
				   ((ContO) conto).keyz[i],
				   (((Plane) ((ContO) conto).p[i_54_]).oz
				    [i_56_]))
				< (((CarDefine) ((Mad) mad).cd).clrad
				   [((Mad) mad).cn]))) {
			    f_55_ = f / 20.0F * ((Record) this).m.random();
			    ((Plane) ((ContO) conto).p[i_54_]).oz[i_56_]
				+= f_55_ * ((Record) this).m.sin(i_52_);
			    ((Plane) ((ContO) conto).p[i_54_]).ox[i_56_]
				-= f_55_ * ((Record) this).m.sin(i_53_);
			}
		    }
		    if (f_55_ != 0.0F) {
			if (Math.abs(f_55_) >= 1.0F) {
			    ((Plane) ((ContO) conto).p[i_54_]).chip = 1;
			    ((Plane) ((ContO) conto).p[i_54_]).ctmag = f_55_;
			}
			if (!((Plane) ((ContO) conto).p[i_54_]).nocol
			    && ((Plane) ((ContO) conto).p[i_54_]).glass != 1) {
			    if (((Plane) ((ContO) conto).p[i_54_]).bfase > 20
				&& (double) (((Plane) ((ContO) conto).p[i_54_])
					     .hsb[1]) > 0.2)
				((Plane) ((ContO) conto).p[i_54_]).hsb[1]
				    = 0.2F;
			    if (((Plane) ((ContO) conto).p[i_54_]).bfase
				> 30) {
				if ((double) ((Plane)
					      ((ContO) conto).p[i_54_]).hsb[2]
				    < 0.5)
				    ((Plane) ((ContO) conto).p[i_54_]).hsb[2]
					= 0.5F;
				if ((double) ((Plane)
					      ((ContO) conto).p[i_54_]).hsb[1]
				    > 0.1)
				    ((Plane) ((ContO) conto).p[i_54_]).hsb[1]
					= 0.1F;
			    }
			    if (((Plane) ((ContO) conto).p[i_54_]).bfase > 40)
				((Plane) ((ContO) conto).p[i_54_]).hsb[1]
				    = 0.05F;
			    if (((Plane) ((ContO) conto).p[i_54_]).bfase
				> 50) {
				if ((double) ((Plane)
					      ((ContO) conto).p[i_54_]).hsb[2]
				    > 0.8)
				    ((Plane) ((ContO) conto).p[i_54_]).hsb[2]
					= 0.8F;
				((Plane) ((ContO) conto).p[i_54_]).hsb[0]
				    = 0.075F;
				((Plane) ((ContO) conto).p[i_54_]).hsb[1]
				    = 0.05F;
			    }
			    if (((Plane) ((ContO) conto).p[i_54_]).bfase > 60)
				((Plane) ((ContO) conto).p[i_54_]).hsb[0]
				    = 0.05F;
			    ((Plane) ((ContO) conto).p[i_54_]).bfase += f_55_;
			    new Color(((Plane) ((ContO) conto).p[i_54_]).c[0],
				      ((Plane) ((ContO) conto).p[i_54_]).c[1],
				      ((Plane) ((ContO) conto).p[i_54_]).c[2]);
			    Color color
				= (Color.getHSBColor
				   (((Plane) ((ContO) conto).p[i_54_]).hsb[0],
				    ((Plane) ((ContO) conto).p[i_54_]).hsb[1],
				    (((Plane) ((ContO) conto).p[i_54_]).hsb
				     [2])));
			    ((Plane) ((ContO) conto).p[i_54_]).c[0]
				= color.getRed();
			    ((Plane) ((ContO) conto).p[i_54_]).c[1]
				= color.getGreen();
			    ((Plane) ((ContO) conto).p[i_54_]).c[2]
				= color.getBlue();
			}
			if (((Plane) ((ContO) conto).p[i_54_]).glass == 1)
			    ((Plane) ((ContO) conto).p[i_54_]).gr
				+= Math.abs((double) f_55_ * 1.5);
		    }
		}
	    }
	    if (i_51_ * i_50_ == -1) {
		int i_57_ = 0;
		int i_58_ = 1;
		for (int i_59_ = 0; i_59_ < ((ContO) conto).npl; i_59_++) {
		    float f_60_ = 0.0F;
		    for (int i_61_ = 0;
			 i_61_ < ((Plane) ((ContO) conto).p[i_59_]).n;
			 i_61_++) {
			if (((Plane) ((ContO) conto).p[i_59_]).wz == 0) {
			    f_60_ = f / 15.0F * ((Record) this).m.random();
			    if (((Math.abs((((Plane) ((ContO) conto).p[i_59_])
					    .oy[i_61_])
					   - (((CarDefine) ((Mad) mad).cd)
					      .flipy[((Mad) mad).cn])
					   - (((Record) this).squash[0]
					      [((Mad) mad).im]))
				  < (((CarDefine) ((Mad) mad).cd).msquash
				     [((Mad) mad).cn]) * 3)
				 || ((((Plane) ((ContO) conto).p[i_59_]).oy
				      [i_61_])
				     < ((((CarDefine) ((Mad) mad).cd).flipy
					 [((Mad) mad).cn])
					+ (((Record) this).squash[0]
					   [((Mad) mad).im]))))
				&& (((Record) this).squash[0][((Mad) mad).im]
				    < (((CarDefine) ((Mad) mad).cd).msquash
				       [((Mad) mad).cn]))) {
				((Plane) ((ContO) conto).p[i_59_]).oy[i_61_]
				    += f_60_;
				i_57_ += f_60_;
				i_58_++;
			    }
			}
		    }
		    if (((Plane) ((ContO) conto).p[i_59_]).glass == 1)
			((Plane) ((ContO) conto).p[i_59_]).gr += 5;
		    else if (f_60_ != 0.0F)
			((Plane) ((ContO) conto).p[i_59_]).bfase += f_60_;
		    if (Math.abs(f_60_) >= 1.0F) {
			((Plane) ((ContO) conto).p[i_59_]).chip = 1;
			((Plane) ((ContO) conto).p[i_59_]).ctmag = f_60_;
		    }
		}
		((Record) this).squash[0][((Mad) mad).im] += i_57_ / i_58_;
	    }
	}
    }
    
    public void regx(int i, float f, ContO conto, Mad mad) {
	if (Math.abs(f) > 100.0F) {
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    for (int i_62_ = 0; i_62_ < ((ContO) conto).npl; i_62_++) {
		float f_63_ = 0.0F;
		for (int i_64_ = 0;
		     i_64_ < ((Plane) ((ContO) conto).p[i_62_]).n; i_64_++) {
		    if (((Plane) ((ContO) conto).p[i_62_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_62_]).ox[i_64_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_62_]).oz[i_64_])
			    < (((CarDefine) ((Mad) mad).cd).clrad
			       [((Mad) mad).cn]))) {
			f_63_ = f / 20.0F * ((Record) this).m.random();
			((Plane) ((ContO) conto).p[i_62_]).oz[i_64_]
			    -= (f_63_
				* ((Record) this).m.sin(((ContO) conto).xz)
				* ((Record) this).m.cos(((ContO) conto).zy));
			((Plane) ((ContO) conto).p[i_62_]).ox[i_64_]
			    += (f_63_
				* ((Record) this).m.cos(((ContO) conto).xz)
				* ((Record) this).m.cos(((ContO) conto).xy));
		    }
		}
		if (f_63_ != 0.0F) {
		    if (Math.abs(f_63_) >= 1.0F) {
			((Plane) ((ContO) conto).p[i_62_]).chip = 1;
			((Plane) ((ContO) conto).p[i_62_]).ctmag = f_63_;
		    }
		    if (!((Plane) ((ContO) conto).p[i_62_]).nocol
			&& ((Plane) ((ContO) conto).p[i_62_]).glass != 1) {
			if (((Plane) ((ContO) conto).p[i_62_]).bfase > 20
			    && (double) (((Plane) ((ContO) conto).p[i_62_]).hsb
					 [1]) > 0.2)
			    ((Plane) ((ContO) conto).p[i_62_]).hsb[1] = 0.2F;
			if (((Plane) ((ContO) conto).p[i_62_]).bfase > 30) {
			    if ((double) (((Plane) ((ContO) conto).p[i_62_])
					  .hsb[2])
				< 0.5)
				((Plane) ((ContO) conto).p[i_62_]).hsb[2]
				    = 0.5F;
			    if ((double) (((Plane) ((ContO) conto).p[i_62_])
					  .hsb[1])
				> 0.1)
				((Plane) ((ContO) conto).p[i_62_]).hsb[1]
				    = 0.1F;
			}
			if (((Plane) ((ContO) conto).p[i_62_]).bfase > 40)
			    ((Plane) ((ContO) conto).p[i_62_]).hsb[1] = 0.05F;
			if (((Plane) ((ContO) conto).p[i_62_]).bfase > 50) {
			    if ((double) (((Plane) ((ContO) conto).p[i_62_])
					  .hsb[2])
				> 0.8)
				((Plane) ((ContO) conto).p[i_62_]).hsb[2]
				    = 0.8F;
			    ((Plane) ((ContO) conto).p[i_62_]).hsb[0] = 0.075F;
			    ((Plane) ((ContO) conto).p[i_62_]).hsb[1] = 0.05F;
			}
			if (((Plane) ((ContO) conto).p[i_62_]).bfase > 60)
			    ((Plane) ((ContO) conto).p[i_62_]).hsb[0] = 0.05F;
			((Plane) ((ContO) conto).p[i_62_]).bfase
			    += Math.abs(f_63_);
			new Color(((Plane) ((ContO) conto).p[i_62_]).c[0],
				  ((Plane) ((ContO) conto).p[i_62_]).c[1],
				  ((Plane) ((ContO) conto).p[i_62_]).c[2]);
			Color color
			    = (Color.getHSBColor
			       (((Plane) ((ContO) conto).p[i_62_]).hsb[0],
				((Plane) ((ContO) conto).p[i_62_]).hsb[1],
				((Plane) ((ContO) conto).p[i_62_]).hsb[2]));
			((Plane) ((ContO) conto).p[i_62_]).c[0]
			    = color.getRed();
			((Plane) ((ContO) conto).p[i_62_]).c[1]
			    = color.getGreen();
			((Plane) ((ContO) conto).p[i_62_]).c[2]
			    = color.getBlue();
		    }
		    if (((Plane) ((ContO) conto).p[i_62_]).glass == 1)
			((Plane) ((ContO) conto).p[i_62_]).gr
			    += Math.abs((double) f_63_ * 1.5);
		}
	    }
	}
    }
    
    public void regz(int i, float f, ContO conto, Mad mad) {
	if (Math.abs(f) > 100.0F) {
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    for (int i_65_ = 0; i_65_ < ((ContO) conto).npl; i_65_++) {
		float f_66_ = 0.0F;
		for (int i_67_ = 0;
		     i_67_ < ((Plane) ((ContO) conto).p[i_65_]).n; i_67_++) {
		    if (((Plane) ((ContO) conto).p[i_65_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_65_]).ox[i_67_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_65_]).oz[i_67_])
			    < (((CarDefine) ((Mad) mad).cd).clrad
			       [((Mad) mad).cn]))) {
			f_66_ = f / 20.0F * ((Record) this).m.random();
			((Plane) ((ContO) conto).p[i_65_]).oz[i_67_]
			    += (f_66_
				* ((Record) this).m.cos(((ContO) conto).xz)
				* ((Record) this).m.cos(((ContO) conto).zy));
			((Plane) ((ContO) conto).p[i_65_]).ox[i_67_]
			    += (f_66_
				* ((Record) this).m.sin(((ContO) conto).xz)
				* ((Record) this).m.cos(((ContO) conto).xy));
		    }
		}
		if (f_66_ != 0.0F) {
		    if (Math.abs(f_66_) >= 1.0F) {
			((Plane) ((ContO) conto).p[i_65_]).chip = 1;
			((Plane) ((ContO) conto).p[i_65_]).ctmag = f_66_;
		    }
		    if (!((Plane) ((ContO) conto).p[i_65_]).nocol
			&& ((Plane) ((ContO) conto).p[i_65_]).glass != 1) {
			if (((Plane) ((ContO) conto).p[i_65_]).bfase > 20
			    && (double) (((Plane) ((ContO) conto).p[i_65_]).hsb
					 [1]) > 0.2)
			    ((Plane) ((ContO) conto).p[i_65_]).hsb[1] = 0.2F;
			if (((Plane) ((ContO) conto).p[i_65_]).bfase > 30) {
			    if ((double) (((Plane) ((ContO) conto).p[i_65_])
					  .hsb[2])
				< 0.5)
				((Plane) ((ContO) conto).p[i_65_]).hsb[2]
				    = 0.5F;
			    if ((double) (((Plane) ((ContO) conto).p[i_65_])
					  .hsb[1])
				> 0.1)
				((Plane) ((ContO) conto).p[i_65_]).hsb[1]
				    = 0.1F;
			}
			if (((Plane) ((ContO) conto).p[i_65_]).bfase > 40)
			    ((Plane) ((ContO) conto).p[i_65_]).hsb[1] = 0.05F;
			if (((Plane) ((ContO) conto).p[i_65_]).bfase > 50) {
			    if ((double) (((Plane) ((ContO) conto).p[i_65_])
					  .hsb[2])
				> 0.8)
				((Plane) ((ContO) conto).p[i_65_]).hsb[2]
				    = 0.8F;
			    ((Plane) ((ContO) conto).p[i_65_]).hsb[0] = 0.075F;
			    ((Plane) ((ContO) conto).p[i_65_]).hsb[1] = 0.05F;
			}
			if (((Plane) ((ContO) conto).p[i_65_]).bfase > 60)
			    ((Plane) ((ContO) conto).p[i_65_]).hsb[0] = 0.05F;
			((Plane) ((ContO) conto).p[i_65_]).bfase
			    += Math.abs(f_66_);
			new Color(((Plane) ((ContO) conto).p[i_65_]).c[0],
				  ((Plane) ((ContO) conto).p[i_65_]).c[1],
				  ((Plane) ((ContO) conto).p[i_65_]).c[2]);
			Color color
			    = (Color.getHSBColor
			       (((Plane) ((ContO) conto).p[i_65_]).hsb[0],
				((Plane) ((ContO) conto).p[i_65_]).hsb[1],
				((Plane) ((ContO) conto).p[i_65_]).hsb[2]));
			((Plane) ((ContO) conto).p[i_65_]).c[0]
			    = color.getRed();
			((Plane) ((ContO) conto).p[i_65_]).c[1]
			    = color.getGreen();
			((Plane) ((ContO) conto).p[i_65_]).c[2]
			    = color.getBlue();
		    }
		    if (((Plane) ((ContO) conto).p[i_65_]).glass == 1)
			((Plane) ((ContO) conto).p[i_65_]).gr
			    += Math.abs((double) f_66_ * 1.5);
		}
	    }
	}
    }
    
    public void chipx(int i, float f, ContO conto, Mad mad) {
	if (Math.abs(f) > 100.0F) {
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    for (int i_68_ = 0; i_68_ < ((ContO) conto).npl; i_68_++) {
		float f_69_ = 0.0F;
		for (int i_70_ = 0;
		     i_70_ < ((Plane) ((ContO) conto).p[i_68_]).n; i_70_++) {
		    if (((Plane) ((ContO) conto).p[i_68_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_68_]).ox[i_70_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_68_]).oz[i_70_])
			    < (((CarDefine) ((Mad) mad).cd).clrad
			       [((Mad) mad).cn])))
			f_69_ = f / 20.0F * ((Record) this).m.random();
		}
		if (f_69_ != 0.0F && Math.abs(f_69_) >= 1.0F) {
		    ((Plane) ((ContO) conto).p[i_68_]).chip = 1;
		    ((Plane) ((ContO) conto).p[i_68_]).ctmag = f_69_;
		}
	    }
	}
    }
    
    public void chipz(int i, float f, ContO conto, Mad mad) {
	if (Math.abs(f) > 100.0F) {
	    if (f > 100.0F)
		f -= 100.0F;
	    if (f < -100.0F)
		f += 100.0F;
	    for (int i_71_ = 0; i_71_ < ((ContO) conto).npl; i_71_++) {
		float f_72_ = 0.0F;
		for (int i_73_ = 0;
		     i_73_ < ((Plane) ((ContO) conto).p[i_71_]).n; i_73_++) {
		    if (((Plane) ((ContO) conto).p[i_71_]).wz == 0
			&& (py(((ContO) conto).keyx[i],
			       ((Plane) ((ContO) conto).p[i_71_]).ox[i_73_],
			       ((ContO) conto).keyz[i],
			       ((Plane) ((ContO) conto).p[i_71_]).oz[i_73_])
			    < (((CarDefine) ((Mad) mad).cd).clrad
			       [((Mad) mad).cn])))
			f_72_ = f / 20.0F * ((Record) this).m.random();
		}
		if (f_72_ != 0.0F && Math.abs(f_72_) >= 1.0F) {
		    ((Plane) ((ContO) conto).p[i_71_]).chip = 1;
		    ((Plane) ((ContO) conto).p[i_71_]).ctmag = f_72_;
		}
	    }
	}
    }
    
    public int py(int i, int i_74_, int i_75_, int i_76_) {
	return (i - i_74_) * (i - i_74_) + (i_75_ - i_76_) * (i_75_ - i_76_);
    }
}
