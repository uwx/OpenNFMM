/* Login - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.TextField;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.util.Date;

public class Login implements Runnable {
	Graphics2D rd;
	xtGraphics xt;
	Medium m;
	FontMetrics ftm;
	ImageObserver ob;
	GameSparker gs;
	int nmsgs = 0;
	int nconf = 0;
	int nfreq = 0;
	int ncreq = 0;
	int fclan = 0;
	int fplayer = 0;
	String clanapv = "";
	boolean justlog = false;
	int cntgame = 0;
	int gamec = -1;
	int groom = 0;
	String gmaker = "";
	String gservern = "";
	Thread connector;
	int fase = 0;
	Socket socket;
	BufferedReader din;
	PrintWriter dout;
	boolean[] pessd = {
		false, false, false, false, false, false
	};
	int[] bx = {
		0, 0, 0, 0, 0, 0
	};
	int[] by = {
		0, 0, 0, 0, 0, 0
	};
	int[] bw = {
		0, 0, 0, 0, 0, 0
	};
	int btn = 0;
	int nflk = 0;
	int ncnt = 0;
	int errcnt = 0;
	int lrgfase = 0;
	String msg = "";
	String lnick = "";
	String lpass = "";
	String lemail = "";
	boolean onf = false;
	boolean nickero = false;
	boolean jflk = false;
	boolean ond = false;
	int opselect = 0;
	int trans = 0;
	int cntcl = 0;
	boolean contrb = false;
	int nservers = 2;
	String[] servers = {
		"multiplayer.needformadness.com", "avenger.needformadness.com",
			"ghostrider.needformadness.com"
	};
	InetAddress[] IPAddress = new InetAddress[3];
	DatagramSocket[] dSocket = new DatagramSocket[3];
	int[] serverdone = {
		-1, -1, -1
	};
	long[] servestart = {
		0L, 0L, 0L
	};
	String[] snames = {
		"Dominion", "Avenger", "Ghostrider"
	};
	boolean socketson = false;
	int srvtrn = 0;
	int[] rmps = {
		0, 0, 0, 0, 0
	};
	int[] rmwt = {
		0, 0, 0, 0, 0
	};
	int recom = 0;
	boolean resofaso = false;
	boolean checknote = false;
	int pend = 0;
	boolean pendb = false;
	boolean gotcai = false;
	int cax = 0;
	int cay = 0;
	boolean btroom = false;
	boolean showtf = false;
	int[] bgmy = {
		0, 400, 800
	};
	int flipo = 0;
	int xrl = 0;
	int xrr = 0;
	boolean onr = false;
	int oxm = 0;
	int oym = 0;
	int lxm = 0;
	int lym = 0;

	public Login(Medium medium, Graphics2D graphics2d,
	xtGraphics var_xtGraphics, GameSparker gamesparker) {
		((Login) this).m = medium;
		((Login) this).rd = graphics2d;
		((Login) this).xt = var_xtGraphics;
		((Login) this).gs = gamesparker;
		if (((xtGraphics)((Login) this).xt).playingame != -1)
		((Login) this).fase = 18;
		if (((xtGraphics)((Login) this).xt).nofull)
		((Login) this).nservers = 1;
	}

	public void inishmulti() {
		((GameSparker)((Login) this).gs).tnick.hide();
		((GameSparker)((Login) this).gs).tnick.enable();
		((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Login) this).gs).tnick.setBackground(color2k(240, 240,
		240));
		((GameSparker)((Login) this).gs).tpass.hide();
		((GameSparker)((Login) this).gs).tpass.enable();
		((GameSparker)((Login) this).gs).tpass.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Login) this).gs).tpass.setBackground(color2k(240, 240,
		240));
		((GameSparker)((Login) this).gs).temail.hide();
		((GameSparker)((Login) this).gs).temail.enable();
		((GameSparker)((Login) this).gs).temail.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Login) this).gs).temail.setBackground(color2k(240, 240, 240));
		((GameSparker)((Login) this).gs).keplo.hide();
		((GameSparker)((Login) this).gs).keplo.enable();
		((GameSparker)((Login) this).gs).keplo.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Login) this).gs).keplo.setBackground(new Color(193, 181, 142));
		((Login) this).gs.requestFocus();
		if (((GameSparker)((Login) this).gs).tnick.getText().equals(""))
		((GameSparker)((Login) this).gs).tnick.setText("Nickname");
		for (int i = 0; i < 6; i++)
		((Login) this).pessd[i] = false;
		((Login) this).nflk = 0;
		((Login) this).ncnt = 0;
		((Login) this).errcnt = 0;
		((Login) this).onf = false;
		((Login) this).ond = false;
		((Login) this).msg = "";
		((Login) this).btroom = false;
		((Login) this).gotcai = false;
		((Medium)((Login) this).m).crs = true;
		((Medium)((Login) this).m).x = -335;
		((Medium)((Login) this).m).y = 0;
		((Medium)((Login) this).m).z = -50;
		((Medium)((Login) this).m).xz = 0;
		((Medium)((Login) this).m).zy = 20;
		((Medium)((Login) this).m).ground = -2000;
		((Login) this).pend = 0;
		((Login) this).pendb = false;
		((Login) this).resofaso = false;
		for (int i = 0; i < ((Login) this).nservers; i++) {
			((Login) this).serverdone[i] = -1;
			((Login) this).servestart[i] = 0L;
		}
		((Login) this).checknote = false;
		if (((xtGraphics)((Login) this).xt).gotlog) {
			((Login) this).checknote = true;
			((Login) this).socketson = false;
			((Login) this).fase = 12;
			((Login) this).connector = new Thread(this);
			((Login) this).connector.start();
		} else {
			((Login) this).msg = "Login to access the multiplayer madness!";
			((GameSparker)((Login) this).gs).tnick.setText(((xtGraphics)((Login) this).xt).nickname);
			((Login) this).fase = 3;
		}
	}

	public void exitfromlobby() {
		if (!((xtGraphics)((Login) this).xt).lan)
		((Login) this).opselect = 0;
		else((Login) this).opselect = 1;
		for (int i = 0; i < ((Login) this).nservers; i++) {
			((Login) this).serverdone[i] = -1;
			((Login) this).servestart[i] = 0L;
		}
		for (int i = 0; i < 6; i++)
		((Login) this).pessd[i] = false;
		((Login) this).gotcai = false;
		((Login) this).btroom = false;
		((Medium)((Login) this).m).crs = true;
		((Medium)((Login) this).m).x = -335;
		((Medium)((Login) this).m).y = 0;
		((Medium)((Login) this).m).z = -50;
		((Medium)((Login) this).m).xz = 0;
		((Medium)((Login) this).m).zy = 20;
		((Medium)((Login) this).m).ground = -2000;
		((Login) this).pend = 0;
		((Login) this).pendb = false;
		((Login) this).gamec = -1;
		((Login) this).socketson = false;
		if (!((xtGraphics)((Login) this).xt).lan) {
			((Login) this).msg = "| Connecting to Servers |";
			((Login) this).trans = 0;
			((Login) this).fase = 13;
			((Login) this).nflk = 0;
		} else((Login) this).fase = 12;
		System.gc();
		((Login) this).connector = new Thread(this);
		((Login) this).connector.start();
	}

	public void endcons() {
		for (int i = 0; i < ((Login) this).nservers; i++) {
			try {
				((Login) this).dSocket[i].close();
				((Login) this).dSocket[i] = null;
			} catch (Exception exception) {
				/* empty */
			}
		}
		try {
			((Login) this).socket.close();
			((Login) this).socket = null;
			((Login) this).din.close();
			((Login) this).din = null;
			((Login) this).dout.close();
			((Login) this).dout = null;
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void checknotifcations() {
		int i = 0;
		int i_0_ = 0;
		int i_1_ = 0;
		int i_2_ = 0;
		int i_3_ = 0;
		String string = "";
		int i_4_ = 0;
		try {
			URL url = (new URL(new StringBuilder().append("http://multiplayer.needformadness.com/profiles/")
				.append(((xtGraphics)((Login) this).xt).nickname).append("/notify.txt?req=").append((int)(Math.random() * 1000.0)).append("").toString()));
			url.openConnection().setConnectTimeout(2000);
			String string_5_ = url.openConnection().getContentType();
			if (string_5_.equals("text/plain")) {
				DataInputStream datainputstream = new DataInputStream(url.openStream());
				String string_6_ = "";
				for (int i_7_ = 0;
				((string_6_ = datainputstream.readLine()) != null && i_7_ < 5);
				i_7_++) {
					string_6_ = string_6_.trim();
					if (i_7_ == 0) {
						for (String string_8_ = getSvalue(string_6_, i); !string_8_.equals("");
						string_8_ = getSvalue(string_6_, i)) {
							if (string_8_.startsWith("clan: ")) i_0_++;
							else if (!string_8_.startsWith("your clan")) i_1_++;
							i++;
						}
					}
					if (i_7_ == 1) {
						boolean bool = false;
						int i_9_;
						try {
							i_9_ = Integer.valueOf(string_6_).intValue();
						} catch (Exception exception) {
							i_9_ = 0;
						}
						i_2_ = i_9_;
					}
					if (i_7_ == 2) {
						boolean bool = false;
						int i_10_;
						try {
							i_10_ = Integer.valueOf(string_6_).intValue();
						} catch (Exception exception) {
							i_10_ = 0;
						}
						i_3_ = i_10_;
					}
					if (i_7_ == 3) string = getSvalue(string_6_, 0);
					if (i_7_ == 4) {
						for (String string_11_ = getSvalue(string_6_, i_4_); !string_11_.equals("");
						string_11_ = getSvalue(string_6_, i_4_))
						i_4_++;
					}
				}
				datainputstream.close();
			}
		} catch (Exception exception) {
			/* empty */
		}
		((Login) this).nmsgs = i;
		((Login) this).fclan = i_0_;
		((Login) this).fplayer = i_1_;
		((Login) this).nfreq = i_2_;
		((Login) this).nconf = i_3_;
		((Login) this).clanapv = string;
		((Login) this).ncreq = i_4_;
	}

	public void gamealert() {
		try {
			((Login) this).socket = new Socket(((Login) this).servers[0], 7061);
			((Login) this).din = new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream()));
			((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
			true);
			((Login) this).dout.println(new StringBuilder().append("101|20|").append(((xtGraphics)((Login) this).xt).nickname).append("|").append(((xtGraphics)((Login) this).xt).nickey).append("|").append(((xtGraphics)((Login) this).xt).servername).append("|").append(((xtGraphics)((Login) this).xt).servport - 7070).append("|").toString());
			String string = ((Login) this).din.readLine();
			((Login) this).socket.close();
			((Login) this).din.close();
			((Login) this).dout.close();
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void checkgamealerts() {
		try {
			((Login) this).socket = new Socket(((Login) this).servers[0], 7061);
			((Login) this).din = new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream()));
			((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
			true);
			((Login) this).dout.println("101|21|");
			String string = ((Login) this).din.readLine();
			if (string != null) {
				int i = getvalue(string, 0);
				if (i != -1 && i != ((Login) this).gamec) {
					String string_12_ = getSvalue(string, 2);
					int i_13_ = getvalue(string, 3);
					boolean bool = false;
					if (!string_12_.equals(((xtGraphics)((Login) this).xt)
						.servername) || i_13_ != (((xtGraphics)((Login) this).xt).servport - 7070)) {
						for (int i_14_ = 0; i_14_ < ((Login) this).nservers;
						i_14_++) {
							if (string_12_.equals(((Login) this).snames[i_14_]) && (((xtGraphics)((Login) this).xt).delays[i_14_]) < 300) bool = true;
						}
					}
					if (bool) {
						((Login) this).gmaker = getSvalue(string, 1);
						if (((Login) this).gmaker.equals(((xtGraphics)
						((Login) this).xt)
							.nickname))
						((Login) this).gmaker = "You";
						((Login) this).groom = i_13_;
						((Login) this).gservern = string_12_;
						((Login) this).gamec = i;
						((Login) this).cntgame = 0;
					}
				}
			}
			((Login) this).socket.close();
			((Login) this).din.close();
			((Login) this).dout.close();
		} catch (Exception exception) {
			/* empty */
		}
	}

	public void run() {
		if (((Login) this).checknote) {
			checknotifcations();
			((Login) this).checknote = false;
		}
		if (((Login) this).fase == 2) {
			((Login) this).gs.setCursor(new Cursor(3));
			int i = -1;
			int i_15_ = -1;
			try {
				((Login) this).socket = new Socket(((Login) this).servers[0], 7061);
				((Login) this).din = (new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream())));
				((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
				true);
				((Login) this).dout.println(new StringBuilder().append("0|").append(((GameSparker)
				((Login) this).gs)
					.tnick.getText())
					.append("|").toString());
				String string = ((Login) this).din.readLine();
				if (string != null) {
					i = getvalue(string, 0);
					if (i == 0) {
						i_15_ = getvalue(string, 1);
						((xtGraphics)((Login) this).xt).hours = getvalue(string, 2);
						((xtGraphics)((Login) this).xt).nickey = getSvalue(string, 3);
					}
				}
				((Login) this).socket.close();
				((Login) this).din.close();
				((Login) this).dout.close();
			} catch (Exception exception) {
				/* empty */
			}
			((GameSparker)((Login) this).gs).tnick.enable();
			if (i == -1) {
				((Login) this).msg = "Unable to connect to any server at this moment.  Please try again later.";
				((Login) this).fase = 1;
			}
			if (i == 0) {
				((xtGraphics)((Login) this).xt).nickname = ((GameSparker)((Login) this).gs).tnick.getText();
				if (i_15_ != -1)
				((xtGraphics)((Login) this).xt).nfreeplays = 0;
				((GameSparker)((Login) this).gs).tnick.hide();
				((GameSparker)((Login) this).gs).tpass.hide();
				((GameSparker)((Login) this).gs).temail.hide();
				((GameSparker)((Login) this).gs).keplo.hide();
				((Login) this).gs.requestFocus();
				((xtGraphics)((Login) this).xt).logged = false;
				((Login) this).fase = 12;
				System.gc();
			}
			if (i == 1) {
				((Login) this).msg = "This Nickname is being used by someone else right now.  Please use another.";
				((Login) this).nickero = true;
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(255, 0, 0));
				((GameSparker)((Login) this).gs).tnick.requestFocus();
				((Login) this).errcnt = 30;
				((Login) this).fase = 1;
			}
			if (i == 2) {
				((Login) this).msg = "Nickname registerd.  Please use another or click 'Login' bellow to login to this Nickname.";
				((Login) this).nickero = true;
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(255, 0, 0));
				((GameSparker)((Login) this).gs).tnick.requestFocus();
				((Login) this).errcnt = 30;
				((Login) this).fase = 1;
			}
			((Login) this).gs.setCursor(new Cursor(0));
		}
		if (((Login) this).fase == 4) {
			((Login) this).gs.setCursor(new Cursor(3));
			int i = -1;
			int i_16_ = -1;
			String string = "";
			try {
				((Login) this).socket = new Socket(((Login) this).servers[0], 7061);
				((Login) this).din = (new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream())));
				((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
				true);
				((Login) this).dout.println(new StringBuilder().append("1|").append(((GameSparker)((Login) this).gs).tnick.getText())
					.append("|").append(((GameSparker)((Login) this).gs).tpass.getText())
					.append("|").toString());
				string = ((Login) this).din.readLine();
				if (string != null) {
					i = getvalue(string, 0);
					if (i == 0 || i == 3 || i > 10 || i == -167) {
						((xtGraphics)((Login) this).xt).nickey = getSvalue(string, 1);
						if (i != -167) {
							((xtGraphics)((Login) this).xt).clan = getSvalue(string, 2);
							((xtGraphics)((Login) this).xt).clankey = getSvalue(string, 3);
						} else {
							((xtGraphics)((Login) this).xt).clan = "";
							((xtGraphics)((Login) this).xt).clankey = "";
							i_16_ = getvalue(string, 2);
							((xtGraphics)((Login) this).xt).hours = getvalue(string, 3);
						}
					}
				}
				((Login) this).socket.close();
				((Login) this).din.close();
				((Login) this).dout.close();
			} catch (Exception exception) {
				/* empty */
			}
			((GameSparker)((Login) this).gs).tnick.enable();
			((GameSparker)((Login) this).gs).tpass.enable();
			((GameSparker)((Login) this).gs).keplo.enable();
			if (i == -1) {
				((Login) this).msg = "Unable to connect to server at this moment.  Please try again later.";
				((Login) this).fase = 3;
			}
			if (i == 0 || i == 3 || i > 10 || i == -167 || i == 111) {
				((xtGraphics)((Login) this).xt).nickname = ((GameSparker)((Login) this).gs).tnick.getText();
				((Login) this).showtf = false;
				((GameSparker)((Login) this).gs).tnick.hide();
				((GameSparker)((Login) this).gs).tpass.hide();
				((GameSparker)((Login) this).gs).temail.hide();
				((GameSparker)((Login) this).gs).keplo.hide();
				((Login) this).gs.requestFocus();
				((Login) this).gs.setloggedcookie();
				((Login) this).btroom = false;
				((xtGraphics)((Login) this).xt).logged = true;
				((xtGraphics)((Login) this).xt).gotlog = true;
				if (i == 0)
				((xtGraphics)((Login) this).xt).acexp = 0;
				if (i > 10)
				((xtGraphics)((Login) this).xt).acexp = i - 10;
				if (i == 3)
				((xtGraphics)((Login) this).xt).acexp = -1;
				if (i == -167) {
					((xtGraphics)((Login) this).xt).logged = false;
					if (i_16_ != -1)
					((xtGraphics)((Login) this).xt).nfreeplays = 0;
				}
				if (((xtGraphics)((Login) this).xt).logged)
				((xtGraphics)((Login) this).xt).backlog = ((xtGraphics)((Login) this).xt).nickname;
				((Login) this).fase = 12;
				((Login) this).justlog = true;
				checknotifcations();
				System.gc();
			}
			if (i == 1) {
				((Login) this).msg = "Sorry.  The Nickname you have entered is incorrect or does not exist.";
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(255, 0, 0));
				((GameSparker)((Login) this).gs).tnick.requestFocus();
				((Login) this).errcnt = 40;
				((Login) this).fase = 3;
			}
			if (i == 2) {
				((Login) this).msg = "Sorry.  The Password you have entered is incorrect.";
				((GameSparker)((Login) this).gs).tpass.setForeground(new Color(255, 0, 0));
				((GameSparker)((Login) this).gs).tpass.requestFocus();
				((Login) this).errcnt = 40;
				((Login) this).fase = 3;
			}
			((Login) this).gs.setCursor(new Cursor(0));
		}
		if (((Login) this).fase == 8) {
			((Login) this).gs.setCursor(new Cursor(3));
			int i = -1;
			try {
				((Login) this).socket = new Socket(((Login) this).servers[0], 7061);
				((Login) this).din = (new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream())));
				((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
				true);
				((Login) this).dout.println(new StringBuilder().append("2|").append(((GameSparker)
				((Login) this).gs)
					.temail.getText().toLowerCase())
					.append("|").toString());
				String string = ((Login) this).din.readLine();
				if (string != null) i = getvalue(string, 0);
				((Login) this).socket.close();
				((Login) this).din.close();
				((Login) this).dout.close();
			} catch (Exception exception) {
				/* empty */
			}
			((GameSparker)((Login) this).gs).temail.enable();
			if (i == -1) {
				((Login) this).msg = "Unable to connect to server at this moment.  Please try again later.";
				((Login) this).fase = 7;
			}
			if (i == 0) {
				((Login) this).showtf = false;
				((GameSparker)((Login) this).gs).temail.hide();
				((Login) this).msg = new StringBuilder().append("Please check your Email: ").append(((GameSparker)((Login) this).gs).temail.getText())
					.append(" to login.").toString();
				((GameSparker)((Login) this).gs).temail.setText("");
				((GameSparker)((Login) this).gs).tnick.setText("");
				((GameSparker)((Login) this).gs).tpass.setText("");
				((Login) this).fase = 3;
			}
			if (i == 1) {
				((Login) this).msg = "Sorry.  This Email Address does not exist in our system!";
				((GameSparker)((Login) this).gs).temail.setForeground(new Color(255, 0, 0));
				((Login) this).errcnt = 40;
				((Login) this).fase = 7;
			}
			((Login) this).gs.setCursor(new Cursor(0));
		}
		if ((((Login) this).fase == 12 || ((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 15) && !((Login) this).socketson) {
			for (int i = 0; i < ((Login) this).nservers; i++) {
				try {
					((Login) this).serverdone[i] = -1;
					((Login) this).IPAddress[i] = InetAddress.getByName(((Login) this).servers[i]);
					((Login) this).dSocket[i] = new DatagramSocket(7001 + i);
				} catch (Exception exception) {
					((Login) this).serverdone[i] = 5;
				}
			}
			((Login) this).srvtrn = 0;
			((Login) this).socketson = true;
		}
		while (((Login) this).fase == 12 || ((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 15) {
			if (((Login) this).srvtrn < ((Login) this).nservers) {
				for ( /**/ ;
				(((Login) this).serverdone[((Login) this).srvtrn] < ((xtGraphics)((Login) this).xt).cntptrys);
				((Login) this).serverdone[((Login) this).srvtrn]++) {
					if (((Login) this).serverdone[((Login) this).srvtrn] == -1)
					((Login) this).serverdone[((Login) this).srvtrn] = 0;
					Date date = new Date();
					((Login) this).servestart[((Login) this).srvtrn] = date.getTime();
					try {
						byte[] is = new byte[4];
						DatagramPacket datagrampacket = new DatagramPacket(is, is.length, (((Login) this).IPAddress[((Login) this).srvtrn]),
						7000);
						String string = new StringBuilder().append("").append(((xtGraphics)((Login) this).xt).nickname)
							.append("|").toString();
						byte[] is_17_ = string.getBytes();
						datagrampacket.setData(is_17_);
						((Login) this).dSocket[((Login) this).srvtrn].send(datagrampacket);
						((Login) this).dSocket[((Login) this).srvtrn].receive(datagrampacket);
						String string_18_ = new String(datagrampacket.getData());
						if (string_18_.startsWith("OK")) {
							date = new Date();
							if (date.getTime() - (((Login) this).servestart[((Login) this).srvtrn]) < (long)(((xtGraphics)((Login) this).xt)
								.delays[((Login) this).srvtrn]))
							((xtGraphics)((Login) this).xt).delays[((Login) this).srvtrn] = (int)(date.getTime() - (((Login) this).servestart[((Login) this).srvtrn]));
						}
					} catch (Exception exception) {
						((xtGraphics)((Login) this).xt).delays[(((Login) this)
							.srvtrn)] = 6000;
						((Login) this).serverdone[((Login) this).srvtrn] = 5;
					}
				}
				((Login) this).srvtrn++;
			} else if (((Login) this).fase == 13) {
				int i = -1;
				boolean bool = false;
				for (int i_19_ = 0; i_19_ < ((Login) this).nservers; i_19_++) {
					if (((xtGraphics)((Login) this).xt).delays[i_19_] < i || i == -1) {
						i = ((xtGraphics)((Login) this).xt).delays[i_19_];
						((Login) this).opselect = i_19_;
					}
					if (((xtGraphics)((Login) this).xt).delays[i_19_] >= 6000) bool = true;
				}
				if (!bool) {
					((xtGraphics)((Login) this).xt).cntptrys -= 2;
					if (((xtGraphics)((Login) this).xt).cntptrys < 1)
					((xtGraphics)((Login) this).xt).cntptrys = 1;
				}
				((Login) this).fase = 14;
			}
			try {
				if (((Login) this).connector != null) {
					/* empty */
				}
				Thread.sleep(5L);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
		if (((Login) this).fase != 12 && ((Login) this).fase != 13 && ((Login) this).fase != 14 && ((Login) this).fase != 15 && ((Login) this).fase != 5 && ((Login) this).socketson) {
			for (int i = 0; i < ((Login) this).nservers; i++) {
				try {
					((Login) this).dSocket[i].close();
					((Login) this).dSocket[i] = null;
				} catch (Exception exception) {
					/* empty */
				}
			}
			((Login) this).socketson = false;
		}
		if (((Login) this).fase == 16 || ((Login) this).fase == 17) {
			boolean bool = false;
			int i = 0;
			int i_20_ = -1;
			((Login) this).recom = 0;
			try {
				((Login) this).socket = new Socket(((xtGraphics)((Login) this).xt).server,
				7067);
				((Login) this).din = (new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream())));
				((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
				true);
			} catch (Exception exception) {
				/* empty */
			}
			while ((((Login) this).fase == 16 || ((Login) this).fase == 17) && i != 3) {
				String string = "";
				if (!bool) {
					try {
						((Login) this).dout.println("10|");
						String string_21_ = ((Login) this).din.readLine();
						if (string_21_ == null) bool = true;
						else string = string_21_;
					} catch (Exception exception) {
						bool = true;
					}
					if (bool) {
						try {
							((Login) this).socket.close();
							((Login) this).socket = null;
							((Login) this).din.close();
							((Login) this).din = null;
							((Login) this).dout.close();
							((Login) this).dout = null;
						} catch (Exception exception) {
							/* empty */
						}
						try {
							((Login) this).socket = new Socket((((xtGraphics)((Login) this).xt)
								.server),
							7067);
							((Login) this).din = new BufferedReader(new InputStreamReader(((Login) this).socket.getInputStream()));
							((Login) this).dout = new PrintWriter(((Login) this).socket.getOutputStream(),
							true);
							((Login) this).dout.println("10|");
							String string_22_ = ((Login) this).din.readLine();
							if (string_22_ != null) bool = false;
							else string = string_22_;
						} catch (Exception exception) {
							bool = true;
						}
					}
					if (bool) {
						try {
							((Login) this).socket.close();
							((Login) this).socket = null;
						} catch (Exception exception) {
							/* empty */
						}
					}
				}
				if (!bool) {
					for (int i_23_ = 0; i_23_ < 5; i_23_++) {
						((Login) this).rmps[i_23_] = getvalue(string, i_23_ * 2);
						((Login) this).rmwt[i_23_] = getvalue(string, 1 + i_23_ * 2);
					}
					int i_24_ = 1000;
					for (int i_25_ = 0; i_25_ < 5; i_25_++) {
						if (Math.abs(((Login) this).rmps[i_25_] - 6) < i_24_) {
							((Login) this).recom = i_25_;
							i_24_ = Math.abs(((Login) this).rmps[i_25_] - 6);
						}
					}
					if (((Login) this).recom != i_20_) {
						((Login) this).opselect = ((Login) this).recom;
						i_20_ = ((Login) this).recom;
					}
					if (((Login) this).fase == 16)
					((Login) this).fase = 17;
				} else {
					((Login) this).msg = "Failed to connect to this Server!";
					i++;
				}
				if (i != 3) {
					try {
						if (((Login) this).connector != null) {
							/* empty */
						}
						Thread.sleep(2000L);
					} catch (InterruptedException interruptedexception) {
						/* empty */
					}
				}
			}
			try {
				((Login) this).socket.close();
				((Login) this).socket = null;
				((Login) this).din.close();
				((Login) this).din = null;
				((Login) this).dout.close();
				((Login) this).dout = null;
			} catch (Exception exception) {
				/* empty */
			}
			if (i == 3)
			((Login) this).resofaso = true;
		}
	}

	public void stopallnow() {
		if (((Login) this).connector != null) {
			((Login) this).connector.stop();
			((Login) this).connector = null;
		}
		endcons();
	}

	public void multimode(ContO[] contos) {
		((Login) this).btn = 0;
		((Login) this).xt.mainbg(4);
		for (int i = 0; i < 3; i++) {
			((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
				.bgmain),
			65, ((Login) this).bgmy[i], null);
			((Login) this).bgmy[i] -= 4;
			if (((Login) this).bgmy[i] <= -400)
			((Login) this).bgmy[i] = 800;
		}
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
		((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bggo, 0,
		0, null);
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		((Login) this).rd.setColor(new Color(0, 0, 0));
		((Login) this).rd.fillRect(65, 425, 670, 25);
		((Login) this).rd.fillRect(0, 0, 65, 450);
		((Login) this).rd.fillRect(735, 0, 65, 450);
		float f = 1.0F - (float)(((Login) this).flipo - 10) / 80.0F;
		if (f > 1.0F) f = 1.0F;
		if (f < 0.0F) f = 0.0F;
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, f));
		if (((Login) this).flipo > 10)
		((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
			.logomadnes),
		96 + (int)(2.0 - Math.random() * 4.0),
		11 + (int)(2.0 - Math.random() * 4.0),
		null);
		else((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
			.logomadnes),
		96, 11, null);
		((Login) this).flipo++;
		if (((Login) this).flipo > 50)
		((Login) this).flipo = 0;
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		drawSbutton(((xtGraphics)((Login) this).xt).exit, 690, 17);
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
		((Login) this).rd.setColor(new Color(203, 227, 253));
		((Login) this).rd.fillRoundRect(319, 83, 180, 96, 20, 20);
		((Login) this).rd.fillRoundRect(173, 83, 132, 32, 20, 20);
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		((Login) this).rd.setColor(color2k(90, 90, 90));
		((Login) this).rd.drawRoundRect(319, 83, 180, 96, 20, 20);
		((Login) this).rd.drawRoundRect(173, 83, 132, 32, 20, 20);
		if (!((Login) this).gotcai) {
			int i = (((Plane)((ContO) contos[(((xtGraphics)((Login) this).xt)
				.sc[0])]).p[0])
				.oz[0]);
			int i_26_ = i;
			int i_27_ = (((Plane)((ContO) contos[(((xtGraphics)((Login) this).xt)
				.sc[0])]).p[0])
				.oy[0]);
			int i_28_ = i_27_;
			for (int i_29_ = 0;
			(i_29_ < (((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]])
				.npl));
			i_29_++) {
				for (int i_30_ = 0;
				i_30_ < ((Plane)
				((ContO) contos[(((xtGraphics)((Login) this).xt)
					.sc[0])]).p[i_29_]).n;
				i_30_++) {
					if (((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt).sc[0])]).p[i_29_]).oz[i_30_] < i) i = ((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt)
						.sc[0])]).p[i_29_]).oz[i_30_];
					if (((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt).sc[0])]).p[i_29_]).oz[i_30_] > i_26_) i_26_ = (((Plane)((ContO) contos[(((xtGraphics)
					((Login) this).xt)
						.sc[0])]).p[i_29_])
						.oz[i_30_]);
					if (((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt).sc[0])]).p[i_29_]).oy[i_30_] < i_27_) i_27_ = (((Plane)((ContO) contos[(((xtGraphics)
					((Login) this).xt)
						.sc[0])]).p[i_29_])
						.oy[i_30_]);
					if (((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt).sc[0])]).p[i_29_]).oy[i_30_] > i_28_) i_28_ = (((Plane)((ContO) contos[(((xtGraphics)
					((Login) this).xt)
						.sc[0])]).p[i_29_])
						.oy[i_30_]);
				}
			}
			((Login) this).cax = (i_26_ + i) / 2;
			((Login) this).cay = (i_28_ + i_27_) / 2;
			((Login) this).gotcai = true;
		}
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).z = 1500;
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).y = 380 - ((Login) this).cay;
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).x = 100 - ((Login) this).cax;
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).zy = 0;
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).xz = -90;
		((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).xy = ((Login) this).pend;
		((Login) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		RenderingHints.VALUE_ANTIALIAS_OFF);
		contos[((xtGraphics)((Login) this).xt).sc[0]].d(((Login) this).rd);
		((Login) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		RenderingHints.VALUE_ANTIALIAS_ON);
		if (!((Login) this).pendb) {
			((Login) this).pend += 2;
			if (((Login) this).pend > 80)
			((Login) this).pendb = true;
		} else {
			((Login) this).pend -= 2;
			if (((Login) this).pend < -10)
			((Login) this).pendb = false;
		}
		((Login) this).rd.setFont(new Font("Arial", 1, 13));
		((Login) this).ftm = ((Login) this).rd.getFontMetrics();
		((Login) this).rd.setColor(new Color(0, 0, 0));
		((Login) this).rd.drawString(((xtGraphics)((Login) this).xt).nickname,
		239 - (((Login) this).ftm.stringWidth(((xtGraphics)((Login) this).xt).nickname) / 2),
		105);
		((Login) this).rd.setColor(color2k(90, 90, 90));
		((Login) this).rd.drawString(new StringBuilder().append("").append(((CarDefine)((xtGraphics)((Login) this).xt).cd).names[((xtGraphics)((Login) this).xt).sc[0]])
			.append("").toString(),
		409 - (((Login) this).ftm.stringWidth(new StringBuilder().append("").append(((CarDefine)((xtGraphics)((Login) this).xt).cd)
			.names[((xtGraphics)((Login) this).xt).sc[0]])
			.append("").toString())) / 2,
		81);
		((Login) this).rd.drawString("Nickname",
		239 - ((Login) this).ftm.stringWidth("Nickname") / 2,
		81);
		drawbutton(((xtGraphics)((Login) this).xt).change, 570, 98);
		drawSbutton(((xtGraphics)((Login) this).xt).logout, 239, 135);
		((Login) this).rd.setColor(new Color(98, 56, 0));
		((Login) this).rd.drawString("Edit my Account",
		239 - (((Login) this).ftm.stringWidth("Edit my Account") / 2),
		168);
		if (((Login) this).ond)
		((Login) this).rd.drawLine(239 - ((Login) this).ftm.stringWidth("Edit my Account") / 2,
		169, (239 - ((Login) this).ftm.stringWidth("Edit my Account") / 2 + ((Login) this).ftm.stringWidth("Edit my Account")),
		169);
		if (((Login) this).fase == 12 || ((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 15) {
			int i = ((Login) this).srvtrn;
			if (i < ((Login) this).nservers && ((Login) this).serverdone[i] != -1) {
				Date date = new Date();
				if (date.getTime() - ((Login) this).servestart[i] > 1500L) {
					if (((Login) this).connector != null) {
						((Login) this).connector.stop();
						((Login) this).connector = null;
					}
					((xtGraphics)((Login) this).xt).delays[i] = 600;
					((Login) this).serverdone[i] = 5;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
			}
		}
		if (((Login) this).fase == 12) {
			if (((xtGraphics)((Login) this).xt).acexp == 0 || ((Login) this).contrb) {
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
				((Login) this).rd.setColor(new Color(203, 227, 253));
				((Login) this).rd.fillRoundRect(205, 225, 390, 120, 20, 20);
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				((Login) this).rd.setColor(color2k(90, 90, 90));
				((Login) this).rd.drawString("Multiplayer Mode",
				400 - (((Login) this).ftm.stringWidth("Multiplayer Mode") / 2),
				220);
				((Login) this).rd.drawRoundRect(205, 225, 390, 120, 20, 20);
				if (((Login) this).opselect == 0 && !((Login) this).pessd[3]) {
					((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
					((Login) this).rd.setColor(new Color(203, 227, 253));
					((Login) this).rd.fillRect(387 - ((xtGraphics)((Login) this).xt).pon.getWidth(((Login) this).ob) / 2,
					242, ((xtGraphics)((Login) this).xt).pon.getWidth(((Login) this).ob) + 26,
					26);
					((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				}
				drawbutton(((xtGraphics)((Login) this).xt).pon, 400, 255);
				if (((Login) this).opselect == 1 && !((Login) this).pessd[4]) {
					((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
					((Login) this).rd.setColor(new Color(203, 227, 253));
					((Login) this).rd.fillRect(387 - ((xtGraphics)((Login) this).xt).pln.getWidth(((Login) this).ob) / 2,
					302, ((xtGraphics)((Login) this).xt).pln.getWidth(((Login) this).ob) + 26,
					26);
					((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				}
				drawbutton(((xtGraphics)((Login) this).xt).pln, 400, 315);
				if (!((xtGraphics)((Login) this).xt).logged) {
					((Login) this).rd.setColor(new Color(30, 70, 110));
					((Login) this).rd.drawString("You can play 5 multiplayer turns per day to try the game with your trial account.", (400 - ((((Login) this).ftm.stringWidth("You can play 1 multiplayer turn per day to try the game with your trial account.")) / 2)),
					368);
					((Login) this).rd.drawString("JK! I\'m hacking, bro! You get 6669 free plays per day!", (400 - ((((Login) this).ftm.stringWidth("JK! I\'m hacking, bro! You get 6669 free plays per day!")) / 2)),
					385);
					drawSbutton(((xtGraphics)((Login) this).xt).upgrade, 400,
					406);
				}
			} else {
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
				((Login) this).rd.setColor(new Color(203, 227, 253));
				((Login) this).rd.fillRoundRect(165, 219, 470, 135, 20, 20);
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				((Login) this).rd.setColor(color2k(90, 90, 90));
				((Login) this).rd.drawRoundRect(165, 219, 470, 135, 20, 20);
				if (((xtGraphics)((Login) this).xt).acexp > 0) {
					((Login) this).rd.setColor(new Color(0, 0, 0));
					((Login) this).rd.drawString(new StringBuilder().append("Dear ").append(((xtGraphics)((Login) this).xt).nickname).append(",").toString(),
					185, 245);
					((Login) this).rd.drawString(new StringBuilder().append("Your account is due to expire in ").append(((xtGraphics)((Login) this).xt).acexp).append(" days.").toString(),
					185, 265);
					((Login) this).rd.drawString("Renew your registration soon!", 185, 295);
					stringbutton("Renew my Account Registration now!", 345,
					332, 0);
					stringbutton("Renew Later", 524, 332, 0);
				}
				if (((xtGraphics)((Login) this).xt).acexp == -1) {
					((Login) this).rd.setColor(new Color(0, 0, 0));
					((Login) this).rd.drawString(new StringBuilder().append("Dear ").append(((xtGraphics)((Login) this).xt).nickname).append(",").toString(),
					185, 245);
					((Login) this).rd.drawString("Your Need for Madness account registration has expired.",
					185, 265);
					((Login) this).rd.drawString("Please renew your registration.", 185, 295);
					stringbutton("Renew my account registration now!", 362,
					332, 0);
					stringbutton("Cancel", 524, 332, 0);
				}
				if (((xtGraphics)((Login) this).xt).acexp == -2) {
					((Login) this).rd.setColor(new Color(0, 0, 0));
					((Login) this).rd.drawString(new StringBuilder().append("Dear ").append(((xtGraphics)((Login) this).xt).nickname).append(",").toString(),
					185, 245);
					((Login) this).rd.drawString("Trial accounts are not allowed to access the downloaded game.",
					185, 265);
					((Login) this).rd.drawString("You can only play the game online using your trial account.",
					185, 295);
					stringbutton("Play the multiplayer online!", 362, 332, 0);
					stringbutton("Cancel", 524, 332, 0);
				}
				if (((xtGraphics)((Login) this).xt).acexp == -3) {
					((Login) this).rd.setColor(new Color(0, 0, 0));
					((Login) this).rd.drawString("Some one else is already logged in the game with your account.",
					185, 245);
					((Login) this).rd.drawString("If you where just in the game then quitted it suddenly, it could just",
					185, 265);
					((Login) this).rd.drawString("be your 'ghost entry', if so please wait a few minutes and try again.",
					185, 285);
					((Login) this).rd.drawString("Otherwise please consider changing your password.",
					185, 305);
					stringbutton("Change Password", 332, 336, 0);
					stringbutton("Try Again", 494, 336, 0);
				}
			}
		}
		if (((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 16 || ((Login) this).fase == 17) {
			if (((Login) this).trans < 40)
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).pon,
			400 - ((xtGraphics)((Login) this).xt).pon.getWidth(((Login) this).ob) / 2,
			255 - (((xtGraphics)((Login) this).xt).pon.getHeight(((Login) this).ob) / 2) - 12 - ((Login) this).trans,
			null);
			else((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).pon,
			400 - ((xtGraphics)((Login) this).xt).pon.getWidth(((Login) this).ob) / 2,
			215 - ((xtGraphics)((Login) this).xt).pon.getHeight(((Login) this).ob) / 2 - 12,
			null);
			if (((Login) this).trans >= 40) {
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
				((Login) this).rd.setColor(new Color(203, 227, 253));
				((Login) this).rd.fillRoundRect(165, 219, 470, 150, 20, 20);
				((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				((Login) this).rd.setColor(color2k(90, 90, 90));
				((Login) this).rd.drawRoundRect(165, 219, 470, 150, 20, 20);
				drawbutton(((xtGraphics)((Login) this).xt).cancel, 583, 395);
				((Login) this).rd.setFont(new Font("Arial", 1, 13));
				((Login) this).ftm = ((Login) this).rd.getFontMetrics();
				if (((Login) this).fase == 13) {
					((Login) this).rd.drawString(((Login) this).msg,
					400 - ((Login) this).ftm.stringWidth(((Login) this).msg) / 2,
					295);
					if (((Login) this).msg.equals(". . . | Connecting to Servers | . . .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = "| Connecting to Servers |";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals(". . | Connecting to Servers | . .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". . . | Connecting to Servers | . . .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals(". | Connecting to Servers | .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". . | Connecting to Servers | . .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals("| Connecting to Servers |") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". | Connecting to Servers | .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).ncnt != 0)
					((Login) this).ncnt--;
				}
				if (((Login) this).fase == 16) {
					((Login) this).rd.drawString(((Login) this).msg,
					400 - ((Login) this).ftm.stringWidth(((Login) this).msg) / 2,
					295);
					if (((Login) this).msg.equals(". . . | Finding Rooms | . . .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = "| Finding Rooms |";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals(". . | Finding Rooms | . .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". . . | Finding Rooms | . . .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals(". | Finding Rooms | .") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". . | Finding Rooms | . .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).msg.equals("| Finding Rooms |") && ((Login) this).ncnt == 0) {
						((Login) this).msg = ". | Finding Rooms | .";
						((Login) this).ncnt = 5;
					}
					if (((Login) this).ncnt != 0)
					((Login) this).ncnt--;
				}
				if (((Login) this).fase == 14) {
					((Login) this).msg = "";
					int i = 0;
					if (!((xtGraphics)((Login) this).xt).nofull) {
						for (int i_31_ = 0; i_31_ < ((Login) this).nservers;
						i_31_++) {
							if (((xtGraphics)((Login) this).xt).delays[i_31_] >= 400) i++;
						}
					}
					if (i != ((Login) this).nservers) {
						boolean bool = false;
						int i_32_ = 0;
						for (int i_33_ = 0; i_33_ < ((Login) this).nservers;
						i_33_++) {
							((Login) this).rd.setColor(new Color(0, 0, 0));
							if (((Login) this).opselect == i_33_) {
								((Login) this).rd.setColor(new Color(98, 56,
								0));
								((Login) this).rd.fillRoundRect(175, (230 + i_33_ * 20),
								450, 20, 14,
								14);
								((Login) this).rd.setColor(new Color(0, 0, 0));
								((Login) this).rd.drawRoundRect(175, (230 + i_33_ * 20),
								450, 20, 14,
								14);
								((Login) this).rd.setColor(color2k(255, 255,
								255));
								if ((((xtGraphics)((Login) this).xt).delays[i_33_]) >= 4000) {
									((Login) this).msg = "Your connection to this server is too slow!";
									i_32_ = 1;
								}
								if ((((xtGraphics)((Login) this).xt).delays[i_33_]) == 6000) {
									((Login) this).msg = "This server is not responding!";
									i_32_ = 1;
								}
								if ((((xtGraphics)((Login) this).xt).delays[i_33_]) < 4000) {
									for (int i_34_ = 0;
									i_34_ < ((Login) this).nservers;
									i_34_++) {
										if (((((xtGraphics)((Login) this).xt)
											.delays[i_34_]) < (((xtGraphics)
										((Login) this).xt)
											.delays[i_33_])) && i_33_ != i_34_) bool = true;
									}
									if (bool)
									((Login) this).msg = "Hacked by Chris.";
									else if ((((xtGraphics)((Login) this).xt)
										.delays[i_33_]) >= 300)
									((Login) this).msg = "Your connection speed is not perfect.  You may encounter delay!";
								}
							}
							((Login) this).rd.drawString("Server Name :", 195,
							245 + i_33_ * 20);
							((Login) this).rd.drawString("|   Delay/Speed :",
							385,
							245 + i_33_ * 20);
							int i_35_ = 0;
							int i_36_ = 0;
							String string = new StringBuilder().append("").append(((xtGraphics)((Login) this).xt).delays[i_33_])
								.append("/").toString();
							if (((xtGraphics)((Login) this).xt).delays[i_33_] < 75) {
								string = new StringBuilder().append(string).append("EXCELENT *****").toString();
								i_35_ = 62;
								i_36_ = 100;
							}
							if ((((xtGraphics)((Login) this).xt).delays[i_33_] >= 75) && (((xtGraphics)((Login) this).xt).delays[i_33_]) < 150) {
								string = new StringBuilder().append(string).append("Perfect ****").toString();
								i_35_ = 62;
								i_36_ = 100;
							}
							if ((((xtGraphics)((Login) this).xt).delays[i_33_] >= 150) && (((xtGraphics)((Login) this).xt).delays[i_33_]) < 250) {
								string = new StringBuilder().append(string).append("Good ***").toString();
								i_35_ = 81;
								i_36_ = 100;
							}
							if ((((xtGraphics)((Login) this).xt).delays[i_33_] >= 250) && (((xtGraphics)((Login) this).xt).delays[i_33_]) < 400) {
								string = new StringBuilder().append(string).append("Acceptable **").toString();
								i_35_ = 100;
								i_36_ = 100;
							}
							if ((((xtGraphics)((Login) this).xt).delays[i_33_] >= 400) && (((xtGraphics)((Login) this).xt).delays[i_33_]) < 600) {
								string = new StringBuilder().append(string).append("Hacked :D").toString();
								i_35_ = 100;
								i_36_ = 100;
							}
							if (((xtGraphics)((Login) this).xt).delays[i_33_] == 6000) string = "Not Responding";
							if (((Login) this).opselect == i_33_) {
								i_35_ *= 2.55F;
								i_36_ *= 2.55F;
							}
							if (i_35_ > 255) i_35_ = 255;
							if (i_35_ < 0) i_35_ = 0;
							if (i_36_ > 255) i_36_ = 255;
							if (i_36_ < 0) i_36_ = 0;
							((Login) this).rd.setColor(new Color(i_35_, i_36_,
							0));
							((Login) this).rd.drawString(new StringBuilder().append("").append(((Login) this).snames[i_33_]).append("").toString(),
							294, 245 + i_33_ * 20);
							((Login) this).rd.drawString(string, 497,
							245 + i_33_ * 20);
						}
						if (!((xtGraphics)((Login) this).xt).logged && (((xtGraphics)((Login) this).xt).nfreeplays - ((xtGraphics)((Login) this).xt).ndisco) >= 5 && i_32_ == 0) {
							((Login) this).msg = "Hacked by Chris, relog to get more free plays!";
							xt.nfreeplays = 0;
							i_32_ = 2;
						}
						if (((xtGraphics)((Login) this).xt).nofull) {
							if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0) {
								((Login) this).rd.setFont(new Font("Arial", 0,
								13));
								((Login) this).ftm = ((Login) this).rd.getFontMetrics();
								((Login) this).rd.setColor(new Color(200, 0,
								0));
								((Login) this).rd.drawString("Warning! You did not allow the game full permissions when you started it.",
								175, 275);
								((Login) this).rd.setColor(new Color(0, 0, 0));
								((Login) this).rd.drawString("(You didn't click 'Run' at the prompt that came up at the start of the game).",
								175, 292);
								((Login) this).rd.drawString("Because of this you will be able to connect to ONLY the game's main server:",
								175, 309);
								((Login) this).rd.drawString(new StringBuilder().append("'").append(((Login) this).snames[0]).append("', which is not necessarily the fastest server you can connect to.")
									.toString(),
								175, 326);
								((Login) this).rd.drawString("Please allow Java full permissions next time to be able to play on all servers!",
								175, 343);
								((Login) this).rd.setFont(new Font("Arial", 1,
								13));
								((Login) this).ftm = ((Login) this).rd.getFontMetrics();
							}
						} else {
							if (i_32_ == 0)
							((Login) this).rd.setColor(new Color(98, 56,
							0));
							if (i_32_ == 1)
							((Login) this).rd.setColor(new Color(200, 0,
							0));
							if (i_32_ == 2)
							((Login) this).rd.setColor(new Color(30, 70,
							110));
							if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0)
							((Login) this).rd.drawString(((Login) this).msg, (400 - (((Login) this).ftm.stringWidth(((Login) this).msg) / 2)),
							360);
							if (((Login) this).nflk != 0)
							((Login) this).nflk--;
						}
					} else {
						if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0) {
							((Login) this).rd.setColor(new Color(200, 0, 0));
							((Login) this).rd.drawString("Sorry.  Your connection is currently not fast enough to play online!", (400 - ((((Login) this).ftm.stringWidth("Sorry.  Your connection is currently not fast enough to play online!")) / 2)),
							242);
						}
						if (((Login) this).nflk != 0)
						((Login) this).nflk--;
						((Login) this).rd.setColor(new Color(0, 0, 0));
						((Login) this).rd.setFont(new Font("Arial", 0, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.drawString("Please make sure you or anyone else using this connection is not slowing",
						181, 265);
						((Login) this).rd.drawString("it down right now by downloading or streaming.",
						181, 282);
						((Login) this).rd.drawString("Also please make sure you don't have any other programs running on your",
						181, 299);
						((Login) this).rd.drawString("computer that maybe consuming your bandwidth.",
						181, 316);
						((Login) this).rd.drawString("Otherwise you may need to upgrade your connection speed to play!",
						181, 333);
						((Login) this).rd.setFont(new Font("Arial", 1, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.drawString("Press 'Cancel' to try again or to try playing a Lan game instead.", (400 - ((((Login) this).ftm.stringWidth("Press 'Cancel' to try again or to try playing a Lan game instead.")) / 2)),
						357);
					}
					drawbutton(((xtGraphics)((Login) this).xt).play, 400,
					395);
				}
				if (((Login) this).fase == 17) {
					int i = 14;
					((Login) this).rd.setColor(new Color(0, 0, 0));
					((Login) this).rd.drawString(new StringBuilder().append(": :   ").append(((xtGraphics)((Login) this).xt).servername)
						.append("   : :").toString(), (400 - (((Login) this).ftm.stringWidth(new StringBuilder().append(": :   ").append(((xtGraphics)((Login) this).xt).servername)
						.append("   : :").toString())) / 2),
					239);
					for (int i_37_ = 0; i_37_ < 5; i_37_++) {
						if (((Login) this).opselect == i_37_) {
							((Login) this).rd.setColor(new Color(98, 56, 0));
							((Login) this).rd.fillRoundRect(300, (230 + i_37_ * 20 + i),
							200, 20, 14, 14);
							((Login) this).rd.setColor(new Color(0, 0, 0));
							((Login) this).rd.drawRoundRect(300, (230 + i_37_ * 20 + i),
							200, 20, 14, 14);
							((Login) this).rd.setColor(color2k(255, 255, 255));
						}
						((Login) this).rd.drawString(new StringBuilder().append("Room ").append(i_37_ + 1).append(" :").toString(),
						329,
						245 + i_37_ * 20 + i);
						((Login) this).rd.drawString(new StringBuilder().append("").append(((Login) this).rmps[i_37_]).append("  Players").toString(),
						471 - (((Login) this).ftm.stringWidth(new StringBuilder().append("").append(((Login) this).rmps[i_37_]).append("  Players").toString())),
						245 + i_37_ * 20 + i);
						if (i_37_ == ((Login) this).recom) {
							if (((Login) this).opselect != i_37_)
							((Login) this).rd.setColor(new Color(125, 200,
							0));
							else((Login) this).rd.setColor(new Color(160, 255,
							0));
						}
						((Login) this).rd.setColor(new Color(0, 0, 0));
					}
					drawbutton(((xtGraphics)((Login) this).xt).play, 400,
					395);
				}
			} else((Login) this).trans += 8;
		}
		if (((Login) this).fase == 15) {
			if (((Login) this).trans < 100)
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).pln,
			400 - ((xtGraphics)((Login) this).xt).pln.getWidth(((Login) this).ob) / 2,
			315 - (((xtGraphics)((Login) this).xt).pln.getHeight(((Login) this).ob) / 2) - 12 - ((Login) this).trans,
			null);
			else((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).pln,
			400 - ((xtGraphics)((Login) this).xt).pln.getWidth(((Login) this).ob) / 2,
			215 - ((xtGraphics)((Login) this).xt).pln.getHeight(((Login) this).ob) / 2 - 12,
			null);
			if (((Login) this).trans >= 100) {
				((Login) this).rd.setColor(color2k(255, 255, 255));
				((Login) this).rd.fillRoundRect(165, 219, 470, 150, 20, 20);
				((Login) this).rd.setColor(new Color(0, 0, 0));
				((Login) this).rd.drawRoundRect(165, 219, 470, 150, 20, 20);
				((Login) this).rd.setFont(new Font("Arial", 1, 13));
				((Login) this).ftm = ((Login) this).rd.getFontMetrics();
				if (((xtGraphics)((Login) this).xt).nofull) {
					if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0) {
						((Login) this).rd.setFont(new Font("Arial", 1, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.setColor(new Color(200, 0, 0));
						((Login) this).rd.drawString("Sorry. You did not allow the game full permissions when you started it.",
						175, 242);
						((Login) this).rd.setFont(new Font("Arial", 0, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.setColor(new Color(0, 0, 0));
						((Login) this).rd.drawString("(You didn't click 'Run' at the prompt that came up at the start of the game).",
						175, 262);
						((Login) this).rd.drawString("Because of this the game will not be able to create LAN connections!",
						175, 288);
						((Login) this).rd.setFont(new Font("Arial", 1, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.drawString("Please restart the game and allow Java full permissions to be able to",
						175, 315);
						((Login) this).rd.drawString("play LAN games!", 175,
						332);
						((Login) this).rd.setFont(new Font("Arial", 0, 13));
						((Login) this).ftm = ((Login) this).rd.getFontMetrics();
						((Login) this).rd.drawString("( Close ALL browser windows including this one then",
						295, 332);
						((Login) this).rd.drawString("start the game again but click 'Run' when asked to 'run this application'. )",
						175, 349);
					}
					if (((Login) this).nflk != 0)
					((Login) this).nflk--;
				} else {
					((Login) this).rd.drawString("Play a multiplayer game across your Local Area Network (LAN).",
					179, 245);
					((Login) this).rd.drawString("Experience the game live with zero delay and 100% real-time action!",
					179, 262);
					((Login) this).rd.setFont(new Font("Arial", 0, 13));
					((Login) this).ftm = ((Login) this).rd.getFontMetrics();
					((Login) this).rd.drawString("This is for if there is more then one computer connected to your network or",
					179, 292);
					((Login) this).rd.drawString("if you are in a computer lab or in an internet caf\u00e9.",
					179, 309);
					((Login) this).rd.drawString("You can also invite your friends to come over with their Laptop PCs or Macs",
					179, 335);
					((Login) this).rd.drawString("to log on to your internet connection/network and play with you!",
					179, 352);
				}
				drawbutton(((xtGraphics)((Login) this).xt).cancel, 583, 395);
				drawbutton(((xtGraphics)((Login) this).xt).play, 400, 395);
			} else((Login) this).trans += 10;
		}
		if (((Login) this).resofaso) {
			((Login) this).resofaso = false;
			if (((Login) this).connector != null) {
				((Login) this).connector.stop();
				((Login) this).connector = null;
			}
			((Login) this).socketson = false;
			((Login) this).msg = "| Connecting to Servers |";
			((Login) this).fase = 13;
			((Login) this).connector = new Thread(this);
			((Login) this).connector.start();
		}
	}

	public void multistart(ContO[] contos, int i, int i_38_, boolean bool) {
		((Login) this).btn = 0;
		((Login) this).xt.mainbg(4);
		for (int i_39_ = 0; i_39_ < 3; i_39_++) {
			((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
				.bgmain),
			65, ((Login) this).bgmy[i_39_], null);
			((Login) this).bgmy[i_39_] -= 4;
			if (((Login) this).bgmy[i_39_] <= -400)
			((Login) this).bgmy[i_39_] = 800;
		}
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
		((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bggo, 0,
		0, null);
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		((Login) this).rd.setColor(new Color(0, 0, 0));
		((Login) this).rd.fillRect(65, 425, 670, 25);
		((Login) this).rd.fillRect(0, 0, 65, 450);
		((Login) this).rd.fillRect(735, 0, 65, 450);
		float f = 1.0F - (float)(((Login) this).flipo - 10) / 80.0F;
		if (f > 1.0F) f = 1.0F;
		if (f < 0.0F) f = 0.0F;
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, f));
		if (((Login) this).flipo > 10)
		((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
			.logomadnes),
		96 + (int)(2.0 - Math.random() * 4.0),
		11 + (int)(2.0 - Math.random() * 4.0),
		null);
		else((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt)
			.logomadnes),
		96, 11, null);
		((Login) this).flipo++;
		if (((Login) this).flipo > 50)
		((Login) this).flipo = 0;
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		int i_40_ = 0;
		if (i != ((Login) this).oxm || i_38_ != ((Login) this).oym) {
			i_40_ = 1;
			((Login) this).oxm = i;
			((Login) this).oym = i_38_;
		}
		if (bool) i_40_ = 2;
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
		((Login) this).rd.drawImage((((xtGraphics)((Login) this).xt).dude[i_40_]),
		87, 76, null);
		((Login) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
		((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).redy, 445,
		153, null);
		drawSbutton(((xtGraphics)((Login) this).xt).exit, 690, 17);
		((Login) this).rd.setFont(new Font("Arial", 1, 13));
		((Login) this).ftm = ((Login) this).rd.getFontMetrics();
		if (((Login) this).fase != 5) {
			((Login) this).rd.setComposite(AlphaComposite.getInstance(3,
			0.25F));
			((Login) this).rd.setColor(new Color(203, 227, 253));
			((Login) this).rd.fillRoundRect(246, 83, 180, 96, 20, 20);
			((Login) this).rd.setComposite(AlphaComposite.getInstance(3,
			1.0F));
			((Login) this).rd.setColor(color2k(90, 90, 90));
			((Login) this).rd.drawString(new StringBuilder().append("").append(((CarDefine)((xtGraphics)((Login) this).xt).cd).names[((xtGraphics)((Login) this).xt).sc[0]])
				.append("").toString(),
			336 - (((Login) this).ftm.stringWidth(new StringBuilder().append("").append(((CarDefine)((xtGraphics)((Login) this).xt).cd)
				.names[((xtGraphics)((Login) this).xt).sc[0]])
				.append("").toString())) / 2,
			81);
			((Login) this).rd.drawRoundRect(246, 83, 180, 96, 20, 20);
			if (!((Login) this).gotcai) {
				int i_41_ = (((Plane)
				((ContO) contos[(((xtGraphics)((Login) this).xt)
					.sc[0])]).p[0])
					.oz[0]);
				int i_42_ = i_41_;
				int i_43_ = (((Plane)
				((ContO) contos[(((xtGraphics)((Login) this).xt)
					.sc[0])]).p[0])
					.oy[0]);
				int i_44_ = i_43_;
				for (int i_45_ = 0;
				i_45_ < ((ContO) contos[(((xtGraphics)((Login) this).xt)
					.sc[0])]).npl;
				i_45_++) {
					for (int i_46_ = 0;
					(i_46_ < ((Plane)
					((ContO) contos[(((xtGraphics)((Login) this).xt)
						.sc[0])]).p[i_45_]).n);
					i_46_++) {
						if (((Plane)
						((ContO) contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oz[i_46_] < i_41_) i_41_ = ((Plane)
						((ContO)
						contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oz[i_46_];
						if (((Plane)
						((ContO) contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oz[i_46_] > i_42_) i_42_ = ((Plane)
						((ContO)
						contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oz[i_46_];
						if (((Plane)
						((ContO) contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oy[i_46_] < i_43_) i_43_ = ((Plane)
						((ContO)
						contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oy[i_46_];
						if (((Plane)
						((ContO) contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oy[i_46_] > i_44_) i_44_ = ((Plane)
						((ContO)
						contos[(((xtGraphics)((Login) this).xt)
							.sc[0])]).p[i_45_]).oy[i_46_];
					}
				}
				((Login) this).cax = (i_42_ + i_41_) / 2;
				((Login) this).cay = (i_44_ + i_43_) / 2;
				((Login) this).gotcai = true;
			}
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).z = 1500;
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).y = 380 - ((Login) this).cay;
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).x = -170 - ((Login) this).cax;
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).zy = 0;
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).xz = -90;
			((ContO) contos[((xtGraphics)((Login) this).xt).sc[0]]).xy = ((Login) this).pend;
			((Login) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, (RenderingHints.VALUE_ANTIALIAS_OFF));
			contos[((xtGraphics)((Login) this).xt).sc[0]].d(((Login) this).rd);
			((Login) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, (RenderingHints.VALUE_ANTIALIAS_ON));
			if (!((Login) this).pendb) {
				((Login) this).pend += 2;
				if (((Login) this).pend > 80)
				((Login) this).pendb = true;
			} else {
				((Login) this).pend -= 2;
				if (((Login) this).pend < -10)
				((Login) this).pendb = false;
			}
			drawbutton(((xtGraphics)((Login) this).xt).change, 497, 98);
		}
		if (((Login) this).fase == 1 || ((Login) this).fase == 2) {
			((Login) this).rd.setColor(new Color(0, 0, 0));
			((Login) this).rd.drawString(((Login) this).msg,
			400 - ((Login) this).ftm.stringWidth(((Login) this).msg) / 2,
			205);
			((Login) this).rd.drawString("Enter a Nickname:", (400 - ((Login) this).ftm.stringWidth("Enter a Nickname:") - 14),
			241);
			if (((Login) this).fase == 2) {
				if (((Login) this).msg.equals(". . . | Checking Nickname | . . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = "| Checking Nickname |";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". . | Checking Nickname | . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . . | Checking Nickname | . . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". | Checking Nickname | .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . | Checking Nickname | . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals("| Checking Nickname |") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". | Checking Nickname | .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).ncnt != 0)
				((Login) this).ncnt--;
				((Login) this).pessd[2] = true;
			}
			if (((Login) this).fase == 1 && !((GameSparker)((Login) this).gs).tnick.isShowing()) {
				((GameSparker)((Login) this).gs).tnick.show();
				((GameSparker)((Login) this).gs).tnick.requestFocus();
				if (((GameSparker)((Login) this).gs).tnick.getText()
					.equals("Nickname"))
				((GameSparker)((Login) this).gs).tnick.select(8, 8);
			}
			if (((Login) this).errcnt != 0) {
				((Login) this).errcnt--;
				if (((Login) this).errcnt == 0)
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0, 0));
			}
			drawbutton(((xtGraphics)((Login) this).xt).play, 400, 285);
			if (((Login) this).nflk > 0) {
				if (((GameSparker)((Login) this).gs).tnick.getText()
					.equals("")) {
					((GameSparker)((Login) this).gs).tnick.setText("Nickname");
					if (((Login) this).nflk == 1)
					((GameSparker)((Login) this).gs).tnick.select(8, 8);
				} else((GameSparker)((Login) this).gs).tnick.setText("");
				((Login) this).nflk--;
			}
			drawbutton(((xtGraphics)((Login) this).xt).login, 400, 340);
			drawbutton(((xtGraphics)((Login) this).xt).register, 400, 395);
			((Login) this).gs.movefield((((GameSparker)((Login) this).gs)
				.tnick),
			400, 225, 129, 23);
			while (((Login) this).ftm.stringWidth(((GameSparker)
			((Login) this).gs)
				.tnick.getText()) > 86) {
				((GameSparker)((Login) this).gs).tnick.setText(((GameSparker)((Login) this).gs).tnick.getText()
					.substring(0, ((GameSparker)((Login) this).gs).tnick.getText()
					.length() - 1));
				((GameSparker)((Login) this).gs).tnick.select(((GameSparker)((Login) this).gs).tnick.getText()
					.length(), ((GameSparker)((Login) this).gs).tnick.getText()
					.length());
			}
			if (!((GameSparker)((Login) this).gs).tnick.getText()
				.equals(((Login) this).lnick)) {
				fixtext(((GameSparker)((Login) this).gs).tnick);
				((Login) this).lnick = ((GameSparker)((Login) this).gs).tnick.getText();
			}
			if (((Login) this).xt.msgcheck(((GameSparker)((Login) this).gs)
				.tnick.getText()))
			((GameSparker)((Login) this).gs).tnick.setText("");
			if (((GameSparker)((Login) this).gs).tnick.getText().toLowerCase().indexOf("madbot") != -1)
			((GameSparker)((Login) this).gs).tnick.setText("");
		}
		if (((Login) this).fase == 3 || ((Login) this).fase == 4) {
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).ntrg,
			97, 388, null);
			((Login) this).rd.setComposite(AlphaComposite.getInstance(3,
			0.25F));
			((Login) this).rd.setColor(new Color(203, 227, 253));
			((Login) this).rd.fillRoundRect(246, 212, 308, 142, 20, 20);
			((Login) this).rd.setComposite(AlphaComposite.getInstance(3,
			1.0F));
			((Login) this).rd.setColor(color2k(90, 90, 90));
			((Login) this).rd.drawRoundRect(246, 212, 308, 142, 20, 20);
			((Login) this).rd.setColor(new Color(0, 0, 0));
			if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0)
			((Login) this).rd.drawString(((Login) this).msg,
			400 - (((Login) this).ftm.stringWidth(((Login) this).msg) / 2),
			205);
			if (((Login) this).nflk != 0)
			((Login) this).nflk--;
			((Login) this).rd.drawString("Nickname:",
			376 - ((Login) this).ftm.stringWidth("Nickname:") - 14, 237);
			((Login) this).rd.drawString("Password:",
			376 - ((Login) this).ftm.stringWidth("Password:") - 14, 267);
			if (((Login) this).fase == 4) {
				if (((Login) this).msg.equals(". . . | Logging In | . . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = "| Logging In |";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". . | Logging In | . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . . | Logging In | . . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". | Logging In | .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . | Logging In | . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals("| Logging In |") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". | Logging In | .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).ncnt != 0)
				((Login) this).ncnt--;
				((Login) this).pessd[2] = true;
			}
			if (((Login) this).fase == 3) {
				((Login) this).showtf = true;
				if (!((GameSparker)((Login) this).gs).applejava) {
					if (!((GameSparker)((Login) this).gs).tpass.isShowing()) {
						((GameSparker)((Login) this).gs).tpass.show();
						if (!((GameSparker)((Login) this).gs).tnick.getText().equals(""))
						((GameSparker)((Login) this).gs).tpass.requestFocus();
					}
					if (!((GameSparker)((Login) this).gs).tnick.isShowing()) {
						((GameSparker)((Login) this).gs).tnick.show();
						if (((GameSparker)((Login) this).gs).tnick.getText().equals(""))
						((GameSparker)((Login) this).gs).tnick.requestFocus();
					}
				}
			}
			if (((Login) this).errcnt != 0) {
				((Login) this).errcnt--;
				if (((Login) this).errcnt == 0) {
					((GameSparker)((Login) this).gs).tpass.setText("");
					((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0, 0));
					((GameSparker)((Login) this).gs).tpass.setForeground(new Color(0, 0, 0));
				}
			}
			drawbutton(((xtGraphics)((Login) this).xt).login, 400, 315);
			if (((Login) this).onf)
			((Login) this).rd.setColor(color2k(0, 72, 255));
			else((Login) this).rd.setColor(color2k(120, 120, 120));
			((Login) this).rd.setFont(new Font("Arial", 1, 11));
			((Login) this).ftm = ((Login) this).rd.getFontMetrics();
			((Login) this).rd.drawString("Forgot your nickname or password?",
			400 - (((Login) this).ftm.stringWidth("Forgot your nickname or password?") / 2),
			345);
			((Login) this).rd.setColor(new Color(0, 0, 0));
			((Login) this).rd.setFont(new Font("Arial", 1, 12));
			((Login) this).ftm = ((Login) this).rd.getFontMetrics();
			String string = "Register a full account here!";
			((Login) this).xrl = 400 - ((Login) this).ftm.stringWidth(string) / 2;
			((Login) this).xrr = ((Login) this).xrl + ((Login) this).ftm.stringWidth(string);
			((Login) this).rd.drawString(string, ((Login) this).xrl, 371);
			((Login) this).rd.drawLine(((Login) this).xrl, 372, ((Login) this).xrr, 372);
			drawbutton(((xtGraphics)((Login) this).xt).register, 400, 395);
			((Login) this).gs.movefieldd((((GameSparker)((Login) this).gs)
				.tnick),
			376, 221, 129, 23, ((Login) this).showtf);
			if (!((GameSparker)((Login) this).gs).tnick.getText()
				.equals(((Login) this).lnick)) {
				fixtext(((GameSparker)((Login) this).gs).tnick);
				((Login) this).lnick = ((GameSparker)((Login) this).gs).tnick.getText();
			}
			((Login) this).gs.movefieldd((((GameSparker)((Login) this).gs)
				.tpass),
			376, 251, 129, 23, ((Login) this).showtf);
			if (!((GameSparker)((Login) this).gs).tpass.getText()
				.equals(((Login) this).lpass)) {
				fixtext(((GameSparker)((Login) this).gs).tpass);
				((Login) this).lpass = ((GameSparker)((Login) this).gs).tpass.getText();
			}
			if (((Login) this).fase == 3 && ((!((GameSparker)((Login) this).gs).tpass.getText()
				.equals("") && !((GameSparker)((Login) this).gs).tnick.getText()
				.equals("")) || !((GameSparker)((Login) this).gs).applejava) && !((GameSparker)((Login) this).gs).keplo.isShowing())
			((GameSparker)((Login) this).gs).keplo.show();
			((Login) this).gs.movefield((((GameSparker)((Login) this).gs)
				.keplo),
			376, 275, 129, 23);
		}
		if (((Login) this).fase == 5) {
			((Login) this).rd.setColor(new Color(0, 0, 0));
			((Login) this).rd.drawString("Nickname:",
			376 - ((Login) this).ftm.stringWidth("Nickname:") - 14, 141);
			((Login) this).gs.movefield((((GameSparker)((Login) this).gs)
				.tnick),
			376, 125, 129, 23);
			while (((Login) this).ftm.stringWidth(((GameSparker)
			((Login) this).gs)
				.tnick.getText()) > 86) {
				((GameSparker)((Login) this).gs).tnick.setText(((GameSparker)((Login) this).gs).tnick.getText()
					.substring(0, ((GameSparker)((Login) this).gs).tnick.getText()
					.length() - 1));
				((GameSparker)((Login) this).gs).tnick.select(((GameSparker)((Login) this).gs).tnick.getText()
					.length(), ((GameSparker)((Login) this).gs).tnick.getText()
					.length());
			}
			if (!((GameSparker)((Login) this).gs).tnick.getText()
				.equals(((Login) this).lnick)) {
				fixtext(((GameSparker)((Login) this).gs).tnick);
				((Login) this).lnick = ((GameSparker)((Login) this).gs).tnick.getText();
			}
			if (!((GameSparker)((Login) this).gs).tnick.isShowing())
			((GameSparker)((Login) this).gs).tnick.show();
			drawbutton(((xtGraphics)((Login) this).xt).register, 400, 325);
			drawbutton(((xtGraphics)((Login) this).xt).cancel, 400, 375);
		}
		if (((Login) this).fase == 7 || ((Login) this).fase == 8) {
			((Login) this).rd.setColor(new Color(0, 0, 0));
			if (((Login) this).nflk % 4 != 0 || ((Login) this).nflk == 0)
			((Login) this).rd.drawString(((Login) this).msg,
			400 - (((Login) this).ftm.stringWidth(((Login) this).msg) / 2),
			205);
			if (((Login) this).nflk != 0)
			((Login) this).nflk--;
			((Login) this).rd.drawString("Your Email:", (344 - ((Login) this).ftm.stringWidth("Your Email:") - 14),
			241);
			if (((Login) this).fase == 8) {
				if (((Login) this).msg.equals(". . . | Checking Email | . . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = "| Checking Email |";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". . | Checking Email | . .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . . | Checking Email | . . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals(". | Checking Email | .") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". . | Checking Email | . .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).msg.equals("| Checking Email |") && ((Login) this).ncnt == 0) {
					((Login) this).msg = ". | Checking Email | .";
					((Login) this).ncnt = 5;
				}
				if (((Login) this).ncnt != 0)
				((Login) this).ncnt--;
				((Login) this).pessd[2] = true;
			}
			if (((Login) this).fase == 7) {
				((Login) this).showtf = true;
				if (!((GameSparker)((Login) this).gs).applejava && !((GameSparker)((Login) this).gs).temail.isShowing()) {
					((GameSparker)((Login) this).gs).temail.show();
					((GameSparker)((Login) this).gs).temail.requestFocus();
				}
			}
			if (((Login) this).errcnt != 0) {
				((Login) this).errcnt--;
				if (((Login) this).errcnt == 0)
				((GameSparker)((Login) this).gs).temail.setForeground(new Color(0, 0, 0));
			}
			drawbutton(((xtGraphics)((Login) this).xt).sdets, 400, 280);
			drawbutton(((xtGraphics)((Login) this).xt).cancel, 400, 375);
			((Login) this).gs.movefieldd((((GameSparker)((Login) this).gs)
				.temail),
			344, 225, 199, 23, ((Login) this).showtf);
			if (!((GameSparker)((Login) this).gs).temail.getText()
				.equals(((Login) this).lemail)) {
				fixtext(((GameSparker)((Login) this).gs).temail);
				((Login) this).lemail = ((GameSparker)((Login) this).gs).temail.getText();
			}
		}
	}

	public void ctachm(int i, int i_47_, int i_48_, Control control,
	Lobby lobby) {
		int i_49_ = -1;
		if (((Login) this).fase != 2 && ((Login) this).fase != 4 && ((Login) this).fase != 6 && ((Login) this).fase != 8 && ((Login) this).fase != 9) {
			for (int i_50_ = 0; i_50_ < ((Login) this).btn; i_50_++) {
				if ((Math.abs(i - ((Login) this).bx[i_50_]) < ((Login) this).bw[i_50_] / 2 + 12) && Math.abs(i_47_ - ((Login) this).by[i_50_]) < 14 && (i_48_ == 1 || i_48_ == 11))
				((Login) this).pessd[i_50_] = true;
				else((Login) this).pessd[i_50_] = false;
				if ((Math.abs(i - ((Login) this).bx[i_50_]) < ((Login) this).bw[i_50_] / 2 + 12) && Math.abs(i_47_ - ((Login) this).by[i_50_]) < 14 && i_48_ <= -1) {
					((GameSparker)((Login) this).gs).mouses = 0;
					i_49_ = i_50_;
				}
				if (((Login) this).fase == 12 && (Math.abs(i - ((Login) this).bx[i_50_]) < ((Login) this).bw[i_50_] / 2 + 12) && Math.abs(i_47_ - ((Login) this).by[i_50_]) < 14 && (i_50_ == 3 || i_50_ == 4) && (i != ((Login) this).lxm || i_47_ != ((Login) this).lym))
				((Login) this).opselect = i_50_ - 3;
			}
		}
		if (i_49_ == 0) {
			((GameSparker)((Login) this).gs).tnick.hide();
			((GameSparker)((Login) this).gs).tpass.hide();
			((GameSparker)((Login) this).gs).keplo.hide();
			((GameSparker)((Login) this).gs).temail.hide();
			((Login) this).gs.requestFocus();
			((xtGraphics)((Login) this).xt).fase = 24;
		}
		if (i_49_ == 1 && ((Login) this).fase != 5) {
			((GameSparker)((Login) this).gs).tnick.hide();
			((GameSparker)((Login) this).gs).tpass.hide();
			((GameSparker)((Login) this).gs).keplo.hide();
			((GameSparker)((Login) this).gs).temail.hide();
			((Login) this).gs.requestFocus();
			((xtGraphics)((Login) this).xt).fase = 23;
		}
		int i_51_ = 2;
		if (((Login) this).fase == 12 || ((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 15 || ((Login) this).fase == 16 || ((Login) this).fase == 17) {
			if (i > 176 && i_47_ > 152 && i < 296 && i_47_ < 174) {
				if (!((Login) this).ond) {
					((Login) this).ond = true;
					((Login) this).gs.setCursor(new Cursor(12));
				}
			} else if (((Login) this).ond) {
				((Login) this).ond = false;
				((Login) this).gs.setCursor(new Cursor(0));
			}
			if (((Login) this).cntcl == 0) {
				if (((Login) this).ond && i_48_ == 11) {
					((Login) this).gs.editlink(((xtGraphics)
					((Login) this).xt).nickname,
					false);
					((Login) this).cntcl = 10;
				}
			} else((Login) this).cntcl--;
			if (i_49_ == i_51_) {
				i_49_ = -1;
				if (((xtGraphics)((Login) this).xt).sc[0] >= 16) {
					((xtGraphics)((Login) this).xt).sc[0] = 15;
					((Login) this).gotcai = false;
				}
				((xtGraphics)((Login) this).xt).logged = false;
				((xtGraphics)((Login) this).xt).gotlog = false;
				((GameSparker)((Login) this).gs).keplo.setState(false);
				((Login) this).gs.setloggedcookie();
				((CarDefine)((xtGraphics)((Login) this).xt).cd).msloaded = 0;
				((CarDefine)((xtGraphics)((Login) this).xt).cd).lastload = 0;
				((Login) this).msg = "Login to access the multiplayer madness!";
				((Login) this).fase = 3;
			}
		}
		if (((Login) this).fase == 12) {
			if (((xtGraphics)((Login) this).xt).acexp == 0 || ((Login) this).contrb) {
				if (((Control) control).up) {
					((Login) this).opselect--;
					if (((Login) this).opselect == -1)
					((Login) this).opselect = 1;
					((Control) control).up = false;
				}
				if (((Control) control).down) {
					((Login) this).opselect++;
					if (((Login) this).opselect == 2)
					((Login) this).opselect = 0;
					((Control) control).down = false;
				}
				if (((Control) control).enter) {
					i_49_ = ((Login) this).opselect + 3;
					((Control) control).enter = false;
				}
				if (i_49_ == i_51_ + 1) {
					((Login) this).msg = "| Connecting to Servers |";
					((Login) this).opselect = 0;
					((Login) this).trans = 0;
					((Login) this).fase = 13;
					((Login) this).nflk = 0;
					i_49_ = -1;
				}
				if (i_49_ == i_51_ + 2) {
					((Login) this).trans = 0;
					((Login) this).fase = 15;
					i_49_ = -1;
				}
				if (!((xtGraphics)((Login) this).xt).logged && i_49_ == i_51_ + 3)
				((Login) this).gs.editlink(((xtGraphics)
				((Login) this).xt).nickname,
				true);
			} else {
				if (((xtGraphics)((Login) this).xt).acexp > 0) {
					if (i_49_ == i_51_ + 1 || ((Control) control).enter) {
						((Login) this).gs.editlink((((xtGraphics)
						((Login) this).xt)
							.nickname),
						false);
						i_49_ = -1;
					}
					if (i_49_ == i_51_ + 2) {
						((Login) this).opselect = 0;
						((Login) this).contrb = true;
						i_49_ = -1;
					}
				}
				if (((xtGraphics)((Login) this).xt).acexp == -1) {
					if (i_49_ == i_51_ + 1 || ((Control) control).enter) {
						((Login) this).gs.editlink((((xtGraphics)
						((Login) this).xt)
							.nickname),
						false);
						i_49_ = -1;
					}
					if (i_49_ == i_51_ + 2) {
						i_49_ = -1;
						if (((xtGraphics)((Login) this).xt).sc[0] >= 16) {
							((xtGraphics)((Login) this).xt).sc[0] = 15;
							((Login) this).gotcai = false;
						}
						((xtGraphics)((Login) this).xt).logged = false;
						((CarDefine)((xtGraphics)((Login) this).xt).cd)
							.lastload = 0;
						((Login) this).msg = "Login to access the multiplayer madness!";
						((Login) this).fase = 3;
					}
				}
				if (((xtGraphics)((Login) this).xt).acexp == -2) {
					if (i_49_ == i_51_ + 1 || ((Control) control).enter) {
						((Login) this).gs.multlink();
						i_49_ = -1;
					}
					if (i_49_ == i_51_ + 2) {
						i_49_ = -1;
						if (((xtGraphics)((Login) this).xt).sc[0] >= 16) {
							((xtGraphics)((Login) this).xt).sc[0] = 15;
							((Login) this).gotcai = false;
						}
						((xtGraphics)((Login) this).xt).logged = false;
						((CarDefine)((xtGraphics)((Login) this).xt).cd)
							.lastload = 0;
						((Login) this).msg = "Login to access the multiplayer madness!";
						((Login) this).fase = 3;
					}
				}
				if (((xtGraphics)((Login) this).xt).acexp == -3) {
					if (i_49_ == i_51_ + 1 || ((Control) control).enter) {
						((Login) this).gs.editlink((((xtGraphics)
						((Login) this).xt)
							.nickname),
						false);
						i_49_ = -1;
					}
					if (i_49_ == i_51_ + 2) {
						i_49_ = -1;
						if (((xtGraphics)((Login) this).xt).sc[0] >= 16) {
							((xtGraphics)((Login) this).xt).sc[0] = 15;
							((Login) this).gotcai = false;
						}
						((xtGraphics)((Login) this).xt).logged = false;
						((CarDefine)((xtGraphics)((Login) this).xt).cd)
							.lastload = 0;
						((Login) this).msg = "Login to access the multiplayer madness!";
						((Login) this).fase = 3;
					}
				}
			}
		}
		if (((Login) this).fase == 13 || ((Login) this).fase == 14 || ((Login) this).fase == 15 || ((Login) this).fase == 16 || ((Login) this).fase == 17) {
			if (((Control) control).exit) i_49_ = 3;
			if (i_49_ == i_51_ + 1) {
				if (((Login) this).fase == 15)
				((Login) this).opselect = 1;
				else((Login) this).opselect = 0;
				if (((Login) this).fase == 16 || ((Login) this).fase == 17) {
					if (((Login) this).connector != null) {
						((Login) this).connector.stop();
						((Login) this).connector = null;
					}
					try {
						((Login) this).socket.close();
						((Login) this).socket = null;
						((Login) this).din.close();
						((Login) this).din = null;
						((Login) this).dout.close();
						((Login) this).dout = null;
					} catch (Exception exception) {
						/* empty */
					}
					((Login) this).fase = 12;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
				if (((Login) this).fase == 14) {
					if (((Login) this).connector != null) {
						((Login) this).connector.stop();
						((Login) this).connector = null;
					}
					for (int i_52_ = 0; i_52_ < ((Login) this).nservers;
					i_52_++) {
						try {
							((Login) this).dSocket[i_52_].close();
							((Login) this).dSocket[i_52_] = null;
						} catch (Exception exception) {
							/* empty */
						}
					}
					((Login) this).socketson = false;
					((Login) this).fase = 12;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
				((Login) this).fase = 12;
				((Login) this).gs.setCursor(new Cursor(0));
			}
		}
		if (((Login) this).fase == 14) {
			if (((Control) control).enter) {
				i_49_ = 4;
				((Login) this).pessd[4] = true;
			}
			if (((Control) control).up) {
				((Login) this).opselect--;
				if (((Login) this).opselect == -1)
				((Login) this).opselect = ((Login) this).nservers - 1;
				((Control) control).up = false;
			}
			if (((Control) control).down) {
				((Login) this).opselect++;
				if (((Login) this).opselect == ((Login) this).nservers)
				((Login) this).opselect = 0;
				((Control) control).down = false;
			}
			for (int i_53_ = 0; i_53_ < ((Login) this).nservers; i_53_++) {
				if (i > 175 && i_47_ > 230 + i_53_ * 20 && i < 625 && i_47_ < 250 + i_53_ * 20 && i_48_ == 1)
				((Login) this).opselect = i_53_;
			}
			if (i_49_ == i_51_ + 2) {
				if ((((xtGraphics)((Login) this).xt).delays[((Login) this).opselect]) >= 400 && !((xtGraphics)((Login) this).xt).nickname.equals("Fyre"))
				((Login) this).nflk = 30;
				else {
					((xtGraphics)((Login) this).xt).server = ((Login) this).servers[((Login) this).opselect];
					((xtGraphics)((Login) this).xt).servername = ((Login) this).snames[((Login) this).opselect];
					((Login) this).msg = "| Finding Rooms |";
					((Login) this).opselect = 0;
					((Login) this).nflk = 0;
					i_49_ = -1;
					((Login) this).fase = 16;
				}
			}
		}
		if (((Login) this).fase == 15) {
			if (((Control) control).enter) {
				i_49_ = 4;
				((Login) this).pessd[4] = true;
			}
			if (i_49_ == i_51_ + 2) {
				if (((xtGraphics)((Login) this).xt).nofull)
				((Login) this).nflk = 30;
				else {
					((xtGraphics)((Login) this).xt).server = ((Login) this).servers[1];
					((xtGraphics)((Login) this).xt).servername = ((Login) this).snames[1];
					((xtGraphics)((Login) this).xt).servport = 7067;
					((xtGraphics)((Login) this).xt).lan = true;
					i_49_ = -1;
					((Login) this).fase = 18;
					((Lobby) lobby).fase = 0;
				}
			}
		}
		if (((Login) this).fase == 17) {
			if (((Control) control).enter) {
				i_49_ = 4;
				((Login) this).pessd[4] = true;
			}
			if (((Control) control).up) {
				((Login) this).opselect--;
				if (((Login) this).opselect == -1)
				((Login) this).opselect = 4;
				((Control) control).up = false;
			}
			if (((Control) control).down) {
				((Login) this).opselect++;
				if (((Login) this).opselect == 5)
				((Login) this).opselect = 0;
				((Control) control).down = false;
			}
			for (int i_54_ = 0; i_54_ < 5; i_54_++) {
				if (i > 175 && i_47_ > 230 + i_54_ * 20 + 14 && i < 625 && i_47_ < 250 + i_54_ * 20 + 14 && i_48_ == 1)
				((Login) this).opselect = i_54_;
			}
			if (i_49_ == i_51_ + 2) {
				((xtGraphics)((Login) this).xt).servport = 7071 + ((Login) this).opselect;
				((xtGraphics)((Login) this).xt).lan = false;
				i_49_ = -1;
				((Login) this).fase = 18;
				((Lobby) lobby).fase = 0;
			}
		}
		if (((Login) this).fase == 3) {
			if (i > 295 && i_47_ > 334 && i < 505 && i_47_ < 348) {
				if (!((Login) this).onf) {
					((Login) this).onf = true;
					((Login) this).gs.setCursor(new Cursor(12));
				}
			} else if (((Login) this).onf) {
				((Login) this).onf = false;
				((Login) this).gs.setCursor(new Cursor(0));
			}
			if (((Login) this).onf && i_48_ == 11) {
				((Login) this).msg = "Please enter your Email Address to recover your account details.";
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0, 0));
				((GameSparker)((Login) this).gs).tpass.setForeground(new Color(0, 0, 0));
				((GameSparker)((Login) this).gs).tnick.hide();
				((GameSparker)((Login) this).gs).tpass.hide();
				((GameSparker)((Login) this).gs).keplo.hide();
				((Login) this).onf = false;
				((Login) this).gs.setCursor(new Cursor(0));
				((Login) this).fase = 7;
			}
			if (i > ((Login) this).xrl && i < ((Login) this).xrr && i_47_ > 360 && i_47_ < 373) {
				if (!((Login) this).onr) {
					((Login) this).onr = true;
					((Login) this).gs.setCursor(new Cursor(12));
				}
			} else if (((Login) this).onr) {
				((Login) this).onr = false;
				((Login) this).gs.setCursor(new Cursor(0));
			}
			if (((Login) this).onr && i_48_ == 11) {
				((Login) this).gs.reglink();
				((GameSparker)((Login) this).gs).mouses = 0;
			}
		}
		if (((Login) this).fase == 1) {
			if (((Control) control).enter) {
				i_49_ = 2;
				((Login) this).pessd[2] = true;
			}
			if (i_49_ == 2) {
				if (((GameSparker)((Login) this).gs).tnick.getText()
					.equals("Fyre") || ((GameSparker)((Login) this).gs).tnick.getText()
					.equals("Nickname") || ((GameSparker)((Login) this).gs).tnick.getText()
					.equals("")) {
					((Login) this).msg = "Type in any Nickname to play...";
					((GameSparker)((Login) this).gs).tnick.setText("Nickname");
					((Login) this).nflk = 30;
				} else {
					((Login) this).msg = "| Checking Nickname |";
					((GameSparker)((Login) this).gs).tnick.disable();
					((Login) this).fase = 2;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
			}
			if (i_49_ == 3) {
				if (((GameSparker)((Login) this).gs).tnick.getText()
					.equals("Nickname") || ((Login) this).msg.startsWith("This"))
				((GameSparker)((Login) this).gs).tnick.setText("");
				((Login) this).msg = "Login to access the multiplayer madness!";
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0, 0));
				((Login) this).fase = 3;
				i_49_ = -1;
			}
			if (i_49_ == 4) {
				if (((Login) this).nickero || ((GameSparker)((Login) this).gs).tnick.getText()
					.equals("Nickname")) {
					((GameSparker)((Login) this).gs).tnick.setText("");
					((Login) this).nickero = false;
				}
				((GameSparker)((Login) this).gs).tnick.setForeground(new Color(0, 0, 0));
				((Login) this).gs.reglink();
			}
		}
		if (((Login) this).fase == 3) {
			if (((Control) control).enter || ((xtGraphics)((Login) this).xt).autolog) {
				i_49_ = 2;
				((Login) this).pessd[2] = true;
				((xtGraphics)((Login) this).xt).autolog = false;
			}
			if (((Control) control).exit) i_49_ = 3;
			if (i_49_ == 2) {
				if (((GameSparker)((Login) this).gs).tnick.getText()
					.equals("")) {
					((Login) this).msg = "Enter your Nickname!";
					((Login) this).nflk = 30;
				} else if (((GameSparker)((Login) this).gs).tpass.getText().equals("")) {
					((Login) this).msg = "Enter your Password!";
					((Login) this).nflk = 30;
				} else {
					((Login) this).msg = "| Logging In |";
					((GameSparker)((Login) this).gs).tnick.disable();
					((GameSparker)((Login) this).gs).tpass.disable();
					((GameSparker)((Login) this).gs).keplo.disable();
					((Login) this).fase = 4;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
			}
			if (i_49_ == 3)
			((Login) this).gs.regnew();
		}
		if (((Login) this).fase == 5) {
			if (((Control) control).enter) {
				i_49_ = 1;
				((Login) this).pessd[1] = true;
			}
			if (((Control) control).exit) i_49_ = 2;
			if (i_49_ != 1) {
				/* empty */
			}
			if (i_49_ == 2) {
				((Login) this).fase = ((Login) this).lrgfase;
				if (((Login) this).fase == 12) {
					((GameSparker)((Login) this).gs).tnick.hide();
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
			}
		}
		if (((Login) this).fase == 7) {
			if (((Control) control).enter) {
				i_49_ = 2;
				((Login) this).pessd[2] = true;
			}
			if (((Control) control).exit) i_49_ = 3;
			if (i_49_ == 2) {
				((Login) this).nflk = 0;
				if (((GameSparker)((Login) this).gs).temail.getText()
					.equals("")) {
					((Login) this).msg = "Please type in your Email Address!";
					((Login) this).nflk = 30;
				}
				if (((Login) this).nflk == 0) {
					String string = ((GameSparker)((Login) this).gs).temail.getText();
					int i_55_ = 0;
					int i_56_ = 0;
					for ( /**/ ; i_55_ < string.length(); i_55_++) {
						String string_57_ = new StringBuilder().append("").append(string.charAt(i_55_)).toString();
						if (string_57_.equals("@") && i_56_ == 0 && i_55_ != 0) i_56_ = 1;
						if (string_57_.equals(".") && i_56_ == 1 && i_55_ != string.length() - 1) i_56_ = 2;
					}
					if (i_56_ != 2) {
						((Login) this).msg = "Please type in your Email Address correctly!";
						((Login) this).nflk = 30;
						((Login) this).errcnt = 40;
						((GameSparker)((Login) this).gs).temail.setForeground(new Color(255, 0, 0));
					}
				}
				if (((Login) this).nflk == 0) {
					((Login) this).msg = "| Checking Email |";
					((GameSparker)((Login) this).gs).temail.disable();
					((Login) this).fase = 8;
					((Login) this).connector = new Thread(this);
					((Login) this).connector.start();
				}
			}
			if (i_49_ == 3) {
				inishmulti();
				((GameSparker)((Login) this).gs).temail.setText("");
				((GameSparker)((Login) this).gs).tpass.setText("");
			}
		}
		((Login) this).lxm = i;
		((Login) this).lym = i_47_;
		((Control) control).enter = false;
		((Control) control).exit = false;
	}

	public void drawSbutton(Image image, int i, int i_58_) {
		((Login) this).bx[((Login) this).btn] = i;
		((Login) this).by[((Login) this).btn] = i_58_;
		((Login) this).bw[((Login) this).btn] = image.getWidth(((Login) this).ob);
		if (!((Login) this).pessd[((Login) this).btn]) {
			((Login) this).rd.drawImage(image, i - ((Login) this).bw[((Login) this).btn] / 2,
			i_58_ - image.getHeight(((Login) this).ob) / 2 - 1, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bols,
			i - (((Login) this).bw[((Login) this).btn]) / 2 - 15,
			i_58_ - 13, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bors,
			i + (((Login) this).bw[((Login) this).btn]) / 2 + 9,
			i_58_ - 13, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bot,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_58_ - 13, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bob,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_58_ + 10, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
		} else {
			((Login) this).rd.drawImage(image, i - ((Login) this).bw[((Login) this).btn] / 2 + 1,
			i_58_ - image.getHeight(((Login) this).ob) / 2, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bolps,
			i - (((Login) this).bw[((Login) this).btn]) / 2 - 15,
			i_58_ - 13, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).borps,
			i + (((Login) this).bw[((Login) this).btn]) / 2 + 9,
			i_58_ - 13, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bob,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_58_ - 13, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bot,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_58_ + 10, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
		}
		((Login) this).btn++;
	}

	public void drawbutton(Image image, int i, int i_59_) {
		((Login) this).bx[((Login) this).btn] = i;
		((Login) this).by[((Login) this).btn] = i_59_;
		((Login) this).bw[((Login) this).btn] = image.getWidth(((Login) this).ob);
		if (!((Login) this).pessd[((Login) this).btn]) {
			((Login) this).rd.drawImage(image, i - ((Login) this).bw[((Login) this).btn] / 2,
			i_59_ - image.getHeight(((Login) this).ob) / 2, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bol,
			i - (((Login) this).bw[((Login) this).btn]) / 2 - 15,
			i_59_ - 16, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bor,
			i + (((Login) this).bw[((Login) this).btn]) / 2 + 9,
			i_59_ - 16, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bot,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_59_ - 16, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bob,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_59_ + 13, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
		} else {
			((Login) this).rd.drawImage(image, i - ((Login) this).bw[((Login) this).btn] / 2 + 1,
			i_59_ - image.getHeight(((Login) this).ob) / 2 + 1, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bolp,
			i - (((Login) this).bw[((Login) this).btn]) / 2 - 15,
			i_59_ - 16, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).borp,
			i + (((Login) this).bw[((Login) this).btn]) / 2 + 9,
			i_59_ - 16, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bob,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_59_ - 16, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
			((Login) this).rd.drawImage(((xtGraphics)((Login) this).xt).bot,
			i - ((Login) this).bw[((Login) this).btn] / 2 - 9, i_59_ + 13, ((Login) this).bw[((Login) this).btn] + 18, 3, null);
		}
		((Login) this).btn++;
	}

	public void stringbutton(String string, int i, int i_60_, int i_61_) {
		((Login) this).rd.setFont(new Font("Arial", 1, 12));
		((Login) this).ftm = ((Login) this).rd.getFontMetrics();
		((Login) this).bx[((Login) this).btn] = i;
		((Login) this).by[((Login) this).btn] = i_60_ - 5;
		((Login) this).bw[((Login) this).btn] = ((Login) this).ftm.stringWidth(string);
		if (!((Login) this).pessd[((Login) this).btn]) {
			((Login) this).rd.setColor(color2k(220, 220, 220));
			((Login) this).rd.fillRect(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_), ((Login) this).bw[((Login) this).btn] + 20, 25 - i_61_ * 2);
			((Login) this).rd.setColor(color2k(240, 240, 240));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (17 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (18 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (18 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 9,
			i_60_ - (19 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 9,
			i_60_ - (19 - i_61_));
			((Login) this).rd.setColor(color2k(200, 200, 200));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 11,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 11,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 12,
			i_60_ - (16 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 12,
			i_60_ + (6 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (7 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (8 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (8 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 9,
			i_60_ + (9 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 9,
			i_60_ + (9 - i_61_));
			((Login) this).rd.setColor(color2k(240, 240, 240));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 11,
			i_60_ - (17 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 11,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 12,
			i_60_ - (16 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 12,
			i_60_ + (6 - i_61_));
			((Login) this).rd.setColor(new Color(0, 0, 0));
			((Login) this).rd.drawString(string,
			i - (((Login) this).bw[((Login) this).btn]) / 2,
			i_60_);
		} else {
			((Login) this).rd.setColor(color2k(210, 210, 210));
			((Login) this).rd.fillRect(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_), ((Login) this).bw[((Login) this).btn] + 20, 25 - i_61_ * 2);
			((Login) this).rd.setColor(color2k(200, 200, 200));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (17 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (18 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (18 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 9,
			i_60_ - (19 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 9,
			i_60_ - (19 - i_61_));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 11,
			i_60_ - (17 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 11,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i + ((Login) this).bw[((Login) this).btn] / 2 + 12,
			i_60_ - (16 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 12,
			i_60_ + (6 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (7 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (8 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 10,
			i_60_ + (8 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 9,
			i_60_ + (9 - i_61_),
			i + ((Login) this).bw[((Login) this).btn] / 2 + 9,
			i_60_ + (9 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ - (17 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 10,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 11,
			i_60_ - (17 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 11,
			i_60_ + (7 - i_61_));
			((Login) this).rd.drawLine(i - ((Login) this).bw[((Login) this).btn] / 2 - 12,
			i_60_ - (16 - i_61_),
			i - ((Login) this).bw[((Login) this).btn] / 2 - 12,
			i_60_ + (6 - i_61_));
			((Login) this).rd.setColor(new Color(0, 0, 0));
			((Login) this).rd.drawString(string,
			i - (((Login) this).bw[((Login) this).btn]) / 2 + 1,
			i_60_);
		}
		((Login) this).btn++;
	}

	public Color color2k(int i, int i_62_, int i_63_) {
		Color color = new Color(i, i_62_, i_63_);
		float[] fs = new float[3];
		Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
		fs[0] = 0.13F;
		fs[1] = 0.35F;
		return Color.getHSBColor(fs[0], fs[1], fs[2]);
	}

	public void fixtext(TextField textfield) {
		String string = textfield.getText();
		string = string.replace('\"', '#');
		String string_64_ = "\\";
		String string_65_ = "";
		int i = 0;
		int i_66_ = -1;
		for ( /**/ ; i < string.length(); i++) {
			String string_67_ = new StringBuilder().append("").append(string.charAt(i)).toString();
			if (string_67_.equals("|") || string_67_.equals(",") || string_67_.equals("(") || string_67_.equals(")") || string_67_.equals("#") || string_67_.equals(string_64_) || string_67_.equals("!") || string_67_.equals("?") || string_67_.equals(" ") || string_67_.equals("~") || string_67_.equals("$") || string_67_.equals("%") || string_67_.equals("^") || string_67_.equals("&") || string_67_.equals("*") || string_67_.equals("+") || string_67_.equals("=") || string_67_.equals(">") || string_67_.equals("<") || string_67_.equals("/") || string_67_.equals("'") || string_67_.equals(";") || string_67_.equals(":") || string_67_.equals("\u00a0")) i_66_ = i;
			else string_65_ = new StringBuilder().append(string_65_).append(string_67_).toString();
		}
		if (i_66_ != -1) {
			textfield.setText(string_65_);
			textfield.select(i_66_, i_66_);
		}
	}

	public int getvalue(String string, int i) {
		int i_68_ = -1;
		try {
			int i_69_ = 0;
			int i_70_ = 0;
			int i_71_ = 0;
			String string_72_ = "";
			String string_73_ = "";
			for ( /**/ ; i_69_ < string.length() && i_71_ != 2; i_69_++) {
				string_72_ = new StringBuilder().append("").append(string.charAt(i_69_)).toString();
				if (string_72_.equals("|")) {
					i_70_++;
					if (i_71_ == 1 || i_70_ > i) i_71_ = 2;
				} else if (i_70_ == i) {
					string_73_ = new StringBuilder().append(string_73_).append(string_72_).toString();
					i_71_ = 1;
				}
			}
			if (string_73_.equals("")) string_73_ = "-1";
			i_68_ = Integer.valueOf(string_73_).intValue();
		} catch (Exception exception) {
			/* empty */
		}
		return i_68_;
	}

	public String getSvalue(String string, int i) {
		String string_74_ = "";
		try {
			int i_75_ = 0;
			int i_76_ = 0;
			int i_77_ = 0;
			String string_78_ = "";
			String string_79_ = "";
			for ( /**/ ; i_75_ < string.length() && i_77_ != 2; i_75_++) {
				string_78_ = new StringBuilder().append("").append(string.charAt(i_75_)).toString();
				if (string_78_.equals("|")) {
					i_76_++;
					if (i_77_ == 1 || i_76_ > i) i_77_ = 2;
				} else if (i_76_ == i) {
					string_79_ = new StringBuilder().append(string_79_).append(string_78_).toString();
					i_77_ = 1;
				}
			}
			string_74_ = string_79_;
		} catch (Exception exception) {
			/* empty */
		}
		return string_74_;
	}
}