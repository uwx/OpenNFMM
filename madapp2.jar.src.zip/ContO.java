/* ContO - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.util.Random;

public class ContO
{
    Medium m;
    Trackers t;
    Plane[] p;
    int npl = 0;
    int x = 0;
    int y = 0;
    int z = 0;
    int xz = 0;
    int xy = 0;
    int zy = 0;
    int wxz = 0;
    int wzy = 0;
    int dist = 0;
    int maxR = 0;
    int disp = 0;
    int disline = 14;
    boolean shadow = false;
    boolean noline = false;
    boolean decor = false;
    float grounded = 1.0F;
    int grat = 0;
    int[] keyx;
    int[] keyz;
    int sprkat;
    int[] txy;
    int[] tzy;
    int[][] tc;
    int[] tradx;
    int[] tradz;
    int[] trady;
    int[] tx;
    int[] ty;
    int[] tz;
    int[] skd;
    int[] dam;
    boolean[] notwall;
    int tnt;
    int[] stg;
    int[] sx;
    int[] sy;
    int[] sz;
    int[] scx;
    int[] scz;
    float[] osmag;
    int[] sav;
    float[][] smag;
    int[][] srgb;
    float[] sbln;
    int ust;
    int srx;
    int sry;
    int srz;
    float rcx;
    float rcy;
    float rcz;
    int sprk;
    int[] rtg;
    boolean[] rbef;
    int[] rx;
    int[] ry;
    int[] rz;
    float[] vrx;
    float[] vry;
    float[] vrz;
    boolean elec;
    boolean roted;
    int[] edl;
    int[] edr;
    int[] elc;
    boolean fix;
    int fcnt;
    int checkpoint;
    int[] fcol;
    int[] scol;
    int colok;
    boolean errd;
    String err;
    int roofat;
    int wh;
    
    public ContO(byte[] is, Medium medium, Trackers trackers) {
	((ContO) this).keyx = new int[4];
	((ContO) this).keyz = new int[4];
	((ContO) this).sprkat = 0;
	((ContO) this).tnt = 0;
	((ContO) this).ust = 0;
	((ContO) this).srx = 0;
	((ContO) this).sry = 0;
	((ContO) this).srz = 0;
	((ContO) this).rcx = 0.0F;
	((ContO) this).rcy = 0.0F;
	((ContO) this).rcz = 0.0F;
	((ContO) this).sprk = 0;
	((ContO) this).elec = false;
	((ContO) this).roted = false;
	((ContO) this).edl = new int[4];
	((ContO) this).edr = new int[4];
	((ContO) this).elc = new int[] { 0, 0, 0, 0 };
	((ContO) this).fix = false;
	((ContO) this).fcnt = 0;
	((ContO) this).checkpoint = 0;
	((ContO) this).fcol = new int[] { 0, 0, 0 };
	((ContO) this).scol = new int[] { 0, 0, 0 };
	((ContO) this).colok = 0;
	((ContO) this).errd = false;
	((ContO) this).err = "";
	((ContO) this).roofat = 0;
	((ContO) this).wh = 0;
	((ContO) this).m = medium;
	((ContO) this).t = trackers;
	//((ContO) this).p = new Plane[286];
	((ContO) this).p = new Plane[10000];
	//int[] is_0_ = new int[286];
	int[] is_0_ = new int[10000];
	//for (int i = 0; i < 286; i++)
	//    is_0_[i] = 0;
	for (int i = 0; i < 10000; i++)
	    is_0_[i] = 0;
	if (((Medium) ((ContO) this).m).loadnew) {
	    for (int i = 0; i < 4; i++)
		((ContO) this).keyz[i] = 0;
	    ((ContO) this).shadow = true;
	}
	String string = "";
	boolean bool = false;
	boolean bool_1_ = false;
	int i = 0;
	float f = 1.0F;
	float f_2_ = 1.0F;
	float[] fs = { 1.0F, 1.0F, 1.0F };
	int[] is_3_ = new int[100];
	int[] is_4_ = new int[100];
	int[] is_5_ = new int[100];
	int[] is_6_ = { 0, 0, 0 };
	boolean bool_7_ = false;
	Wheels wheels = new Wheels();
	boolean bool_8_ = false;
	int i_9_ = 0;
	int i_10_ = 1;
	int i_11_ = 0;
	int i_12_ = 0;
	int i_13_ = 0;
	int i_14_ = 0;
	boolean bool_15_ = false;
	boolean bool_16_ = false;
	try {
	    DataInputStream datainputstream
		= new DataInputStream(new ByteArrayInputStream(is));
	    String string_17_;
	    while ((string_17_ = datainputstream.readLine()) != null) {
		string = new StringBuilder().append("").append
			     (string_17_.trim()).toString();
		if (((ContO) this).npl < 10000 /*210*/) {
		    if (string.startsWith("<p>")) {
			bool = true;
			i = 0;
			i_10_ = 0;
			i_11_ = 0;
			i_13_ = 0;
			is_0_[((ContO) this).npl] = 1;
			if (!bool_16_)
			    bool_15_ = false;
		    }
		    if (bool) {
			if (string.startsWith("gr("))
			    i_10_ = getvalue("gr", string, 0);
			if (string.startsWith("fs(")) {
			    i_11_ = getvalue("fs", string, 0);
			    is_0_[((ContO) this).npl] = 2;
			}
			if (string.startsWith("c(")) {
			    i_14_ = 0;
			    is_6_[0] = getvalue("c", string, 0);
			    is_6_[1] = getvalue("c", string, 1);
			    is_6_[2] = getvalue("c", string, 2);
			}
			if (string.startsWith("glass"))
			    i_14_ = 1;
			if (string.startsWith("gshadow"))
			    i_14_ = 2;
			if (string.startsWith("lightF"))
			    i_13_ = 1;
			if (string.startsWith("light"))
			    i_13_ = 1;
			if (string.startsWith("lightB"))
			    i_13_ = 2;
			if (string.startsWith("noOutline"))
			    bool_15_ = true;
			if (string.startsWith("p(")) {
			    is_3_[i] = (int) ((float) getvalue("p", string, 0)
					      * f * f_2_ * fs[0]);
			    is_4_[i] = (int) ((float) getvalue("p", string, 1)
					      * f * fs[1]);
			    is_5_[i] = (int) ((float) getvalue("p", string, 2)
					      * f * fs[2]);
			    int i_18_
				= (int) Math.sqrt((double) (is_3_[i] * is_3_[i]
							    + (is_4_[i]
							       * is_4_[i])
							    + (is_5_[i]
							       * is_5_[i])));
			    if (i_18_ > ((ContO) this).maxR)
				((ContO) this).maxR = i_18_;
			    i++;
			}
		    }
		    if (string.startsWith("</p>")) {
			((ContO) this).p[((ContO) this).npl]
			    = new Plane(((ContO) this).m, ((ContO) this).t,
					is_3_, is_5_, is_4_, i, is_6_, i_14_,
					i_10_, i_11_, 0, 0, 0,
					((ContO) this).disline, 0, bool_7_,
					i_13_, bool_15_);
			if (is_6_[0] == ((ContO) this).fcol[0]
			    && is_6_[1] == ((ContO) this).fcol[1]
			    && is_6_[2] == ((ContO) this).fcol[2]
			    && i_14_ == 0)
			    ((Plane) ((ContO) this).p[((ContO) this).npl])
				.colnum
				= 1;
			if (is_6_[0] == ((ContO) this).scol[0]
			    && is_6_[1] == ((ContO) this).scol[1]
			    && is_6_[2] == ((ContO) this).scol[2]
			    && i_14_ == 0)
			    ((Plane) ((ContO) this).p[((ContO) this).npl])
				.colnum
				= 2;
			((ContO) this).npl++;
			bool = false;
		    }
		}
		if (string.startsWith("rims("))
		    wheels.setrims(getvalue("rims", string, 0),
				   getvalue("rims", string, 1),
				   getvalue("rims", string, 2),
				   getvalue("rims", string, 3),
				   getvalue("rims", string, 4));
		if (string.startsWith("w(") && i_9_ < 4) {
		    ((ContO) this).keyx[i_9_]
			= (int) ((float) getvalue("w", string, 0) * f * fs[0]);
		    ((ContO) this).keyz[i_9_]
			= (int) ((float) getvalue("w", string, 2) * f * fs[2]);
		    wheels.make(((ContO) this).m, ((ContO) this).t,
				((ContO) this).p, ((ContO) this).npl,
				(int) ((float) getvalue("w", string, 0) * f
				       * f_2_ * fs[0]),
				(int) ((float) getvalue("w", string, 1) * f
				       * fs[1]),
				(int) ((float) getvalue("w", string, 2) * f
				       * fs[2]),
				getvalue("w", string, 3),
				(int) ((float) getvalue("w", string, 4) * f
				       * f_2_),
				(int) ((float) getvalue("w", string, 5) * f),
				i_12_);
		    ((ContO) this).npl += 19;
		    if (((Medium) ((ContO) this).m).loadnew) {
			((ContO) this).wh
			    += (int) ((float) getvalue("w", string, 5) * f);
			if (((Wheels) wheels).ground > 140) {
			    String string_19_ = "FRONT";
			    if (((ContO) this).keyz[i_9_] < 0)
				string_19_ = "BACK";
			    ((ContO) this).err
				= new StringBuilder().append
				      ("Wheels Error:\n").append
				      (string_19_).append
				      (" Wheels floor is too far below the center of Y Axis of the car!    \n\nPlease decrease the Y value of the ")
				      .append
				      (string_19_).append
				      (" Wheels or decrease its height.     \n \n")
				      .toString();
			    ((ContO) this).errd = true;
			    ((ContO) this).keyz[i_9_] = 0;
			    ((ContO) this).keyx[i_9_] = 0;
			}
			if (((Wheels) wheels).ground < -100) {
			    String string_20_ = "FRONT";
			    if (((ContO) this).keyz[i_9_] < 0)
				string_20_ = "BACK";
			    ((ContO) this).err
				= new StringBuilder().append
				      ("Wheels Error:\n").append
				      (string_20_).append
				      (" Wheels floor is too far above the center of Y Axis of the car!    \n\nPlease increase the Y value of the ")
				      .append
				      (string_20_).append
				      (" Wheels or increase its height.     \n \n")
				      .toString();
			    ((ContO) this).errd = true;
			    ((ContO) this).keyz[i_9_] = 0;
			    ((ContO) this).keyx[i_9_] = 0;
			}
			if (Math.abs(((ContO) this).keyx[i_9_]) > 400) {
			    String string_21_ = "FRONT";
			    if (((ContO) this).keyz[i_9_] < 0)
				string_21_ = "BACK";
			    ((ContO) this).err
				= new StringBuilder().append
				      ("Wheels Error:\n").append
				      (string_21_).append
				      (" Wheels are too far apart!    \n\nPlease decrease the \u00b1X value of the ")
				      .append
				      (string_21_).append
				      (" Wheels.     \n \n").toString();
			    ((ContO) this).errd = true;
			    ((ContO) this).keyz[i_9_] = 0;
			    ((ContO) this).keyx[i_9_] = 0;
			}
			if (Math.abs(((ContO) this).keyz[i_9_]) > 700) {
			    if (((ContO) this).keyz[i_9_] < 0)
				((ContO) this).err
				    = "Wheels Error:\nBACK Wheels are too far backwards from the center of the Z Axis!    \n\nPlease increase the -Z value of the BACK Wheels.     \n \n";
			    else
				((ContO) this).err
				    = "Wheels Error:\nFRONT Wheels are too far forwards from the center of the Z Axis!    \n\nPlease decrease the +Z value of the FRONT Wheels.     \n \n";
			    ((ContO) this).errd = true;
			    ((ContO) this).keyz[i_9_] = 0;
			    ((ContO) this).keyx[i_9_] = 0;
			}
			if ((int) ((float) getvalue("w", string, 4) * f * f_2_)
			    > 300) {
			    String string_22_ = "FRONT";
			    if (((ContO) this).keyz[i_9_] < 0)
				string_22_ = "BACK";
			    ((ContO) this).err
				= new StringBuilder().append
				      ("Wheels Error:\nWidth of the ").append
				      (string_22_).append
				      (" Wheels is too large!    \n\nPlease decrease the width of the ")
				      .append
				      (string_22_).append
				      (" Wheels.     \n \n").toString();
			    ((ContO) this).errd = true;
			    ((ContO) this).keyz[i_9_] = 0;
			    ((ContO) this).keyx[i_9_] = 0;
			}
		    }
		    i_9_++;
		}
		if (string.startsWith("tracks")) {
		    int i_23_ = getvalue("tracks", string, 0);
		    ((ContO) this).txy = new int[i_23_];
		    ((ContO) this).tzy = new int[i_23_];
		    ((ContO) this).tc = new int[i_23_][3];
		    ((ContO) this).tradx = new int[i_23_];
		    ((ContO) this).tradz = new int[i_23_];
		    ((ContO) this).trady = new int[i_23_];
		    ((ContO) this).tx = new int[i_23_];
		    ((ContO) this).ty = new int[i_23_];
		    ((ContO) this).tz = new int[i_23_];
		    ((ContO) this).skd = new int[i_23_];
		    ((ContO) this).dam = new int[i_23_];
		    ((ContO) this).notwall = new boolean[i_23_];
		    bool_8_ = true;
		}
		if (bool_8_) {
		    if (string.startsWith("<track>")) {
			bool_1_ = true;
			((ContO) this).notwall[((ContO) this).tnt] = false;
			((ContO) this).dam[((ContO) this).tnt] = 1;
			((ContO) this).skd[((ContO) this).tnt] = 0;
			((ContO) this).ty[((ContO) this).tnt] = 0;
			((ContO) this).tx[((ContO) this).tnt] = 0;
			((ContO) this).tz[((ContO) this).tnt] = 0;
			((ContO) this).txy[((ContO) this).tnt] = 0;
			((ContO) this).tzy[((ContO) this).tnt] = 0;
			((ContO) this).trady[((ContO) this).tnt] = 0;
			((ContO) this).tradx[((ContO) this).tnt] = 0;
			((ContO) this).tradz[((ContO) this).tnt] = 0;
			((ContO) this).tc[((ContO) this).tnt][0] = 0;
			((ContO) this).tc[((ContO) this).tnt][1] = 0;
			((ContO) this).tc[((ContO) this).tnt][2] = 0;
		    }
		    if (bool_1_) {
			if (string.startsWith("c")) {
			    ((ContO) this).tc[((ContO) this).tnt][0]
				= getvalue("c", string, 0);
			    ((ContO) this).tc[((ContO) this).tnt][1]
				= getvalue("c", string, 1);
			    ((ContO) this).tc[((ContO) this).tnt][2]
				= getvalue("c", string, 2);
			}
			if (string.startsWith("xy"))
			    ((ContO) this).txy[((ContO) this).tnt]
				= getvalue("xy", string, 0);
			if (string.startsWith("zy"))
			    ((ContO) this).tzy[((ContO) this).tnt]
				= getvalue("zy", string, 0);
			if (string.startsWith("radx"))
			    ((ContO) this).tradx[((ContO) this).tnt]
				= (int) ((float) getvalue("radx", string, 0)
					 * f);
			if (string.startsWith("rady"))
			    ((ContO) this).trady[((ContO) this).tnt]
				= (int) ((float) getvalue("rady", string, 0)
					 * f);
			if (string.startsWith("radz"))
			    ((ContO) this).tradz[((ContO) this).tnt]
				= (int) ((float) getvalue("radz", string, 0)
					 * f);
			if (string.startsWith("ty"))
			    ((ContO) this).ty[((ContO) this).tnt]
				= (int) ((float) getvalue("ty", string, 0)
					 * f);
			if (string.startsWith("tx"))
			    ((ContO) this).tx[((ContO) this).tnt]
				= (int) ((float) getvalue("tx", string, 0)
					 * f);
			if (string.startsWith("tz"))
			    ((ContO) this).tz[((ContO) this).tnt]
				= (int) ((float) getvalue("tz", string, 0)
					 * f);
			if (string.startsWith("skid"))
			    ((ContO) this).skd[((ContO) this).tnt]
				= getvalue("skid", string, 0);
			if (string.startsWith("dam"))
			    ((ContO) this).dam[((ContO) this).tnt] = 3;
			if (string.startsWith("notwall"))
			    ((ContO) this).notwall[((ContO) this).tnt] = true;
		    }
		    if (string.startsWith("</track>")) {
			bool_1_ = false;
			((ContO) this).tnt++;
		    }
		}
		if (string.startsWith("disp("))
		    ((ContO) this).disp = getvalue("disp", string, 0);
		if (string.startsWith("disline("))
		    ((ContO) this).disline
			= getvalue("disline", string, 0) * 2;
		if (string.startsWith("shadow"))
		    ((ContO) this).shadow = true;
		if (string.startsWith("stonecold"))
		    ((ContO) this).noline = true;
		if (string.startsWith("newstone")) {
		    ((ContO) this).noline = true;
		    bool_15_ = true;
		    bool_16_ = true;
		}
		if (string.startsWith("decorative"))
		    ((ContO) this).decor = true;
		if (string.startsWith("road"))
		    bool_7_ = true;
		if (string.startsWith("notroad"))
		    bool_7_ = false;
		if (string.startsWith("grounded("))
		    ((ContO) this).grounded
			= (float) getvalue("grounded", string, 0) / 100.0F;
		if (string.startsWith("div("))
		    f = (float) getvalue("div", string, 0) / 10.0F;
		if (string.startsWith("idiv("))
		    f = (float) getvalue("idiv", string, 0) / 100.0F;
		if (string.startsWith("iwid("))
		    f_2_ = (float) getvalue("iwid", string, 0) / 100.0F;
		if (string.startsWith("ScaleX("))
		    fs[0] = (float) getvalue("ScaleX", string, 0) / 100.0F;
		if (string.startsWith("ScaleY("))
		    fs[1] = (float) getvalue("ScaleY", string, 0) / 100.0F;
		if (string.startsWith("ScaleZ("))
		    fs[2] = (float) getvalue("ScaleZ", string, 0) / 100.0F;
		if (string.startsWith("gwgr(")) {
		    i_12_ = getvalue("gwgr", string, 0);
		    if (((Medium) ((ContO) this).m).loadnew) {
			if (i_12_ > 40)
			    i_12_ = 40;
			if (i_12_ < 0 && i_12_ >= -15)
			    i_12_ = -16;
			if (i_12_ < -40)
			    i_12_ = -40;
		    }
		}
		if (string.startsWith("1stColor(")) {
		    ((ContO) this).fcol[0] = getvalue("1stColor", string, 0);
		    ((ContO) this).fcol[1] = getvalue("1stColor", string, 1);
		    ((ContO) this).fcol[2] = getvalue("1stColor", string, 2);
		    ((ContO) this).colok++;
		}
		if (string.startsWith("2ndColor(")) {
		    ((ContO) this).scol[0] = getvalue("2ndColor", string, 0);
		    ((ContO) this).scol[1] = getvalue("2ndColor", string, 1);
		    ((ContO) this).scol[2] = getvalue("2ndColor", string, 2);
		    ((ContO) this).colok++;
		}
	    }
	    datainputstream.close();
	} catch (Exception exception) {
	    if (!((ContO) this).errd) {
		((ContO) this).err
		    = new StringBuilder().append
			  ("Error While Loading 3D Model\n\nLine:     ").append
			  (string).append
			  ("\n\nError Detail:\n").append
			  (exception).append
			  ("           \n \n").toString();
		System.out.println(((ContO) this).err);
		((ContO) this).errd = true;
	    }
	}
	((ContO) this).grat = ((Wheels) wheels).ground;
	((ContO) this).sprkat = ((Wheels) wheels).sparkat;
	if (((ContO) this).shadow) {
	    ((ContO) this).stg = new int[20];
	    ((ContO) this).rtg = new int[100];
	    for (int i_24_ = 0; i_24_ < 20; i_24_++)
		((ContO) this).stg[i_24_] = 0;
	    for (int i_25_ = 0; i_25_ < 100; i_25_++)
		((ContO) this).rtg[i_25_] = 0;
	}
	if (((Medium) ((ContO) this).m).loadnew) {
	    if (i_9_ != 0)
		((ContO) this).wh = ((ContO) this).wh / i_9_;
	    boolean bool_26_ = false;
	    for (int i_27_ = 0; i_27_ < ((ContO) this).npl; i_27_++) {
		int i_28_ = 0;
		int i_29_ = ((Plane) ((ContO) this).p[i_27_]).ox[0];
		int i_30_ = ((Plane) ((ContO) this).p[i_27_]).ox[0];
		int i_31_ = ((Plane) ((ContO) this).p[i_27_]).oy[0];
		int i_32_ = ((Plane) ((ContO) this).p[i_27_]).oy[0];
		int i_33_ = ((Plane) ((ContO) this).p[i_27_]).oz[0];
		int i_34_ = ((Plane) ((ContO) this).p[i_27_]).oz[0];
		for (int i_35_ = 0;
		     i_35_ < ((Plane) ((ContO) this).p[i_27_]).n; i_35_++) {
		    if (((Plane) ((ContO) this).p[i_27_]).ox[i_35_] > i_29_)
			i_29_ = ((Plane) ((ContO) this).p[i_27_]).ox[i_35_];
		    if (((Plane) ((ContO) this).p[i_27_]).ox[i_35_] < i_30_)
			i_30_ = ((Plane) ((ContO) this).p[i_27_]).ox[i_35_];
		    if (((Plane) ((ContO) this).p[i_27_]).oy[i_35_] > i_31_)
			i_31_ = ((Plane) ((ContO) this).p[i_27_]).oy[i_35_];
		    if (((Plane) ((ContO) this).p[i_27_]).oy[i_35_] < i_32_)
			i_32_ = ((Plane) ((ContO) this).p[i_27_]).oy[i_35_];
		    if (((Plane) ((ContO) this).p[i_27_]).oz[i_35_] > i_33_)
			i_33_ = ((Plane) ((ContO) this).p[i_27_]).oz[i_35_];
		    if (((Plane) ((ContO) this).p[i_27_]).oz[i_35_] < i_34_)
			i_34_ = ((Plane) ((ContO) this).p[i_27_]).oz[i_35_];
		}
		if (Math.abs(i_29_ - i_30_) <= Math.abs(i_31_ - i_32_)
		    && Math.abs(i_29_ - i_30_) <= Math.abs(i_33_ - i_34_))
		    i_28_ = 1;
		if (Math.abs(i_31_ - i_32_) <= Math.abs(i_29_ - i_30_)
		    && Math.abs(i_31_ - i_32_) <= Math.abs(i_33_ - i_34_))
		    i_28_ = 2;
		if (Math.abs(i_33_ - i_34_) <= Math.abs(i_29_ - i_30_)
		    && Math.abs(i_33_ - i_34_) <= Math.abs(i_31_ - i_32_))
		    i_28_ = 3;
		if (i_28_ == 2
		    && (!bool_26_
			|| (i_31_ + i_32_) / 2 < ((ContO) this).roofat)) {
		    ((ContO) this).roofat = (i_31_ + i_32_) / 2;
		    bool_26_ = true;
		}
		if (is_0_[i_27_] == 1) {
		    int i_36_ = 1000;
		    int i_37_ = 0;
		    for (int i_38_ = 0;
			 i_38_ < ((Plane) ((ContO) this).p[i_27_]).n;
			 i_38_++) {
			int i_39_ = i_38_ + 1;
			if (i_39_ >= ((Plane) ((ContO) this).p[i_27_]).n)
			    i_39_ -= ((Plane) ((ContO) this).p[i_27_]).n;
			int i_40_ = i_38_ + 2;
			if (i_40_ >= ((Plane) ((ContO) this).p[i_27_]).n)
			    i_40_ -= ((Plane) ((ContO) this).p[i_27_]).n;
			if (i_28_ == 1) {
			    int i_41_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oz[i_38_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oz[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).oy[i_38_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .oy[i_39_]))))
					   / 0.017453292519943295)));
			    int i_42_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oz[i_40_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oz[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).oy[i_40_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .oy[i_39_]))))
					   / 0.017453292519943295)));
			    if (i_41_ > 45)
				i_41_ = 90 - i_41_;
			    else
				i_42_ = 90 - i_42_;
			    if (i_41_ + i_42_ < i_36_) {
				i_36_ = i_41_ + i_42_;
				i_37_ = i_38_;
			    }
			}
			if (i_28_ == 2) {
			    int i_43_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oz[i_38_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oz[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).ox[i_38_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .ox[i_39_]))))
					   / 0.017453292519943295)));
			    int i_44_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oz[i_40_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oz[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).ox[i_40_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .ox[i_39_]))))
					   / 0.017453292519943295)));
			    if (i_43_ > 45)
				i_43_ = 90 - i_43_;
			    else
				i_44_ = 90 - i_44_;
			    if (i_43_ + i_44_ < i_36_) {
				i_36_ = i_43_ + i_44_;
				i_37_ = i_38_;
			    }
			}
			if (i_28_ == 3) {
			    int i_45_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oy[i_38_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oy[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).ox[i_38_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .ox[i_39_]))))
					   / 0.017453292519943295)));
			    int i_46_
				= (Math.abs
				   ((int) ((Math.atan
					    ((double) (((Plane)
							(((ContO) this).p
							 [i_27_])).oy[i_40_]
						       - ((Plane)
							  (((ContO) this).p
							   [i_27_])).oy[i_39_])
					     / (double) (((Plane)
							  (((ContO) this).p
							   [i_27_])).ox[i_40_]
							 - (((Plane)
							     (((ContO) this).p
							      [i_27_]))
							    .ox[i_39_]))))
					   / 0.017453292519943295)));
			    if (i_45_ > 45)
				i_45_ = 90 - i_45_;
			    else
				i_46_ = 90 - i_46_;
			    if (i_45_ + i_46_ < i_36_) {
				i_36_ = i_45_ + i_46_;
				i_37_ = i_38_;
			    }
			}
		    }
		    if (i_37_ != 0) {
			int[] is_47_
			    = new int[((Plane) ((ContO) this).p[i_27_]).n];
			int[] is_48_
			    = new int[((Plane) ((ContO) this).p[i_27_]).n];
			int[] is_49_
			    = new int[((Plane) ((ContO) this).p[i_27_]).n];
			for (int i_50_ = 0;
			     i_50_ < ((Plane) ((ContO) this).p[i_27_]).n;
			     i_50_++) {
			    is_47_[i_50_]
				= ((Plane) ((ContO) this).p[i_27_]).ox[i_50_];
			    is_48_[i_50_]
				= ((Plane) ((ContO) this).p[i_27_]).oy[i_50_];
			    is_49_[i_50_]
				= ((Plane) ((ContO) this).p[i_27_]).oz[i_50_];
			}
			for (int i_51_ = 0;
			     i_51_ < ((Plane) ((ContO) this).p[i_27_]).n;
			     i_51_++) {
			    int i_52_ = i_51_ + i_37_;
			    if (i_52_ >= ((Plane) ((ContO) this).p[i_27_]).n)
				i_52_ -= ((Plane) ((ContO) this).p[i_27_]).n;
			    ((Plane) ((ContO) this).p[i_27_]).ox[i_51_]
				= is_47_[i_52_];
			    ((Plane) ((ContO) this).p[i_27_]).oy[i_51_]
				= is_48_[i_52_];
			    ((Plane) ((ContO) this).p[i_27_]).oz[i_51_]
				= is_49_[i_52_];
			}
		    }
		    if (i_28_ == 1) {
			if (Math.abs(((Plane) ((ContO) this).p[i_27_]).oz[0]
				     - ((Plane) ((ContO) this).p[i_27_]).oz[1])
			    > Math.abs(((Plane) ((ContO) this).p[i_27_]).oy[0]
				       - (((Plane) ((ContO) this).p[i_27_]).oy
					  [1]))) {
			    if (((Plane) ((ContO) this).p[i_27_]).oz[0]
				> ((Plane) ((ContO) this).p[i_27_]).oz[1]) {
				if (((Plane) ((ContO) this).p[i_27_]).oy[1]
				    > ((Plane) ((ContO) this).p[i_27_]).oy[2])
				    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
				else
				    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    } else if (((Plane) ((ContO) this).p[i_27_]).oy[1]
				       > (((Plane) ((ContO) this).p[i_27_]).oy
					  [2]))
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			} else if (((Plane) ((ContO) this).p[i_27_]).oy[0]
				   > ((Plane) ((ContO) this).p[i_27_]).oy[1]) {
			    if (((Plane) ((ContO) this).p[i_27_]).oz[1]
				> ((Plane) ((ContO) this).p[i_27_]).oz[2])
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			} else if (((Plane) ((ContO) this).p[i_27_]).oz[1]
				   > ((Plane) ((ContO) this).p[i_27_]).oz[2])
			    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
			else
			    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
		    }
		    if (i_28_ == 2) {
			if (Math.abs(((Plane) ((ContO) this).p[i_27_]).oz[0]
				     - ((Plane) ((ContO) this).p[i_27_]).oz[1])
			    > Math.abs(((Plane) ((ContO) this).p[i_27_]).ox[0]
				       - (((Plane) ((ContO) this).p[i_27_]).ox
					  [1]))) {
			    if (((Plane) ((ContO) this).p[i_27_]).oz[0]
				> ((Plane) ((ContO) this).p[i_27_]).oz[1]) {
				if (((Plane) ((ContO) this).p[i_27_]).ox[1]
				    > ((Plane) ((ContO) this).p[i_27_]).ox[2])
				    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
				else
				    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
			    } else if (((Plane) ((ContO) this).p[i_27_]).ox[1]
				       > (((Plane) ((ContO) this).p[i_27_]).ox
					  [2]))
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			} else if (((Plane) ((ContO) this).p[i_27_]).ox[0]
				   > ((Plane) ((ContO) this).p[i_27_]).ox[1]) {
			    if (((Plane) ((ContO) this).p[i_27_]).oz[1]
				> ((Plane) ((ContO) this).p[i_27_]).oz[2])
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			} else if (((Plane) ((ContO) this).p[i_27_]).oz[1]
				   > ((Plane) ((ContO) this).p[i_27_]).oz[2])
			    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
			else
			    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
		    }
		    if (i_28_ == 3) {
			if (Math.abs(((Plane) ((ContO) this).p[i_27_]).oy[0]
				     - ((Plane) ((ContO) this).p[i_27_]).oy[1])
			    > Math.abs(((Plane) ((ContO) this).p[i_27_]).ox[0]
				       - (((Plane) ((ContO) this).p[i_27_]).ox
					  [1]))) {
			    if (((Plane) ((ContO) this).p[i_27_]).oy[0]
				> ((Plane) ((ContO) this).p[i_27_]).oy[1]) {
				if (((Plane) ((ContO) this).p[i_27_]).ox[1]
				    > ((Plane) ((ContO) this).p[i_27_]).ox[2])
				    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
				else
				    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    } else if (((Plane) ((ContO) this).p[i_27_]).ox[1]
				       > (((Plane) ((ContO) this).p[i_27_]).ox
					  [2]))
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			} else if (((Plane) ((ContO) this).p[i_27_]).ox[0]
				   > ((Plane) ((ContO) this).p[i_27_]).ox[1]) {
			    if (((Plane) ((ContO) this).p[i_27_]).oy[1]
				> ((Plane) ((ContO) this).p[i_27_]).oy[2])
				((Plane) ((ContO) this).p[i_27_]).fs = -1;
			    else
				((Plane) ((ContO) this).p[i_27_]).fs = 1;
			} else if (((Plane) ((ContO) this).p[i_27_]).oy[1]
				   > ((Plane) ((ContO) this).p[i_27_]).oy[2])
			    ((Plane) ((ContO) this).p[i_27_]).fs = 1;
			else
			    ((Plane) ((ContO) this).p[i_27_]).fs = -1;
		    }
		    boolean bool_53_ = false;
		    boolean bool_54_ = false;
		    for (int i_55_ = 0; i_55_ < ((ContO) this).npl; i_55_++) {
			if (i_55_ != i_27_ && is_0_[i_55_] != 0) {
			    boolean bool_56_ = false;
			    int i_57_
				= ((Plane) ((ContO) this).p[i_55_]).ox[0];
			    int i_58_
				= ((Plane) ((ContO) this).p[i_55_]).ox[0];
			    int i_59_
				= ((Plane) ((ContO) this).p[i_55_]).oy[0];
			    int i_60_
				= ((Plane) ((ContO) this).p[i_55_]).oy[0];
			    int i_61_
				= ((Plane) ((ContO) this).p[i_55_]).oz[0];
			    int i_62_
				= ((Plane) ((ContO) this).p[i_55_]).oz[0];
			    for (int i_63_ = 0;
				 i_63_ < ((Plane) ((ContO) this).p[i_55_]).n;
				 i_63_++) {
				if (((Plane) ((ContO) this).p[i_55_]).ox[i_63_]
				    > i_57_)
				    i_57_ = (((Plane) ((ContO) this).p[i_55_])
					     .ox[i_63_]);
				if (((Plane) ((ContO) this).p[i_55_]).ox[i_63_]
				    < i_58_)
				    i_58_ = (((Plane) ((ContO) this).p[i_55_])
					     .ox[i_63_]);
				if (((Plane) ((ContO) this).p[i_55_]).oy[i_63_]
				    > i_59_)
				    i_59_ = (((Plane) ((ContO) this).p[i_55_])
					     .oy[i_63_]);
				if (((Plane) ((ContO) this).p[i_55_]).oy[i_63_]
				    < i_60_)
				    i_60_ = (((Plane) ((ContO) this).p[i_55_])
					     .oy[i_63_]);
				if (((Plane) ((ContO) this).p[i_55_]).oz[i_63_]
				    > i_61_)
				    i_61_ = (((Plane) ((ContO) this).p[i_55_])
					     .oz[i_63_]);
				if (((Plane) ((ContO) this).p[i_55_]).oz[i_63_]
				    < i_62_)
				    i_62_ = (((Plane) ((ContO) this).p[i_55_])
					     .oz[i_63_]);
			    }
			    int i_64_ = (i_57_ + i_58_) / 2;
			    int i_65_ = (i_59_ + i_60_) / 2;
			    int i_66_ = (i_61_ + i_62_) / 2;
			    int i_67_ = (i_29_ + i_30_) / 2;
			    int i_68_ = (i_31_ + i_32_) / 2;
			    int i_69_ = (i_33_ + i_34_) / 2;
			    if (i_28_ == 1
				&& ((i_65_ <= i_31_ && i_65_ >= i_32_
				     && i_66_ <= i_33_ && i_66_ >= i_34_)
				    || (i_68_ <= i_59_ && i_68_ >= i_60_
					&& i_69_ <= i_61_
					&& i_69_ >= i_62_))) {
				if (i_57_ < i_30_)
				    bool_53_ = true;
				if (i_58_ > i_29_)
				    bool_54_ = true;
			    }
			    if (i_28_ == 2
				&& ((i_64_ <= i_29_ && i_64_ >= i_30_
				     && i_66_ <= i_33_ && i_66_ >= i_34_)
				    || (i_67_ <= i_57_ && i_67_ >= i_58_
					&& i_69_ <= i_61_
					&& i_69_ >= i_62_))) {
				if (i_59_ < i_32_)
				    bool_53_ = true;
				if (i_60_ > i_31_)
				    bool_54_ = true;
			    }
			    if (i_28_ == 3
				&& ((i_64_ <= i_29_ && i_64_ >= i_30_
				     && i_65_ <= i_31_ && i_65_ >= i_32_)
				    || (i_67_ <= i_57_ && i_67_ >= i_58_
					&& i_68_ <= i_59_
					&& i_68_ >= i_60_))) {
				if (i_61_ < i_34_)
				    bool_53_ = true;
				if (i_62_ > i_33_)
				    bool_54_ = true;
			    }
			}
			if (bool_53_ && bool_54_)
			    break;
		    }
		    boolean bool_70_ = false;
		    if (bool_53_ && !bool_54_)
			bool_70_ = true;
		    if (bool_54_ && !bool_53_) {
			((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			bool_70_ = true;
		    }
		    if (bool_53_ && bool_54_) {
			((Plane) ((ContO) this).p[i_27_]).fs = 0;
			((Plane) ((ContO) this).p[i_27_]).gr = 40;
			bool_70_ = true;
		    }
		    if (!bool_70_) {
			int i_71_ = 0;
			int i_72_ = 0;
			if (i_28_ == 1) {
			    i_71_ = (i_29_ + i_30_) / 2;
			    i_72_ = i_71_;
			}
			if (i_28_ == 2) {
			    i_71_ = (i_31_ + i_32_) / 2;
			    i_72_ = i_71_;
			}
			if (i_28_ == 3) {
			    i_71_ = (i_33_ + i_34_) / 2;
			    i_72_ = i_71_;
			}
			for (int i_73_ = 0; i_73_ < ((ContO) this).npl;
			     i_73_++) {
			    if (i_73_ != i_27_) {
				boolean bool_74_ = false;
				boolean[] bools
				    = (new boolean
				       [((Plane) ((ContO) this).p[i_73_]).n]);
				for (int i_75_ = 0;
				     (i_75_
				      < ((Plane) ((ContO) this).p[i_73_]).n);
				     i_75_++) {
				    bools[i_75_] = false;
				    for (int i_76_ = 0;
					 (i_76_
					  < (((Plane) ((ContO) this).p[i_27_])
					     .n));
					 i_76_++) {
					if (((((Plane) ((ContO) this).p[i_27_])
					      .ox[i_76_])
					     == ((Plane) (((ContO) this).p
							  [i_73_])).ox[i_75_])
					    && (((Plane) (((ContO) this).p
							  [i_27_])).oy[i_76_]
						== (((Plane)
						     ((ContO) this).p[i_73_])
						    .oy[i_75_]))
					    && (((Plane) (((ContO) this).p
							  [i_27_])).oz[i_76_]
						== (((Plane)
						     ((ContO) this).p[i_73_])
						    .oz[i_75_]))) {
					    bools[i_75_] = true;
					    bool_74_ = true;
					}
				    }
				}
				if (bool_74_) {
				    for (int i_77_ = 0;
					 (i_77_
					  < (((Plane) ((ContO) this).p[i_73_])
					     .n));
					 i_77_++) {
					if (!bools[i_77_]) {
					    if (i_28_ == 1) {
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .ox[i_77_])
						    > i_71_)
						    i_71_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .ox[i_77_]);
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .ox[i_77_])
						    < i_72_)
						    i_72_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .ox[i_77_]);
					    }
					    if (i_28_ == 2) {
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .oy[i_77_])
						    > i_71_)
						    i_71_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .oy[i_77_]);
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .oy[i_77_])
						    < i_72_)
						    i_72_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .oy[i_77_]);
					    }
					    if (i_28_ == 3) {
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .oz[i_77_])
						    > i_71_)
						    i_71_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .oz[i_77_]);
						if ((((Plane)
						      ((ContO) this).p[i_73_])
						     .oz[i_77_])
						    < i_72_)
						    i_72_ = (((Plane)
							      (((ContO) this).p
							       [i_73_]))
							     .oz[i_77_]);
					    }
					}
				    }
				}
			    }
			}
			if (i_28_ == 1) {
			    if ((i_71_ + i_72_) / 2 > (i_29_ + i_30_) / 2)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			    else if ((i_71_ + i_72_) / 2 == (i_29_ + i_30_) / 2
				     && (i_29_ + i_30_) / 2 < 0)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			}
			if (i_28_ == 2) {
			    if ((i_71_ + i_72_) / 2 > (i_31_ + i_32_) / 2)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			    else if ((i_71_ + i_72_) / 2 == (i_31_ + i_32_) / 2
				     && (i_31_ + i_32_) / 2 < 0)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			}
			if (i_28_ == 3) {
			    if ((i_71_ + i_72_) / 2 > (i_33_ + i_34_) / 2)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			    else if ((i_71_ + i_72_) / 2 == (i_33_ + i_34_) / 2
				     && (i_33_ + i_34_) / 2 < 0)
				((Plane) ((ContO) this).p[i_27_]).fs *= -1;
			}
		    }
		    ((ContO) this).p[i_27_].deltafntyp();
		}
	    }
	}
    }
    
    public ContO(ContO conto_78_, int i, int i_79_, int i_80_, int i_81_) {
	((ContO) this).keyx = new int[4];
	((ContO) this).keyz = new int[4];
	((ContO) this).sprkat = 0;
	((ContO) this).tnt = 0;
	((ContO) this).ust = 0;
	((ContO) this).srx = 0;
	((ContO) this).sry = 0;
	((ContO) this).srz = 0;
	((ContO) this).rcx = 0.0F;
	((ContO) this).rcy = 0.0F;
	((ContO) this).rcz = 0.0F;
	((ContO) this).sprk = 0;
	((ContO) this).elec = false;
	((ContO) this).roted = false;
	((ContO) this).edl = new int[4];
	((ContO) this).edr = new int[4];
	((ContO) this).elc = new int[] { 0, 0, 0, 0 };
	((ContO) this).fix = false;
	((ContO) this).fcnt = 0;
	((ContO) this).checkpoint = 0;
	((ContO) this).fcol = new int[] { 0, 0, 0 };
	((ContO) this).scol = new int[] { 0, 0, 0 };
	((ContO) this).colok = 0;
	((ContO) this).errd = false;
	((ContO) this).err = "";
	((ContO) this).roofat = 0;
	((ContO) this).wh = 0;
	((ContO) this).m = ((ContO) conto_78_).m;
	((ContO) this).t = ((ContO) conto_78_).t;
	((ContO) this).npl = ((ContO) conto_78_).npl;
	((ContO) this).maxR = ((ContO) conto_78_).maxR;
	((ContO) this).disp = ((ContO) conto_78_).disp;
	((ContO) this).disline = ((ContO) conto_78_).disline;
	((ContO) this).noline = ((ContO) conto_78_).noline;
	((ContO) this).shadow = ((ContO) conto_78_).shadow;
	((ContO) this).grounded = ((ContO) conto_78_).grounded;
	((ContO) this).decor = ((ContO) conto_78_).decor;
	if (((Medium) ((ContO) this).m).loadnew
	    && (i_81_ == 90 || i_81_ == -90))
	    ((ContO) this).grounded += 10000.0F;
	((ContO) this).grat = ((ContO) conto_78_).grat;
	((ContO) this).sprkat = ((ContO) conto_78_).sprkat;
	((ContO) this).p = new Plane[((ContO) conto_78_).npl];
	for (int i_82_ = 0; i_82_ < ((ContO) this).npl; i_82_++) {
	    if (((Plane) ((ContO) conto_78_).p[i_82_]).master == 1)
		((Plane) ((ContO) conto_78_).p[i_82_]).n = 20;
	    ((ContO) this).p[i_82_]
		= new Plane(((ContO) this).m, ((ContO) this).t,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).ox,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).oz,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).oy,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).n,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).oc,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).glass,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).gr,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).fs,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).wx,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).wy,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).wz,
			    ((ContO) conto_78_).disline,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).bfase,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).road,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).light,
			    ((Plane) ((ContO) conto_78_).p[i_82_]).solo);
	}
	((ContO) this).x = i;
	((ContO) this).y = i_79_;
	((ContO) this).z = i_80_;
	((ContO) this).xz = 0;
	((ContO) this).xy = 0;
	((ContO) this).zy = 0;
	for (int i_83_ = 0; i_83_ < ((ContO) this).npl; i_83_++) {
	    ((Plane) ((ContO) this).p[i_83_]).colnum
		= ((Plane) ((ContO) conto_78_).p[i_83_]).colnum;
	    ((Plane) ((ContO) this).p[i_83_]).master
		= ((Plane) ((ContO) conto_78_).p[i_83_]).master;
	    ((ContO) this).p[i_83_].rot(((Plane) ((ContO) this).p[i_83_]).ox,
					((Plane) ((ContO) this).p[i_83_]).oz,
					0, 0, i_81_,
					((Plane) ((ContO) this).p[i_83_]).n);
	    ((ContO) this).p[i_83_].loadprojf();
	}
	if (((ContO) conto_78_).tnt != 0) {
	    for (int i_84_ = 0; i_84_ < ((ContO) conto_78_).tnt; i_84_++) {
		((Trackers) ((ContO) this).t).xy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = (int) (((float) ((ContO) conto_78_).txy[i_84_]
			      * ((ContO) this).m.cos(i_81_))
			     - ((float) ((ContO) conto_78_).tzy[i_84_]
				* ((ContO) this).m.sin(i_81_)));
		((Trackers) ((ContO) this).t).zy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = (int) (((float) ((ContO) conto_78_).tzy[i_84_]
			      * ((ContO) this).m.cos(i_81_))
			     + ((float) ((ContO) conto_78_).txy[i_84_]
				* ((ContO) this).m.sin(i_81_)));
		for (int i_85_ = 0; i_85_ < 3; i_85_++) {
		    ((Trackers) ((ContO) this).t).c
			[((Trackers) ((ContO) this).t).nt][i_85_]
			= (int) ((float) ((ContO) conto_78_).tc[i_84_][i_85_]
				 + ((float) (((ContO) conto_78_).tc[i_84_]
					     [i_85_])
				    * ((float) (((Medium) ((ContO) this).m)
						.snap[i_85_])
				       / 100.0F)));
		    if ((((Trackers) ((ContO) this).t).c
			 [((Trackers) ((ContO) this).t).nt][i_85_])
			> 255)
			((Trackers) ((ContO) this).t).c
			    [((Trackers) ((ContO) this).t).nt][i_85_]
			    = 255;
		    if ((((Trackers) ((ContO) this).t).c
			 [((Trackers) ((ContO) this).t).nt][i_85_])
			< 0)
			((Trackers) ((ContO) this).t).c
			    [((Trackers) ((ContO) this).t).nt][i_85_]
			    = 0;
		}
		((Trackers) ((ContO) this).t).x[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (int) ((float) ((ContO) this).x
			     + ((float) ((ContO) conto_78_).tx[i_84_]
				* ((ContO) this).m.cos(i_81_))
			     - ((float) ((ContO) conto_78_).tz[i_84_]
				* ((ContO) this).m.sin(i_81_)));
		((Trackers) ((ContO) this).t).z[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (int) ((float) ((ContO) this).z
			     + ((float) ((ContO) conto_78_).tz[i_84_]
				* ((ContO) this).m.cos(i_81_))
			     + ((float) ((ContO) conto_78_).tx[i_84_]
				* ((ContO) this).m.sin(i_81_)));
		((Trackers) ((ContO) this).t).y[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = ((ContO) this).y + ((ContO) conto_78_).ty[i_84_];
		((Trackers) ((ContO) this).t).skd
		    [((Trackers) ((ContO) this).t).nt]
		    = ((ContO) conto_78_).skd[i_84_];
		((Trackers) ((ContO) this).t).dam
		    [((Trackers) ((ContO) this).t).nt]
		    = ((ContO) conto_78_).dam[i_84_];
		((Trackers) ((ContO) this).t).notwall
		    [((Trackers) ((ContO) this).t).nt]
		    = ((ContO) conto_78_).notwall[i_84_];
		if (((ContO) this).decor)
		    ((Trackers) ((ContO) this).t).decor
			[((Trackers) ((ContO) this).t).nt]
			= true;
		else
		    ((Trackers) ((ContO) this).t).decor
			[((Trackers) ((ContO) this).t).nt]
			= false;
		int i_86_ = Math.abs(i_81_);
		if (i_86_ == 180)
		    i_86_ = 0;
		((Trackers) ((ContO) this).t).radx
		    [((Trackers) ((ContO) this).t).nt]
		    = (int) Math.abs(((float) ((ContO) conto_78_).tradx[i_84_]
				      * ((ContO) this).m.cos(i_86_))
				     + ((float) (((ContO) conto_78_).tradz
						 [i_84_])
					* ((ContO) this).m.sin(i_86_)));
		((Trackers) ((ContO) this).t).radz
		    [((Trackers) ((ContO) this).t).nt]
		    = (int) Math.abs(((float) ((ContO) conto_78_).tradx[i_84_]
				      * ((ContO) this).m.sin(i_86_))
				     + ((float) (((ContO) conto_78_).tradz
						 [i_84_])
					* ((ContO) this).m.cos(i_86_)));
		((Trackers) ((ContO) this).t).rady
		    [((Trackers) ((ContO) this).t).nt]
		    = ((ContO) conto_78_).trady[i_84_];
		((Trackers) ((ContO) this).t).nt++;
	    }
	}
	for (int i_87_ = 0; i_87_ < 4; i_87_++) {
	    ((ContO) this).keyx[i_87_] = ((ContO) conto_78_).keyx[i_87_];
	    ((ContO) this).keyz[i_87_] = ((ContO) conto_78_).keyz[i_87_];
	}
	if (((ContO) this).shadow) {
	    ((ContO) this).stg = new int[20];
	    ((ContO) this).sx = new int[20];
	    ((ContO) this).sy = new int[20];
	    ((ContO) this).sz = new int[20];
	    ((ContO) this).scx = new int[20];
	    ((ContO) this).scz = new int[20];
	    ((ContO) this).osmag = new float[20];
	    ((ContO) this).sav = new int[20];
	    ((ContO) this).smag = new float[20][8];
	    ((ContO) this).srgb = new int[20][3];
	    ((ContO) this).sbln = new float[20];
	    ((ContO) this).ust = 0;
	    for (int i_88_ = 0; i_88_ < 20; i_88_++)
		((ContO) this).stg[i_88_] = 0;
	    ((ContO) this).rtg = new int[100];
	    ((ContO) this).rbef = new boolean[100];
	    ((ContO) this).rx = new int[100];
	    ((ContO) this).ry = new int[100];
	    ((ContO) this).rz = new int[100];
	    ((ContO) this).vrx = new float[100];
	    ((ContO) this).vry = new float[100];
	    ((ContO) this).vrz = new float[100];
	    for (int i_89_ = 0; i_89_ < 100; i_89_++)
		((ContO) this).rtg[i_89_] = 0;
	}
    }
    
    public ContO(int i, int i_90_, int i_91_, Medium medium, Trackers trackers,
		 int i_92_, int i_93_, int i_94_) {
	((ContO) this).keyx = new int[4];
	((ContO) this).keyz = new int[4];
	((ContO) this).sprkat = 0;
	((ContO) this).tnt = 0;
	((ContO) this).ust = 0;
	((ContO) this).srx = 0;
	((ContO) this).sry = 0;
	((ContO) this).srz = 0;
	((ContO) this).rcx = 0.0F;
	((ContO) this).rcy = 0.0F;
	((ContO) this).rcz = 0.0F;
	((ContO) this).sprk = 0;
	((ContO) this).elec = false;
	((ContO) this).roted = false;
	((ContO) this).edl = new int[4];
	((ContO) this).edr = new int[4];
	((ContO) this).elc = new int[] { 0, 0, 0, 0 };
	((ContO) this).fix = false;
	((ContO) this).fcnt = 0;
	((ContO) this).checkpoint = 0;
	((ContO) this).fcol = new int[] { 0, 0, 0 };
	((ContO) this).scol = new int[] { 0, 0, 0 };
	((ContO) this).colok = 0;
	((ContO) this).errd = false;
	((ContO) this).err = "";
	((ContO) this).roofat = 0;
	((ContO) this).wh = 0;
	((ContO) this).m = medium;
	((ContO) this).t = trackers;
	((ContO) this).x = i_92_;
	((ContO) this).z = i_93_;
	((ContO) this).y = i_94_;
	((ContO) this).xz = 0;
	((ContO) this).xy = 0;
	((ContO) this).zy = 0;
	((ContO) this).grat = 0;
	((ContO) this).sprkat = 0;
	((ContO) this).disline = 4;
	((ContO) this).noline = true;
	((ContO) this).shadow = false;
	((ContO) this).grounded = 115.0F;
	((ContO) this).decor = true;
	((ContO) this).npl = 5;
	((ContO) this).p = new Plane[5];
	Random random = new Random((long) i);
	int[] is = new int[8];
	int[] is_95_ = new int[8];
	int[] is_96_ = new int[8];
	int[] is_97_ = new int[8];
	int[] is_98_ = new int[8];
	float f = (float) i_90_;
	float f_99_ = (float) i_91_;
	if (f_99_ < 2.0F)
	    f_99_ = 2.0F;
	if (f_99_ > 6.0F)
	    f_99_ = 6.0F;
	if (f < 2.0F)
	    f = 2.0F;
	if (f > 6.0F)
	    f = 6.0F;
	f /= 1.5F;
	f_99_ /= 1.5F;
	f_99_ *= 1.0F + (f - 2.0F) * 0.1786F;
	float f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[0] = -(int) (f_100_ * f * 0.7071F);
	is_95_[0] = (int) (f_100_ * f * 0.7071F);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[1] = 0;
	is_95_[1] = (int) (f_100_ * f);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[2] = (int) ((double) (f_100_ * f) * 0.7071);
	is_95_[2] = (int) ((double) (f_100_ * f) * 0.7071);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[3] = (int) (f_100_ * f);
	is_95_[3] = 0;
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[4] = (int) ((double) (f_100_ * f) * 0.7071);
	is_95_[4] = -(int) ((double) (f_100_ * f) * 0.7071);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[5] = 0;
	is_95_[5] = -(int) (f_100_ * f);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[6] = -(int) ((double) (f_100_ * f) * 0.7071);
	is_95_[6] = -(int) ((double) (f_100_ * f) * 0.7071);
	f_100_ = (float) (50.0 + 100.0 * random.nextDouble());
	is[7] = -(int) (f_100_ * f);
	is_95_[7] = 0;
	for (int i_101_ = 0; i_101_ < 8; i_101_++) {
	    is_96_[i_101_] = (int) ((double) is[i_101_]
				    * (0.2 + 0.4 * random.nextDouble()));
	    is_97_[i_101_] = (int) ((double) is_95_[i_101_]
				    * (0.2 + 0.4 * random.nextDouble()));
	    is_98_[i_101_] = -(int) ((10.0 + 15.0 * random.nextDouble())
				     * (double) f_99_);
	}
	((ContO) this).maxR = 0;
	for (int i_102_ = 0; i_102_ < 8; i_102_++) {
	    int i_103_ = i_102_ - 1;
	    if (i_103_ == -1)
		i_103_ = 7;
	    int i_104_ = i_102_ + 1;
	    if (i_104_ == 8)
		i_104_ = 0;
	    is[i_102_] = ((is[i_103_] + is[i_104_]) / 2 + is[i_102_]) / 2;
	    is_95_[i_102_]
		= ((is_95_[i_103_] + is_95_[i_104_]) / 2 + is_95_[i_102_]) / 2;
	    is_96_[i_102_]
		= ((is_96_[i_103_] + is_96_[i_104_]) / 2 + is_96_[i_102_]) / 2;
	    is_97_[i_102_]
		= ((is_97_[i_103_] + is_97_[i_104_]) / 2 + is_97_[i_102_]) / 2;
	    is_98_[i_102_]
		= ((is_98_[i_103_] + is_98_[i_104_]) / 2 + is_98_[i_102_]) / 2;
	    int i_105_ = (int) Math.sqrt((double) (is[i_102_] * is[i_102_]
						   + (is_95_[i_102_]
						      * is_95_[i_102_])));
	    if (i_105_ > ((ContO) this).maxR)
		((ContO) this).maxR = i_105_;
	    i_105_
		= (int) Math.sqrt((double) (is_96_[i_102_] * is_96_[i_102_]
					    + is_98_[i_102_] * is_98_[i_102_]
					    + (is_97_[i_102_]
					       * is_97_[i_102_])));
	    if (i_105_ > ((ContO) this).maxR)
		((ContO) this).maxR = i_105_;
	}
	((ContO) this).disp = ((ContO) this).maxR / 17;
	int[] is_106_ = new int[3];
	float f_107_ = -1.0F;
	float f_108_ = (f / f_99_ - 0.33F) / 33.4F;
	if ((double) f_108_ < 0.005)
	    f_108_ = 0.0F;
	if ((double) f_108_ > 0.057)
	    f_108_ = 0.057F;
	for (int i_109_ = 0; i_109_ < 4; i_109_++) {
	    int i_110_ = i_109_ * 2;
	    int i_111_ = i_110_ + 2;
	    if (i_111_ == 8)
		i_111_ = 0;
	    int[] is_112_ = new int[6];
	    int[] is_113_ = new int[6];
	    int[] is_114_ = new int[6];
	    is_112_[0] = is[i_110_];
	    is_112_[1] = is[i_110_ + 1];
	    is_112_[2] = is[i_111_];
	    is_112_[5] = is_96_[i_110_];
	    is_112_[4] = is_96_[i_110_ + 1];
	    is_112_[3] = is_96_[i_111_];
	    is_114_[0] = is_95_[i_110_];
	    is_114_[1] = is_95_[i_110_ + 1];
	    is_114_[2] = is_95_[i_111_];
	    is_114_[5] = is_97_[i_110_];
	    is_114_[4] = is_97_[i_110_ + 1];
	    is_114_[3] = is_97_[i_111_];
	    is_113_[0] = 0;
	    is_113_[1] = 0;
	    is_113_[2] = 0;
	    is_113_[5] = is_98_[i_110_];
	    is_113_[4] = is_98_[i_110_ + 1];
	    is_113_[3] = is_98_[i_111_];
	    for (f_100_ = (float) ((0.17 - (double) f_108_)
				   * random.nextDouble());
		 ((double) Math.abs(f_107_ - f_100_)
		  < 0.03 - (double) (f_108_ * 0.176F));
		 f_100_ = (float) ((0.17 - (double) f_108_)
				   * random.nextDouble())) {
		/* empty */
	    }
	    f_107_ = f_100_;
	    for (int i_115_ = 0; i_115_ < 3; i_115_++) {
		if (((Medium) ((ContO) this).m).trk == 2)
		    is_106_[i_115_]
			= (int) (390.0F / (2.2F + f_100_ - f_108_));
		else
		    is_106_[i_115_]
			= (int) ((float) ((((Medium) ((ContO) this).m).cpol
					   [i_115_])
					  + (((Medium) ((ContO) this).m).cgrnd
					     [i_115_]))
				 / (2.2F + f_100_ - f_108_));
	    }
	    ((ContO) this).p[i_109_]
		= new Plane(((ContO) this).m, ((ContO) this).t, is_112_,
			    is_114_, is_113_, 6, is_106_, 3, -8, 0, 0, 0, 0,
			    ((ContO) this).disline, 0, true, 0, false);
	}
	f_100_ = (float) (0.02 * random.nextDouble());
	for (int i_116_ = 0; i_116_ < 3; i_116_++) {
	    if (((Medium) ((ContO) this).m).trk == 2)
		is_106_[i_116_] = (int) (390.0F / (2.15F + f_100_));
	    else
		is_106_[i_116_]
		    = (int) ((float) (((Medium) ((ContO) this).m).cpol[i_116_]
				      + (((Medium) ((ContO) this).m).cgrnd
					 [i_116_]))
			     / (2.15F + f_100_));
	}
	((ContO) this).p[4]
	    = new Plane(((ContO) this).m, ((ContO) this).t, is_96_, is_97_,
			is_98_, 8, is_106_, 3, -8, 0, 0, 0, 0,
			((ContO) this).disline, 0, true, 0, false);
	int[] is_117_ = new int[2];
	int[] is_118_ = new int[2];
	for (int i_119_ = 0; i_119_ < 4; i_119_++) {
	    int i_120_ = i_119_ * 2 + 1;
	    ((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt]
		= is_98_[i_120_] / 2;
	    ((Trackers) ((ContO) this).t).rady[(((Trackers) ((ContO) this).t)
						.nt)]
		= Math.abs(is_98_[i_120_] / 2);
	    if (i_119_ == 0 || i_119_ == 2) {
		((Trackers) ((ContO) this).t).z[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (is_95_[i_120_] + is_97_[i_120_]) / 2;
		((Trackers) ((ContO) this).t).radz
		    [((Trackers) ((ContO) this).t).nt]
		    = Math.abs((((Trackers) ((ContO) this).t).z
				[((Trackers) ((ContO) this).t).nt])
			       - is_95_[i_120_]);
		i_120_ = i_119_ * 2 + 2;
		if (i_120_ == 8)
		    i_120_ = 0;
		((Trackers) ((ContO) this).t).x[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (is[i_119_ * 2] + is[i_120_]) / 2;
		((Trackers) ((ContO) this).t).radx
		    [((Trackers) ((ContO) this).t).nt]
		    = Math.abs((((Trackers) ((ContO) this).t).x
				[((Trackers) ((ContO) this).t).nt])
			       - is[i_119_ * 2]);
	    } else {
		((Trackers) ((ContO) this).t).x[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (is[i_120_] + is_96_[i_120_]) / 2;
		((Trackers) ((ContO) this).t).radx
		    [((Trackers) ((ContO) this).t).nt]
		    = Math.abs((((Trackers) ((ContO) this).t).x
				[((Trackers) ((ContO) this).t).nt])
			       - is[i_120_]);
		i_120_ = i_119_ * 2 + 2;
		if (i_120_ == 8)
		    i_120_ = 0;
		((Trackers) ((ContO) this).t).z[(((Trackers) ((ContO) this).t)
						 .nt)]
		    = (is_95_[i_119_ * 2] + is_95_[i_120_]) / 2;
		((Trackers) ((ContO) this).t).radz
		    [((Trackers) ((ContO) this).t).nt]
		    = Math.abs((((Trackers) ((ContO) this).t).z
				[((Trackers) ((ContO) this).t).nt])
			       - is_95_[i_119_ * 2]);
	    }
	    if (i_119_ == 0) {
		is_118_[0] = ((((Trackers) ((ContO) this).t).z
			       [((Trackers) ((ContO) this).t).nt])
			      - (((Trackers) ((ContO) this).t).radz
				 [((Trackers) ((ContO) this).t).nt]));
		((Trackers) ((ContO) this).t).zy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = (int) ((Math.atan
			      ((double) (((Trackers) ((ContO) this).t).rady
					 [((Trackers) ((ContO) this).t).nt])
			       / (double) (((Trackers) ((ContO) this).t).radz
					   [(((Trackers) ((ContO) this).t)
					     .nt)])))
			     / 0.017453292519943295);
		if ((((Trackers) ((ContO) this).t).zy
		     [((Trackers) ((ContO) this).t).nt])
		    > 40)
		    ((Trackers) ((ContO) this).t).zy
			[((Trackers) ((ContO) this).t).nt]
			= 40;
		((Trackers) ((ContO) this).t).xy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = 0;
	    }
	    if (i_119_ == 1) {
		is_117_[0] = ((((Trackers) ((ContO) this).t).x
			       [((Trackers) ((ContO) this).t).nt])
			      - (((Trackers) ((ContO) this).t).radx
				 [((Trackers) ((ContO) this).t).nt]));
		((Trackers) ((ContO) this).t).xy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = (int) ((Math.atan
			      ((double) (((Trackers) ((ContO) this).t).rady
					 [((Trackers) ((ContO) this).t).nt])
			       / (double) (((Trackers) ((ContO) this).t).radx
					   [(((Trackers) ((ContO) this).t)
					     .nt)])))
			     / 0.017453292519943295);
		if ((((Trackers) ((ContO) this).t).xy
		     [((Trackers) ((ContO) this).t).nt])
		    > 40)
		    ((Trackers) ((ContO) this).t).xy
			[((Trackers) ((ContO) this).t).nt]
			= 40;
		((Trackers) ((ContO) this).t).zy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = 0;
	    }
	    if (i_119_ == 2) {
		is_118_[1] = ((((Trackers) ((ContO) this).t).z
			       [((Trackers) ((ContO) this).t).nt])
			      + (((Trackers) ((ContO) this).t).radz
				 [((Trackers) ((ContO) this).t).nt]));
		((Trackers) ((ContO) this).t).zy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = -(int) ((Math.atan
			       ((double) (((Trackers) ((ContO) this).t).rady
					  [((Trackers) ((ContO) this).t).nt])
				/ (double) (((Trackers) ((ContO) this).t).radz
					    [(((Trackers) ((ContO) this).t)
					      .nt)])))
			      / 0.017453292519943295);
		if ((((Trackers) ((ContO) this).t).zy
		     [((Trackers) ((ContO) this).t).nt])
		    < -40)
		    ((Trackers) ((ContO) this).t).zy
			[((Trackers) ((ContO) this).t).nt]
			= -40;
		((Trackers) ((ContO) this).t).xy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = 0;
	    }
	    if (i_119_ == 3) {
		is_117_[1] = ((((Trackers) ((ContO) this).t).x
			       [((Trackers) ((ContO) this).t).nt])
			      + (((Trackers) ((ContO) this).t).radx
				 [((Trackers) ((ContO) this).t).nt]));
		((Trackers) ((ContO) this).t).xy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = -(int) ((Math.atan
			       ((double) (((Trackers) ((ContO) this).t).rady
					  [((Trackers) ((ContO) this).t).nt])
				/ (double) (((Trackers) ((ContO) this).t).radx
					    [(((Trackers) ((ContO) this).t)
					      .nt)])))
			      / 0.017453292519943295);
		if ((((Trackers) ((ContO) this).t).xy
		     [((Trackers) ((ContO) this).t).nt])
		    < -40)
		    ((Trackers) ((ContO) this).t).xy
			[((Trackers) ((ContO) this).t).nt]
			= -40;
		((Trackers) ((ContO) this).t).zy[(((Trackers) ((ContO) this).t)
						  .nt)]
		    = 0;
	    }
	    ((Trackers) ((ContO) this).t).x[((Trackers) ((ContO) this).t).nt]
		+= ((ContO) this).x;
	    ((Trackers) ((ContO) this).t).z[((Trackers) ((ContO) this).t).nt]
		+= ((ContO) this).z;
	    ((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt]
		+= ((ContO) this).y;
	    for (int i_121_ = 0; i_121_ < 3; i_121_++)
		((Trackers) ((ContO) this).t).c
		    [((Trackers) ((ContO) this).t).nt][i_121_]
		    = ((Plane) ((ContO) this).p[i_119_]).oc[i_121_];
	    ((Trackers) ((ContO) this).t).skd[((Trackers) ((ContO) this).t).nt]
		= 2;
	    ((Trackers) ((ContO) this).t).dam[((Trackers) ((ContO) this).t).nt]
		= 1;
	    ((Trackers) ((ContO) this).t).notwall
		[((Trackers) ((ContO) this).t).nt]
		= false;
	    ((Trackers) ((ContO) this).t).decor[(((Trackers) ((ContO) this).t)
						 .nt)]
		= true;
	    ((Trackers) ((ContO) this).t).rady[(((Trackers) ((ContO) this).t)
						.nt)]
		+= 10;
	    ((Trackers) ((ContO) this).t).nt++;
	}
	((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt] = 0;
	for (int i_122_ = 0; i_122_ < 8; i_122_++)
	    ((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt]
		+= is_98_[i_122_];
	((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt]
	    = (((Trackers) ((ContO) this).t).y
	       [((Trackers) ((ContO) this).t).nt]) / 8;
	((Trackers) ((ContO) this).t).y[((Trackers) ((ContO) this).t).nt]
	    += ((ContO) this).y;
	((Trackers) ((ContO) this).t).rady[((Trackers) ((ContO) this).t).nt]
	    = 200;
	((Trackers) ((ContO) this).t).radx[((Trackers) ((ContO) this).t).nt]
	    = is_117_[0] - is_117_[1];
	((Trackers) ((ContO) this).t).radz[((Trackers) ((ContO) this).t).nt]
	    = is_118_[0] - is_118_[1];
	((Trackers) ((ContO) this).t).x[((Trackers) ((ContO) this).t).nt]
	    = (is_117_[0] + is_117_[1]) / 2 + ((ContO) this).x;
	((Trackers) ((ContO) this).t).z[((Trackers) ((ContO) this).t).nt]
	    = (is_118_[0] + is_118_[1]) / 2 + ((ContO) this).z;
	((Trackers) ((ContO) this).t).zy[((Trackers) ((ContO) this).t).nt] = 0;
	((Trackers) ((ContO) this).t).xy[((Trackers) ((ContO) this).t).nt] = 0;
	for (int i_123_ = 0; i_123_ < 3; i_123_++)
	    ((Trackers) ((ContO) this).t).c
		[((Trackers) ((ContO) this).t).nt][i_123_]
		= ((Plane) ((ContO) this).p[4]).oc[i_123_];
	((Trackers) ((ContO) this).t).skd[((Trackers) ((ContO) this).t).nt]
	    = 4;
	((Trackers) ((ContO) this).t).dam[((Trackers) ((ContO) this).t).nt]
	    = 1;
	((Trackers) ((ContO) this).t).notwall[((Trackers) ((ContO) this).t).nt]
	    = false;
	((Trackers) ((ContO) this).t).decor[((Trackers) ((ContO) this).t).nt]
	    = true;
	((Trackers) ((ContO) this).t).nt++;
    }
    
    public void d(Graphics2D graphics2d) {
	if (((ContO) this).dist != 0)
	    ((ContO) this).dist = 0;
	int i = (((Medium) ((ContO) this).m).cx
		 + (int) (((float) (((ContO) this).x
				    - ((Medium) ((ContO) this).m).x
				    - ((Medium) ((ContO) this).m).cx)
			   * ((ContO) this).m
				 .cos(((Medium) ((ContO) this).m).xz))
			  - ((float) (((ContO) this).z
				      - ((Medium) ((ContO) this).m).z
				      - ((Medium) ((ContO) this).m).cz)
			     * ((ContO) this).m
				   .sin(((Medium) ((ContO) this).m).xz))));
	int i_124_
	    = (((Medium) ((ContO) this).m).cz
	       + (int) (((float) (((ContO) this).x
				  - ((Medium) ((ContO) this).m).x
				  - ((Medium) ((ContO) this).m).cx)
			 * ((ContO) this).m
			       .sin(((Medium) ((ContO) this).m).xz))
			+ ((float) (((ContO) this).z
				    - ((Medium) ((ContO) this).m).z
				    - ((Medium) ((ContO) this).m).cz)
			   * ((ContO) this).m
				 .cos(((Medium) ((ContO) this).m).xz))));
	int i_125_
	    = (((Medium) ((ContO) this).m).cz
	       + (int) (((float) (((ContO) this).y
				  - ((Medium) ((ContO) this).m).y
				  - ((Medium) ((ContO) this).m).cy)
			 * ((ContO) this).m
			       .sin(((Medium) ((ContO) this).m).zy))
			+ ((float) (i_124_ - ((Medium) ((ContO) this).m).cz)
			   * ((ContO) this).m
				 .cos(((Medium) ((ContO) this).m).zy))));
	int i_126_ = (xs(i + ((ContO) this).maxR, i_125_)
		      - xs(i - ((ContO) this).maxR, i_125_));
	if ((xs(i + ((ContO) this).maxR * 2, i_125_)
	     > ((Medium) ((ContO) this).m).iw)
	    && (xs(i - ((ContO) this).maxR * 2, i_125_)
		< ((Medium) ((ContO) this).m).w)
	    && i_125_ > -((ContO) this).maxR
	    && (i_125_ < (((Medium) ((ContO) this).m).fade
			  [((ContO) this).disline]) + ((ContO) this).maxR
		|| ((Medium) ((ContO) this).m).trk != 0)
	    && (i_126_ > ((ContO) this).disp
		|| ((Medium) ((ContO) this).m).trk != 0)
	    && (!((ContO) this).decor
		|| (((Medium) ((ContO) this).m).resdown != 2
		    && ((Medium) ((ContO) this).m).trk != 1))) {
	    if (((ContO) this).shadow) {
		if (!((Medium) ((ContO) this).m).crs) {
		    if (i_125_ < 2000) {
			boolean bool = false;
			if (((Trackers) ((ContO) this).t).ncx != 0
			    || ((Trackers) ((ContO) this).t).ncz != 0) {
			    int i_127_ = ((((ContO) this).x
					   - ((Trackers) ((ContO) this).t).sx)
					  / 3000);
			    if (i_127_ > ((Trackers) ((ContO) this).t).ncx)
				i_127_ = ((Trackers) ((ContO) this).t).ncx;
			    if (i_127_ < 0)
				i_127_ = 0;
			    int i_128_ = ((((ContO) this).z
					   - ((Trackers) ((ContO) this).t).sz)
					  / 3000);
			    if (i_128_ > ((Trackers) ((ContO) this).t).ncz)
				i_128_ = ((Trackers) ((ContO) this).t).ncz;
			    if (i_128_ < 0)
				i_128_ = 0;
			    for (int i_129_ = ((((Trackers) ((ContO) this).t)
						.sect[i_127_][i_128_]).length
					       - 1);
				 i_129_ >= 0; i_129_--) {
				int i_130_ = (((Trackers) ((ContO) this).t)
					      .sect[i_127_][i_128_][i_129_]);
				if (Math.abs(((Trackers) ((ContO) this).t).zy
					     [i_130_]) != 90
				    && Math.abs(((Trackers) ((ContO) this).t)
						.xy[i_130_]) != 90
				    && (Math.abs(((ContO) this).x
						 - ((Trackers) (((ContO) this)
								.t)).x[i_130_])
					< (((Trackers) ((ContO) this).t).radx
					   [i_130_]) + ((ContO) this).maxR)
				    && (Math.abs(((ContO) this).z
						 - ((Trackers) (((ContO) this)
								.t)).z[i_130_])
					< (((Trackers) ((ContO) this).t).radz
					   [i_130_]) + ((ContO) this).maxR)
				    && (!(((Trackers) ((ContO) this).t).decor
					  [i_130_])
					|| (((Medium) ((ContO) this).m).resdown
					    != 2))) {
				    bool = true;
				    break;
				}
			    }
			}
			if (bool) {
			    for (int i_131_ = 0; i_131_ < ((ContO) this).npl;
				 i_131_++)
				((ContO) this).p[i_131_].s
				    (graphics2d,
				     (((ContO) this).x
				      - ((Medium) ((ContO) this).m).x),
				     (((ContO) this).y
				      - ((Medium) ((ContO) this).m).y),
				     (((ContO) this).z
				      - ((Medium) ((ContO) this).m).z),
				     ((ContO) this).xz, ((ContO) this).xy,
				     ((ContO) this).zy, 0);
			} else {
			    int i_132_
				= (((Medium) ((ContO) this).m).cy
				   + (int) (((float) (((Medium)
						       ((ContO) this).m).ground
						      - ((Medium)
							 ((ContO) this).m).cy)
					     * ((ContO) this).m.cos(((Medium)
								     ((ContO)
								      this).m)
								    .zy))
					    - ((float) (i_124_
							- (((Medium)
							    ((ContO) this).m)
							   .cz))
					       * (((ContO) this).m.sin
						  (((Medium) ((ContO) this).m)
						   .zy)))));
			    int i_133_
				= (((Medium) ((ContO) this).m).cz
				   + (int) (((float) (((Medium)
						       ((ContO) this).m).ground
						      - ((Medium)
							 ((ContO) this).m).cy)
					     * ((ContO) this).m.sin(((Medium)
								     ((ContO)
								      this).m)
								    .zy))
					    + ((float) (i_124_
							- (((Medium)
							    ((ContO) this).m)
							   .cz))
					       * (((ContO) this).m.cos
						  (((Medium) ((ContO) this).m)
						   .zy)))));
			    if (ys(i_132_ + ((ContO) this).maxR, i_133_) > 0
				&& (ys(i_132_ - ((ContO) this).maxR, i_133_)
				    < ((Medium) ((ContO) this).m).h)) {
				for (int i_134_ = 0;
				     i_134_ < ((ContO) this).npl; i_134_++)
				    ((ContO) this).p[i_134_].s
					(graphics2d,
					 (((ContO) this).x
					  - ((Medium) ((ContO) this).m).x),
					 (((ContO) this).y
					  - ((Medium) ((ContO) this).m).y),
					 (((ContO) this).z
					  - ((Medium) ((ContO) this).m).z),
					 ((ContO) this).xz, ((ContO) this).xy,
					 ((ContO) this).zy, 1);
			    }
			}
			((ContO) this).m.addsp
			    (((ContO) this).x - ((Medium) ((ContO) this).m).x,
			     ((ContO) this).z - ((Medium) ((ContO) this).m).z,
			     (int) ((double) ((ContO) this).maxR * 0.8));
		    } else
			lowshadow(graphics2d, i_125_);
		} else {
		    for (int i_135_ = 0; i_135_ < ((ContO) this).npl; i_135_++)
			((ContO) this).p[i_135_].s
			    (graphics2d,
			     ((ContO) this).x - ((Medium) ((ContO) this).m).x,
			     ((ContO) this).y - ((Medium) ((ContO) this).m).y,
			     ((ContO) this).z - ((Medium) ((ContO) this).m).z,
			     ((ContO) this).xz, ((ContO) this).xy,
			     ((ContO) this).zy, 2);
		}
	    }
	    int i_136_
		= (((Medium) ((ContO) this).m).cy
		   + (int) (((float) (((ContO) this).y
				      - ((Medium) ((ContO) this).m).y
				      - ((Medium) ((ContO) this).m).cy)
			     * ((ContO) this).m
				   .cos(((Medium) ((ContO) this).m).zy))
			    - ((float) (i_124_
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .sin(((Medium) ((ContO) this).m).zy))));
	    if ((ys(i_136_ + ((ContO) this).maxR, i_125_)
		 > ((Medium) ((ContO) this).m).ih)
		&& (ys(i_136_ - ((ContO) this).maxR, i_125_)
		    < ((Medium) ((ContO) this).m).h)) {
		if (((ContO) this).elec
		    && ((Medium) ((ContO) this).m).noelec == 0)
		    electrify(graphics2d);
		if (((ContO) this).fix)
		    fixit(graphics2d);
		if (((ContO) this).checkpoint != 0
		    && (((ContO) this).checkpoint - 1
			== ((Medium) ((ContO) this).m).checkpoint))
		    i_126_ = -1;
		if (((ContO) this).shadow) {
		    ((ContO) this).dist
			= (int) (Math.sqrt
				 ((double) (((((Medium) ((ContO) this).m).x
					      + ((Medium) ((ContO) this).m).cx
					      - ((ContO) this).x)
					     * (((Medium) ((ContO) this).m).x
						+ (((Medium) ((ContO) this).m)
						   .cx)
						- ((ContO) this).x))
					    + ((((Medium) ((ContO) this).m).z
						- ((ContO) this).z)
					       * (((Medium) ((ContO) this).m).z
						  - ((ContO) this).z))
					    + ((((Medium) ((ContO) this).m).y
						+ (((Medium) ((ContO) this).m)
						   .cy)
						- ((ContO) this).y)
					       * (((Medium) ((ContO) this).m).y
						  + ((Medium)
						     ((ContO) this).m).cy
						  - ((ContO) this).y)))));
		    for (int i_137_ = 0; i_137_ < 20; i_137_++) {
			if (((ContO) this).stg[i_137_] != 0)
			    pdust(i_137_, graphics2d, true);
		    }
		    dsprk(graphics2d, true);
		}
		int[] is = new int[((ContO) this).npl];
		int[] is_138_ = new int[((ContO) this).npl];
		for (int i_139_ = 0; i_139_ < ((ContO) this).npl; i_139_++)
		    is[i_139_] = 0;
		for (int i_140_ = 0; i_140_ < ((ContO) this).npl; i_140_++) {
		    for (int i_141_ = i_140_ + 1; i_141_ < ((ContO) this).npl;
			 i_141_++) {
			if (((Plane) ((ContO) this).p[i_140_]).av
			    != ((Plane) ((ContO) this).p[i_141_]).av) {
			    if (((Plane) ((ContO) this).p[i_140_]).av
				< ((Plane) ((ContO) this).p[i_141_]).av)
				is[i_140_]++;
			    else
				is[i_141_]++;
			} else if (i_140_ > i_141_)
			    is[i_140_]++;
			else
			    is[i_141_]++;
		    }
		    is_138_[is[i_140_]] = i_140_;
		}
		for (int i_142_ = 0; i_142_ < ((ContO) this).npl; i_142_++)
		    ((ContO) this).p[is_138_[i_142_]].d
			(graphics2d,
			 ((ContO) this).x - ((Medium) ((ContO) this).m).x,
			 ((ContO) this).y - ((Medium) ((ContO) this).m).y,
			 ((ContO) this).z - ((Medium) ((ContO) this).m).z,
			 ((ContO) this).xz, ((ContO) this).xy,
			 ((ContO) this).zy, ((ContO) this).wxz,
			 ((ContO) this).wzy, ((ContO) this).noline, i_126_);
		if (((ContO) this).shadow) {
		    for (int i_143_ = 0; i_143_ < 20; i_143_++) {
			if (((ContO) this).stg[i_143_] != 0)
			    pdust(i_143_, graphics2d, false);
		    }
		    dsprk(graphics2d, false);
		}
		((ContO) this).dist
		    = (int) ((Math.sqrt
			      ((double) (int) Math.sqrt
					      ((double) (((((Medium)
							    ((ContO) this).m).x
							   + ((Medium)
							      (((ContO) this)
							       .m)).cx
							   - ((ContO) this).x)
							  * (((Medium)
							      (((ContO) this)
							       .m)).x
							     + ((Medium)
								(((ContO) this)
								 .m)).cx
							     - (((ContO) this)
								.x)))
							 + ((((Medium)
							      (((ContO) this)
							       .m)).z
							     - (((ContO) this)
								.z))
							    * (((Medium)
								(((ContO) this)
								 .m)).z
							       - ((ContO)
								  this).z))
							 + ((((Medium)
							      (((ContO) this)
							       .m)).y
							     + ((Medium)
								(((ContO) this)
								 .m)).cy
							     - (((ContO) this)
								.y))
							    * (((Medium)
								(((ContO) this)
								 .m)).y
							       + ((Medium)
								  ((ContO)
								   this).m).cy
							       - ((ContO)
								  this).y))))))
			     * (double) ((ContO) this).grounded);
	    }
	}
	if (((ContO) this).shadow && ((ContO) this).dist == 0) {
	    for (int i_144_ = 0; i_144_ < 20; i_144_++) {
		if (((ContO) this).stg[i_144_] != 0)
		    ((ContO) this).stg[i_144_] = 0;
	    }
	    for (int i_145_ = 0; i_145_ < 100; i_145_++) {
		if (((ContO) this).rtg[i_145_] != 0)
		    ((ContO) this).rtg[i_145_] = 0;
	    }
	    if (((ContO) this).sprk != 0)
		((ContO) this).sprk = 0;
	}
    }
    
    public void lowshadow(Graphics2D graphics2d, int i) {
	int[] is = new int[4];
	int[] is_146_ = new int[4];
	int[] is_147_ = new int[4];
	int i_148_ = 1;
	int i_149_;
	for (i_149_ = Math.abs(((ContO) this).zy); i_149_ > 270;
	     i_149_ -= 360) {
	    /* empty */
	}
	i_149_ = Math.abs(i_149_);
	if (i_149_ > 90)
	    i_148_ = -1;
	is[0] = (int) ((double) ((ContO) this).keyx[0] * 1.2
		       + (double) ((ContO) this).x
		       - (double) ((Medium) ((ContO) this).m).x);
	is_147_[0]
	    = (int) ((double) ((((ContO) this).keyz[0] + 30) * i_148_) * 1.2
		     + (double) ((ContO) this).z
		     - (double) ((Medium) ((ContO) this).m).z);
	is[1] = (int) ((double) ((ContO) this).keyx[1] * 1.2
		       + (double) ((ContO) this).x
		       - (double) ((Medium) ((ContO) this).m).x);
	is_147_[1]
	    = (int) ((double) ((((ContO) this).keyz[1] + 30) * i_148_) * 1.2
		     + (double) ((ContO) this).z
		     - (double) ((Medium) ((ContO) this).m).z);
	is[2] = (int) ((double) ((ContO) this).keyx[3] * 1.2
		       + (double) ((ContO) this).x
		       - (double) ((Medium) ((ContO) this).m).x);
	is_147_[2]
	    = (int) ((double) ((((ContO) this).keyz[3] - 30) * i_148_) * 1.2
		     + (double) ((ContO) this).z
		     - (double) ((Medium) ((ContO) this).m).z);
	is[3] = (int) ((double) ((ContO) this).keyx[2] * 1.2
		       + (double) ((ContO) this).x
		       - (double) ((Medium) ((ContO) this).m).x);
	is_147_[3]
	    = (int) ((double) ((((ContO) this).keyz[2] - 30) * i_148_) * 1.2
		     + (double) ((ContO) this).z
		     - (double) ((Medium) ((ContO) this).m).z);
	rot(is, is_147_, ((ContO) this).x - ((Medium) ((ContO) this).m).x,
	    ((ContO) this).z - ((Medium) ((ContO) this).m).z,
	    ((ContO) this).xz, 4);
	int i_150_
	    = (int) ((double) (float) ((Medium) ((ContO) this).m).crgrnd[0]
		     / 1.5);
	int i_151_
	    = (int) ((double) (float) ((Medium) ((ContO) this).m).crgrnd[1]
		     / 1.5);
	int i_152_
	    = (int) ((double) (float) ((Medium) ((ContO) this).m).crgrnd[2]
		     / 1.5);
	for (int i_153_ = 0; i_153_ < 4; i_153_++)
	    is_146_[i_153_] = ((Medium) ((ContO) this).m).ground;
	if (((Trackers) ((ContO) this).t).ncx != 0
	    || ((Trackers) ((ContO) this).t).ncz != 0) {
	    int i_154_
		= (((ContO) this).x - ((Trackers) ((ContO) this).t).sx) / 3000;
	    if (i_154_ > ((Trackers) ((ContO) this).t).ncx)
		i_154_ = ((Trackers) ((ContO) this).t).ncx;
	    if (i_154_ < 0)
		i_154_ = 0;
	    int i_155_
		= (((ContO) this).z - ((Trackers) ((ContO) this).t).sz) / 3000;
	    if (i_155_ > ((Trackers) ((ContO) this).t).ncz)
		i_155_ = ((Trackers) ((ContO) this).t).ncz;
	    if (i_155_ < 0)
		i_155_ = 0;
	    for (int i_156_ = (((Trackers) ((ContO) this).t).sect[i_154_]
			       [i_155_]).length - 1;
		 i_156_ >= 0; i_156_--) {
		int i_157_ = (((Trackers) ((ContO) this).t).sect[i_154_]
			      [i_155_][i_156_]);
		int i_158_ = 0;
		for (int i_159_ = 0; i_159_ < 4; i_159_++) {
		    if ((Math.abs(((Trackers) ((ContO) this).t).zy[i_157_])
			 != 90)
			&& (Math.abs(((Trackers) ((ContO) this).t).xy[i_157_])
			    != 90)
			&& ((Trackers) ((ContO) this).t).rady[i_157_] != 801
			&& (Math.abs(is[i_159_]
				     - (((Trackers) ((ContO) this).t).x[i_157_]
					- ((Medium) ((ContO) this).m).x))
			    < ((Trackers) ((ContO) this).t).radx[i_157_])
			&& (Math.abs(is_147_[i_159_]
				     - (((Trackers) ((ContO) this).t).z[i_157_]
					- ((Medium) ((ContO) this).m).z))
			    < ((Trackers) ((ContO) this).t).radz[i_157_])
			&& (!((Trackers) ((ContO) this).t).decor[i_157_]
			    || ((Medium) ((ContO) this).m).resdown != 2))
			i_158_++;
		}
		if (i_158_ > 2) {
		    for (int i_160_ = 0; i_160_ < 4; i_160_++) {
			is_146_[i_160_]
			    = (((Trackers) ((ContO) this).t).y[i_157_]
			       - ((Medium) ((ContO) this).m).y);
			if (((Trackers) ((ContO) this).t).zy[i_157_] != 0)
			    is_146_[i_160_]
				+= (((float) (is_147_[i_160_]
					      - ((((Trackers) ((ContO) this).t)
						  .z[i_157_])
						 - (((Medium) ((ContO) this).m)
						    .z)
						 - (((Trackers)
						     ((ContO) this).t)
						    .radz[i_157_])))
				     * ((ContO) this).m.sin(((Trackers)
							     ((ContO) this).t)
							    .zy[i_157_])
				     / ((ContO) this).m.sin(90
							    - (((Trackers)
								(((ContO) this)
								 .t))
							       .zy[i_157_])))
				    - ((float) (((Trackers) ((ContO) this).t)
						.radz[i_157_])
				       * ((ContO) this).m.sin(((Trackers)
							       (((ContO) this)
								.t))
							      .zy[i_157_])
				       / (((ContO) this).m.sin
					  (90 - (((Trackers) ((ContO) this).t)
						 .zy[i_157_])))));
			if (((Trackers) ((ContO) this).t).xy[i_157_] != 0)
			    is_146_[i_160_]
				+= (((float) (is[i_160_]
					      - ((((Trackers) ((ContO) this).t)
						  .x[i_157_])
						 - (((Medium) ((ContO) this).m)
						    .x)
						 - (((Trackers)
						     ((ContO) this).t)
						    .radx[i_157_])))
				     * ((ContO) this).m.sin(((Trackers)
							     ((ContO) this).t)
							    .xy[i_157_])
				     / ((ContO) this).m.sin(90
							    - (((Trackers)
								(((ContO) this)
								 .t))
							       .xy[i_157_])))
				    - ((float) (((Trackers) ((ContO) this).t)
						.radx[i_157_])
				       * ((ContO) this).m.sin(((Trackers)
							       (((ContO) this)
								.t))
							      .xy[i_157_])
				       / (((ContO) this).m.sin
					  (90 - (((Trackers) ((ContO) this).t)
						 .xy[i_157_])))));
		    }
		    i_150_ = (int) ((double) (float) (((Trackers)
						       ((ContO) this).t)
						      .c[i_157_][0])
				    / 1.5);
		    i_151_ = (int) ((double) (float) (((Trackers)
						       ((ContO) this).t)
						      .c[i_157_][1])
				    / 1.5);
		    i_152_ = (int) ((double) (float) (((Trackers)
						       ((ContO) this).t)
						      .c[i_157_][2])
				    / 1.5);
		    break;
		}
	    }
	}
	rot(is, is_147_, ((Medium) ((ContO) this).m).cx,
	    ((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).xz, 4);
	rot(is_146_, is_147_, ((Medium) ((ContO) this).m).cy,
	    ((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).zy, 4);
	boolean bool = true;
	int i_161_ = 0;
	int i_162_ = 0;
	int i_163_ = 0;
	int i_164_ = 0;
	for (int i_165_ = 0; i_165_ < 4; i_165_++) {
	    is[i_165_] = xs(is[i_165_], is_147_[i_165_]);
	    is_146_[i_165_] = ys(is_146_[i_165_], is_147_[i_165_]);
	    if (is_146_[i_165_] < ((Medium) ((ContO) this).m).ih
		|| is_147_[i_165_] < 10)
		i_161_++;
	    if (is_146_[i_165_] > ((Medium) ((ContO) this).m).h
		|| is_147_[i_165_] < 10)
		i_162_++;
	    if (is[i_165_] < ((Medium) ((ContO) this).m).iw
		|| is_147_[i_165_] < 10)
		i_163_++;
	    if (is[i_165_] > ((Medium) ((ContO) this).m).w
		|| is_147_[i_165_] < 10)
		i_164_++;
	}
	if (i_163_ == 4 || i_161_ == 4 || i_162_ == 4 || i_164_ == 4)
	    bool = false;
	if (bool) {
	    for (int i_166_ = 0; i_166_ < 16; i_166_++) {
		if (i > ((Medium) ((ContO) this).m).fade[i_166_]) {
		    i_150_ = ((i_150_ * ((Medium) ((ContO) this).m).fogd
			       + ((Medium) ((ContO) this).m).cfade[0])
			      / (((Medium) ((ContO) this).m).fogd + 1));
		    i_151_ = ((i_151_ * ((Medium) ((ContO) this).m).fogd
			       + ((Medium) ((ContO) this).m).cfade[1])
			      / (((Medium) ((ContO) this).m).fogd + 1));
		    i_152_ = ((i_152_ * ((Medium) ((ContO) this).m).fogd
			       + ((Medium) ((ContO) this).m).cfade[2])
			      / (((Medium) ((ContO) this).m).fogd + 1));
		}
	    }
	    graphics2d.setColor(new Color(i_150_, i_151_, i_152_));
	    graphics2d.fillPolygon(is, is_146_, 4);
	}
    }
    
    public void fixit(Graphics2D graphics2d) {
	if (((ContO) this).fcnt == 1) {
	    for (int i = 0; i < ((ContO) this).npl; i++) {
		((Plane) ((ContO) this).p[i]).hsb[0] = 0.57F;
		((Plane) ((ContO) this).p[i]).hsb[2] = 0.8F;
		((Plane) ((ContO) this).p[i]).hsb[1] = 0.8F;
		Color color
		    = Color.getHSBColor(((Plane) ((ContO) this).p[i]).hsb[0],
					((Plane) ((ContO) this).p[i]).hsb[1],
					((Plane) ((ContO) this).p[i]).hsb[2]);
		int i_167_
		    = (int) ((float) color.getRed()
			     + ((float) color.getRed()
				* ((float) ((Medium) ((ContO) this).m).snap[0]
				   / 100.0F)));
		if (i_167_ > 255)
		    i_167_ = 255;
		if (i_167_ < 0)
		    i_167_ = 0;
		int i_168_
		    = (int) ((float) color.getGreen()
			     + ((float) color.getGreen()
				* ((float) ((Medium) ((ContO) this).m).snap[1]
				   / 100.0F)));
		if (i_168_ > 255)
		    i_168_ = 255;
		if (i_168_ < 0)
		    i_168_ = 0;
		int i_169_
		    = (int) ((float) color.getBlue()
			     + ((float) color.getBlue()
				* ((float) ((Medium) ((ContO) this).m).snap[2]
				   / 100.0F)));
		if (i_169_ > 255)
		    i_169_ = 255;
		if (i_169_ < 0)
		    i_169_ = 0;
		Color.RGBtoHSB(i_167_, i_168_, i_169_,
			       ((Plane) ((ContO) this).p[i]).hsb);
		((Plane) ((ContO) this).p[i]).flx = 1;
	    }
	}
	if (((ContO) this).fcnt == 2) {
	    for (int i = 0; i < ((ContO) this).npl; i++)
		((Plane) ((ContO) this).p[i]).flx = 1;
	}
	if (((ContO) this).fcnt == 4) {
	    for (int i = 0; i < ((ContO) this).npl; i++)
		((Plane) ((ContO) this).p[i]).flx = 3;
	}
	if ((((ContO) this).fcnt == 1 || ((ContO) this).fcnt > 2)
	    && ((ContO) this).fcnt != 9) {
	    int[] is = new int[8];
	    int[] is_170_ = new int[8];
	    int[] is_171_ = new int[4];
	    for (int i = 0; i < 4; i++) {
		is[i] = (((ContO) this).keyx[i] + ((ContO) this).x
			 - ((Medium) ((ContO) this).m).x);
		is_170_[i] = (((ContO) this).grat + ((ContO) this).y
			      - ((Medium) ((ContO) this).m).y);
		is_171_[i] = (((ContO) this).keyz[i] + ((ContO) this).z
			      - ((Medium) ((ContO) this).m).z);
	    }
	    rot(is, is_170_, ((ContO) this).x - ((Medium) ((ContO) this).m).x,
		((ContO) this).y - ((Medium) ((ContO) this).m).y,
		((ContO) this).xy, 4);
	    rot(is_170_, is_171_,
		((ContO) this).y - ((Medium) ((ContO) this).m).y,
		((ContO) this).z - ((Medium) ((ContO) this).m).y,
		((ContO) this).zy, 4);
	    rot(is, is_171_, ((ContO) this).x - ((Medium) ((ContO) this).m).x,
		((ContO) this).z - ((Medium) ((ContO) this).m).z,
		((ContO) this).xz, 4);
	    rot(is, is_171_, ((Medium) ((ContO) this).m).cx,
		((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).xz,
		4);
	    rot(is_170_, is_171_, ((Medium) ((ContO) this).m).cy,
		((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).zy,
		4);
	    int i = 0;
	    int i_172_ = 0;
	    int i_173_ = 0;
	    for (int i_174_ = 0; i_174_ < 4; i_174_++) {
		for (int i_175_ = 0; i_175_ < 4; i_175_++) {
		    if (Math.abs(is[i_174_] - is[i_175_]) > i)
			i = Math.abs(is[i_174_] - is[i_175_]);
		    if (Math.abs(is_170_[i_174_] - is_170_[i_175_]) > i_172_)
			i_172_ = Math.abs(is_170_[i_174_] - is_170_[i_175_]);
		    if (py(is[i_174_], is[i_175_], is_170_[i_174_],
			   is_170_[i_175_])
			> i_173_)
			i_173_ = py(is[i_174_], is[i_175_], is_170_[i_174_],
				    is_170_[i_175_]);
		}
	    }
	    i_173_ = (int) (Math.sqrt((double) i_173_) / 1.5);
	    if (i < i_173_)
		i = i_173_;
	    if (i_172_ < i_173_)
		i_172_ = i_173_;
	    int i_176_
		= (((Medium) ((ContO) this).m).cx
		   + (int) (((float) (((ContO) this).x
				      - ((Medium) ((ContO) this).m).x
				      - ((Medium) ((ContO) this).m).cx)
			     * ((ContO) this).m
				   .cos(((Medium) ((ContO) this).m).xz))
			    - ((float) (((ContO) this).z
					- ((Medium) ((ContO) this).m).z
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .sin(((Medium) ((ContO) this).m).xz))));
	    int i_177_
		= (((Medium) ((ContO) this).m).cz
		   + (int) (((float) (((ContO) this).x
				      - ((Medium) ((ContO) this).m).x
				      - ((Medium) ((ContO) this).m).cx)
			     * ((ContO) this).m
				   .sin(((Medium) ((ContO) this).m).xz))
			    + ((float) (((ContO) this).z
					- ((Medium) ((ContO) this).m).z
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .cos(((Medium) ((ContO) this).m).xz))));
	    int i_178_
		= (((Medium) ((ContO) this).m).cy
		   + (int) (((float) (((ContO) this).y
				      - ((Medium) ((ContO) this).m).y
				      - ((Medium) ((ContO) this).m).cy)
			     * ((ContO) this).m
				   .cos(((Medium) ((ContO) this).m).zy))
			    - ((float) (i_177_
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .sin(((Medium) ((ContO) this).m).zy))));
	    i_177_
		= (((Medium) ((ContO) this).m).cz
		   + (int) (((float) (((ContO) this).y
				      - ((Medium) ((ContO) this).m).y
				      - ((Medium) ((ContO) this).m).cy)
			     * ((ContO) this).m
				   .sin(((Medium) ((ContO) this).m).zy))
			    + ((float) (i_177_
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .cos(((Medium) ((ContO) this).m).zy))));
	    is[0]
		= xs((int) ((double) i_176_ - (double) i / 0.8
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 2.4)),
		     i_177_);
	    is_170_[0] = ys((int) ((double) i_178_ - (double) i_172_ / 1.92
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 5.67))),
			    i_177_);
	    is[1]
		= xs((int) ((double) i_176_ - (double) i / 0.8
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 2.4)),
		     i_177_);
	    is_170_[1] = ys((int) ((double) i_178_ + (double) i_172_ / 1.92
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 5.67))),
			    i_177_);
	    is[2]
		= xs((int) ((double) i_176_ - (double) i / 1.92
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 5.67)),
		     i_177_);
	    is_170_[2] = ys((int) ((double) i_178_ + (double) i_172_ / 0.8
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 2.4))),
			    i_177_);
	    is[3]
		= xs((int) ((double) i_176_ + (double) i / 1.92
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 5.67)),
		     i_177_);
	    is_170_[3] = ys((int) ((double) i_178_ + (double) i_172_ / 0.8
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 2.4))),
			    i_177_);
	    is[4]
		= xs((int) ((double) i_176_ + (double) i / 0.8
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 2.4)),
		     i_177_);
	    is_170_[4] = ys((int) ((double) i_178_ + (double) i_172_ / 1.92
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 5.67))),
			    i_177_);
	    is[5]
		= xs((int) ((double) i_176_ + (double) i / 0.8
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 2.4)),
		     i_177_);
	    is_170_[5] = ys((int) ((double) i_178_ - (double) i_172_ / 1.92
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 5.67))),
			    i_177_);
	    is[6]
		= xs((int) ((double) i_176_ + (double) i / 1.92
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 5.67)),
		     i_177_);
	    is_170_[6] = ys((int) ((double) i_178_ - (double) i_172_ / 0.8
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 2.4))),
			    i_177_);
	    is[7]
		= xs((int) ((double) i_176_ - (double) i / 1.92
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 5.67)),
		     i_177_);
	    is_170_[7] = ys((int) ((double) i_178_ - (double) i_172_ / 0.8
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 2.4))),
			    i_177_);
	    if (((ContO) this).fcnt == 3)
		rot(is, is_170_, xs(i_176_, i_177_), ys(i_178_, i_177_), 22,
		    8);
	    if (((ContO) this).fcnt == 4)
		rot(is, is_170_, xs(i_176_, i_177_), ys(i_178_, i_177_), 22,
		    8);
	    if (((ContO) this).fcnt == 5)
		rot(is, is_170_, xs(i_176_, i_177_), ys(i_178_, i_177_), 0, 8);
	    if (((ContO) this).fcnt == 6)
		rot(is, is_170_, xs(i_176_, i_177_), ys(i_178_, i_177_), -22,
		    8);
	    if (((ContO) this).fcnt == 7)
		rot(is, is_170_, xs(i_176_, i_177_), ys(i_178_, i_177_), -22,
		    8);
	    int i_179_
		= (int) (191.0F
			 + (191.0F
			    * ((float) ((Medium) ((ContO) this).m).snap[0]
			       / 350.0F)));
	    if (i_179_ > 255)
		i_179_ = 255;
	    if (i_179_ < 0)
		i_179_ = 0;
	    int i_180_
		= (int) (232.0F
			 + (232.0F
			    * ((float) ((Medium) ((ContO) this).m).snap[1]
			       / 350.0F)));
	    if (i_180_ > 255)
		i_180_ = 255;
	    if (i_180_ < 0)
		i_180_ = 0;
	    int i_181_
		= (int) (255.0F
			 + (255.0F
			    * ((float) ((Medium) ((ContO) this).m).snap[2]
			       / 350.0F)));
	    if (i_181_ > 255)
		i_181_ = 255;
	    if (i_181_ < 0)
		i_181_ = 0;
	    graphics2d.setColor(new Color(i_179_, i_180_, i_181_));
	    graphics2d.fillPolygon(is, is_170_, 8);
	    is[0] = xs((int) ((float) (i_176_ - i)
			      - ((ContO) this).m.random() * (float) (i / 4)),
		       i_177_);
	    is_170_[0] = ys((int) ((double) i_178_ - (double) i_172_ / 2.4
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 9.6))),
			    i_177_);
	    is[1] = xs((int) ((float) (i_176_ - i)
			      - ((ContO) this).m.random() * (float) (i / 4)),
		       i_177_);
	    is_170_[1] = ys((int) ((double) i_178_ + (double) i_172_ / 2.4
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 9.6))),
			    i_177_);
	    is[2]
		= xs((int) ((double) i_176_ - (double) i / 2.4
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 9.6)),
		     i_177_);
	    is_170_[2]
		= ys((int) ((float) (i_178_ + i_172_)
			    + ((ContO) this).m.random() * (float) (i_172_
								   / 4)),
		     i_177_);
	    is[3]
		= xs((int) ((double) i_176_ + (double) i / 2.4
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 9.6)),
		     i_177_);
	    is_170_[3]
		= ys((int) ((float) (i_178_ + i_172_)
			    + ((ContO) this).m.random() * (float) (i_172_
								   / 4)),
		     i_177_);
	    is[4] = xs((int) ((float) (i_176_ + i)
			      + ((ContO) this).m.random() * (float) (i / 4)),
		       i_177_);
	    is_170_[4] = ys((int) ((double) i_178_ + (double) i_172_ / 2.4
				   + ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 9.6))),
			    i_177_);
	    is[5] = xs((int) ((float) (i_176_ + i)
			      + ((ContO) this).m.random() * (float) (i / 4)),
		       i_177_);
	    is_170_[5] = ys((int) ((double) i_178_ - (double) i_172_ / 2.4
				   - ((double) ((ContO) this).m.random()
				      * ((double) i_172_ / 9.6))),
			    i_177_);
	    is[6]
		= xs((int) ((double) i_176_ + (double) i / 2.4
			    + (double) ((ContO) this).m.random() * ((double) i
								    / 9.6)),
		     i_177_);
	    is_170_[6]
		= ys((int) ((float) (i_178_ - i_172_)
			    - ((ContO) this).m.random() * (float) (i_172_
								   / 4)),
		     i_177_);
	    is[7]
		= xs((int) ((double) i_176_ - (double) i / 2.4
			    - (double) ((ContO) this).m.random() * ((double) i
								    / 9.6)),
		     i_177_);
	    is_170_[7]
		= ys((int) ((float) (i_178_ - i_172_)
			    - ((ContO) this).m.random() * (float) (i_172_
								   / 4)),
		     i_177_);
	    i_179_ = (int) (213.0F
			    + (213.0F
			       * ((float) ((Medium) ((ContO) this).m).snap[0]
				  / 350.0F)));
	    if (i_179_ > 255)
		i_179_ = 255;
	    if (i_179_ < 0)
		i_179_ = 0;
	    i_180_ = (int) (239.0F
			    + (239.0F
			       * ((float) ((Medium) ((ContO) this).m).snap[1]
				  / 350.0F)));
	    if (i_180_ > 255)
		i_180_ = 255;
	    if (i_180_ < 0)
		i_180_ = 0;
	    i_181_ = (int) (255.0F
			    + (255.0F
			       * ((float) ((Medium) ((ContO) this).m).snap[2]
				  / 350.0F)));
	    if (i_181_ > 255)
		i_181_ = 255;
	    if (i_181_ < 0)
		i_181_ = 0;
	    graphics2d.setColor(new Color(i_179_, i_180_, i_181_));
	    graphics2d.fillPolygon(is, is_170_, 8);
	}
	if (((ContO) this).fcnt > 7) {
	    ((ContO) this).fcnt = 0;
	    ((ContO) this).fix = false;
	} else
	    ((ContO) this).fcnt++;
    }
    
    public void electrify(Graphics2D graphics2d) {
	for (int i = 0; i < 4; i++) {
	    if (((ContO) this).elc[i] == 0) {
		((ContO) this).edl[i]
		    = (int) (380.0F - ((ContO) this).m.random() * 760.0F);
		((ContO) this).edr[i]
		    = (int) (380.0F - ((ContO) this).m.random() * 760.0F);
		((ContO) this).elc[i] = 1;
	    }
	    int i_182_
		= (int) ((float) ((ContO) this).edl[i]
			 + (190.0F - ((ContO) this).m.random() * 380.0F));
	    int i_183_
		= (int) ((float) ((ContO) this).edr[i]
			 + (190.0F - ((ContO) this).m.random() * 380.0F));
	    int i_184_ = (int) (((ContO) this).m.random() * 126.0F);
	    int i_185_ = (int) (((ContO) this).m.random() * 126.0F);
	    int[] is = new int[8];
	    int[] is_186_ = new int[8];
	    int[] is_187_ = new int[8];
	    for (int i_188_ = 0; i_188_ < 8; i_188_++)
		is_187_[i_188_]
		    = ((ContO) this).z - ((Medium) ((ContO) this).m).z;
	    is[0] = ((ContO) this).x - ((Medium) ((ContO) this).m).x - 504;
	    is_186_[0] = (((ContO) this).y - ((Medium) ((ContO) this).m).y
			  - ((ContO) this).edl[i] - 5
			  - (int) (((ContO) this).m.random() * 5.0F));
	    is[1] = (((ContO) this).x - ((Medium) ((ContO) this).m).x - 252
		     + i_185_);
	    is_186_[1]
		= (((ContO) this).y - ((Medium) ((ContO) this).m).y - i_182_
		   - 5 - (int) (((ContO) this).m.random() * 5.0F));
	    is[2] = (((ContO) this).x - ((Medium) ((ContO) this).m).x + 252
		     - i_184_);
	    is_186_[2]
		= (((ContO) this).y - ((Medium) ((ContO) this).m).y - i_183_
		   - 5 - (int) (((ContO) this).m.random() * 5.0F));
	    is[3] = ((ContO) this).x - ((Medium) ((ContO) this).m).x + 504;
	    is_186_[3] = (((ContO) this).y - ((Medium) ((ContO) this).m).y
			  - ((ContO) this).edr[i] - 5
			  - (int) (((ContO) this).m.random() * 5.0F));
	    is[4] = ((ContO) this).x - ((Medium) ((ContO) this).m).x + 504;
	    is_186_[4] = (((ContO) this).y - ((Medium) ((ContO) this).m).y
			  - ((ContO) this).edr[i] + 5
			  + (int) (((ContO) this).m.random() * 5.0F));
	    is[5] = (((ContO) this).x - ((Medium) ((ContO) this).m).x + 252
		     - i_184_);
	    is_186_[5]
		= (((ContO) this).y - ((Medium) ((ContO) this).m).y - i_183_
		   + 5 + (int) (((ContO) this).m.random() * 5.0F));
	    is[6] = (((ContO) this).x - ((Medium) ((ContO) this).m).x - 252
		     + i_185_);
	    is_186_[6]
		= (((ContO) this).y - ((Medium) ((ContO) this).m).y - i_182_
		   + 5 + (int) (((ContO) this).m.random() * 5.0F));
	    is[7] = ((ContO) this).x - ((Medium) ((ContO) this).m).x - 504;
	    is_186_[7] = (((ContO) this).y - ((Medium) ((ContO) this).m).y
			  - ((ContO) this).edl[i] + 5
			  + (int) (((ContO) this).m.random() * 5.0F));
	    if (((ContO) this).roted)
		rot(is, is_187_,
		    ((ContO) this).x - ((Medium) ((ContO) this).m).x,
		    ((ContO) this).z - ((Medium) ((ContO) this).m).z, 90, 8);
	    rot(is, is_187_, ((Medium) ((ContO) this).m).cx,
		((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).xz,
		8);
	    rot(is_186_, is_187_, ((Medium) ((ContO) this).m).cy,
		((Medium) ((ContO) this).m).cz, ((Medium) ((ContO) this).m).zy,
		8);
	    boolean bool = true;
	    int i_189_ = 0;
	    int i_190_ = 0;
	    int i_191_ = 0;
	    int i_192_ = 0;
	    int[] is_193_ = new int[8];
	    int[] is_194_ = new int[8];
	    for (int i_195_ = 0; i_195_ < 8; i_195_++) {
		is_193_[i_195_] = xs(is[i_195_], is_187_[i_195_]);
		is_194_[i_195_] = ys(is_186_[i_195_], is_187_[i_195_]);
		if (is_194_[i_195_] < ((Medium) ((ContO) this).m).ih
		    || is_187_[i_195_] < 10)
		    i_189_++;
		if (is_194_[i_195_] > ((Medium) ((ContO) this).m).h
		    || is_187_[i_195_] < 10)
		    i_190_++;
		if (is_193_[i_195_] < ((Medium) ((ContO) this).m).iw
		    || is_187_[i_195_] < 10)
		    i_191_++;
		if (is_193_[i_195_] > ((Medium) ((ContO) this).m).w
		    || is_187_[i_195_] < 10)
		    i_192_++;
	    }
	    if (i_191_ == 8 || i_189_ == 8 || i_190_ == 8 || i_192_ == 8)
		bool = false;
	    if (bool) {
		int i_196_
		    = (int) (160.0F
			     + (160.0F
				* ((float) ((Medium) ((ContO) this).m).snap[0]
				   / 500.0F)));
		if (i_196_ > 255)
		    i_196_ = 255;
		if (i_196_ < 0)
		    i_196_ = 0;
		int i_197_
		    = (int) (238.0F
			     + (238.0F
				* ((float) ((Medium) ((ContO) this).m).snap[1]
				   / 500.0F)));
		if (i_197_ > 255)
		    i_197_ = 255;
		if (i_197_ < 0)
		    i_197_ = 0;
		int i_198_
		    = (int) (255.0F
			     + (255.0F
				* ((float) ((Medium) ((ContO) this).m).snap[2]
				   / 500.0F)));
		if (i_198_ > 255)
		    i_198_ = 255;
		if (i_198_ < 0)
		    i_198_ = 0;
		i_196_ = ((i_196_ * 2 + 214 * (((ContO) this).elc[i] - 1))
			  / (((ContO) this).elc[i] + 1));
		i_197_ = ((i_197_ * 2 + 236 * (((ContO) this).elc[i] - 1))
			  / (((ContO) this).elc[i] + 1));
		if (((Medium) ((ContO) this).m).trk == 1) {
		    i_196_ = 255;
		    i_197_ = 128;
		    i_198_ = 0;
		}
		graphics2d.setColor(new Color(i_196_, i_197_, i_198_));
		graphics2d.fillPolygon(is_193_, is_194_, 8);
		if (is_187_[0] < 4000) {
		    i_196_
			= (int) (150.0F
				 + 150.0F * ((float) ((Medium)
						      ((ContO) this).m).snap[0]
					     / 500.0F));
		    if (i_196_ > 255)
			i_196_ = 255;
		    if (i_196_ < 0)
			i_196_ = 0;
		    i_197_
			= (int) (227.0F
				 + 227.0F * ((float) ((Medium)
						      ((ContO) this).m).snap[1]
					     / 500.0F));
		    if (i_197_ > 255)
			i_197_ = 255;
		    if (i_197_ < 0)
			i_197_ = 0;
		    i_198_
			= (int) (255.0F
				 + 255.0F * ((float) ((Medium)
						      ((ContO) this).m).snap[2]
					     / 500.0F));
		    if (i_198_ > 255)
			i_198_ = 255;
		    if (i_198_ < 0)
			i_198_ = 0;
		    graphics2d.setColor(new Color(i_196_, i_197_, i_198_));
		    graphics2d.drawPolygon(is_193_, is_194_, 8);
		}
	    }
	    if ((float) ((ContO) this).elc[i]
		> ((ContO) this).m.random() * 60.0F)
		((ContO) this).elc[i] = 0;
	    else
		((ContO) this).elc[i]++;
	}
	if (!((ContO) this).roted || ((ContO) this).xz != 0) {
	    ((ContO) this).xy += 11;
	    if (((ContO) this).xy > 360)
		((ContO) this).xy -= 360;
	} else {
	    ((ContO) this).zy += 11;
	    if (((ContO) this).zy > 360)
		((ContO) this).zy -= 360;
	}
    }
    
    public void dust(int i, float f, float f_199_, float f_200_, int i_201_,
		     int i_202_, float f_203_, int i_204_, boolean bool) {
	boolean bool_205_ = false;
	if (i_204_ > 5 && (i == 0 || i == 2))
	    bool_205_ = true;
	if (i_204_ < -5 && (i == 1 || i == 3))
	    bool_205_ = true;
	float f_206_
	    = (float) ((Math.sqrt((double) (i_201_ * i_201_ + i_202_ * i_202_))
			- 40.0)
		       / 160.0);
	if (f_206_ > 1.0F)
	    f_206_ = 1.0F;
	if ((double) f_206_ > 0.2 && !bool_205_) {
	    ((ContO) this).ust++;
	    if (((ContO) this).ust == 20)
		((ContO) this).ust = 0;
	    if (!bool) {
		float f_207_ = ((ContO) this).m.random();
		((ContO) this).sx[((ContO) this).ust]
		    = (int) ((f + (float) ((ContO) this).x * f_207_)
			     / (1.0F + f_207_));
		((ContO) this).sz[((ContO) this).ust]
		    = (int) ((f_200_ + (float) ((ContO) this).z * f_207_)
			     / (1.0F + f_207_));
		((ContO) this).sy[((ContO) this).ust]
		    = (int) ((f_199_ + (float) ((ContO) this).y * f_207_)
			     / (1.0F + f_207_));
	    } else {
		((ContO) this).sx[((ContO) this).ust]
		    = (int) ((f + (float) (((ContO) this).x + i_201_)) / 2.0F);
		((ContO) this).sz[((ContO) this).ust]
		    = (int) ((f_200_ + (float) (((ContO) this).z + i_202_))
			     / 2.0F);
		((ContO) this).sy[((ContO) this).ust] = (int) f_199_;
	    }
	    if (((ContO) this).sy[i] > 250)
		((ContO) this).sy[i] = 250;
	    ((ContO) this).osmag[((ContO) this).ust] = f_203_ * f_206_;
	    ((ContO) this).scx[((ContO) this).ust] = i_201_;
	    ((ContO) this).scz[((ContO) this).ust] = i_202_;
	    ((ContO) this).stg[((ContO) this).ust] = 1;
	}
    }
    
    public void pdust(int i, Graphics2D graphics2d, boolean bool) {
	if (bool)
	    ((ContO) this).sav[i]
		= (int) (Math.sqrt
			 ((double) (((((Medium) ((ContO) this).m).x
				      + ((Medium) ((ContO) this).m).cx
				      - ((ContO) this).sx[i])
				     * (((Medium) ((ContO) this).m).x
					+ ((Medium) ((ContO) this).m).cx
					- ((ContO) this).sx[i]))
				    + ((((Medium) ((ContO) this).m).y
					+ ((Medium) ((ContO) this).m).cy
					- ((ContO) this).sy[i])
				       * (((Medium) ((ContO) this).m).y
					  + ((Medium) ((ContO) this).m).cy
					  - ((ContO) this).sy[i]))
				    + ((((Medium) ((ContO) this).m).z
					- ((ContO) this).sz[i])
				       * (((Medium) ((ContO) this).m).z
					  - ((ContO) this).sz[i])))));
	if (bool && ((ContO) this).sav[i] > ((ContO) this).dist
	    || !bool && ((ContO) this).sav[i] <= ((ContO) this).dist) {
	    if (((ContO) this).stg[i] == 1) {
		((ContO) this).sbln[i] = 0.6F;
		boolean bool_208_ = false;
		int[] is = new int[3];
		for (int i_209_ = 0; i_209_ < 3; i_209_++) {
		    is[i_209_]
			= (int) (255.0F + 255.0F * ((float) (((Medium)
							      ((ContO) this).m)
							     .snap[i_209_])
						    / 100.0F));
		    if (is[i_209_] > 255)
			is[i_209_] = 255;
		    if (is[i_209_] < 0)
			is[i_209_] = 0;
		}
		int i_210_
		    = ((((ContO) this).x - ((Trackers) ((ContO) this).t).sx)
		       / 3000);
		if (i_210_ > ((Trackers) ((ContO) this).t).ncx)
		    i_210_ = ((Trackers) ((ContO) this).t).ncx;
		if (i_210_ < 0)
		    i_210_ = 0;
		int i_211_
		    = ((((ContO) this).z - ((Trackers) ((ContO) this).t).sz)
		       / 3000);
		if (i_211_ > ((Trackers) ((ContO) this).t).ncz)
		    i_211_ = ((Trackers) ((ContO) this).t).ncz;
		if (i_211_ < 0)
		    i_211_ = 0;
		for (int i_212_ = 0;
		     i_212_ < (((Trackers) ((ContO) this).t).sect[i_210_]
			       [i_211_]).length;
		     i_212_++) {
		    int i_213_ = (((Trackers) ((ContO) this).t).sect[i_210_]
				  [i_211_][i_212_]);
		    if ((Math.abs(((Trackers) ((ContO) this).t).zy[i_213_])
			 != 90)
			&& (Math.abs(((Trackers) ((ContO) this).t).xy[i_213_])
			    != 90)
			&& (Math.abs(((ContO) this).sx[i]
				     - ((Trackers) ((ContO) this).t).x[i_213_])
			    < ((Trackers) ((ContO) this).t).radx[i_213_])
			&& (Math.abs(((ContO) this).sz[i]
				     - ((Trackers) ((ContO) this).t).z[i_213_])
			    < ((Trackers) ((ContO) this).t).radz[i_213_])) {
			if (((Trackers) ((ContO) this).t).skd[i_213_] == 0)
			    ((ContO) this).sbln[i] = 0.2F;
			if (((Trackers) ((ContO) this).t).skd[i_213_] == 1)
			    ((ContO) this).sbln[i] = 0.4F;
			if (((Trackers) ((ContO) this).t).skd[i_213_] == 2)
			    ((ContO) this).sbln[i] = 0.45F;
			for (int i_214_ = 0; i_214_ < 3; i_214_++)
			    ((ContO) this).srgb[i][i_214_]
				= ((((Trackers) ((ContO) this).t).c[i_213_]
				    [i_214_])
				   + is[i_214_]) / 2;
			bool_208_ = true;
		    }
		}
		if (!bool_208_) {
		    for (int i_215_ = 0; i_215_ < 3; i_215_++)
			((ContO) this).srgb[i][i_215_]
			    = (((Medium) ((ContO) this).m).crgrnd[i_215_]
			       + is[i_215_]) / 2;
		}
		float f = (float) (0.1 + (double) ((ContO) this).m.random());
		if (f > 1.0F)
		    f = 1.0F;
		((ContO) this).scx[i]
		    = (int) ((float) ((ContO) this).scx[i] * f);
		((ContO) this).scz[i]
		    = (int) ((float) ((ContO) this).scx[i] * f);
		for (int i_216_ = 0; i_216_ < 8; i_216_++)
		    ((ContO) this).smag[i][i_216_]
			= (((ContO) this).osmag[i] * ((ContO) this).m.random()
			   * 50.0F);
		for (int i_217_ = 0; i_217_ < 8; i_217_++) {
		    int i_218_ = i_217_ - 1;
		    if (i_218_ == -1)
			i_218_ = 7;
		    int i_219_ = i_217_ + 1;
		    if (i_219_ == 8)
			i_219_ = 0;
		    ((ContO) this).smag[i][i_217_]
			= ((((ContO) this).smag[i][i_218_]
			    + ((ContO) this).smag[i][i_219_]) / 2.0F
			   + ((ContO) this).smag[i][i_217_]) / 2.0F;
		}
		((ContO) this).smag[i][6] = ((ContO) this).smag[i][7];
	    }
	    int i_220_
		= (((Medium) ((ContO) this).m).cx
		   + (int) (((float) (((ContO) this).sx[i]
				      - ((Medium) ((ContO) this).m).x
				      - ((Medium) ((ContO) this).m).cx)
			     * ((ContO) this).m
				   .cos(((Medium) ((ContO) this).m).xz))
			    - ((float) (((ContO) this).sz[i]
					- ((Medium) ((ContO) this).m).z
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .sin(((Medium) ((ContO) this).m).xz))));
	    int i_221_
		= (((Medium) ((ContO) this).m).cz
		   + (int) (((float) (((ContO) this).sx[i]
				      - ((Medium) ((ContO) this).m).x
				      - ((Medium) ((ContO) this).m).cx)
			     * ((ContO) this).m
				   .sin(((Medium) ((ContO) this).m).xz))
			    + ((float) (((ContO) this).sz[i]
					- ((Medium) ((ContO) this).m).z
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .cos(((Medium) ((ContO) this).m).xz))));
	    int i_222_
		= (((Medium) ((ContO) this).m).cy
		   + (int) ((((float) (((ContO) this).sy[i]
				       - ((Medium) ((ContO) this).m).y
				       - ((Medium) ((ContO) this).m).cy)
			      - ((ContO) this).smag[i][7])
			     * ((ContO) this).m
				   .cos(((Medium) ((ContO) this).m).zy))
			    - ((float) (i_221_
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .sin(((Medium) ((ContO) this).m).zy))));
	    i_221_
		= (((Medium) ((ContO) this).m).cz
		   + (int) ((((float) (((ContO) this).sy[i]
				       - ((Medium) ((ContO) this).m).y
				       - ((Medium) ((ContO) this).m).cy)
			      - ((ContO) this).smag[i][7])
			     * ((ContO) this).m
				   .sin(((Medium) ((ContO) this).m).zy))
			    + ((float) (i_221_
					- ((Medium) ((ContO) this).m).cz)
			       * ((ContO) this).m
				     .cos(((Medium) ((ContO) this).m).zy))));
	    ((ContO) this).sx[i]
		+= ((ContO) this).scx[i] / (((ContO) this).stg[i] + 1);
	    ((ContO) this).sz[i]
		+= ((ContO) this).scz[i] / (((ContO) this).stg[i] + 1);
	    int[] is = new int[8];
	    int[] is_223_ = new int[8];
	    is[0] = xs((int) ((float) i_220_
			      + ((ContO) this).smag[i][0] * 0.9238F * 1.5F),
		       i_221_);
	    is_223_[0]
		= ys((int) ((float) i_222_
			    + ((ContO) this).smag[i][0] * 0.3826F * 1.5F),
		     i_221_);
	    is[1] = xs((int) ((float) i_220_
			      + ((ContO) this).smag[i][1] * 0.9238F * 1.5F),
		       i_221_);
	    is_223_[1]
		= ys((int) ((float) i_222_
			    - ((ContO) this).smag[i][1] * 0.3826F * 1.5F),
		     i_221_);
	    is[2] = xs((int) ((float) i_220_
			      + ((ContO) this).smag[i][2] * 0.3826F),
		       i_221_);
	    is_223_[2] = ys((int) ((float) i_222_
				   - ((ContO) this).smag[i][2] * 0.9238F),
			    i_221_);
	    is[3] = xs((int) ((float) i_220_
			      - ((ContO) this).smag[i][3] * 0.3826F),
		       i_221_);
	    is_223_[3] = ys((int) ((float) i_222_
				   - ((ContO) this).smag[i][3] * 0.9238F),
			    i_221_);
	    is[4] = xs((int) ((float) i_220_
			      - ((ContO) this).smag[i][4] * 0.9238F * 1.5F),
		       i_221_);
	    is_223_[4]
		= ys((int) ((float) i_222_
			    - ((ContO) this).smag[i][4] * 0.3826F * 1.5F),
		     i_221_);
	    is[5] = xs((int) ((float) i_220_
			      - ((ContO) this).smag[i][5] * 0.9238F * 1.5F),
		       i_221_);
	    is_223_[5]
		= ys((int) ((float) i_222_
			    + ((ContO) this).smag[i][5] * 0.3826F * 1.5F),
		     i_221_);
	    is[6] = xs((int) ((float) i_220_
			      - ((ContO) this).smag[i][6] * 0.3826F * 1.7F),
		       i_221_);
	    is_223_[6] = ys((int) ((float) i_222_
				   + ((ContO) this).smag[i][6] * 0.9238F),
			    i_221_);
	    is[7] = xs((int) ((float) i_220_
			      + ((ContO) this).smag[i][7] * 0.3826F * 1.7F),
		       i_221_);
	    is_223_[7] = ys((int) ((float) i_222_
				   + ((ContO) this).smag[i][7] * 0.9238F),
			    i_221_);
	    for (int i_224_ = 0; i_224_ < 7; i_224_++)
		((ContO) this).smag[i][i_224_]
		    += 5.0F + ((ContO) this).m.random() * 15.0F;
	    ((ContO) this).smag[i][7] = ((ContO) this).smag[i][6];
	    boolean bool_225_ = true;
	    int i_226_ = 0;
	    int i_227_ = 0;
	    int i_228_ = 0;
	    int i_229_ = 0;
	    for (int i_230_ = 0; i_230_ < 8; i_230_++) {
		if (is_223_[i_230_] < ((Medium) ((ContO) this).m).ih
		    || i_221_ < 10)
		    i_226_++;
		if (is_223_[i_230_] > ((Medium) ((ContO) this).m).h
		    || i_221_ < 10)
		    i_227_++;
		if (is[i_230_] < ((Medium) ((ContO) this).m).iw || i_221_ < 10)
		    i_228_++;
		if (is[i_230_] > ((Medium) ((ContO) this).m).w || i_221_ < 10)
		    i_229_++;
	    }
	    if (i_228_ == 4 || i_226_ == 4 || i_227_ == 4 || i_229_ == 4)
		bool_225_ = false;
	    if (bool_225_) {
		int i_231_ = ((ContO) this).srgb[i][0];
		int i_232_ = ((ContO) this).srgb[i][1];
		int i_233_ = ((ContO) this).srgb[i][2];
		for (int i_234_ = 0; i_234_ < 16; i_234_++) {
		    if (((ContO) this).sav[i]
			> ((Medium) ((ContO) this).m).fade[i_234_]) {
			i_231_ = ((i_231_ * ((Medium) ((ContO) this).m).fogd
				   + ((Medium) ((ContO) this).m).cfade[0])
				  / (((Medium) ((ContO) this).m).fogd + 1));
			i_232_ = ((i_232_ * ((Medium) ((ContO) this).m).fogd
				   + ((Medium) ((ContO) this).m).cfade[1])
				  / (((Medium) ((ContO) this).m).fogd + 1));
			i_233_ = ((i_233_ * ((Medium) ((ContO) this).m).fogd
				   + ((Medium) ((ContO) this).m).cfade[2])
				  / (((Medium) ((ContO) this).m).fogd + 1));
		    }
		}
		graphics2d.setColor(new Color(i_231_, i_232_, i_233_));
		float f = (((ContO) this).sbln[i]
			   - ((float) ((ContO) this).stg[i]
			      * (((ContO) this).sbln[i] / 8.0F)));
		graphics2d.setComposite(AlphaComposite.getInstance(3, f));
		graphics2d.fillPolygon(is, is_223_, 8);
		graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
	    }
	    if (((ContO) this).stg[i] == 7)
		((ContO) this).stg[i] = 0;
	    else
		((ContO) this).stg[i]++;
	}
    }
    
    public void sprk(float f, float f_235_, float f_236_, float f_237_,
		     float f_238_, float f_239_, int i) {
	if (i != 1) {
	    ((ContO) this).srx
		= (int) (f - ((float) ((ContO) this).sprkat
			      * ((ContO) this).m.sin(((ContO) this).xz)));
	    ((ContO) this).sry
		= (int) (f_235_ - ((float) ((ContO) this).sprkat
				   * ((ContO) this).m.cos(((ContO) this).zy)
				   * ((ContO) this).m.cos(((ContO) this).xy)));
	    ((ContO) this).srz
		= (int) (f_236_ + ((float) ((ContO) this).sprkat
				   * ((ContO) this).m.cos(((ContO) this).xz)));
	    ((ContO) this).sprk = 1;
	} else {
	    ((ContO) this).sprk++;
	    if (((ContO) this).sprk == 4) {
		((ContO) this).srx = (int) ((float) ((ContO) this).x + f_237_);
		((ContO) this).sry = (int) f_235_;
		((ContO) this).srz = (int) ((float) ((ContO) this).z + f_239_);
		((ContO) this).sprk = 5;
	    } else {
		((ContO) this).srx = (int) f;
		((ContO) this).sry = (int) f_235_;
		((ContO) this).srz = (int) f_236_;
	    }
	}
	if (i == 2)
	    ((ContO) this).sprk = 6;
	((ContO) this).rcx = f_237_;
	((ContO) this).rcy = f_238_;
	((ContO) this).rcz = f_239_;
    }
    
    public void dsprk(Graphics2D graphics2d, boolean bool) {
	if (bool && ((ContO) this).sprk != 0) {
	    int i = (int) (Math.sqrt((double) ((((ContO) this).rcx
						* ((ContO) this).rcx)
					       + (((ContO) this).rcy
						  * ((ContO) this).rcy)
					       + (((ContO) this).rcz
						  * ((ContO) this).rcz)))
			   / 10.0);
	    if (i > 5) {
		boolean bool_240_ = false;
		if ((double) ((ContO) this).dist
		    < Math.sqrt((double) (((((Medium) ((ContO) this).m).x
					    + ((Medium) ((ContO) this).m).cx
					    - ((ContO) this).srx)
					   * (((Medium) ((ContO) this).m).x
					      + ((Medium) ((ContO) this).m).cx
					      - ((ContO) this).srx))
					  + ((((Medium) ((ContO) this).m).y
					      + ((Medium) ((ContO) this).m).cy
					      - ((ContO) this).sry)
					     * (((Medium) ((ContO) this).m).y
						+ (((Medium) ((ContO) this).m)
						   .cy)
						- ((ContO) this).sry))
					  + ((((Medium) ((ContO) this).m).z
					      - ((ContO) this).srz)
					     * (((Medium) ((ContO) this).m).z
						- ((ContO) this).srz)))))
		    bool_240_ = true;
		if (i > 33)
		    i = 33;
		int i_241_ = 0;
		for (int i_242_ = 0; i_242_ < 100; i_242_++) {
		    if (((ContO) this).rtg[i_242_] == 0) {
			((ContO) this).rtg[i_242_] = 1;
			((ContO) this).rbef[i_242_] = bool_240_;
			i_241_++;
		    }
		    if (i_241_ == i)
			break;
		}
	    }
	}
	for (int i = 0; i < 100; i++) {
	    if (((ContO) this).rtg[i] != 0
		&& (((ContO) this).rbef[i] && bool
		    || !((ContO) this).rbef[i] && !bool)) {
		if (((ContO) this).rtg[i] == 1) {
		    if (((ContO) this).sprk < 5) {
			((ContO) this).rx[i]
			    = (((ContO) this).srx + 3
			       - (int) ((double) ((ContO) this).m.random()
					* 6.7));
			((ContO) this).ry[i]
			    = (((ContO) this).sry + 3
			       - (int) ((double) ((ContO) this).m.random()
					* 6.7));
			((ContO) this).rz[i]
			    = (((ContO) this).srz + 3
			       - (int) ((double) ((ContO) this).m.random()
					* 6.7));
		    } else {
			((ContO) this).rx[i]
			    = (((ContO) this).srx + 10
			       - (int) (((ContO) this).m.random() * 20.0F));
			((ContO) this).ry[i]
			    = (((ContO) this).sry
			       - (int) (((ContO) this).m.random() * 4.0F));
			((ContO) this).rz[i]
			    = (((ContO) this).srz + 10
			       - (int) (((ContO) this).m.random() * 20.0F));
		    }
		    int i_243_
			= (int) Math.sqrt((double) ((((ContO) this).rcx
						     * ((ContO) this).rcx)
						    + (((ContO) this).rcy
						       * ((ContO) this).rcy)
						    + (((ContO) this).rcz
						       * ((ContO) this).rcz)));
		    float f = 0.2F + 0.4F * ((ContO) this).m.random();
		    float f_244_ = (((ContO) this).m.random()
				    * ((ContO) this).m.random()
				    * ((ContO) this).m.random());
		    float f_245_ = 1.0F;
		    if (((ContO) this).m.random()
			> ((ContO) this).m.random()) {
			if (((ContO) this).m.random()
			    > ((ContO) this).m.random())
			    f_245_ *= -1.0F;
			((ContO) this).vrx[i]
			    = -((((ContO) this).rcx
				 + ((float) i_243_
				    * (1.0F
				       - ((ContO) this).rcx / (float) i_243_)
				    * f_244_ * f_245_))
				* f);
		    }
		    if (((ContO) this).m.random()
			> ((ContO) this).m.random()) {
			if (((ContO) this).m.random()
			    > ((ContO) this).m.random())
			    f_245_ *= -1.0F;
			if (((ContO) this).sprk == 5)
			    f_245_ = 1.0F;
			((ContO) this).vry[i]
			    = -((((ContO) this).rcy
				 + ((float) i_243_
				    * (1.0F
				       - ((ContO) this).rcy / (float) i_243_)
				    * f_244_ * f_245_))
				* f);
		    }
		    if (((ContO) this).m.random()
			> ((ContO) this).m.random()) {
			if (((ContO) this).m.random()
			    > ((ContO) this).m.random())
			    f_245_ *= -1.0F;
			((ContO) this).vrz[i]
			    = -((((ContO) this).rcz
				 + ((float) i_243_
				    * (1.0F
				       - ((ContO) this).rcz / (float) i_243_)
				    * f_244_ * f_245_))
				* f);
		    }
		}
		((ContO) this).rx[i] += ((ContO) this).vrx[i];
		((ContO) this).ry[i] += ((ContO) this).vry[i];
		((ContO) this).rz[i] += ((ContO) this).vrz[i];
		int i_246_
		    = (((Medium) ((ContO) this).m).cx
		       + (int) (((float) (((ContO) this).rx[i]
					  - ((Medium) ((ContO) this).m).x
					  - ((Medium) ((ContO) this).m).cx)
				 * ((ContO) this).m
				       .cos(((Medium) ((ContO) this).m).xz))
				- ((float) (((ContO) this).rz[i]
					    - ((Medium) ((ContO) this).m).z
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.sin(((Medium)
							   ((ContO) this).m)
							  .xz))));
		int i_247_
		    = (((Medium) ((ContO) this).m).cz
		       + (int) (((float) (((ContO) this).rx[i]
					  - ((Medium) ((ContO) this).m).x
					  - ((Medium) ((ContO) this).m).cx)
				 * ((ContO) this).m
				       .sin(((Medium) ((ContO) this).m).xz))
				+ ((float) (((ContO) this).rz[i]
					    - ((Medium) ((ContO) this).m).z
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.cos(((Medium)
							   ((ContO) this).m)
							  .xz))));
		int i_248_
		    = (((Medium) ((ContO) this).m).cy
		       + (int) (((float) (((ContO) this).ry[i]
					  - ((Medium) ((ContO) this).m).y
					  - ((Medium) ((ContO) this).m).cy)
				 * ((ContO) this).m
				       .cos(((Medium) ((ContO) this).m).zy))
				- ((float) (i_247_
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.sin(((Medium)
							   ((ContO) this).m)
							  .zy))));
		i_247_
		    = (((Medium) ((ContO) this).m).cz
		       + (int) (((float) (((ContO) this).ry[i]
					  - ((Medium) ((ContO) this).m).y
					  - ((Medium) ((ContO) this).m).cy)
				 * ((ContO) this).m
				       .sin(((Medium) ((ContO) this).m).zy))
				+ ((float) (i_247_
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.cos(((Medium)
							   ((ContO) this).m)
							  .zy))));
		int i_249_
		    = (((Medium) ((ContO) this).m).cx
		       + (int) ((((float) (((ContO) this).rx[i]
					   - ((Medium) ((ContO) this).m).x
					   - ((Medium) ((ContO) this).m).cx)
				  + ((ContO) this).vrx[i])
				 * ((ContO) this).m
				       .cos(((Medium) ((ContO) this).m).xz))
				- (((float) (((ContO) this).rz[i]
					     - ((Medium) ((ContO) this).m).z
					     - ((Medium) ((ContO) this).m).cz)
				    + ((ContO) this).vrz[i])
				   * ((ContO) this).m.sin(((Medium)
							   ((ContO) this).m)
							  .xz))));
		int i_250_
		    = (((Medium) ((ContO) this).m).cz
		       + (int) ((((float) (((ContO) this).rx[i]
					   - ((Medium) ((ContO) this).m).x
					   - ((Medium) ((ContO) this).m).cx)
				  + ((ContO) this).vrx[i])
				 * ((ContO) this).m
				       .sin(((Medium) ((ContO) this).m).xz))
				+ (((float) (((ContO) this).rz[i]
					     - ((Medium) ((ContO) this).m).z
					     - ((Medium) ((ContO) this).m).cz)
				    + ((ContO) this).vrz[i])
				   * ((ContO) this).m.cos(((Medium)
							   ((ContO) this).m)
							  .xz))));
		int i_251_
		    = (((Medium) ((ContO) this).m).cy
		       + (int) ((((float) (((ContO) this).ry[i]
					   - ((Medium) ((ContO) this).m).y
					   - ((Medium) ((ContO) this).m).cy)
				  + ((ContO) this).vry[i])
				 * ((ContO) this).m
				       .cos(((Medium) ((ContO) this).m).zy))
				- ((float) (i_250_
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.sin(((Medium)
							   ((ContO) this).m)
							  .zy))));
		i_250_
		    = (((Medium) ((ContO) this).m).cz
		       + (int) ((((float) (((ContO) this).ry[i]
					   - ((Medium) ((ContO) this).m).y
					   - ((Medium) ((ContO) this).m).cy)
				  + ((ContO) this).vry[i])
				 * ((ContO) this).m
				       .sin(((Medium) ((ContO) this).m).zy))
				+ ((float) (i_250_
					    - ((Medium) ((ContO) this).m).cz)
				   * ((ContO) this).m.cos(((Medium)
							   ((ContO) this).m)
							  .zy))));
		int i_252_ = xs(i_246_, i_247_);
		int i_253_ = ys(i_248_, i_247_);
		int i_254_ = xs(i_249_, i_250_);
		int i_255_ = ys(i_251_, i_250_);
		if (i_252_ < ((Medium) ((ContO) this).m).iw
		    && i_254_ < ((Medium) ((ContO) this).m).iw)
		    ((ContO) this).rtg[i] = 0;
		if (i_252_ > ((Medium) ((ContO) this).m).w
		    && i_254_ > ((Medium) ((ContO) this).m).w)
		    ((ContO) this).rtg[i] = 0;
		if (i_253_ < ((Medium) ((ContO) this).m).ih
		    && i_255_ < ((Medium) ((ContO) this).m).ih)
		    ((ContO) this).rtg[i] = 0;
		if (i_253_ > ((Medium) ((ContO) this).m).h
		    && i_255_ > ((Medium) ((ContO) this).m).h)
		    ((ContO) this).rtg[i] = 0;
		if (((ContO) this).ry[i] > 250)
		    ((ContO) this).rtg[i] = 0;
		if (((ContO) this).rtg[i] != 0) {
		    int i_256_ = 255;
		    int i_257_ = 197 - 30 * ((ContO) this).rtg[i];
		    int i_258_ = 0;
		    for (int i_259_ = 0; i_259_ < 16; i_259_++) {
			if (i_247_
			    > ((Medium) ((ContO) this).m).fade[i_259_]) {
			    i_256_
				= ((i_256_ * ((Medium) ((ContO) this).m).fogd
				    + ((Medium) ((ContO) this).m).cfade[0])
				   / (((Medium) ((ContO) this).m).fogd + 1));
			    i_257_
				= ((i_257_ * ((Medium) ((ContO) this).m).fogd
				    + ((Medium) ((ContO) this).m).cfade[1])
				   / (((Medium) ((ContO) this).m).fogd + 1));
			    i_258_
				= ((i_258_ * ((Medium) ((ContO) this).m).fogd
				    + ((Medium) ((ContO) this).m).cfade[2])
				   / (((Medium) ((ContO) this).m).fogd + 1));
			}
		    }
		    graphics2d.setColor(new Color(i_256_, i_257_, i_258_));
		    graphics2d.drawLine(i_252_, i_253_, i_254_, i_255_);
		    ((ContO) this).vrx[i] = ((ContO) this).vrx[i] * 0.8F;
		    ((ContO) this).vry[i] = ((ContO) this).vry[i] * 0.8F;
		    ((ContO) this).vrz[i] = ((ContO) this).vrz[i] * 0.8F;
		    if (((ContO) this).rtg[i] == 3)
			((ContO) this).rtg[i] = 0;
		    else
			((ContO) this).rtg[i]++;
		}
	    }
	}
	if (((ContO) this).sprk != 0)
	    ((ContO) this).sprk = 0;
    }
    
    public int xs(int i, int i_260_) {
	if (i_260_ < 50)
	    i_260_ = 50;
	return (((i_260_ - ((Medium) ((ContO) this).m).focus_point)
		 * (((Medium) ((ContO) this).m).cx - i) / i_260_)
		+ i);
    }
    
    public int ys(int i, int i_261_) {
	if (i_261_ < 50)
	    i_261_ = 50;
	return (((i_261_ - ((Medium) ((ContO) this).m).focus_point)
		 * (((Medium) ((ContO) this).m).cy - i) / i_261_)
		+ i);
    }
    
    public int getvalue(String string, String string_262_, int i) {
	int i_263_ = 0;
	String string_264_ = "";
	for (int i_265_ = string.length() + 1; i_265_ < string_262_.length();
	     i_265_++) {
	    String string_266_ = new StringBuilder().append("").append
				     (string_262_.charAt(i_265_)).toString();
	    if (string_266_.equals(",") || string_266_.equals(")")) {
		i_263_++;
		i_265_++;
	    }
	    if (i_263_ == i)
		string_264_ = new StringBuilder().append(string_264_).append
				  (string_262_.charAt(i_265_)).toString();
	}
	return Float.valueOf(string_264_).intValue();
    }
    
    public int getpy(int i, int i_267_, int i_268_) {
	return ((i - ((ContO) this).x) / 10 * ((i - ((ContO) this).x) / 10)
		+ ((i_267_ - ((ContO) this).y) / 10
		   * ((i_267_ - ((ContO) this).y) / 10))
		+ ((i_268_ - ((ContO) this).z) / 10
		   * ((i_268_ - ((ContO) this).z) / 10)));
    }
    
    public int py(int i, int i_269_, int i_270_, int i_271_) {
	return ((i - i_269_) * (i - i_269_)
		+ (i_270_ - i_271_) * (i_270_ - i_271_));
    }
    
    public void rot(int[] is, int[] is_272_, int i, int i_273_, int i_274_,
		    int i_275_) {
	if (i_274_ != 0) {
	    for (int i_276_ = 0; i_276_ < i_275_; i_276_++) {
		int i_277_ = is[i_276_];
		int i_278_ = is_272_[i_276_];
		is[i_276_] = i + (int) (((float) (i_277_ - i)
					 * ((ContO) this).m.cos(i_274_))
					- ((float) (i_278_ - i_273_)
					   * ((ContO) this).m.sin(i_274_)));
		is_272_[i_276_]
		    = i_273_ + (int) (((float) (i_277_ - i)
				       * ((ContO) this).m.sin(i_274_))
				      + ((float) (i_278_ - i_273_)
					 * ((ContO) this).m.cos(i_274_)));
	    }
	}
    }
}
