package ds.nfm.mod;

class ModInstrument
{
  String name;
  byte[] samples;
  int sample_length;
  int finetune_rate;
  int period_low_limit;
  int period_high_limit;
  int finetune_value;
  int volume;
  int repeat_point;
  int repeat_length;
}


/* Location:              E:\Games\Need For Madness\data\madapp.jar!\ds\nfm\mod\ModInstrument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */