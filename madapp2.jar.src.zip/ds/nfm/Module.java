/*    */ package ds.nfm;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Module
/*    */ {
/*    */   protected String name;
/* 13 */   protected boolean loaded = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 20 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isLoaded()
/*    */   {
/* 28 */     return this.loaded;
/*    */   }
/*    */   
/*    */   public abstract void loadMod(InputStream paramInputStream)
/*    */     throws IOException;
/*    */ }


/* Location:              E:\Games\Need For Madness\data\madapp.jar!\ds\nfm\Module.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */