/* StageMaker - Decompiled by JODE extended
 * DragShot Software
 * JODE (c) 1998-2001 Jochen Hoenicke
 */
import java.applet.Applet;
import java.awt.AlphaComposite;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Event;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.TextField;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.swing.JOptionPane;
public class StageMaker extends Applet implements Runnable
{
    Graphics2D rd;
    Image offImage;
    Thread thredo;
    boolean exwist = false;
    FontMetrics ftm;
    int apx = 0;
    int apy = 0;
    String sstage = "";
    String suser = "Horaks";
    int tab = 0;
    int tabed = -1;
    Image[] btgame = new Image[2];
    Image logo;
    boolean onbtgame = false;
    boolean focuson = true;
    boolean overcan = false;
    boolean left = false;
    boolean right = false;
    boolean up = false;
    boolean down = false;
    boolean zoomi = false;
    boolean zoomo = false;
    String stagename = "";
    String tstage = new StringBuilder().append("snap(0,0,0)\r\nsky(191,215,255)\r\nclouds(255,255,255,5,-1000)\r\nfog(195,207,230)\r\nground(192,194,202)\r\ntexture(0,0,0,50)\r\nfadefrom(5000)\r\ndensity(5)\n\rmountains(").append((int) (Math.random() * 100000.0)).append(")\r\nnlaps(5)\r\n\r\n").toString();
    String bstage = "set(47,0,0,0)\r\nmaxr(11,28500,-5600)\r\nmaxb(9,-8000,-12300)\r\nmaxl(11,-14700,-5600)\r\nmaxt(9,44800,-12300)\r\n";
    String[] undos = new String[5000];
    int nundo = 0;
    Medium m = new Medium();
    CheckPoints cp = new CheckPoints();
    Trackers t = new Trackers();
    ContO[] bco = new ContO[67];
    ContO[] co = new ContO[10000];
    int nob = 0;
    int xnob = 0;
    int errd = 0;
    int origfade = 5000;
    int sfase = 0;
    Smenu slstage = new Smenu(2000);
    TextField srch = new TextField("", 38);
    Smenu strtyp = new Smenu(40);
    Smenu ptyp = new Smenu(40);
    Smenu part = new Smenu(40);
    int sptyp = 0;
    int spart = 0;
    int sp = 0;
    int lsp = -1;
    int seq = 0;
    boolean setcur = false;
    boolean epart = false;
    boolean arrng = false;
    int esp = -1;
    int hi = -1;
    int arrcnt = 0;
    int chi = -1;
    boolean seqn = false;
    int rot = 0;
    int adrot = 0;
    Image[] su = new Image[2];
    Image[] sl = new Image[2];
    Image[] sd = new Image[2];
    Image[] sr = new Image[2];
    Image[] zi = new Image[2];
    Image[] zo = new Image[2];
    boolean pgen = false;
    float pwd = (float) (2L + Math.round(Math.random() * 4.0));
    float phd = (float) (2L + Math.round(Math.random() * 4.0));
    int fgen = 0;
    int sx = 0;
    int sz = 1500;
    int sy = -10000;
    TextField fixh = new TextField("2000", 5);
    int hf = 2000;
    int[][] atp = { { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 1520, 2830, -1520, -2830 }, { -1520, 2830, 1520, -2830 }, { 0, -1750, 1750, 0 }, { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 0, -1750, 1750, 0 }, { 0, 2800, 0, -2800 }, { 0, -1750, 1750, 0 }, { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 0, 560, 0, -560 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 385, 980, 385, -980 }, { 0, 0, 0, -600 }, { 0, 0, 0, 0 }, { 0, 2164, 0, -2164 }, { 0, 2164, 0, -2164 }, { 0, 3309, 0, -1680 }, { 0, 1680, 0, -3309 }, { 350, 0, -350, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 1810, 980, 1810, -980 }, { 0, 0, 0, 0 }, { 0, 500, 0, -500 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 0, 1680, 0, -3309 }, { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 0, 2800, 0, -2800 }, { 700, 1400, 700, -1400 }, { 0, -1480, 0, -1480 }, { 0, 0, 0, 0 }, { 350, 0, -350, 0 }, { 0, 0, 0, 0 }, { 700, 0, -700, 0 }, { 0, 0, 0, 0 }, { 0, -2198, 0, 1482 }, { 0, -1319, 0, 1391 }, { 0, -1894, 0, 2271 }, { 0, -826, 0, 839 }, { 0, -1400, 0, 1400 }, { 0, -1400, 0, 1400 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
    String[] discp = { "NormalRoad :  Basic asphalt road.\nAttaches correctly to the following other parts :\n\n'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',  'NormalRoad Edged',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad Edged :  Asphalt road with edged side blocks (a destructive road).\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad TwistedRight :  Asphalt road twisted towards the right.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad Twistedleft',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad TwistedLeft :  Asphalt road twisted towards the left.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad Turn :  Asphalt corner road turn.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp', 'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "OffRoad :  Basic sandy dirt-road.\nAttaches correctly to the following other parts :\n\n'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "OffRoad BumpyGreen :  Dirt-road with bumpy greenery in the middle.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "OffRoad Turn :  Dirt-road corner turn.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad End',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand 'Normal-Off-Road Blend'\n\n", "HalfpipeRoad :  Basic road for the half-pipe ramp.\nAttaches correctly to the following other parts :\n\n'Off-Halfpipe-Road Blend',  'HalfpipeRoad',  'HalfpipeRoad Turn',  'HalfpipeRoad-Ramp Filler'\nand  'Halfpipe-Normal-Road Blend'\n\n", "HalfpipeRoad Turn :  Half-pipe corner road turn.\nAttaches correctly to the following other parts :\n\n'HalfpipeRoad',  'Off-Halfpipe-Road Blend',  'HalfpipeRoad'  and  'Halfpipe-Normal-Road Blend'\n\n", "Normal-Off-Road Blend :  Road blend between the normal asphalt road and the dirt-road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'NormalRoad-Raised Ramp', 'Halfpipe-Normal-Road Blend' 'OffRoad',  'OffRoad Turn',\n'OffRoad End',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start'  and  'Off-Halfpipe-Road Blend'\n\n", "Off-Halfpipe-Road Blend :  Road blend between the dirt-road and the half-pipe road.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start',\n'HalfpipeRoad',  'HalfpipeRoad Turn',  'Halfpipe-Normal-Road Blend'  and  'Normal-Off-Road Blend'\n\n", "Halfpipe-Normal-Road Blend :  Road blend between the normal asphalt road and the half-pipe road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'NormalRoad-Raised Ramp',  'HalfpipeRoad',  'Off-Halfpipe-Road Blend',  'HalfpipeRoad'\nand  'Off-Halfpipe-Road Blend'\n\n", "NormalRoad End :  The end part of the normal asphalt road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad Edged',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "OffRoad End :  The end part of the dirt-road.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "HalfpipeRoad-Ramp Filler :  A part that gets placed between the half-pipe road and the half-pipe ramp to extend the distance in between.\nAttaches correctly to the following other parts :\n\n'HalfpipeRoad'  and  'Halfpipe'\n\n", "Basic Ramp :  Basic 30 degree asphalt ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Crash Ramp :  A 35 degree ramp with big side blocks for crashing into.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Two-Way Ramp :  Two way 15 degree inclined ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Two-Way High-Low Ramp :  Two way 15 degree inclined ramp, with peeked side for an optional higher car jump.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Landing Ramp :  A ramp that is both a landing inclination and an obstacle as well, it is usually placed just after another normal ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Big-Takeoff Ramp:  A big takeoff ramp for getting huge heights with the cars.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Small Ramp :  A small ramp that can be placed on either side of the road.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Offroad Bump Ramp :  A small bump ramp that is to be placed over the off-road dirt tracks.\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Offroad Big Ramp :  The big off-road dirt mountain like ramp!\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Offroad Ramp :  Normal sized off-road dirt track ramp!\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Halfpipe :  The Half-pipe ramp, two of these ramps opposite each other create a half-pipe for the cars!\nAttaches correctly over and to the following other parts :\n\n'HalfpipeRoad',  'HalfpipeRoad Turn'  and  'HalfpipeRoad-Ramp Filler'\n\n", "Spiky Pillars :  An obstacle that is usually placed after a ramp for the cars to crash onto if they did not jump high or far enough!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Rail Doorway :  A rail doorway that works as an obstacle for cars flying above it or cars driving through it!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "The Wall", "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "Fixing Hoop :  The fixing hoop that fixes a car when it flies through it! You can add a max of 5 fixing hoops per stage.\nPlace it anywhere in the stage at an height your choose, the only important thing is that it needs to be reachable by the cars.", "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "OffRoad BumpySides :  Off-road dirt track with bumpy sandbar sides.\nAttaches correctly to the following other parts :\n\n'OffRoad-BumpySides Start'\n\n", "OffRoad-BumpySides Start: The start of the off-road dirt track with bumpy sandbar sides.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides',\n'Off-Halfpipe-Road Blend'  and  'Normal-Off-Road Blend'\n\n", "NormalRoad-Raised Ramp:  The start of the raised above the ground road (NormalRoad Raised).\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight'  and  'NormalRoad Raised'\n\n", "NormalRoad Raised :  Normal road raised above the ground, cars must avoid falling off it when driving on it.\nAttaches correctly to the following other parts :\n\n'NormalRoad-Raised Ramp'\n\n", "The Start1", "The Start2", "Tunnel Side Ramp:  A ramp that can be used to create a tunnel like road with an open top or can be used as a wall ramp!\nAttaches correctly over only the 'NormalRoad' part.", "Launch Pad Ramp:  A ramp that launches your car fully upwards like a rocket, it also has sides to lock any car climbing it!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "The Net:  An obstacle part that is to be placed in the center of the road right after a ramp, the idea is that the\ncars jumping the ramp should try to go over it or through it without getting caught crashing (without getting\ncaught in it, getting caught in the net!).\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Speed Ramp:  A ramp that is designed to have the perfect angle to catapult your car the furthest when doing forward loops, it is half the roads width.\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Offroad Hill Ramp:  An offroad hill ramp that has two different inclines from the front and back to jump.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Bump Slide:  A small bump obstacle that is to be placed on the sides of the road or in the center.\nAttaches correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Offroad Big Hill Ramp:  An offroad big hill ramp that has two different inclines from the front and back to jump.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Rollercoaster Start/End:  The ramp that starts the Rollercoaster Road and ends it.\nAttaches correctly over and to following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n 'NormalRoad TwistedRight'  and  'Rollercoaster Start/End'\n\n", "Rollercoaster Road1\nAttaches correctly to only 'Rollercoaster Start/End', 'Rollercoaster Road2' and itself.\n\n", "Rollercoaster Road3\nAttaches correctly to only 'Rollercoaster Road2', 'Rollercoaster Road4' and itself.\n\n", "Rollercoaster Road4\nAttaches correctly to only 'Rollercoaster Road3', 'Rollercoaster Road5' and itself.\n\n", "Rollercoaster Road2\nAttaches correctly to only 'Rollercoaster Road1', 'Rollercoaster Road3' and itself.\n\n", "Rollercoaster Road5\nAttaches correctly to only 'Rollercoaster Road4' and itself.\n\n", "Offroad Dirt-Pile:  A dirt pile obstacle that is to be placed anywhere in the middle of the road.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start'  and  'OffRoad-BumpySides'\n\n", "Offroad Dirt-Pile:  A dirt pile obstacle that is to be placed anywhere in the middle of the road.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start'  and  'OffRoad-BumpySides'\n\n", "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Ground Piles are to be paced outside the race track on the ground and NEVER on any road part or ramp!\nThey are to be used as ground decoration and out of race course obstacles (ground obstacles)!\n\n" };
    String[] errlo = { "The maximum allocated memory for the stage's part's details has been exerted.\nPlease decrease the amount of parts in the stage that have more details then average.", "The maximum amount of road points allowed in the track has been exceeded.\nPlease remove some of the road parts that are in the circler path of the track (the parts that are between the checkpoints).\nOr try to remove some of the extra checkpoints in the track as well.", "The maximum allowed area for a track (the area in between its walls) has been exceeded.\nPlease try to place parts only inside the current allowed area, inside the area between the current maximum wall placements.", "The maximum number of parts allowed per stage has been exceeded.\nPlease remove some of the already extra parts placed in order to make space.", "The maximum number of Fixing Hoops allowed per stage is 5!\nPlease remove the extra Fixing Hoops from your stage to have only 5 main ones left.", "Unknown Error, please make sure the stage you are handling is saved correctly.\nPlease go to the 'Build' tab and press 'Save & Preview'.", "There needs to be at least 2 checkpoints in the Stage in order for the game to work.\nPlease go to the 'Build' tab and select 'Checkpoint' in the Part Selection menu to add more checkpoints.", "The name of the stage is too long!\nPlease go to the 'Stage' tab, click 'Rename Stage' and give your stage a shorter name." };
    int[] rcheckp = { 0, 1, 2, 3, 4, 12, 13, 37 };
    int[] ocheckp = { 5, 6, 7, 11, 14, 33, 34, 38 };
    boolean onoff = false;
    boolean onfly = false;
    int flyh = 0;
    int[] csky = { 170, 220, 255 };
    int[] cgrnd = { 205, 200, 200 };
    int[] cfade = { 255, 220, 220 };
    int[] texture = { 0, 0, 0, 10 };
    int[] cldd = { 210, 210, 210, 1, -1000 };
    TextField mgen = new TextField("", 10);
    int vxz = 0;
    int vx = 0;
    int vz = 0;
    int vy = 0;
    int dtab = 0;
    int dtabed = -1;
    int mouseon = -1;
    float[][] hsb = { { 0.5F, 0.875F, 0.5F }, { 0.5F, 0.875F, 0.5F }, { 0.5F, 0.875F, 0.5F } };
    Checkbox pfog = new Checkbox("Linked Blend");
    int[] snap = { 50, 50, 50 };
    int[] fogn = { 60, 0 };
    Smenu nlaps = new Smenu(40);
    Smenu tracks = new Smenu(2000);
    String trackname = "";
    String ltrackname = "";
    int trackvol = 200;
    int tracksize = 111;
    RadicalMod track = new RadicalMod();
    int avon = 0;
    Smenu witho = new Smenu(40);
    int logged = 0;
    TextField tnick = new TextField("", 15);
    TextField tpass = new TextField("", 15);
    Smenu pubtyp = new Smenu(40);
    int nms = 0;
    String[] mystages = new String[20];
    String[] maker = new String[20];
    int[] pubt = new int[20];
    String[][] addeda = new String[20][5000];
    int[] nad = new int[20];
    boolean[] pessd = { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
    int[] bx = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    int[] by = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    int[] bw = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    int btn = 0;
    int mouses = 0;
    int xm = 0;
    int ym = 0;
    int lxm = 0;
    int lym = 0;
    int cntout = 0;
    boolean preop = false;
    boolean mousdr = false;
    String ttstage = "";
    
    public void run() {
        ((StageMaker) this).thredo.setPriority(10);
        ((StageMaker) this).btgame[0] = getImage("data/backtogame1.gif");
        ((StageMaker) this).btgame[1] = getImage("data/backtogame2.gif");
        ((StageMaker) this).logo = getImage("data/stagemakerlogo.gif");
        for (int i = 0; i < 2; i++) {
            ((StageMaker) this).su[i] = getImage(new StringBuilder().append("data/su").append(i + 1).append(".gif").toString());
            ((StageMaker) this).sl[i] = getImage(new StringBuilder().append("data/sl").append(i + 1).append(".gif").toString());
            ((StageMaker) this).sd[i] = getImage(new StringBuilder().append("data/sd").append(i + 1).append(".gif").toString());
            ((StageMaker) this).sr[i] = getImage(new StringBuilder().append("data/sr").append(i + 1).append(".gif").toString());
            ((StageMaker) this).zi[i] = getImage(new StringBuilder().append("data/zi").append(i + 1).append(".gif").toString());
            ((StageMaker) this).zo[i] = getImage(new StringBuilder().append("data/zo").append(i + 1).append(".gif").toString());
        }
        loadbase();
        loadsettings();
        if (Madness.testdrive != 0) {
            if (Madness.testcar.equals("Failx12")) {
                JOptionPane.showMessageDialog(null, "Failed to load stage! Please make sure stage is saved properly before Test Drive.", "Stage Maker", 1);
                ((StageMaker) this).thredo.stop();
            } else {
                ((StageMaker) this).stagename = Madness.testcar;
                ((StageMaker) this).errd = 0;
                readstage(3);
                if (((StageMaker) this).errd == 0) {
                    ((StageMaker) this).tab = 2;
                    ((StageMaker) this).dtab = 6;
                    ((StageMaker) this).witho.select(Madness.testdrive - 3);
                }
            }
            Madness.testcar = "";
            Madness.testdrive = 0;
        }
        requestFocus();
        while (!((StageMaker) this).exwist) {
            ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
            ((StageMaker) this).rd.fillRect(0, 25, 800, 525);
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            if (((StageMaker) this).tab != ((StageMaker) this).tabed)
                hidefields();
            if (((StageMaker) this).tab == 0) {
                if (((StageMaker) this).tabed != ((StageMaker) this).tab) {
                    ((StageMaker) this).slstage.removeAll();
                    ((Smenu) ((StageMaker) this).slstage).maxl = 360;
                    ((StageMaker) this).slstage.add(((StageMaker) this).rd, "Select a Stage                      ");
                    String[] strings = new File("mystages/").list();
                    if (strings != null) {
                        for (int i = 0; i < strings.length; i++) {
                            if (strings[i].toLowerCase().endsWith(".txt"))
                                ((StageMaker) this).slstage.add(((StageMaker) this).rd, strings[i].substring(0, strings[i].length() - 4));
                        }
                    }
                    if (((StageMaker) this).stagename.equals(""))
                        ((StageMaker) this).slstage.select(0);
                    else {
                        ((StageMaker) this).slstage.select(((StageMaker) this).stagename);
                        if (((StageMaker) this).stagename.equals(((StageMaker) this).slstage.getSelectedItem())) {
                            readstage(3);
                            ((StageMaker) this).sx = 0;
                            ((StageMaker) this).sz = 1500;
                            ((StageMaker) this).sy = -10000;
                        } else {
                            ((StageMaker) this).stagename = "";
                            ((StageMaker) this).slstage.select(0);
                        }
                    }
                    ((StageMaker) this).mouseon = -1;
                    ((StageMaker) this).sfase = 0;
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).logo, 261, 35, null);
                if (((StageMaker) this).xm > 261 && ((StageMaker) this).xm < 538 && ((StageMaker) this).ym > 35 && ((StageMaker) this).ym < 121) {
                    if (((StageMaker) this).mouseon == -1) {
                        ((StageMaker) this).mouseon = 3;
                        setCursor(new Cursor(12));
                    }
                } else if (((StageMaker) this).mouseon == 3) {
                    ((StageMaker) this).mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if (((StageMaker) this).mouseon == 3 && ((StageMaker) this).mouses == -1)
                    openhlink();
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                if (((StageMaker) this).xm > 200 && ((StageMaker) this).xm < 550 && ((StageMaker) this).ym > 467 && ((StageMaker) this).ym < 504) {
                    if (((StageMaker) this).mouseon == -1) {
                        ((StageMaker) this).mouseon = 2;
                        setCursor(new Cursor(12));
                    }
                } else if (((StageMaker) this).mouseon == 2) {
                    ((StageMaker) this).mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if (((StageMaker) this).mouseon == 2)
                    ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
                else
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawString("For the Stage Maker Homepage, Development Center and Forums :", 400 - ((StageMaker) this).ftm.stringWidth("For the Stage Maker Homepage, Development Center and Forums :") / 2, 480);
                ((StageMaker) this).rd.setColor(new Color(0, 128, 255));
                String string = "http://www.needformadness.com/developer/";
                ((StageMaker) this).rd.drawString(string, 400 - ((StageMaker) this).ftm.stringWidth(string) / 2, 500);
                if (((StageMaker) this).mouseon == 2)
                    ((StageMaker) this).rd.setColor(new Color(0, 128, 255));
                else
                    ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
                ((StageMaker) this).rd.drawLine(400 - ((StageMaker) this).ftm.stringWidth(string) / 2, 501, 400 + ((StageMaker) this).ftm.stringWidth(string) / 2, 501);
                if (((StageMaker) this).mouseon == 2 && ((StageMaker) this).mouses == -1)
                    openhlink();
                int i = -110;
                if (((StageMaker) this).xm > 150 && ((StageMaker) this).xm < 600 && ((StageMaker) this).ym > 467 + i && ((StageMaker) this).ym < 504 + i) {
                    if (((StageMaker) this).mouseon == -1) {
                        ((StageMaker) this).mouseon = 1;
                        setCursor(new Cursor(12));
                    }
                } else if (((StageMaker) this).mouseon == 1) {
                    ((StageMaker) this).mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if (((StageMaker) this).mouseon == 1)
                    ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
                else
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawString("For help and a detailed step by step description on how to use the Stage Maker :", 400 - ((StageMaker) this).ftm.stringWidth("For help and a detailed step by step description on how to use the Stage Maker :") / 2, 480 + i);
                ((StageMaker) this).rd.setColor(new Color(0, 128, 255));
                string = "http://www.needformadness.com/developer/help.html";
                ((StageMaker) this).rd.drawString(string, 400 - ((StageMaker) this).ftm.stringWidth(string) / 2, 500 + i);
                if (((StageMaker) this).mouseon == 1)
                    ((StageMaker) this).rd.setColor(new Color(0, 128, 255));
                else
                    ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
                ((StageMaker) this).rd.drawLine(400 - ((StageMaker) this).ftm.stringWidth(string) / 2, 501 + i, 400 + ((StageMaker) this).ftm.stringWidth(string) / 2, 501 + i);
                if (((StageMaker) this).mouseon == 1 && ((StageMaker) this).mouses == -1)
                    openlink();
                int i_0_ = -60;
                int i_1_ = 70;
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawRect(227 - i_1_, 194 + i_0_, 346 + i_1_ * 2, 167 + i_1_ / 5);
                if (((StageMaker) this).sfase == 0) {
                    ((StageMaker) this).rd.drawString("Select Stage to Edit", 400 - ((StageMaker) this).ftm.stringWidth("Select Stage to Edit") / 2, 230 + i_0_);
                    ((StageMaker) this).slstage.move(220, 240 + i_0_);
                    if (((StageMaker) this).slstage.getWidth() != 360)
                        ((StageMaker) this).slstage.setSize(360, 21);
                    if (!((StageMaker) this).slstage.isShowing())
                        ((StageMaker) this).slstage.show();
                    if (button("    Make new Stage    ", 400, 296 + i_0_, 0, true)) {
                        ((StageMaker) this).srch.setText("");
                        ((StageMaker) this).slstage.hide();
                        ((StageMaker) this).sfase = 1;
                    }
                    if (button("     Rename Stage     ", 325, 336 + i_0_, 0, false)) {
                        if (!((StageMaker) this).stagename.equals("")) {
                            ((StageMaker) this).slstage.hide();
                            ((StageMaker) this).srch.setText(((StageMaker) this).stagename);
                            ((StageMaker) this).sfase = 2;
                        } else
                            JOptionPane.showMessageDialog(null, "Please select a stage to rename first.", "Stage Maker", 1);
                    }
                    if (button("      Delete Stage      ", 475, 336 + i_0_, 0, false)) {
                        if (!((StageMaker) this).stagename.equals("")) {
                            if (JOptionPane.showConfirmDialog(null, new StringBuilder().append("Are you sure you want to permanently delete this stage?\n\n").append(((StageMaker) this).stagename).append("\n\n").toString(), "Stage Maker", 0) == 0)
                                delstage(((StageMaker) this).stagename);
                        } else
                            JOptionPane.showMessageDialog(null, "Please select a stage to delete first.", "Stage Maker", 1);
                    }
                    if (((StageMaker) this).slstage.getSelectedIndex() != 0) {
                        if (!((StageMaker) this).stagename.equals(((StageMaker) this).slstage.getSelectedItem())) {
                            ((StageMaker) this).stagename = ((StageMaker) this).slstage.getSelectedItem();
                            readstage(3);
                            ((StageMaker) this).sx = 0;
                            ((StageMaker) this).sz = 1500;
                            ((StageMaker) this).sy = -10000;
                            requestFocus();
                        }
                    } else
                        ((StageMaker) this).stagename = "";
                }
                if (((StageMaker) this).sfase == 1) {
                    ((StageMaker) this).rd.drawString("Make a new Stage", 400 - ((StageMaker) this).ftm.stringWidth("Make a new Stage") / 2, 220 + i_0_);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).rd.drawString("New stage name :", 200, 246 + i_0_);
                    movefield(((StageMaker) this).srch, 310, 231 + i_0_, 290, 23);
                    if (!((StageMaker) this).srch.isShowing()) {
                        ((StageMaker) this).srch.show();
                        ((StageMaker) this).srch.requestFocus();
                    }
                    fixtext(((StageMaker) this).srch);
                    ((StageMaker) this).rd.drawString("Starting line type :", 293, 272 + i_0_);
                    ((StageMaker) this).strtyp.move(408, 256 + i_0_);
                    if (!((StageMaker) this).strtyp.isShowing())
                        ((StageMaker) this).strtyp.show();
                    if (button("    Make Stage    ", 400, 311 + i_0_, 0, true))
                        newstage();
                    if (button("  Cancel  ", 400, 351 + i_0_, 0, false)) {
                        ((StageMaker) this).strtyp.hide();
                        ((StageMaker) this).srch.hide();
                        ((StageMaker) this).sfase = 0;
                    }
                }
                if (((StageMaker) this).sfase == 2) {
                    ((StageMaker) this).rd.drawString(new StringBuilder().append("Rename Stage :  ").append(((StageMaker) this).stagename).append("").toString(), 400 - ((StageMaker) this).ftm.stringWidth(new StringBuilder().append("Rename Stage :  ").append(((StageMaker) this).stagename).append("").toString()) / 2, 230 + i_0_);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).rd.drawString("New name :", 218, 266 + i_0_);
                    if (!((StageMaker) this).srch.isShowing()) {
                        ((StageMaker) this).srch.show();
                        ((StageMaker) this).srch.requestFocus();
                    }
                    movefield(((StageMaker) this).srch, 292, 251 + i_0_, 290, 23);
                    fixtext(((StageMaker) this).srch);
                    if (button("    Rename Stage    ", 400, 306 + i_0_, 0, true))
                        renstage(((StageMaker) this).srch.getText());
                    if (button("  Cancel  ", 400, 346 + i_0_, 0, false)) {
                        ((StageMaker) this).srch.hide();
                        ((StageMaker) this).sfase = 0;
                    }
                }
            }
            if (((StageMaker) this).tab == 1) {
                if (((StageMaker) this).tabed != ((StageMaker) this).tab) {
                    ((Medium) ((StageMaker) this).m).trk = 2;
                    readstage(0);
                    if (((StageMaker) this).sptyp == 0)
                        partroads();
                    if (((StageMaker) this).sptyp == 1)
                        partramps();
                    if (((StageMaker) this).sptyp == 2)
                        partobst();
                    if (((StageMaker) this).sptyp == 5)
                        partrees();
                    ((StageMaker) this).onoff = false;
                    setCursor(new Cursor(0));
                    ((StageMaker) this).setcur = false;
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                    if (((StageMaker) this).nob == 1) {
                        ((StageMaker) this).sptyp = 0;
                        if (((ContO) ((StageMaker) this).co[0]).colok == 38)
                            ((StageMaker) this).spart = 9;
                        else
                            ((StageMaker) this).spart = 0;
                    }
                    ((StageMaker) this).mouseon = -1;
                }
                if (((StageMaker) this).sptyp == 0) {
                    if (((StageMaker) this).spart == 0)
                        ((StageMaker) this).sp = 0;
                    if (((StageMaker) this).spart == 1)
                        ((StageMaker) this).sp = 4;
                    if (((StageMaker) this).spart == 2)
                        ((StageMaker) this).sp = 13;
                    if (((StageMaker) this).spart == 3)
                        ((StageMaker) this).sp = 3;
                    if (((StageMaker) this).spart == 4)
                        ((StageMaker) this).sp = 2;
                    if (((StageMaker) this).spart == 5)
                        ((StageMaker) this).sp = 1;
                    if (((StageMaker) this).spart == 6)
                        ((StageMaker) this).sp = 35;
                    if (((StageMaker) this).spart == 7)
                        ((StageMaker) this).sp = 36;
                    if (((StageMaker) this).spart == 8)
                        ((StageMaker) this).sp = 10;
                    if (((StageMaker) this).spart == 9)
                        ((StageMaker) this).sp = 5;
                    if (((StageMaker) this).spart == 10)
                        ((StageMaker) this).sp = 7;
                    if (((StageMaker) this).spart == 11)
                        ((StageMaker) this).sp = 14;
                    if (((StageMaker) this).spart == 12)
                        ((StageMaker) this).sp = 6;
                    if (((StageMaker) this).spart == 13)
                        ((StageMaker) this).sp = 34;
                    if (((StageMaker) this).spart == 14)
                        ((StageMaker) this).sp = 33;
                    if (((StageMaker) this).spart == 15)
                        ((StageMaker) this).sp = 11;
                    if (((StageMaker) this).spart == 16)
                        ((StageMaker) this).sp = 8;
                    if (((StageMaker) this).spart == 17)
                        ((StageMaker) this).sp = 9;
                    if (((StageMaker) this).spart == 18)
                        ((StageMaker) this).sp = 15;
                    if (((StageMaker) this).spart == 19)
                        ((StageMaker) this).sp = 12;
                    if (((StageMaker) this).spart == 20)
                        ((StageMaker) this).sp = 46;
                    if (((StageMaker) this).spart == 21)
                        ((StageMaker) this).sp = 47;
                    if (((StageMaker) this).spart == 22)
                        ((StageMaker) this).sp = 50;
                    if (((StageMaker) this).spart == 23)
                        ((StageMaker) this).sp = 48;
                    if (((StageMaker) this).spart == 24)
                        ((StageMaker) this).sp = 49;
                    if (((StageMaker) this).spart == 25)
                        ((StageMaker) this).sp = 51;
                }
                if (((StageMaker) this).sptyp == 1) {
                    if (((StageMaker) this).spart == 0)
                        ((StageMaker) this).sp = 16;
                    if (((StageMaker) this).spart == 1)
                        ((StageMaker) this).sp = 18;
                    if (((StageMaker) this).spart == 2)
                        ((StageMaker) this).sp = 19;
                    if (((StageMaker) this).spart == 3)
                        ((StageMaker) this).sp = 22;
                    if (((StageMaker) this).spart == 4)
                        ((StageMaker) this).sp = 17;
                    if (((StageMaker) this).spart == 5)
                        ((StageMaker) this).sp = 21;
                    if (((StageMaker) this).spart == 6)
                        ((StageMaker) this).sp = 20;
                    if (((StageMaker) this).spart == 7)
                        ((StageMaker) this).sp = 39;
                    if (((StageMaker) this).spart == 8)
                        ((StageMaker) this).sp = 42;
                    if (((StageMaker) this).spart == 9)
                        ((StageMaker) this).sp = 40;
                    if (((StageMaker) this).spart == 10)
                        ((StageMaker) this).sp = 23;
                    if (((StageMaker) this).spart == 11)
                        ((StageMaker) this).sp = 25;
                    if (((StageMaker) this).spart == 12)
                        ((StageMaker) this).sp = 24;
                    if (((StageMaker) this).spart == 13)
                        ((StageMaker) this).sp = 43;
                    if (((StageMaker) this).spart == 14)
                        ((StageMaker) this).sp = 45;
                    if (((StageMaker) this).spart == 15)
                        ((StageMaker) this).sp = 26;
                }
                if (((StageMaker) this).sptyp == 2) {
                    if (((StageMaker) this).spart == 0)
                        ((StageMaker) this).sp = 27;
                    if (((StageMaker) this).spart == 1)
                        ((StageMaker) this).sp = 28;
                    if (((StageMaker) this).spart == 2)
                        ((StageMaker) this).sp = 41;
                    if (((StageMaker) this).spart == 3)
                        ((StageMaker) this).sp = 44;
                    if (((StageMaker) this).spart == 4)
                        ((StageMaker) this).sp = 52;
                    if (((StageMaker) this).spart == 5)
                        ((StageMaker) this).sp = 53;
                }
                if (((StageMaker) this).sptyp == 3) {
                    if (((StageMaker) this).onfly)
                        ((StageMaker) this).sp = 54;
                    else if (!((StageMaker) this).onoff)
                        ((StageMaker) this).sp = 30;
                    else
                        ((StageMaker) this).sp = 32;
                }
                if (((StageMaker) this).sptyp == 4)
                    ((StageMaker) this).sp = 31;
                if (((StageMaker) this).sptyp == 5) {
                    if (((StageMaker) this).spart == 0)
                        ((StageMaker) this).sp = 55;
                    if (((StageMaker) this).spart == 1)
                        ((StageMaker) this).sp = 56;
                    if (((StageMaker) this).spart == 2)
                        ((StageMaker) this).sp = 57;
                    if (((StageMaker) this).spart == 3)
                        ((StageMaker) this).sp = 58;
                    if (((StageMaker) this).spart == 4)
                        ((StageMaker) this).sp = 59;
                    if (((StageMaker) this).spart == 5)
                        ((StageMaker) this).sp = 60;
                    if (((StageMaker) this).spart == 6)
                        ((StageMaker) this).sp = 61;
                    if (((StageMaker) this).spart == 7)
                        ((StageMaker) this).sp = 62;
                    if (((StageMaker) this).spart == 8)
                        ((StageMaker) this).sp = 63;
                    if (((StageMaker) this).spart == 9)
                        ((StageMaker) this).sp = 64;
                    if (((StageMaker) this).spart == 10)
                        ((StageMaker) this).sp = 65;
                }
                if (((StageMaker) this).sptyp == 6) {
                    if (!((StageMaker) this).pgen) {
                        int i = (int) (10000.0 * Math.random());
                        if (((StageMaker) this).fgen != 0) {
                            i = ((StageMaker) this).fgen;
                            ((StageMaker) this).fgen = 0;
                        }
                        ((StageMaker) this).bco[66] = new ContO(i, (int) ((StageMaker) this).pwd, (int) ((StageMaker) this).phd, ((StageMaker) this).m, ((StageMaker) this).t, 0, 0, 0);
                        ((ContO) ((StageMaker) this).bco[66]).srz = i;
                        ((ContO) ((StageMaker) this).bco[66]).srx = (int) ((StageMaker) this).pwd;
                        ((ContO) ((StageMaker) this).bco[66]).sry = (int) ((StageMaker) this).phd;
                        ((StageMaker) this).pgen = true;
                        ((StageMaker) this).seq = 3;
                    }
                    ((StageMaker) this).sp = 66;
                    ((StageMaker) this).rot = 0;
                } else if (((StageMaker) this).pgen) {
                    ((StageMaker) this).pgen = false;
                    ((StageMaker) this).pwd = (float) (2L + Math.round(Math.random() * 4.0));
                    ((StageMaker) this).phd = (float) (2L + Math.round(Math.random() * 4.0));
                }
                if (((StageMaker) this).sp == 30 || ((StageMaker) this).sp == 31 || ((StageMaker) this).sp == 32 || ((StageMaker) this).sp == 54) {
                    if (((StageMaker) this).rot == -90)
                        ((StageMaker) this).rot = 90;
                    if (((StageMaker) this).rot == 180)
                        ((StageMaker) this).rot = 0;
                }
                ((StageMaker) this).adrot = 0;
                if (((StageMaker) this).sp == 2)
                    ((StageMaker) this).adrot = -30;
                if (((StageMaker) this).sp == 3)
                    ((StageMaker) this).adrot = 30;
                if (((StageMaker) this).sp == 15)
                    ((StageMaker) this).adrot = 90;
                if (((StageMaker) this).sp == 20)
                    ((StageMaker) this).adrot = 180;
                if (((StageMaker) this).sp == 26)
                    ((StageMaker) this).adrot = 90;
                ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
                ((StageMaker) this).rd.fillRect(248, 63, 514, 454);
                ((Medium) ((StageMaker) this).m).trk = 2;
                ((Medium) ((StageMaker) this).m).zy = 90;
                ((Medium) ((StageMaker) this).m).xz = 0;
                ((Medium) ((StageMaker) this).m).iw = 248;
                ((Medium) ((StageMaker) this).m).w = 762;
                ((Medium) ((StageMaker) this).m).ih = 63;
                ((Medium) ((StageMaker) this).m).h = 517;
                ((Medium) ((StageMaker) this).m).cx = 505;
                ((Medium) ((StageMaker) this).m).cy = 290;
                ((Medium) ((StageMaker) this).m).x = ((StageMaker) this).sx - ((Medium) ((StageMaker) this).m).cx;
                ((Medium) ((StageMaker) this).m).z = ((StageMaker) this).sz - ((Medium) ((StageMaker) this).m).cz;
                ((Medium) ((StageMaker) this).m).y = ((StageMaker) this).sy;
                int i = 0;
                int[] is = new int[10000]; // stageselect limit
                for (int i_2_ = 0; i_2_ < ((StageMaker) this).nob; i_2_++) {
                    if (((ContO) ((StageMaker) this).co[i_2_]).dist != 0) {
                        is[i] = i_2_;
                        i++;
                    } else
                        ((StageMaker) this).co[i_2_].d(((StageMaker) this).rd);
                }
                int[] is_3_ = new int[i];
                for (int i_4_ = 0; i_4_ < i; i_4_++)
                    is_3_[i_4_] = 0;
                for (int i_5_ = 0; i_5_ < i; i_5_++) {
                    for (int i_6_ = i_5_ + 1; i_6_ < i; i_6_++) {
                        if (((ContO) ((StageMaker) this).co[is[i_5_]]).dist != ((ContO) ((StageMaker) this).co[is[i_6_]]).dist) {
                            if (((ContO) ((StageMaker) this).co[is[i_5_]]).dist < ((ContO) ((StageMaker) this).co[is[i_6_]]).dist)
                                is_3_[i_5_]++;
                            else
                                is_3_[i_6_]++;
                        } else if (i_6_ > i_5_)
                            is_3_[i_5_]++;
                        else
                            is_3_[i_6_]++;
                    }
                }
                for (int i_7_ = 0; i_7_ < i; i_7_++) {
                    for (int i_8_ = 0; i_8_ < i; i_8_++) {
                        if (is_3_[i_8_] == i_7_) {
                            if (is[i_8_] == ((StageMaker) this).hi)
                                ((Medium) ((StageMaker) this).m).trk = 3;
                            if (is[i_8_] == ((StageMaker) this).chi && !((ContO) ((StageMaker) this).co[is[i_8_]]).errd) {
                                int i_9_ = ((Medium) ((StageMaker) this).m).cx + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz) - (float) (((ContO) ((StageMaker) this).co[is[i_8_]]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz));
                                int i_10_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz) + (float) (((ContO) ((StageMaker) this).co[is[i_8_]]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz));
                                int i_11_ = ((Medium) ((StageMaker) this).m).cy + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy) - (float) (i_10_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy));
                                int i_12_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy) + (float) (i_10_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy));
                                int i_13_ = 1000000 / Math.abs(((StageMaker) this).sy);
                                Graphics2D graphics2d = ((StageMaker) this).rd;
                                graphics2d.setComposite(AlphaComposite.getInstance(3, 0.7F));
                                ((StageMaker) this).rd.setColor(new Color(0, 164, 255));
                                ((StageMaker) this).rd.fillOval(xs(i_9_, i_12_) - i_13_ / 2, ys(i_11_, i_12_) - i_13_ / 2, i_13_, i_13_);
                                graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                                ((StageMaker) this).rd.drawString(new StringBuilder().append("NO# ").append(((StageMaker) this).arrcnt + 1).append("").toString(), xs(i_9_, i_12_) - ((StageMaker) this).ftm.stringWidth(new StringBuilder().append("NO# ").append(((StageMaker) this).arrcnt + 1).append("").toString()) / 2, ys(i_11_, i_12_) - i_13_ / 2);
                            }
                            if (((StageMaker) this).arrng && (((ContO) ((StageMaker) this).co[is[i_8_]]).colok == 30 || ((ContO) ((StageMaker) this).co[is[i_8_]]).colok == 32 || ((ContO) ((StageMaker) this).co[is[i_8_]]).colok == 54) && ((ContO) ((StageMaker) this).co[is[i_8_]]).errd) {
                                int i_14_ = ((Medium) ((StageMaker) this).m).cx + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz) - (float) (((ContO) ((StageMaker) this).co[is[i_8_]]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz));
                                int i_15_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz) + (float) (((ContO) ((StageMaker) this).co[is[i_8_]]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz));
                                int i_16_ = ((Medium) ((StageMaker) this).m).cy + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy) - (float) (i_15_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy));
                                int i_17_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[is[i_8_]]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy) + (float) (i_15_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy));
                                int i_18_ = 1000000 / Math.abs(((StageMaker) this).sy);
                                Graphics2D graphics2d = ((StageMaker) this).rd;
                                graphics2d.setComposite(AlphaComposite.getInstance(3, 0.5F));
                                ((StageMaker) this).rd.setColor(new Color(255, 128, 0));
                                ((StageMaker) this).rd.fillOval(xs(i_14_, i_17_) - i_18_ / 2, ys(i_16_, i_17_) - i_18_ / 2, i_18_, i_18_);
                                graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                                ((StageMaker) this).rd.drawString(new StringBuilder().append("NO# ").append(((ContO) ((StageMaker) this).co[is[i_8_]]).wh).append("").toString(), xs(i_14_, i_17_) - ((StageMaker) this).ftm.stringWidth(new StringBuilder().append("NO# ").append(((ContO) ((StageMaker) this).co[is[i_8_]]).wh).append("").toString()) / 2, ys(i_16_, i_17_) - i_18_ / 2);
                            }
                            ((StageMaker) this).co[is[i_8_]].d(((StageMaker) this).rd);
                            if (((Medium) ((StageMaker) this).m).trk == 3)
                                ((Medium) ((StageMaker) this).m).trk = 2;
                        }
                    }
                }
                if (((StageMaker) this).xm > 248 && ((StageMaker) this).xm < 762 && ((StageMaker) this).ym > 63 && ((StageMaker) this).ym < 517) {
                    if (!((StageMaker) this).epart && !((StageMaker) this).arrng) {
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x = (((StageMaker) this).xm - 505) * (Math.abs(((StageMaker) this).sy) / ((Medium) ((StageMaker) this).m).focus_point) + ((StageMaker) this).sx;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z = (290 - ((StageMaker) this).ym) * (Math.abs(((StageMaker) this).sy) / ((Medium) ((StageMaker) this).m).focus_point) + ((StageMaker) this).sz;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y = ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).grat;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz = ((StageMaker) this).rot + ((StageMaker) this).adrot;
                        int i_19_ = 200;
                        int i_20_ = 0;
                        int i_21_ = 0;
                        int[] is_22_ = { ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x + ((StageMaker) this).atp[((StageMaker) this).sp][0], ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x + ((StageMaker) this).atp[((StageMaker) this).sp][2] };
                        int[] is_23_ = { ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z + ((StageMaker) this).atp[((StageMaker) this).sp][1], ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z + ((StageMaker) this).atp[((StageMaker) this).sp][3] };
                        rot(is_22_, is_23_, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((StageMaker) this).rot, 2);
                        int i_24_ = 0;
                        ((StageMaker) this).onfly = false;
                        int i_25_ = 500;
                        for (int i_26_ = 0; i_26_ < ((StageMaker) this).nob; i_26_++) {
                            int[] is_27_ = { ((ContO) ((StageMaker) this).co[i_26_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_26_]).colok][0], ((ContO) ((StageMaker) this).co[i_26_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_26_]).colok][2] };
                            int[] is_28_ = { ((ContO) ((StageMaker) this).co[i_26_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_26_]).colok][1], ((ContO) ((StageMaker) this).co[i_26_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_26_]).colok][3] };
                            int i_29_ = ((ContO) ((StageMaker) this).co[i_26_]).roofat;
                            if (((ContO) ((StageMaker) this).co[i_26_]).colok == 2)
                                i_29_ += 30;
                            if (((ContO) ((StageMaker) this).co[i_26_]).colok == 3)
                                i_29_ -= 30;
                            if (((ContO) ((StageMaker) this).co[i_26_]).colok == 15)
                                i_29_ -= 90;
                            if (((ContO) ((StageMaker) this).co[i_26_]).colok == 20)
                                i_29_ -= 180;
                            if (((ContO) ((StageMaker) this).co[i_26_]).colok == 26)
                                i_29_ -= 90;
                            rot(is_27_, is_28_, ((ContO) ((StageMaker) this).co[i_26_]).x, ((ContO) ((StageMaker) this).co[i_26_]).z, i_29_, 2);
                            if (((StageMaker) this).sp <= 54) {
                                int i_30_ = py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]);
                                if (i_30_ < i_19_ && i_30_ != 0) {
                                    i_19_ = i_30_;
                                    i_20_ = is_27_[0] - is_22_[0];
                                    i_21_ = is_28_[0] - is_23_[0];
                                }
                                i_30_ = py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]);
                                if (i_30_ < i_19_ && i_30_ != 0) {
                                    i_19_ = i_30_;
                                    i_20_ = is_27_[1] - is_22_[0];
                                    i_21_ = is_28_[1] - is_23_[0];
                                }
                                i_30_ = py(is_27_[1], is_22_[1], is_28_[1], is_23_[1]);
                                if (i_30_ < i_19_ && i_30_ != 0) {
                                    i_19_ = i_30_;
                                    i_20_ = is_27_[1] - is_22_[1];
                                    i_21_ = is_28_[1] - is_23_[1];
                                }
                                i_30_ = py(is_27_[0], is_22_[1], is_28_[0], is_23_[1]);
                                if (i_30_ < i_19_ && i_30_ != 0) {
                                    i_19_ = i_30_;
                                    i_20_ = is_27_[0] - is_22_[1];
                                    i_21_ = is_28_[0] - is_23_[1];
                                }
                            }
                            if (((StageMaker) this).sptyp == 3 && py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]) != 0 && py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]) != 0) {
                                for (int i_31_ = 0; i_31_ < ((StageMaker) this).rcheckp.length; i_31_++) {
                                    if (((ContO) ((StageMaker) this).co[i_26_]).colok == ((StageMaker) this).rcheckp[i_31_]) {
                                        if (py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]) <= i_24_ || i_24_ == 0) {
                                            i_24_ = py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]);
                                            ((StageMaker) this).onoff = false;
                                        }
                                        if (py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]) <= i_24_) {
                                            i_24_ = py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]);
                                            ((StageMaker) this).onoff = false;
                                        }
                                    }
                                }
                                for (int i_32_ = 0; i_32_ < ((StageMaker) this).ocheckp.length; i_32_++) {
                                    if (((ContO) ((StageMaker) this).co[i_26_]).colok == ((StageMaker) this).ocheckp[i_32_]) {
                                        if (py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]) <= i_24_ || i_24_ == 0) {
                                            i_24_ = py(is_27_[0], is_22_[0], is_28_[0], is_23_[0]);
                                            ((StageMaker) this).onoff = true;
                                        }
                                        if (py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]) <= i_24_) {
                                            i_24_ = py(is_27_[1], is_22_[0], is_28_[1], is_23_[0]);
                                            ((StageMaker) this).onoff = true;
                                        }
                                    }
                                }
                            }
                            if (((StageMaker) this).sp > 12 && ((StageMaker) this).sp < 33 || ((StageMaker) this).sp == 35 || ((StageMaker) this).sp == 36 || ((StageMaker) this).sp >= 39 && ((StageMaker) this).sp <= 54) {
                                if ((((StageMaker) this).rot == 0 || ((StageMaker) this).rot == 180 || ((StageMaker) this).sp == 26 || ((StageMaker) this).sp == 15) && (i_29_ == 0 || i_29_ == 180 || ((StageMaker) this).sp == 26 || ((StageMaker) this).sp == 15)) {
                                    if (Math.abs(is_27_[0] - is_22_[0]) < 200)
                                        i_20_ = is_27_[0] - is_22_[0];
                                    if (Math.abs(is_27_[0] - is_22_[1]) < 200)
                                        i_20_ = is_27_[0] - is_22_[1];
                                    if (Math.abs(is_27_[1] - is_22_[1]) < 200)
                                        i_20_ = is_27_[1] - is_22_[1];
                                    if (Math.abs(is_27_[1] - is_22_[0]) < 200)
                                        i_20_ = is_27_[1] - is_22_[0];
                                }
                                if ((((StageMaker) this).rot == 90 || ((StageMaker) this).rot == -90 || ((StageMaker) this).sp == 26 || ((StageMaker) this).sp == 15) && (i_29_ == 90 || i_29_ == -90 || ((StageMaker) this).sp == 26 || ((StageMaker) this).sp == 15)) {
                                    if (Math.abs(is_28_[0] - is_23_[0]) < 200)
                                        i_21_ = is_28_[0] - is_23_[0];
                                    if (Math.abs(is_28_[0] - is_23_[1]) < 200)
                                        i_21_ = is_28_[0] - is_23_[1];
                                    if (Math.abs(is_28_[1] - is_23_[1]) < 200)
                                        i_21_ = is_28_[1] - is_23_[1];
                                    if (Math.abs(is_28_[1] - is_23_[0]) < 200)
                                        i_21_ = is_28_[1] - is_23_[0];
                                }
                            }
                            if (((StageMaker) this).sptyp == 3 && ((ContO) ((StageMaker) this).co[i_26_]).colok >= 46 && ((ContO) ((StageMaker) this).co[i_26_]).colok <= 51) {
                                int[] is_33_ = { 2, 3, 5, 2, 3, 3 };
                                if ((Math.abs(((ContO) ((StageMaker) this).co[i_26_]).roofat) == 180 || ((ContO) ((StageMaker) this).co[i_26_]).roofat == 0) && ((StageMaker) this).rot == 0 && Math.abs(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x - ((ContO) ((StageMaker) this).co[i_26_]).x) < 500 && Math.abs(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z - ((ContO) ((StageMaker) this).co[i_26_]).z) < 3000) {
                                    for (int i_34_ = 0; i_34_ < is_33_[((ContO) ((StageMaker) this).co[i_26_]).colok - 46]; i_34_++) {
                                        for (int i_35_ = 0; i_35_ < ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_34_]).n; i_35_++) {
                                            if (py(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).co[i_26_]).x, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).co[i_26_]).z + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_34_]).oz[i_35_]) < i_25_) {
                                                i_25_ = py(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).co[i_26_]).x, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).co[i_26_]).z + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_34_]).oz[i_35_]);
                                                ((StageMaker) this).flyh = ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_34_]).oy[i_35_] - 28 + ((Medium) ((StageMaker) this).m).ground;
                                                i_20_ = ((ContO) ((StageMaker) this).co[i_26_]).x - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x;
                                                i_21_ = ((ContO) ((StageMaker) this).co[i_26_]).z + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_34_]).oz[i_35_] - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z;
                                                ((StageMaker) this).onfly = true;
                                            }
                                        }
                                    }
                                }
                                if (Math.abs(((ContO) ((StageMaker) this).co[i_26_]).roofat) == 90 && ((StageMaker) this).rot == 90 && Math.abs(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z - ((ContO) ((StageMaker) this).co[i_26_]).z) < 500 && Math.abs(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x - ((ContO) ((StageMaker) this).co[i_26_]).x) < 3000) {
                                    for (int i_36_ = 0; i_36_ < is_33_[((ContO) ((StageMaker) this).co[i_26_]).colok - 46]; i_36_++) {
                                        for (int i_37_ = 0; i_37_ < ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_36_]).n; i_37_++) {
                                            if (py(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).co[i_26_]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).co[i_26_]).x + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_36_]).ox[i_37_]) < i_25_) {
                                                i_25_ = py(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).co[i_26_]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).co[i_26_]).x + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_36_]).ox[i_37_]);
                                                ((StageMaker) this).flyh = ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_36_]).oy[i_37_] - 28 + ((Medium) ((StageMaker) this).m).ground;
                                                i_21_ = ((ContO) ((StageMaker) this).co[i_26_]).z - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z;
                                                i_20_ = ((ContO) ((StageMaker) this).co[i_26_]).x + ((Plane) ((ContO) ((StageMaker) this).co[i_26_]).p[i_36_]).ox[i_37_] - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x;
                                                ((StageMaker) this).onfly = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x += i_20_;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z += i_21_;
                        int i_38_ = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy;
                        int i_39_ = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy;
                        if (((StageMaker) this).sp == 31) {
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y = -((StageMaker) this).hf;
                            if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y > -500)
                                ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y = -500;
                        } else
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                        if (((StageMaker) this).sp == 54)
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y = ((StageMaker) this).flyh;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                        if (((StageMaker) this).cntout == 0) {
                            if (((StageMaker) this).mouseon == -1) {
                                ((StageMaker) this).bco[((StageMaker) this).sp].d(((StageMaker) this).rd);
                                if (!((StageMaker) this).setcur) {
                                    setCursor(new Cursor(13));
                                    ((StageMaker) this).setcur = true;
                                }
                                if (((StageMaker) this).mouses == -1) {
                                    if (((StageMaker) this).nundo < 5000) {
                                        ((StageMaker) this).undos[((StageMaker) this).nundo] = ((StageMaker) this).bstage;
                                        ((StageMaker) this).nundo++;
                                    }
                                    if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz == 270)
                                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz = -90;
                                    if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz == 360)
                                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz = 0;
                                    ((StageMaker) this).errd = 0;
                                    boolean bool = false;
                                    if (((StageMaker) this).xnob < 10000) {
                                        if (((StageMaker) this).sp != 31 && ((StageMaker) this).sp != 54 && ((StageMaker) this).sp != 66) {
                                            try {
                                                ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[((StageMaker) this).sp], ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).grat, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz);
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz;
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = ((StageMaker) this).sp;
                                                ((StageMaker) this).nob++;
                                            } catch (Exception exception) {
                                                ((StageMaker) this).errd = 1;
                                            }
                                        }
                                        if (((StageMaker) this).sp == 31) {
                                            if (((CheckPoints) ((StageMaker) this).cp).fn < 5) {
                                                ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[((StageMaker) this).sp], ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz);
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz;
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = ((StageMaker) this).sp;
                                                ((StageMaker) this).nob++;
                                                ((StageMaker) this).fixh.setText(new StringBuilder().append("").append(Math.abs(((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y)).append("").toString());
                                            } else
                                                ((StageMaker) this).errd = 5;
                                        }
                                        if (((StageMaker) this).sp == 54) {
                                            try {
                                                ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[((StageMaker) this).sp], ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz);
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz;
                                                ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = ((StageMaker) this).sp;
                                                ((StageMaker) this).nob++;
                                            } catch (Exception exception) {
                                                ((StageMaker) this).errd = 1;
                                            }
                                        }
                                        if (((StageMaker) this).sp == 66) {
                                            ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((ContO) ((StageMaker) this).bco[66]).srz, ((ContO) ((StageMaker) this).bco[66]).srx, ((ContO) ((StageMaker) this).bco[66]).sry, ((StageMaker) this).m, ((StageMaker) this).t, ((ContO) ((StageMaker) this).bco[66]).x, ((ContO) ((StageMaker) this).bco[66]).z, ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y);
                                            ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).srz = ((ContO) ((StageMaker) this).bco[66]).srz;
                                            ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).srx = ((ContO) ((StageMaker) this).bco[66]).srx;
                                            ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).sry = ((ContO) ((StageMaker) this).bco[66]).sry;
                                            ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = ((StageMaker) this).sp;
                                            ((StageMaker) this).nob++;
                                        }
                                    } else
                                        ((StageMaker) this).errd = 4;
                                    if (((StageMaker) this).errd == 0) {
                                        sortstage();
                                        readstage(0);
                                        bool = true;
                                        if (((StageMaker) this).sp == 66)
                                            ((StageMaker) this).pgen = false;
                                        if (((StageMaker) this).sp == 52 || ((StageMaker) this).sp == 53 || ((StageMaker) this).sp >= 55 && ((StageMaker) this).sp <= 65) {
                                            ((StageMaker) this).seq = 3;
                                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                                            boolean bool_40_ = false;
                                            if (((StageMaker) this).rot == 0 && !bool_40_) {
                                                ((StageMaker) this).rot = 90;
                                                bool_40_ = true;
                                            }
                                            if (((StageMaker) this).rot == 90 && !bool_40_) {
                                                ((StageMaker) this).rot = 180;
                                                bool_40_ = true;
                                            }
                                            if (((StageMaker) this).rot == 180 && !bool_40_) {
                                                ((StageMaker) this).rot = -90;
                                                bool_40_ = true;
                                            }
                                            if (((StageMaker) this).rot == -90 && !bool_40_) {
                                                ((StageMaker) this).rot = 0;
                                                bool_40_ = true;
                                            }
                                        }
                                    }
                                    if (((StageMaker) this).errd != 0) {
                                        JOptionPane.showMessageDialog(null, new StringBuilder().append("Error!  Unable to place part!\nReason:\n").append(((StageMaker) this).errlo[((StageMaker) this).errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                                        if (bool) {
                                            ((StageMaker) this).nundo--;
                                            ((StageMaker) this).bstage = ((StageMaker) this).undos[((StageMaker) this).nundo];
                                            readstage(0);
                                        }
                                    }
                                    ((StageMaker) this).lxm = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x;
                                    ((StageMaker) this).lym = ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z;
                                    ((StageMaker) this).cntout = 10;
                                }
                            }
                        } else {
                            if (((StageMaker) this).lxm != ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x && ((StageMaker) this).lxm != ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z)
                                ((StageMaker) this).cntout--;
                            if (((StageMaker) this).setcur) {
                                setCursor(new Cursor(0));
                                ((StageMaker) this).setcur = false;
                            }
                        }
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = i_38_;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = i_39_;
                    } else {
                        if (((StageMaker) this).epart) {
                            if (((StageMaker) this).esp == -1 && !((StageMaker) this).overcan) {
                                ((StageMaker) this).hi = -1;
                                int i_41_ = 0;
                                for (int i_42_ = 0; i_42_ < ((StageMaker) this).nob; i_42_++) {
                                    int i_43_ = ((Medium) ((StageMaker) this).m).cx + (int) ((float) (((ContO) ((StageMaker) this).co[i_42_]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz) - (float) (((ContO) ((StageMaker) this).co[i_42_]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz));
                                    int i_44_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[i_42_]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz) + (float) (((ContO) ((StageMaker) this).co[i_42_]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz));
                                    int i_45_ = ((Medium) ((StageMaker) this).m).cy + (int) ((float) (((ContO) ((StageMaker) this).co[i_42_]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy) - (float) (i_44_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy));
                                    int i_46_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[i_42_]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy) + (float) (i_44_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy));
                                    if (((StageMaker) this).xm > xs(i_43_ - ((ContO) ((StageMaker) this).co[i_42_]).maxR, i_46_) && ((StageMaker) this).xm < xs(i_43_ + ((ContO) ((StageMaker) this).co[i_42_]).maxR, i_46_) && ((StageMaker) this).ym > ys(i_45_ - ((ContO) ((StageMaker) this).co[i_42_]).maxR, i_46_) && ((StageMaker) this).ym < ys(i_45_ + ((ContO) ((StageMaker) this).co[i_42_]).maxR, i_46_) && ((ContO) ((StageMaker) this).co[i_42_]).colok != 37 && ((ContO) ((StageMaker) this).co[i_42_]).colok != 38) {
                                        if (((StageMaker) this).hi == -1) {
                                            ((StageMaker) this).hi = i_42_;
                                            i_41_ = py(((StageMaker) this).xm, xs(i_43_, i_46_), ((StageMaker) this).ym, ys(i_45_, i_46_));
                                        } else if (py(((StageMaker) this).xm, xs(i_43_, i_46_), ((StageMaker) this).ym, ys(i_45_, i_46_)) <= i_41_) {
                                            ((StageMaker) this).hi = i_42_;
                                            i_41_ = py(((StageMaker) this).xm, xs(i_43_, i_46_), ((StageMaker) this).ym, ys(i_45_, i_46_));
                                        }
                                    }
                                }
                                if (((StageMaker) this).hi != -1) {
                                    if (!((StageMaker) this).setcur) {
                                        setCursor(new Cursor(13));
                                        ((StageMaker) this).setcur = true;
                                    }
                                    if (((StageMaker) this).mouses == -1) {
                                        ((StageMaker) this).esp = ((StageMaker) this).hi;
                                        ((StageMaker) this).mouses = 0;
                                    }
                                } else if (((StageMaker) this).setcur) {
                                    setCursor(new Cursor(0));
                                    ((StageMaker) this).setcur = false;
                                }
                            } else if (((StageMaker) this).setcur) {
                                setCursor(new Cursor(0));
                                ((StageMaker) this).setcur = false;
                            }
                        }
                        if (((StageMaker) this).arrng) {
                            ((StageMaker) this).chi = -1;
                            int i_47_ = 5000;
                            for (int i_48_ = 0; i_48_ < ((StageMaker) this).nob; i_48_++) {
                                if ((((ContO) ((StageMaker) this).co[i_48_]).colok == 30 || ((ContO) ((StageMaker) this).co[i_48_]).colok == 32 || ((ContO) ((StageMaker) this).co[i_48_]).colok == 54) && !((ContO) ((StageMaker) this).co[i_48_]).errd) {
                                    int i_49_ = ((Medium) ((StageMaker) this).m).cx + (int) ((float) (((ContO) ((StageMaker) this).co[i_48_]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz) - (float) (((ContO) ((StageMaker) this).co[i_48_]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz));
                                    int i_50_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[i_48_]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz) + (float) (((ContO) ((StageMaker) this).co[i_48_]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz));
                                    int i_51_ = ((Medium) ((StageMaker) this).m).cy + (int) ((float) (((ContO) ((StageMaker) this).co[i_48_]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy) - (float) (i_50_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy));
                                    int i_52_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[i_48_]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy) + (float) (i_50_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy));
                                    if (((StageMaker) this).xm > xs(i_49_ - ((ContO) ((StageMaker) this).co[i_48_]).maxR, i_52_) && ((StageMaker) this).xm < xs(i_49_ + ((ContO) ((StageMaker) this).co[i_48_]).maxR, i_52_) && ((StageMaker) this).ym > ys(i_51_ - ((ContO) ((StageMaker) this).co[i_48_]).maxR, i_52_) && ((StageMaker) this).ym < ys(i_51_ + ((ContO) ((StageMaker) this).co[i_48_]).maxR, i_52_) && py(((StageMaker) this).xm, xs(i_49_, i_52_), ((StageMaker) this).ym, ys(i_51_, i_52_)) <= i_47_) {
                                        ((StageMaker) this).chi = i_48_;
                                        i_47_ = py(((StageMaker) this).xm, xs(i_49_, i_52_), ((StageMaker) this).ym, ys(i_51_, i_52_));
                                    }
                                }
                            }
                            if (((StageMaker) this).chi != -1) {
                                if (!((StageMaker) this).setcur) {
                                    setCursor(new Cursor(13));
                                    ((StageMaker) this).setcur = true;
                                }
                                if (((StageMaker) this).mouses == -1) {
                                    ((StageMaker) this).arrcnt++;
                                    ((ContO) ((StageMaker) this).co[((StageMaker) this).chi]).wh = ((StageMaker) this).arrcnt;
                                    ((ContO) ((StageMaker) this).co[((StageMaker) this).chi]).errd = true;
                                    ((StageMaker) this).mouses = 0;
                                }
                            } else if (((StageMaker) this).setcur) {
                                setCursor(new Cursor(0));
                                ((StageMaker) this).setcur = false;
                            }
                        }
                    }
                } else if (((StageMaker) this).setcur) {
                    setCursor(new Cursor(0));
                    ((StageMaker) this).setcur = false;
                }
                if (((StageMaker) this).epart && ((StageMaker) this).esp != -1) {
                    if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).dist != 0) {
                        ((Medium) ((StageMaker) this).m).cx = 505;
                        ((Medium) ((StageMaker) this).m).cy = 290;
                        ((Medium) ((StageMaker) this).m).x = ((StageMaker) this).sx - ((Medium) ((StageMaker) this).m).cx;
                        ((Medium) ((StageMaker) this).m).z = ((StageMaker) this).sz - ((Medium) ((StageMaker) this).m).cz;
                        ((Medium) ((StageMaker) this).m).y = ((StageMaker) this).sy;
                        int i_53_ = ((Medium) ((StageMaker) this).m).cx + (int) ((float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz) - (float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz));
                        int i_54_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x - ((Medium) ((StageMaker) this).m).x - ((Medium) ((StageMaker) this).m).cx) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz) + (float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z - ((Medium) ((StageMaker) this).m).z - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz));
                        int i_55_ = ((Medium) ((StageMaker) this).m).cy + (int) ((float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy) - (float) (i_54_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy));
                        int i_56_ = ((Medium) ((StageMaker) this).m).cz + (int) ((float) (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).y - ((Medium) ((StageMaker) this).m).y - ((Medium) ((StageMaker) this).m).cy) * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).zy) + (float) (i_54_ - ((Medium) ((StageMaker) this).m).cz) * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).zy));
                        int i_57_ = xs(i_53_, i_56_);
                        int i_58_ = ys(i_55_, i_56_);
                        ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                        ((StageMaker) this).rd.fillRect(i_57_, i_58_, 90, 88);
                        ((StageMaker) this).rd.setColor(new Color(138, 147, 160));
                        ((StageMaker) this).rd.drawRect(i_57_, i_58_, 90, 88);
                        if (button("   Edit   ", i_57_ + 45, i_58_ + 22, 3, false)) {
                            copyesp(true);
                            removesp();
                            ((StageMaker) this).lxm = 0;
                            ((StageMaker) this).lym = 0;
                            ((StageMaker) this).cntout = 2;
                            ((StageMaker) this).epart = false;
                        }
                        if (button(" Remove ", i_57_ + 45, i_58_ + 49, 3, false)) {
                            removesp();
                            ((StageMaker) this).esp = -1;
                            ((StageMaker) this).mouses = 0;
                        }
                        if (button("  Copy  ", i_57_ + 45, i_58_ + 76, 3, false)) {
                            copyesp(false);
                            ((StageMaker) this).lxm = 0;
                            ((StageMaker) this).lym = 0;
                            ((StageMaker) this).cntout = 2;
                            ((StageMaker) this).epart = false;
                        }
                        ((StageMaker) this).rd.setColor(new Color(255, 0, 0));
                        ((StageMaker) this).rd.drawString("x", i_57_ + 82, i_58_ - 2);
                        if (((StageMaker) this).xm > 248 && ((StageMaker) this).xm < 762 && ((StageMaker) this).ym > 63 && ((StageMaker) this).ym < 517 && ((StageMaker) this).mouses == 1 && (((StageMaker) this).xm < i_57_ || ((StageMaker) this).xm > i_57_ + 90 || ((StageMaker) this).ym < i_58_ || ((StageMaker) this).ym > i_58_ + 88)) {
                            ((StageMaker) this).esp = -1;
                            ((StageMaker) this).mouses = 0;
                        }
                    } else
                        ((StageMaker) this).esp = -1;
                }
                ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                ((StageMaker) this).rd.fillRect(248, 25, 514, 38);
                ((StageMaker) this).rd.fillRect(0, 25, 248, 530);
                ((StageMaker) this).rd.fillRect(248, 517, 514, 38);
                ((StageMaker) this).rd.fillRect(762, 25, 38, 530);
                if (((StageMaker) this).sptyp == 6) {
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).rd.drawString("Radius:", 11, 97);
                    ((StageMaker) this).rd.drawString("Height:", 14, 117);
                    boolean bool = false;
                    if (((StageMaker) this).xm > 57 && ((StageMaker) this).xm < 204 && ((StageMaker) this).ym > 90 && ((StageMaker) this).ym < 99)
                        bool = true;
                    ((StageMaker) this).rd.setColor(new Color(136, 148, 170));
                    if (bool || ((StageMaker) this).mouseon == 1) {
                        ((StageMaker) this).rd.drawRect(57, 90, 147, 8);
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    }
                    ((StageMaker) this).rd.drawLine(57, 94, 204, 94);
                    if (((StageMaker) this).mouseon == 1) {
                        ((StageMaker) this).pwd = (float) (((StageMaker) this).xm - 57) / 36.75F + 2.0F;
                        if (((StageMaker) this).pwd < 2.0F)
                            ((StageMaker) this).pwd = 2.0F;
                        if (((StageMaker) this).pwd > 6.0F)
                            ((StageMaker) this).pwd = 6.0F;
                    }
                    ((StageMaker) this).rd.drawRect((int) (57.0F + (((StageMaker) this).pwd - 2.0F) * 36.75F), 90, 2, 8);
                    boolean bool_59_ = false;
                    if (((StageMaker) this).xm > 57 && ((StageMaker) this).xm < 204 && ((StageMaker) this).ym > 110 && ((StageMaker) this).ym < 119)
                        bool_59_ = true;
                    ((StageMaker) this).rd.setColor(new Color(136, 148, 170));
                    if (bool_59_ || ((StageMaker) this).mouseon == 2) {
                        ((StageMaker) this).rd.drawRect(57, 110, 147, 8);
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    }
                    ((StageMaker) this).rd.drawLine(57, 114, 204, 114);
                    if (((StageMaker) this).mouseon == 2) {
                        ((StageMaker) this).phd = (float) (((StageMaker) this).xm - 57) / 36.75F + 2.0F;
                        if (((StageMaker) this).phd < 2.0F)
                            ((StageMaker) this).phd = 2.0F;
                        if (((StageMaker) this).phd > 6.0F)
                            ((StageMaker) this).phd = 6.0F;
                    }
                    ((StageMaker) this).rd.drawRect((int) (57.0F + (((StageMaker) this).phd - 2.0F) * 36.75F), 110, 2, 8);
                    if (((StageMaker) this).mouses == 1) {
                        if (bool)
                            ((StageMaker) this).mouseon = 1;
                        if (bool_59_)
                            ((StageMaker) this).mouseon = 2;
                    } else {
                        if (((StageMaker) this).mouseon == 1 || ((StageMaker) this).mouseon == 2)
                            ((StageMaker) this).pgen = false;
                        ((StageMaker) this).mouseon = -1;
                    }
                }
                int i_60_ = 0;
                if (((StageMaker) this).xm > 482 && ((StageMaker) this).xm < 529 && ((StageMaker) this).ym > 35 && ((StageMaker) this).ym < 61 || ((StageMaker) this).up) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).up)
                        ((StageMaker) this).sz += 500;
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).su[i_60_], 482, 35, null);
                i_60_ = 0;
                if (((StageMaker) this).xm > 482 && ((StageMaker) this).xm < 529 && ((StageMaker) this).ym > 519 && ((StageMaker) this).ym < 545 || ((StageMaker) this).down) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).down)
                        ((StageMaker) this).sz -= 500;
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).sd[i_60_], 482, 519, null);
                i_60_ = 0;
                if (((StageMaker) this).xm > 220 && ((StageMaker) this).xm < 246 && ((StageMaker) this).ym > 264 && ((StageMaker) this).ym < 311 || ((StageMaker) this).left) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).left)
                        ((StageMaker) this).sx -= 500;
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).sl[i_60_], 220, 264, null);
                i_60_ = 0;
                if (((StageMaker) this).xm > 764 && ((StageMaker) this).xm < 790 && ((StageMaker) this).ym > 264 && ((StageMaker) this).ym < 311 || ((StageMaker) this).right) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).right)
                        ((StageMaker) this).sx += 500;
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).sr[i_60_], 764, 264, null);
                i_60_ = 0;
                if (((StageMaker) this).xm > 616 && ((StageMaker) this).xm < 677 && ((StageMaker) this).ym > 30 && ((StageMaker) this).ym < 61 || ((StageMaker) this).zoomi) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).zoomi) {
                        ((StageMaker) this).sy += 500;
                        if (((StageMaker) this).sy > -2500)
                            ((StageMaker) this).sy = -2500;
                    }
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).zi[i_60_], 616, 30, null);
                i_60_ = 0;
                if (((StageMaker) this).xm > 690 && ((StageMaker) this).xm < 751 && ((StageMaker) this).ym > 30 && ((StageMaker) this).ym < 61 || ((StageMaker) this).zoomo) {
                    i_60_ = 1;
                    if (((StageMaker) this).mouses == 1 || ((StageMaker) this).zoomo) {
                        ((StageMaker) this).sy -= 500;
                        if (((StageMaker) this).sy < -55000)
                            ((StageMaker) this).sy = -55000;
                    }
                }
                ((StageMaker) this).rd.drawImage(((StageMaker) this).zo[i_60_], 690, 30, null);
                if ((((StageMaker) this).epart || ((StageMaker) this).arrng) && ((StageMaker) this).sy < -36000)
                    ((StageMaker) this).sy = -36000;
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 11));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawString("Part Selection", 11, 47);
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                ((StageMaker) this).ptyp.move(10, 50);
                if (!((StageMaker) this).ptyp.isShowing()) {
                    ((StageMaker) this).ptyp.show();
                    ((StageMaker) this).ptyp.select(((StageMaker) this).sptyp);
                }
                if (((StageMaker) this).sptyp != ((StageMaker) this).ptyp.getSelectedIndex()) {
                    ((StageMaker) this).sptyp = ((StageMaker) this).ptyp.getSelectedIndex();
                    if (((StageMaker) this).sptyp == 0) {
                        partroads();
                        ((StageMaker) this).part.show();
                    }
                    if (((StageMaker) this).sptyp == 1) {
                        partramps();
                        ((StageMaker) this).part.show();
                    }
                    if (((StageMaker) this).sptyp == 2) {
                        partobst();
                        ((StageMaker) this).part.show();
                    }
                    if (((StageMaker) this).sptyp == 5) {
                        partrees();
                        ((StageMaker) this).part.show();
                    }
                    ((StageMaker) this).spart = 0;
                    ((StageMaker) this).part.select(((StageMaker) this).spart);
                    requestFocus();
                    ((StageMaker) this).fixh.setText("2000");
                    ((StageMaker) this).focuson = false;
                }
                ((StageMaker) this).part.move(10, 80);
                ((StageMaker) this).part.setSize(200, 21);
                if (((StageMaker) this).sptyp == 0 || ((StageMaker) this).sptyp == 1 || ((StageMaker) this).sptyp == 2 || ((StageMaker) this).sptyp == 5) {
                    if (!((StageMaker) this).part.isShowing()) {
                        ((StageMaker) this).part.show();
                        ((StageMaker) this).part.select(((StageMaker) this).spart);
                    }
                } else if (((StageMaker) this).part.isShowing())
                    ((StageMaker) this).part.hide();
                if (((StageMaker) this).spart != ((StageMaker) this).part.getSelectedIndex()) {
                    ((StageMaker) this).spart = ((StageMaker) this).part.getSelectedIndex();
                    ((StageMaker) this).focuson = false;
                }
                if (((StageMaker) this).sptyp == 3)
                    ((StageMaker) this).rd.drawString("Checkpoint", 110 - ((StageMaker) this).ftm.stringWidth("Checkpoint") / 2, 120);
                if (((StageMaker) this).sptyp == 4)
                    ((StageMaker) this).rd.drawString("Fixing Hoop", 110 - ((StageMaker) this).ftm.stringWidth("Fixing Hoop") / 2, 120);
                if (((StageMaker) this).lsp != ((StageMaker) this).sp) {
                    ((StageMaker) this).seq = 3;
                    ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                    ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                    ((StageMaker) this).lsp = ((StageMaker) this).sp;
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                }
                if (((StageMaker) this).xm > 10 && ((StageMaker) this).xm < 210 && ((StageMaker) this).ym > 130 && ((StageMaker) this).ym < 334) {
                    if (((StageMaker) this).seq >= 3) {
                        if (((StageMaker) this).seq == 20 || !((StageMaker) this).seqn) {
                            ((StageMaker) this).seq = 0;
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                        } else
                            ((StageMaker) this).seq++;
                    }
                    ((StageMaker) this).seqn = true;
                    ((StageMaker) this).rd.setColor(new Color(210, 210, 210));
                } else {
                    ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
                    ((StageMaker) this).seqn = false;
                }
                ((StageMaker) this).rd.fillRect(10, 130, 200, 200);
                if ((((StageMaker) this).sp == 30 || ((StageMaker) this).sp == 32 || ((StageMaker) this).sp == 54) && button("  Rearrange Checkpoints  >  ", 110, 315, 2, true)) {
                    ((StageMaker) this).mouses = 0;
                    ((StageMaker) this).epart = false;
                    if (!((StageMaker) this).arrng) {
                        ((StageMaker) this).arrcnt = 0;
                        for (int i_61_ = 0; i_61_ < ((StageMaker) this).nob; i_61_++) {
                            if (((ContO) ((StageMaker) this).co[i_61_]).colok == 30 || ((ContO) ((StageMaker) this).co[i_61_]).colok == 32 || ((ContO) ((StageMaker) this).co[i_61_]).colok == 54)
                                ((ContO) ((StageMaker) this).co[i_61_]).errd = false;
                        }
                        ((StageMaker) this).arrng = true;
                    } else
                        ((StageMaker) this).arrng = false;
                }
                if (((StageMaker) this).seqn && ((StageMaker) this).mouses == -1) {
                    if (((StageMaker) this).sp != 66) {
                        boolean bool = false;
                        if (((StageMaker) this).rot == 0 && !bool) {
                            ((StageMaker) this).rot = 90;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == 90 && !bool) {
                            ((StageMaker) this).rot = 180;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == 180 && !bool) {
                            ((StageMaker) this).rot = -90;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == -90 && !bool) {
                            ((StageMaker) this).rot = 0;
                            bool = true;
                        }
                        if (((StageMaker) this).sp == 30 || ((StageMaker) this).sp == 31 || ((StageMaker) this).sp == 32) {
                            if (((StageMaker) this).rot == -90)
                                ((StageMaker) this).rot = 90;
                            if (((StageMaker) this).rot == 180)
                                ((StageMaker) this).rot = 0;
                        }
                        ((StageMaker) this).seq = 5;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                        ((StageMaker) this).epart = false;
                        ((StageMaker) this).arrng = false;
                    } else {
                        ((StageMaker) this).pgen = false;
                        ((StageMaker) this).pwd = (float) (2L + Math.round(Math.random() * 4.0));
                        ((StageMaker) this).phd = (float) (2L + Math.round(Math.random() * 4.0));
                    }
                }
                if (((StageMaker) this).sp == 31) {
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Height:", 62, 280);
                    movefield(((StageMaker) this).fixh, 107, 266, 50, 20);
                    if (((StageMaker) this).fixh.hasFocus())
                        ((StageMaker) this).focuson = false;
                    if (!((StageMaker) this).fixh.isShowing())
                        ((StageMaker) this).fixh.show();
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 11));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("( Height off the ground... )", 110 - ((StageMaker) this).ftm.stringWidth("( Height off the ground... )") / 2, 300);
                    if (((StageMaker) this).fixh.getText().equals("")) {
                        ((StageMaker) this).fixh.setText("0");
                        ((StageMaker) this).fixh.select(0, 0);
                    }
                    try {
                        ((StageMaker) this).hf = Integer.valueOf(((StageMaker) this).fixh.getText()).intValue();
                        if (((StageMaker) this).hf > 8000) {
                            ((StageMaker) this).hf = 8000;
                            ((StageMaker) this).fixh.setText("8000");
                        }
                    } catch (Exception exception) {
                        ((StageMaker) this).hf = 2000;
                        ((StageMaker) this).fixh.setText("2000");
                    }
                } else if (((StageMaker) this).fixh.isShowing())
                    ((StageMaker) this).fixh.hide();
                ((Medium) ((StageMaker) this).m).trk = 2;
                ((Medium) ((StageMaker) this).m).zy = 90;
                ((Medium) ((StageMaker) this).m).xz = 0;
                ((Medium) ((StageMaker) this).m).iw = 10;
                ((Medium) ((StageMaker) this).m).w = 210;
                ((Medium) ((StageMaker) this).m).ih = 130;
                ((Medium) ((StageMaker) this).m).h = 330;
                ((Medium) ((StageMaker) this).m).cx = 110;
                ((Medium) ((StageMaker) this).m).cy = 230;
                ((Medium) ((StageMaker) this).m).x = -110;
                ((Medium) ((StageMaker) this).m).z = -230;
                ((Medium) ((StageMaker) this).m).y = -15000;
                if (((StageMaker) this).sptyp == 1 && ((StageMaker) this).sp != 20 && ((StageMaker) this).sp != 21 && ((StageMaker) this).sp != 43 && ((StageMaker) this).sp != 45)
                    ((Medium) ((StageMaker) this).m).y = -10000;
                if (((StageMaker) this).sptyp == 2 && ((StageMaker) this).sp != 41)
                    ((Medium) ((StageMaker) this).m).y = -7600;
                if (((StageMaker) this).sptyp == 3 || ((StageMaker) this).sptyp == 4)
                    ((Medium) ((StageMaker) this).m).y = -5000;
                if (((StageMaker) this).sptyp == 5) {
                    ((Medium) ((StageMaker) this).m).y = -3000;
                    ((Medium) ((StageMaker) this).m).z = 150;
                }
                if (((StageMaker) this).sptyp == 6)
                    ((Medium) ((StageMaker) this).m).y = -7600;
                if (((StageMaker) this).sp == 31) {
                    ((Medium) ((StageMaker) this).m).z = -500;
                    if (((StageMaker) this).rot != 0)
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).roted = true;
                    else
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).roted = false;
                }
                ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).x = 0;
                ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).y = 0;
                ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).z = 0;
                ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xz = ((StageMaker) this).rot + ((StageMaker) this).adrot;
                ((StageMaker) this).bco[((StageMaker) this).sp].d(((StageMaker) this).rd);
                int i_62_ = 1;
                if (((StageMaker) this).sptyp == 0 || ((StageMaker) this).sptyp == 1) {
                    if (((StageMaker) this).sp != 26 && ((StageMaker) this).sp != 20) {
                        if (((StageMaker) this).rot == -90 || ((StageMaker) this).rot == 0)
                            i_62_ = -1;
                    } else {
                        if (((StageMaker) this).sp == 26 && (((StageMaker) this).rot == -90 || ((StageMaker) this).rot == 180))
                            i_62_ = -1;
                        if (((StageMaker) this).sp == 20 && (((StageMaker) this).rot == 90 || ((StageMaker) this).rot == 180))
                            i_62_ = -1;
                    }
                    if (((StageMaker) this).seq == 2) {
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy -= 5 * i_62_;
                        if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy == 0)
                            ((StageMaker) this).seq = 3;
                    }
                    if (((StageMaker) this).seq == 1)
                        ((StageMaker) this).seq = 2;
                    if (((StageMaker) this).seq == 0) {
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy += 5 * i_62_;
                        if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy == 85 * i_62_)
                            ((StageMaker) this).seq = 1;
                    }
                }
                if (((StageMaker) this).sptyp == 2 || ((StageMaker) this).sptyp == 3 || ((StageMaker) this).sptyp == 4 || ((StageMaker) this).sptyp == 6) {
                    if (((StageMaker) this).rot == -90 || ((StageMaker) this).rot == 180)
                        i_62_ = -1;
                    if (((StageMaker) this).seq == 2) {
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy += 5 * i_62_;
                        if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy == 0)
                            ((StageMaker) this).seq = 3;
                    }
                    if (((StageMaker) this).seq == 1)
                        ((StageMaker) this).seq = 2;
                    if (((StageMaker) this).seq == 0) {
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy -= 5 * i_62_;
                        if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy == -(85 * i_62_))
                            ((StageMaker) this).seq = 1;
                    }
                }
                if (((StageMaker) this).sptyp == 5) {
                    if (((StageMaker) this).rot == -90 || ((StageMaker) this).rot == 180)
                        i_62_ = -1;
                    boolean bool = false;
                    if (((StageMaker) this).rot == -90 || ((StageMaker) this).rot == 90)
                        bool = true;
                    if (!bool)
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                    else
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                    if (((StageMaker) this).seq == 2) {
                        if (!bool) {
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy += 5 * i_62_;
                            if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy == 0)
                                ((StageMaker) this).seq = 3;
                        } else {
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy -= 5 * i_62_;
                            if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy == 0)
                                ((StageMaker) this).seq = 3;
                        }
                    }
                    if (((StageMaker) this).seq == 1)
                        ((StageMaker) this).seq = 2;
                    if (((StageMaker) this).seq == 0) {
                        if (!bool) {
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy -= 5 * i_62_;
                            if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy == -(85 * i_62_))
                                ((StageMaker) this).seq = 1;
                        } else {
                            ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy += 5 * i_62_;
                            if (((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy == 85 * i_62_)
                                ((StageMaker) this).seq = 1;
                        }
                    }
                }
                if (((StageMaker) this).sp != 66) {
                    if (button("  Rotate  ", 110, 348, 3, true)) {
                        boolean bool = false;
                        if (((StageMaker) this).rot == 0 && !bool) {
                            ((StageMaker) this).rot = 90;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == 90 && !bool) {
                            ((StageMaker) this).rot = 180;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == 180 && !bool) {
                            ((StageMaker) this).rot = -90;
                            bool = true;
                        }
                        if (((StageMaker) this).rot == -90 && !bool) {
                            ((StageMaker) this).rot = 0;
                            bool = true;
                        }
                        if (((StageMaker) this).sp == 30 || ((StageMaker) this).sp == 31 || ((StageMaker) this).sp == 32) {
                            if (((StageMaker) this).rot == -90)
                                ((StageMaker) this).rot = 90;
                            if (((StageMaker) this).rot == 180)
                                ((StageMaker) this).rot = 0;
                        }
                        ((StageMaker) this).seq = 3;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).xy = 0;
                        ((ContO) ((StageMaker) this).bco[((StageMaker) this).sp]).zy = 0;
                        ((StageMaker) this).epart = false;
                        ((StageMaker) this).arrng = false;
                    }
                } else if (button("  Generate New  ", 110, 348, 3, true)) {
                    ((StageMaker) this).pgen = false;
                    ((StageMaker) this).pwd = (float) (2L + Math.round(Math.random() * 4.0));
                    ((StageMaker) this).phd = (float) (2L + Math.round(Math.random() * 4.0));
                }
                if (button(">", 191, 348, 3, true) && (((StageMaker) this).sptyp == 0 || ((StageMaker) this).sptyp == 1 || ((StageMaker) this).sptyp == 2 || ((StageMaker) this).sptyp == 5)) {
                    ((StageMaker) this).spart++;
                    if (((StageMaker) this).spart == ((StageMaker) this).part.getItemCount())
                        ((StageMaker) this).spart = 0;
                    ((StageMaker) this).part.select(((StageMaker) this).spart);
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                }
                if (button("<", 28, 348, 3, true) && (((StageMaker) this).sptyp == 0 || ((StageMaker) this).sptyp == 1 || ((StageMaker) this).sptyp == 2 || ((StageMaker) this).sptyp == 5)) {
                    ((StageMaker) this).spart--;
                    if (((StageMaker) this).spart == -1)
                        ((StageMaker) this).spart = ((StageMaker) this).part.getItemCount() - 1;
                    ((StageMaker) this).part.select(((StageMaker) this).spart);
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                }
                if (button("   <  Undo   ", 204, 404, 0, true)) {
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                    if (((StageMaker) this).nundo > 0) {
                        ((StageMaker) this).nundo--;
                        ((StageMaker) this).bstage = ((StageMaker) this).undos[((StageMaker) this).nundo];
                        readstage(0);
                    }
                }
                if (button("   Remove / Edit  Part   ", 172, 454, 0, true)) {
                    if (!((StageMaker) this).epart)
                        ((StageMaker) this).epart = true;
                    else
                        ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                    ((StageMaker) this).esp = -1;
                }
                if (button("   Go to >  Startline   ", 175, 504, 0, true)) {
                    ((StageMaker) this).sx = 0;
                    ((StageMaker) this).sz = 1500;
                }
                if (button(" About Part ", 164, 66, 3, false))
                    JOptionPane.showMessageDialog(null, ((StageMaker) this).discp[((StageMaker) this).sp], "Stage Maker", 1);
                if (button("  Keyboard Controls  ", 691, 536, 3, false))
                    JOptionPane.showMessageDialog(null, "Instead of clicking the triangular buttons around the Building Area to scroll, you can use:\n[ Keyboard Arrows ]\n\nYou can also zoom in and out using the following keys:\n[+] & [-]  or  [8] & [2]  or  [Enter] & [Backspace]\n\n", "Stage Maker", 1);
                if (button("  Save  ", 280, 50, 0, false)) {
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                    savefile();
                }
                if (button("  Save & Preview  ", 380, 50, 0, false)) {
                    ((StageMaker) this).epart = false;
                    ((StageMaker) this).arrng = false;
                    savefile();
                    hidefields();
                    ((StageMaker) this).tab = 2;
                }
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                boolean bool = false;
                int i_63_ = 0;
                int i_64_ = (int) ((float) ((StageMaker) this).xnob / 10000.0F * 200.0F); //limits
                int i_65_ = i_64_;
                int i_66_ = (int) ((float) ((Trackers) ((StageMaker) this).t).nt / 6700000.0F * 200.0F); //limits
                if (i_66_ > i_65_) {
                    i_65_ = i_66_;
                    i_63_ = 1;
                }
                int i_67_ = (int) ((float) ((CheckPoints) ((StageMaker) this).cp).n / 10000.0F * 200.0F); //limits
                if (i_67_ > i_65_) {
                    i_65_ = i_67_;
                    i_63_ = 2;
                }
                int i_68_ = (int) ((float) (((Medium) ((StageMaker) this).m).nrw * ((Medium) ((StageMaker) this).m).ncl) / 9999999.0F * 200.0F); //medium limit...does it exist?
                if (i_68_ > i_65_) {
                    i_65_ = i_68_;
                    i_63_ = 3;
                }
                if (i_65_ > 200) //may be a limit
                    i_65_ = 200;
                if (i_65_ <= 100)
                    ((StageMaker) this).rd.setColor(new Color(100 + i_65_, 225, 30));
                else
                    ((StageMaker) this).rd.setColor(new Color(200, 325 - i_65_, 30));
                ((StageMaker) this).rd.fillRect(167, 531, i_65_, 9);
                if (button("Memory Consumption :", 85, 540, 3, false))
                    JOptionPane.showMessageDialog(null, new StringBuilder().append("Memory Consumption Details\n\nNumber of Parts:  ").append(i_64_ / 2).append(" %\nPart's Details:  ").append(i_66_ / 2).append(" %\nRoad Points:  ").append(i_67_ / 2).append(" %\nStage Area:  ").append(i_68_ / 2).append(" %\n \n").toString(), "Stage Maker", 1);
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawRect(167, 531, 200, 9);
                String[] strings = { "Number of Parts", "Part's Details", "Road Points", "Stage Area" };
                ((StageMaker) this).rd.drawString(strings[i_63_], 267 - ((StageMaker) this).ftm.stringWidth(strings[i_63_]) / 2, 540);
                ((StageMaker) this).rd.drawString(new StringBuilder().append("").append(i_65_ / 2).append(" %  used").toString(), 375, 540);
                if (((StageMaker) this).overcan)
                    ((StageMaker) this).overcan = false;
                if (((StageMaker) this).epart) {
                    if (((StageMaker) this).esp == -1) {
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString("Click on any part to Edit >", 257, 454);
                        if (button(" Cancel ", 323, 474, 4, false))
                            ((StageMaker) this).epart = false;
                    }
                } else {
                    if (((StageMaker) this).hi != -1)
                        ((StageMaker) this).hi = -1;
                    if (((StageMaker) this).esp != -1)
                        ((StageMaker) this).esp = -1;
                }
                if (((StageMaker) this).arrng) {
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString(new StringBuilder().append("Click on Checkpoint NO# ").append(((StageMaker) this).arrcnt + 1).append("  >").toString(), 257, 80);
                    if (button(" Cancel ", 330, 100, 4, false))
                        ((StageMaker) this).arrng = false;
                    if (((StageMaker) this).arrcnt == ((CheckPoints) ((StageMaker) this).cp).nsp) {
                        sortstage();
                        JOptionPane.showMessageDialog(null, "Checkpoints Arranged!\nPress Save and Test Drive to check the new checkpoint order.\n", "Stage Maker", 1);
                        ((StageMaker) this).arrng = false;
                    }
                } else if (((StageMaker) this).chi != -1)
                    ((StageMaker) this).chi = -1;
            }
            if (((StageMaker) this).tab == 2) {
                if (((StageMaker) this).tabed != ((StageMaker) this).tab) {
                    ((Medium) ((StageMaker) this).m).trk = 0;
                    readstage(1);
                    setCursor(new Cursor(0));
                    ((StageMaker) this).setcur = false;
                    ((StageMaker) this).vxz = 0;
                    ((StageMaker) this).vx = ((StageMaker) this).sx - 400;
                    ((StageMaker) this).vz = ((StageMaker) this).sz - ((Medium) ((StageMaker) this).m).cz - 8000;
                    ((StageMaker) this).vy = -1500;
                    ((StageMaker) this).dtabed = -1;
                }
                ((Medium) ((StageMaker) this).m).trk = 0;
                ((Medium) ((StageMaker) this).m).zy = 6;
                ((Medium) ((StageMaker) this).m).iw = 10;
                ((Medium) ((StageMaker) this).m).w = 790;
                ((Medium) ((StageMaker) this).m).ih = 35;
                ((Medium) ((StageMaker) this).m).h = 445;
                ((Medium) ((StageMaker) this).m).cx = 400;
                ((Medium) ((StageMaker) this).m).cy = 215;
                ((Medium) ((StageMaker) this).m).xz = ((StageMaker) this).vxz;
                ((Medium) ((StageMaker) this).m).x = ((StageMaker) this).vx;
                ((Medium) ((StageMaker) this).m).z = ((StageMaker) this).vz;
                ((Medium) ((StageMaker) this).m).y = ((StageMaker) this).vy;
                ((StageMaker) this).m.d(((StageMaker) this).rd);
                int i = 0;
                int[] is = new int[10000]; // stageselect limit
                for (int i_69_ = 0; i_69_ < ((StageMaker) this).nob; i_69_++) {
                    if (((ContO) ((StageMaker) this).co[i_69_]).dist != 0) {
                        is[i] = i_69_;
                        i++;
                    } else
                        ((StageMaker) this).co[i_69_].d(((StageMaker) this).rd);
                }
                int[] is_70_ = new int[i];
                for (int i_71_ = 0; i_71_ < i; i_71_++)
                    is_70_[i_71_] = 0;
                for (int i_72_ = 0; i_72_ < i; i_72_++) {
                    for (int i_73_ = i_72_ + 1; i_73_ < i; i_73_++) {
                        if (((ContO) ((StageMaker) this).co[is[i_72_]]).dist != ((ContO) ((StageMaker) this).co[is[i_73_]]).dist) {
                            if (((ContO) ((StageMaker) this).co[is[i_72_]]).dist < ((ContO) ((StageMaker) this).co[is[i_73_]]).dist)
                                is_70_[i_72_]++;
                            else
                                is_70_[i_73_]++;
                        } else if (i_73_ > i_72_)
                            is_70_[i_72_]++;
                        else
                            is_70_[i_73_]++;
                    }
                }
                for (int i_74_ = 0; i_74_ < i; i_74_++) {
                    for (int i_75_ = 0; i_75_ < i; i_75_++) {
                        if (is_70_[i_75_] == i_74_) {
                            if (is[i_75_] == ((StageMaker) this).hi)
                                ((Medium) ((StageMaker) this).m).trk = 3;
                            ((StageMaker) this).co[is[i_75_]].d(((StageMaker) this).rd);
                            if (((Medium) ((StageMaker) this).m).trk == 3)
                                ((Medium) ((StageMaker) this).m).trk = 2;
                        }
                    }
                }
                if (((StageMaker) this).up) {
                    ((StageMaker) this).vz += 500.0F * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz);
                    ((StageMaker) this).vx += 500.0F * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz);
                }
                if (((StageMaker) this).down) {
                    ((StageMaker) this).vz -= 500.0F * ((StageMaker) this).m.cos(((Medium) ((StageMaker) this).m).xz);
                    ((StageMaker) this).vx -= 500.0F * ((StageMaker) this).m.sin(((Medium) ((StageMaker) this).m).xz);
                }
                if (((StageMaker) this).left)
                    ((StageMaker) this).vxz -= 5;
                if (((StageMaker) this).right)
                    ((StageMaker) this).vxz += 5;
                if (((StageMaker) this).zoomi) {
                    ((StageMaker) this).vy += 100;
                    if (((StageMaker) this).vy > -500)
                        ((StageMaker) this).vy = -500;
                }
                if (((StageMaker) this).zoomo) {
                    ((StageMaker) this).vy -= 100;
                    if (((StageMaker) this).vy < -5000)
                        ((StageMaker) this).vy = -5000;
                }
                ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                ((StageMaker) this).rd.fillRect(0, 25, 10, 525);
                ((StageMaker) this).rd.fillRect(790, 25, 10, 525);
                ((StageMaker) this).rd.fillRect(10, 25, 780, 10);
                ((StageMaker) this).rd.fillRect(10, 445, 780, 105);
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                String[] strings = { "Controls", "Atmosphere", "Colors", "Scenery", "Laps", "Sound Track", "Test Drive" };
                int[] is_76_ = { 10, 10, 121, 111 };
                int[] is_77_ = { 425, 445, 445, 425 };
                for (int i_78_ = 0; i_78_ < 7; i_78_++) {
                    ((StageMaker) this).rd.setColor(new Color(170, 170, 170));
                    if (((StageMaker) this).xm > is_76_[0] && ((StageMaker) this).xm < is_76_[3] && ((StageMaker) this).ym > 425 && ((StageMaker) this).ym < 445)
                        ((StageMaker) this).rd.setColor(new Color(190, 190, 190));
                    if (((StageMaker) this).dtab == i_78_)
                        ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                    ((StageMaker) this).rd.fillPolygon(is_76_, is_77_, 4);
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString(strings[i_78_], i_78_ * 111 + 62 - ((StageMaker) this).ftm.stringWidth(strings[i_78_]) / 2, 439);
                    if (((StageMaker) this).xm > is_76_[0] && ((StageMaker) this).xm < is_76_[3] && ((StageMaker) this).ym > 425 && ((StageMaker) this).ym < 445 && ((StageMaker) this).mouses == -1 && ((StageMaker) this).mouseon == -1)
                        ((StageMaker) this).dtab = i_78_;
                    for (int i_79_ = 0; i_79_ < 4; i_79_++)
                        is_76_[i_79_] += 111;
                }
                if (((StageMaker) this).tabed == ((StageMaker) this).tab && ((StageMaker) this).dtab != ((StageMaker) this).dtabed) {
                    if (!((StageMaker) this).ttstage.equals("")) {
                        ((StageMaker) this).tstage = ((StageMaker) this).ttstage;
                        ((StageMaker) this).ttstage = "";
                    }
                    readstage(1);
                    hidefields();
                }
                if (((StageMaker) this).dtab == 0) {
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Use the [ Keyboard Arrows ] to navigate through the stage.", 20, 470);
                    ((StageMaker) this).rd.drawString("[Left] & [Right] arrows are for rotating.  [Up] & [Down] arrows are for moving forwards and backwards.", 20, 490);
                    ((StageMaker) this).rd.drawString("For moving vertically down and up use the following keys:  [+] & [-]  or  [8] & [2]  or  [Enter] & [Backspace]", 20, 520);
                }
                if (((StageMaker) this).dtab == 2) {
                    if (((StageMaker) this).dtabed != ((StageMaker) this).dtab) {
                        Color.RGBtoHSB(((StageMaker) this).csky[0], ((StageMaker) this).csky[1], ((StageMaker) this).csky[2], ((StageMaker) this).hsb[0]);
                        Color.RGBtoHSB(((StageMaker) this).cfade[0], ((StageMaker) this).cfade[1], ((StageMaker) this).cfade[2], ((StageMaker) this).hsb[1]);
                        Color.RGBtoHSB(((StageMaker) this).cgrnd[0], ((StageMaker) this).cgrnd[1], ((StageMaker) this).cgrnd[2], ((StageMaker) this).hsb[2]);
                        for (int i_80_ = 0; i_80_ < 3; i_80_++) {
                            float f = ((StageMaker) this).hsb[i_80_][1];
                            ((StageMaker) this).hsb[i_80_][1] = ((StageMaker) this).hsb[i_80_][2];
                            ((StageMaker) this).hsb[i_80_][2] = f;
                        }
                        if (((StageMaker) this).hsb[1][1] == (((StageMaker) this).hsb[0][1] + ((StageMaker) this).hsb[2][1]) / 2.0F && ((StageMaker) this).hsb[1][0] == ((StageMaker) this).hsb[2][0] && ((StageMaker) this).hsb[1][2] == ((StageMaker) this).hsb[2][2])
                            ((StageMaker) this).pfog.setState(true);
                        else
                            ((StageMaker) this).pfog.setState(false);
                        ((StageMaker) this).ttstage = "";
                        ((StageMaker) this).mouseon = -1;
                    }
                    if (((StageMaker) this).mouses != 1) {
                        if ((((StageMaker) this).mouseon >= 6 || ((StageMaker) this).mouseon < 3) && ((StageMaker) this).mouseon != -1) {
                            if (((StageMaker) this).ttstage.equals(""))
                                ((StageMaker) this).ttstage = ((StageMaker) this).tstage;
                            sortop();
                            readstage(1);
                        }
                        ((StageMaker) this).mouseon = -1;
                    }
                    String[] strings_81_ = { "Sky", "Dust / Fog", "Ground" };
                    for (int i_82_ = 0; i_82_ < 3; i_82_++) {
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString(strings_81_[i_82_], 107 + 195 * i_82_ - ((StageMaker) this).ftm.stringWidth(strings_81_[i_82_]) / 2, 461);
                        for (int i_83_ = 0; i_83_ < 150; i_83_++) {
                            ((StageMaker) this).rd.setColor(Color.getHSBColor((float) ((double) (float) i_83_ * 0.006667), 1.0F, 1.0F));
                            ((StageMaker) this).rd.drawLine(32 + i_83_ + 195 * i_82_, 467, 32 + i_83_ + 195 * i_82_, 474);
                        }
                        for (int i_84_ = 0; i_84_ < 150; i_84_++) {
                            ((StageMaker) this).rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.5F + (float) i_84_ * 0.00333F));
                            ((StageMaker) this).rd.drawLine(32 + i_84_ + 195 * i_82_, 483, 32 + i_84_ + 195 * i_82_, 490);
                        }
                        for (int i_85_ = 0; i_85_ < 150; i_85_++) {
                            ((StageMaker) this).rd.setColor(Color.getHSBColor(((StageMaker) this).hsb[i_82_][0], 0.0F + (float) ((double) (float) i_85_ * 0.001667), ((StageMaker) this).hsb[i_82_][1]));
                            ((StageMaker) this).rd.drawLine(32 + i_85_ + 195 * i_82_, 499, 32 + i_85_ + 195 * i_82_, 506);
                        }
                        for (int i_86_ = 0; i_86_ < 3; i_86_++) {
                            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                            float f = ((StageMaker) this).hsb[i_82_][i_86_] * 150.0F;
                            if (i_86_ == 1) {
                                float f_87_ = 0.75F;
                                if (i_82_ == 0)
                                    f_87_ = 0.85F;
                                if (i_82_ == 1)
                                    f_87_ = 0.8F;
                                f = (((StageMaker) this).hsb[i_82_][i_86_] - f_87_) / 0.001F;
                            }
                            if (i_86_ == 2)
                                f = ((StageMaker) this).hsb[i_82_][i_86_] * 600.0F;
                            if (f < 0.0F)
                                f = 0.0F;
                            if (f > 150.0F)
                                f = 150.0F;
                            ((StageMaker) this).rd.drawLine((int) ((float) (32 + 195 * i_82_) + f), 467 + i_86_ * 16, (int) ((float) (32 + 195 * i_82_) + f), 474 + i_86_ * 16);
                            ((StageMaker) this).rd.drawLine((int) ((float) (33 + 195 * i_82_) + f), 467 + i_86_ * 16, (int) ((float) (33 + 195 * i_82_) + f), 474 + i_86_ * 16);
                            ((StageMaker) this).rd.fillRect((int) ((float) (31 + 195 * i_82_) + f), 475 + i_86_ * 16, 4, 2);
                            ((StageMaker) this).rd.drawLine((int) ((float) (30 + 195 * i_82_) + f), 477 + i_86_ * 16, (int) ((float) (35 + 195 * i_82_) + f), 477 + i_86_ * 16);
                            if (((StageMaker) this).xm > 29 + 195 * i_82_ && ((StageMaker) this).xm < 185 + 195 * i_82_ && ((StageMaker) this).ym > 468 + i_86_ * 16 && ((StageMaker) this).ym < 477 + i_86_ * 16 && ((StageMaker) this).mouses == 1 && ((StageMaker) this).mouseon == -1)
                                ((StageMaker) this).mouseon = i_86_ + i_82_ * 3;
                            if (((StageMaker) this).mouseon == i_86_ + i_82_ * 3) {
                                if (i_86_ == 0)
                                    ((StageMaker) this).hsb[i_82_][i_86_] = (float) (((StageMaker) this).xm - (32 + 195 * i_82_)) / 150.0F;
                                if (i_86_ == 1) {
                                    float f_88_ = 0.75F;
                                    if (i_82_ == 0)
                                        f_88_ = 0.85F;
                                    if (i_82_ == 1)
                                        f_88_ = 0.8F;
                                    ((StageMaker) this).hsb[i_82_][i_86_] = f_88_ + (float) (((StageMaker) this).xm - (32 + 195 * i_82_)) * 0.001F;
                                    if (((StageMaker) this).hsb[i_82_][i_86_] < f_88_)
                                        ((StageMaker) this).hsb[i_82_][i_86_] = f_88_;
                                    if (((StageMaker) this).hsb[i_82_][i_86_] > f_88_ + 0.15F)
                                        ((StageMaker) this).hsb[i_82_][i_86_] = f_88_ + 0.15F;
                                }
                                if (i_86_ == 2) {
                                    ((StageMaker) this).hsb[i_82_][i_86_] = (float) (((StageMaker) this).xm - (32 + 195 * i_82_)) / 600.0F;
                                    if ((double) ((StageMaker) this).hsb[i_82_][i_86_] > 0.25)
                                        ((StageMaker) this).hsb[i_82_][i_86_] = 0.25F;
                                }
                                if (((StageMaker) this).hsb[i_82_][i_86_] > 1.0F)
                                    ((StageMaker) this).hsb[i_82_][i_86_] = 1.0F;
                                if (((StageMaker) this).hsb[i_82_][i_86_] < 0.0F)
                                    ((StageMaker) this).hsb[i_82_][i_86_] = 0.0F;
                            }
                        }
                    }
                    movefield(((StageMaker) this).pfog, 258, 511, 200, 23);
                    if (!((StageMaker) this).pfog.isShowing())
                        ((StageMaker) this).pfog.show();
                    if (((StageMaker) this).pfog.getState()) {
                        ((StageMaker) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.fillRect(215, 464, 175, 47);
                        ((StageMaker) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                        ((StageMaker) this).hsb[1][1] = (((StageMaker) this).hsb[0][1] + ((StageMaker) this).hsb[2][1]) / 2.0F;
                        ((StageMaker) this).hsb[1][0] = ((StageMaker) this).hsb[2][0];
                        ((StageMaker) this).hsb[1][2] = ((StageMaker) this).hsb[2][2];
                    }
                    Color color = Color.getHSBColor(((StageMaker) this).hsb[0][0], ((StageMaker) this).hsb[0][2], ((StageMaker) this).hsb[0][1]);
                    ((StageMaker) this).m.setsky(color.getRed(), color.getGreen(), color.getBlue());
                    ((StageMaker) this).csky[0] = color.getRed();
                    ((StageMaker) this).csky[1] = color.getGreen();
                    ((StageMaker) this).csky[2] = color.getBlue();
                    color = Color.getHSBColor(((StageMaker) this).hsb[1][0], ((StageMaker) this).hsb[1][2], ((StageMaker) this).hsb[1][1]);
                    ((StageMaker) this).m.setfade(color.getRed(), color.getGreen(), color.getBlue());
                    ((StageMaker) this).cfade[0] = color.getRed();
                    ((StageMaker) this).cfade[1] = color.getGreen();
                    ((StageMaker) this).cfade[2] = color.getBlue();
                    color = Color.getHSBColor(((StageMaker) this).hsb[2][0], ((StageMaker) this).hsb[2][2], ((StageMaker) this).hsb[2][1]);
                    ((StageMaker) this).m.setgrnd(color.getRed(), color.getGreen(), color.getBlue());
                    ((StageMaker) this).cgrnd[0] = color.getRed();
                    ((StageMaker) this).cgrnd[1] = color.getGreen();
                    ((StageMaker) this).cgrnd[2] = color.getBlue();
                    if (button(" Reset ", 650, 510, 0, true)) {
                        if (!((StageMaker) this).ttstage.equals("")) {
                            ((StageMaker) this).tstage = ((StageMaker) this).ttstage;
                            ((StageMaker) this).ttstage = "";
                        }
                        readstage(1);
                        ((StageMaker) this).dtabed = -2;
                    }
                    if (button("        Save        ", 737, 510, 0, true)) {
                        sortop();
                        ((StageMaker) this).ttstage = "";
                        savefile();
                    }
                }
                if (((StageMaker) this).dtab == 3) {
                    if (((StageMaker) this).dtabed != ((StageMaker) this).dtab) {
                        Color.RGBtoHSB(((StageMaker) this).cldd[0], ((StageMaker) this).cldd[1], ((StageMaker) this).cldd[2], ((StageMaker) this).hsb[0]);
                        Color.RGBtoHSB(((StageMaker) this).texture[0], ((StageMaker) this).texture[1], ((StageMaker) this).texture[2], ((StageMaker) this).hsb[1]);
                        ((StageMaker) this).mgen.setText(new StringBuilder().append("").append(((Medium) ((StageMaker) this).m).mgen).append("").toString());
                        ((StageMaker) this).mouseon = -1;
                        ((StageMaker) this).ttstage = "";
                    }
                    if (((StageMaker) this).mouses != 1) {
                        if (((StageMaker) this).mouseon == 0 || ((StageMaker) this).mouseon == 1 || ((StageMaker) this).mouseon == 2 || ((StageMaker) this).mouseon == 6) {
                            if (((StageMaker) this).ttstage.equals(""))
                                ((StageMaker) this).ttstage = ((StageMaker) this).tstage;
                            sortop();
                            readstage(1);
                        }
                        ((StageMaker) this).mouseon = -1;
                    }
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Clouds", 32, 461);
                    for (int i_89_ = 0; i_89_ < 150; i_89_++) {
                        ((StageMaker) this).rd.setColor(Color.getHSBColor((float) i_89_ * 0.006667F, 1.0F, 1.0F));
                        ((StageMaker) this).rd.drawLine(32 + i_89_ + 0, 467, 32 + i_89_ + 0, 474);
                    }
                    for (int i_90_ = 0; i_90_ < 150; i_90_++) {
                        ((StageMaker) this).rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.75F + (float) i_90_ * 0.001667F));
                        ((StageMaker) this).rd.drawLine(32 + i_90_ + 0, 483, 32 + i_90_ + 0, 490);
                    }
                    for (int i_91_ = 0; i_91_ < 150; i_91_++) {
                        ((StageMaker) this).rd.setColor(Color.getHSBColor(((StageMaker) this).hsb[0][0], (float) i_91_ * 0.003333F, ((StageMaker) this).hsb[0][2]));
                        ((StageMaker) this).rd.drawLine(32 + i_91_ + 0, 499, 32 + i_91_ + 0, 506);
                    }
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 11));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Blend:", 32, 529);
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.fillRect(70, 522, 112, 2);
                    ((StageMaker) this).rd.fillRect(70, 528, 112, 2);
                    float f = 0.0F;
                    int i_92_ = 255;
                    for (int i_93_ = 0; i_93_ < 112; i_93_++) {
                        i_92_ = (int) (255.0F / (f + 1.0F));
                        if (i_92_ > 255)
                            i_92_ = 255;
                        if (i_92_ < 0)
                            i_92_ = 0;
                        f += 0.02F;
                        ((StageMaker) this).rd.setColor(new Color(i_92_, i_92_, i_92_));
                        ((StageMaker) this).rd.drawLine(70 + i_93_, 524, 70 + i_93_, 527);
                    }
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Height", 202 - ((StageMaker) this).ftm.stringWidth("Height") / 2, 461);
                    ((StageMaker) this).rd.drawLine(202, 467, 202, 530);
                    for (int i_94_ = 0; i_94_ < 8; i_94_++)
                        ((StageMaker) this).rd.drawLine(202, 466 + i_94_ * 8, 202 + (8 - i_94_), 466 + i_94_ * 8);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Ground Texture", 257, 471);
                    for (int i_95_ = 0; i_95_ < 150; i_95_++) {
                        ((StageMaker) this).rd.setColor(Color.getHSBColor((float) i_95_ * 0.006667F, 1.0F, 1.0F));
                        ((StageMaker) this).rd.drawLine(32 + i_95_ + 225, 477, 32 + i_95_ + 225, 484);
                    }
                    for (int i_96_ = 0; i_96_ < 150; i_96_++) {
                        ((StageMaker) this).rd.setColor(Color.getHSBColor(((StageMaker) this).hsb[1][0], (float) i_96_ * 0.006667F, (float) i_96_ * 0.006667F));
                        ((StageMaker) this).rd.drawLine(32 + i_96_ + 225, 493, 32 + i_96_ + 225, 500);
                    }
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 11));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Blend:", 257, 523);
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.fillRect(295, 516, 112, 2);
                    ((StageMaker) this).rd.fillRect(295, 522, 112, 2);
                    f = 0.0F;
                    i_92_ = 255;
                    for (int i_97_ = 0; i_97_ < 112; i_97_++) {
                        i_92_ = (int) (255.0F / (f + 1.0F));
                        if (i_92_ > 255)
                            i_92_ = 255;
                        if (i_92_ < 0)
                            i_92_ = 0;
                        f += 0.02F;
                        ((StageMaker) this).rd.setColor(new Color(i_92_, i_92_, i_92_));
                        ((StageMaker) this).rd.drawLine(70 + i_97_ + 225, 518, 70 + i_97_ + 225, 521);
                    }
                    for (int i_98_ = 0; i_98_ < 2; i_98_++) {
                        int i_99_ = 3;
                        if (i_98_ == 1)
                            i_99_ = 2;
                        for (int i_100_ = 0; i_100_ < i_99_; i_100_++) {
                            int i_101_ = i_100_;
                            if (i_100_ == 1)
                                i_101_ = 2;
                            if (i_100_ == 2)
                                i_101_ = 1;
                            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                            float f_102_ = ((StageMaker) this).hsb[i_98_][i_101_] * 150.0F;
                            if (i_100_ == 1 && i_98_ == 0) {
                                float f_103_ = 0.75F;
                                f_102_ = (((StageMaker) this).hsb[i_98_][i_101_] - f_103_) / 0.001667F;
                            }
                            if (i_100_ == 2 && i_98_ == 0)
                                f_102_ = ((StageMaker) this).hsb[i_98_][i_101_] / 0.003333F;
                            if (f_102_ < 0.0F)
                                f_102_ = 0.0F;
                            if (f_102_ > 150.0F)
                                f_102_ = 150.0F;
                            ((StageMaker) this).rd.drawLine((int) ((float) (32 + 225 * i_98_) + f_102_), 467 + i_100_ * 16 + 10 * i_98_, (int) ((float) (32 + 225 * i_98_) + f_102_), 474 + i_100_ * 16 + 10 * i_98_);
                            ((StageMaker) this).rd.drawLine((int) ((float) (33 + 225 * i_98_) + f_102_), 467 + i_100_ * 16 + 10 * i_98_, (int) ((float) (33 + 225 * i_98_) + f_102_), 474 + i_100_ * 16 + 10 * i_98_);
                            ((StageMaker) this).rd.fillRect((int) ((float) (31 + 225 * i_98_) + f_102_), 475 + i_100_ * 16 + 10 * i_98_, 4, 2);
                            ((StageMaker) this).rd.drawLine((int) ((float) (30 + 225 * i_98_) + f_102_), 477 + i_100_ * 16 + 10 * i_98_, (int) ((float) (35 + 225 * i_98_) + f_102_), 477 + i_100_ * 16 + 10 * i_98_);
                            if (((StageMaker) this).xm > 29 + 225 * i_98_ && ((StageMaker) this).xm < 185 + 225 * i_98_ && ((StageMaker) this).ym > 468 + i_100_ * 16 + 10 * i_98_ && ((StageMaker) this).ym < 477 + i_100_ * 16 + 10 * i_98_ && ((StageMaker) this).mouses == 1 && ((StageMaker) this).mouseon == -1)
                                ((StageMaker) this).mouseon = i_100_ + i_98_ * 3;
                            if (((StageMaker) this).mouseon == i_100_ + i_98_ * 3) {
                                ((StageMaker) this).hsb[i_98_][i_101_] = (float) (((StageMaker) this).xm - (32 + 225 * i_98_)) * 0.006667F;
                                if (i_100_ == 1 && i_98_ == 1) {
                                    ((StageMaker) this).hsb[i_98_][1] = (float) (((StageMaker) this).xm - (32 + 225 * i_98_)) * 0.006667F;
                                    if (((StageMaker) this).hsb[i_98_][1] > 1.0F)
                                        ((StageMaker) this).hsb[i_98_][1] = 1.0F;
                                    if (((StageMaker) this).hsb[i_98_][1] < 0.0F)
                                        ((StageMaker) this).hsb[i_98_][1] = 0.0F;
                                }
                                if (i_100_ == 1 && i_98_ == 0) {
                                    float f_104_ = 0.75F;
                                    ((StageMaker) this).hsb[i_98_][i_101_] = f_104_ + (float) (((StageMaker) this).xm - (32 + 225 * i_98_)) * 0.001667F;
                                    if (((StageMaker) this).hsb[i_98_][i_101_] < f_104_)
                                        ((StageMaker) this).hsb[i_98_][i_101_] = f_104_;
                                }
                                if (i_100_ == 2 && i_98_ == 0) {
                                    ((StageMaker) this).hsb[i_98_][i_101_] = (float) (((StageMaker) this).xm - (32 + 225 * i_98_)) * 0.003333F;
                                    if ((double) ((StageMaker) this).hsb[i_98_][i_101_] > 0.5)
                                        ((StageMaker) this).hsb[i_98_][i_101_] = 0.5F;
                                }
                                if (((StageMaker) this).hsb[i_98_][i_101_] > 1.0F)
                                    ((StageMaker) this).hsb[i_98_][i_101_] = 1.0F;
                                if (((StageMaker) this).hsb[i_98_][i_101_] < 0.0F)
                                    ((StageMaker) this).hsb[i_98_][i_101_] = 0.0F;
                            }
                        }
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        float f_105_ = (float) (((StageMaker) this).texture[3] - 20) * 2.8F;
                        if (i_98_ == 0)
                            f_105_ = (float) ((StageMaker) this).cldd[3] * 11.2F;
                        if (f_105_ < 0.0F)
                            f_105_ = 0.0F;
                        if (f_105_ > 112.0F)
                            f_105_ = 112.0F;
                        ((StageMaker) this).rd.drawLine((int) ((float) (70 + 225 * i_98_) + f_105_), 522 - 6 * i_98_, (int) ((float) (70 + 225 * i_98_) + f_105_), 529 - 6 * i_98_);
                        ((StageMaker) this).rd.drawLine((int) ((float) (71 + 225 * i_98_) + f_105_), 522 - 6 * i_98_, (int) ((float) (71 + 225 * i_98_) + f_105_), 529 - 6 * i_98_);
                        ((StageMaker) this).rd.fillRect((int) ((float) (69 + 225 * i_98_) + f_105_), 530 - 6 * i_98_, 4, 2);
                        ((StageMaker) this).rd.drawLine((int) ((float) (68 + 225 * i_98_) + f_105_), 532 - 6 * i_98_, (int) ((float) (73 + 225 * i_98_) + f_105_), 532 - 6 * i_98_);
                        if (((StageMaker) this).xm > 67 + 225 * i_98_ && ((StageMaker) this).xm < 185 + 225 * i_98_ && ((StageMaker) this).ym > 522 - 6 * i_98_ && ((StageMaker) this).ym < 532 - 6 * i_98_ && ((StageMaker) this).mouses == 1 && ((StageMaker) this).mouseon == -1)
                            ((StageMaker) this).mouseon = 6 + i_98_;
                    }
                    if (((StageMaker) this).mouseon == 6) {
                        ((StageMaker) this).cldd[3] = (int) ((float) (((StageMaker) this).xm - 70) / 11.2F);
                        if (((StageMaker) this).cldd[3] < 0)
                            ((StageMaker) this).cldd[3] = 0;
                        if (((StageMaker) this).cldd[3] > 10)
                            ((StageMaker) this).cldd[3] = 10;
                    }
                    if (((StageMaker) this).mouseon == 7) {
                        ((StageMaker) this).texture[3] = (int) ((double) (((StageMaker) this).xm - 70 - 225) / 2.8 + 20.0);
                        if (((StageMaker) this).texture[3] < 20)
                            ((StageMaker) this).texture[3] = 20;
                        if (((StageMaker) this).texture[3] > 60)
                            ((StageMaker) this).texture[3] = 60;
                    }
                    ((StageMaker) this).rd.setColor(new Color(0, 128, 255));
                    float f_106_ = (float) (1500 - Math.abs(((StageMaker) this).cldd[4])) / 15.625F;
                    if (f_106_ > 64.0F)
                        f_106_ = 64.0F;
                    if (f_106_ < 0.0F)
                        f_106_ = 0.0F;
                    ((StageMaker) this).rd.drawRect(199, (int) (465.0F + f_106_), 12, 2);
                    if (((StageMaker) this).xm > 197 && ((StageMaker) this).xm < 213 && ((StageMaker) this).ym > 463 && ((StageMaker) this).ym < 533 && ((StageMaker) this).mouses == 1 && ((StageMaker) this).mouseon == -1)
                        ((StageMaker) this).mouseon = 8;
                    if (((StageMaker) this).mouseon == 8) {
                        ((StageMaker) this).cldd[4] = -(int) ((float) (530 - ((StageMaker) this).ym) * 15.625F + 500.0F);
                        if (((StageMaker) this).cldd[4] > -500)
                            ((StageMaker) this).cldd[4] = -500;
                        if (((StageMaker) this).cldd[4] < -1500)
                            ((StageMaker) this).cldd[4] = -1500;
                    }
                    Color color = Color.getHSBColor(((StageMaker) this).hsb[0][0], ((StageMaker) this).hsb[0][1], ((StageMaker) this).hsb[0][2]);
                    ((StageMaker) this).m.setcloads(color.getRed(), color.getGreen(), color.getBlue(), ((StageMaker) this).cldd[3], ((StageMaker) this).cldd[4]);
                    ((StageMaker) this).cldd[0] = color.getRed();
                    ((StageMaker) this).cldd[1] = color.getGreen();
                    ((StageMaker) this).cldd[2] = color.getBlue();
                    color = Color.getHSBColor(((StageMaker) this).hsb[1][0], ((StageMaker) this).hsb[1][1], ((StageMaker) this).hsb[1][2]);
                    ((StageMaker) this).m.setexture(color.getRed(), color.getGreen(), color.getBlue(), ((StageMaker) this).texture[3]);
                    ((StageMaker) this).texture[0] = color.getRed();
                    ((StageMaker) this).texture[1] = color.getGreen();
                    ((StageMaker) this).texture[2] = color.getBlue();
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Mountains", 452, 465);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 11));
                    ((StageMaker) this).rd.drawString("Mountain Generator Key:", 452, 480);
                    movefield(((StageMaker) this).mgen, 452, 484, 120, 20);
                    if (((StageMaker) this).mgen.hasFocus())
                        ((StageMaker) this).focuson = false;
                    if (!((StageMaker) this).mgen.isShowing())
                        ((StageMaker) this).mgen.show();
                    if (button("  Generate New  ", 512, 525, 3, true)) {
                        ((Medium) ((StageMaker) this).m).mgen = (int) (Math.random() * 100000.0);
                        ((StageMaker) this).mgen.setText(new StringBuilder().append("").append(((Medium) ((StageMaker) this).m).mgen).append("").toString());
                        if (((StageMaker) this).ttstage.equals(""))
                            ((StageMaker) this).ttstage = ((StageMaker) this).tstage;
                        sortop();
                        readstage(1);
                    }
                    if (!((StageMaker) this).mgen.getText().equals(new StringBuilder().append("").append(((Medium) ((StageMaker) this).m).mgen).append("").toString())) {
                        try {
                            int i_107_ = Integer.valueOf(((StageMaker) this).mgen.getText()).intValue();
                            ((Medium) ((StageMaker) this).m).mgen = i_107_;
                            if (((StageMaker) this).ttstage.equals(""))
                                ((StageMaker) this).ttstage = ((StageMaker) this).tstage;
                            sortop();
                            readstage(1);
                        } catch (Exception exception) {
                            ((StageMaker) this).mgen.setText(new StringBuilder().append("").append(((Medium) ((StageMaker) this).m).mgen).append("").toString());
                        }
                    }
                    if (button(" Reset ", 650, 510, 0, true)) {
                        if (!((StageMaker) this).ttstage.equals("")) {
                            ((StageMaker) this).tstage = ((StageMaker) this).ttstage;
                            ((StageMaker) this).ttstage = "";
                        }
                        readstage(1);
                        ((StageMaker) this).dtabed = -2;
                    }
                    if (button("        Save        ", 737, 510, 0, true)) {
                        sortop();
                        ((StageMaker) this).ttstage = "";
                        savefile();
                    }
                }
                if (((StageMaker) this).dtab == 1) {
                    if (((StageMaker) this).dtabed != ((StageMaker) this).dtab) {
                        for (int i_108_ = 0; i_108_ < 3; i_108_++)
                            ((StageMaker) this).snap[i_108_] = (int) ((float) ((Medium) ((StageMaker) this).m).snap[i_108_] / 1.2F + 50.0F);
                        ((StageMaker) this).fogn[0] = (8 - ((((Medium) ((StageMaker) this).m).fogd + 1) / 2 - 1)) * 20;
                        ((StageMaker) this).fogn[1] = (((Medium) ((StageMaker) this).m).fade[0] - 5000) / 30;
                    }
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Atmosphere RGB Mask", 20, 461);
                    ((StageMaker) this).rd.setColor(new Color(128, 128, 128));
                    ((StageMaker) this).rd.drawLine(10, 457, 17, 457);
                    ((StageMaker) this).rd.drawLine(260, 457, 152, 457);
                    ((StageMaker) this).rd.drawLine(10, 457, 10, 546);
                    ((StageMaker) this).rd.drawLine(260, 457, 260, 527);
                    ((StageMaker) this).rd.drawLine(260, 527, 360, 527);
                    ((StageMaker) this).rd.drawLine(10, 546, 360, 546);
                    ((StageMaker) this).rd.drawLine(360, 527, 360, 546);
                    String[] strings_109_ = { "Red", "Green", "Blue" };
                    int[] is_110_ = { 32, 20, 29 };
                    int i_111_ = 38;
                    int i_112_ = -70;
                    for (int i_113_ = 0; i_113_ < 3; i_113_++) {
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString(new StringBuilder().append("").append(strings_109_[i_113_]).append(" :").toString(), is_110_[i_113_], 447 + i_113_ * 24 + i_111_);
                        ((StageMaker) this).rd.drawLine(140 + i_112_, 443 + (i_113_ * 24 + i_111_), 230 + i_112_, 443 + i_113_ * 24 + i_111_);
                        for (int i_114_ = 1; i_114_ < 10; i_114_++)
                            ((StageMaker) this).rd.drawLine(140 + 10 * i_114_ + i_112_, 443 - i_114_ + i_113_ * 24 + i_111_, 140 + 10 * i_114_ + i_112_, 443 + i_114_ + i_113_ * 24 + i_111_);
                        ((StageMaker) this).rd.setColor(new Color(255, 0, 0));
                        int i_115_ = (int) ((float) ((StageMaker) this).snap[i_113_] / 1.1111F / 10.0F);
                        ((StageMaker) this).rd.fillRect(138 + (int) ((float) ((StageMaker) this).snap[i_113_] / 1.1111F) + i_112_, 443 - i_115_ + i_113_ * 24 + i_111_, 5, i_115_ * 2 + 1);
                        ((StageMaker) this).rd.setColor(new Color(255, 128, 0));
                        ((StageMaker) this).rd.drawRect(139 + (int) ((float) ((StageMaker) this).snap[i_113_] / 1.1111F) + i_112_, 434 + i_113_ * 24 + i_111_, 2, 18);
                        if (button(" - ", 260 + i_112_, 447 + i_113_ * 24 + i_111_, 4, false)) {
                            ((StageMaker) this).snap[i_113_] -= 2;
                            if (((StageMaker) this).snap[i_113_] < 0)
                                ((StageMaker) this).snap[i_113_] = 0;
                        }
                        if (button(" + ", 300 + i_112_, 447 + i_113_ * 24 + i_111_, 4, false)) {
                            if (((StageMaker) this).snap[0] + ((StageMaker) this).snap[1] + ((StageMaker) this).snap[2] > 200) {
                                for (int i_116_ = 0; i_116_ < 3; i_116_++) {
                                    if (i_116_ != i_113_) {
                                        ((StageMaker) this).snap[i_116_]--;
                                        if (((StageMaker) this).snap[i_116_] < 0)
                                            ((StageMaker) this).snap[i_116_] = 0;
                                    }
                                }
                            }
                            ((StageMaker) this).snap[i_113_] += 2;
                            if (((StageMaker) this).snap[i_113_] > 100)
                                ((StageMaker) this).snap[i_113_] = 100;
                        }
                    }
                    if (((Medium) ((StageMaker) this).m).snap[0] != (int) ((float) ((StageMaker) this).snap[0] * 1.2F - 60.0F) || ((Medium) ((StageMaker) this).m).snap[1] != (int) ((float) ((StageMaker) this).snap[1] * 1.2F - 60.0F) || ((Medium) ((StageMaker) this).m).snap[2] != (int) ((float) ((StageMaker) this).snap[2] * 1.2F - 60.0F)) {
                        for (int i_117_ = 0; i_117_ < 3; i_117_++)
                            ((Medium) ((StageMaker) this).m).snap[i_117_] = (int) ((float) ((StageMaker) this).snap[i_117_] * 1.2F - 60.0F);
                        readstage(2);
                    }
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Car Lights :", 265, 541);
                    if (((StageMaker) this).snap[0] + ((StageMaker) this).snap[1] + ((StageMaker) this).snap[2] > 110) {
                        ((StageMaker) this).rd.drawString("Off", 335, 541);
                        ((Medium) ((StageMaker) this).m).lightson = false;
                    } else {
                        ((StageMaker) this).rd.setColor(new Color(0, 200, 0));
                        ((StageMaker) this).rd.drawString("On", 335, 541);
                        ((Medium) ((StageMaker) this).m).lightson = true;
                    }
                    int i_118_ = 33;
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Dust/Fog Properties", 280 + i_118_, 461);
                    ((StageMaker) this).rd.setColor(new Color(128, 128, 128));
                    ((StageMaker) this).rd.drawLine(270 + i_118_, 457, 277 + i_118_, 457);
                    ((StageMaker) this).rd.drawLine(540 + i_118_, 457, 393 + i_118_, 457);
                    ((StageMaker) this).rd.drawLine(270 + i_118_, 457, 270 + i_118_, 522);
                    ((StageMaker) this).rd.drawLine(540 + i_118_, 457, 540 + i_118_, 522);
                    ((StageMaker) this).rd.drawLine(270 + i_118_, 522, 540 + i_118_, 522);
                    String[] strings_119_ = { "Density", "Near / Far" };
                    int[] is_120_ = { 292 + i_118_, 280 + i_118_ };
                    int[] is_121_ = { 20, 10 };
                    i_111_ = 38;
                    i_112_ = 210 + i_118_;
                    for (int i_122_ = 0; i_122_ < 2; i_122_++) {
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString(new StringBuilder().append("").append(strings_119_[i_122_]).append(" :").toString(), is_120_[i_122_], 447 + i_122_ * 24 + i_111_);
                        ((StageMaker) this).rd.drawLine(140 + i_112_, 443 + (i_122_ * 24 + i_111_), 230 + i_112_, 443 + i_122_ * 24 + i_111_);
                        for (int i_123_ = 1; i_123_ < 10; i_123_++)
                            ((StageMaker) this).rd.drawLine(140 + 10 * i_123_ + i_112_, 443 - i_123_ + i_122_ * 24 + i_111_, 140 + 10 * i_123_ + i_112_, 443 + i_123_ + i_122_ * 24 + i_111_);
                        ((StageMaker) this).rd.setColor(new Color(255, 0, 0));
                        int i_124_ = (int) ((float) ((StageMaker) this).fogn[i_122_] / 1.1111F / 10.0F);
                        ((StageMaker) this).rd.fillRect(138 + (int) ((float) ((StageMaker) this).fogn[i_122_] / 1.1111F) + i_112_, 443 - i_124_ + i_122_ * 24 + i_111_, 5, i_124_ * 2 + 1);
                        ((StageMaker) this).rd.setColor(new Color(255, 128, 0));
                        ((StageMaker) this).rd.drawRect(139 + (int) ((float) ((StageMaker) this).fogn[i_122_] / 1.1111F) + i_112_, 434 + i_122_ * 24 + i_111_, 2, 18);
                        if (button(" - ", 260 + i_112_, 447 + i_122_ * 24 + i_111_, 4, false)) {
                            ((StageMaker) this).fogn[i_122_] -= is_121_[i_122_];
                            if (((StageMaker) this).fogn[i_122_] < 0)
                                ((StageMaker) this).fogn[i_122_] = 0;
                        }
                        if (button(" + ", 300 + i_112_, 447 + i_122_ * 24 + i_111_, 4, false)) {
                            ((StageMaker) this).fogn[i_122_] += is_121_[i_122_];
                            if (((StageMaker) this).fogn[i_122_] > 100)
                                ((StageMaker) this).fogn[i_122_] = 100;
                        }
                    }
                    ((Medium) ((StageMaker) this).m).fogd = (8 - ((StageMaker) this).fogn[0] / 20 + 1) * 2 - 1;
                    ((StageMaker) this).m.fadfrom(5000 + ((StageMaker) this).fogn[1] * 30);
                    ((StageMaker) this).origfade = ((Medium) ((StageMaker) this).m).fade[0];
                    if (button(" Reset ", 650, 510, 0, true))
                        ((StageMaker) this).dtabed = -2;
                    if (button("        Save        ", 737, 510, 0, true)) {
                        sortop();
                        savefile();
                    }
                }
                if (((StageMaker) this).dtab == 4) {
                    if (((StageMaker) this).dtabed != ((StageMaker) this).dtab && ((CheckPoints) ((StageMaker) this).cp).nlaps - 1 >= 0 && ((CheckPoints) ((StageMaker) this).cp).nlaps - 1 <= 14)
                        ((StageMaker) this).nlaps.select(((CheckPoints) ((StageMaker) this).cp).nlaps - 1);
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Set the number of laps for this stage:", 130, 496);
                    ((StageMaker) this).nlaps.move(348, 480);
                    if (!((StageMaker) this).nlaps.isShowing())
                        ((StageMaker) this).nlaps.show();
                    if (((CheckPoints) ((StageMaker) this).cp).nlaps != ((StageMaker) this).nlaps.getSelectedIndex() + 1) {
                        ((CheckPoints) ((StageMaker) this).cp).nlaps = ((StageMaker) this).nlaps.getSelectedIndex() + 1;
                        requestFocus();
                    }
                    if (button(" Reset ", 530, 496, 0, true))
                        ((StageMaker) this).dtabed = -2;
                    if (button("        Save        ", 617, 496, 0, true)) {
                        sortop();
                        savefile();
                    }
                }
                if (((StageMaker) this).dtab == 5) {
                    if (((StageMaker) this).dtabed != ((StageMaker) this).dtab) {
                        ((StageMaker) this).tracks.removeAll();
                        ((Smenu) ((StageMaker) this).tracks).maxl = 200;
                        ((StageMaker) this).tracks.add(((StageMaker) this).rd, "The Play List  -  MOD Tracks");
                        String[] strings_125_ = new File("mystages/mymusic/").list();
                        if (strings_125_ != null) {
                            for (int i_126_ = 0; i_126_ < strings_125_.length; i_126_++) {
                                if (strings_125_[i_126_].toLowerCase().endsWith(".zip"))
                                    ((StageMaker) this).tracks.add(((StageMaker) this).rd, strings_125_[i_126_].substring(0, strings_125_[i_126_].length() - 4));
                            }
                        }
                        if (((StageMaker) this).ltrackname.equals("")) {
                            if (((StageMaker) this).trackname.equals(""))
                                ((StageMaker) this).tracks.select(0);
                            else
                                ((StageMaker) this).tracks.select(((StageMaker) this).trackname);
                        } else
                            ((StageMaker) this).tracks.select(((StageMaker) this).ltrackname);
                        ((StageMaker) this).mouseon = -1;
                    }
                    ((StageMaker) this).tracks.move(10, 450);
                    if (((StageMaker) this).tracks.getWidth() != 200)
                        ((StageMaker) this).tracks.setSize(200, 21);
                    if (!((StageMaker) this).tracks.isShowing())
                        ((StageMaker) this).tracks.show();
                    if (((RadicalMod) ((StageMaker) this).track).playing && ((RadicalMod) ((StageMaker) this).track).loaded == 2) {
                        if (button("      Stop      ", 110, 495, 2, false))
                            ((StageMaker) this).track.stop();
                        if (!((StageMaker) this).ltrackname.equals(((StageMaker) this).tracks.getSelectedItem()))
                            ((StageMaker) this).track.stop();
                        if (((StageMaker) this).xm > 10 && ((StageMaker) this).xm < 210 && ((StageMaker) this).ym > 516 && ((StageMaker) this).ym < 534) {
                            if (((StageMaker) this).mouses == 1)
                                ((StageMaker) this).mouseon = 1;
                            ((StageMaker) this).rd.setColor(new Color(0, 164, 242));
                        } else
                            ((StageMaker) this).rd.setColor(new Color(120, 210, 255));
                        ((StageMaker) this).rd.drawRect(10, 516, 200, 18);
                        ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
                        ((StageMaker) this).rd.drawLine(10, 523, 210, 523);
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawLine(10, 524, 210, 524);
                        ((StageMaker) this).rd.drawLine(10, 525, 210, 525);
                        ((StageMaker) this).rd.drawLine(10, 526, 210, 526);
                        ((StageMaker) this).rd.setColor(new Color(255, 255, 255));
                        ((StageMaker) this).rd.drawLine(10, 527, 210, 527);
                        int i_127_ = (int) ((1.0F - (float) ((SuperClip) ((RadicalMod) ((StageMaker) this).track).sClip).stream.available() / (float) ((StageMaker) this).avon) * 200.0F);
                        if (((StageMaker) this).mouseon == 1) {
                            i_127_ = ((StageMaker) this).xm - 10;
                            if (i_127_ < 0)
                                i_127_ = 0;
                            if (i_127_ > 200)
                                i_127_ = 200;
                            if (((StageMaker) this).mouses != 1) {
                                ((SuperClip) ((RadicalMod) ((StageMaker) this).track).sClip).stream.reset();
                                ((SuperClip) ((RadicalMod) ((StageMaker) this).track).sClip).stream.skip((long) ((float) i_127_ / 200.0F * (float) ((StageMaker) this).avon));
                                ((StageMaker) this).mouseon = -1;
                            }
                        }
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawRect(8 + i_127_, 516, 4, 18);
                        ((StageMaker) this).rd.setColor(new Color(0, 164, 242));
                        ((StageMaker) this).rd.drawLine(10 + i_127_, 520, 10 + i_127_, 518);
                        ((StageMaker) this).rd.drawLine(10 + i_127_, 530, 10 + i_127_, 532);
                    } else if (((StageMaker) this).tracks.getSelectedIndex() != 0 && button("      Play  >      ", 110, 495, 2, false)) {
                        if (!((StageMaker) this).ltrackname.equals(((StageMaker) this).tracks.getSelectedItem())) {
                            ((StageMaker) this).track.unload();
                            ((StageMaker) this).track = new RadicalMod(new StringBuilder().append("mystages/mymusic/").append(((StageMaker) this).tracks.getSelectedItem()).append(".zip").toString(), 300, 8000, 125, true, false);
                            if (((RadicalMod) ((StageMaker) this).track).loaded == 2) {
                                ((StageMaker) this).avon = ((SuperClip) ((RadicalMod) ((StageMaker) this).track).sClip).stream.available();
                                ((StageMaker) this).ltrackname = ((StageMaker) this).tracks.getSelectedItem();
                            } else
                                ((StageMaker) this).ltrackname = "";
                        }
                        if (!((StageMaker) this).ltrackname.equals(""))
                            ((StageMaker) this).track.play();
                        else
                            JOptionPane.showMessageDialog(null, new StringBuilder().append("Failed to load '").append(((StageMaker) this).tracks.getSelectedItem()).append("', please make sure it is a valid MOD Track!").toString(), "Stage Maker", 1);
                    }
                    if (((StageMaker) this).tracks.getSelectedIndex() != 0) {
                        if (button("   Set as the stage's Sound Track  >   ", 330, 466, 2, false)) {
                            if (!((StageMaker) this).ltrackname.equals(((StageMaker) this).tracks.getSelectedItem())) {
                                ((StageMaker) this).track.unload();
                                ((StageMaker) this).track = new RadicalMod(new StringBuilder().append("mystages/mymusic/").append(((StageMaker) this).tracks.getSelectedItem()).append(".zip").toString(), 300, 8000, 125, true, false);
                                if (((RadicalMod) ((StageMaker) this).track).loaded == 2) {
                                    ((StageMaker) this).avon = ((SuperClip) ((RadicalMod) ((StageMaker) this).track).sClip).stream.available();
                                    ((StageMaker) this).ltrackname = ((StageMaker) this).tracks.getSelectedItem();
                                } else
                                    ((StageMaker) this).ltrackname = "";
                            }
                            if (!((StageMaker) this).ltrackname.equals("")) {
                                ((StageMaker) this).trackname = ((StageMaker) this).ltrackname;
                                ((StageMaker) this).trackvol = (int) (220.0F / ((float) ((RadicalMod) ((StageMaker) this).track).rvol / 3750.0F));
                                try {
                                    File file = new File(new StringBuilder().append("mystages/mymusic/").append(((StageMaker) this).trackname).append(".zip").toString());
                                    ((StageMaker) this).tracksize = (int) (file.length() / 1024L);
                                    if (((StageMaker) this).tracksize > 250) {
                                        JOptionPane.showMessageDialog(null, new StringBuilder().append("Cannot use '").append(((StageMaker) this).tracks.getSelectedItem()).append("' as the sound track!\nIts file size is bigger then 250KB.\n\n").toString(), "Stage Maker", 1);
                                        ((StageMaker) this).trackname = "";
                                    }
                                } catch (Exception exception) {
                                    ((StageMaker) this).tracksize = 111;
                                }
                            } else
                                JOptionPane.showMessageDialog(null, new StringBuilder().append("Failed to load '").append(((StageMaker) this).tracks.getSelectedItem()).append("', please make sure it is a valid MOD Track!").toString(), "Stage Maker", 1);
                        }
                        if (button("   X Delete   ", 258, 495, 2, false) && JOptionPane.showConfirmDialog(null, new StringBuilder().append("Are you sure you want to permanently delete this MOD Track from your Play List?\n\n").append(((StageMaker) this).tracks.getSelectedItem()).append("\n\n>  If you delete this Track from the Play List you will not be able to use it for other stages as well!     \n\n").toString(), "Stage Maker", 0) == 0)
                            deltrack();
                    }
                    if (button("   Add a new MOD Track from file . . .  ", 330, 530, 0, false) && JOptionPane.showConfirmDialog(null, "The game only accepts MOD format music files for the game ('.mod' file extension).\nA good place to find MOD Tracks is the modarchive.com, all the current MOD Tracks\nthat are distributed with the game are from the modarchive.com.\n\nTo find out more about MOD Tracks and to learn how to compose & remix your own\nmusic, please read the section of the Stage Maker help about it.\n\nThe MOD Track needs to be compressed in a zip file to be added here, please make\nsure the MOD Track you wish to add to your stages sound track play list is zipped before\nadding it here.\nThe ZIP file must also be less then 250KB in size.\n\nIs the track you are about to insert a MOD Track in a ZIP file that is less then 250KB?\n", "Stage Maker", 0) == 0) {
                        File file = null;
                        FileDialog filedialog = new FileDialog(new Frame(), "Stage Maker - Add MOD Track file to stage sound track play list!");
                        filedialog.setFile("*.zip");
                        filedialog.setMode(0);
                        filedialog.setVisible(true);
                        try {
                            if (filedialog.getFile() != null)
                                file = new File(new StringBuilder().append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString());
                        } catch (Exception exception) {
                            /* empty */
                        }
                        if (file != null) {
                            try {
                                if (file.length() / 1024L < 250L) {
                                    File file_128_ = new File("mystages/mymusic/");
                                    if (!file_128_.exists())
                                        file_128_.mkdirs();
                                    file_128_ = new File(new StringBuilder().append("mystages/mymusic/").append(file.getName()).append("").toString());
                                    FileInputStream fileinputstream = new FileInputStream(file);
                                    FileOutputStream fileoutputstream = new FileOutputStream(file_128_);
                                    byte[] is_129_ = new byte[1024];
                                    int i_130_;
                                    while ((i_130_ = fileinputstream.read(is_129_)) > 0)
                                    fileoutputstream.write(is_129_, 0, i_130_);
                                    fileinputstream.close();
                                    fileoutputstream.close();
                                    ((StageMaker) this).tracks.removeAll();
                                    ((StageMaker) this).tracks.add(((StageMaker) this).rd, "Select MOD Track                      ");
                                    String[] strings_131_ = new File("mystages/mymusic/").list();
                                    if (strings_131_ != null) {
                                        for (int i_132_ = 0; i_132_ < strings_131_.length; i_132_++) {
                                            if (strings_131_[i_132_].toLowerCase().endsWith(".zip"))
                                                ((StageMaker) this).tracks.add(((StageMaker) this).rd, strings_131_[i_132_].substring(0, strings_131_[i_132_].length() - 4));
                                        }
                                    }
                                    ((StageMaker) this).tracks.select(file.getName().substring(0, file.getName().length() - 4));
                                } else
                                    JOptionPane.showMessageDialog(null, "The selected file is larger then 250KB in size and therefore cannot be added!", "Stage Maker", 1);
                            } catch (Exception exception) {
                                JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to copy file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
                            }
                        }
                    }
                    int i_133_ = 200;
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Sound Track", 280 + i_133_, 461);
                    String string = ((StageMaker) this).trackname;
                    if (string.equals(""))
                        string = "No Sound Track set.";
                    else if (button("   <  Remove Track   ", 378, 495, 2, false))
                        ((StageMaker) this).trackname = "";
                    ((StageMaker) this).rd.drawString(string, 629 - ((StageMaker) this).ftm.stringWidth(string) / 2, 482);
                    ((StageMaker) this).rd.setColor(new Color(128, 128, 128));
                    ((StageMaker) this).rd.drawLine(270 + i_133_, 457, 277 + i_133_, 457);
                    ((StageMaker) this).rd.drawLine(589 + i_133_, 457, 353 + i_133_, 457);
                    ((StageMaker) this).rd.drawLine(270 + i_133_, 457, 270 + i_133_, 497);
                    ((StageMaker) this).rd.drawLine(589 + i_133_, 457, 589 + i_133_, 497);
                    ((StageMaker) this).rd.drawLine(270 + i_133_, 497, 589 + i_133_, 497);
                    if (button(" Reset ", 576, 530, 0, true)) {
                        ((StageMaker) this).ltrackname = "";
                        ((StageMaker) this).dtabed = -2;
                    }
                    if (button("        Save        ", 663, 530, 0, true)) {
                        sortop();
                        savefile();
                    }
                }
                if (((StageMaker) this).dtab == 6) {
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("Test Drive the Stage", 400 - ((StageMaker) this).ftm.stringWidth("Test Drive the Stage") / 2, 470);
                    ((StageMaker) this).witho.move(342, 480);
                    if (!((StageMaker) this).witho.isShowing())
                        ((StageMaker) this).witho.show();
                    if (button("     TEST DRIVE!     ", 400, 530, 0, true)) {
                        savefile();
                        ((StageMaker) this).errd = 0;
                        readstage(3);
                        if (((CheckPoints) ((StageMaker) this).cp).nsp < 2)
                            ((StageMaker) this).errd = 7;
                        if (((StageMaker) this).errd == 0) {
                            Madness.testcar = ((StageMaker) this).stagename;
                            Madness.testdrive = ((StageMaker) this).witho.getSelectedIndex() + 3;
                            Madness.game();
                        } else
                            JOptionPane.showMessageDialog(null, new StringBuilder().append("Error!  This stage is not ready for a test drive!\nReason:\n").append(((StageMaker) this).errlo[((StageMaker) this).errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                    }
                }
                if (((StageMaker) this).dtabed != ((StageMaker) this).dtab) {
                    if (((StageMaker) this).dtabed == -2)
                        ((StageMaker) this).dtabed = -1;
                    else
                        ((StageMaker) this).dtabed = ((StageMaker) this).dtab;
                }
            }
            if (((StageMaker) this).tab == 3) {
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawString(new StringBuilder().append("Publish Stage :  [ ").append(((StageMaker) this).stagename).append(" ]").toString(), 30, 50);
                ((StageMaker) this).rd.drawString("Publishing Type :", 30, 80);
                ((StageMaker) this).pubtyp.move(150, 63);
                if (!((StageMaker) this).pubtyp.isShowing()) {
                    ((StageMaker) this).pubtyp.show();
                    ((StageMaker) this).pubtyp.select(1);
                }
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
                if (((StageMaker) this).pubtyp.getSelectedIndex() == 0) {
                    ((StageMaker) this).rd.drawString("Private :  This means only you can have your stage in your account and no one else can add", 268, 72);
                    ((StageMaker) this).rd.drawString("it to their account to play it!", 268, 88);
                }
                if (((StageMaker) this).pubtyp.getSelectedIndex() == 1) {
                    ((StageMaker) this).rd.drawString("Public :  This means anyone can add this stage to their account to play it, but only you can", 268, 72);
                    ((StageMaker) this).rd.drawString("download it to your Stage Maker and edit it (no one else but you can edit it).", 268, 88);
                }
                if (((StageMaker) this).pubtyp.getSelectedIndex() == 2) {
                    ((StageMaker) this).rd.drawString("Super Public :  This means anyone can add this stage to their account to play it and can also", 268, 72);
                    ((StageMaker) this).rd.drawString("download it to their stage Maker, edit it and publish it.", 268, 88);
                }
                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                ((StageMaker) this).rd.drawString("Stage Name", 180 - ((StageMaker) this).ftm.stringWidth("Stage Name") / 2, 138);
                ((StageMaker) this).rd.drawString("Created By", 400 - ((StageMaker) this).ftm.stringWidth("Created By") / 2, 138);
                ((StageMaker) this).rd.drawString("Added By", 500 - ((StageMaker) this).ftm.stringWidth("Added By") / 2, 138);
                ((StageMaker) this).rd.drawString("Publish Type", 600 - ((StageMaker) this).ftm.stringWidth("Publish Type") / 2, 138);
                ((StageMaker) this).rd.drawString("Options", 720 - ((StageMaker) this).ftm.stringWidth("Options") / 2, 138);
                ((StageMaker) this).rd.drawLine(350, 129, 350, 140);
                ((StageMaker) this).rd.drawLine(450, 129, 450, 140);
                ((StageMaker) this).rd.drawLine(550, 129, 550, 140);
                ((StageMaker) this).rd.drawLine(650, 129, 650, 140);
                ((StageMaker) this).rd.drawRect(10, 140, 780, 402);
                if (button("       Publish  >       ", 102, 110, 0, true)) {
                    if (((StageMaker) this).logged == 0)
                        JOptionPane.showMessageDialog(null, "Please login to retrieve your account first before publishing!", "Stage Maker", 1);
                    if (((StageMaker) this).logged == 3 || ((StageMaker) this).logged == -1) {
                        savefile();
                        ((StageMaker) this).errd = 0;
                        readstage(3);
                        if (((CheckPoints) ((StageMaker) this).cp).nsp < 2)
                            ((StageMaker) this).errd = 7;
                        ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
                        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                        if (((StageMaker) this).ftm.stringWidth(((StageMaker) this).stagename) > 274)
                            ((StageMaker) this).errd = 8;
                        if (((StageMaker) this).errd == 0) {
                            int i = 0;
                            for (int i_134_ = 0; i_134_ < ((StageMaker) this).nms; i_134_++) {
                                if (((StageMaker) this).mystages[i_134_].equals(((StageMaker) this).stagename) && ((StageMaker) this).maker[i_134_].toLowerCase().equals(((StageMaker) this).tnick.getText().toLowerCase()))
                                    i = JOptionPane.showConfirmDialog(null, new StringBuilder().append("Replace your already online stage '").append(((StageMaker) this).stagename).append("' with this one?").toString(), "Stage Maker", 0);
                            }
                            if (i == 0) {
                                setCursor(new Cursor(3));
                                ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                                ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                                ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                                ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                ((StageMaker) this).rd.drawString("Connecting to Server...", 400 - ((StageMaker) this).ftm.stringWidth("Connecting to Server...") / 2, 250);
                                repaint();
                                int i_135_ = -1;
                                try {
                                    Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                                    BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                    PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                                    Object object = null;
                                    printwriter.println(new StringBuilder().append("20|").append(((StageMaker) this).tnick.getText()).append("|").append(((StageMaker) this).tpass.getText()).append("|").append(((StageMaker) this).stagename).append("|").append(((StageMaker) this).pubtyp.getSelectedIndex()).append("|").toString());
                                    String string = bufferedreader.readLine();
                                    if (string != null)
                                        i_135_ = servervalue(string, 0);
                                    if (i_135_ == 0) {
                                        String string_136_ = " Publishing Stage ";
                                        String string_137_ = new StringBuilder().append("").append(((StageMaker) this).tstage).append("\r\n").append(((StageMaker) this).bstage).append("").toString();
                                        DataInputStream datainputstream = new DataInputStream(new ByteArrayInputStream(string_137_.getBytes()));
                                        Object object_138_ = null;
                                        String string_139_;
                                        while ((string_139_ = datainputstream.readLine()) != null) {
                                            string_139_ = string_139_.trim();
                                            printwriter.println(string_139_);
                                            ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                                            ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                                            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                            ((StageMaker) this).rd.drawString(string_136_, 400 - ((StageMaker) this).ftm.stringWidth(string_136_) / 2, 250);
                                            string_136_ = new StringBuilder().append("| ").append(string_136_).append(" |").toString();
                                            if (string_136_.equals("| | | | | | | | | | | | | | | | | | | | | | | |  Publishing Stage  | | | | | | | | | | | | | | | | | | | | | | | |"))
                                                string_136_ = " Publishing Stage ";
                                            repaint();
                                            try {
                                                if (((StageMaker) this).thredo != null) {
                                                    /* empty */
                                                }
                                                Thread.sleep(10L);
                                            } catch (InterruptedException interruptedexception) {
                                                /* empty */
                                            }
                                        }
                                        printwriter.println("QUITX1111");
                                        ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                                        ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                        ((StageMaker) this).rd.drawString("Creating the stage online...", 400 - ((StageMaker) this).ftm.stringWidth("Creating the stage online...") / 2, 250);
                                        ((StageMaker) this).rd.drawString("This may take a couple of minutes, please wait...", 400 - ((StageMaker) this).ftm.stringWidth("This may take a couple of minutes, please wait...") / 2, 280);
                                        repaint();
                                        string = bufferedreader.readLine();
                                        if (string != null)
                                            i_135_ = servervalue(string, 0);
                                        else
                                            i_135_ = -1;
                                        if (i_135_ == 0) {
                                            ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                                            ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                                            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                            ((StageMaker) this).rd.drawString("Uploading stage's sound track...", 400 - ((StageMaker) this).ftm.stringWidth("Uploading Stage's Sound Track...") / 2, 250);
                                            ((StageMaker) this).rd.drawString("This may take a couple of minutes, please wait...", 400 - ((StageMaker) this).ftm.stringWidth("This may take a couple of minutes, please wait...") / 2, 280);
                                            repaint();
                                            File file = new File(new StringBuilder().append("mystages/mymusic/").append(((StageMaker) this).trackname).append(".zip").toString());
                                            if (!((StageMaker) this).trackname.equals("") && file.exists()) {
                                                int i_140_ = (int) file.length();
                                                printwriter.println(new StringBuilder().append("track|").append(((StageMaker) this).trackname).append("|").append(i_140_).append("|").toString());
                                                string = bufferedreader.readLine();
                                                if (string != null)
                                                    i_135_ = servervalue(string, 0);
                                                else
                                                    i_135_ = -2;
                                                if (i_135_ == 0) {
                                                    FileInputStream fileinputstream = new FileInputStream(file);
                                                    byte[] is = new byte[i_140_];
                                                    fileinputstream.read(is);
                                                    fileinputstream.close();
                                                    DataOutputStream dataoutputstream = new DataOutputStream(socket.getOutputStream());
                                                    dataoutputstream.write(is, 0, i_140_);
                                                    string = bufferedreader.readLine();
                                                    if (string != null)
                                                        i_135_ = servervalue(string, 0);
                                                    else
                                                        i_135_ = -2;
                                                }
                                                if (i_135_ == -67)
                                                    i_135_ = 0;
                                            } else {
                                                printwriter.println("END");
                                                string = bufferedreader.readLine();
                                            }
                                        }
                                    }
                                    socket.close();
                                } catch (Exception exception) {
                                    i_135_ = -1;
                                }
                                setCursor(new Cursor(0));
                                boolean bool = false;
                                if (i_135_ == 0) {
                                    ((StageMaker) this).logged = 1;
                                    bool = true;
                                }
                                if (i_135_ == 3) {
                                    JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to publish stage.\nReason:\n").append(((StageMaker) this).errlo[8]).append("\n\n").toString(), "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ == 4) {
                                    JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to publish stage.\nReason:\nStage name used (").append(((StageMaker) this).stagename).append(").\nThe name '").append(((StageMaker) this).stagename).append("' is already used by another published stage.\nPlease rename your stage.\n\n").toString(), "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ == 5) {
                                    JOptionPane.showMessageDialog(null, "Unable to create stage online!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ > 5) {
                                    JOptionPane.showMessageDialog(null, "Unable to publish stage fully!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ == -4) {
                                    ((StageMaker) this).logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!\nReason:\nAnother MOD Track is already uploaded with the same name, please rename your Track.\nOpen your 'mystages' folder then open 'mymusic' to find your MOD Track to rename it.\n\n", "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ == -3) {
                                    ((StageMaker) this).logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!\nReason:\nYour MOD Track\u2019s file size is too large, Track file size must be less then 250KB to be accepted.\n\n", "Stage Maker", 1);
                                    bool = true;
                                }
                                if (i_135_ == -2) {
                                    ((StageMaker) this).logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    bool = true;
                                }
                                if (!bool)
                                    JOptionPane.showMessageDialog(null, "Unable to publish stage!  Unknown Error.", "Stage Maker", 1);
                            }
                        } else
                            JOptionPane.showMessageDialog(null, new StringBuilder().append("Error!  This stage is not ready for publishing!\nReason:\n").append(((StageMaker) this).errlo[((StageMaker) this).errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                    }
                }
                if (((StageMaker) this).logged == 3) {
                    for (int i = 0; i < ((StageMaker) this).nms; i++) {
                        ((StageMaker) this).rd.setColor(new Color(235, 235, 235));
                        if (((StageMaker) this).xm > 11 && ((StageMaker) this).xm < 789 && ((StageMaker) this).ym > 142 + i * 20 && ((StageMaker) this).ym < 160 + i * 20)
                            ((StageMaker) this).rd.setColor(new Color(255, 255, 255));
                        ((StageMaker) this).rd.fillRect(11, 142 + i * 20, 778, 18);
                        ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
                        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString(((StageMaker) this).mystages[i], 180 - ((StageMaker) this).ftm.stringWidth(((StageMaker) this).mystages[i]) / 2, 156 + i * 20);
                        ((StageMaker) this).rd.setColor(new Color(155, 155, 155));
                        ((StageMaker) this).rd.drawLine(350, 145 + i * 20, 350, 157 + i * 20);
                        if (((StageMaker) this).pubt[i] != -1) {
                            ((StageMaker) this).rd.drawLine(450, 145 + i * 20, 450, 157 + i * 20);
                            ((StageMaker) this).rd.drawLine(550, 145 + i * 20, 550, 157 + i * 20);
                            ((StageMaker) this).rd.drawLine(650, 145 + i * 20, 650, 157 + i * 20);
                            boolean bool = false;
                            if (((StageMaker) this).maker[i].toLowerCase().equals(((StageMaker) this).tnick.getText().toLowerCase())) {
                                bool = true;
                                ((StageMaker) this).rd.setColor(new Color(0, 64, 0));
                                ((StageMaker) this).rd.drawString("You", 400 - ((StageMaker) this).ftm.stringWidth("You") / 2, 156 + i * 20);
                            } else {
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 64));
                                ((StageMaker) this).rd.drawString(((StageMaker) this).maker[i], 400 - ((StageMaker) this).ftm.stringWidth(((StageMaker) this).maker[i]) / 2, 156 + i * 20);
                            }
                            if (((StageMaker) this).nad[i] > 1) {
                                if (ovbutton(new StringBuilder().append("").append(((StageMaker) this).nad[i]).append(" Players").toString(), 500, 156 + i * 20)) {
                                    String string = new StringBuilder().append("[ ").append(((StageMaker) this).mystages[i]).append(" ]  has been added by the following players to their accounts:     \n\n").toString();
                                    int i_141_ = 0;
                                    for (int i_142_ = 0; i_142_ < ((StageMaker) this).nad[i]; i_142_++) {
                                        if (++i_141_ == 17) {
                                            string = new StringBuilder().append(string).append("\n").toString();
                                            i_141_ = 1;
                                        }
                                        string = new StringBuilder().append(string).append(((StageMaker) this).addeda[i][i_142_]).toString();
                                        if (i_142_ != ((StageMaker) this).nad[i] - 1) {
                                            if (i_142_ != ((StageMaker) this).nad[i] - 2)
                                                string = new StringBuilder().append(string).append(", ").toString();
                                            else if (i_141_ == 16) {
                                                string = new StringBuilder().append(string).append("\nand ").toString();
                                                i_141_ = 0;
                                            } else
                                                string = new StringBuilder().append(string).append(" and ").toString();
                                        }
                                    }
                                    string = new StringBuilder().append(string).append("\n \n \n").toString();
                                    JOptionPane.showMessageDialog(null, string, "Stage Maker", 1);
                                }
                            } else {
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 64));
                                ((StageMaker) this).rd.drawString("None", 500 - ((StageMaker) this).ftm.stringWidth("None") / 2, 156 + i * 20);
                            }
                            if (((StageMaker) this).pubt[i] == 0) {
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 64));
                                ((StageMaker) this).rd.drawString("Private", 600 - ((StageMaker) this).ftm.stringWidth("Private") / 2, 156 + i * 20);
                            }
                            if (((StageMaker) this).pubt[i] == 1) {
                                ((StageMaker) this).rd.setColor(new Color(0, 0, 64));
                                ((StageMaker) this).rd.drawString("Public", 600 - ((StageMaker) this).ftm.stringWidth("Public") / 2, 156 + i * 20);
                            }
                            if (((StageMaker) this).pubt[i] == 2) {
                                ((StageMaker) this).rd.setColor(new Color(0, 64, 0));
                                ((StageMaker) this).rd.drawString("Super Public", 600 - ((StageMaker) this).ftm.stringWidth("Super Public") / 2, 156 + i * 20);
                            }
                            if ((((StageMaker) this).pubt[i] == 2 || bool) && ovbutton("Download", 700, 156 + i * 20)) {
                                int i_143_ = 0;
                                for (int i_144_ = 0; i_144_ < ((StageMaker) this).slstage.getItemCount(); i_144_++) {
                                    if (((StageMaker) this).mystages[i].equals(((StageMaker) this).slstage.getItem(i_144_)))
                                        i_143_ = JOptionPane.showConfirmDialog(null, new StringBuilder().append("Replace the local ").append(((StageMaker) this).mystages[i]).append(" in your 'mystages' folder with the published online copy?").toString(), "Stage Maker", 0);
                                }
                                if (i_143_ == 0) {
                                    setCursor(new Cursor(3));
                                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                                    ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                                    ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                    ((StageMaker) this).rd.drawString("Downloading stage, please wait...", 400 - ((StageMaker) this).ftm.stringWidth("Downloading stage, please wait...") / 2, 250);
                                    repaint();
                                    try {
                                        String string = new StringBuilder().append("http://multiplayer.needformadness.com/tracks/").append(((StageMaker) this).mystages[i]).append(".radq?reqlo=").append((int) (Math.random() * 1000.0)).append("").toString();
                                        string = string.replace(' ', '_');
                                        URL url = new URL(string);
                                        int i_145_ = url.openConnection().getContentLength();
                                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                                        byte[] is = new byte[i_145_];
                                        datainputstream.readFully(is);
                                        datainputstream.close();
                                        ZipInputStream zipinputstream;
                                        if (is[0] == 80 && is[1] == 75 && is[2] == 3)
                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(is));
                                        else {
                                            byte[] is_146_ = new byte[i_145_ - 40];
                                            for (int i_147_ = 0; i_147_ < i_145_ - 40; i_147_++) {
                                                int i_148_ = 20;
                                                if (i_147_ >= 500)
                                                    i_148_ = 40;
                                                is_146_[i_147_] = is[i_147_ + i_148_];
                                            }
                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(is_146_));
                                        }
                                        ZipEntry zipentry = zipinputstream.getNextEntry();
                                        if (zipentry != null) {
                                            String string_149_ = "";
                                            int i_150_ = Integer.valueOf(zipentry.getName()).intValue();
                                            byte[] is_151_ = new byte[i_150_];
                                            int i_152_ = 0;
                                            int i_153_;
                                            for (/**/; i_150_ > 0; i_150_ -= i_153_) {
                                                i_153_ = zipinputstream.read(is_151_, i_152_, i_150_);
                                                i_152_ += i_153_;
                                            }
                                            String string_154_ = new String(is_151_);
                                            string_154_ = new StringBuilder().append(string_154_).append("\n").toString();
                                            String string_155_ = "";
                                            int i_156_ = 0;
                                            int i_157_ = string_154_.indexOf("\n", 0);
                                            while (i_157_ != -1 && i_156_ < string_154_.length()) {
                                                String string_158_ = string_154_.substring(i_156_, i_157_);
                                                string_158_ = string_158_.trim();
                                                i_156_ = i_157_ + 1;
                                                i_157_ = string_154_.indexOf("\n", i_156_);
                                                if (!string_158_.startsWith("stagemaker(") && !string_158_.startsWith("publish("))
                                                    string_155_ = new StringBuilder().append(string_155_).append("").append(string_158_).append("\r\n").toString();
                                                else {
                                                    string_155_ = string_155_.trim();
                                                    string_155_ = new StringBuilder().append(string_155_).append("\r\n").toString();
                                                }
                                                if (string_158_.startsWith("soundtrack"))
                                                    string_149_ = getstring("soundtrack", string_158_, 0);
                                            }
                                            string_155_ = string_155_.trim();
                                            string_155_ = new StringBuilder().append(string_155_).append("\r\n\r\n").toString();
                                            File file = new File("mystages/");
                                            if (!file.exists())
                                                file.mkdirs();
                                            file = new File(new StringBuilder().append("mystages/").append(((StageMaker) this).mystages[i]).append(".txt").toString());
                                            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                                            bufferedwriter.write(string_155_);
                                            bufferedwriter.close();
                                            Object object = null;
                                            zipinputstream.close();
                                            if (!string_149_.equals("")) {
                                                try {
                                                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                                                    ((StageMaker) this).rd.drawString("Downloading stage's sound track...", 400 - ((StageMaker) this).ftm.stringWidth("Downloading stage's sound track...") / 2, 280);
                                                    repaint();
                                                    string = new StringBuilder().append("http://multiplayer.needformadness.com/tracks/music/").append(string_149_).append(".zip").toString();
                                                    string = string.replace(' ', '_');
                                                    url = new URL(string);
                                                    i_145_ = url.openConnection().getContentLength();
                                                    file = new File(new StringBuilder().append("mystages/mymusic/").append(string_149_).append(".zip").toString());
                                                    if (file.exists()) {
                                                        if (file.length() == (long) i_145_)
                                                            i_143_ = 1;
                                                        else
                                                            i_143_ = JOptionPane.showConfirmDialog(null, new StringBuilder().append("Another track named '").append(string_149_).append("' already exists in your Sound Tracks folder!\nReplace it with the one attached to this stage?").toString(), "Stage Maker", 0);
                                                    }
                                                    if (i_143_ == 0) {
                                                        datainputstream = new DataInputStream(url.openStream());
                                                        is = new byte[i_145_];
                                                        datainputstream.readFully(is);
                                                        datainputstream.close();
                                                        FileOutputStream fileoutputstream = new FileOutputStream(file);
                                                        fileoutputstream.write(is);
                                                        fileoutputstream.close();
                                                        Object object_159_ = null;
                                                    }
                                                } catch (Exception exception) {
                                                    /* empty */
                                                }
                                            }
                                            setCursor(new Cursor(0));
                                            JOptionPane.showMessageDialog(null, new StringBuilder().append("").append(((StageMaker) this).mystages[i]).append(" has been successfully downloaded!").toString(), "Stage Maker", 1);
                                        } else
                                            JOptionPane.showMessageDialog(null, "Unable to download stage.  Unknown Error!     \nPlease try again later.", "Stage Maker", 1);
                                    } catch (Exception exception) {
                                        JOptionPane.showMessageDialog(null, "Unable to download stage.  Unknown Error!     \nPlease try again later.", "Stage Maker", 1);
                                    }
                                }
                            }
                        } else
                            ((StageMaker) this).rd.drawString("-    Error Loading this stage's info!    -", 550 - ((StageMaker) this).ftm.stringWidth("-    Error Loading this stage's info!    -") / 2, 156 + i * 20);
                        if (ovbutton("X", 765, 156 + i * 20) && JOptionPane.showConfirmDialog(null, new StringBuilder().append("Remove ").append(((StageMaker) this).mystages[i]).append(" from your account?").toString(), "Stage Maker", 0) == 0) {
                            setCursor(new Cursor(3));
                            int i_160_ = -1;
                            try {
                                Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                                BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                                printwriter.println(new StringBuilder().append("19|").append(((StageMaker) this).tnick.getText()).append("|").append(((StageMaker) this).tpass.getText()).append("|").append(((StageMaker) this).mystages[i]).append("|").toString());
                                String string = bufferedreader.readLine();
                                if (string != null)
                                    i_160_ = servervalue(string, 0);
                                socket.close();
                            } catch (Exception exception) {
                                i_160_ = -1;
                            }
                            if (i_160_ == 0)
                                ((StageMaker) this).logged = 1;
                            else {
                                setCursor(new Cursor(0));
                                JOptionPane.showMessageDialog(null, new StringBuilder().append("Failed to remove ").append(((StageMaker) this).mystages[i]).append(" from your account.  Unknown Error!     \nPlease try again later.").toString(), "Stage Maker", 1);
                            }
                        }
                    }
                }
                if (((StageMaker) this).logged == 2) {
                    for (int i = 0; i < ((StageMaker) this).nms; i++) {
                        ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                        ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                        ((StageMaker) this).rd.fillRect(50, 150, 600, 150);
                        ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                        ((StageMaker) this).rd.drawString(new StringBuilder().append("Loading ").append(((StageMaker) this).mystages[i]).append("\u2018s info...").toString(), 400 - ((StageMaker) this).ftm.stringWidth(new StringBuilder().append("Loading ").append(((StageMaker) this).mystages[i]).append("\u2018s info...").toString()) / 2, 220);
                        repaint();
                        ((StageMaker) this).maker[i] = "Unkown";
                        ((StageMaker) this).pubt[i] = -1;
                        ((StageMaker) this).nad[i] = 0;
                        String string = "";
                        try {
                            String string_161_ = new StringBuilder().append("http://multiplayer.needformadness.com/tracks/").append(((StageMaker) this).mystages[i]).append(".txt?reqlo=").append((int) (Math.random() * 1000.0)).append("").toString();
                            string_161_ = string_161_.replace(' ', '_');
                            URL url = new URL(string_161_);
                            DataInputStream datainputstream = new DataInputStream(url.openStream());
                            while ((string = datainputstream.readLine()) != null) {
                                string = new StringBuilder().append("").append(string.trim()).toString();
                                if (string.startsWith("details")) {
                                    ((StageMaker) this).maker[i] = getSvalue("details", string, 0);
                                    ((StageMaker) this).pubt[i] = getvalue("details", string, 1);
                                    boolean bool = false;
                                    while (!bool) {
                                        ((StageMaker) this).addeda[i][((StageMaker) this).nad[i]] = getSvalue("details", string, 2 + ((StageMaker) this).nad[i]);
                                        if (((StageMaker) this).addeda[i][((StageMaker) this).nad[i]].equals(""))
                                            bool = true;
                                        else
                                            ((StageMaker) this).nad[i]++;
                                    }
                                }
                            }
                        } catch (Exception exception) {
                            /* empty */
                        }
                    }
                    setCursor(new Cursor(0));
                    ((StageMaker) this).logged = 3;
                }
                if (((StageMaker) this).logged == -1) {
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Account empty, no published stages found.", 400 - ((StageMaker) this).ftm.stringWidth("Account empty, no published stages found.") / 2, 220);
                    ((StageMaker) this).rd.drawString("Click \u2018Publish\u2019 above to begin.", 400 - ((StageMaker) this).ftm.stringWidth("Click \u2018Publish\u2019 above to begin.") / 2, 280);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("The maximum number of stages your account can have at once is 20 stages.", 400 - ((StageMaker) this).ftm.stringWidth("The maximum number of stages your account can have at once is 20 stages.") / 2, 320);
                }
                if (((StageMaker) this).logged == 1) {
                    ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                    ((StageMaker) this).rd.fillRect(11, 141, 779, 401);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                    ((StageMaker) this).rd.drawString("Loading your account's stage list...", 400 - ((StageMaker) this).ftm.stringWidth("Loading your account's stage list...") / 2, 220);
                    repaint();
                    ((StageMaker) this).nms = 0;
                    String string = "";
                    try {
                        URL url = new URL(new StringBuilder().append("http://multiplayer.needformadness.com/tracks/lists/").append(((StageMaker) this).tnick.getText()).append(".txt?reqlo=").append((int) (Math.random() * 1000.0)).append("").toString());
                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                        while ((string = datainputstream.readLine()) != null) {
                            string = new StringBuilder().append("").append(string.trim()).toString();
                            if (string.startsWith("mystages")) {
                                boolean bool = true;
                                while (bool && ((StageMaker) this).nms < 20) {
                                    ((StageMaker) this).mystages[((StageMaker) this).nms] = getSvalue("mystages", string, ((StageMaker) this).nms);
                                    if (((StageMaker) this).mystages[((StageMaker) this).nms].equals(""))
                                        bool = false;
                                    else
                                        ((StageMaker) this).nms++;
                                }
                            }
                        }
                        if (((StageMaker) this).nms > 0)
                            ((StageMaker) this).logged = 2;
                        else {
                            setCursor(new Cursor(0));
                            ((StageMaker) this).logged = -1;
                        }
                        datainputstream.close();
                    } catch (Exception exception) {
                        String string_162_ = new StringBuilder().append("").append(exception).toString();
                        if (string_162_.indexOf("FileNotFound") != -1) {
                            setCursor(new Cursor(0));
                            ((StageMaker) this).logged = -1;
                        } else {
                            ((StageMaker) this).logged = 0;
                            JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Stage Maker", 1);
                        }
                    }
                }
                if (((StageMaker) this).logged == 0) {
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("The maximum number of stages your account can have at once is 20 stages.", 400 - ((StageMaker) this).ftm.stringWidth("The maximum number of stages your account can have at once is 20 stages.") / 2, 180);
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("Login to Retrieve your Account Stages", 400 - ((StageMaker) this).ftm.stringWidth("Login to Retrieve your Account Stages") / 2, 220);
                    ((StageMaker) this).rd.drawString("Nickname:", 376 - ((StageMaker) this).ftm.stringWidth("Nickname:") - 14, 266);
                    if (!((StageMaker) this).tnick.isShowing())
                        ((StageMaker) this).tnick.show();
                    movefield(((StageMaker) this).tnick, 376, 250, 129, 23);
                    ((StageMaker) this).rd.drawString("Password:", 376 - ((StageMaker) this).ftm.stringWidth("Password:") - 14, 296);
                    if (!((StageMaker) this).tpass.isShowing())
                        ((StageMaker) this).tpass.show();
                    movefield(((StageMaker) this).tpass, 376, 280, 129, 23);
                    if (button("       Login       ", 400, 340, 0, true)) {
                        setCursor(new Cursor(3));
                        int i = -1;
                        try {
                            Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                            printwriter.println(new StringBuilder().append("1|").append(((StageMaker) this).tnick.getText().toLowerCase()).append("|").append(((StageMaker) this).tpass.getText()).append("|").toString());
                            String string = bufferedreader.readLine();
                            if (string != null)
                                i = servervalue(string, 0);
                            socket.close();
                        } catch (Exception exception) {
                            i = -1;
                        }
                        if (i == 0 || i == 3 || i > 10) {
                            ((StageMaker) this).tnick.hide();
                            ((StageMaker) this).tpass.hide();
                            ((StageMaker) this).logged = 1;
                            savesettings();
                        }
                        if (i == 1 || i == 2) {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Sorry.  Incorrect Nickname or Password!", "Stage Maker", 0);
                        }
                        if (i == -167) {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Sorry.  Trial accounts are not allowed to publish cars & stages, please register a full account!", "Stage Maker", 0);
                        }
                        if (i == -1) {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Stage Maker", 1);
                        }
                    }
                    ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("Not registered yet?", 400 - ((StageMaker) this).ftm.stringWidth("Not registered yet?") / 2, 450);
                    if (button("   Register Now!   ", 400, 480, 0, true))
                        Madness.openurl("http://multiplayer.needformadness.com/register.html");
                    ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
                    ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
                    ((StageMaker) this).rd.drawString("Register to publish your stages to the multiplayer game!", 400 - ((StageMaker) this).ftm.stringWidth("Register to publish your stages to the multiplayer game!") / 2, 505);
                }
            }
            if (((StageMaker) this).tabed != ((StageMaker) this).tab) {
                if (((StageMaker) this).tabed == -2)
                    ((StageMaker) this).tabed = -1;
                else
                    ((StageMaker) this).tabed = ((StageMaker) this).tab;
            }
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            ((StageMaker) this).rd.fillRect(0, 0, 800, 25);
            if (!((StageMaker) this).onbtgame)
                ((StageMaker) this).rd.drawImage(((StageMaker) this).btgame[0], 620, 0, null);
            else
                ((StageMaker) this).rd.drawImage(((StageMaker) this).btgame[1], 620, 0, null);
            ((StageMaker) this).rd.setFont(new Font("Arial", 1, 13));
            ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
            String[] strings = { "Stage", "Build", "View & Edit", "Publish" };
            int[] is = { 0, 0, 100, 90 };
            int[] is_163_ = { 0, 25, 25, 0 };
            int i = 4;
            if (((StageMaker) this).stagename.equals("") || ((StageMaker) this).sfase != 0) {
                ((StageMaker) this).tab = 0;
                i = 1;
            }
            for (int i_164_ = 0; i_164_ < i; i_164_++) {
                ((StageMaker) this).rd.setColor(new Color(170, 170, 170));
                if (((StageMaker) this).xm > is[0] && ((StageMaker) this).xm < is[3] && ((StageMaker) this).ym > 0 && ((StageMaker) this).ym < 25)
                    ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
                if (((StageMaker) this).tab == i_164_)
                    ((StageMaker) this).rd.setColor(new Color(225, 225, 225));
                ((StageMaker) this).rd.fillPolygon(is, is_163_, 4);
                ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
                ((StageMaker) this).rd.drawString(strings[i_164_], i_164_ * 100 + 45 - ((StageMaker) this).ftm.stringWidth(strings[i_164_]) / 2, 17);
                if (((StageMaker) this).xm > is[0] && ((StageMaker) this).xm < is[3] && ((StageMaker) this).ym > 0 && ((StageMaker) this).ym < 25 && ((StageMaker) this).mouses == -1)
                    ((StageMaker) this).tab = i_164_;
                for (int i_165_ = 0; i_165_ < 4; i_165_++)
                    is[i_165_] += 100;
            }
            if (((StageMaker) this).mouses == -1)
                ((StageMaker) this).mouses = 0;
            drawms();
            repaint();
            if (!((StageMaker) this).exwist) {
                try {
                    if (((StageMaker) this).thredo != null) {
                        /* empty */
                    }
                    Thread.sleep(40L);
                } catch (InterruptedException interruptedexception) {
                    /* empty */
                }
            }
        }
        ((StageMaker) this).track.unload();
        ((StageMaker) this).track = null;
        ((StageMaker) this).rd.dispose();
        System.gc();
    }
    
    public void removesp() {
        if (((StageMaker) this).nundo < 5000) {
            ((StageMaker) this).undos[((StageMaker) this).nundo] = ((StageMaker) this).bstage;
            ((StageMaker) this).nundo++;
        }
        String string = "";
        if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok != 30 && ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok != 31 && ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok != 32 && ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok != 66)
            string = new StringBuilder().append("set(").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).roofat).append(")").toString();
        if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok == 31)
            string = new StringBuilder().append("fix(").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).y).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).roofat).append(")").toString();
        if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok == 30 || ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok == 32)
            string = new StringBuilder().append("chk(").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).roofat).append(")").toString();
        if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok == 54)
            string = new StringBuilder().append("chk(").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).roofat).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).y).append(")").toString();
        if (((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok == 66)
            string = new StringBuilder().append("pile(").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).srz).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).srx).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).sry).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).x).append(",").append(((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).z).append(")").toString();
        int i = ((StageMaker) this).bstage.indexOf(string);
        int i_166_ = i + string.length();
        int i_167_ = -1;
        int i_168_ = ((StageMaker) this).bstage.indexOf("set", i_166_);
        if (i_168_ != -1)
            i_167_ = i_168_;
        i_168_ = ((StageMaker) this).bstage.indexOf("chk", i_166_);
        if (i_168_ != -1 && i_168_ < i_167_)
            i_167_ = i_168_;
        i_168_ = ((StageMaker) this).bstage.indexOf("fix", i_166_);
        if (i_168_ != -1 && i_168_ < i_167_)
            i_167_ = i_168_;
        if (i_167_ == -1) {
            i_167_ = ((StageMaker) this).bstage.indexOf("\r\n", i_166_);
            if (i_167_ != -1)
                i_167_++;
        }
        if (i_167_ != -1)
            i_166_ = i_167_;
        if (i != -1)
            ((StageMaker) this).bstage = new StringBuilder().append("").append(((StageMaker) this).bstage.substring(0, i)).append("").append(((StageMaker) this).bstage.substring(i_166_, ((StageMaker) this).bstage.length())).append("").toString();
        readstage(0);
    }
    
    public void copyesp(boolean bool) {
        ((StageMaker) this).sp = ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).colok;
        ((StageMaker) this).rot = ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).roofat;
        if (((StageMaker) this).sp == 2)
            ((StageMaker) this).rot -= 30;
        if (((StageMaker) this).sp == 3)
            ((StageMaker) this).rot += 30;
        if (((StageMaker) this).sp == 15)
            ((StageMaker) this).rot += 90;
        if (((StageMaker) this).sp == 20)
            ((StageMaker) this).rot += 180;
        if (((StageMaker) this).sp == 26)
            ((StageMaker) this).rot -= 90;
        if (((StageMaker) this).sp == 0) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 4) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 1;
        }
        if (((StageMaker) this).sp == 13) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 2;
        }
        if (((StageMaker) this).sp == 3) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 3;
        }
        if (((StageMaker) this).sp == 2) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 4;
        }
        if (((StageMaker) this).sp == 1) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 5;
        }
        if (((StageMaker) this).sp == 35) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 6;
        }
        if (((StageMaker) this).sp == 36) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 7;
        }
        if (((StageMaker) this).sp == 10) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 8;
        }
        if (((StageMaker) this).sp == 5) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 9;
        }
        if (((StageMaker) this).sp == 7) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 10;
        }
        if (((StageMaker) this).sp == 14) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 11;
        }
        if (((StageMaker) this).sp == 6) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 12;
        }
        if (((StageMaker) this).sp == 34) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 13;
        }
        if (((StageMaker) this).sp == 33) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 14;
        }
        if (((StageMaker) this).sp == 11) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 15;
        }
        if (((StageMaker) this).sp == 8) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 16;
        }
        if (((StageMaker) this).sp == 9) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 17;
        }
        if (((StageMaker) this).sp == 15) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 18;
        }
        if (((StageMaker) this).sp == 12) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 19;
        }
        if (((StageMaker) this).sp == 46) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 20;
        }
        if (((StageMaker) this).sp == 47) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 21;
        }
        if (((StageMaker) this).sp == 48) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 23;
        }
        if (((StageMaker) this).sp == 49) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 24;
        }
        if (((StageMaker) this).sp == 50) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 22;
        }
        if (((StageMaker) this).sp == 51) {
            ((StageMaker) this).sptyp = 0;
            ((StageMaker) this).spart = 25;
        }
        if (((StageMaker) this).sp == 16) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 18) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 1;
        }
        if (((StageMaker) this).sp == 19) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 2;
        }
        if (((StageMaker) this).sp == 22) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 3;
        }
        if (((StageMaker) this).sp == 17) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 4;
        }
        if (((StageMaker) this).sp == 21) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 5;
        }
        if (((StageMaker) this).sp == 20) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 6;
        }
        if (((StageMaker) this).sp == 39) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 7;
        }
        if (((StageMaker) this).sp == 42) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 8;
        }
        if (((StageMaker) this).sp == 40) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 9;
        }
        if (((StageMaker) this).sp == 23) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 10;
        }
        if (((StageMaker) this).sp == 25) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 11;
        }
        if (((StageMaker) this).sp == 24) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 12;
        }
        if (((StageMaker) this).sp == 43) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 13;
        }
        if (((StageMaker) this).sp == 45) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 14;
        }
        if (((StageMaker) this).sp == 26) {
            ((StageMaker) this).sptyp = 1;
            ((StageMaker) this).spart = 15;
        }
        if (((StageMaker) this).sp == 27) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 28) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 1;
        }
        if (((StageMaker) this).sp == 41) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 2;
        }
        if (((StageMaker) this).sp == 44) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 3;
        }
        if (((StageMaker) this).sp == 52) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 4;
        }
        if (((StageMaker) this).sp == 53) {
            ((StageMaker) this).sptyp = 2;
            ((StageMaker) this).spart = 5;
        }
        if (((StageMaker) this).sp == 30 || ((StageMaker) this).sp == 32 || ((StageMaker) this).sp == 54) {
            ((StageMaker) this).sptyp = 3;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 31) {
            ((StageMaker) this).sptyp = 4;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 55) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 0;
        }
        if (((StageMaker) this).sp == 56) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 1;
        }
        if (((StageMaker) this).sp == 57) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 2;
        }
        if (((StageMaker) this).sp == 58) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 3;
        }
        if (((StageMaker) this).sp == 59) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 4;
        }
        if (((StageMaker) this).sp == 60) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 5;
        }
        if (((StageMaker) this).sp == 61) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 6;
        }
        if (((StageMaker) this).sp == 62) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 7;
        }
        if (((StageMaker) this).sp == 63) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 8;
        }
        if (((StageMaker) this).sp == 64) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 9;
        }
        if (((StageMaker) this).sp == 65) {
            ((StageMaker) this).sptyp = 5;
            ((StageMaker) this).spart = 10;
        }
        if (((StageMaker) this).sp == 66) {
            if (bool)
                ((StageMaker) this).fgen = ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).srz;
            else
                ((StageMaker) this).fgen = 0;
            ((StageMaker) this).pwd = (float) ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).srx;
            ((StageMaker) this).phd = (float) ((ContO) ((StageMaker) this).co[((StageMaker) this).esp]).sry;
            ((StageMaker) this).pgen = false;
            ((StageMaker) this).sptyp = 6;
        }
        if (((StageMaker) this).sptyp == 0) {
            partroads();
            ((StageMaker) this).part.show();
        }
        if (((StageMaker) this).sptyp == 1) {
            partramps();
            ((StageMaker) this).part.show();
        }
        if (((StageMaker) this).sptyp == 2) {
            partobst();
            ((StageMaker) this).part.show();
        }
        if (((StageMaker) this).sptyp == 5) {
            partrees();
            ((StageMaker) this).part.show();
        }
        ((StageMaker) this).ptyp.select(((StageMaker) this).sptyp);
        ((StageMaker) this).part.select(((StageMaker) this).spart);
    }
    
    public void partrees() {
        ((StageMaker) this).part.removeAll();
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tree 1");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tree 2");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tree 3");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tree 4");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tree 5");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Palm Tree 1");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Palm Tree 2");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Palm Tree 3");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Cactus 1");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Cactus 2");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Cactus 3");
    }
    
    public void partroads() {
        ((StageMaker) this).part.removeAll();
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad Turn");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad End");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad TwistedLeft");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad TwistedRight");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad Edged");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad-Raised Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "NormalRoad Raised");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Normal-Off-Road Blend");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad Turn");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad End");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad BumpyGreen");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad-BumpySides Start");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "OffRoad BumpySides");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Off-Halfpipe-Road Blend");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "HalfpipeRoad");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "HalfpipeRoad Turn");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "HalfpipeRoad-Ramp Filler");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Halfpipe-Normal-Road Blend");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Start/End");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Road1");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Road2");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Road3");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Road4");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rollercoaster Road5");
    }
    
    public void partramps() {
        ((StageMaker) this).part.removeAll();
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Basic Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Two-Way Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Two-Way High-Low Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Small Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Crash Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Big-Takeoff Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Landing Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Tunnel Side Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Speed Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Launch Pad Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Bump Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Big Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Hill Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Big Hill Ramp");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Halfpipe");
    }
    
    public void partobst() {
        ((StageMaker) this).part.removeAll();
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Spiky Pillars");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Rail Doorway");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "The Net");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Bump Slide");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Dirt-Pile 1");
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Offroad Dirt-Pile 2");
    }
    
    public void init() {
        setBackground(new Color(0, 0, 0));
        ((StageMaker) this).offImage = createImage(800, 550);
        if (((StageMaker) this).offImage != null)
            ((StageMaker) this).rd = (Graphics2D) ((StageMaker) this).offImage.getGraphics();
        ((StageMaker) this).rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        setLayout(null);
        ((StageMaker) this).slstage.setFont(new Font("Arial", 1, 13));
        ((StageMaker) this).slstage.add(((StageMaker) this).rd, "Select a Stage...         ");
        ((StageMaker) this).slstage.setForeground(new Color(63, 80, 110));
        ((StageMaker) this).slstage.setBackground(new Color(209, 217, 230));
        ((StageMaker) this).srch.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).srch.setBackground(new Color(255, 255, 255));
        ((StageMaker) this).srch.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).strtyp.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).strtyp.add(((StageMaker) this).rd, "NormalRoad");
        ((StageMaker) this).strtyp.add(((StageMaker) this).rd, "OffRoad");
        ((StageMaker) this).strtyp.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).strtyp.setForeground(new Color(209, 217, 230));
        ((StageMaker) this).ptyp.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Roads");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Ramps");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Obstacles");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Checkpoint");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Fixing Hoop");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Trees");
        ((StageMaker) this).ptyp.add(((StageMaker) this).rd, "Ground Pile");
        ((StageMaker) this).ptyp.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).ptyp.setForeground(new Color(209, 217, 230));
        ((StageMaker) this).part.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).part.add(((StageMaker) this).rd, "Halfpipe-Normal-Road Blend");
        ((StageMaker) this).part.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).part.setForeground(new Color(209, 217, 230));
        ((StageMaker) this).fixh.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).fixh.setBackground(new Color(255, 255, 255));
        ((StageMaker) this).fixh.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).mgen.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).mgen.setBackground(new Color(255, 255, 255));
        ((StageMaker) this).mgen.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).pfog.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).pfog.setBackground(new Color(225, 225, 225));
        ((StageMaker) this).pfog.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).nlaps.setFont(new Font("Arial", 1, 12));
        for (int i = 0; i < 15; i++)
            ((StageMaker) this).nlaps.add(((StageMaker) this).rd, new StringBuilder().append(" ").append(i + 1).append(" ").toString());
        ((StageMaker) this).nlaps.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).nlaps.setForeground(new Color(209, 217, 230));
        ((StageMaker) this).tracks.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).tracks.add(((StageMaker) this).rd, "Select MOD Track");
        ((StageMaker) this).tracks.setForeground(new Color(63, 80, 110));
        ((StageMaker) this).tracks.setBackground(new Color(209, 217, 230));
        ((StageMaker) this).witho.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).witho.add(((StageMaker) this).rd, "With other cars");
        ((StageMaker) this).witho.add(((StageMaker) this).rd, "Alone");
        ((StageMaker) this).witho.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).witho.setForeground(new Color(209, 217, 230));
        ((StageMaker) this).tnick.setFont(new Font("Arial", 1, 13));
        ((StageMaker) this).tnick.setBackground(new Color(255, 255, 255));
        ((StageMaker) this).tnick.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).tpass.setFont(new Font("Arial", 1, 13));
        ((StageMaker) this).tpass.setEchoCharacter('*');
        ((StageMaker) this).tpass.setBackground(new Color(255, 255, 255));
        ((StageMaker) this).tpass.setForeground(new Color(0, 0, 0));
        ((StageMaker) this).pubtyp.setFont(new Font("Arial", 1, 13));
        ((StageMaker) this).pubtyp.add(((StageMaker) this).rd, "Private");
        ((StageMaker) this).pubtyp.add(((StageMaker) this).rd, "Public");
        ((StageMaker) this).pubtyp.add(((StageMaker) this).rd, "Super Public");
        ((StageMaker) this).pubtyp.setBackground(new Color(63, 80, 110));
        ((StageMaker) this).pubtyp.setForeground(new Color(209, 217, 230));
        add(((StageMaker) this).tnick);
        add(((StageMaker) this).tpass);
        add(((StageMaker) this).srch);
        add(((StageMaker) this).fixh);
        add(((StageMaker) this).mgen);
        add(((StageMaker) this).pfog);
        hidefields();
    }
    
    public void hidefields() {
        ((StageMaker) this).pubtyp.hide();
        ((StageMaker) this).tpass.hide();
        ((StageMaker) this).tnick.hide();
        ((StageMaker) this).witho.hide();
        ((StageMaker) this).strtyp.hide();
        ((StageMaker) this).srch.hide();
        ((StageMaker) this).slstage.hide();
        ((StageMaker) this).tracks.hide();
        ((StageMaker) this).nlaps.hide();
        ((StageMaker) this).pfog.hide();
        ((StageMaker) this).fixh.hide();
        ((StageMaker) this).mgen.hide();
        ((StageMaker) this).ptyp.hide();
        ((StageMaker) this).part.hide();
    }
    
    public void movefield(Component component, int i, int i_169_, int i_170_, int i_171_) {
        i += ((StageMaker) this).apx;
        i_169_ += ((StageMaker) this).apy;
        if (component.getX() != i || component.getY() != i_169_ || component.getWidth() != i_170_ || component.getHeight() != i_171_)
            component.setBounds(i, i_169_, i_170_, i_171_);
    }
    
    public void drawms() {
        boolean bool = false;
        if (((StageMaker) this).pubtyp.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, false))
            bool = true;
        if (((StageMaker) this).slstage.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, false))
            bool = true;
        if (((StageMaker) this).strtyp.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, false))
            bool = true;
        int i = 0;
        if (((StageMaker) this).preop)
            i = -1000;
        if (((StageMaker) this).part.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym + i, ((StageMaker) this).mousdr && !((StageMaker) this).preop, 550, false))
            bool = true;
        if (((StageMaker) this).ptyp.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, false)) {
            bool = true;
            ((StageMaker) this).preop = true;
        } else
            ((StageMaker) this).preop = false;
        if (((StageMaker) this).nlaps.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, true))
            bool = true;
        if (((StageMaker) this).tracks.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, true))
            bool = true;
        if (((StageMaker) this).witho.draw(((StageMaker) this).rd, ((StageMaker) this).xm, ((StageMaker) this).ym, ((StageMaker) this).mousdr, 550, true))
            bool = true;
        if (bool)
            ((StageMaker) this).mouses = 0;
    }
    
    public void start() {
        if (((StageMaker) this).thredo == null)
            ((StageMaker) this).thredo = new Thread(this);
        ((StageMaker) this).thredo.start();
    }
    
    public void stop() {
        ((StageMaker) this).exwist = true;
    }
    
    public void paint(Graphics graphics) {
        ((StageMaker) this).apx = getWidth() / 2 - 400;
        ((StageMaker) this).apy = getHeight() / 2 - 275;
        graphics.drawImage(((StageMaker) this).offImage, ((StageMaker) this).apx, ((StageMaker) this).apy, this);
    }
    
    public void update(Graphics graphics) {
        paint(graphics);
    }
    
    public boolean mouseUp(Event event, int i, int i_172_) {
        ((StageMaker) this).mousdr = false;
        ((StageMaker) this).xm = i - ((StageMaker) this).apx;
        ((StageMaker) this).ym = i_172_ - ((StageMaker) this).apy;
        if (((StageMaker) this).mouses == 1)
            ((StageMaker) this).mouses = -1;
        if (((StageMaker) this).onbtgame)
            Madness.game();
        return false;
    }
    
    public boolean mouseDown(Event event, int i, int i_173_) {
        ((StageMaker) this).mousdr = true;
        ((StageMaker) this).xm = i - ((StageMaker) this).apx;
        ((StageMaker) this).ym = i_173_ - ((StageMaker) this).apy;
        ((StageMaker) this).mouses = 1;
        requestFocus();
        ((StageMaker) this).focuson = true;
        return false;
    }
    
    public boolean mouseMove(Event event, int i, int i_174_) {
        ((StageMaker) this).xm = i - ((StageMaker) this).apx;
        ((StageMaker) this).ym = i_174_ - ((StageMaker) this).apy;
        if (((StageMaker) this).xm > 620 && ((StageMaker) this).xm < 774 && ((StageMaker) this).ym > 0 && ((StageMaker) this).ym < 23) {
            if (!((StageMaker) this).onbtgame) {
                ((StageMaker) this).onbtgame = true;
                setCursor(new Cursor(12));
            }
        } else if (((StageMaker) this).onbtgame) {
            ((StageMaker) this).onbtgame = false;
            setCursor(new Cursor(0));
        }
        return false;
    }
    
    public boolean mouseDrag(Event event, int i, int i_175_) {
        ((StageMaker) this).mousdr = true;
        ((StageMaker) this).xm = i - ((StageMaker) this).apx;
        ((StageMaker) this).ym = i_175_ - ((StageMaker) this).apy;
        return false;
    }
    
    public boolean keyDown(Event event, int i) {
        if (((StageMaker) this).focuson) {
            if (i == 42 || i == 10 || i == 56 || i == 119 || i == 87 || i == 43 || i == 61)
                ((StageMaker) this).zoomi = true;
            if (i == 47 || i == 8 || i == 50 || i == 115 || i == 83 || i == 45)
                ((StageMaker) this).zoomo = true;
            if (i == 1006)
                ((StageMaker) this).left = true;
            if (i == 1007)
                ((StageMaker) this).right = true;
            if (i == 1005)
                ((StageMaker) this).down = true;
            if (i == 1004)
                ((StageMaker) this).up = true;
        }
        return false;
    }
    
    public boolean keyUp(Event event, int i) {
        if (i == 42 || i == 10 || i == 56 || i == 119 || i == 87 || i == 43 || i == 61)
            ((StageMaker) this).zoomi = false;
        if (i == 47 || i == 8 || i == 50 || i == 115 || i == 83 || i == 45)
            ((StageMaker) this).zoomo = false;
        if (i == 1006)
            ((StageMaker) this).left = false;
        if (i == 1007)
            ((StageMaker) this).right = false;
        if (i == 1005)
            ((StageMaker) this).down = false;
        if (i == 1004)
            ((StageMaker) this).up = false;
        return false;
    }
    
    public void loadbase() {
        String[] strings = { "road", "froad", "twister2", "twister1", "turn", "offroad", "bumproad", "offturn", "nroad", "nturn", "roblend", "noblend", "rnblend", "roadend", "offroadend", "hpground", "ramp30", "cramp35", "dramp15", "dhilo15", "slide10", "takeoff", "sramp22", "offbump", "offramp", "sofframp", "halfpipe", "spikes", "rail", "thewall", "checkpoint", "fixpoint", "offcheckpoint", "sideoff", "bsideoff", "uprise", "riseroad", "sroad", "soffroad", "tside", "launchpad", "thenet", "speedramp", "offhill", "slider", "uphill", "roll1", "roll2", "roll3", "roll4", "roll5", "roll6", "opile1", "opile2", "aircheckpoint", "tree1", "tree2", "tree3", "tree4", "tree5", "tree6", "tree7", "tree8", "cac1", "cac2", "cac3" };
        try {
            File file = new File("data/models.zip");
            ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(file));
            ZipEntry zipentry = zipinputstream.getNextEntry();
            Object object = null;
            for (/**/; zipentry != null; zipentry = zipinputstream.getNextEntry()) {
                int i = -1;
                for (int i_176_ = 0; i_176_ < 66; i_176_++) {
                    if (zipentry.getName().startsWith(strings[i_176_]))
                        i = i_176_;
                }
                if (i != -1) {
                    int i_177_ = (int) zipentry.getSize();
                    byte[] is = new byte[i_177_];
                    int i_178_ = 0;
                    int i_179_;
                    for (/**/; i_177_ > 0; i_177_ -= i_179_) {
                        i_179_ = zipinputstream.read(is, i_178_, i_177_);
                        i_178_ += i_179_;
                    }
                    ((StageMaker) this).bco[i] = new ContO(is, ((StageMaker) this).m, ((StageMaker) this).t);
                    for (int i_180_ = 0; i_180_ < ((ContO) ((StageMaker) this).bco[i]).npl; i_180_++)
                        ((ContO) ((StageMaker) this).bco[i]).p[i_180_].loadprojf();
                    if (i == 31)
                        ((ContO) ((StageMaker) this).bco[i]).elec = true;
                }
            }
            zipinputstream.close();
            ((StageMaker) this).bco[66] = new ContO((int) (10000.0 * Math.random()), (int) ((StageMaker) this).pwd, (int) ((StageMaker) this).phd, ((StageMaker) this).m, ((StageMaker) this).t, 0, 0, 0);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to load file 'data/models.zip'!\nError:\n").append(exception).toString(), "Stage Maker", 1);
        }
        System.gc();
    }
    
    public void readstage(int i) {
        ((StageMaker) this).errd = 0;
        ((StageMaker) this).trackname = "";
        ((Trackers) ((StageMaker) this).t).nt = 0;
        ((StageMaker) this).nob = 0;
        ((StageMaker) this).xnob = 0;
        ((CheckPoints) ((StageMaker) this).cp).n = 0;
        ((CheckPoints) ((StageMaker) this).cp).nsp = 0;
        ((CheckPoints) ((StageMaker) this).cp).fn = 0;
        ((CheckPoints) ((StageMaker) this).cp).haltall = false;
        ((CheckPoints) ((StageMaker) this).cp).wasted = 0;
        ((CheckPoints) ((StageMaker) this).cp).catchfin = 0;
        ((Medium) ((StageMaker) this).m).ground = 250;
        ((Medium) ((StageMaker) this).m).lightson = false;
        if (i == 0) {
            ((Medium) ((StageMaker) this).m).snap[0] = 0;
            ((Medium) ((StageMaker) this).m).snap[1] = 0;
            ((Medium) ((StageMaker) this).m).snap[2] = 0;
        }
        if (i == 3) {
            ((StageMaker) this).tstage = "";
            ((StageMaker) this).bstage = "";
        }
        String string = ((StageMaker) this).bstage;
        if (i == 1 || i == 2)
            string = new StringBuilder().append("").append(((StageMaker) this).tstage).append("\r\n").append(((StageMaker) this).bstage).append("").toString();
        int i_181_ = 0;
        int i_182_ = 100;
        int i_183_ = 0;
        int i_184_ = 100;
        boolean bool = true;
        boolean bool_185_ = true;
        String string_186_ = "";
        try {
            Object object = null;
            DataInputStream datainputstream;
            if (i == 3) {
                File file = new File(new StringBuilder().append("mystages/").append(((StageMaker) this).stagename).append(".txt").toString());
                datainputstream = new DataInputStream(new FileInputStream(file));
                ((StageMaker) this).nundo = 0;
            } else
                datainputstream = new DataInputStream(new ByteArrayInputStream(string.getBytes()));
            String string_187_;
            while ((string_187_ = datainputstream.readLine()) != null) {
                string_186_ = new StringBuilder().append("").append(string_187_.trim()).toString();
                if (string_186_.startsWith("sky")) {
                    ((StageMaker) this).csky[0] = getint("sky", string_186_, 0);
                    ((StageMaker) this).csky[1] = getint("sky", string_186_, 1);
                    ((StageMaker) this).csky[2] = getint("sky", string_186_, 2);
                    ((StageMaker) this).m.setsky(((StageMaker) this).csky[0], ((StageMaker) this).csky[1], ((StageMaker) this).csky[2]);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_188_ = this;
                        ((StageMaker) stagemaker_188_).tstage = stringbuilder.append(((StageMaker) stagemaker_188_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("ground")) {
                    ((StageMaker) this).cgrnd[0] = getint("ground", string_186_, 0);
                    ((StageMaker) this).cgrnd[1] = getint("ground", string_186_, 1);
                    ((StageMaker) this).cgrnd[2] = getint("ground", string_186_, 2);
                    ((StageMaker) this).m.setgrnd(((StageMaker) this).cgrnd[0], ((StageMaker) this).cgrnd[1], ((StageMaker) this).cgrnd[2]);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_189_ = this;
                        ((StageMaker) stagemaker_189_).tstage = stringbuilder.append(((StageMaker) stagemaker_189_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("polys")) {
                    ((StageMaker) this).m.setpolys(getint("polys", string_186_, 0), getint("polys", string_186_, 1), getint("polys", string_186_, 2));
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_190_ = this;
                        ((StageMaker) stagemaker_190_).tstage = stringbuilder.append(((StageMaker) stagemaker_190_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("fog")) {
                    ((StageMaker) this).cfade[0] = getint("fog", string_186_, 0);
                    ((StageMaker) this).cfade[1] = getint("fog", string_186_, 1);
                    ((StageMaker) this).cfade[2] = getint("fog", string_186_, 2);
                    ((StageMaker) this).m.setfade(((StageMaker) this).cfade[0], ((StageMaker) this).cfade[1], ((StageMaker) this).cfade[2]);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_191_ = this;
                        ((StageMaker) stagemaker_191_).tstage = stringbuilder.append(((StageMaker) stagemaker_191_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("texture")) {
                    ((StageMaker) this).texture[0] = getint("texture", string_186_, 0);
                    ((StageMaker) this).texture[1] = getint("texture", string_186_, 1);
                    ((StageMaker) this).texture[2] = getint("texture", string_186_, 2);
                    ((StageMaker) this).texture[3] = getint("texture", string_186_, 3);
                    ((StageMaker) this).m.setexture(((StageMaker) this).texture[0], ((StageMaker) this).texture[1], ((StageMaker) this).texture[2], ((StageMaker) this).texture[3]);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_192_ = this;
                        ((StageMaker) stagemaker_192_).tstage = stringbuilder.append(((StageMaker) stagemaker_192_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("clouds")) {
                    ((StageMaker) this).cldd[0] = getint("clouds", string_186_, 0);
                    ((StageMaker) this).cldd[1] = getint("clouds", string_186_, 1);
                    ((StageMaker) this).cldd[2] = getint("clouds", string_186_, 2);
                    ((StageMaker) this).cldd[3] = getint("clouds", string_186_, 3);
                    ((StageMaker) this).cldd[4] = getint("clouds", string_186_, 4);
                    ((StageMaker) this).m.setcloads(((StageMaker) this).cldd[0], ((StageMaker) this).cldd[1], ((StageMaker) this).cldd[2], ((StageMaker) this).cldd[3], ((StageMaker) this).cldd[4]);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_193_ = this;
                        ((StageMaker) stagemaker_193_).tstage = stringbuilder.append(((StageMaker) stagemaker_193_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (i != 2 && string_186_.startsWith("snap")) {
                    ((StageMaker) this).m.setsnap(getint("snap", string_186_, 0), getint("snap", string_186_, 1), getint("snap", string_186_, 2));
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_194_ = this;
                        ((StageMaker) stagemaker_194_).tstage = stringbuilder.append(((StageMaker) stagemaker_194_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("density")) {
                    ((Medium) ((StageMaker) this).m).fogd = (getint("density", string_186_, 0) + 1) * 2 - 1;
                    if (((Medium) ((StageMaker) this).m).fogd < 1)
                        ((Medium) ((StageMaker) this).m).fogd = 1;
                    if (((Medium) ((StageMaker) this).m).fogd > 30)
                        ((Medium) ((StageMaker) this).m).fogd = 30;
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_195_ = this;
                        ((StageMaker) stagemaker_195_).tstage = stringbuilder.append(((StageMaker) stagemaker_195_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("mountains")) {
                    ((Medium) ((StageMaker) this).m).mgen = getint("mountains", string_186_, 0);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_196_ = this;
                        ((StageMaker) stagemaker_196_).tstage = stringbuilder.append(((StageMaker) stagemaker_196_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("fadefrom")) {
                    ((StageMaker) this).m.fadfrom(getint("fadefrom", string_186_, 0));
                    ((StageMaker) this).origfade = ((Medium) ((StageMaker) this).m).fade[0];
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_197_ = this;
                        ((StageMaker) stagemaker_197_).tstage = stringbuilder.append(((StageMaker) stagemaker_197_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("lightson")) {
                    ((Medium) ((StageMaker) this).m).lightson = true;
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_198_ = this;
                        ((StageMaker) stagemaker_198_).tstage = stringbuilder.append(((StageMaker) stagemaker_198_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("nlaps")) {
                    ((CheckPoints) ((StageMaker) this).cp).nlaps = getint("nlaps", string_186_, 0);
                    if (((CheckPoints) ((StageMaker) this).cp).nlaps < 1)
                        ((CheckPoints) ((StageMaker) this).cp).nlaps = 1;
                    if (((CheckPoints) ((StageMaker) this).cp).nlaps > 15)
                        ((CheckPoints) ((StageMaker) this).cp).nlaps = 15;
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_199_ = this;
                        ((StageMaker) stagemaker_199_).tstage = stringbuilder.append(((StageMaker) stagemaker_199_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("soundtrack")) {
                    ((StageMaker) this).trackname = getstring("soundtrack", string_186_, 0);
                    ((StageMaker) this).trackvol = getint("soundtrack", string_186_, 1);
                    ((StageMaker) this).tracksize = getint("soundtrack", string_186_, 2);
                    if (i == 3) {
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_200_ = this;
                        ((StageMaker) stagemaker_200_).tstage = stringbuilder.append(((StageMaker) stagemaker_200_).tstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("set")) {
                    int i_201_ = getint("set", string_186_, 0);
                    if (i_201_ >= 10 && i_201_ <= 25)
                        ((Medium) ((StageMaker) this).m).loadnew = true;
                    i_201_ -= 10;
                    ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[i_201_], getint("set", string_186_, 1), ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[i_201_]).grat, getint("set", string_186_, 2), getint("set", string_186_, 3));
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = getint("set", string_186_, 3);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = i_201_;
                    if (string_186_.indexOf(")p") != -1) {
                        ((CheckPoints) ((StageMaker) this).cp).x[((CheckPoints) ((StageMaker) this).cp).n] = getint("chk", string_186_, 1);
                        ((CheckPoints) ((StageMaker) this).cp).z[((CheckPoints) ((StageMaker) this).cp).n] = getint("chk", string_186_, 2);
                        ((CheckPoints) ((StageMaker) this).cp).y[((CheckPoints) ((StageMaker) this).cp).n] = 0;
                        ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = 0;
                        if (string_186_.indexOf(")pt") != -1)
                            ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = -1;
                        if (string_186_.indexOf(")pr") != -1)
                            ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = -2;
                        if (string_186_.indexOf(")po") != -1)
                            ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = -3;
                        if (string_186_.indexOf(")ph") != -1)
                            ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = -4;
                        ((CheckPoints) ((StageMaker) this).cp).n++;
                    }
                    ((StageMaker) this).xnob++;
                    ((StageMaker) this).nob++;
                    if (i == 3) {
                        if (bool_185_) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_202_ = this;
                            ((StageMaker) stagemaker_202_).bstage = stringbuilder.append(((StageMaker) stagemaker_202_).bstage).append("\r\n").toString();
                            bool_185_ = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_203_ = this;
                        ((StageMaker) stagemaker_203_).bstage = stringbuilder.append(((StageMaker) stagemaker_203_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                    if (((Medium) ((StageMaker) this).m).loadnew)
                        ((Medium) ((StageMaker) this).m).loadnew = false;
                }
                if (string_186_.startsWith("chk")) {
                    int i_204_ = getint("chk", string_186_, 0);
                    i_204_ -= 10;
                    int i_205_ = ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[i_204_]).grat;
                    if (i_204_ == 54)
                        i_205_ = getint("chk", string_186_, 4);
                    ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[i_204_], getint("chk", string_186_, 1), i_205_, getint("chk", string_186_, 2), getint("chk", string_186_, 3));
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = getint("chk", string_186_, 3);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = i_204_;
                    ((CheckPoints) ((StageMaker) this).cp).x[((CheckPoints) ((StageMaker) this).cp).n] = getint("chk", string_186_, 1);
                    ((CheckPoints) ((StageMaker) this).cp).z[((CheckPoints) ((StageMaker) this).cp).n] = getint("chk", string_186_, 2);
                    ((CheckPoints) ((StageMaker) this).cp).y[((CheckPoints) ((StageMaker) this).cp).n] = i_205_;
                    if (getint("chk", string_186_, 3) == 0)
                        ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = 1;
                    else
                        ((CheckPoints) ((StageMaker) this).cp).typ[((CheckPoints) ((StageMaker) this).cp).n] = 2;
                    ((CheckPoints) ((StageMaker) this).cp).pcs = ((CheckPoints) ((StageMaker) this).cp).n;
                    ((CheckPoints) ((StageMaker) this).cp).n++;
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).checkpoint = ((CheckPoints) ((StageMaker) this).cp).nsp + 1;
                    if (string_186_.indexOf(")r") != -1)
                        ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).wh = ((CheckPoints) ((StageMaker) this).cp).nsp + 1;
                    ((CheckPoints) ((StageMaker) this).cp).nsp++;
                    ((StageMaker) this).xnob++;
                    ((StageMaker) this).nob++;
                    if (i == 3) {
                        if (bool_185_) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_206_ = this;
                            ((StageMaker) stagemaker_206_).bstage = stringbuilder.append(((StageMaker) stagemaker_206_).bstage).append("\r\n").toString();
                            bool_185_ = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_207_ = this;
                        ((StageMaker) stagemaker_207_).bstage = stringbuilder.append(((StageMaker) stagemaker_207_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("fix")) {
                    int i_208_ = getint("fix", string_186_, 0);
                    i_208_ -= 10;
                    ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[i_208_], getint("fix", string_186_, 1), getint("fix", string_186_, 3), getint("fix", string_186_, 2), getint("fix", string_186_, 4));
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roofat = getint("fix", string_186_, 4);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = i_208_;
                    ((CheckPoints) ((StageMaker) this).cp).fx[((CheckPoints) ((StageMaker) this).cp).fn] = getint("fix", string_186_, 1);
                    ((CheckPoints) ((StageMaker) this).cp).fz[((CheckPoints) ((StageMaker) this).cp).fn] = getint("fix", string_186_, 2);
                    ((CheckPoints) ((StageMaker) this).cp).fy[((CheckPoints) ((StageMaker) this).cp).fn] = getint("fix", string_186_, 3);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).elec = true;
                    if (getint("fix", string_186_, 4) != 0) {
                        ((CheckPoints) ((StageMaker) this).cp).roted[((CheckPoints) ((StageMaker) this).cp).fn] = true;
                        ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).roted = true;
                    } else
                        ((CheckPoints) ((StageMaker) this).cp).roted[((CheckPoints) ((StageMaker) this).cp).fn] = false;
                    if (string_186_.indexOf(")s") != -1)
                        ((CheckPoints) ((StageMaker) this).cp).special[((CheckPoints) ((StageMaker) this).cp).fn] = true;
                    else
                        ((CheckPoints) ((StageMaker) this).cp).special[((CheckPoints) ((StageMaker) this).cp).fn] = false;
                    ((CheckPoints) ((StageMaker) this).cp).fn++;
                    ((StageMaker) this).xnob++;
                    ((StageMaker) this).nob++;
                    if (i == 3) {
                        if (bool_185_) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_209_ = this;
                            ((StageMaker) stagemaker_209_).bstage = stringbuilder.append(((StageMaker) stagemaker_209_).bstage).append("\r\n").toString();
                            bool_185_ = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_210_ = this;
                        ((StageMaker) stagemaker_210_).bstage = stringbuilder.append(((StageMaker) stagemaker_210_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("pile")) {
                    ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(getint("pile", string_186_, 0), getint("pile", string_186_, 1), getint("pile", string_186_, 2), ((StageMaker) this).m, ((StageMaker) this).t, getint("pile", string_186_, 3), getint("pile", string_186_, 4), ((Medium) ((StageMaker) this).m).ground);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).srz = getint("pile", string_186_, 0);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).srx = getint("pile", string_186_, 1);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).sry = getint("pile", string_186_, 2);
                    ((ContO) ((StageMaker) this).co[((StageMaker) this).nob]).colok = 66;
                    ((StageMaker) this).xnob++;
                    ((StageMaker) this).nob++;
                    if (i == 3) {
                        if (bool_185_) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_211_ = this;
                            ((StageMaker) stagemaker_211_).bstage = stringbuilder.append(((StageMaker) stagemaker_211_).bstage).append("\r\n").toString();
                            bool_185_ = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_212_ = this;
                        ((StageMaker) stagemaker_212_).bstage = stringbuilder.append(((StageMaker) stagemaker_212_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("maxr")) {
                    int i_213_ = getint("maxr", string_186_, 0);
                    int i_214_ = getint("maxr", string_186_, 1);
                    i_181_ = i_214_;
                    int i_215_ = getint("maxr", string_186_, 2);
                    for (int i_216_ = 0; i_216_ < i_213_; i_216_++) {
                        ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[29], i_214_, ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[29]).grat, i_216_ * 4800 + i_215_, 0);
                        if (i == 0)
                            ((StageMaker) this).xnob++;
                        else
                            ((StageMaker) this).nob++;
                    }
                    if (i == 3) {
                        if (bool) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_217_ = this;
                            ((StageMaker) stagemaker_217_).bstage = stringbuilder.append(((StageMaker) stagemaker_217_).bstage).append("\r\n").toString();
                            bool = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_218_ = this;
                        ((StageMaker) stagemaker_218_).bstage = stringbuilder.append(((StageMaker) stagemaker_218_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("maxl")) {
                    int i_219_ = getint("maxl", string_186_, 0);
                    int i_220_ = getint("maxl", string_186_, 1);
                    i_182_ = i_220_;
                    int i_221_ = getint("maxl", string_186_, 2);
                    for (int i_222_ = 0; i_222_ < i_219_; i_222_++) {
                        ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[29], i_220_, ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[29]).grat, i_222_ * 4800 + i_221_, 180);
                        if (i == 0)
                            ((StageMaker) this).xnob++;
                        else
                            ((StageMaker) this).nob++;
                    }
                    if (i == 3) {
                        if (bool) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_223_ = this;
                            ((StageMaker) stagemaker_223_).bstage = stringbuilder.append(((StageMaker) stagemaker_223_).bstage).append("\r\n").toString();
                            bool = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_224_ = this;
                        ((StageMaker) stagemaker_224_).bstage = stringbuilder.append(((StageMaker) stagemaker_224_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("maxt")) {
                    int i_225_ = getint("maxt", string_186_, 0);
                    int i_226_ = getint("maxt", string_186_, 1);
                    i_183_ = i_226_;
                    int i_227_ = getint("maxt", string_186_, 2);
                    for (int i_228_ = 0; i_228_ < i_225_; i_228_++) {
                        ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[29], i_228_ * 4800 + i_227_, ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[29]).grat, i_226_, 90);
                        if (i == 0)
                            ((StageMaker) this).xnob++;
                        else
                            ((StageMaker) this).nob++;
                    }
                    if (i == 3) {
                        if (bool) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_229_ = this;
                            ((StageMaker) stagemaker_229_).bstage = stringbuilder.append(((StageMaker) stagemaker_229_).bstage).append("\r\n").toString();
                            bool = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_230_ = this;
                        ((StageMaker) stagemaker_230_).bstage = stringbuilder.append(((StageMaker) stagemaker_230_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
                if (string_186_.startsWith("maxb")) {
                    int i_231_ = getint("maxb", string_186_, 0);
                    int i_232_ = getint("maxb", string_186_, 1);
                    i_184_ = i_232_;
                    int i_233_ = getint("maxb", string_186_, 2);
                    for (int i_234_ = 0; i_234_ < i_231_; i_234_++) {
                        ((StageMaker) this).co[((StageMaker) this).nob] = new ContO(((StageMaker) this).bco[29], i_234_ * 4800 + i_233_, ((Medium) ((StageMaker) this).m).ground - ((ContO) ((StageMaker) this).bco[29]).grat, i_232_, -90);
                        if (i == 0)
                            ((StageMaker) this).xnob++;
                        else
                            ((StageMaker) this).nob++;
                    }
                    if (i == 3) {
                        if (bool) {
                            StringBuilder stringbuilder = new StringBuilder();
                            StageMaker stagemaker_235_ = this;
                            ((StageMaker) stagemaker_235_).bstage = stringbuilder.append(((StageMaker) stagemaker_235_).bstage).append("\r\n").toString();
                            bool = false;
                        }
                        StringBuilder stringbuilder = new StringBuilder();
                        StageMaker stagemaker_236_ = this;
                        ((StageMaker) stagemaker_236_).bstage = stringbuilder.append(((StageMaker) stagemaker_236_).bstage).append("").append(string_186_).append("\r\n").toString();
                    }
                }
            }
            datainputstream.close();
            ((StageMaker) this).m.newpolys(i_182_, i_181_ - i_182_, i_184_, i_183_ - i_184_, ((StageMaker) this).t, ((StageMaker) this).nob);
            ((StageMaker) this).m.newclouds(i_182_, i_181_, i_184_, i_183_);
            ((StageMaker) this).m.newmountains(i_182_, i_181_, i_184_, i_183_);
            ((StageMaker) this).m.newstars();
        } catch (Exception exception) {
            System.out.println(new StringBuilder().append("Error in stage ").append(((StageMaker) this).stagename).toString());
            System.out.println(new StringBuilder().append("").append(exception).toString());
            System.out.println(new StringBuilder().append("At line: ").append(string_186_).toString());
            ((StageMaker) this).errd = 6;
            if (((CheckPoints) ((StageMaker) this).cp).fn >= 5) //file name size????
                ((StageMaker) this).errd = 5;
            if (((Trackers) ((StageMaker) this).t).nt >= 6700000) //trackers limit
                ((StageMaker) this).errd = 1;
            if (((CheckPoints) ((StageMaker) this).cp).n >= 10000) // )p etc limit
                ((StageMaker) this).errd = 2;
            if (((StageMaker) this).nob >= 10000) //part limit
                ((StageMaker) this).errd = 4;
        }
        if (((Medium) ((StageMaker) this).m).nrw * ((Medium) ((StageMaker) this).m).ncl >= 16000)
            ((StageMaker) this).errd = 3;
        if (((StageMaker) this).xnob >= 10000)
            ((StageMaker) this).errd = 4;
        if (i == 3 && ((StageMaker) this).bstage.indexOf("set(47,0,0,0)") == -1 && ((StageMaker) this).bstage.indexOf("set(48,0,0,0)") == -1) {
            StringBuilder stringbuilder = new StringBuilder();
            StageMaker stagemaker_237_ = this;
            ((StageMaker) stagemaker_237_).bstage = stringbuilder.append(((StageMaker) stagemaker_237_).bstage).append("set(47,0,0,0)\r\n").toString();
        }
    }
    
    public void newstage() {
        if (!((StageMaker) this).srch.getText().equals("")) {
            File file = new File(new StringBuilder().append("mystages/").append(((StageMaker) this).srch.getText()).append(".txt").toString());
            if (!file.exists()) {
                ((StageMaker) this).stagename = ((StageMaker) this).srch.getText();
                ((StageMaker) this).tstage = new StringBuilder().append("snap(0,0,0)\r\nsky(191,215,255)\r\nclouds(255,255,255,5,-1000)\r\nfog(195,207,230)\r\nground(192,194,202)\r\ntexture(0,0,0,50)\r\nfadefrom(5000)\r\ndensity(5)\r\nmountains(").append((int) (Math.random() * 100000.0)).append(")\r\nnlaps(5)\r\n\r\n").toString();
                if (((StageMaker) this).strtyp.getSelectedIndex() == 1)
                    ((StageMaker) this).bstage = "set(48,0,0,0)\r\n";
                else
                    ((StageMaker) this).bstage = "set(47,0,0,0)\r\n";
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_238_ = this;
                ((StageMaker) stagemaker_238_).bstage = stringbuilder.append(((StageMaker) stagemaker_238_).bstage).append("\r\nmaxl(3,-7200,-4800)\r\nmaxb(3,-7200,-4800)\r\nmaxr(3,7200,-4800)\r\nmaxt(3,7200,-4800)\r\n").toString();
                savefile();
                ((StageMaker) this).strtyp.hide();
                ((StageMaker) this).srch.hide();
                ((StageMaker) this).sfase = 0;
                ((StageMaker) this).tabed = -2;
            } else
                JOptionPane.showMessageDialog(null, "A stage with that name already exists, please choose another name!", "Stage Maker", 1);
        } else
            JOptionPane.showMessageDialog(null, "Please enter a stage name first!", "Stage Maker", 1);
    }
    
    public void sortop() {
        ((StageMaker) this).tstage = new StringBuilder().append("snap(").append(((Medium) ((StageMaker) this).m).snap[0]).append(",").append(((Medium) ((StageMaker) this).m).snap[1]).append(",").append(((Medium) ((StageMaker) this).m).snap[2]).append(")\r\nsky(").append(((StageMaker) this).csky[0]).append(",").append(((StageMaker) this).csky[1]).append(",").append(((StageMaker) this).csky[2]).append(")\r\nfog(").append(((StageMaker) this).cfade[0]).append(",").append(((StageMaker) this).cfade[1]).append(",").append(((StageMaker) this).cfade[2]).append(")\r\nclouds(").append(((StageMaker) this).cldd[0]).append(",").append(((StageMaker) this).cldd[1]).append(",").append(((StageMaker) this).cldd[2]).append(",").append(((StageMaker) this).cldd[3]).append(",").append(((StageMaker) this).cldd[4]).append(")\r\nground(").append(((StageMaker) this).cgrnd[0]).append(",").append(((StageMaker) this).cgrnd[1]).append(",").append(((StageMaker) this).cgrnd[2]).append(")\r\ntexture(").append(((StageMaker) this).texture[0]).append(",").append(((StageMaker) this).texture[1]).append(",").append(((StageMaker) this).texture[2]).append(",").append(((StageMaker) this).texture[3]).append(")\r\nfadefrom(").append(((StageMaker) this).origfade).append(")\r\ndensity(").append((((Medium) ((StageMaker) this).m).fogd + 1) / 2 - 1).append(")\r\nmountains(").append(((Medium) ((StageMaker) this).m).mgen).append(")\r\nnlaps(").append(((CheckPoints) ((StageMaker) this).cp).nlaps).append(")\r\n").toString();
        if (!((StageMaker) this).trackname.equals("")) {
            StringBuilder stringbuilder = new StringBuilder();
            StageMaker stagemaker_239_ = this;
            ((StageMaker) stagemaker_239_).tstage = stringbuilder.append(((StageMaker) stagemaker_239_).tstage).append("soundtrack(").append(((StageMaker) this).trackname).append(",").append(((StageMaker) this).trackvol).append(",").append(((StageMaker) this).tracksize).append(")\r\n").toString();
        }
        for (int i = 0; i < 3; i++)
            ((StageMaker) this).snap[i] = (int) ((float) ((Medium) ((StageMaker) this).m).snap[i] / 1.2F + 50.0F);
        if (((StageMaker) this).snap[0] + ((StageMaker) this).snap[1] + ((StageMaker) this).snap[2] <= 110) {
            StringBuilder stringbuilder = new StringBuilder();
            StageMaker stagemaker_240_ = this;
            ((StageMaker) stagemaker_240_).tstage = stringbuilder.append(((StageMaker) stagemaker_240_).tstage).append("lightson()\r\n").toString();
        }
        StringBuilder stringbuilder = new StringBuilder();
        StageMaker stagemaker_241_ = this;
        ((StageMaker) stagemaker_241_).tstage = stringbuilder.append(((StageMaker) stagemaker_241_).tstage).append("\r\n").toString();
    }
    
    public void sortstage() {
        int[] is = new int[((StageMaker) this).nob * 2];
        int[] is_242_ = new int[((StageMaker) this).nob * 2];
        for (int i = 0; i < ((StageMaker) this).nob; i++)
            is[i] = 0;
        int i = 0;
        int i_243_ = 0;
        is_242_[i_243_] = 0;
        i_243_++;
        boolean bool = false;
        int i_244_ = 0;
        while (!bool) {
            int[] is_245_ = { ((ContO) ((StageMaker) this).co[i]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i]).colok][0], ((ContO) ((StageMaker) this).co[i]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i]).colok][2] };
            int[] is_246_ = { ((ContO) ((StageMaker) this).co[i]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i]).colok][1], ((ContO) ((StageMaker) this).co[i]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i]).colok][3] };
            int i_247_ = ((ContO) ((StageMaker) this).co[i]).roofat;
            if (((ContO) ((StageMaker) this).co[i]).colok == 2)
                i_247_ += 30;
            if (((ContO) ((StageMaker) this).co[i]).colok == 3)
                i_247_ -= 30;
            if (((ContO) ((StageMaker) this).co[i]).colok == 15)
                i_247_ -= 90;
            if (((ContO) ((StageMaker) this).co[i]).colok == 20)
                i_247_ -= 180;
            if (((ContO) ((StageMaker) this).co[i]).colok == 26)
                i_247_ -= 90;
            rot(is_245_, is_246_, ((ContO) ((StageMaker) this).co[i]).x, ((ContO) ((StageMaker) this).co[i]).z, i_247_, 2);
            int i_248_ = -1;
            int i_249_ = -1;
            if (i_244_ != 0) {
                for (int i_250_ = 0; i_250_ < ((StageMaker) this).nob; i_250_++) {
                    boolean bool_251_ = false;
                    if (i_243_ == 2 && i_250_ == 0)
                        bool_251_ = true;
                    if (i != i_250_ && !bool_251_ && is[i_250_] == 0 && (((ContO) ((StageMaker) this).co[i_250_]).colok <= 14 || ((ContO) ((StageMaker) this).co[i_250_]).colok >= 33) && (((ContO) ((StageMaker) this).co[i_250_]).colok < 39 || ((ContO) ((StageMaker) this).co[i_250_]).colok >= 46) && ((ContO) ((StageMaker) this).co[i_250_]).colok < 52) {
                        int i_252_ = 0;
                        if (((ContO) ((StageMaker) this).co[i_250_]).colok != 2 && ((ContO) ((StageMaker) this).co[i_250_]).colok != 3 && ((ContO) ((StageMaker) this).co[i_250_]).colok != 4 && ((ContO) ((StageMaker) this).co[i_250_]).colok != 7 && ((ContO) ((StageMaker) this).co[i_250_]).colok != 9) {
                            if (i_244_ == 1 && ((ContO) ((StageMaker) this).co[i_250_]).z > ((ContO) ((StageMaker) this).co[i]).z && Math.abs(((ContO) ((StageMaker) this).co[i_250_]).x - ((ContO) ((StageMaker) this).co[i]).x) < 1000 && (((ContO) ((StageMaker) this).co[i_250_]).roofat == 180 || ((ContO) ((StageMaker) this).co[i_250_]).roofat == 0))
                                i_252_ = 1;
                            if (i_244_ == 2 && ((ContO) ((StageMaker) this).co[i_250_]).z < ((ContO) ((StageMaker) this).co[i]).z && Math.abs(((ContO) ((StageMaker) this).co[i_250_]).x - ((ContO) ((StageMaker) this).co[i]).x) < 1000 && (((ContO) ((StageMaker) this).co[i_250_]).roofat == 180 || ((ContO) ((StageMaker) this).co[i_250_]).roofat == 0))
                                i_252_ = 1;
                            if (i_244_ == 3 && ((ContO) ((StageMaker) this).co[i_250_]).x > ((ContO) ((StageMaker) this).co[i]).x && Math.abs(((ContO) ((StageMaker) this).co[i_250_]).z - ((ContO) ((StageMaker) this).co[i]).z) < 1000 && (((ContO) ((StageMaker) this).co[i_250_]).roofat == 90 || ((ContO) ((StageMaker) this).co[i_250_]).roofat == -90))
                                i_252_ = 1;
                            if (i_244_ == 4 && ((ContO) ((StageMaker) this).co[i_250_]).x < ((ContO) ((StageMaker) this).co[i]).x && Math.abs(((ContO) ((StageMaker) this).co[i_250_]).z - ((ContO) ((StageMaker) this).co[i]).z) < 1000 && (((ContO) ((StageMaker) this).co[i_250_]).roofat == 90 || ((ContO) ((StageMaker) this).co[i_250_]).roofat == -90))
                                i_252_ = 1;
                        } else
                            i_252_ = 2;
                        if (i_252_ != 0) {
                            int[] is_253_ = { ((ContO) ((StageMaker) this).co[i_250_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_250_]).colok][0], ((ContO) ((StageMaker) this).co[i_250_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_250_]).colok][2] };
                            int[] is_254_ = { ((ContO) ((StageMaker) this).co[i_250_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_250_]).colok][1], ((ContO) ((StageMaker) this).co[i_250_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_250_]).colok][3] };
                            i_247_ = ((ContO) ((StageMaker) this).co[i_250_]).roofat;
                            if (((ContO) ((StageMaker) this).co[i_250_]).colok == 2)
                                i_247_ += 30;
                            if (((ContO) ((StageMaker) this).co[i_250_]).colok == 3)
                                i_247_ -= 30;
                            if (((ContO) ((StageMaker) this).co[i_250_]).colok == 15)
                                i_247_ -= 90;
                            if (((ContO) ((StageMaker) this).co[i_250_]).colok == 20)
                                i_247_ -= 180;
                            if (((ContO) ((StageMaker) this).co[i_250_]).colok == 26)
                                i_247_ -= 90;
                            rot(is_253_, is_254_, ((ContO) ((StageMaker) this).co[i_250_]).x, ((ContO) ((StageMaker) this).co[i_250_]).z, i_247_, 2);
                            boolean bool_255_ = false;
                            if (i_250_ != 0) {
                                int i_256_ = pyn(is_253_[0], is_245_[0], is_254_[0], is_246_[0]);
                                if (i_256_ >= 0 && (i_256_ < 100 || i_252_ != 2) && (i_256_ < i_248_ || i_248_ == -1)) {
                                    i_248_ = i_256_;
                                    i_249_ = i_250_;
                                }
                            }
                            int i_257_ = pyn(is_253_[1], is_245_[0], is_254_[1], is_246_[0]);
                            if (i_257_ >= 0 && (i_257_ < 100 || i_252_ != 2) && (i_257_ < i_248_ || i_248_ == -1)) {
                                i_248_ = i_257_;
                                i_249_ = i_250_;
                            }
                            if (i != 0) {
                                if (i_250_ != 0) {
                                    i_257_ = pyn(is_253_[0], is_245_[1], is_254_[0], is_246_[1]);
                                    if (i_257_ >= 0 && (i_257_ < 100 || i_252_ != 2) && i_257_ < i_248_) {
                                        i_248_ = i_257_;
                                        i_249_ = i_250_;
                                    }
                                }
                                i_257_ = pyn(is_253_[1], is_245_[1], is_254_[1], is_246_[1]);
                                if (i_257_ >= 0 && (i_257_ < 100 || i_252_ != 2) && i_257_ < i_248_) {
                                    i_248_ = i_257_;
                                    i_249_ = i_250_;
                                }
                            }
                        }
                    }
                }
            }
            if (i_249_ == -1) {
                for (int i_258_ = 0; i_258_ < ((StageMaker) this).nob; i_258_++) {
                    boolean bool_259_ = false;
                    if (i_243_ == 2 && i_258_ == 0)
                        bool_259_ = true;
                    if (i != i_258_ && !bool_259_ && is[i_258_] == 0 && (((ContO) ((StageMaker) this).co[i_258_]).colok <= 14 || ((ContO) ((StageMaker) this).co[i_258_]).colok >= 33) && (((ContO) ((StageMaker) this).co[i_258_]).colok < 39 || ((ContO) ((StageMaker) this).co[i_258_]).colok >= 46) && ((ContO) ((StageMaker) this).co[i_258_]).colok < 52) {
                        int[] is_260_ = { ((ContO) ((StageMaker) this).co[i_258_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_258_]).colok][0], ((ContO) ((StageMaker) this).co[i_258_]).x + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_258_]).colok][2] };
                        int[] is_261_ = { ((ContO) ((StageMaker) this).co[i_258_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_258_]).colok][1], ((ContO) ((StageMaker) this).co[i_258_]).z + ((StageMaker) this).atp[((ContO) ((StageMaker) this).co[i_258_]).colok][3] };
                        i_247_ = ((ContO) ((StageMaker) this).co[i_258_]).roofat;
                        if (((ContO) ((StageMaker) this).co[i_258_]).colok == 2)
                            i_247_ += 30;
                        if (((ContO) ((StageMaker) this).co[i_258_]).colok == 3)
                            i_247_ -= 30;
                        if (((ContO) ((StageMaker) this).co[i_258_]).colok == 15)
                            i_247_ -= 90;
                        if (((ContO) ((StageMaker) this).co[i_258_]).colok == 20)
                            i_247_ -= 180;
                        if (((ContO) ((StageMaker) this).co[i_258_]).colok == 26)
                            i_247_ -= 90;
                        rot(is_260_, is_261_, ((ContO) ((StageMaker) this).co[i_258_]).x, ((ContO) ((StageMaker) this).co[i_258_]).z, i_247_, 2);
                        boolean bool_262_ = false;
                        if (i_258_ != 0) {
                            int i_263_ = pyn(is_260_[0], is_245_[0], is_261_[0], is_246_[0]);
                            if (i_263_ >= 0 && (i_263_ < i_248_ || i_248_ == -1)) {
                                i_248_ = i_263_;
                                i_249_ = i_258_;
                            }
                        }
                        int i_264_ = pyn(is_260_[1], is_245_[0], is_261_[1], is_246_[0]);
                        if (i_264_ >= 0 && (i_264_ < i_248_ || i_248_ == -1)) {
                            i_248_ = i_264_;
                            i_249_ = i_258_;
                        }
                        if (i != 0) {
                            if (i_258_ != 0) {
                                i_264_ = pyn(is_260_[0], is_245_[1], is_261_[0], is_246_[1]);
                                if (i_264_ >= 0 && i_264_ < i_248_) {
                                    i_248_ = i_264_;
                                    i_249_ = i_258_;
                                }
                            }
                            i_264_ = pyn(is_260_[1], is_245_[1], is_261_[1], is_246_[1]);
                            if (i_264_ >= 0 && i_264_ < i_248_) {
                                i_248_ = i_264_;
                                i_249_ = i_258_;
                            }
                        }
                    }
                }
            }
            if (i_249_ != -1) {
                i_244_ = 0;
                if (((ContO) ((StageMaker) this).co[i_249_]).colok != 2 && ((ContO) ((StageMaker) this).co[i_249_]).colok != 3 && ((ContO) ((StageMaker) this).co[i_249_]).colok != 4 && ((ContO) ((StageMaker) this).co[i_249_]).colok != 7 && ((ContO) ((StageMaker) this).co[i_249_]).colok != 9) {
                    if ((((ContO) ((StageMaker) this).co[i_249_]).roofat == 180 || ((ContO) ((StageMaker) this).co[i_249_]).roofat == 0) && ((ContO) ((StageMaker) this).co[i_249_]).z > ((ContO) ((StageMaker) this).co[i]).z)
                        i_244_ = 1;
                    if ((((ContO) ((StageMaker) this).co[i_249_]).roofat == 180 || ((ContO) ((StageMaker) this).co[i_249_]).roofat == 0) && ((ContO) ((StageMaker) this).co[i_249_]).z < ((ContO) ((StageMaker) this).co[i]).z)
                        i_244_ = 2;
                    if ((((ContO) ((StageMaker) this).co[i_249_]).roofat == 90 || ((ContO) ((StageMaker) this).co[i_249_]).roofat == -90) && ((ContO) ((StageMaker) this).co[i_249_]).x > ((ContO) ((StageMaker) this).co[i]).x)
                        i_244_ = 3;
                    if ((((ContO) ((StageMaker) this).co[i_249_]).roofat == 90 || ((ContO) ((StageMaker) this).co[i_249_]).roofat == -90) && ((ContO) ((StageMaker) this).co[i_249_]).x < ((ContO) ((StageMaker) this).co[i]).x)
                        i_244_ = 4;
                }
                if (((ContO) ((StageMaker) this).co[i_249_]).colok == 4 || ((ContO) ((StageMaker) this).co[i_249_]).colok == 7 || ((ContO) ((StageMaker) this).co[i_249_]).colok == 9)
                    is[i_249_] = 2;
                else
                    is[i_249_] = 1;
                if (((ContO) ((StageMaker) this).co[i_249_]).colok >= 46 && ((ContO) ((StageMaker) this).co[i_249_]).colok <= 51)
                    is[i_249_] = 6;
                i = i_249_;
                if (i_249_ == 0) {
                    is[0] = 1;
                    bool = true;
                } else {
                    is_242_[i_243_] = i_249_;
                    i_243_++;
                }
            } else {
                is[0] = 1;
                bool = true;
            }
        }
        for (int i_265_ = 0; i_265_ < ((StageMaker) this).nob; i_265_++) {
            if (is[i_265_] == 0 && (((ContO) ((StageMaker) this).co[i_265_]).colok <= 14 || ((ContO) ((StageMaker) this).co[i_265_]).colok >= 33) && (((ContO) ((StageMaker) this).co[i_265_]).colok < 39 || ((ContO) ((StageMaker) this).co[i_265_]).colok >= 46) && ((ContO) ((StageMaker) this).co[i_265_]).colok < 52) {
                is_242_[i_243_] = i_265_;
                i_243_++;
            }
        }
        for (int i_266_ = 0; i_266_ < i_243_; i_266_++) {
            if (((ContO) ((StageMaker) this).co[is_242_[i_266_]]).colok >= 46 && ((ContO) ((StageMaker) this).co[is_242_[i_266_]]).colok <= 51) {
                for (int i_267_ = i_266_ + 1; i_267_ < i_243_; i_267_++) {
                    int i_268_ = pyn(((ContO) ((StageMaker) this).co[is_242_[i_266_]]).x, ((ContO) ((StageMaker) this).co[is_242_[i_267_]]).x, ((ContO) ((StageMaker) this).co[is_242_[i_266_]]).z, ((ContO) ((StageMaker) this).co[is_242_[i_267_]]).z);
                    if (i_268_ >= 0 && (((ContO) ((StageMaker) this).co[is_242_[i_267_]]).colok < 46 || ((ContO) ((StageMaker) this).co[is_242_[i_266_]]).colok > 51) && i_268_ < (((ContO) ((StageMaker) this).co[is_242_[i_266_]]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_267_]]).maxR) / 100 * ((((ContO) ((StageMaker) this).co[is_242_[i_266_]]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_267_]]).maxR) / 100)) {
                        int i_269_ = is_242_[i_267_];
                        for (int i_270_ = i_267_; i_270_ > i_266_; i_270_--)
                            is_242_[i_270_] = is_242_[i_270_ - 1];
                        is_242_[i_266_] = i_269_;
                        is[is_242_[i_266_]] = 0;
                        i_266_++;
                    }
                }
            }
        }
        int i_271_ = 1;
        for (int i_272_ = 0; i_272_ < ((CheckPoints) ((StageMaker) this).cp).nsp; i_272_++) {
            for (int i_273_ = 0; i_273_ < ((StageMaker) this).nob; i_273_++) {
                if (((ContO) ((StageMaker) this).co[i_273_]).wh == i_272_ + 1 && (((ContO) ((StageMaker) this).co[i_273_]).colok == 30 || ((ContO) ((StageMaker) this).co[i_273_]).colok == 32 || ((ContO) ((StageMaker) this).co[i_273_]).colok == 54)) {
                    int i_274_ = -1;
                    int i_275_ = -1;
                    for (int i_276_ = i_271_; i_276_ < i_243_; i_276_++) {
                        if (((ContO) ((StageMaker) this).co[is_242_[i_276_]]).colok != 30 && ((ContO) ((StageMaker) this).co[is_242_[i_276_]]).colok != 32 && ((ContO) ((StageMaker) this).co[is_242_[i_276_]]).colok != 54) {
                            int i_277_ = pyn(((ContO) ((StageMaker) this).co[i_273_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_276_]]).x, ((ContO) ((StageMaker) this).co[i_273_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_276_]]).z);
                            if (i_277_ >= 0 && (i_277_ < i_274_ || i_274_ == -1)) {
                                i_274_ = i_277_;
                                i_275_ = i_276_;
                            }
                        }
                    }
                    if (i_275_ != -1) {
                        is[is_242_[i_275_]] = 0;
                        for (int i_278_ = i_243_; i_278_ > i_275_; i_278_--)
                            is_242_[i_278_] = is_242_[i_278_ - 1];
                        is_242_[i_275_ + 1] = i_273_;
                        i_271_ = i_275_ + 1;
                        i_243_++;
                    } else {
                        is_242_[i_243_] = i_273_;
                        i_271_ = i_243_;
                        i_243_++;
                    }
                }
            }
        }
        for (int i_279_ = 0; i_279_ < ((StageMaker) this).nob; i_279_++) {
            if (((ContO) ((StageMaker) this).co[i_279_]).wh == 0 && (((ContO) ((StageMaker) this).co[i_279_]).colok == 30 || ((ContO) ((StageMaker) this).co[i_279_]).colok == 32 || ((ContO) ((StageMaker) this).co[i_279_]).colok == 54)) {
                int i_280_ = -1;
                int i_281_ = -1;
                for (int i_282_ = i_271_; i_282_ < i_243_; i_282_++) {
                    if (((ContO) ((StageMaker) this).co[is_242_[i_282_]]).colok != 30 && ((ContO) ((StageMaker) this).co[is_242_[i_282_]]).colok != 32 && ((ContO) ((StageMaker) this).co[is_242_[i_282_]]).colok != 54) {
                        int i_283_ = pyn(((ContO) ((StageMaker) this).co[i_279_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_282_]]).x, ((ContO) ((StageMaker) this).co[i_279_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_282_]]).z);
                        if (i_283_ >= 0 && (i_283_ < i_280_ || i_280_ == -1)) {
                            i_280_ = i_283_;
                            i_281_ = i_282_;
                        }
                    }
                }
                if (i_281_ != -1) {
                    is[is_242_[i_281_]] = 0;
                    for (int i_284_ = i_243_; i_284_ > i_281_; i_284_--)
                        is_242_[i_284_] = is_242_[i_284_ - 1];
                    is_242_[i_281_ + 1] = i_279_;
                    i_243_++;
                } else {
                    is_242_[i_243_] = i_279_;
                    i_243_++;
                }
            }
        }
        for (int i_285_ = 0; i_285_ < ((StageMaker) this).nob; i_285_++) {
            if (((ContO) ((StageMaker) this).co[i_285_]).colok == 31) {
                int i_286_ = -1;
                int i_287_ = -1;
                for (int i_288_ = 0; i_288_ < i_243_; i_288_++) {
                    int i_289_ = pyn(((ContO) ((StageMaker) this).co[i_285_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_288_]]).x, ((ContO) ((StageMaker) this).co[i_285_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_288_]]).z);
                    if (i_289_ >= 0 && (i_289_ < i_286_ || i_286_ == -1)) {
                        i_286_ = i_289_;
                        i_287_ = i_288_;
                    }
                }
                if (i_287_ != -1) {
                    for (int i_290_ = i_243_; i_290_ > i_287_; i_290_--)
                        is_242_[i_290_] = is_242_[i_290_ - 1];
                    is_242_[i_287_] = i_285_;
                    i_243_++;
                } else {
                    is_242_[i_243_] = i_285_;
                    i_243_++;
                }
            }
        }
        for (int i_291_ = 0; i_291_ < ((StageMaker) this).nob; i_291_++) {
            if (((ContO) ((StageMaker) this).co[i_291_]).colok == 15 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 27 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 28 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 41 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 44 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 52 || ((ContO) ((StageMaker) this).co[i_291_]).colok == 53) {
                int i_292_ = -1;
                for (int i_293_ = 0; i_293_ < i_243_; i_293_++) {
                    if ((((ContO) ((StageMaker) this).co[is_242_[i_293_]]).colok <= 14 || ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).colok >= 33) && ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).colok < 39) {
                        int i_294_ = pyn(((ContO) ((StageMaker) this).co[i_291_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).x, ((ContO) ((StageMaker) this).co[i_291_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).z);
                        if (i_294_ >= 0 && i_294_ < (((ContO) ((StageMaker) this).co[i_291_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).maxR) / 100 * ((((ContO) ((StageMaker) this).co[i_291_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_293_]]).maxR) / 100))
                            i_292_ = i_293_;
                    }
                }
                if (i_292_ != -1) {
                    for (int i_295_ = i_243_; i_295_ > i_292_; i_295_--)
                        is_242_[i_295_] = is_242_[i_295_ - 1];
                    is_242_[i_292_ + 1] = i_291_;
                    i_243_++;
                } else {
                    is_242_[i_243_] = i_291_;
                    i_243_++;
                }
            }
        }
        for (int i_296_ = 0; i_296_ < ((StageMaker) this).nob; i_296_++) {
            if (((ContO) ((StageMaker) this).co[i_296_]).colok >= 16 && ((ContO) ((StageMaker) this).co[i_296_]).colok <= 25 || ((ContO) ((StageMaker) this).co[i_296_]).colok == 40 || ((ContO) ((StageMaker) this).co[i_296_]).colok == 42 || ((ContO) ((StageMaker) this).co[i_296_]).colok == 43 || ((ContO) ((StageMaker) this).co[i_296_]).colok == 45) {
                int i_297_ = -1;
                for (int i_298_ = 0; i_298_ < i_243_; i_298_++) {
                    if ((((ContO) ((StageMaker) this).co[is_242_[i_298_]]).colok <= 14 || ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).colok >= 33) && ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).colok < 39) {
                        int i_299_ = pyn(((ContO) ((StageMaker) this).co[i_296_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).x, ((ContO) ((StageMaker) this).co[i_296_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).z);
                        if (i_299_ >= 0 && i_299_ < (((ContO) ((StageMaker) this).co[i_296_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).maxR) / 100 * ((((ContO) ((StageMaker) this).co[i_296_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_298_]]).maxR) / 100)) {
                            if (is[is_242_[i_298_]] != 0) {
                                is[is_242_[i_298_]] = 0;
                                if (((ContO) ((StageMaker) this).co[i_296_]).colok != 20)
                                    is[i_296_] = 3;
                                else
                                    is[i_296_] = 5;
                            }
                            i_297_ = i_298_;
                        }
                    }
                }
                if (i_297_ != -1) {
                    /* empty */
                }
                if (i_297_ != -1) {
                    for (int i_300_ = i_243_; i_300_ > i_297_; i_300_--)
                        is_242_[i_300_] = is_242_[i_300_ - 1];
                    is_242_[i_297_ + 1] = i_296_;
                    i_243_++;
                } else {
                    is_242_[i_243_] = i_296_;
                    i_243_++;
                }
            }
        }
        for (int i_301_ = 0; i_301_ < ((StageMaker) this).nob; i_301_++) {
            if (((ContO) ((StageMaker) this).co[i_301_]).colok == 26 || ((ContO) ((StageMaker) this).co[i_301_]).colok == 39) {
                boolean bool_302_ = false;
                if (Math.random() > Math.random()) {
                    bool_302_ = true;
                    if (((ContO) ((StageMaker) this).co[i_301_]).colok == 39) {
                        if (Math.random() > Math.random())
                            bool_302_ = false;
                        else if (Math.random() > Math.random())
                            bool_302_ = false;
                    }
                }
                int i_303_ = -1;
                for (int i_304_ = 0; i_304_ < i_243_; i_304_++) {
                    if ((((ContO) ((StageMaker) this).co[is_242_[i_304_]]).colok <= 14 || ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).colok >= 33) && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).colok < 39) {
                        int i_305_ = pyn(((ContO) ((StageMaker) this).co[i_301_]).x, ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).x, ((ContO) ((StageMaker) this).co[i_301_]).z, ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).z);
                        if (i_305_ >= 0 && i_305_ < (((ContO) ((StageMaker) this).co[i_301_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).maxR) / 100 * ((((ContO) ((StageMaker) this).co[i_301_]).maxR + ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).maxR) / 100)) {
                            boolean bool_306_ = false;
                            if (((ContO) ((StageMaker) this).co[i_301_]).colok == 26) {
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 90 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).x > ((ContO) ((StageMaker) this).co[i_301_]).x)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == -90 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).x < ((ContO) ((StageMaker) this).co[i_301_]).x)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 0 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).z < ((ContO) ((StageMaker) this).co[i_301_]).z)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 180 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).z > ((ContO) ((StageMaker) this).co[i_301_]).z)
                                    bool_306_ = true;
                            }
                            if (((ContO) ((StageMaker) this).co[i_301_]).colok == 39) {
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 90 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).z > ((ContO) ((StageMaker) this).co[i_301_]).z)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == -90 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).z < ((ContO) ((StageMaker) this).co[i_301_]).z)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 0 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).x > ((ContO) ((StageMaker) this).co[i_301_]).x)
                                    bool_306_ = true;
                                if (((ContO) ((StageMaker) this).co[i_301_]).roofat == 180 && ((ContO) ((StageMaker) this).co[is_242_[i_304_]]).x < ((ContO) ((StageMaker) this).co[i_301_]).x)
                                    bool_306_ = true;
                            }
                            if (bool_306_) {
                                if (is[is_242_[i_304_]] == 1 && bool_302_) {
                                    is[is_242_[i_304_]] = 0;
                                    is[i_301_] = 4;
                                }
                                i_303_ = i_304_;
                            }
                        }
                    }
                }
                if (i_303_ != -1) {
                    for (int i_307_ = i_243_; i_307_ > i_303_; i_307_--)
                        is_242_[i_307_] = is_242_[i_307_ - 1];
                    is_242_[i_303_ + 1] = i_301_;
                    i_243_++;
                } else {
                    is_242_[i_243_] = i_301_;
                    i_243_++;
                }
            }
        }
        for (int i_308_ = 0; i_308_ < ((StageMaker) this).nob; i_308_++) {
            if (((ContO) ((StageMaker) this).co[i_308_]).colok >= 55 && ((ContO) ((StageMaker) this).co[i_308_]).colok <= 65 || ((ContO) ((StageMaker) this).co[i_308_]).colok == 66) {
                is_242_[i_243_] = i_308_;
                i_243_++;
            }
        }
        int i_309_ = 0;
        int i_310_ = 0;
        int i_311_ = 0;
        int i_312_ = 0;
        ((StageMaker) this).bstage = "";
        for (int i_313_ = 0; i_313_ < i_243_; i_313_++) {
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok != 30 && ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok != 31 && ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok != 32 && ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok != 54 && ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok != 66) {
                String string = "";
                if (is[is_242_[i_313_]] == 1)
                    string = "p";
                if (is[is_242_[i_313_]] == 2)
                    string = "pt";
                if (is[is_242_[i_313_]] == 3)
                    string = "pr";
                if (is[is_242_[i_313_]] == 4)
                    string = "ph";
                if (is[is_242_[i_313_]] == 5)
                    string = "pl";
                if (is[is_242_[i_313_]] == 6)
                    string = "pr";
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_314_ = this;
                ((StageMaker) stagemaker_314_).bstage = stringbuilder.append(((StageMaker) stagemaker_314_).bstage).append("set(").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat).append(")").append(string).append("\r\n").toString();
            }
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok == 30 || ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok == 32) {
                if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat == 180)
                    ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat = 0;
                String string = "";
                if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).wh != 0)
                    string = "r";
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_315_ = this;
                ((StageMaker) stagemaker_315_).bstage = stringbuilder.append(((StageMaker) stagemaker_315_).bstage).append("chk(").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat).append(")").append(string).append("\r\n").toString();
            }
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok == 54) {
                if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat == 180)
                    ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat = 0;
                String string = "";
                if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).wh != 0)
                    string = "r";
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_316_ = this;
                ((StageMaker) stagemaker_316_).bstage = stringbuilder.append(((StageMaker) stagemaker_316_).bstage).append("chk(").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).y).append(")").append(string).append("\r\n").toString();
            }
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok == 31) {
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_317_ = this;
                ((StageMaker) stagemaker_317_).bstage = stringbuilder.append(((StageMaker) stagemaker_317_).bstage).append("fix(").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok + 10).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).y).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).roofat).append(")\r\n").toString();
            }
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).colok == 66) {
                StringBuilder stringbuilder = new StringBuilder();
                StageMaker stagemaker_318_ = this;
                ((StageMaker) stagemaker_318_).bstage = stringbuilder.append(((StageMaker) stagemaker_318_).bstage).append("pile(").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).srz).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).srx).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).sry).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x).append(",").append(((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z).append(")\r\n").toString();
            }
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x + ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR > i_309_)
                i_309_ = ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x + ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR;
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x - ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR < i_311_)
                i_311_ = ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).x - ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR;
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z + ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR > i_310_)
                i_310_ = ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z + ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR;
            if (((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z - ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR < i_312_)
                i_312_ = ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).z - ((ContO) ((StageMaker) this).co[is_242_[i_313_]]).maxR;
        }
        int i_319_ = i_311_ - 0;
        int i_320_ = i_309_ + 0;
        int i_321_ = (int) ((float) (i_320_ - i_319_) / 4800.0F) + 1;
        int i_322_ = (i_321_ * 4800 - (i_320_ - i_319_)) / 2;
        i_319_ -= i_322_;
        i_320_ += i_322_;
        int i_323_ = i_319_ + 2400;
        int i_324_ = i_312_ - 0;
        int i_325_ = i_310_ + 0;
        int i_326_ = (int) ((float) (i_325_ - i_324_) / 4800.0F) + 1;
        i_322_ = (i_326_ * 4800 - (i_325_ - i_324_)) / 2;
        i_324_ -= i_322_;
        i_325_ += i_322_;
        int i_327_ = i_324_ + 2400;
        StringBuilder stringbuilder = new StringBuilder();
        StageMaker stagemaker_328_ = this;
        ((StageMaker) stagemaker_328_).bstage = stringbuilder.append(((StageMaker) stagemaker_328_).bstage).append("\r\nmaxl(").append(i_326_).append(",").append(i_319_).append(",").append(i_327_).append(")\r\nmaxb(").append(i_321_).append(",").append(i_324_).append(",").append(i_323_).append(")\r\nmaxr(").append(i_326_).append(",").append(i_320_).append(",").append(i_327_).append(")\r\nmaxt(").append(i_321_).append(",").append(i_325_).append(",").append(i_323_).append(")\r\n").toString();
    }
    
    public void savefile() {
        try {
            File file = new File("mystages/");
            if (!file.exists())
                file.mkdirs();
            file = new File(new StringBuilder().append("mystages/").append(((StageMaker) this).stagename).append(".txt").toString());
            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
            bufferedwriter.write(((StageMaker) this).tstage);
            bufferedwriter.write(((StageMaker) this).bstage);
            bufferedwriter.close();
            Object object = null;
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to save file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
        savesettings();
    }
    
    public void renstage(String string) {
        if (string.equals(""))
            JOptionPane.showMessageDialog(null, "Please Enter a New Stage Name!\n", "Stage Maker", 1);
        else {
            try {
                File file = new File(new StringBuilder().append("mystages/").append(((StageMaker) this).stagename).append(".txt").toString());
                File file_329_ = new File(new StringBuilder().append("mystages/").append(string).append(".txt").toString());
                if (file.renameTo(file_329_)) {
                    ((StageMaker) this).stagename = string;
                    ((StageMaker) this).sfase = 0;
                    hidefields();
                    ((StageMaker) this).tabed = -2;
                } else
                    JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to rename stage to: '").append(string).append("', possible reason: stage name already used!\n").toString(), "Stage Maker", 1);
            } catch (Exception exception) {
                JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to rename file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
            }
        }
    }
    
    public void delstage(String string) {
        try {
            File file = new File(new StringBuilder().append("mystages/").append(string).append(".txt").toString());
            file.delete();
            ((StageMaker) this).slstage.remove(string);
            ((StageMaker) this).slstage.select(0);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to delete file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
    }
    
    public void deltrack() {
        try {
            File file = new File(new StringBuilder().append("mystages/mymusic/").append(((StageMaker) this).tracks.getSelectedItem()).append(".zip").toString());
            file.delete();
            if (((StageMaker) this).trackname.equals(((StageMaker) this).tracks.getSelectedItem())) {
                ((StageMaker) this).trackname = "";
                sortop();
                savefile();
            }
            ((StageMaker) this).tracks.remove(((StageMaker) this).tracks.getSelectedItem());
            ((StageMaker) this).tracks.select(0);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, new StringBuilder().append("Unable to delete file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
    }
    
    public void loadsettings() {
        try {
            File file = new File("mystages/settings.data");
            if (file.exists()) {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string = bufferedreader.readLine();
                if (string != null) {
                    ((StageMaker) this).sstage = string;
                    ((StageMaker) this).stagename = ((StageMaker) this).sstage;
                }
                string = bufferedreader.readLine();
                if (string != null) {
                    ((StageMaker) this).suser = string;
                    if (!((StageMaker) this).suser.equals("Horaks"))
                        ((StageMaker) this).tnick.setText(((StageMaker) this).suser);
                }
                bufferedreader.close();
                Object object = null;
            }
        } catch (Exception exception) {
            /* empty */
        }
    }
    
    public void savesettings() {
        if (!((StageMaker) this).sstage.equals(((StageMaker) this).stagename) || !((StageMaker) this).suser.equals(((StageMaker) this).tnick.getText())) {
            String string = new StringBuilder().append("").append(((StageMaker) this).stagename).append("\n").append(((StageMaker) this).tnick.getText()).append("\n\n").toString();
            ((StageMaker) this).sstage = ((StageMaker) this).stagename;
            ((StageMaker) this).suser = ((StageMaker) this).tnick.getText();
            try {
                File file = new File("mystages/");
                if (!file.exists())
                    file.mkdirs();
                file = new File("mystages/settings.data");
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                bufferedwriter.write(string);
                bufferedwriter.close();
                Object object = null;
            } catch (Exception exception) {
                /* empty */
            }
        }
    }
    
    public void fixtext(TextField textfield) {
        String string = textfield.getText();
        string = string.replace('\"', '#');
        String string_330_ = "\\";
        String string_331_ = "";
        int i = 0;
        int i_332_ = -1;
        ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
        for (/**/; i < string.length(); i++) {
            String string_333_ = new StringBuilder().append("").append(string.charAt(i)).toString();
            if (string_333_.equals("|") || string_333_.equals(",") || string_333_.equals("(") || string_333_.equals(")") || string_333_.equals("#") || string_333_.equals(string_330_) || string_333_.equals("!") || string_333_.equals("?") || string_333_.equals("~") || string_333_.equals(".") || string_333_.equals("@") || string_333_.equals("$") || string_333_.equals("%") || string_333_.equals("^") || string_333_.equals("&") || string_333_.equals("*") || string_333_.equals("+") || string_333_.equals("=") || string_333_.equals(">") || string_333_.equals("<") || string_333_.equals("/") || string_333_.equals(";") || string_333_.equals(":") || ((StageMaker) this).ftm.stringWidth(string_331_) > 274)
                i_332_ = i;
            else
                string_331_ = new StringBuilder().append(string_331_).append(string_333_).toString();
        }
        if (i_332_ != -1) {
            textfield.setText(string_331_);
            textfield.select(i_332_, i_332_);
        }
    }
    
    public void rot(int[] is, int[] is_334_, int i, int i_335_, int i_336_, int i_337_) {
        if (i_336_ != 0) {
            for (int i_338_ = 0; i_338_ < i_337_; i_338_++) {
                int i_339_ = is[i_338_];
                int i_340_ = is_334_[i_338_];
                is[i_338_] = i + (int) ((float) (i_339_ - i) * ((StageMaker) this).m.cos(i_336_) - (float) (i_340_ - i_335_) * ((StageMaker) this).m.sin(i_336_));
                is_334_[i_338_] = i_335_ + (int) ((float) (i_339_ - i) * ((StageMaker) this).m.sin(i_336_) + (float) (i_340_ - i_335_) * ((StageMaker) this).m.cos(i_336_));
            }
        }
    }
    
    public int xs(int i, int i_341_) {
        if (i_341_ < ((Medium) ((StageMaker) this).m).cz)
            i_341_ = ((Medium) ((StageMaker) this).m).cz;
        return (i_341_ - ((Medium) ((StageMaker) this).m).focus_point) * (((Medium) ((StageMaker) this).m).cx - i) / i_341_ + i;
    }
    
    public int ys(int i, int i_342_) {
        if (i_342_ < ((Medium) ((StageMaker) this).m).cz)
            i_342_ = ((Medium) ((StageMaker) this).m).cz;
        return (i_342_ - ((Medium) ((StageMaker) this).m).focus_point) * (((Medium) ((StageMaker) this).m).cy - i) / i_342_ + i;
    }
    
    public int py(int i, int i_343_, int i_344_, int i_345_) {
        return (int) Math.sqrt((double) ((i - i_343_) * (i - i_343_) + (i_344_ - i_345_) * (i_344_ - i_345_)));
    }
    
    public int pyn(int i, int i_346_, int i_347_, int i_348_) {
        return (i - i_346_) / 100 * ((i - i_346_) / 100) + (i_347_ - i_348_) / 100 * ((i_347_ - i_348_) / 100);
    }
    
    public String getstring(String string, String string_349_, int i) {
        int i_350_ = 0;
        String string_351_ = "";
        for (int i_352_ = string.length() + 1; i_352_ < string_349_.length(); i_352_++) {
            String string_353_ = new StringBuilder().append("").append(string_349_.charAt(i_352_)).toString();
            if (string_353_.equals(",") || string_353_.equals(")")) {
                i_350_++;
                i_352_++;
            }
            if (i_350_ == i)
                string_351_ = new StringBuilder().append(string_351_).append(string_349_.charAt(i_352_)).toString();
        }
        return string_351_;
    }
    
    public int getint(String string, String string_354_, int i) {
        int i_355_ = 0;
        String string_356_ = "";
        for (int i_357_ = string.length() + 1; i_357_ < string_354_.length(); i_357_++) {
            String string_358_ = new StringBuilder().append("").append(string_354_.charAt(i_357_)).toString();
            if (string_358_.equals(",") || string_358_.equals(")")) {
                i_355_++;
                i_357_++;
            }
            if (i_355_ == i)
                string_356_ = new StringBuilder().append(string_356_).append(string_354_.charAt(i_357_)).toString();
        }
        return Integer.valueOf(string_356_).intValue();
    }
    
    public Image getImage(String string) {
        Image image = Toolkit.getDefaultToolkit().createImage(string);
        MediaTracker mediatracker = new MediaTracker(this);
        mediatracker.addImage(image, 0);
        try {
            mediatracker.waitForID(0);
        } catch (Exception exception) {
            /* empty */
        }
        return image;
    }
    
    public int servervalue(String string, int i) {
        int i_359_ = -1;
        try {
            int i_360_ = 0;
            int i_361_ = 0;
            int i_362_ = 0;
            String string_363_ = "";
            String string_364_ = "";
            for (/**/; i_360_ < string.length() && i_362_ != 2; i_360_++) {
                string_363_ = new StringBuilder().append("").append(string.charAt(i_360_)).toString();
                if (string_363_.equals("|")) {
                    i_361_++;
                    if (i_362_ == 1 || i_361_ > i)
                        i_362_ = 2;
                } else if (i_361_ == i) {
                    string_364_ = new StringBuilder().append(string_364_).append(string_363_).toString();
                    i_362_ = 1;
                }
            }
            if (string_364_.equals(""))
                string_364_ = "-1";
            i_359_ = Integer.valueOf(string_364_).intValue();
        } catch (Exception exception) {
            /* empty */
        }
        return i_359_;
    }
    
    public String serverSvalue(String string, int i) {
        String string_365_ = "";
        try {
            int i_366_ = 0;
            int i_367_ = 0;
            int i_368_ = 0;
            String string_369_ = "";
            String string_370_ = "";
            for (/**/; i_366_ < string.length() && i_368_ != 2; i_366_++) {
                string_369_ = new StringBuilder().append("").append(string.charAt(i_366_)).toString();
                if (string_369_.equals("|")) {
                    i_367_++;
                    if (i_368_ == 1 || i_367_ > i)
                        i_368_ = 2;
                } else if (i_367_ == i) {
                    string_370_ = new StringBuilder().append(string_370_).append(string_369_).toString();
                    i_368_ = 1;
                }
            }
            string_365_ = string_370_;
        } catch (Exception exception) {
            /* empty */
        }
        return string_365_;
    }
    
    public int getvalue(String string, String string_371_, int i) {
        int i_372_ = 0;
        String string_373_ = "";
        for (int i_374_ = string.length() + 1; i_374_ < string_371_.length(); i_374_++) {
            String string_375_ = new StringBuilder().append("").append(string_371_.charAt(i_374_)).toString();
            if (string_375_.equals(",") || string_375_.equals(")")) {
                i_372_++;
                i_374_++;
            }
            if (i_372_ == i)
                string_373_ = new StringBuilder().append(string_373_).append(string_371_.charAt(i_374_)).toString();
        }
        return Float.valueOf(string_373_).intValue();
    }
    
    public String getSvalue(String string, String string_376_, int i) {
        String string_377_ = "";
        int i_378_ = 0;
        for (int i_379_ = string.length() + 1; i_379_ < string_376_.length() && i_378_ <= i; i_379_++) {
            String string_380_ = new StringBuilder().append("").append(string_376_.charAt(i_379_)).toString();
            if (string_380_.equals(",") || string_380_.equals(")"))
                i_378_++;
            else if (i_378_ == i)
                string_377_ = new StringBuilder().append(string_377_).append(string_380_).toString();
        }
        return string_377_;
    }
    
    public boolean button(String string, int i, int i_381_, int i_382_, boolean bool) {
        ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
        int i_383_ = ((StageMaker) this).ftm.stringWidth(string);
        boolean bool_384_ = false;
        boolean bool_385_ = false;
        if (string.equals(" Cancel ") && ((StageMaker) this).epart && Math.abs(((StageMaker) this).xm - i) < i_383_ / 2 + 12 && Math.abs(((StageMaker) this).ym - i_381_ + 5) < 10)
            ((StageMaker) this).overcan = true;
        if (Math.abs(((StageMaker) this).xm - i) < i_383_ / 2 + 12 && Math.abs(((StageMaker) this).ym - i_381_ + 5) < 10 && ((StageMaker) this).mouses == 1)
            bool_384_ = true;
        else
            bool_384_ = false;
        if (Math.abs(((StageMaker) this).xm - i) < i_383_ / 2 + 12 && Math.abs(((StageMaker) this).ym - i_381_ + 5) < 10 && ((StageMaker) this).mouses == -1) {
            ((StageMaker) this).mouses = 0;
            bool_385_ = true;
        }
        boolean bool_386_ = false;
        if (bool) {
            if (((StageMaker) this).tab == 0)
                ((StageMaker) this).rd.setColor(new Color(207, 207, 207));
            if (((StageMaker) this).tab == 1)
                ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            if (((StageMaker) this).tab == 2)
                ((StageMaker) this).rd.setColor(new Color(170, 170, 170));
            if (((StageMaker) this).tab != 3) {
                ((StageMaker) this).rd.drawRect(i - i_383_ / 2 - 15, i_381_ - (22 - i_382_), i_383_ + 29, 34 - i_382_ * 2);
                if (i_382_ == 2 && ((StageMaker) this).tab == 1) {
                    ((StageMaker) this).rd.setColor(new Color(220, 220, 220));
                    ((StageMaker) this).rd.fillRect(i - i_383_ / 2 - 15, i_381_ - (22 - i_382_), i_383_ + 29, 34 - i_382_ * 2);
                }
            } else
                bool_386_ = true;
        }
        if (!bool_384_) {
            ((StageMaker) this).rd.setColor(new Color(220, 220, 220));
            if (bool_386_)
                ((StageMaker) this).rd.setColor(new Color(230, 230, 230));
            ((StageMaker) this).rd.fillRect(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i_383_ + 20, 25 - i_382_ * 2);
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            if (bool_386_)
                ((StageMaker) this).rd.setColor(new Color(255, 255, 255));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i + i_383_ / 2 + 10, i_381_ - (17 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (18 - i_382_), i + i_383_ / 2 + 10, i_381_ - (18 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 9, i_381_ - (19 - i_382_), i + i_383_ / 2 + 9, i_381_ - (19 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            if (bool_386_)
                ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 10, i_381_ - (17 - i_382_), i + i_383_ / 2 + 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 11, i_381_ - (17 - i_382_), i + i_383_ / 2 + 11, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            if (bool_386_)
                ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 12, i_381_ - (16 - i_382_), i + i_383_ / 2 + 12, i_381_ + (6 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ + (7 - i_382_), i + i_383_ / 2 + 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ + (8 - i_382_), i + i_383_ / 2 + 10, i_381_ + (8 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 9, i_381_ + (9 - i_382_), i + i_383_ / 2 + 9, i_381_ + (9 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            if (bool_386_)
                ((StageMaker) this).rd.setColor(new Color(255, 255, 255));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i - i_383_ / 2 - 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 11, i_381_ - (17 - i_382_), i - i_383_ / 2 - 11, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 12, i_381_ - (16 - i_382_), i - i_383_ / 2 - 12, i_381_ + (6 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            if (string.equals("  Keyboard Controls  "))
                ((StageMaker) this).rd.setColor(new Color(100, 100, 100));
            ((StageMaker) this).rd.drawString(string, i - i_383_ / 2, i_381_);
        } else {
            ((StageMaker) this).rd.setColor(new Color(220, 220, 220));
            ((StageMaker) this).rd.fillRect(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i_383_ + 20, 25 - i_382_ * 2);
            ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i + i_383_ / 2 + 10, i_381_ - (17 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (18 - i_382_), i + i_383_ / 2 + 10, i_381_ - (18 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 9, i_381_ - (19 - i_382_), i + i_383_ / 2 + 9, i_381_ - (19 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(247, 247, 247));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 10, i_381_ - (17 - i_382_), i + i_383_ / 2 + 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 11, i_381_ - (17 - i_382_), i + i_383_ / 2 + 11, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i + i_383_ / 2 + 12, i_381_ - (16 - i_382_), i + i_383_ / 2 + 12, i_381_ + (6 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ + (7 - i_382_), i + i_383_ / 2 + 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ + (8 - i_382_), i + i_383_ / 2 + 10, i_381_ + (8 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 9, i_381_ + (9 - i_382_), i + i_383_ / 2 + 9, i_381_ + (9 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 10, i_381_ - (17 - i_382_), i - i_383_ / 2 - 10, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 11, i_381_ - (17 - i_382_), i - i_383_ / 2 - 11, i_381_ + (7 - i_382_));
            ((StageMaker) this).rd.drawLine(i - i_383_ / 2 - 12, i_381_ - (16 - i_382_), i - i_383_ / 2 - 12, i_381_ + (6 - i_382_));
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            if (string.equals("  Keyboard Controls  "))
                ((StageMaker) this).rd.setColor(new Color(100, 100, 100));
            ((StageMaker) this).rd.drawString(string, i - i_383_ / 2 + 1, i_381_ + 1);
        }
        return bool_385_;
    }
    
    public boolean ovbutton(String string, int i, int i_387_) {
        ((StageMaker) this).rd.setFont(new Font("Arial", 0, 12));
        ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
        if (string.equals("X") || string.equals("Download")) {
            ((StageMaker) this).rd.setFont(new Font("Arial", 1, 12));
            ((StageMaker) this).ftm = ((StageMaker) this).rd.getFontMetrics();
        }
        int i_388_ = ((StageMaker) this).ftm.stringWidth(string);
        int i_389_ = 4;
        boolean bool = false;
        boolean bool_390_ = false;
        if (Math.abs(((StageMaker) this).xm - i) < i_388_ / 2 + 12 && Math.abs(((StageMaker) this).ym - i_387_ + 5) < 10 && ((StageMaker) this).mouses == 1)
            bool = true;
        else
            bool = false;
        if (Math.abs(((StageMaker) this).xm - i) < i_388_ / 2 + 12 && Math.abs(((StageMaker) this).ym - i_387_ + 5) < 10 && ((StageMaker) this).mouses == -1) {
            ((StageMaker) this).mouses = 0;
            bool_390_ = true;
        }
        if (!bool) {
            ((StageMaker) this).rd.setColor(new Color(220, 220, 220));
            ((StageMaker) this).rd.fillRect(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i_388_ + 20, 25 - i_389_ * 2);
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i + i_388_ / 2 + 10, i_387_ - (17 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (18 - i_389_), i + i_388_ / 2 + 10, i_387_ - (18 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 9, i_387_ - (19 - i_389_), i + i_388_ / 2 + 9, i_387_ - (19 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 10, i_387_ - (17 - i_389_), i + i_388_ / 2 + 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 11, i_387_ - (17 - i_389_), i + i_388_ / 2 + 11, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 12, i_387_ - (16 - i_389_), i + i_388_ / 2 + 12, i_387_ + (6 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ + (7 - i_389_), i + i_388_ / 2 + 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ + (8 - i_389_), i + i_388_ / 2 + 10, i_387_ + (8 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(200, 200, 200));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 9, i_387_ + (9 - i_389_), i + i_388_ / 2 + 9, i_387_ + (9 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i - i_388_ / 2 - 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 11, i_387_ - (17 - i_389_), i - i_388_ / 2 - 11, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(240, 240, 240));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 12, i_387_ - (16 - i_389_), i - i_388_ / 2 - 12, i_387_ + (6 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            if (string.equals("X"))
                ((StageMaker) this).rd.setColor(new Color(255, 0, 0));
            if (string.equals("Download"))
                ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
            ((StageMaker) this).rd.drawString(string, i - i_388_ / 2, i_387_);
        } else {
            ((StageMaker) this).rd.setColor(new Color(220, 220, 220));
            ((StageMaker) this).rd.fillRect(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i_388_ + 20, 25 - i_389_ * 2);
            ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i + i_388_ / 2 + 10, i_387_ - (17 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (18 - i_389_), i + i_388_ / 2 + 10, i_387_ - (18 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 9, i_387_ - (19 - i_389_), i + i_388_ / 2 + 9, i_387_ - (19 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(247, 247, 247));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 10, i_387_ - (17 - i_389_), i + i_388_ / 2 + 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 11, i_387_ - (17 - i_389_), i + i_388_ / 2 + 11, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i + i_388_ / 2 + 12, i_387_ - (16 - i_389_), i + i_388_ / 2 + 12, i_387_ + (6 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ + (7 - i_389_), i + i_388_ / 2 + 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ + (8 - i_389_), i + i_388_ / 2 + 10, i_387_ + (8 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 9, i_387_ + (9 - i_389_), i + i_388_ / 2 + 9, i_387_ + (9 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(192, 192, 192));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 10, i_387_ - (17 - i_389_), i - i_388_ / 2 - 10, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 11, i_387_ - (17 - i_389_), i - i_388_ / 2 - 11, i_387_ + (7 - i_389_));
            ((StageMaker) this).rd.drawLine(i - i_388_ / 2 - 12, i_387_ - (16 - i_389_), i - i_388_ / 2 - 12, i_387_ + (6 - i_389_));
            ((StageMaker) this).rd.setColor(new Color(0, 0, 0));
            if (string.equals("X"))
                ((StageMaker) this).rd.setColor(new Color(255, 0, 0));
            if (string.equals("Download"))
                ((StageMaker) this).rd.setColor(new Color(0, 64, 128));
            ((StageMaker) this).rd.drawString(string, i - i_388_ / 2 + 1, i_387_ + 1);
        }
        return bool_390_;
    }
    
    public void openlink() {
        Madness.openurl("http://www.needformadness.com/developer/help.html");
    }
    
    public void openhlink() {
        Madness.openurl("http://www.needformadness.com/developer/");
    }
}
