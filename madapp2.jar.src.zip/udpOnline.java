/* udpOnline - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;

public class udpOnline implements Runnable
{
    Thread con;
    UDPMistro um;
    int gameport = 7001;
    InetAddress IPAddress;
    DatagramSocket dSocket;
    long sendat = 0L;
    boolean started = false;
    boolean errd = false;
    int nu = 0;
    
    public udpOnline(UDPMistro udpmistro, String string, int i, int i_0_,
		     int i_1_) {
	((udpOnline) this).um = udpmistro;
	((udpOnline) this).gameport = i;
	((udpOnline) this).nu = i_0_;
	try {
	    ((udpOnline) this).dSocket
		= new DatagramSocket(7010 + i_1_ + ((udpOnline) this).nu);
	    ((udpOnline) this).errd = false;
	    ((udpOnline) this).IPAddress = InetAddress.getByName(string);
	} catch (Exception exception) {
	    System.out.println(new StringBuilder().append
				   ("Error preparing for UDP Connection: ")
				   .append
				   (exception).toString());
	}
    }
    
    public void spark() {
	if (((udpOnline) this).errd) {
	    try {
		((udpOnline) this).dSocket
		    = new DatagramSocket(7020 + ((udpOnline) this).nu);
		((udpOnline) this).errd = false;
	    } catch (Exception exception) {
		/* empty */
	    }
	}
	try {
	    ((udpOnline) this).con = new Thread(this);
	    ((udpOnline) this).con.start();
	} catch (Exception exception) {
	    /* empty */
	}
    }
    
    public void closeSocket() {
	try {
	    ((udpOnline) this).dSocket.close();
	} catch (Exception exception) {
	    /* empty */
	}
	((udpOnline) this).dSocket = null;
	((udpOnline) this).errd = true;
	if (((udpOnline) this).con != null) {
	    ((udpOnline) this).con.stop();
	    ((udpOnline) this).con = null;
	}
	((udpOnline) this).started = false;
    }
    
    public void stomp() {
	if (((udpOnline) this).con != null) {
	    ((udpOnline) this).con.stop();
	    ((udpOnline) this).con = null;
	}
	((udpOnline) this).started = false;
    }
    
    public void run() {
	((udpOnline) this).started = true;
	Date date = new Date();
	((udpOnline) this).sendat = date.getTime();
	String string = "";
	if (!((UDPMistro) ((udpOnline) this).um).go)
	    string = "MAGNITUDE";
	if (((udpOnline) this).nu == 0
	    && ((UDPMistro) ((udpOnline) this).um).diledelay == 0) {
	    ((UDPMistro) ((udpOnline) this).um).sendat
		= ((udpOnline) this).sendat;
	    string = new StringBuilder().append("").append
			 (((udpOnline) this).sendat).toString();
	    string = string.substring(string.length() - 3, string.length());
	    ((UDPMistro) ((udpOnline) this).um).sendcheck = string;
	    ((UDPMistro) ((udpOnline) this).um).diledelay = 100;
	}
	try {
	    byte[] is = new byte[4];
	    DatagramPacket datagrampacket
		= new DatagramPacket(is, is.length,
				     ((udpOnline) this).IPAddress,
				     ((udpOnline) this).gameport);
	    String string_2_
		= new StringBuilder().append("").append(string).append("|")
		      .append
		      (((UDPMistro) ((udpOnline) this).um).im).append
		      ("|").append
		      (((UDPMistro) ((udpOnline) this).um).frame
		       [((UDPMistro) ((udpOnline) this).um).im][0])
		      .append
		      ("|").append
		      (((UDPMistro) ((udpOnline) this).um).info
		       [((UDPMistro) ((udpOnline) this).um).im][0])
		      .append
		      ("|").toString();
	    byte[] is_3_ = string_2_.getBytes();
	    datagrampacket.setData(is_3_);
	    ((udpOnline) this).dSocket.send(datagrampacket);
	    for (int i = 0;
		 i < ((UDPMistro) ((udpOnline) this).um).nplayers - 1; i++) {
		((udpOnline) this).dSocket.receive(datagrampacket);
		String string_4_ = new String(datagrampacket.getData());
		if ((((udpOnline) this).nu == 0
		     || !((UDPMistro) ((udpOnline) this).um).go)
		    && i == 0) {
		    string = getSvalue(string_4_, 0);
		    if (!((UDPMistro) ((udpOnline) this).um).go
			&& string.equals("1111111"))
			((UDPMistro) ((udpOnline) this).um).go = true;
		}
		int i_5_ = getvalue(string_4_, 1);
		if (i_5_ >= 0
		    && i_5_ < ((UDPMistro) ((udpOnline) this).um).nplayers) {
		    int i_6_ = getvalue(string_4_, 2);
		    int i_7_ = 0;
		    for (int i_8_ = 0; i_8_ < 3; i_8_++) {
			if (i_6_ != (((UDPMistro) ((udpOnline) this).um).frame
				     [i_5_][i_8_]))
			    i_7_++;
		    }
		    if (i_7_ == 3) {
			for (int i_9_ = 0; i_9_ < 3; i_9_++) {
			    if (i_6_ > (((UDPMistro) ((udpOnline) this).um)
					.frame[i_5_][i_9_])) {
				for (int i_10_ = 2; i_10_ >= i_9_ + 1;
				     i_10_--) {
				    ((UDPMistro) ((udpOnline) this).um)
					.frame[i_5_][i_10_]
					= (((UDPMistro) ((udpOnline) this).um)
					   .frame[i_5_][i_10_ - 1]);
				    ((UDPMistro) ((udpOnline) this).um)
					.info[i_5_][i_10_]
					= (((UDPMistro) ((udpOnline) this).um)
					   .info[i_5_][i_10_ - 1]);
				}
				((UDPMistro) ((udpOnline) this).um).frame
				    [i_5_][i_9_]
				    = i_6_;
				((UDPMistro) ((udpOnline) this).um).info
				    [i_5_][i_9_]
				    = getSvalue(string_4_, 3);
				i_9_ = 3;
			    }
			}
		    }
		}
	    }
	    if (((udpOnline) this).nu == 0
		&& ((UDPMistro) ((udpOnline) this).um).diledelay != 0
		&& ((UDPMistro) ((udpOnline) this).um).sendcheck
		       .equals(string)) {
		date = new Date();
		for (int i = 4; i > 0; i--)
		    ((UDPMistro) ((udpOnline) this).um).ldelays[i]
			= ((UDPMistro) ((udpOnline) this).um).ldelays[i - 1];
		((UDPMistro) ((udpOnline) this).um).ldelays[0]
		    = (int) (date.getTime()
			     - ((UDPMistro) ((udpOnline) this).um).sendat);
		((UDPMistro) ((udpOnline) this).um).delay = 0;
		for (int i = 0; i < 5; i++) {
		    if (((UDPMistro) ((udpOnline) this).um).ldelays[i] != 0
			&& (((UDPMistro) ((udpOnline) this).um).delay == 0
			    || (((UDPMistro) ((udpOnline) this).um).ldelays[i]
				< ((UDPMistro) ((udpOnline) this).um).delay)))
			((UDPMistro) ((udpOnline) this).um).delay
			    = ((UDPMistro) ((udpOnline) this).um).ldelays[i];
		}
		((UDPMistro) ((udpOnline) this).um).diledelay = 0;
		if (((UDPMistro) ((udpOnline) this).um).diled != 10)
		    ((UDPMistro) ((udpOnline) this).um).diled++;
	    }
	} catch (Exception exception) {
	    try {
		((udpOnline) this).dSocket.close();
	    } catch (Exception exception_11_) {
		/* empty */
	    }
	    ((udpOnline) this).dSocket = null;
	    ((udpOnline) this).errd = true;
	}
	((udpOnline) this).started = false;
	((udpOnline) this).con = null;
    }
    
    public int getvalue(String string, int i) {
	int i_12_ = -1;
	try {
	    int i_13_ = 0;
	    int i_14_ = 0;
	    int i_15_ = 0;
	    String string_16_ = "";
	    String string_17_ = "";
	    for (/**/; i_13_ < string.length() && i_15_ != 2; i_13_++) {
		string_16_ = new StringBuilder().append("").append
				 (string.charAt(i_13_)).toString();
		if (string_16_.equals("|")) {
		    i_14_++;
		    if (i_15_ == 1 || i_14_ > i)
			i_15_ = 2;
		} else if (i_14_ == i) {
		    string_17_ = new StringBuilder().append(string_17_).append
				     (string_16_).toString();
		    i_15_ = 1;
		}
	    }
	    if (string_17_.equals(""))
		string_17_ = "-1";
	    i_12_ = Integer.valueOf(string_17_).intValue();
	} catch (Exception exception) {
	    /* empty */
	}
	return i_12_;
    }
    
    public String getSvalue(String string, int i) {
	String string_18_ = "";
	try {
	    int i_19_ = 0;
	    int i_20_ = 0;
	    int i_21_ = 0;
	    String string_22_ = "";
	    String string_23_ = "";
	    for (/**/; i_19_ < string.length() && i_21_ != 2; i_19_++) {
		string_22_ = new StringBuilder().append("").append
				 (string.charAt(i_19_)).toString();
		if (string_22_.equals("|")) {
		    i_20_++;
		    if (i_21_ == 1 || i_20_ > i)
			i_21_ = 2;
		} else if (i_20_ == i) {
		    string_23_ = new StringBuilder().append(string_23_).append
				     (string_22_).toString();
		    i_21_ = 1;
		}
	    }
	    string_18_ = string_23_;
	} catch (Exception exception) {
	    /* empty */
	}
	return string_18_;
    }
}
