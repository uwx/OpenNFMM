import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

final class Madness$1
  extends WindowAdapter
{
  public void windowClosing(WindowEvent paramWindowEvent) {}
}


/* Location:              E:\Games\Need For Madness\data\madapp.jar!\Madness$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */