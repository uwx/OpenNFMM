/* Medium - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Medium
{
    int focus_point = 400;
    int ground = 250;
    int skyline = -300;
    int[] fade = { 3000, 4500, 6000, 7500, 9000, 10500, 12000, 13500, 15000,
		   16500, 18000, 19500, 21000, 22500, 24000, 25500 };
    int[] cldd = { 210, 210, 210, 1, -1000 };
    int[] clds = { 210, 210, 210 };
    int[] osky = { 170, 220, 255 };
    int[] csky = { 170, 220, 255 };
    int[] ogrnd = { 205, 200, 200 };
    int[] cgrnd = { 205, 200, 200 };
    int[] texture = { 0, 0, 0, 50 };
    int[] cpol = { 215, 210, 210 };
    int[] crgrnd = { 205, 200, 200 };
    int[] cfade = { 255, 220, 220 };
    int[] snap = { 0, 0, 0 };
    int fogd = 7;
    int mgen = (int) (Math.random() * 100000.0);
    boolean loadnew = false;
    boolean lightson = false;
    boolean darksky = false;
    int lightn = -1;
    int lilo = 217;
    boolean lton = false;
    int noelec = 0;
    int trk = 0;
    boolean crs = false;
    int cx = 400;
    int cy = 225;
    int cz = 50;
    int xz = 0;
    int zy = 0;
    int x = 0;
    int y = 0;
    int z = 0;
    int iw = 0;
    int ih = 0;
    int w = 800;
    int h = 450;
    int nsp = 0;
    int[] spx = new int[7];
    int[] spz = new int[7];
    int[] sprad = new int[7];
    boolean td = false;
    int bcxz = 0;
    boolean bt = false;
    int vxz = 180;
    int adv = 500;
    boolean vert = false;
    float[] tcos = new float[360];
    float[] tsin = new float[360];
    int lastmaf = 0;
    int checkpoint = -1;
    boolean lastcheck = false;
    float elecr = 0.0F;
    boolean cpflik = false;
    boolean nochekflk = false;
    int cntrn = 0;
    boolean[] diup = { false, false, false };
    int[] rand = { 0, 0, 0 };
    int trn = 0;
    int hit = 45000;
    int ptr = 0;
    int ptcnt = -10;
    int nrnd = 0;
    long trx = 0L;
    long trz = 0L;
    long atrx = 0L;
    long atrz = 0L;
    int fallen = 0;
    float fo = 1.0F;
    float gofo = (float) (0.33000001311302185 + Math.random() * 1.34);
    int fvect = 200;
    int[][] ogpx = null;
    int[][] ogpz = null;
    float[][] pvr = null;
    int[] cgpx = null;
    int[] cgpz = null;
    int[] pmx = null;
    float[] pcv = null;
    int sgpx = 0;
    int sgpz = 0;
    int nrw = 0;
    int ncl = 0;
    int noc = 0;
    int[] clx = null;
    int[] clz = null;
    int[] cmx = null;
    int[][][] clax = null;
    int[][][] clay = null;
    int[][][] claz = null;
    int[][][][] clc = null;
    int nmt = 0;
    int[] mrd = null;
    int[] nmv = null;
    int[][] mtx = null;
    int[][] mty = null;
    int[][] mtz = null;
    int[][][] mtc = null;
    int nst = 0;
    int[] stx = null;
    int[] stz = null;
    int[][][] stc = null;
    boolean[] bst = null;
    int[] twn = null;
    int resdown = 0;
    int rescnt = 5;
    
    public Medium() {
	for (int i = 0; i < 360; i++)
	    ((Medium) this).tcos[i]
		= (float) Math.cos((double) i * 0.017453292519943295);
	for (int i = 0; i < 360; i++)
	    ((Medium) this).tsin[i]
		= (float) Math.sin((double) i * 0.017453292519943295);
    }
    
    public float random() {
	if (((Medium) this).cntrn == 0) {
	    for (int i = 0; i < 3; i++) {
		((Medium) this).rand[i] = (int) (10.0 * Math.random());
		if (Math.random() > Math.random())
		    ((Medium) this).diup[i] = false;
		else
		    ((Medium) this).diup[i] = true;
	    }
	    ((Medium) this).cntrn = 20;
	} else
	    ((Medium) this).cntrn--;
	for (int i = 0; i < 3; i++) {
	    if (((Medium) this).diup[i]) {
		((Medium) this).rand[i]++;
		if (((Medium) this).rand[i] == 10)
		    ((Medium) this).rand[i] = 0;
	    } else {
		((Medium) this).rand[i]--;
		if (((Medium) this).rand[i] == -1)
		    ((Medium) this).rand[i] = 9;
	    }
	}
	((Medium) this).trn++;
	if (((Medium) this).trn == 3)
	    ((Medium) this).trn = 0;
	return (float) ((Medium) this).rand[((Medium) this).trn] / 10.0F;
    }
    
    public void watch(ContO conto, int i) {
	if (((Medium) this).td) {
	    ((Medium) this).y = (int) ((float) (((ContO) conto).y - 300)
				       - 1100.0F * random());
	    ((Medium) this).x
		= (((ContO) conto).x
		   + (int) ((float) (((ContO) conto).x + 400
				     - ((ContO) conto).x) * cos(i)
			    - (float) (((ContO) conto).z + 5000
				       - ((ContO) conto).z) * sin(i)));
	    ((Medium) this).z
		= (((ContO) conto).z
		   + (int) ((float) (((ContO) conto).x + 400
				     - ((ContO) conto).x) * sin(i)
			    + (float) (((ContO) conto).z + 5000
				       - ((ContO) conto).z) * cos(i)));
	    ((Medium) this).td = false;
	}
	int i_0_ = 0;
	if (((ContO) conto).x - ((Medium) this).x - ((Medium) this).cx > 0)
	    i_0_ = 180;
	int i_1_ = -(int) ((double) (90 + i_0_)
			   + (Math.atan((double) (((ContO) conto).z
						  - ((Medium) this).z)
					/ (double) (((ContO) conto).x
						    - ((Medium) this).x
						    - ((Medium) this).cx))
			      / 0.017453292519943295));
	i_0_ = 0;
	if (((ContO) conto).y - ((Medium) this).y - ((Medium) this).cy < 0)
	    i_0_ = -180;
	int i_2_ = (int) Math.sqrt((double) (((((ContO) conto).z
					       - ((Medium) this).z)
					      * (((ContO) conto).z
						 - ((Medium) this).z))
					     + ((((ContO) conto).x
						 - ((Medium) this).x
						 - ((Medium) this).cx)
						* (((ContO) conto).x
						   - ((Medium) this).x
						   - ((Medium) this).cx))));
	int i_3_ = (int) ((double) (90 + i_0_)
			  - (Math.atan((double) i_2_
				       / (double) (((ContO) conto).y
						   - ((Medium) this).y
						   - ((Medium) this).cy))
			     / 0.017453292519943295));
	for (/**/; i_1_ < 0; i_1_ += 360) {
	    /* empty */
	}
	for (/**/; i_1_ > 360; i_1_ -= 360) {
	    /* empty */
	}
	((Medium) this).xz = i_1_;
	((Medium) this).zy += (i_3_ - ((Medium) this).zy) / 5;
	if ((int) Math.sqrt((double) (((((ContO) conto).z - ((Medium) this).z)
				       * (((ContO) conto).z
					  - ((Medium) this).z))
				      + ((((ContO) conto).x - ((Medium) this).x
					  - ((Medium) this).cx)
					 * (((ContO) conto).x
					    - ((Medium) this).x
					    - ((Medium) this).cx))
				      + ((((ContO) conto).y - ((Medium) this).y
					  - ((Medium) this).cy)
					 * (((ContO) conto).y
					    - ((Medium) this).y
					    - ((Medium) this).cy))))
	    > 6000)
	    ((Medium) this).td = true;
    }
    
    public void aroundtrack(CheckPoints checkpoints) {
	((Medium) this).y = -((Medium) this).hit;
	((Medium) this).x = (((Medium) this).cx + (int) ((Medium) this).trx
			     + (int) (17000.0F * cos(((Medium) this).vxz)));
	((Medium) this).z
	    = (int) ((Medium) this).trz + (int) (17000.0F
						 * sin(((Medium) this).vxz));
	if (((Medium) this).hit > 5000) {
	    if (((Medium) this).hit == 45000) {
		((Medium) this).fo = 1.0F;
		((Medium) this).zy = 67;
		((Medium) this).atrx = ((long) ((CheckPoints) checkpoints).x[0]
					- ((Medium) this).trx) / 116L;
		((Medium) this).atrz = ((long) ((CheckPoints) checkpoints).z[0]
					- ((Medium) this).trz) / 116L;
		((Medium) this).focus_point = 400;
	    }
	    if (((Medium) this).hit == 20000) {
		((Medium) this).fallen = 500;
		((Medium) this).fo = 1.0F;
		((Medium) this).zy = 67;
		((Medium) this).atrx = ((long) ((CheckPoints) checkpoints).x[0]
					- ((Medium) this).trx) / 116L;
		((Medium) this).atrz = ((long) ((CheckPoints) checkpoints).z[0]
					- ((Medium) this).trz) / 116L;
		((Medium) this).focus_point = 400;
	    }
	    ((Medium) this).hit -= ((Medium) this).fallen;
	    ((Medium) this).fallen += 7;
	    ((Medium) this).trx += ((Medium) this).atrx;
	    ((Medium) this).trz += ((Medium) this).atrz;
	    if (((Medium) this).hit < 17600)
		((Medium) this).zy -= 2;
	    if (((Medium) this).fallen > 500)
		((Medium) this).fallen = 500;
	    if (((Medium) this).hit <= 5000) {
		((Medium) this).hit = 5000;
		((Medium) this).fallen = 0;
	    }
	    ((Medium) this).vxz += 3;
	} else {
	    ((Medium) this).focus_point = (int) (400.0F * ((Medium) this).fo);
	    if ((double) Math.abs(((Medium) this).fo - ((Medium) this).gofo)
		> 0.005) {
		if (((Medium) this).fo < ((Medium) this).gofo)
		    ((Medium) this).fo += 0.005F;
		else
		    ((Medium) this).fo -= 0.005F;
	    } else
		((Medium) this).gofo
		    = (float) (0.3499999940395355 + Math.random() * 1.3);
	    ((Medium) this).vxz++;
	    ((Medium) this).trx -= (((Medium) this).trx
				    - (long) (((CheckPoints) checkpoints).x
					      [((Medium) this).ptr])) / 10L;
	    ((Medium) this).trz -= (((Medium) this).trz
				    - (long) (((CheckPoints) checkpoints).z
					      [((Medium) this).ptr])) / 10L;
	    if (((Medium) this).ptcnt == 7) {
		((Medium) this).ptr++;
		if (((Medium) this).ptr == ((CheckPoints) checkpoints).n) {
		    ((Medium) this).ptr = 0;
		    ((Medium) this).nrnd++;
		}
		((Medium) this).ptcnt = 0;
	    } else
		((Medium) this).ptcnt++;
	}
	if (((Medium) this).vxz > 360)
	    ((Medium) this).vxz -= 360;
	((Medium) this).xz = -((Medium) this).vxz - 90;
	boolean bool = false;
	if (-((Medium) this).y - ((Medium) this).cy < 0) {
	    int i = -180;
	}
	int i
	    = (int) Math.sqrt((double) (((((Medium) this).trz
					  - (long) ((Medium) this).z
					  + (long) ((Medium) this).cz)
					 * (((Medium) this).trz
					    - (long) ((Medium) this).z
					    + (long) ((Medium) this).cz))
					+ ((((Medium) this).trx
					    - (long) ((Medium) this).x
					    - (long) ((Medium) this).cx)
					   * (((Medium) this).trx
					      - (long) ((Medium) this).x
					      - (long) ((Medium) this).cx))));
	if (((Medium) this).cpflik)
	    ((Medium) this).cpflik = false;
	else
	    ((Medium) this).cpflik = true;
    }
    
    public void around(ContO conto, boolean bool) {
	if (!bool) {
	    if (!((Medium) this).vert)
		((Medium) this).adv += 2;
	    else
		((Medium) this).adv -= 2;
	    if (((Medium) this).adv > 900)
		((Medium) this).vert = true;
	    if (((Medium) this).adv < -500)
		((Medium) this).vert = false;
	} else {
	    ((Medium) this).adv -= 14;
	    if (((Medium) this).adv < 617)
		((Medium) this).adv = 617;
	}
	int i = 500 + ((Medium) this).adv;
	if (bool && i < 1300)
	    i = 1300;
	if (i < 1000)
	    i = 1000;
	((Medium) this).y = ((ContO) conto).y - ((Medium) this).adv;
	if (((Medium) this).y > 10)
	    ((Medium) this).vert = false;
	((Medium) this).x
	    = ((ContO) conto).x + (int) ((float) (((ContO) conto).x - i
						  - ((ContO) conto).x)
					 * cos(((Medium) this).vxz));
	((Medium) this).z
	    = ((ContO) conto).z + (int) ((float) (((ContO) conto).x - i
						  - ((ContO) conto).x)
					 * sin(((Medium) this).vxz));
	if (!bool)
	    ((Medium) this).vxz += 2;
	else
	    ((Medium) this).vxz += 4;
	int i_4_ = 0;
	int i_5_ = ((Medium) this).y;
	if (i_5_ > 0)
	    i_5_ = 0;
	if (((ContO) conto).y - i_5_ - ((Medium) this).cy < 0)
	    i_4_ = -180;
	int i_6_
	    = (int) Math.sqrt((double) (((((ContO) conto).z - ((Medium) this).z
					  + ((Medium) this).cz)
					 * (((ContO) conto).z
					    - ((Medium) this).z
					    + ((Medium) this).cz))
					+ ((((ContO) conto).x
					    - ((Medium) this).x
					    - ((Medium) this).cx)
					   * (((ContO) conto).x
					      - ((Medium) this).x
					      - ((Medium) this).cx))));
	int i_7_ = (int) ((double) (90 + i_4_)
			  - (Math.atan((double) i_6_
				       / (double) (((ContO) conto).y - i_5_
						   - ((Medium) this).cy))
			     / 0.017453292519943295));
	((Medium) this).xz = -((Medium) this).vxz + 90;
	if (bool)
	    i_7_ -= 15;
	((Medium) this).zy += (i_7_ - ((Medium) this).zy) / 10;
    }
    
    public void getaround(ContO conto) {
	if (!((Medium) this).vert)
	    ((Medium) this).adv += 2;
	else
	    ((Medium) this).adv -= 2;
	if (((Medium) this).adv > 1700)
	    ((Medium) this).vert = true;
	if (((Medium) this).adv < -500)
	    ((Medium) this).vert = false;
	if (((ContO) conto).y - ((Medium) this).adv > 10)
	    ((Medium) this).vert = false;
	int i = 500 + ((Medium) this).adv;
	if (i < 1000)
	    i = 1000;
	int i_8_ = ((ContO) conto).y - ((Medium) this).adv;
	int i_9_ = ((ContO) conto).x + (int) ((float) (((ContO) conto).x - i
						       - ((ContO) conto).x)
					      * cos(((Medium) this).vxz));
	int i_10_ = ((ContO) conto).z + (int) ((float) (((ContO) conto).x - i
							- ((ContO) conto).x)
					       * sin(((Medium) this).vxz));
	int i_11_ = 0;
	if (Math.abs(i_8_ - ((Medium) this).y) > ((Medium) this).fvect) {
	    if (((Medium) this).y < i_8_)
		((Medium) this).y += ((Medium) this).fvect;
	    else
		((Medium) this).y -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).y = i_8_;
	    i_11_++;
	}
	if (Math.abs(i_9_ - ((Medium) this).x) > ((Medium) this).fvect) {
	    if (((Medium) this).x < i_9_)
		((Medium) this).x += ((Medium) this).fvect;
	    else
		((Medium) this).x -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).x = i_9_;
	    i_11_++;
	}
	if (Math.abs(i_10_ - ((Medium) this).z) > ((Medium) this).fvect) {
	    if (((Medium) this).z < i_10_)
		((Medium) this).z += ((Medium) this).fvect;
	    else
		((Medium) this).z -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).z = i_10_;
	    i_11_++;
	}
	if (i_11_ == 3)
	    ((Medium) this).fvect = 200;
	else
	    ((Medium) this).fvect += 2;
	for (((Medium) this).vxz += 2; ((Medium) this).vxz > 360;
	     ((Medium) this).vxz -= 360) {
	    /* empty */
	}
	int i_12_ = -((Medium) this).vxz + 90;
	int i_13_ = 0;
	if (((ContO) conto).x - ((Medium) this).x - ((Medium) this).cx > 0)
	    i_13_ = 180;
	int i_14_ = -(int) ((double) (90 + i_13_)
			    + (Math.atan((double) (((ContO) conto).z
						   - ((Medium) this).z)
					 / (double) (((ContO) conto).x
						     - ((Medium) this).x
						     - ((Medium) this).cx))
			       / 0.017453292519943295));
	int i_15_ = ((Medium) this).y;
	i_13_ = 0;
	if (i_15_ > 0)
	    i_15_ = 0;
	if (((ContO) conto).y - i_15_ - ((Medium) this).cy < 0)
	    i_13_ = -180;
	int i_16_
	    = (int) Math.sqrt((double) (((((ContO) conto).z - ((Medium) this).z
					  + ((Medium) this).cz)
					 * (((ContO) conto).z
					    - ((Medium) this).z
					    + ((Medium) this).cz))
					+ ((((ContO) conto).x
					    - ((Medium) this).x
					    - ((Medium) this).cx)
					   * (((ContO) conto).x
					      - ((Medium) this).x
					      - ((Medium) this).cx))));
	int i_17_ = 25;
	if (i_16_ != 0)
	    i_17_ = (int) ((double) (90 + i_13_)
			   - (Math.atan((double) i_16_
					/ (double) (((ContO) conto).y - i_15_
						    - ((Medium) this).cy))
			      / 0.017453292519943295));
	for (/**/; i_12_ < 0; i_12_ += 360) {
	    /* empty */
	}
	for (/**/; i_12_ > 360; i_12_ -= 360) {
	    /* empty */
	}
	for (/**/; i_14_ < 0; i_14_ += 360) {
	    /* empty */
	}
	for (/**/; i_14_ > 360; i_14_ -= 360) {
	    /* empty */
	}
	if ((Math.abs(i_12_ - i_14_) < 30 || Math.abs(i_12_ - i_14_) > 330)
	    && i_11_ == 3) {
	    if (Math.abs(i_12_ - ((Medium) this).xz) > 7
		&& Math.abs(i_12_ - ((Medium) this).xz) < 353) {
		if (Math.abs(i_12_ - ((Medium) this).xz) > 180) {
		    if (((Medium) this).xz > i_12_)
			((Medium) this).xz += 7;
		    else
			((Medium) this).xz -= 7;
		} else if (((Medium) this).xz < i_12_)
		    ((Medium) this).xz += 7;
		else
		    ((Medium) this).xz -= 7;
	    } else
		((Medium) this).xz = i_12_;
	} else if (Math.abs(i_14_ - ((Medium) this).xz) > 6
		   && Math.abs(i_14_ - ((Medium) this).xz) < 354) {
	    if (Math.abs(i_14_ - ((Medium) this).xz) > 180) {
		if (((Medium) this).xz > i_14_)
		    ((Medium) this).xz += 3;
		else
		    ((Medium) this).xz -= 3;
	    } else if (((Medium) this).xz < i_14_)
		((Medium) this).xz += 3;
	    else
		((Medium) this).xz -= 3;
	} else
	    ((Medium) this).xz = i_14_;
	((Medium) this).zy += (i_17_ - ((Medium) this).zy) / 10;
    }
    
    public void transaround(ContO conto, ContO conto_18_, int i) {
	int i_19_
	    = (((ContO) conto).x * (20 - i) + ((ContO) conto_18_).x * i) / 20;
	int i_20_
	    = (((ContO) conto).y * (20 - i) + ((ContO) conto_18_).y * i) / 20;
	int i_21_
	    = (((ContO) conto).z * (20 - i) + ((ContO) conto_18_).z * i) / 20;
	if (!((Medium) this).vert)
	    ((Medium) this).adv += 2;
	else
	    ((Medium) this).adv -= 2;
	if (((Medium) this).adv > 900)
	    ((Medium) this).vert = true;
	if (((Medium) this).adv < -500)
	    ((Medium) this).vert = false;
	int i_22_ = 500 + ((Medium) this).adv;
	if (i_22_ < 1000)
	    i_22_ = 1000;
	((Medium) this).y = i_20_ - ((Medium) this).adv;
	if (((Medium) this).y > 10)
	    ((Medium) this).vert = false;
	((Medium) this).x = i_19_ + (int) ((float) (i_19_ - i_22_ - i_19_)
					   * cos(((Medium) this).vxz));
	((Medium) this).z = i_21_ + (int) ((float) (i_19_ - i_22_ - i_19_)
					   * sin(((Medium) this).vxz));
	((Medium) this).vxz += 2;
	int i_23_ = 0;
	int i_24_ = ((Medium) this).y;
	if (i_24_ > 0)
	    i_24_ = 0;
	if (i_20_ - i_24_ - ((Medium) this).cy < 0)
	    i_23_ = -180;
	int i_25_ = (int) Math.sqrt((double) (((i_21_ - ((Medium) this).z
						+ ((Medium) this).cz)
					       * (i_21_ - ((Medium) this).z
						  + ((Medium) this).cz))
					      + ((i_19_ - ((Medium) this).x
						  - ((Medium) this).cx)
						 * (i_19_ - ((Medium) this).x
						    - ((Medium) this).cx))));
	int i_26_ = (int) ((double) (90 + i_23_)
			   - (Math.atan((double) i_25_
					/ (double) (i_20_ - i_24_
						    - ((Medium) this).cy))
			      / 0.017453292519943295));
	((Medium) this).xz = -((Medium) this).vxz + 90;
	((Medium) this).zy += (i_26_ - ((Medium) this).zy) / 10;
    }
    
    public void follow(ContO conto, int i, int i_27_) {
	((Medium) this).zy = 10;
	int i_28_ = 2 + Math.abs(((Medium) this).bcxz) / 4;
	if (i_28_ > 20)
	    i_28_ = 20;
	if (i_27_ != 0) {
	    if (i_27_ == 1) {
		if (((Medium) this).bcxz < 180)
		    ((Medium) this).bcxz += i_28_;
		if (((Medium) this).bcxz > 180)
		    ((Medium) this).bcxz = 180;
	    }
	    if (i_27_ == -1) {
		if (((Medium) this).bcxz > -180)
		    ((Medium) this).bcxz -= i_28_;
		if (((Medium) this).bcxz < -180)
		    ((Medium) this).bcxz = -180;
	    }
	} else if (Math.abs(((Medium) this).bcxz) > i_28_) {
	    if (((Medium) this).bcxz > 0)
		((Medium) this).bcxz -= i_28_;
	    else
		((Medium) this).bcxz += i_28_;
	} else if (((Medium) this).bcxz != 0)
	    ((Medium) this).bcxz = 0;
	i += ((Medium) this).bcxz;
	((Medium) this).xz = -i;
	((Medium) this).x
	    = (((ContO) conto).x - ((Medium) this).cx
	       + (int) ((float) -(((ContO) conto).z - 800 - ((ContO) conto).z)
			* sin(i)));
	((Medium) this).z
	    = (((ContO) conto).z - ((Medium) this).cz
	       + (int) ((float) (((ContO) conto).z - 800 - ((ContO) conto).z)
			* cos(i)));
	((Medium) this).y = ((ContO) conto).y - 250 - ((Medium) this).cy;
    }
    
    public void getfollow(ContO conto, int i, int i_29_) {
	((Medium) this).zy = 10;
	int i_30_ = 2 + Math.abs(((Medium) this).bcxz) / 4;
	if (i_30_ > 20)
	    i_30_ = 20;
	if (i_29_ != 0) {
	    if (i_29_ == 1) {
		if (((Medium) this).bcxz < 180)
		    ((Medium) this).bcxz += i_30_;
		if (((Medium) this).bcxz > 180)
		    ((Medium) this).bcxz = 180;
	    }
	    if (i_29_ == -1) {
		if (((Medium) this).bcxz > -180)
		    ((Medium) this).bcxz -= i_30_;
		if (((Medium) this).bcxz < -180)
		    ((Medium) this).bcxz = -180;
	    }
	} else if (Math.abs(((Medium) this).bcxz) > i_30_) {
	    if (((Medium) this).bcxz > 0)
		((Medium) this).bcxz -= i_30_;
	    else
		((Medium) this).bcxz += i_30_;
	} else if (((Medium) this).bcxz != 0)
	    ((Medium) this).bcxz = 0;
	i += ((Medium) this).bcxz;
	((Medium) this).xz = -i;
	int i_31_
	    = (((ContO) conto).x - ((Medium) this).cx
	       + (int) ((float) -(((ContO) conto).z - 800 - ((ContO) conto).z)
			* sin(i)));
	int i_32_
	    = (((ContO) conto).z - ((Medium) this).cz
	       + (int) ((float) (((ContO) conto).z - 800 - ((ContO) conto).z)
			* cos(i)));
	int i_33_ = ((ContO) conto).y - 250 - ((Medium) this).cy;
	int i_34_ = 0;
	if (Math.abs(i_33_ - ((Medium) this).y) > ((Medium) this).fvect) {
	    if (((Medium) this).y < i_33_)
		((Medium) this).y += ((Medium) this).fvect;
	    else
		((Medium) this).y -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).y = i_33_;
	    i_34_++;
	}
	if (Math.abs(i_31_ - ((Medium) this).x) > ((Medium) this).fvect) {
	    if (((Medium) this).x < i_31_)
		((Medium) this).x += ((Medium) this).fvect;
	    else
		((Medium) this).x -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).x = i_31_;
	    i_34_++;
	}
	if (Math.abs(i_32_ - ((Medium) this).z) > ((Medium) this).fvect) {
	    if (((Medium) this).z < i_32_)
		((Medium) this).z += ((Medium) this).fvect;
	    else
		((Medium) this).z -= ((Medium) this).fvect;
	} else {
	    ((Medium) this).z = i_32_;
	    i_34_++;
	}
	if (i_34_ == 3)
	    ((Medium) this).fvect = 200;
	else
	    ((Medium) this).fvect += 2;
    }
    
    public void newpolys(int i, int i_35_, int i_36_, int i_37_,
			 Trackers trackers, int i_38_) {
	Random random = new Random((long) ((i_38_ + ((Medium) this).cgrnd[0]
					    + ((Medium) this).cgrnd[1]
					    + ((Medium) this).cgrnd[2])
					   * 1671));
	((Medium) this).nrw = i_35_ / 1200 + 9;
	((Medium) this).ncl = i_37_ / 1200 + 9;
	((Medium) this).sgpx = i - 4800;
	((Medium) this).sgpz = i_36_ - 4800;
	((Medium) this).ogpx = null;
	((Medium) this).ogpz = null;
	((Medium) this).pvr = null;
	((Medium) this).cgpx = null;
	((Medium) this).cgpz = null;
	((Medium) this).pmx = null;
	((Medium) this).pcv = null;
	((Medium) this).ogpx
	    = new int[((Medium) this).nrw * ((Medium) this).ncl][8];
	((Medium) this).ogpz
	    = new int[((Medium) this).nrw * ((Medium) this).ncl][8];
	((Medium) this).pvr
	    = new float[((Medium) this).nrw * ((Medium) this).ncl][8];
	((Medium) this).cgpx
	    = new int[((Medium) this).nrw * ((Medium) this).ncl];
	((Medium) this).cgpz
	    = new int[((Medium) this).nrw * ((Medium) this).ncl];
	((Medium) this).pmx
	    = new int[((Medium) this).nrw * ((Medium) this).ncl];
	((Medium) this).pcv
	    = new float[((Medium) this).nrw * ((Medium) this).ncl];
	int i_39_ = 0;
	int i_40_ = 0;
	for (int i_41_ = 0; i_41_ < ((Medium) this).nrw * ((Medium) this).ncl;
	     i_41_++) {
	    ((Medium) this).cgpx[i_41_]
		= (((Medium) this).sgpx + i_39_ * 1200
		   + (int) (random.nextDouble() * 1000.0 - 500.0));
	    ((Medium) this).cgpz[i_41_]
		= (((Medium) this).sgpz + i_40_ * 1200
		   + (int) (random.nextDouble() * 1000.0 - 500.0));
	    if (trackers != null) {
		for (int i_42_ = 0; i_42_ < ((Trackers) trackers).nt;
		     i_42_++) {
		    if (((Trackers) trackers).zy[i_42_] == 0
			&& ((Trackers) trackers).xy[i_42_] == 0) {
			if ((((Trackers) trackers).radx[i_42_]
			     < ((Trackers) trackers).radz[i_42_])
			    && (Math.abs(((Medium) this).cgpz[i_41_]
					 - ((Trackers) trackers).z[i_42_])
				< ((Trackers) trackers).radz[i_42_])) {
			    for (/**/;
				 (Math.abs(((Medium) this).cgpx[i_41_]
					   - ((Trackers) trackers).x[i_42_])
				  < ((Trackers) trackers).radx[i_42_]);
				 ((Medium) this).cgpx[i_41_]
				     += ((random.nextDouble()
					  * (double) (((Trackers) trackers)
						      .radx[i_42_])
					  * 2.0)
					 - (double) (((Trackers) trackers).radx
						     [i_42_]))) {
				/* empty */
			    }
			}
			if ((((Trackers) trackers).radz[i_42_]
			     < ((Trackers) trackers).radx[i_42_])
			    && (Math.abs(((Medium) this).cgpx[i_41_]
					 - ((Trackers) trackers).x[i_42_])
				< ((Trackers) trackers).radx[i_42_])) {
			    for (/**/;
				 (Math.abs(((Medium) this).cgpz[i_41_]
					   - ((Trackers) trackers).z[i_42_])
				  < ((Trackers) trackers).radz[i_42_]);
				 ((Medium) this).cgpz[i_41_]
				     += ((random.nextDouble()
					  * (double) (((Trackers) trackers)
						      .radz[i_42_])
					  * 2.0)
					 - (double) (((Trackers) trackers).radz
						     [i_42_]))) {
				/* empty */
			    }
			}
		    }
		}
	    }
	    if (++i_39_ == ((Medium) this).nrw) {
		i_39_ = 0;
		i_40_++;
	    }
	}
	for (int i_43_ = 0; i_43_ < ((Medium) this).nrw * ((Medium) this).ncl;
	     i_43_++) {
	    float f = (float) (0.3 + 1.6 * random.nextDouble());
	    ((Medium) this).ogpx[i_43_][0] = 0;
	    ((Medium) this).ogpz[i_43_][0]
		= (int) ((100.0 + random.nextDouble() * 760.0) * (double) f);
	    ((Medium) this).ogpx[i_43_][1]
		= (int) ((100.0 + random.nextDouble() * 760.0) * 0.7071
			 * (double) f);
	    ((Medium) this).ogpz[i_43_][1] = ((Medium) this).ogpx[i_43_][1];
	    ((Medium) this).ogpx[i_43_][2]
		= (int) ((100.0 + random.nextDouble() * 760.0) * (double) f);
	    ((Medium) this).ogpz[i_43_][2] = 0;
	    ((Medium) this).ogpx[i_43_][3]
		= (int) ((100.0 + random.nextDouble() * 760.0) * 0.7071
			 * (double) f);
	    ((Medium) this).ogpz[i_43_][3] = -((Medium) this).ogpx[i_43_][3];
	    ((Medium) this).ogpx[i_43_][4] = 0;
	    ((Medium) this).ogpz[i_43_][4]
		= -(int) ((100.0 + random.nextDouble() * 760.0) * (double) f);
	    ((Medium) this).ogpx[i_43_][5]
		= -(int) ((100.0 + random.nextDouble() * 760.0) * 0.7071
			  * (double) f);
	    ((Medium) this).ogpz[i_43_][5] = ((Medium) this).ogpx[i_43_][5];
	    ((Medium) this).ogpx[i_43_][6]
		= -(int) ((100.0 + random.nextDouble() * 760.0) * (double) f);
	    ((Medium) this).ogpz[i_43_][6] = 0;
	    ((Medium) this).ogpx[i_43_][7]
		= -(int) ((100.0 + random.nextDouble() * 760.0) * 0.7071
			  * (double) f);
	    ((Medium) this).ogpz[i_43_][7] = -((Medium) this).ogpx[i_43_][7];
	    for (int i_44_ = 0; i_44_ < 8; i_44_++) {
		int i_45_ = i_44_ - 1;
		if (i_45_ == -1)
		    i_45_ = 7;
		int i_46_ = i_44_ + 1;
		if (i_46_ == 8)
		    i_46_ = 0;
		((Medium) this).ogpx[i_43_][i_44_]
		    = ((((Medium) this).ogpx[i_43_][i_45_]
			+ ((Medium) this).ogpx[i_43_][i_46_]) / 2
		       + ((Medium) this).ogpx[i_43_][i_44_]) / 2;
		((Medium) this).ogpz[i_43_][i_44_]
		    = ((((Medium) this).ogpz[i_43_][i_45_]
			+ ((Medium) this).ogpz[i_43_][i_46_]) / 2
		       + ((Medium) this).ogpz[i_43_][i_44_]) / 2;
		((Medium) this).pvr[i_43_][i_44_]
		    = (float) (1.1 + random.nextDouble() * 0.8);
		int i_47_
		    = (int) (Math.sqrt
			     ((double) (int) (((float) ((((Medium) this).ogpx
							 [i_43_][i_44_])
							* (((Medium) this).ogpx
							   [i_43_][i_44_]))
					       * (((Medium) this).pvr[i_43_]
						  [i_44_])
					       * (((Medium) this).pvr[i_43_]
						  [i_44_]))
					      + ((float) ((((Medium) this).ogpz
							   [i_43_][i_44_])
							  * (((Medium) this)
							     .ogpz[i_43_]
							     [i_44_]))
						 * (((Medium) this).pvr[i_43_]
						    [i_44_])
						 * (((Medium) this).pvr[i_43_]
						    [i_44_])))));
		if (i_47_ > ((Medium) this).pmx[i_43_])
		    ((Medium) this).pmx[i_43_] = i_47_;
	    }
	    ((Medium) this).pcv[i_43_]
		= (float) (0.97 + random.nextDouble() * 0.03);
	    if (((Medium) this).pcv[i_43_] > 1.0F)
		((Medium) this).pcv[i_43_] = 1.0F;
	    if (random.nextDouble() > random.nextDouble())
		((Medium) this).pcv[i_43_] = 1.0F;
	}
    }
    
    public void groundpolys(Graphics2D graphics2d) {
	int i = (((Medium) this).x - ((Medium) this).sgpx) / 1200 - 12;
	if (i < 0)
	    i = 0;
	int i_48_ = i + 25;
	if (i_48_ > ((Medium) this).nrw)
	    i_48_ = ((Medium) this).nrw;
	if (i_48_ < i)
	    i_48_ = i;
	int i_49_ = (((Medium) this).z - ((Medium) this).sgpz) / 1200 - 12;
	if (i_49_ < 0)
	    i_49_ = 0;
	int i_50_ = i_49_ + 25;
	if (i_50_ > ((Medium) this).ncl)
	    i_50_ = ((Medium) this).ncl;
	if (i_50_ < i_49_)
	    i_50_ = i_49_;
	int[][] is = new int[i_48_ - i][i_50_ - i_49_];
	for (int i_51_ = i; i_51_ < i_48_; i_51_++) {
	    for (int i_52_ = i_49_; i_52_ < i_50_; i_52_++) {
		is[i_51_ - i][i_52_ - i_49_] = 0;
		int i_53_ = i_51_ + i_52_ * ((Medium) this).nrw;
		if (((Medium) this).resdown < 2 || i_53_ % 2 == 0) {
		    int i_54_
			= (((Medium) this).cx
			   + (int) (((float) (((Medium) this).cgpx[i_53_]
					      - ((Medium) this).x
					      - ((Medium) this).cx)
				     * cos(((Medium) this).xz))
				    - ((float) (((Medium) this).cgpz[i_53_]
						- ((Medium) this).z
						- ((Medium) this).cz)
				       * sin(((Medium) this).xz))));
		    int i_55_
			= (((Medium) this).cz
			   + (int) (((float) (((Medium) this).cgpx[i_53_]
					      - ((Medium) this).x
					      - ((Medium) this).cx)
				     * sin(((Medium) this).xz))
				    + ((float) (((Medium) this).cgpz[i_53_]
						- ((Medium) this).z
						- ((Medium) this).cz)
				       * cos(((Medium) this).xz))));
		    int i_56_
			= (((Medium) this).cz
			   + (int) (((float) (250 - ((Medium) this).y
					      - ((Medium) this).cy)
				     * sin(((Medium) this).zy))
				    + ((float) (i_55_ - ((Medium) this).cz)
				       * cos(((Medium) this).zy))));
		    if (xs(i_54_ + ((Medium) this).pmx[i_53_], i_56_) > 0
			&& (xs(i_54_ - ((Medium) this).pmx[i_53_], i_56_)
			    < ((Medium) this).w)
			&& i_56_ > -((Medium) this).pmx[i_53_]
			&& i_56_ < ((Medium) this).fade[2]) {
			is[i_51_ - i][i_52_ - i_49_] = i_56_;
			int[] is_57_ = new int[8];
			int[] is_58_ = new int[8];
			int[] is_59_ = new int[8];
			for (int i_60_ = 0; i_60_ < 8; i_60_++) {
			    is_57_[i_60_]
				= (int) (((float) (((Medium) this).ogpx[i_53_]
						   [i_60_])
					  * ((Medium) this).pvr[i_53_][i_60_])
					 + (float) ((Medium) this).cgpx[i_53_]
					 - (float) ((Medium) this).x);
			    is_58_[i_60_]
				= (int) (((float) (((Medium) this).ogpz[i_53_]
						   [i_60_])
					  * ((Medium) this).pvr[i_53_][i_60_])
					 + (float) ((Medium) this).cgpz[i_53_]
					 - (float) ((Medium) this).z);
			    is_59_[i_60_] = ((Medium) this).ground;
			}
			rot(is_57_, is_58_, ((Medium) this).cx,
			    ((Medium) this).cz, ((Medium) this).xz, 8);
			rot(is_59_, is_58_, ((Medium) this).cy,
			    ((Medium) this).cz, ((Medium) this).zy, 8);
			int[] is_61_ = new int[8];
			int[] is_62_ = new int[8];
			int i_63_ = 0;
			int i_64_ = 0;
			int i_65_ = 0;
			int i_66_ = 0;
			boolean bool = true;
			for (int i_67_ = 0; i_67_ < 8; i_67_++) {
			    is_61_[i_67_] = xs(is_57_[i_67_], is_58_[i_67_]);
			    is_62_[i_67_] = ys(is_59_[i_67_], is_58_[i_67_]);
			    if (is_62_[i_67_] < 0 || is_58_[i_67_] < 10)
				i_63_++;
			    if (is_62_[i_67_] > ((Medium) this).h
				|| is_58_[i_67_] < 10)
				i_64_++;
			    if (is_61_[i_67_] < 0 || is_58_[i_67_] < 10)
				i_65_++;
			    if (is_61_[i_67_] > ((Medium) this).w
				|| is_58_[i_67_] < 10)
				i_66_++;
			}
			if (i_65_ == 8 || i_63_ == 8 || i_64_ == 8
			    || i_66_ == 8)
			    bool = false;
			if (bool) {
			    int i_68_
				= (int) ((((float) ((Medium) this).cpol[0]
					   * ((Medium) this).pcv[i_53_])
					  + (float) ((Medium) this).cgrnd[0])
					 / 2.0F);
			    int i_69_
				= (int) ((((float) ((Medium) this).cpol[1]
					   * ((Medium) this).pcv[i_53_])
					  + (float) ((Medium) this).cgrnd[1])
					 / 2.0F);
			    int i_70_
				= (int) ((((float) ((Medium) this).cpol[2]
					   * ((Medium) this).pcv[i_53_])
					  + (float) ((Medium) this).cgrnd[2])
					 / 2.0F);
			    if (i_56_ - ((Medium) this).pmx[i_53_]
				> ((Medium) this).fade[0]) {
				i_68_ = ((i_68_ * 7 + ((Medium) this).cfade[0])
					 / 8);
				i_69_ = ((i_69_ * 7 + ((Medium) this).cfade[1])
					 / 8);
				i_70_ = ((i_70_ * 7 + ((Medium) this).cfade[2])
					 / 8);
			    }
			    if (i_56_ - ((Medium) this).pmx[i_53_]
				> ((Medium) this).fade[1]) {
				i_68_ = ((i_68_ * 7 + ((Medium) this).cfade[0])
					 / 8);
				i_69_ = ((i_69_ * 7 + ((Medium) this).cfade[1])
					 / 8);
				i_70_ = ((i_70_ * 7 + ((Medium) this).cfade[2])
					 / 8);
			    }
			    graphics2d.setColor(new Color(i_68_, i_69_,
							  i_70_));
			    graphics2d.fillPolygon(is_61_, is_62_, 8);
			}
		    }
		}
	    }
	}
	for (int i_71_ = i; i_71_ < i_48_; i_71_++) {
	    for (int i_72_ = i_49_; i_72_ < i_50_; i_72_++) {
		if (is[i_71_ - i][i_72_ - i_49_] != 0) {
		    int i_73_ = i_71_ + i_72_ * ((Medium) this).nrw;
		    int[] is_74_ = new int[8];
		    int[] is_75_ = new int[8];
		    int[] is_76_ = new int[8];
		    for (int i_77_ = 0; i_77_ < 8; i_77_++) {
			is_74_[i_77_] = (((Medium) this).ogpx[i_73_][i_77_]
					 + ((Medium) this).cgpx[i_73_]
					 - ((Medium) this).x);
			is_75_[i_77_] = (((Medium) this).ogpz[i_73_][i_77_]
					 + ((Medium) this).cgpz[i_73_]
					 - ((Medium) this).z);
			is_76_[i_77_] = ((Medium) this).ground;
		    }
		    rot(is_74_, is_75_, ((Medium) this).cx, ((Medium) this).cz,
			((Medium) this).xz, 8);
		    rot(is_76_, is_75_, ((Medium) this).cy, ((Medium) this).cz,
			((Medium) this).zy, 8);
		    int[] is_78_ = new int[8];
		    int[] is_79_ = new int[8];
		    int i_80_ = 0;
		    int i_81_ = 0;
		    int i_82_ = 0;
		    int i_83_ = 0;
		    boolean bool = true;
		    for (int i_84_ = 0; i_84_ < 8; i_84_++) {
			is_78_[i_84_] = xs(is_74_[i_84_], is_75_[i_84_]);
			is_79_[i_84_] = ys(is_76_[i_84_], is_75_[i_84_]);
			if (is_79_[i_84_] < 0 || is_75_[i_84_] < 10)
			    i_80_++;
			if (is_79_[i_84_] > ((Medium) this).h
			    || is_75_[i_84_] < 10)
			    i_81_++;
			if (is_78_[i_84_] < 0 || is_75_[i_84_] < 10)
			    i_82_++;
			if (is_78_[i_84_] > ((Medium) this).w
			    || is_75_[i_84_] < 10)
			    i_83_++;
		    }
		    if (i_82_ == 8 || i_80_ == 8 || i_81_ == 8 || i_83_ == 8)
			bool = false;
		    if (bool) {
			int i_85_ = (int) ((float) ((Medium) this).cpol[0]
					   * ((Medium) this).pcv[i_73_]);
			int i_86_ = (int) ((float) ((Medium) this).cpol[1]
					   * ((Medium) this).pcv[i_73_]);
			int i_87_ = (int) ((float) ((Medium) this).cpol[2]
					   * ((Medium) this).pcv[i_73_]);
			if ((is[i_71_ - i][i_72_ - i_49_]
			     - ((Medium) this).pmx[i_73_])
			    > ((Medium) this).fade[0]) {
			    i_85_ = (i_85_ * 7 + ((Medium) this).cfade[0]) / 8;
			    i_86_ = (i_86_ * 7 + ((Medium) this).cfade[1]) / 8;
			    i_87_ = (i_87_ * 7 + ((Medium) this).cfade[2]) / 8;
			}
			if ((is[i_71_ - i][i_72_ - i_49_]
			     - ((Medium) this).pmx[i_73_])
			    > ((Medium) this).fade[1]) {
			    i_85_ = (i_85_ * 7 + ((Medium) this).cfade[0]) / 8;
			    i_86_ = (i_86_ * 7 + ((Medium) this).cfade[1]) / 8;
			    i_87_ = (i_87_ * 7 + ((Medium) this).cfade[2]) / 8;
			}
			graphics2d.setColor(new Color(i_85_, i_86_, i_87_));
			graphics2d.fillPolygon(is_78_, is_79_, 8);
		    }
		}
	    }
	}
    }
    
    public void newclouds(int i, int i_88_, int i_89_, int i_90_) {
	((Medium) this).clx = null;
	((Medium) this).clz = null;
	((Medium) this).cmx = null;
	((Medium) this).clax = null;
	((Medium) this).clay = null;
	((Medium) this).claz = null;
	((Medium) this).clc = null;
	i = i / 20 - 10000;
	i_88_ = i_88_ / 20 + 10000;
	i_89_ = i_89_ / 20 - 10000;
	i_90_ = i_90_ / 20 + 10000;
	((Medium) this).noc = (i_88_ - i) * (i_90_ - i_89_) / 16666667;
	((Medium) this).clx = new int[((Medium) this).noc];
	((Medium) this).clz = new int[((Medium) this).noc];
	((Medium) this).cmx = new int[((Medium) this).noc];
	((Medium) this).clax = new int[((Medium) this).noc][3][12];
	((Medium) this).clay = new int[((Medium) this).noc][3][12];
	((Medium) this).claz = new int[((Medium) this).noc][3][12];
	((Medium) this).clc = new int[((Medium) this).noc][2][6][3];
	for (int i_91_ = 0; i_91_ < ((Medium) this).noc; i_91_++) {
	    ((Medium) this).clx[i_91_]
		= (int) ((double) i + (double) (i_88_ - i) * Math.random());
	    ((Medium) this).clz[i_91_]
		= (int) ((double) i_89_
			 + (double) (i_90_ - i_89_) * Math.random());
	    float f = (float) (0.25 + Math.random() * 1.25);
	    float f_92_
		= (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][0]
		= (int) ((double) f_92_ * 0.3826);
	    ((Medium) this).claz[i_91_][0][0]
		= (int) ((double) f_92_ * 0.9238);
	    ((Medium) this).clay[i_91_][0][0]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][1]
		= (int) ((double) f_92_ * 0.7071);
	    ((Medium) this).claz[i_91_][0][1]
		= (int) ((double) f_92_ * 0.7071);
	    ((Medium) this).clay[i_91_][0][1]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][2]
		= (int) ((double) f_92_ * 0.9238);
	    ((Medium) this).claz[i_91_][0][2]
		= (int) ((double) f_92_ * 0.3826);
	    ((Medium) this).clay[i_91_][0][2]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][3]
		= (int) ((double) f_92_ * 0.9238);
	    ((Medium) this).claz[i_91_][0][3]
		= -(int) ((double) f_92_ * 0.3826);
	    ((Medium) this).clay[i_91_][0][3]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][4]
		= (int) ((double) f_92_ * 0.7071);
	    ((Medium) this).claz[i_91_][0][4]
		= -(int) ((double) f_92_ * 0.7071);
	    ((Medium) this).clay[i_91_][0][4]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][5]
		= (int) ((double) f_92_ * 0.3826);
	    ((Medium) this).claz[i_91_][0][5]
		= -(int) ((double) f_92_ * 0.9238);
	    ((Medium) this).clay[i_91_][0][5]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][6]
		= -(int) ((double) f_92_ * 0.3826);
	    ((Medium) this).claz[i_91_][0][6]
		= -(int) ((double) f_92_ * 0.9238);
	    ((Medium) this).clay[i_91_][0][6]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][7]
		= -(int) ((double) f_92_ * 0.7071);
	    ((Medium) this).claz[i_91_][0][7]
		= -(int) ((double) f_92_ * 0.7071);
	    ((Medium) this).clay[i_91_][0][7]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][8]
		= -(int) ((double) f_92_ * 0.9238);
	    ((Medium) this).claz[i_91_][0][8]
		= -(int) ((double) f_92_ * 0.3826);
	    ((Medium) this).clay[i_91_][0][8]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][9]
		= -(int) ((double) f_92_ * 0.9238);
	    ((Medium) this).claz[i_91_][0][9]
		= (int) ((double) f_92_ * 0.3826);
	    ((Medium) this).clay[i_91_][0][9]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][10]
		= -(int) ((double) f_92_ * 0.7071);
	    ((Medium) this).claz[i_91_][0][10]
		= (int) ((double) f_92_ * 0.7071);
	    ((Medium) this).clay[i_91_][0][10]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    f_92_ = (float) ((200.0 + Math.random() * 700.0) * (double) f);
	    ((Medium) this).clax[i_91_][0][11]
		= -(int) ((double) f_92_ * 0.3826);
	    ((Medium) this).claz[i_91_][0][11]
		= (int) ((double) f_92_ * 0.9238);
	    ((Medium) this).clay[i_91_][0][11]
		= (int) ((25.0 - Math.random() * 50.0) * (double) f);
	    for (int i_93_ = 0; i_93_ < 12; i_93_++) {
		int i_94_ = i_93_ - 1;
		if (i_94_ == -1)
		    i_94_ = 11;
		int i_95_ = i_93_ + 1;
		if (i_95_ == 12)
		    i_95_ = 0;
		((Medium) this).clax[i_91_][0][i_93_]
		    = ((((Medium) this).clax[i_91_][0][i_94_]
			+ ((Medium) this).clax[i_91_][0][i_95_]) / 2
		       + ((Medium) this).clax[i_91_][0][i_93_]) / 2;
		((Medium) this).clay[i_91_][0][i_93_]
		    = ((((Medium) this).clay[i_91_][0][i_94_]
			+ ((Medium) this).clay[i_91_][0][i_95_]) / 2
		       + ((Medium) this).clay[i_91_][0][i_93_]) / 2;
		((Medium) this).claz[i_91_][0][i_93_]
		    = ((((Medium) this).claz[i_91_][0][i_94_]
			+ ((Medium) this).claz[i_91_][0][i_95_]) / 2
		       + ((Medium) this).claz[i_91_][0][i_93_]) / 2;
	    }
	    for (int i_96_ = 0; i_96_ < 12; i_96_++) {
		f_92_ = (float) (1.2 + 0.6 * Math.random());
		((Medium) this).clax[i_91_][1][i_96_]
		    = (int) ((float) ((Medium) this).clax[i_91_][0][i_96_]
			     * f_92_);
		((Medium) this).claz[i_91_][1][i_96_]
		    = (int) ((float) ((Medium) this).claz[i_91_][0][i_96_]
			     * f_92_);
		((Medium) this).clay[i_91_][1][i_96_]
		    = (int) ((double) ((Medium) this).clay[i_91_][0][i_96_]
			     - 100.0 * Math.random());
		f_92_ = (float) (1.1 + 0.3 * Math.random());
		((Medium) this).clax[i_91_][2][i_96_]
		    = (int) ((float) ((Medium) this).clax[i_91_][1][i_96_]
			     * f_92_);
		((Medium) this).claz[i_91_][2][i_96_]
		    = (int) ((float) ((Medium) this).claz[i_91_][1][i_96_]
			     * f_92_);
		((Medium) this).clay[i_91_][2][i_96_]
		    = (int) ((double) ((Medium) this).clay[i_91_][1][i_96_]
			     - 240.0 * Math.random());
	    }
	    ((Medium) this).cmx[i_91_] = 0;
	    for (int i_97_ = 0; i_97_ < 12; i_97_++) {
		int i_98_ = i_97_ - 1;
		if (i_98_ == -1)
		    i_98_ = 11;
		int i_99_ = i_97_ + 1;
		if (i_99_ == 12)
		    i_99_ = 0;
		((Medium) this).clay[i_91_][1][i_97_]
		    = ((((Medium) this).clay[i_91_][1][i_98_]
			+ ((Medium) this).clay[i_91_][1][i_99_]) / 2
		       + ((Medium) this).clay[i_91_][1][i_97_]) / 2;
		((Medium) this).clay[i_91_][2][i_97_]
		    = ((((Medium) this).clay[i_91_][2][i_98_]
			+ ((Medium) this).clay[i_91_][2][i_99_]) / 2
		       + ((Medium) this).clay[i_91_][2][i_97_]) / 2;
		int i_100_
		    = (int) Math.sqrt((double) (((((Medium) this).clax[i_91_]
						  [2][i_97_])
						 * (((Medium) this).clax[i_91_]
						    [2][i_97_]))
						+ ((((Medium) this).claz[i_91_]
						    [2][i_97_])
						   * (((Medium) this).claz
						      [i_91_][2][i_97_]))));
		if (i_100_ > ((Medium) this).cmx[i_91_])
		    ((Medium) this).cmx[i_91_] = i_100_;
	    }
	    for (int i_101_ = 0; i_101_ < 6; i_101_++) {
		double d = Math.random();
		double d_102_ = Math.random();
		for (int i_103_ = 0; i_103_ < 3; i_103_++) {
		    f_92_ = ((float) ((Medium) this).clds[i_103_] * 1.05F
			     - (float) ((Medium) this).clds[i_103_]);
		    ((Medium) this).clc[i_91_][0][i_101_][i_103_]
			= (int) ((double) ((Medium) this).clds[i_103_]
				 + (double) f_92_ * d);
		    if (((Medium) this).clc[i_91_][0][i_101_][i_103_] > 255)
			((Medium) this).clc[i_91_][0][i_101_][i_103_] = 255;
		    if (((Medium) this).clc[i_91_][0][i_101_][i_103_] < 0)
			((Medium) this).clc[i_91_][0][i_101_][i_103_] = 0;
		    ((Medium) this).clc[i_91_][1][i_101_][i_103_]
			= (int) ((double) ((float) ((Medium) this).clds[i_103_]
					   * 1.05F)
				 + (double) f_92_ * d_102_);
		    if (((Medium) this).clc[i_91_][1][i_101_][i_103_] > 255)
			((Medium) this).clc[i_91_][1][i_101_][i_103_] = 255;
		    if (((Medium) this).clc[i_91_][1][i_101_][i_103_] < 0)
			((Medium) this).clc[i_91_][1][i_101_][i_103_] = 0;
		}
	    }
	}
    }
    
    public void drawclouds(Graphics2D graphics2d) {
	for (int i = 0; i < ((Medium) this).noc; i++) {
	    int i_104_ = (((Medium) this).cx
			  + (int) (((float) (((Medium) this).clx[i]
					     - ((Medium) this).x / 20
					     - ((Medium) this).cx)
				    * cos(((Medium) this).xz))
				   - ((float) (((Medium) this).clz[i]
					       - ((Medium) this).z / 20
					       - ((Medium) this).cz)
				      * sin(((Medium) this).xz))));
	    int i_105_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).clx[i]
					     - ((Medium) this).x / 20
					     - ((Medium) this).cx)
				    * sin(((Medium) this).xz))
				   + ((float) (((Medium) this).clz[i]
					       - ((Medium) this).z / 20
					       - ((Medium) this).cz)
				      * cos(((Medium) this).xz))));
	    int i_106_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).cldd[4]
					     - ((Medium) this).y / 20
					     - ((Medium) this).cy)
				    * sin(((Medium) this).zy))
				   + ((float) (i_105_ - ((Medium) this).cz)
				      * cos(((Medium) this).zy))));
	    int i_107_ = xs(i_104_ + ((Medium) this).cmx[i], i_106_);
	    int i_108_ = xs(i_104_ - ((Medium) this).cmx[i], i_106_);
	    if (i_107_ > 0 && i_108_ < ((Medium) this).w
		&& i_106_ > -((Medium) this).cmx[i] && i_107_ - i_108_ > 20) {
		int[][] is = new int[3][12];
		int[][] is_109_ = new int[3][12];
		int[][] is_110_ = new int[3][12];
		int[] is_111_ = new int[12];
		int[] is_112_ = new int[12];
		boolean bool = false;
		boolean bool_113_ = false;
		boolean bool_114_ = false;
		boolean bool_115_ = false;
		boolean bool_116_ = true;
		boolean bool_117_ = false;
		boolean bool_118_ = false;
		boolean bool_119_ = false;
		for (int i_120_ = 0; i_120_ < 3; i_120_++) {
		    for (int i_121_ = 0; i_121_ < 12; i_121_++) {
			is[i_120_][i_121_]
			    = (((Medium) this).clax[i][i_120_][i_121_]
			       + ((Medium) this).clx[i]
			       - ((Medium) this).x / 20);
			is_110_[i_120_][i_121_]
			    = (((Medium) this).claz[i][i_120_][i_121_]
			       + ((Medium) this).clz[i]
			       - ((Medium) this).z / 20);
			is_109_[i_120_][i_121_]
			    = (((Medium) this).clay[i][i_120_][i_121_]
			       + ((Medium) this).cldd[4]
			       - ((Medium) this).y / 20);
		    }
		    rot(is[i_120_], is_110_[i_120_], ((Medium) this).cx,
			((Medium) this).cz, ((Medium) this).xz, 12);
		    rot(is_109_[i_120_], is_110_[i_120_], ((Medium) this).cy,
			((Medium) this).cz, ((Medium) this).zy, 12);
		}
		for (int i_122_ = 0; i_122_ < 12; i_122_ += 2) {
		    int i_123_ = 0;
		    int i_124_ = 0;
		    int i_125_ = 0;
		    int i_126_ = 0;
		    bool_116_ = true;
		    int i_127_ = 0;
		    int i_128_ = 0;
		    int i_129_ = 0;
		    for (int i_130_ = 0; i_130_ < 6; i_130_++) {
			int i_131_ = 0;
			int i_132_ = 1;
			if (i_130_ == 0)
			    i_131_ = i_122_;
			if (i_130_ == 1) {
			    i_131_ = i_122_ + 1;
			    if (i_131_ >= 12)
				i_131_ -= 12;
			}
			if (i_130_ == 2) {
			    i_131_ = i_122_ + 2;
			    if (i_131_ >= 12)
				i_131_ -= 12;
			}
			if (i_130_ == 3) {
			    i_131_ = i_122_ + 2;
			    if (i_131_ >= 12)
				i_131_ -= 12;
			    i_132_ = 2;
			}
			if (i_130_ == 4) {
			    i_131_ = i_122_ + 1;
			    if (i_131_ >= 12)
				i_131_ -= 12;
			    i_132_ = 2;
			}
			if (i_130_ == 5) {
			    i_131_ = i_122_;
			    i_132_ = 2;
			}
			is_111_[i_130_]
			    = xs(is[i_132_][i_131_], is_110_[i_132_][i_131_]);
			is_112_[i_130_] = ys(is_109_[i_132_][i_131_],
					     is_110_[i_132_][i_131_]);
			i_128_ += is[i_132_][i_131_];
			i_127_ += is_109_[i_132_][i_131_];
			i_129_ += is_110_[i_132_][i_131_];
			if (is_112_[i_130_] < 0 || is_110_[0][i_130_] < 10)
			    i_123_++;
			if (is_112_[i_130_] > ((Medium) this).h
			    || is_110_[0][i_130_] < 10)
			    i_124_++;
			if (is_111_[i_130_] < 0 || is_110_[0][i_130_] < 10)
			    i_125_++;
			if (is_111_[i_130_] > ((Medium) this).w
			    || is_110_[0][i_130_] < 10)
			    i_126_++;
		    }
		    if (i_125_ == 6 || i_123_ == 6 || i_124_ == 6
			|| i_126_ == 6)
			bool_116_ = false;
		    if (bool_116_) {
			i_128_ /= 6;
			i_127_ /= 6;
			i_129_ /= 6;
			int i_133_
			    = (int) Math.sqrt((double) (((((Medium) this).cy
							  - i_127_)
							 * (((Medium) this).cy
							    - i_127_))
							+ ((((Medium) this).cx
							    - i_128_)
							   * ((((Medium) this)
							       .cx)
							      - i_128_))
							+ i_129_ * i_129_));
			if (i_133_ < ((Medium) this).fade[7]) {
			    int i_134_
				= ((Medium) this).clc[i][1][i_122_ / 2][0];
			    int i_135_
				= ((Medium) this).clc[i][1][i_122_ / 2][1];
			    int i_136_
				= ((Medium) this).clc[i][1][i_122_ / 2][2];
			    for (int i_137_ = 0; i_137_ < 16; i_137_++) {
				if (i_133_ > ((Medium) this).fade[i_137_]) {
				    i_134_ = ((i_134_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[0])
					      / (((Medium) this).fogd + 1));
				    i_135_ = ((i_135_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[1])
					      / (((Medium) this).fogd + 1));
				    i_136_ = ((i_136_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[2])
					      / (((Medium) this).fogd + 1));
				}
			    }
			    graphics2d.setColor(new Color(i_134_, i_135_,
							  i_136_));
			    graphics2d.fillPolygon(is_111_, is_112_, 6);
			}
		    }
		}
		for (int i_138_ = 0; i_138_ < 12; i_138_ += 2) {
		    int i_139_ = 0;
		    int i_140_ = 0;
		    int i_141_ = 0;
		    int i_142_ = 0;
		    bool_116_ = true;
		    int i_143_ = 0;
		    int i_144_ = 0;
		    int i_145_ = 0;
		    for (int i_146_ = 0; i_146_ < 6; i_146_++) {
			int i_147_ = 0;
			int i_148_ = 0;
			if (i_146_ == 0)
			    i_147_ = i_138_;
			if (i_146_ == 1) {
			    i_147_ = i_138_ + 1;
			    if (i_147_ >= 12)
				i_147_ -= 12;
			}
			if (i_146_ == 2) {
			    i_147_ = i_138_ + 2;
			    if (i_147_ >= 12)
				i_147_ -= 12;
			}
			if (i_146_ == 3) {
			    i_147_ = i_138_ + 2;
			    if (i_147_ >= 12)
				i_147_ -= 12;
			    i_148_ = 1;
			}
			if (i_146_ == 4) {
			    i_147_ = i_138_ + 1;
			    if (i_147_ >= 12)
				i_147_ -= 12;
			    i_148_ = 1;
			}
			if (i_146_ == 5) {
			    i_147_ = i_138_;
			    i_148_ = 1;
			}
			is_111_[i_146_]
			    = xs(is[i_148_][i_147_], is_110_[i_148_][i_147_]);
			is_112_[i_146_] = ys(is_109_[i_148_][i_147_],
					     is_110_[i_148_][i_147_]);
			i_144_ += is[i_148_][i_147_];
			i_143_ += is_109_[i_148_][i_147_];
			i_145_ += is_110_[i_148_][i_147_];
			if (is_112_[i_146_] < 0 || is_110_[0][i_146_] < 10)
			    i_139_++;
			if (is_112_[i_146_] > ((Medium) this).h
			    || is_110_[0][i_146_] < 10)
			    i_140_++;
			if (is_111_[i_146_] < 0 || is_110_[0][i_146_] < 10)
			    i_141_++;
			if (is_111_[i_146_] > ((Medium) this).w
			    || is_110_[0][i_146_] < 10)
			    i_142_++;
		    }
		    if (i_141_ == 6 || i_139_ == 6 || i_140_ == 6
			|| i_142_ == 6)
			bool_116_ = false;
		    if (bool_116_) {
			i_144_ /= 6;
			i_143_ /= 6;
			i_145_ /= 6;
			int i_149_
			    = (int) Math.sqrt((double) (((((Medium) this).cy
							  - i_143_)
							 * (((Medium) this).cy
							    - i_143_))
							+ ((((Medium) this).cx
							    - i_144_)
							   * ((((Medium) this)
							       .cx)
							      - i_144_))
							+ i_145_ * i_145_));
			if (i_149_ < ((Medium) this).fade[7]) {
			    int i_150_
				= ((Medium) this).clc[i][0][i_138_ / 2][0];
			    int i_151_
				= ((Medium) this).clc[i][0][i_138_ / 2][1];
			    int i_152_
				= ((Medium) this).clc[i][0][i_138_ / 2][2];
			    for (int i_153_ = 0; i_153_ < 16; i_153_++) {
				if (i_149_ > ((Medium) this).fade[i_153_]) {
				    i_150_ = ((i_150_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[0])
					      / (((Medium) this).fogd + 1));
				    i_151_ = ((i_151_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[1])
					      / (((Medium) this).fogd + 1));
				    i_152_ = ((i_152_ * ((Medium) this).fogd
					       + ((Medium) this).cfade[2])
					      / (((Medium) this).fogd + 1));
				}
			    }
			    graphics2d.setColor(new Color(i_150_, i_151_,
							  i_152_));
			    graphics2d.fillPolygon(is_111_, is_112_, 6);
			}
		    }
		}
		int i_154_ = 0;
		int i_155_ = 0;
		int i_156_ = 0;
		int i_157_ = 0;
		bool_116_ = true;
		int i_158_ = 0;
		int i_159_ = 0;
		int i_160_ = 0;
		for (int i_161_ = 0; i_161_ < 12; i_161_++) {
		    is_111_[i_161_] = xs(is[0][i_161_], is_110_[0][i_161_]);
		    is_112_[i_161_]
			= ys(is_109_[0][i_161_], is_110_[0][i_161_]);
		    i_159_ += is[0][i_161_];
		    i_158_ += is_109_[0][i_161_];
		    i_160_ += is_110_[0][i_161_];
		    if (is_112_[i_161_] < 0 || is_110_[0][i_161_] < 10)
			i_154_++;
		    if (is_112_[i_161_] > ((Medium) this).h
			|| is_110_[0][i_161_] < 10)
			i_155_++;
		    if (is_111_[i_161_] < 0 || is_110_[0][i_161_] < 10)
			i_156_++;
		    if (is_111_[i_161_] > ((Medium) this).w
			|| is_110_[0][i_161_] < 10)
			i_157_++;
		}
		if (i_156_ == 12 || i_154_ == 12 || i_155_ == 12
		    || i_157_ == 12)
		    bool_116_ = false;
		if (bool_116_) {
		    i_159_ /= 12;
		    i_158_ /= 12;
		    i_160_ /= 12;
		    int i_162_
			= (int) Math.sqrt((double) (((((Medium) this).cy
						      - i_158_)
						     * (((Medium) this).cy
							- i_158_))
						    + ((((Medium) this).cx
							- i_159_)
						       * (((Medium) this).cx
							  - i_159_))
						    + i_160_ * i_160_));
		    if (i_162_ < ((Medium) this).fade[7]) {
			int i_163_ = ((Medium) this).clds[0];
			int i_164_ = ((Medium) this).clds[1];
			int i_165_ = ((Medium) this).clds[2];
			for (int i_166_ = 0; i_166_ < 16; i_166_++) {
			    if (i_162_ > ((Medium) this).fade[i_166_]) {
				i_163_ = ((i_163_ * ((Medium) this).fogd
					   + ((Medium) this).cfade[0])
					  / (((Medium) this).fogd + 1));
				i_164_ = ((i_164_ * ((Medium) this).fogd
					   + ((Medium) this).cfade[1])
					  / (((Medium) this).fogd + 1));
				i_165_ = ((i_165_ * ((Medium) this).fogd
					   + ((Medium) this).cfade[2])
					  / (((Medium) this).fogd + 1));
			    }
			}
			graphics2d.setColor(new Color(i_163_, i_164_, i_165_));
			graphics2d.fillPolygon(is_111_, is_112_, 12);
		    }
		}
	    }
	}
    }
    
    public void newmountains(int i, int i_167_, int i_168_, int i_169_) {
	Random random = new Random((long) ((Medium) this).mgen);
	((Medium) this).nmt = (int) (20.0 + 10.0 * random.nextDouble());
	int i_170_ = (i + i_167_) / 60;
	int i_171_ = (i_168_ + i_169_) / 60;
	int i_172_ = Math.max(i_167_ - i, i_169_ - i_168_) / 60;
	((Medium) this).mrd = null;
	((Medium) this).nmv = null;
	((Medium) this).mtx = null;
	((Medium) this).mty = null;
	((Medium) this).mtz = null;
	((Medium) this).mtc = null;
	((Medium) this).mrd = new int[((Medium) this).nmt];
	((Medium) this).nmv = new int[((Medium) this).nmt];
	((Medium) this).mtx = new int[((Medium) this).nmt][];
	((Medium) this).mty = new int[((Medium) this).nmt][];
	((Medium) this).mtz = new int[((Medium) this).nmt][];
	((Medium) this).mtc = new int[((Medium) this).nmt][][];
	int[] is = new int[((Medium) this).nmt];
	int[] is_173_ = new int[((Medium) this).nmt];
	for (int i_174_ = 0; i_174_ < ((Medium) this).nmt; i_174_++) {
	    int i_175_ = 85;
	    float f = 0.5F;
	    float f_176_ = 0.5F;
	    is[i_174_] = (int) (10000.0 + random.nextDouble() * 10000.0);
	    int i_177_ = (int) (random.nextDouble() * 360.0);
	    if (random.nextDouble() > random.nextDouble()) {
		f = (float) (0.2 + random.nextDouble() * 0.35);
		f_176_ = (float) (0.2 + random.nextDouble() * 0.35);
		((Medium) this).nmv[i_174_]
		    = (int) ((double) f * (24.0 + 16.0 * random.nextDouble()));
		i_175_ = (int) (85.0 + 10.0 * random.nextDouble());
	    } else {
		f = (float) (0.3 + random.nextDouble() * 1.1);
		f_176_ = (float) (0.2 + random.nextDouble() * 0.35);
		((Medium) this).nmv[i_174_]
		    = (int) ((double) f * (12.0 + 8.0 * random.nextDouble()));
		i_175_ = (int) (104.0 - 10.0 * random.nextDouble());
	    }
	    ((Medium) this).mtx[i_174_]
		= new int[((Medium) this).nmv[i_174_] * 2];
	    ((Medium) this).mty[i_174_]
		= new int[((Medium) this).nmv[i_174_] * 2];
	    ((Medium) this).mtz[i_174_]
		= new int[((Medium) this).nmv[i_174_] * 2];
	    ((Medium) this).mtc[i_174_]
		= new int[((Medium) this).nmv[i_174_]][3];
	    for (int i_178_ = 0; i_178_ < ((Medium) this).nmv[i_174_];
		 i_178_++) {
		((Medium) this).mtx[i_174_][i_178_]
		    = (int) (((double) (i_178_ * 500)
			      + (random.nextDouble() * 800.0 - 400.0)
			      - (double) (250
					  * (((Medium) this).nmv[i_174_] - 1)))
			     * (double) f);
		((Medium) this).mtx[i_174_][(i_178_
					     + ((Medium) this).nmv[i_174_])]
		    = (int) (((double) (i_178_ * 500)
			      + (random.nextDouble() * 800.0 - 400.0)
			      - (double) (250
					  * (((Medium) this).nmv[i_174_] - 1)))
			     * (double) f);
		((Medium) this).mtx[i_174_][((Medium) this).nmv[i_174_]]
		    = (int) ((double) ((Medium) this).mtx[i_174_][0]
			     - ((100.0 + random.nextDouble() * 600.0)
				* (double) f));
		((Medium) this).mtx[i_174_][(((Medium) this).nmv[i_174_] * 2
					     - 1)]
		    = (int) ((double) (((Medium) this).mtx[i_174_]
				       [((Medium) this).nmv[i_174_] - 1])
			     + ((100.0 + random.nextDouble() * 600.0)
				* (double) f));
		if (i_178_ == 0 || i_178_ == ((Medium) this).nmv[i_174_] - 1)
		    ((Medium) this).mty[i_174_][i_178_]
			= (int) (((-400.0 - 1200.0 * random.nextDouble())
				  * (double) f_176_)
				 + (double) ((Medium) this).ground);
		if (i_178_ == 1 || i_178_ == ((Medium) this).nmv[i_174_] - 2)
		    ((Medium) this).mty[i_174_][i_178_]
			= (int) (((-1000.0 - 1450.0 * random.nextDouble())
				  * (double) f_176_)
				 + (double) ((Medium) this).ground);
		if (i_178_ > 1 && i_178_ < ((Medium) this).nmv[i_174_] - 2)
		    ((Medium) this).mty[i_174_][i_178_]
			= (int) (((-1600.0 - 1700.0 * random.nextDouble())
				  * (double) f_176_)
				 + (double) ((Medium) this).ground);
		((Medium) this).mty[i_174_][(i_178_
					     + ((Medium) this).nmv[i_174_])]
		    = ((Medium) this).ground - 70;
		((Medium) this).mtz[i_174_][i_178_]
		    = i_171_ + i_172_ + is[i_174_];
		((Medium) this).mtz[i_174_][(i_178_
					     + ((Medium) this).nmv[i_174_])]
		    = i_171_ + i_172_ + is[i_174_];
		float f_179_ = (float) (0.5 + random.nextDouble() * 0.5);
		((Medium) this).mtc[i_174_][i_178_][0]
		    = (int) (170.0F * f_179_
			     + (170.0F * f_179_
				* ((float) ((Medium) this).snap[0] / 100.0F)));
		if (((Medium) this).mtc[i_174_][i_178_][0] > 255)
		    ((Medium) this).mtc[i_174_][i_178_][0] = 255;
		if (((Medium) this).mtc[i_174_][i_178_][0] < 0)
		    ((Medium) this).mtc[i_174_][i_178_][0] = 0;
		((Medium) this).mtc[i_174_][i_178_][1]
		    = (int) ((float) i_175_ * f_179_
			     + (85.0F * f_179_
				* ((float) ((Medium) this).snap[1] / 100.0F)));
		if (((Medium) this).mtc[i_174_][i_178_][1] > 255)
		    ((Medium) this).mtc[i_174_][i_178_][1] = 255;
		if (((Medium) this).mtc[i_174_][i_178_][1] < 1)
		    ((Medium) this).mtc[i_174_][i_178_][1] = 0;
		((Medium) this).mtc[i_174_][i_178_][2] = 0;
	    }
	    for (int i_180_ = 1; i_180_ < ((Medium) this).nmv[i_174_] - 1;
		 i_180_++) {
		int i_181_ = i_180_ - 1;
		int i_182_ = i_180_ + 1;
		((Medium) this).mty[i_174_][i_180_]
		    = ((((Medium) this).mty[i_174_][i_181_]
			+ ((Medium) this).mty[i_174_][i_182_]) / 2
		       + ((Medium) this).mty[i_174_][i_180_]) / 2;
	    }
	    rot(((Medium) this).mtx[i_174_], ((Medium) this).mtz[i_174_],
		i_170_, i_171_, i_177_, ((Medium) this).nmv[i_174_] * 2);
	    is_173_[i_174_] = 0;
	}
	for (int i_183_ = 0; i_183_ < ((Medium) this).nmt; i_183_++) {
	    for (int i_184_ = i_183_ + 1; i_184_ < ((Medium) this).nmt;
		 i_184_++) {
		if (is[i_183_] < is[i_184_])
		    is_173_[i_183_]++;
		else
		    is_173_[i_184_]++;
	    }
	    ((Medium) this).mrd[is_173_[i_183_]] = i_183_;
	}
    }
    
    public void drawmountains(Graphics2D graphics2d) {
	for (int i = 0; i < ((Medium) this).nmt; i++) {
	    int i_185_ = ((Medium) this).mrd[i];
	    int i_186_ = (((Medium) this).cx
			  + (int) (((float) (((Medium) this).mtx[i_185_][0]
					     - ((Medium) this).x / 30
					     - ((Medium) this).cx)
				    * cos(((Medium) this).xz))
				   - ((float) (((Medium) this).mtz[i_185_][0]
					       - ((Medium) this).z / 30
					       - ((Medium) this).cz)
				      * sin(((Medium) this).xz))));
	    int i_187_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).mtx[i_185_][0]
					     - ((Medium) this).x / 30
					     - ((Medium) this).cx)
				    * sin(((Medium) this).xz))
				   + ((float) (((Medium) this).mtz[i_185_][0]
					       - ((Medium) this).z / 30
					       - ((Medium) this).cz)
				      * cos(((Medium) this).xz))));
	    int i_188_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).mty[i_185_][0]
					     - ((Medium) this).y / 30
					     - ((Medium) this).cy)
				    * sin(((Medium) this).zy))
				   + ((float) (i_187_ - ((Medium) this).cz)
				      * cos(((Medium) this).zy))));
	    int i_189_
		= (((Medium) this).cx
		   + (int) (((float) ((((Medium) this).mtx[i_185_]
				       [((Medium) this).nmv[i_185_] - 1])
				      - ((Medium) this).x / 30
				      - ((Medium) this).cx)
			     * cos(((Medium) this).xz))
			    - ((float) ((((Medium) this).mtz[i_185_]
					 [((Medium) this).nmv[i_185_] - 1])
					- ((Medium) this).z / 30
					- ((Medium) this).cz)
			       * sin(((Medium) this).xz))));
	    int i_190_
		= (((Medium) this).cz
		   + (int) (((float) ((((Medium) this).mtx[i_185_]
				       [((Medium) this).nmv[i_185_] - 1])
				      - ((Medium) this).x / 30
				      - ((Medium) this).cx)
			     * sin(((Medium) this).xz))
			    + ((float) ((((Medium) this).mtz[i_185_]
					 [((Medium) this).nmv[i_185_] - 1])
					- ((Medium) this).z / 30
					- ((Medium) this).cz)
			       * cos(((Medium) this).xz))));
	    int i_191_
		= (((Medium) this).cz
		   + (int) (((float) ((((Medium) this).mty[i_185_]
				       [((Medium) this).nmv[i_185_] - 1])
				      - ((Medium) this).y / 30
				      - ((Medium) this).cy)
			     * sin(((Medium) this).zy))
			    + ((float) (i_190_ - ((Medium) this).cz)
			       * cos(((Medium) this).zy))));
	    if (xs(i_189_, i_191_) > 0
		&& xs(i_186_, i_188_) < ((Medium) this).w) {
		int[] is = new int[((Medium) this).nmv[i_185_] * 2];
		int[] is_192_ = new int[((Medium) this).nmv[i_185_] * 2];
		int[] is_193_ = new int[((Medium) this).nmv[i_185_] * 2];
		for (int i_194_ = 0; i_194_ < ((Medium) this).nmv[i_185_] * 2;
		     i_194_++) {
		    is[i_194_] = (((Medium) this).mtx[i_185_][i_194_]
				  - ((Medium) this).x / 30);
		    is_192_[i_194_] = (((Medium) this).mty[i_185_][i_194_]
				       - ((Medium) this).y / 30);
		    is_193_[i_194_] = (((Medium) this).mtz[i_185_][i_194_]
				       - ((Medium) this).z / 30);
		}
		int i_195_
		    = (int) (Math.sqrt
			     ((double) ((is[((Medium) this).nmv[i_185_] / 4]
					 * is[((Medium) this).nmv[i_185_] / 4])
					+ ((is_193_
					    [((Medium) this).nmv[i_185_] / 4])
					   * is_193_[(((Medium) this).nmv
						      [i_185_]) / 4]))));
		rot(is, is_193_, ((Medium) this).cx, ((Medium) this).cz,
		    ((Medium) this).xz, ((Medium) this).nmv[i_185_] * 2);
		rot(is_192_, is_193_, ((Medium) this).cy, ((Medium) this).cz,
		    ((Medium) this).zy, ((Medium) this).nmv[i_185_] * 2);
		int[] is_196_ = new int[4];
		int[] is_197_ = new int[4];
		boolean bool = false;
		boolean bool_198_ = false;
		boolean bool_199_ = false;
		boolean bool_200_ = false;
		boolean bool_201_ = true;
		for (int i_202_ = 0; i_202_ < ((Medium) this).nmv[i_185_] - 1;
		     i_202_++) {
		    int i_203_ = 0;
		    int i_204_ = 0;
		    int i_205_ = 0;
		    int i_206_ = 0;
		    bool_201_ = true;
		    for (int i_207_ = 0; i_207_ < 4; i_207_++) {
			int i_208_ = i_207_ + i_202_;
			if (i_207_ == 2)
			    i_208_ = i_202_ + ((Medium) this).nmv[i_185_] + 1;
			if (i_207_ == 3)
			    i_208_ = i_202_ + ((Medium) this).nmv[i_185_];
			is_196_[i_207_] = xs(is[i_208_], is_193_[i_208_]);
			is_197_[i_207_] = ys(is_192_[i_208_], is_193_[i_208_]);
			if (is_197_[i_207_] < 0 || is_193_[i_208_] < 10)
			    i_203_++;
			if (is_197_[i_207_] > ((Medium) this).h
			    || is_193_[i_208_] < 10)
			    i_204_++;
			if (is_196_[i_207_] < 0 || is_193_[i_208_] < 10)
			    i_205_++;
			if (is_196_[i_207_] > ((Medium) this).w
			    || is_193_[i_208_] < 10)
			    i_206_++;
		    }
		    if (i_205_ == 4 || i_203_ == 4 || i_204_ == 4
			|| i_206_ == 4)
			bool_201_ = false;
		    if (bool_201_) {
			float f
			    = ((float) i_195_ / 2500.0F
			       + ((8000.0F - (float) ((Medium) this).fade[0])
				  / 1000.0F)
			       - 2.0F
			       - ((float) Math.abs(((Medium) this).y)
				  - 250.0F) / 5000.0F);
			if (f > 0.0F && f < 10.0F) {
			    if ((double) f < 3.5)
				f = 3.5F;
			    int i_209_
				= (int) (((float) ((((Medium) this).mtc[i_185_]
						    [i_202_][0])
						   + ((Medium) this).cgrnd[0])
					  + (float) ((Medium) this).csky[0] * f
					  + ((float) ((Medium) this).cfade[0]
					     * f))
					 / (2.0F + f * 2.0F));
			    int i_210_
				= (int) (((float) ((((Medium) this).mtc[i_185_]
						    [i_202_][1])
						   + ((Medium) this).cgrnd[1])
					  + (float) ((Medium) this).csky[1] * f
					  + ((float) ((Medium) this).cfade[1]
					     * f))
					 / (2.0F + f * 2.0F));
			    int i_211_
				= (int) (((float) ((((Medium) this).mtc[i_185_]
						    [i_202_][2])
						   + ((Medium) this).cgrnd[2])
					  + (float) ((Medium) this).csky[2] * f
					  + ((float) ((Medium) this).cfade[2]
					     * f))
					 / (2.0F + f * 2.0F));
			    graphics2d.setColor(new Color(i_209_, i_210_,
							  i_211_));
			    graphics2d.fillPolygon(is_196_, is_197_, 4);
			}
		    }
		}
	    }
	}
    }
    
    public void newstars() {
	((Medium) this).stx = null;
	((Medium) this).stz = null;
	((Medium) this).stc = null;
	((Medium) this).bst = null;
	((Medium) this).twn = null;
	((Medium) this).nst = 0;
	if (((Medium) this).lightson) {
	    Random random = new Random((long) (Math.random() * 100000.0));
	    ((Medium) this).nst = 40;
	    ((Medium) this).stx = new int[((Medium) this).nst];
	    ((Medium) this).stz = new int[((Medium) this).nst];
	    ((Medium) this).stc = new int[((Medium) this).nst][2][3];
	    ((Medium) this).bst = new boolean[((Medium) this).nst];
	    ((Medium) this).twn = new int[((Medium) this).nst];
	    for (int i = 0; i < ((Medium) this).nst; i++) {
		((Medium) this).stx[i]
		    = (int) (2000.0 * random.nextDouble() - 1000.0);
		((Medium) this).stz[i]
		    = (int) (2000.0 * random.nextDouble() - 1000.0);
		int i_212_ = (int) (3.0 * random.nextDouble());
		if (i_212_ >= 3)
		    i_212_ = 0;
		if (i_212_ <= -1)
		    i_212_ = 2;
		int i_213_ = i_212_ + 1;
		if (random.nextDouble() > random.nextDouble())
		    i_213_ = i_212_ - 1;
		if (i_213_ == 3)
		    i_213_ = 0;
		if (i_213_ == -1)
		    i_213_ = 2;
		for (int i_214_ = 0; i_214_ < 3; i_214_++) {
		    ((Medium) this).stc[i][0][i_214_] = 200;
		    if (i_212_ == i_214_)
			((Medium) this).stc[i][0][i_214_]
			    += (int) (55.0 * random.nextDouble());
		    if (i_213_ == i_214_)
			((Medium) this).stc[i][0][i_214_] += 55;
		    ((Medium) this).stc[i][0][i_214_]
			= (((Medium) this).stc[i][0][i_214_] * 2
			   + ((Medium) this).csky[i_214_]) / 3;
		    ((Medium) this).stc[i][1][i_214_]
			= (((Medium) this).stc[i][0][i_214_]
			   + ((Medium) this).csky[i_214_]) / 2;
		}
		((Medium) this).twn[i] = (int) (4.0 * random.nextDouble());
		if (random.nextDouble() > 0.8)
		    ((Medium) this).bst[i] = true;
		else
		    ((Medium) this).bst[i] = false;
	    }
	}
    }
    
    public void drawstars(Graphics2D graphics2d) {
	for (int i = 0; i < ((Medium) this).nst; i++) {
	    int i_215_
		= ((Medium) this).cx + (int) (((float) ((Medium) this).stx[i]
					       * cos(((Medium) this).xz))
					      - ((float) ((Medium) this).stz[i]
						 * sin(((Medium) this).xz)));
	    int i_216_
		= ((Medium) this).cz + (int) (((float) ((Medium) this).stx[i]
					       * sin(((Medium) this).xz))
					      + ((float) ((Medium) this).stz[i]
						 * cos(((Medium) this).xz)));
	    int i_217_
		= (((Medium) this).cy
		   + (int) (-200.0F * cos(((Medium) this).zy)
			    - (float) i_216_ * sin(((Medium) this).zy)));
	    int i_218_
		= (((Medium) this).cz
		   + (int) (-200.0F * sin(((Medium) this).zy)
			    + (float) i_216_ * cos(((Medium) this).zy)));
	    i_215_ = xs(i_215_, i_218_);
	    i_217_ = ys(i_217_, i_218_);
	    if (i_215_ - 1 > ((Medium) this).iw
		&& i_215_ + 3 < ((Medium) this).w
		&& i_217_ - 1 > ((Medium) this).ih
		&& i_217_ + 3 < ((Medium) this).h) {
		if (((Medium) this).twn[i] == 0) {
		    int i_219_ = (int) (3.0 * Math.random());
		    if (i_219_ >= 3)
			i_219_ = 0;
		    if (i_219_ <= -1)
			i_219_ = 2;
		    int i_220_ = i_219_ + 1;
		    if (Math.random() > Math.random())
			i_220_ = i_219_ - 1;
		    if (i_220_ == 3)
			i_220_ = 0;
		    if (i_220_ == -1)
			i_220_ = 2;
		    for (int i_221_ = 0; i_221_ < 3; i_221_++) {
			((Medium) this).stc[i][0][i_221_] = 200;
			if (i_219_ == i_221_)
			    ((Medium) this).stc[i][0][i_221_]
				+= (int) (55.0 * Math.random());
			if (i_220_ == i_221_)
			    ((Medium) this).stc[i][0][i_221_] += 55;
			((Medium) this).stc[i][0][i_221_]
			    = (((Medium) this).stc[i][0][i_221_] * 2
			       + ((Medium) this).csky[i_221_]) / 3;
			((Medium) this).stc[i][1][i_221_]
			    = (((Medium) this).stc[i][0][i_221_]
			       + ((Medium) this).csky[i_221_]) / 2;
		    }
		    ((Medium) this).twn[i] = 3;
		} else
		    ((Medium) this).twn[i]--;
		int i_222_ = 0;
		if (((Medium) this).bst[i])
		    i_222_ = 1;
		graphics2d.setColor(new Color(((Medium) this).stc[i][1][0],
					      ((Medium) this).stc[i][1][1],
					      ((Medium) this).stc[i][1][2]));
		graphics2d.fillRect(i_215_ - 1, i_217_, 3 + i_222_,
				    1 + i_222_);
		graphics2d.fillRect(i_215_, i_217_ - 1, 1 + i_222_,
				    3 + i_222_);
		graphics2d.setColor(new Color(((Medium) this).stc[i][0][0],
					      ((Medium) this).stc[i][0][1],
					      ((Medium) this).stc[i][0][2]));
		graphics2d.fillRect(i_215_, i_217_, 1 + i_222_, 1 + i_222_);
	    }
	}
    }
    
    public void d(Graphics2D graphics2d) {
	((Medium) this).nsp = 0;
	if (((Medium) this).zy > 90)
	    ((Medium) this).zy = 90;
	if (((Medium) this).zy < -90)
	    ((Medium) this).zy = -90;
	if (((Medium) this).xz > 360)
	    ((Medium) this).xz -= 360;
	if (((Medium) this).xz < 0)
	    ((Medium) this).xz += 360;
	if (((Medium) this).y > 0)
	    ((Medium) this).y = 0;
	((Medium) this).ground = 250 - ((Medium) this).y;
	int[] is = new int[4];
	int[] is_223_ = new int[4];
	int i = ((Medium) this).cgrnd[0];
	int i_224_ = ((Medium) this).cgrnd[1];
	int i_225_ = ((Medium) this).cgrnd[2];
	int i_226_ = ((Medium) this).crgrnd[0];
	int i_227_ = ((Medium) this).crgrnd[1];
	int i_228_ = ((Medium) this).crgrnd[2];
	int i_229_ = ((Medium) this).h;
	for (int i_230_ = 0; i_230_ < 16; i_230_++) {
	    int i_231_ = ((Medium) this).fade[i_230_];
	    int i_232_ = ((Medium) this).ground;
	    if (((Medium) this).zy != 0) {
		i_232_ = (((Medium) this).cy
			  + (int) (((float) (((Medium) this).ground
					     - ((Medium) this).cy)
				    * cos(((Medium) this).zy))
				   - ((float) (((Medium) this).fade[i_230_]
					       - ((Medium) this).cz)
				      * sin(((Medium) this).zy))));
		i_231_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).ground
					     - ((Medium) this).cy)
				    * sin(((Medium) this).zy))
				   + ((float) (((Medium) this).fade[i_230_]
					       - ((Medium) this).cz)
				      * cos(((Medium) this).zy))));
	    }
	    is[0] = ((Medium) this).iw;
	    is_223_[0] = ys(i_232_, i_231_);
	    if (is_223_[0] < ((Medium) this).ih)
		is_223_[0] = ((Medium) this).ih;
	    if (is_223_[0] > ((Medium) this).h)
		is_223_[0] = ((Medium) this).h;
	    is[1] = ((Medium) this).iw;
	    is_223_[1] = i_229_;
	    is[2] = ((Medium) this).w;
	    is_223_[2] = i_229_;
	    is[3] = ((Medium) this).w;
	    is_223_[3] = is_223_[0];
	    i_229_ = is_223_[0];
	    if (i_230_ > 0) {
		i_226_ = (i_226_ * 7 + ((Medium) this).cfade[0]) / 8;
		i_227_ = (i_227_ * 7 + ((Medium) this).cfade[1]) / 8;
		i_228_ = (i_228_ * 7 + ((Medium) this).cfade[2]) / 8;
		if (i_230_ < 3) {
		    i = (i * 7 + ((Medium) this).cfade[0]) / 8;
		    i_224_ = (i_224_ * 7 + ((Medium) this).cfade[1]) / 8;
		    i_225_ = (i_225_ * 7 + ((Medium) this).cfade[2]) / 8;
		} else {
		    i = i_226_;
		    i_224_ = i_227_;
		    i_225_ = i_228_;
		}
	    }
	    if (is_223_[0] < ((Medium) this).h
		&& is_223_[1] > ((Medium) this).ih) {
		graphics2d.setColor(new Color(i, i_224_, i_225_));
		graphics2d.fillPolygon(is, is_223_, 4);
	    }
	}
	if (((Medium) this).lightn != -1 && ((Medium) this).lton) {
	    if (((Medium) this).lightn < 16) {
		if (((Medium) this).lilo > ((Medium) this).lightn + 217)
		    ((Medium) this).lilo -= 3;
		else
		    ((Medium) this).lightn = (int) (16.0F + 16.0F * random());
	    } else if (((Medium) this).lilo < ((Medium) this).lightn + 217)
		((Medium) this).lilo += 7;
	    else
		((Medium) this).lightn = (int) (16.0F * random());
	    ((Medium) this).csky[0]
		= (int) ((float) ((Medium) this).lilo
			 + ((float) ((Medium) this).lilo
			    * ((float) ((Medium) this).snap[0] / 100.0F)));
	    if (((Medium) this).csky[0] > 255)
		((Medium) this).csky[0] = 255;
	    if (((Medium) this).csky[0] < 0)
		((Medium) this).csky[0] = 0;
	    ((Medium) this).csky[1]
		= (int) ((float) ((Medium) this).lilo
			 + ((float) ((Medium) this).lilo
			    * ((float) ((Medium) this).snap[1] / 100.0F)));
	    if (((Medium) this).csky[1] > 255)
		((Medium) this).csky[1] = 255;
	    if (((Medium) this).csky[1] < 0)
		((Medium) this).csky[1] = 0;
	    ((Medium) this).csky[2]
		= (int) ((float) ((Medium) this).lilo
			 + ((float) ((Medium) this).lilo
			    * ((float) ((Medium) this).snap[2] / 100.0F)));
	    if (((Medium) this).csky[2] > 255)
		((Medium) this).csky[2] = 255;
	    if (((Medium) this).csky[2] < 0)
		((Medium) this).csky[2] = 0;
	}
	i = ((Medium) this).csky[0];
	i_224_ = ((Medium) this).csky[1];
	i_225_ = ((Medium) this).csky[2];
	int i_233_ = i;
	int i_234_ = i_224_;
	int i_235_ = i_225_;
	int i_236_ = (((Medium) this).cy
		      + (int) (((float) (((Medium) this).skyline - 700
					 - ((Medium) this).cy)
				* cos(((Medium) this).zy))
			       - ((float) (7000 - ((Medium) this).cz)
				  * sin(((Medium) this).zy))));
	int i_237_ = (((Medium) this).cz
		      + (int) (((float) (((Medium) this).skyline - 700
					 - ((Medium) this).cy)
				* sin(((Medium) this).zy))
			       + ((float) (7000 - ((Medium) this).cz)
				  * cos(((Medium) this).zy))));
	i_236_ = ys(i_236_, i_237_);
	int i_238_ = ((Medium) this).ih;
	for (int i_239_ = 0; i_239_ < 16; i_239_++) {
	    int i_240_ = ((Medium) this).fade[i_239_];
	    int i_241_ = ((Medium) this).skyline;
	    if (((Medium) this).zy != 0) {
		i_241_ = (((Medium) this).cy
			  + (int) (((float) (((Medium) this).skyline
					     - ((Medium) this).cy)
				    * cos(((Medium) this).zy))
				   - ((float) (((Medium) this).fade[i_239_]
					       - ((Medium) this).cz)
				      * sin(((Medium) this).zy))));
		i_240_ = (((Medium) this).cz
			  + (int) (((float) (((Medium) this).skyline
					     - ((Medium) this).cy)
				    * sin(((Medium) this).zy))
				   + ((float) (((Medium) this).fade[i_239_]
					       - ((Medium) this).cz)
				      * cos(((Medium) this).zy))));
	    }
	    is[0] = ((Medium) this).iw;
	    is_223_[0] = ys(i_241_, i_240_);
	    if (is_223_[0] > ((Medium) this).h)
		is_223_[0] = ((Medium) this).h;
	    if (is_223_[0] < ((Medium) this).ih)
		is_223_[0] = ((Medium) this).ih;
	    is[1] = ((Medium) this).iw;
	    is_223_[1] = i_238_;
	    is[2] = ((Medium) this).w;
	    is_223_[2] = i_238_;
	    is[3] = ((Medium) this).w;
	    is_223_[3] = is_223_[0];
	    i_238_ = is_223_[0];
	    if (i_239_ > 0) {
		i = (i * 7 + ((Medium) this).cfade[0]) / 8;
		i_224_ = (i_224_ * 7 + ((Medium) this).cfade[1]) / 8;
		i_225_ = (i_225_ * 7 + ((Medium) this).cfade[2]) / 8;
	    }
	    if (is_223_[1] < i_236_) {
		i_233_ = i;
		i_234_ = i_224_;
		i_235_ = i_225_;
	    }
	    if (is_223_[0] > ((Medium) this).ih
		&& is_223_[1] < ((Medium) this).h) {
		graphics2d.setColor(new Color(i, i_224_, i_225_));
		graphics2d.fillPolygon(is, is_223_, 4);
	    }
	}
	is[0] = ((Medium) this).iw;
	is_223_[0] = i_238_;
	is[1] = ((Medium) this).iw;
	is_223_[1] = i_229_;
	is[2] = ((Medium) this).w;
	is_223_[2] = i_229_;
	is[3] = ((Medium) this).w;
	is_223_[3] = i_238_;
	if (is_223_[0] < ((Medium) this).h
	    && is_223_[1] > ((Medium) this).ih) {
	    float f = (((float) Math.abs(((Medium) this).y) - 250.0F)
		       / (float) (((Medium) this).fade[0] * 2));
	    if (f < 0.0F)
		f = 0.0F;
	    if (f > 1.0F)
		f = 1.0F;
	    i = (int) (((float) i * (1.0F - f) + (float) i_226_ * (1.0F + f))
		       / 2.0F);
	    i_224_ = (int) (((float) i_224_ * (1.0F - f)
			     + (float) i_227_ * (1.0F + f))
			    / 2.0F);
	    i_225_ = (int) (((float) i_225_ * (1.0F - f)
			     + (float) i_228_ * (1.0F + f))
			    / 2.0F);
	    graphics2d.setColor(new Color(i, i_224_, i_225_));
	    graphics2d.fillPolygon(is, is_223_, 4);
	}
	if (((Medium) this).resdown != 2) {
	    for (int i_242_ = 1; i_242_ < 20; i_242_++) {
		int i_243_ = 7000;
		int i_244_ = ((Medium) this).skyline - 700 - i_242_ * 70;
		if (((Medium) this).zy != 0 && i_242_ != 19) {
		    i_244_ = (((Medium) this).cy
			      + (int) (((float) (((Medium) this).skyline - 700
						 - i_242_ * 70
						 - ((Medium) this).cy)
					* cos(((Medium) this).zy))
				       - ((float) (7000 - ((Medium) this).cz)
					  * sin(((Medium) this).zy))));
		    i_243_ = (((Medium) this).cz
			      + (int) (((float) (((Medium) this).skyline - 700
						 - i_242_ * 70
						 - ((Medium) this).cy)
					* sin(((Medium) this).zy))
				       + ((float) (7000 - ((Medium) this).cz)
					  * cos(((Medium) this).zy))));
		}
		is[0] = ((Medium) this).iw;
		if (i_242_ != 19) {
		    is_223_[0] = ys(i_244_, i_243_);
		    if (is_223_[0] > ((Medium) this).h)
			is_223_[0] = ((Medium) this).h;
		    if (is_223_[0] < ((Medium) this).ih)
			is_223_[0] = ((Medium) this).ih;
		} else
		    is_223_[0] = ((Medium) this).ih;
		is[1] = ((Medium) this).iw;
		is_223_[1] = i_236_;
		is[2] = ((Medium) this).w;
		is_223_[2] = i_236_;
		is[3] = ((Medium) this).w;
		is_223_[3] = is_223_[0];
		i_236_ = is_223_[0];
		i_233_ *= 0.991;
		i_234_ *= 0.991;
		i_235_ *= 0.998;
		if (is_223_[1] > ((Medium) this).ih
		    && is_223_[0] < ((Medium) this).h) {
		    graphics2d.setColor(new Color(i_233_, i_234_, i_235_));
		    graphics2d.fillPolygon(is, is_223_, 4);
		}
	    }
	    if (((Medium) this).lightson)
		drawstars(graphics2d);
	    drawmountains(graphics2d);
	    drawclouds(graphics2d);
	}
	groundpolys(graphics2d);
	if (((Medium) this).noelec != 0)
	    ((Medium) this).noelec--;
	if (((Medium) this).cpflik)
	    ((Medium) this).cpflik = false;
	else {
	    ((Medium) this).cpflik = true;
	    ((Medium) this).elecr = random() * 15.0F - 6.0F;
	}
    }
    
    public void addsp(int i, int i_245_, int i_246_) {
	if (((Medium) this).nsp != 7) {
	    ((Medium) this).spx[((Medium) this).nsp] = i;
	    ((Medium) this).spz[((Medium) this).nsp] = i_245_;
	    ((Medium) this).sprad[((Medium) this).nsp] = i_246_;
	    ((Medium) this).nsp++;
	}
    }
    
    public void setsnap(int i, int i_247_, int i_248_) {
	((Medium) this).snap[0] = i;
	((Medium) this).snap[1] = i_247_;
	((Medium) this).snap[2] = i_248_;
    }
    
    public void setsky(int i, int i_249_, int i_250_) {
	((Medium) this).osky[0] = i;
	((Medium) this).osky[1] = i_249_;
	((Medium) this).osky[2] = i_250_;
	for (int i_251_ = 0; i_251_ < 3; i_251_++) {
	    ((Medium) this).clds[i_251_]
		= ((((Medium) this).osky[i_251_] * ((Medium) this).cldd[3]
		    + ((Medium) this).cldd[i_251_])
		   / (((Medium) this).cldd[3] + 1));
	    ((Medium) this).clds[i_251_]
		= (int) ((float) ((Medium) this).clds[i_251_]
			 + ((float) ((Medium) this).clds[i_251_]
			    * ((float) ((Medium) this).snap[i_251_]
			       / 100.0F)));
	    if (((Medium) this).clds[i_251_] > 255)
		((Medium) this).clds[i_251_] = 255;
	    if (((Medium) this).clds[i_251_] < 0)
		((Medium) this).clds[i_251_] = 0;
	}
	((Medium) this).csky[0]
	    = (int) ((float) i
		     + (float) i * ((float) ((Medium) this).snap[0] / 100.0F));
	if (((Medium) this).csky[0] > 255)
	    ((Medium) this).csky[0] = 255;
	if (((Medium) this).csky[0] < 0)
	    ((Medium) this).csky[0] = 0;
	((Medium) this).csky[1]
	    = (int) ((float) i_249_
		     + (float) i_249_ * ((float) ((Medium) this).snap[1]
					 / 100.0F));
	if (((Medium) this).csky[1] > 255)
	    ((Medium) this).csky[1] = 255;
	if (((Medium) this).csky[1] < 0)
	    ((Medium) this).csky[1] = 0;
	((Medium) this).csky[2]
	    = (int) ((float) i_250_
		     + (float) i_250_ * ((float) ((Medium) this).snap[2]
					 / 100.0F));
	if (((Medium) this).csky[2] > 255)
	    ((Medium) this).csky[2] = 255;
	if (((Medium) this).csky[2] < 0)
	    ((Medium) this).csky[2] = 0;
	float[] fs = new float[3];
	Color.RGBtoHSB(((Medium) this).csky[0], ((Medium) this).csky[1],
		       ((Medium) this).csky[2], fs);
	if ((double) fs[2] < 0.6)
	    ((Medium) this).darksky = true;
	else
	    ((Medium) this).darksky = false;
    }
    
    public void setcloads(int i, int i_252_, int i_253_, int i_254_,
			  int i_255_) {
	if (i_254_ < 0)
	    i_254_ = 0;
	if (i_254_ > 10)
	    i_254_ = 10;
	if (i_255_ < -1500)
	    i_255_ = -1500;
	if (i_255_ > -500)
	    i_255_ = -500;
	((Medium) this).cldd[0] = i;
	((Medium) this).cldd[1] = i_252_;
	((Medium) this).cldd[2] = i_253_;
	((Medium) this).cldd[3] = i_254_;
	((Medium) this).cldd[4] = i_255_;
	for (int i_256_ = 0; i_256_ < 3; i_256_++) {
	    ((Medium) this).clds[i_256_]
		= ((((Medium) this).osky[i_256_] * ((Medium) this).cldd[3]
		    + ((Medium) this).cldd[i_256_])
		   / (((Medium) this).cldd[3] + 1));
	    ((Medium) this).clds[i_256_]
		= (int) ((float) ((Medium) this).clds[i_256_]
			 + ((float) ((Medium) this).clds[i_256_]
			    * ((float) ((Medium) this).snap[i_256_]
			       / 100.0F)));
	    if (((Medium) this).clds[i_256_] > 255)
		((Medium) this).clds[i_256_] = 255;
	    if (((Medium) this).clds[i_256_] < 0)
		((Medium) this).clds[i_256_] = 0;
	}
    }
    
    public void setgrnd(int i, int i_257_, int i_258_) {
	((Medium) this).ogrnd[0] = i;
	((Medium) this).ogrnd[1] = i_257_;
	((Medium) this).ogrnd[2] = i_258_;
	for (int i_259_ = 0; i_259_ < 3; i_259_++) {
	    ((Medium) this).cpol[i_259_]
		= ((((Medium) this).ogrnd[i_259_] * ((Medium) this).texture[3]
		    + ((Medium) this).texture[i_259_])
		   / (1 + ((Medium) this).texture[3]));
	    ((Medium) this).cpol[i_259_]
		= (int) ((float) ((Medium) this).cpol[i_259_]
			 + ((float) ((Medium) this).cpol[i_259_]
			    * ((float) ((Medium) this).snap[i_259_]
			       / 100.0F)));
	    if (((Medium) this).cpol[i_259_] > 255)
		((Medium) this).cpol[i_259_] = 255;
	    if (((Medium) this).cpol[i_259_] < 0)
		((Medium) this).cpol[i_259_] = 0;
	}
	((Medium) this).cgrnd[0]
	    = (int) ((float) i
		     + (float) i * ((float) ((Medium) this).snap[0] / 100.0F));
	if (((Medium) this).cgrnd[0] > 255)
	    ((Medium) this).cgrnd[0] = 255;
	if (((Medium) this).cgrnd[0] < 0)
	    ((Medium) this).cgrnd[0] = 0;
	((Medium) this).cgrnd[1]
	    = (int) ((float) i_257_
		     + (float) i_257_ * ((float) ((Medium) this).snap[1]
					 / 100.0F));
	if (((Medium) this).cgrnd[1] > 255)
	    ((Medium) this).cgrnd[1] = 255;
	if (((Medium) this).cgrnd[1] < 0)
	    ((Medium) this).cgrnd[1] = 0;
	((Medium) this).cgrnd[2]
	    = (int) ((float) i_258_
		     + (float) i_258_ * ((float) ((Medium) this).snap[2]
					 / 100.0F));
	if (((Medium) this).cgrnd[2] > 255)
	    ((Medium) this).cgrnd[2] = 255;
	if (((Medium) this).cgrnd[2] < 0)
	    ((Medium) this).cgrnd[2] = 0;
	for (int i_260_ = 0; i_260_ < 3; i_260_++)
	    ((Medium) this).crgrnd[i_260_]
		= (int) (((double) ((Medium) this).cpol[i_260_] * 0.99
			  + (double) ((Medium) this).cgrnd[i_260_])
			 / 2.0);
    }
    
    public void setexture(int i, int i_261_, int i_262_, int i_263_) {
	if (i_263_ < 20)
	    i_263_ = 20;
	if (i_263_ > 60)
	    i_263_ = 60;
	((Medium) this).texture[0] = i;
	((Medium) this).texture[1] = i_261_;
	((Medium) this).texture[2] = i_262_;
	((Medium) this).texture[3] = i_263_;
	i = (((Medium) this).ogrnd[0] * i_263_ + i) / (1 + i_263_);
	i_261_ = (((Medium) this).ogrnd[1] * i_263_ + i_261_) / (1 + i_263_);
	i_262_ = (((Medium) this).ogrnd[2] * i_263_ + i_262_) / (1 + i_263_);
	((Medium) this).cpol[0]
	    = (int) ((float) i
		     + (float) i * ((float) ((Medium) this).snap[0] / 100.0F));
	if (((Medium) this).cpol[0] > 255)
	    ((Medium) this).cpol[0] = 255;
	if (((Medium) this).cpol[0] < 0)
	    ((Medium) this).cpol[0] = 0;
	((Medium) this).cpol[1]
	    = (int) ((float) i_261_
		     + (float) i_261_ * ((float) ((Medium) this).snap[1]
					 / 100.0F));
	if (((Medium) this).cpol[1] > 255)
	    ((Medium) this).cpol[1] = 255;
	if (((Medium) this).cpol[1] < 0)
	    ((Medium) this).cpol[1] = 0;
	((Medium) this).cpol[2]
	    = (int) ((float) i_262_
		     + (float) i_262_ * ((float) ((Medium) this).snap[2]
					 / 100.0F));
	if (((Medium) this).cpol[2] > 255)
	    ((Medium) this).cpol[2] = 255;
	if (((Medium) this).cpol[2] < 0)
	    ((Medium) this).cpol[2] = 0;
	for (int i_264_ = 0; i_264_ < 3; i_264_++)
	    ((Medium) this).crgrnd[i_264_]
		= (int) (((double) ((Medium) this).cpol[i_264_] * 0.99
			  + (double) ((Medium) this).cgrnd[i_264_])
			 / 2.0);
    }
    
    public void setpolys(int i, int i_265_, int i_266_) {
	((Medium) this).cpol[0]
	    = (int) ((float) i
		     + (float) i * ((float) ((Medium) this).snap[0] / 100.0F));
	if (((Medium) this).cpol[0] > 255)
	    ((Medium) this).cpol[0] = 255;
	if (((Medium) this).cpol[0] < 0)
	    ((Medium) this).cpol[0] = 0;
	((Medium) this).cpol[1]
	    = (int) ((float) i_265_
		     + (float) i_265_ * ((float) ((Medium) this).snap[1]
					 / 100.0F));
	if (((Medium) this).cpol[1] > 255)
	    ((Medium) this).cpol[1] = 255;
	if (((Medium) this).cpol[1] < 0)
	    ((Medium) this).cpol[1] = 0;
	((Medium) this).cpol[2]
	    = (int) ((float) i_266_
		     + (float) i_266_ * ((float) ((Medium) this).snap[2]
					 / 100.0F));
	if (((Medium) this).cpol[2] > 255)
	    ((Medium) this).cpol[2] = 255;
	if (((Medium) this).cpol[2] < 0)
	    ((Medium) this).cpol[2] = 0;
	for (int i_267_ = 0; i_267_ < 3; i_267_++)
	    ((Medium) this).crgrnd[i_267_]
		= (int) (((double) ((Medium) this).cpol[i_267_] * 0.99
			  + (double) ((Medium) this).cgrnd[i_267_])
			 / 2.0);
    }
    
    public void setfade(int i, int i_268_, int i_269_) {
	((Medium) this).cfade[0]
	    = (int) ((float) i
		     + (float) i * ((float) ((Medium) this).snap[0] / 100.0F));
	if (((Medium) this).cfade[0] > 255)
	    ((Medium) this).cfade[0] = 255;
	if (((Medium) this).cfade[0] < 0)
	    ((Medium) this).cfade[0] = 0;
	((Medium) this).cfade[1]
	    = (int) ((float) i_268_
		     + (float) i_268_ * ((float) ((Medium) this).snap[1]
					 / 100.0F));
	if (((Medium) this).cfade[1] > 255)
	    ((Medium) this).cfade[1] = 255;
	if (((Medium) this).cfade[1] < 0)
	    ((Medium) this).cfade[1] = 0;
	((Medium) this).cfade[2]
	    = (int) ((float) i_269_
		     + (float) i_269_ * ((float) ((Medium) this).snap[2]
					 / 100.0F));
	if (((Medium) this).cfade[2] > 255)
	    ((Medium) this).cfade[2] = 255;
	if (((Medium) this).cfade[2] < 0)
	    ((Medium) this).cfade[2] = 0;
    }
    
    public void fadfrom(int i) {
	if (i > 8000)
	    i = 8000;
	for (int i_270_ = 1; i_270_ < 17; i_270_++)
	    ((Medium) this).fade[i_270_ - 1] = i / 2 * (i_270_ + 1);
    }
    
    public void adjstfade(float f, float f_271_, int i,
			  GameSparker gamesparker) {
	if (((Medium) this).resdown != 2) {
	    if (f == 5.0F) {
		if (((Medium) this).resdown == 0
		    && ((Medium) this).rescnt == 0) {
		    ((GameSparker) gamesparker).moto = 0;
		    Madness.anti = 0;
		    ((Medium) this).fade[0] = 3000;
		    fadfrom(((Medium) this).fade[0]);
		    ((Medium) this).resdown = 1;
		    ((Medium) this).rescnt = 10;
		}
		if (((Medium) this).resdown == 1
		    && ((Medium) this).rescnt == 0)
		    ((Medium) this).resdown = 2;
		if ((i == 0 || ((Medium) this).resdown == 0)
		    && f_271_ <= -20.0F)
		    ((Medium) this).rescnt--;
	    } else if (((Medium) this).resdown == 0)
		((Medium) this).rescnt = 5;
	    else
		((Medium) this).rescnt = 10;
	}
    }
    
    public int xs(int i, int i_272_) {
	if (i_272_ < ((Medium) this).cz)
	    i_272_ = ((Medium) this).cz;
	return (((i_272_ - ((Medium) this).focus_point)
		 * (((Medium) this).cx - i) / i_272_)
		+ i);
    }
    
    public int ys(int i, int i_273_) {
	if (i_273_ < 10)
	    i_273_ = 10;
	return (((i_273_ - ((Medium) this).focus_point)
		 * (((Medium) this).cy - i) / i_273_)
		+ i);
    }
    
    public float cos(int i) {
	for (/**/; i >= 360; i -= 360) {
	    /* empty */
	}
	for (/**/; i < 0; i += 360) {
	    /* empty */
	}
	return ((Medium) this).tcos[i];
    }
    
    public float sin(int i) {
	for (/**/; i >= 360; i -= 360) {
	    /* empty */
	}
	for (/**/; i < 0; i += 360) {
	    /* empty */
	}
	return ((Medium) this).tsin[i];
    }
    
    public void rot(int[] is, int[] is_274_, int i, int i_275_, int i_276_,
		    int i_277_) {
	if (i_276_ != 0) {
	    for (int i_278_ = 0; i_278_ < i_277_; i_278_++) {
		int i_279_ = is[i_278_];
		int i_280_ = is_274_[i_278_];
		is[i_278_]
		    = i + (int) ((float) (i_279_ - i) * cos(i_276_)
				 - (float) (i_280_ - i_275_) * sin(i_276_));
		is_274_[i_278_]
		    = (i_275_
		       + (int) ((float) (i_279_ - i) * sin(i_276_)
				+ (float) (i_280_ - i_275_) * cos(i_276_)));
	    }
	}
    }
}
