/* Lobby - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;

public class Lobby implements Runnable {
	Graphics2D rd;
	Login lg;
	Globe gb;
	xtGraphics xt;
	CarDefine cd;
	Medium m;
	FontMetrics ftm;
	ImageObserver ob;
	GameSparker gs;
	Thread connector;
	int conon = 0;
	boolean regnow = false;
	boolean lanlogged = true;
	int fase = 0;
	int stage = 0;
	int laps = 3;
	String stagename = "";
	int nfix = 0;
	boolean notb = false;
	boolean[] pessd = {
		false, false, false, false, false, false, false, false
	};
	int[] bx = {
		0, 0, 0, 0, 0, 0, 0, 0
	};
	int[] by = {
		0, 0, 0, 0, 0, 0, 0, 0
	};
	int[] bw = {
		0, 0, 0, 0, 0, 0, 0, 0
	};
	int btn = 0;
	int pbtn = 0;
	int nflk = 0;
	int ncnt = 0;
	int rerr = 0;
	int pback = 0;
	int cflk = 0;
	int sflk = 0;
	String msg = "";
	String lmsg = "| Searching/Waiting for other LAN Players |";
	int opselect = 0;
	boolean lloaded = false;
	int npo = 0;
	String[] pnames = new String[200];
	int[] pcars = new int[200];
	String[] pcarnames = new String[200];
	String[] pclan = new String[200];
	int[] pgames = new int[200];
	float[][] pcols = new float[200][6];
	int prnpo = 0;
	String[] prnames = {
		"", "", "", "", "", "", "", ""
	};
	int[] ppos = {
		6, 6, 6, 6, 6, 6, 6, 6
	};
	int[] plap = {
		6, 6, 6, 6, 6, 6, 6, 6
	};
	int[] ppow = {
		50, 50, 50, 50, 50, 50, 50, 50
	};
	int[] pdam = {
		50, 50, 50, 50, 50, 50, 50, 50
	};
	int prevloaded = -1;
	String stuntname = "";
	String lapsname = "";
	String wastename = "";
	int ngm = 0;
	int[] gnum = new int[500];
	int[] gstgn = new int[500];
	String[] gstages = new String[500];
	int[] gnlaps = new int[500];
	int[] mnpls = new int[500];
	int[] mnbts = new int[500];
	int[] wait = new int[500];
	int[] gcrs = new int[500];
	int[] gclss = new int[500];
	int[] gfx = new int[500];
	int[] gntb = new int[500];
	String[] gplyrs = new String[500];
	int[] gwarb = new int[500];
	String[] gwarbnum = new String[500];
	int[] gameturn = new int[500];
	String[] gaclan = new String[500];
	String[] gvclan = new String[500];
	int[] gascore = new int[500];
	int[] gvscore = new int[500];
	int[] gwtyp = new int[500];
	String[] gmaker = new String[500];
	int[] npls = new int[500];
	int ongame = -1;
	int join = -1;
	int chalngd = -1;
	int im = 0;
	int longame = -1;
	int onjoin = -1;
	int ontyp = 0;
	int dispcar = -1;
	int forcar = -1;
	int addstage = 0;
	ContO dispco = null;
	boolean fstart = false;
	boolean jflexo = false;
	String chalby = "";
	int ctime = 0;
	boolean invo = false;
	String[] invos = {
		"", "", "", "", "", "", "", ""
	};
	String[] dinvi = {
		"", "", "", "", "", "", "", ""
	};
	String[] cnames = {
		"", "", "", "", "", "", ""
	};
	String[] sentn = {
		"", "", "", "", "", "", ""
	};
	int updatec = -1;
	int loadstage = 0;
	int gstage = 0;
	int gstagelaps = 0;
	int gnpls = 8;
	int gwait = 0;
	int gnbts = 0;
	int gcars;
	int gclass = 0;
	int gfix = 0;
	int gnotp = 0;
	int remstage = 0;
	int msload = 0;
	int sgflag = 0;
	String gstagename = "";
	String gplayers = "";
	boolean inwab = false;
	boolean loadwarb = false;
	int warbsel = 0;
	int cancreate = 0;
	int pgamesel = 0;
	int cntchkn = 0;
	Socket socket;
	BufferedReader din;
	PrintWriter dout;
	int spos = 0;
	int spos2 = 0;
	int spos3 = 28;
	int mscro = 125;
	int lspos = 0;
	int mscro2 = 145;
	int lspos2 = 0;
	int mscro3 = 345;
	int lspos3 = 0;
	int clicked = -1;
	int opengame = 0;
	int britchl = 0;
	boolean zeromsw = false;
	int mousonp = -1;
	int cmonp = -1;
	long ptime = 0L;
	int pcurs = 0;
	boolean grprsd = false;
	int pend = 0;
	int mrot = 0;
	boolean pendb = false;
	int[] cac = {
		-1, -1, -1, -1, -1, -1, -1, -1, -1
	};
	int[] cax = {
		0, 0, 0, 0, 0, 0, 0, 0, 0
	};
	int[] cay = {
		0, 0, 0, 0, 0, 0, 0, 0, 0
	};
	boolean mousedout = false;
	int flks = 0;
	int waitlink = 0;
	boolean pre1 = false;
	boolean pre2 = false;
	int prereq = 0;
	int plsndt = 0;
	int lxm = 0;
	int lym = 0;

	public Lobby(Medium medium, Graphics2D graphics2d, Login login,
	Globe globe, xtGraphics var_xtGraphics, CarDefine cardefine,
	GameSparker gamesparker) {
		((Lobby) this).m = medium;
		((Lobby) this).rd = graphics2d;
		((Lobby) this).xt = var_xtGraphics;
		((Lobby) this).cd = cardefine;
		((Lobby) this).gs = gamesparker;
		((Lobby) this).lg = login;
		((Lobby) this).gb = globe;
		((GameSparker)((Lobby) this).gs).cmsg.setBackground(color2k(240, 240,
		240));
		((GameSparker)((Lobby) this).gs).swait.setBackground(color2k(220, 220,
		220));
		((GameSparker)((Lobby) this).gs).snpls.setBackground(color2k(220, 220,
		220));
		((GameSparker)((Lobby) this).gs).snbts.setBackground(color2k(220, 220,
		220));
		((GameSparker)((Lobby) this).gs).sgame.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).wgame.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).pgame.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).vnpls.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).vtyp.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).warb.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).snfmm.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).snfm1.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).snfm2.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).mstgs.setBackground(color2k(230, 230,
		230));
		((GameSparker)((Lobby) this).gs).slaps.setBackground(color2k(200, 200,
		200));
		((GameSparker)((Lobby) this).gs).sclass.setBackground(color2k(220, 220, 220));
		((GameSparker)((Lobby) this).gs).scars.setBackground(color2k(220, 220,
		220));
		((GameSparker)((Lobby) this).gs).sfix.setBackground(color2k(220, 220,
		220));
		((GameSparker)((Lobby) this).gs).mycar.setBackground(color2k(255, 255,
		255));
		((GameSparker)((Lobby) this).gs).notp.setBackground(color2k(255, 255,
		255));
		((GameSparker)((Lobby) this).gs).rooms.setBackground(color2k(170, 170,
		170));
		((GameSparker)((Lobby) this).gs).swait.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).snpls.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).snbts.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).sgame.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).wgame.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).pgame.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).vnpls.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).vtyp.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).warb.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).snfmm.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).snfm1.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).slaps.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).snfm2.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).mstgs.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).sclass.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).scars.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).sfix.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).mycar.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).notp.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).rooms.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).sgame.removeAll();
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" NFM Multiplayer ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" NFM 2     ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" NFM 1     ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" My Stages ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" My Clan Stages ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" Weekly Top 20 ");
		((GameSparker)((Lobby) this).gs).sgame.add(((Lobby) this).rd,
			" Monthly Top 20 ");
	}

	public void inishlobby() {
		((GameSparker)((Lobby) this).gs).tnick.hide();
		((GameSparker)((Lobby) this).gs).tpass.hide();
		((GameSparker)((Lobby) this).gs).temail.hide();
		hideinputs();
		((GameSparker)((Lobby) this).gs).mycar.setBackground(color2k(255, 255,
		255));
		((GameSparker)((Lobby) this).gs).mycar.setForeground(new Color(0, 0,
		0));
		((GameSparker)((Lobby) this).gs).rooms.removeAll();
		((GameSparker)((Lobby) this).gs).rooms.add(((Lobby) this).rd,
		new StringBuilder().append("").append(((xtGraphics)((Lobby) this).xt).servername).append(" :: ").append(((xtGraphics)((Lobby) this).xt).servport - 7070).append("").toString());
		((GameSparker)((Lobby) this).gs).rooms.select(0);
		((Lobby) this).gs.requestFocus();
		((Lobby) this).cd.loadready();
		for (int i = 0; i < 500; i++) {
			((Lobby) this).gnum[i] = -2;
			((Lobby) this).gstgn[i] = 0;
			((Lobby) this).gstages[i] = "";
			((Lobby) this).gnlaps[i] = 0;
			((Lobby) this).mnpls[i] = 0;
			((Lobby) this).mnbts[i] = 0;
			((Lobby) this).wait[i] = 0;
			((Lobby) this).gmaker[i] = "";
			((Lobby) this).gcrs[i] = 0;
			((Lobby) this).gclss[i] = 0;
			((Lobby) this).gfx[i] = 0;
			((Lobby) this).gntb[i] = 0;
			((Lobby) this).gplyrs[i] = "";
			((Lobby) this).npls[i] = 0;
			((Lobby) this).gwarb[i] = 0;
			((Lobby) this).gwarbnum[i] = "";
			((Lobby) this).gameturn[i] = 0;
			((Lobby) this).gaclan[i] = "";
			((Lobby) this).gvclan[i] = "";
			((Lobby) this).gascore[i] = 0;
			((Lobby) this).gvscore[i] = 0;
			((Lobby) this).gwtyp[i] = 0;
		}
		for (int i = 0; i < 200; i++) {
			((Lobby) this).pnames[i] = "";
			((Lobby) this).pcars[i] = 0;
			((Lobby) this).pcarnames[i] = "";
			((Lobby) this).pgames[i] = -1;
			((Lobby) this).pclan[i] = "";
			for (int i_0_ = 0; i_0_ < 6; i_0_++)
			((Lobby) this).pcols[i][i_0_] = 0.0F;
		}
		((Lobby) this).ongame = -1;
		((Lobby) this).join = -1;
		((Lobby) this).onjoin = -1;
		((Lobby) this).chalngd = -1;
		((Lobby) this).dispcar = -1;
		((Lobby) this).forcar = -1;
		((Lobby) this).chalby = "";
		((Lobby) this).im = 0;
		((Lobby) this).fstart = false;
		((Lobby) this).updatec = -1;
		((Lobby) this).prevloaded = -1;
		((Lobby) this).spos = 0;
		((Lobby) this).spos2 = 0;
		((Lobby) this).spos3 = 0;
		((Lobby) this).ngm = 0;
		((Lobby) this).npo = 0;
		((Lobby) this).fase = 1;
		((Lobby) this).lloaded = false;
		((Login)((Lobby) this).lg).gamec = -1;
		try {
			((Lobby) this).socket = new Socket(((xtGraphics)((Lobby) this).xt).server, ((xtGraphics)((Lobby) this).xt).servport);
			((Lobby) this).din = new BufferedReader(new InputStreamReader(((Lobby) this).socket.getInputStream()));
			((Lobby) this).dout = new PrintWriter(((Lobby) this).socket.getOutputStream(),
			true);
		} catch (Exception exception) {
			/* empty */
		}
		((Lobby) this).conon = 1;
		((Lobby) this).connector = new Thread(this);
		((Lobby) this).connector.start();
	}

	public void run() {
		int i = -1;
		while (((Lobby) this).conon == 1) {
			Date date = new Date();
			long l = date.getTime();
			if (!((Lobby) this).lloaded)
			((Lobby) this).gs.setCursor(new Cursor(3));
			if (!((xtGraphics)((Lobby) this).xt).logged && !((xtGraphics)((Lobby) this).xt).lan && (((xtGraphics)((Lobby) this).xt).nfreeplays - ((xtGraphics)((Lobby) this).xt).ndisco) >= 5) {
				if (((Lobby) this).join >= 0) {
					((Lobby) this).join = -1;
					((Lobby) this).regnow = true;
				}
				if (((Lobby) this).pgames[((Lobby) this).im] != -1) {
					((Lobby) this).join = -2;
					((Lobby) this).regnow = true;
				}
			}
			if ((((Lobby) this).join >= 0 || ((Lobby) this).pgames[((Lobby) this).im] != -1) && !((Lobby) this).regnow) {
				int i_1_ = -1;
				for (int i_2_ = 0; i_2_ < ((Lobby) this).ngm; i_2_++) {
					if (((Lobby) this).join == ((Lobby) this).gnum[i_2_] || (((Lobby) this).pgames[((Lobby) this).im] == ((Lobby) this).gnum[i_2_])) i_1_ = i_2_;
				}
				if (i_1_ != -1) {
					boolean bool = false;
					((Lobby) this).ontyp = 0;
					if (((Lobby) this).gcrs[i_1_] == 1 && ((Lobby) this).pcars[((Lobby) this).im] < 16) {
						bool = true;
						((Lobby) this).ontyp = 10;
						if (((Lobby) this).gclss[i_1_] > 0 && ((Lobby) this).gclss[i_1_] <= 5)
						((Lobby) this).ontyp += ((Lobby) this).gclss[i_1_];
					}
					if (((Lobby) this).gcrs[i_1_] == 2 && ((Lobby) this).pcars[((Lobby) this).im] >= 16) {
						bool = true;
						((Lobby) this).ontyp = 20;
						if (((Lobby) this).gclss[i_1_] > 0 && ((Lobby) this).gclss[i_1_] <= 5)
						((Lobby) this).ontyp += ((Lobby) this).gclss[i_1_];
					}
					if (((Lobby) this).gcrs[i_1_] == 1 && ((Lobby) this).gwarb[i_1_] != 0 && ((xtGraphics)((Lobby) this).xt).sc[0] != 36) {
						bool = true;
						((Lobby) this).ontyp = 30;
						if (((Lobby) this).gclss[i_1_] > 0 && ((Lobby) this).gclss[i_1_] <= 5)
						((Lobby) this).ontyp += ((Lobby) this).gclss[i_1_];
					}
					if (((Lobby) this).gclss[i_1_] > 0 && ((Lobby) this).gclss[i_1_] <= 5 && Math.abs((((CarDefine)((Lobby) this).cd).cclass[((Lobby) this).pcars[((Lobby) this).im]]) - (((Lobby) this).gclss[i_1_] - 1)) > 1) {
						bool = true;
						if (((Lobby) this).gcrs[i_1_] == 1) {
							if (((Lobby) this).gwarb[i_1_] == 0)
							((Lobby) this).ontyp = 10;
							else((Lobby) this).ontyp = 30;
						}
						if (((Lobby) this).gcrs[i_1_] == 2)
						((Lobby) this).ontyp = 20;
						((Lobby) this).ontyp += ((Lobby) this).gclss[i_1_];
					}
					if (((Lobby) this).gclss[i_1_] <= -2 && (((Lobby) this).pcars[((Lobby) this).im] != Math.abs(((Lobby) this).gclss[i_1_] + 2))) {
						bool = true;
						((Lobby) this).ontyp = ((Lobby) this).gclss[i_1_];
					}
					if (((Lobby) this).gstgn[i_1_] == -2 && !((xtGraphics)((Lobby) this).xt).logged) {
						bool = true;
						((Lobby) this).ontyp = 76;
					}
					if (bool) {
						((Lobby) this).onjoin = ((Lobby) this).gnum[i_1_];
						((Lobby) this).jflexo = false;
						if (((Lobby) this).join >= 0)
						((Lobby) this).join = -1;
						if (((Lobby) this).pgames[((Lobby) this).im] != -1)
						((Lobby) this).join = -2;
					}
				}
			}
			if (((xtGraphics)((Lobby) this).xt).onjoin != -1) {
				((Lobby) this).join = ((xtGraphics)((Lobby) this).xt).onjoin;
				((Lobby) this).ongame = ((xtGraphics)((Lobby) this).xt).onjoin;
				((xtGraphics)((Lobby) this).xt).onjoin = -1;
			}
			if (((Lobby) this).updatec < -17)
			((Lobby) this).updatec = -17;
			boolean bool = false;
			if (((Lobby) this).lloaded) {
				i = ((Lobby) this).pgames[((Lobby) this).im];
				if (i != -1) {
					for (int i_3_ = 0; i_3_ < ((Lobby) this).ngm; i_3_++) {
						if (i == ((Lobby) this).gnum[i_3_]) {
							((Lobby) this).laps = ((Lobby) this).gnlaps[i_3_];
							((Lobby) this).stage = ((Lobby) this).gstgn[i_3_];
							((Lobby) this).stagename = ((Lobby) this).gstages[i_3_];
							((Lobby) this).nfix = ((Lobby) this).gfx[i_3_];
							if (((Lobby) this).gntb[i_3_] == 1)
							((Lobby) this).notb = true;
							else((Lobby) this).notb = false;
						}
					}
				}
			}
			String string = new StringBuilder().append("").append(((xtGraphics)((Lobby) this).xt).sc[0]).append("").toString();
			if (((xtGraphics)((Lobby) this).xt).sc[0] >= 16) string = new StringBuilder().append("C").append(((CarDefine)((Lobby) this).cd).names[((xtGraphics)((Lobby) this).xt).sc[0]])
				.append("").toString();
			String string_4_ = new StringBuilder().append("1|").append(((xtGraphics)((Lobby) this).xt).nickname).append(":").append(((xtGraphics)((Lobby) this).xt).nickey).append("|").append(((xtGraphics)((Lobby) this).xt).clan).append("|").append(((xtGraphics)((Lobby) this).xt).clankey).append("|").append(string).append("|").append(((Lobby) this).join).append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[0] * 100.0F))
				.append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[1] * 100.0F))
				.append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[2] * 100.0F))
				.append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[3] * 100.0F))
				.append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[4] * 100.0F))
				.append("|").append((int)(((xtGraphics)((Lobby) this).xt).arnp[5] * 100.0F))
				.append("|").append(((Lobby) this).ongame).append("|").toString();
			if (!((xtGraphics)((Lobby) this).xt).lan) {
				string_4_ = new StringBuilder().append(string_4_).append("").append(((Lobby) this).updatec).append("|").toString();
				if (((Lobby) this).updatec <= -11) {
					for (int i_5_ = 0; i_5_ < -((Lobby) this).updatec - 10;
					i_5_++)
					string_4_ = new StringBuilder().append(string_4_).append("").append(((Lobby) this).cnames[6 - i_5_]).append("|").append(((Lobby) this).sentn[6 - i_5_]).append("|").toString();
					((Lobby) this).updatec = -2;
				}
			} else {
				String string_6_ = "Nonex";
				try {
					string_6_ = InetAddress.getLocalHost().getHostName();
					if (string_6_.indexOf("|") != -1) string_6_ = InetAddress.getLocalHost().getHostAddress();
				} catch (Exception exception) {
					string_6_ = "Nonex";
				}
				int i_7_ = 0;
				if (((xtGraphics)((Lobby) this).xt).logged) i_7_ = 1;
				string_4_ = new StringBuilder().append(string_4_).append("").append(string_6_).append("|").append(i_7_).append("|").toString();
			}
			if (((Lobby) this).fstart) {
				string_4_ = new StringBuilder().append(string_4_).append("3|").toString();
				bool = true;
			}
			if (((Lobby) this).chalngd == -5 && !((Lobby) this).fstart) {
				string_4_ = new StringBuilder().append(string_4_).append("11|")
					.append(((Lobby) this).gstage).append("|").append(((Lobby) this).gstagename).append("|").append(((Lobby) this).gstagelaps).append("|").append(((Lobby) this).gnpls).append("|").append(((Lobby) this).gwait).append("|").append(((Lobby) this).pnames[((Lobby) this).im]).append("|").append(((Lobby) this).gcars).append("|").append(((Lobby) this).gclass).append("|").append(((Lobby) this).gfix).append("|").append(((Lobby) this).gnotp).append("|").append(((Lobby) this).gplayers).append("|").toString();
				if (((xtGraphics)((Lobby) this).xt).lan) string_4_ = new StringBuilder().append(string_4_).append("").append(((Lobby) this).gnbts).append("|").toString();
			}
			if (((Lobby) this).ongame != -1 && ((Lobby) this).chalngd != -5 && !((Lobby) this).fstart) {
				boolean bool_8_ = false;
				for (int i_9_ = 0; i_9_ < 7; i_9_++) {
					if (!((Lobby) this).invos[i_9_].equals("") && !((Lobby) this).dinvi[i_9_].equals(((Lobby) this).invos[i_9_])) {
						if (!bool_8_) {
							string_4_ = new StringBuilder().append(string_4_).append("2|").append(((Lobby) this).ongame).append("|").toString();
							bool_8_ = true;
						}
						string_4_ = new StringBuilder().append(string_4_).append("").append(((Lobby) this).invos[i_9_]).append("|").toString();
						((Lobby) this).dinvi[i_9_] = ((Lobby) this).invos[i_9_];
					}
				}
			}
			String string_10_ = "";
			boolean bool_11_ = false;
			try {
				((Lobby) this).dout.println(string_4_);
				string_10_ = ((Lobby) this).din.readLine();
				if (string_10_ == null) bool_11_ = true;
			} catch (Exception exception) {
				bool_11_ = true;
			}
			if (bool_11_) {
				try {
					((Lobby) this).socket.close();
					((Lobby) this).socket = null;
					((Lobby) this).din.close();
					((Lobby) this).din = null;
					((Lobby) this).dout.close();
					((Lobby) this).dout = null;
				} catch (Exception exception) {
					/* empty */
				}
				try {
					((Lobby) this).socket = new Socket(((xtGraphics)((Lobby) this).xt).server, (((xtGraphics)((Lobby) this).xt)
						.servport));
					((Lobby) this).din = (new BufferedReader(new InputStreamReader(((Lobby) this).socket.getInputStream())));
					((Lobby) this).dout = new PrintWriter(((Lobby) this).socket.getOutputStream(),
					true);
					((Lobby) this).dout.println(string_4_);
					string_10_ = ((Lobby) this).din.readLine();
					if (string_10_ != null) bool_11_ = false;
				} catch (Exception exception) {
					/* empty */
				}
			}
			if (bool_11_) {
				try {
					((Lobby) this).socket.close();
					((Lobby) this).socket = null;
				} catch (Exception exception) {
					/* empty */
				}
				((Lobby) this).conon = 0;
				((Lobby) this).lg.exitfromlobby();
				hideinputs();
				((Lobby) this).connector.stop();
			}
			if (((Lobby) this).regnow && ((Lobby) this).join == -2)
			((Lobby) this).join = -1;
			((Lobby) this).npo = getvalue(string_10_, 0);
			if (((Lobby) this).npo < 0)
			((Lobby) this).npo = 0;
			((Lobby) this).im = getvalue(string_10_, 1);
			if (((Lobby) this).im < 0)
			((Lobby) this).im = 0;
			for (int i_12_ = 0; i_12_ < ((Lobby) this).npo; i_12_++) {
				((Lobby) this).pnames[i_12_] = getSvalue(string_10_, 2 + i_12_ * 10);
				if (((Lobby) this).pnames[i_12_].equals(""))
				((Lobby) this).pnames[i_12_] = "Unknown";
				String string_13_ = getSvalue(string_10_, 3 + i_12_ * 10);
				if (string_13_.startsWith("C")) {
					((Lobby) this).pcarnames[i_12_] = string_13_.substring(1);
					if (!((Lobby) this).pcarnames[i_12_].equals("")) {
						int i_14_ = 0;
						for (int i_15_ = 16; i_15_ < 56; i_15_++) {
							if (((Lobby) this).pcarnames[i_12_].equals(((CarDefine)((Lobby) this).cd).names[i_15_])) {
								i_14_ = i_15_;
								break;
							}
						}
						if (i_14_ == 0) {
							((Lobby) this).pcars[i_12_] = -1;
							boolean bool_16_ = false;
							for (int i_17_ = 0;
							i_17_ < ((CarDefine)((Lobby) this).cd).nl;
							i_17_++) {
								if (((Lobby) this).pcarnames[i_12_].equals(((CarDefine)((Lobby) this).cd).loadnames[i_17_])) bool_16_ = true;
							}
							if (!bool_16_ && ((CarDefine)((Lobby) this).cd).nl < 20 && ((CarDefine)((Lobby) this).cd).nl >= 0) {
								((CarDefine)((Lobby) this).cd).loadnames[((CarDefine)((Lobby) this).cd).nl] = ((Lobby) this).pcarnames[i_12_];
								((CarDefine)((Lobby) this).cd).nl++;
							}
							((Lobby) this).cd.sparkcarloader();
						} else((Lobby) this).pcars[i_12_] = i_14_;
					} else {
						((Lobby) this).pcars[i_12_] = 0;
						((Lobby) this).pcarnames[i_12_] = (((CarDefine)((Lobby) this).cd).names[((Lobby) this).pcars[i_12_]]);
					}
				} else {
					((Lobby) this).pcars[i_12_] = getvalue(string_10_, 3 + i_12_ * 10);
					if (((Lobby) this).pcars[i_12_] == -1)
					((Lobby) this).pcars[i_12_] = 0;
					((Lobby) this).pcarnames[i_12_] = (((CarDefine)((Lobby) this).cd).names[((Lobby) this).pcars[i_12_]]);
				}
				((Lobby) this).pclan[i_12_] = getSvalue(string_10_, 4 + i_12_ * 10);
				((Lobby) this).pgames[i_12_] = getvalue(string_10_, 5 + i_12_ * 10);
				((Lobby) this).pcols[i_12_][0] = (float) getvalue(string_10_, 6 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][0] == -1.0F)
				((Lobby) this).pcols[i_12_][0] = 0.0F;
				((Lobby) this).pcols[i_12_][1] = (float) getvalue(string_10_, 7 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][1] == -1.0F)
				((Lobby) this).pcols[i_12_][1] = 0.0F;
				((Lobby) this).pcols[i_12_][2] = (float) getvalue(string_10_, 8 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][2] == -1.0F)
				((Lobby) this).pcols[i_12_][2] = 0.0F;
				((Lobby) this).pcols[i_12_][3] = (float) getvalue(string_10_, 9 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][3] == -1.0F)
				((Lobby) this).pcols[i_12_][3] = 0.0F;
				((Lobby) this).pcols[i_12_][4] = (float) getvalue(string_10_, 10 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][4] == -1.0F)
				((Lobby) this).pcols[i_12_][4] = 0.0F;
				((Lobby) this).pcols[i_12_][5] = (float) getvalue(string_10_, 11 + i_12_ * 10) / 100.0F;
				if (((Lobby) this).pcols[i_12_][5] == -1.0F)
				((Lobby) this).pcols[i_12_][5] = 0.0F;
			}
			int i_18_ = 12 + (((Lobby) this).npo - 1) * 10;
			((Lobby) this).ngm = getvalue(string_10_, i_18_);
			if (((Lobby) this).ngm < 0)
			((Lobby) this).ngm = 0;
			int i_19_ = 12;
			if (((xtGraphics)((Lobby) this).xt).lan) i_19_ = 13;
			for (int i_20_ = 0; i_20_ < ((Lobby) this).ngm; i_20_++) {
				((Lobby) this).gnum[i_20_] = getvalue(string_10_, i_18_ + 1 + i_20_ * i_19_);
				((Lobby) this).gstgn[i_20_] = getvalue(string_10_, i_18_ + 2 + i_20_ * i_19_);
				((Lobby) this).gstgn[i_20_] = Math.abs(((Lobby) this).gstgn[i_20_]);
				if (((Lobby) this).gstgn[i_20_] > 100)
				((Lobby) this).gstgn[i_20_] = -2;
				((Lobby) this).gstages[i_20_] = getSvalue(string_10_, i_18_ + 3 + i_20_ * i_19_);
				((Lobby) this).gnlaps[i_20_] = getvalue(string_10_, i_18_ + 4 + i_20_ * i_19_);
				((Lobby) this).mnpls[i_20_] = getvalue(string_10_, i_18_ + 5 + i_20_ * i_19_);
				((Lobby) this).wait[i_20_] = getvalue(string_10_, i_18_ + 6 + i_20_ * i_19_);
				((Lobby) this).gmaker[i_20_] = getSvalue(string_10_, i_18_ + 7 + i_20_ * i_19_);
				((Lobby) this).gcrs[i_20_] = getvalue(string_10_, i_18_ + 8 + i_20_ * i_19_);
				((Lobby) this).gclss[i_20_] = getvalue(string_10_, i_18_ + 9 + i_20_ * i_19_);
				((Lobby) this).gfx[i_20_] = getvalue(string_10_, i_18_ + 10 + i_20_ * i_19_);
				((Lobby) this).gntb[i_20_] = getvalue(string_10_, i_18_ + 11 + i_20_ * i_19_);
				((Lobby) this).gplyrs[i_20_] = getSvalue(string_10_, i_18_ + 12 + i_20_ * i_19_);
				if (((Lobby) this).gplyrs[i_20_].startsWith("#warb#")) {
					((Lobby) this).gwarb[i_20_] = getHvalue(((Lobby) this).gplyrs[i_20_], 2);
					((Lobby) this).gwarbnum[i_20_] = getHSvalue(((Lobby) this).gplyrs[i_20_], 3);
					((Lobby) this).gameturn[i_20_] = getHvalue(((Lobby) this).gplyrs[i_20_], 4);
					((Lobby) this).gaclan[i_20_] = getHSvalue(((Lobby) this).gplyrs[i_20_], 5);
					((Lobby) this).gvclan[i_20_] = getHSvalue(((Lobby) this).gplyrs[i_20_], 6);
					((Lobby) this).gascore[i_20_] = getHvalue(((Lobby) this).gplyrs[i_20_], 7);
					((Lobby) this).gvscore[i_20_] = getHvalue(((Lobby) this).gplyrs[i_20_], 8);
					((Lobby) this).gwtyp[i_20_] = getHvalue(((Lobby) this).gplyrs[i_20_], 9);
					if (((Lobby) this).gwtyp[i_20_] < 1 || ((Lobby) this).gwtyp[i_20_] > 5)
					((Lobby) this).gwtyp[i_20_] = 1;
					((Lobby) this).gplyrs[i_20_] = "";
				} else {
					((Lobby) this).gwarb[i_20_] = 0;
					((Lobby) this).gwarbnum[i_20_] = "";
					((Lobby) this).gameturn[i_20_] = 0;
					((Lobby) this).gaclan[i_20_] = "";
					((Lobby) this).gvclan[i_20_] = "";
					((Lobby) this).gascore[i_20_] = 0;
					((Lobby) this).gvscore[i_20_] = 0;
					((Lobby) this).gwtyp[i_20_] = 0;
				}
				if (((xtGraphics)((Lobby) this).xt).lan)
				((Lobby) this).mnbts[i_20_] = getvalue(string_10_, i_18_ + 13 + i_20_ * i_19_);
				if (((xtGraphics)((Lobby) this).xt).playingame > -1 && (((xtGraphics)((Lobby) this).xt).playingame == ((Lobby) this).gnum[i_20_]) && !((xtGraphics)((Lobby) this).xt).lan)
				((Lobby) this).ongame = ((Lobby) this).gnum[i_20_];
				if (i == ((Lobby) this).gnum[i_20_] && ((Lobby) this).wait[i_20_] == 0 && ((Lobby) this).lloaded && i != -1) {
					for (int i_21_ = 0; i_21_ < ((Lobby) this).npo; i_21_++) {
						if ((((Lobby) this).pgames[i_21_] == ((Lobby) this).gnum[i_20_]) && (((Lobby) this).pnames[i_21_].equals(((xtGraphics)((Lobby) this).xt).nickname))) {
							((Lobby) this).im = i_21_;
							break;
						}
					}
					((Lobby) this).conon = 2;
					((Lobby) this).gs.setCursor(new Cursor(3));
				}
			}
			for (int i_22_ = 0; i_22_ < ((Lobby) this).ngm; i_22_++) {
				((Lobby) this).npls[i_22_] = 0;
				for (int i_23_ = 0; i_23_ < ((Lobby) this).npo; i_23_++) {
					if (((Lobby) this).pgames[i_23_] == ((Lobby) this).gnum[i_22_])
					((Lobby) this).npls[i_22_]++;
				}
			}
			if (((Lobby) this).conon != 0 && ((xtGraphics)((Lobby) this).xt).playingame != -1)
			((xtGraphics)((Lobby) this).xt).playingame = -1;
			if (((Lobby) this).ongame != -1) {
				boolean bool_24_ = false;
				for (int i_25_ = 0; i_25_ < ((Lobby) this).ngm; i_25_++) {
					if (((Lobby) this).ongame == ((Lobby) this).gnum[i_25_]) bool_24_ = true;
				}
				if (!bool_24_)
				((Lobby) this).britchl = -1;
			}
			if (((Lobby) this).join > -1) {
				boolean bool_26_ = false;
				for (int i_27_ = 0; i_27_ < ((Lobby) this).ngm; i_27_++) {
					if (((Lobby) this).join == ((Lobby) this).gnum[i_27_]) bool_26_ = true;
				}
				if (!bool_26_)
				((Lobby) this).join = -1;
			}
			for (int i_28_ = 0; i_28_ < ((Lobby) this).npo; i_28_++) {
				if (((Lobby) this).pgames[i_28_] != -1) {
					boolean bool_29_ = false;
					for (int i_30_ = 0; i_30_ < ((Lobby) this).ngm; i_30_++) {
						if (((Lobby) this).pgames[i_28_] == ((Lobby) this).gnum[i_30_]) bool_29_ = true;
					}
					if (!bool_29_)
					((Lobby) this).pgames[i_28_] = -1;
				}
			}
			if (((xtGraphics)((Lobby) this).xt).lan) i_18_ += 14 + (((Lobby) this).ngm - 1) * 13;
			else i_18_ += 13 + (((Lobby) this).ngm - 1) * 12;
			if (!((xtGraphics)((Lobby) this).xt).lan) {
				int i_31_ = getvalue(string_10_, i_18_);
				int i_32_ = getvalue(string_10_, i_18_ + 1);
				i_18_ += 2;
				if (((Lobby) this).updatec != i_31_ && ((Lobby) this).updatec >= -2 && i_32_ == ((Lobby) this).ongame) {
					for (int i_33_ = 0; i_33_ < 7; i_33_++) {
						((Lobby) this).cnames[i_33_] = getSvalue(string_10_, i_18_ + i_33_ * 2);
						((Lobby) this).sentn[i_33_] = getSvalue(string_10_, i_18_ + 1 + i_33_ * 2);
					}
					((Lobby) this).updatec = i_31_;
					if (((Lobby) this).ongame == -1)
					((Lobby) this).spos3 = 28;
					i_18_ += 14;
				}
				if (((Lobby) this).ongame != -1) {
					if (((Lobby) this).prevloaded != -1)
					((Lobby) this).prevloaded = -1;
					boolean bool_34_ = false;
					for (int i_35_ = 0; i_35_ < ((Lobby) this).ngm; i_35_++) {
						if (((Lobby) this).ongame == ((Lobby) this).gnum[i_35_] && ((Lobby) this).wait[i_35_] <= 0) bool_34_ = true;
					}
					if (bool_34_) {
						((Lobby) this).prevloaded = getvalue(string_10_, i_18_);
						i_18_++;
						if (((Lobby) this).prevloaded == 1) {
							((Lobby) this).prnpo = getvalue(string_10_, i_18_);
							i_18_++;
							for (int i_36_ = 0; i_36_ < ((Lobby) this).prnpo;
							i_36_++) {
								((Lobby) this).prnames[i_36_] = getSvalue(string_10_, i_18_);
								i_18_++;
							}
							for (int i_37_ = 0; i_37_ < ((Lobby) this).prnpo;
							i_37_++) {
								((Lobby) this).ppos[i_37_] = getvalue(string_10_, i_18_);
								i_18_++;
							}
							for (int i_38_ = 0; i_38_ < ((Lobby) this).prnpo;
							i_38_++) {
								((Lobby) this).plap[i_38_] = getvalue(string_10_, i_18_);
								i_18_++;
							}
							for (int i_39_ = 0; i_39_ < ((Lobby) this).prnpo;
							i_39_++) {
								((Lobby) this).ppow[i_39_] = (int)((float) getvalue(string_10_,
								i_18_) / 9800.0F * 55.0F);
								i_18_++;
							}
							for (int i_40_ = 0; i_40_ < ((Lobby) this).prnpo;
							i_40_++) {
								int i_41_ = getvalue(string_10_, i_18_);
								if (i_41_ != -17)
								((Lobby) this).pdam[i_40_] = (int)((float) i_41_ / 100.0F * 55.0F);
								else((Lobby) this).pdam[i_40_] = -17;
								i_18_++;
							}
							((Lobby) this).stuntname = getSvalue(string_10_, i_18_);
							i_18_++;
							((Lobby) this).lapsname = getSvalue(string_10_, i_18_);
							i_18_++;
							((Lobby) this).wastename = getSvalue(string_10_, i_18_);
							i_18_++;
						}
					}
				}
			} else {
				int i_42_ = getvalue(string_10_, i_18_);
				if (i_42_ == 1)
				((Lobby) this).lanlogged = true;
				else((Lobby) this).lanlogged = true;
				i_18_++;
			}
			int i_43_ = getvalue(string_10_, i_18_);
			if (i_43_ != -1) {
				int i_44_ = 0;
				for (int i_45_ = 0; i_45_ < ((Lobby) this).ngm; i_45_++) {
					if (i_43_ == ((Lobby) this).gnum[i_45_]) i_44_ = i_45_;
				}
				boolean bool_46_ = false;
				if (((Lobby) this).gwarb[i_44_] != 0) {
					if (((xtGraphics)((Lobby) this).xt).clan.toLowerCase()
						.equals(((Lobby) this).gaclan[i_44_].toLowerCase()) || (((xtGraphics)((Lobby) this).xt).clan.toLowerCase().equals(((Lobby) this).gvclan[i_44_].toLowerCase()))) bool_46_ = true;
				} else bool_46_ = true;
				if (((((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).ongame) || ((Lobby) this).ongame == -1) && i_43_ != ((Lobby) this).ongame && ((Lobby) this).chalngd == -1 && ((Lobby) this).join == -1 && ((Lobby) this).fase == 1 && ((Lobby) this).wait[i_44_] > 0 && bool_46_) {
					((Lobby) this).chalngd = i_43_;
					((Lobby) this).chalby = getSvalue(string_10_, i_18_ + 1);
					((Lobby) this).cflk = 20;
					((Lobby) this).ctime = 20;
					((Lobby) this).ptime = 0L;
					((Lobby) this).longame = ((Lobby) this).ongame;
					if (((Smenu)((GameSparker)((Lobby) this).gs).rooms).open)
					((Smenu)((GameSparker)((Lobby) this).gs).rooms).open = false;
					if (((Lobby) this).ongame != -1)
					((Lobby) this).britchl = -1;
				}
				i_18_++;
			}
			if (!((xtGraphics)((Lobby) this).xt).lan) {
				int i_47_ = 1;
				for (int i_48_ = 1; i_48_ < 6; i_48_++) {
					if (i_48_ != ((xtGraphics)((Lobby) this).xt).servport - 7070) {
						int i_49_ = getvalue(string_10_, i_18_ + i_48_);
						if (i_49_ != -1) {
							((Smenu)((GameSparker)((Lobby) this).gs).rooms)
								.sopts[i_47_] = new StringBuilder().append("Room ").append(i_48_).append("  ::  ").append(i_49_).append("").toString();
							((Smenu)((GameSparker)((Lobby) this).gs).rooms)
								.opts[i_47_] = "";
							((Smenu)((GameSparker)((Lobby) this).gs).rooms)
								.iroom[i_47_] = i_48_;
							i_47_++;
						}
					}
				}
				for (int i_50_ = 0;
				i_50_ < ((Login)((Lobby) this).lg).nservers; i_50_++) {
					if (!(((xtGraphics)((Lobby) this).xt).server.equals(((Login)((Lobby) this).lg).servers[i_50_])) && (((xtGraphics)((Lobby) this).xt).delays[i_50_] < 300)) {
						((Smenu)((GameSparker)((Lobby) this).gs).rooms)
							.sopts[i_47_] = new StringBuilder().append(":: ").append(((Login)((Lobby) this).lg).snames[i_50_])
							.append("").toString();
						((Smenu)((GameSparker)((Lobby) this).gs).rooms)
							.opts[i_47_] = "";
						((Smenu)((GameSparker)((Lobby) this).gs).rooms)
							.iroom[i_47_] = 1000 + i_50_;
						i_47_++;
					}
				}
				((Smenu)((GameSparker)((Lobby) this).gs).rooms).no = i_47_;
			}
			if (((Lobby) this).join > -1) {
				boolean bool_51_ = false;
				for (int i_52_ = 0; i_52_ < ((Lobby) this).ngm; i_52_++) {
					if (((Lobby) this).join == ((Lobby) this).gnum[i_52_] && ((Lobby) this).wait[i_52_] == 0) bool_51_ = true;
				}
				if ((((Lobby) this).pgames[((Lobby) this).im] == ((Lobby) this).join) || bool_51_) {
					((Lobby) this).join = -1;
					((Lobby) this).nflk = 3;
				}
			}
			if (((Lobby) this).join == -2) {
				boolean bool_53_ = false;
				for (int i_54_ = 0; i_54_ < ((Lobby) this).ngm; i_54_++) {
					if ((((Lobby) this).pgames[((Lobby) this).im] == ((Lobby) this).gnum[i_54_]) && ((Lobby) this).wait[i_54_] == 0) bool_53_ = true;
				}
				if (((Lobby) this).pgames[((Lobby) this).im] == -1 || bool_53_) {
					((Lobby) this).join = -1;
					if (!bool_53_)
					((Lobby) this).ongame = -1;
				}
			}
			if (((Lobby) this).chalngd == -5 && ((Lobby) this).pgames[((Lobby) this).im] != -1) {
				((Lobby) this).ongame = ((Lobby) this).pgames[((Lobby) this).im];
				((Lobby) this).chalngd = -1;
				if (!((xtGraphics)((Lobby) this).xt).lan && ((Lobby) this).gplayers.equals(""))
				((Lobby) this).lg.gamealert();
			}
			if (((Lobby) this).fstart && bool)
			((Lobby) this).fstart = false;
			((Lobby) this).rerr = 0;
			if (!((Lobby) this).lloaded) {
				((Lobby) this).gs.setCursor(new Cursor(0));
				((Lobby) this).lloaded = true;
			}
			if (!((Globe)((Lobby) this).gb).domon) {
				((Lobby) this).gb.roomlogos(((Lobby) this).pnames, ((Lobby) this).npo);
				if (((Lobby) this).ongame == -1) {
					if (((Lobby) this).cntchkn == 5)
					((Lobby) this).lg.checkgamealerts();
				} else if (((Login)((Lobby) this).lg).gamec != -1)
				((Login)((Lobby) this).lg).gamec = -1;
				if (((Lobby) this).cntchkn == 5) {
					((Lobby) this).lg.checknotifcations();
					((Lobby) this).cntchkn = 0;
				} else((Lobby) this).cntchkn++;
			} else if (((Login)((Lobby) this).lg).gamec != -1)
			((Login)((Lobby) this).lg).gamec = -1;
			date = new Date();
			long l_55_ = date.getTime();
			int i_56_ = 700 - (int)(l_55_ - l);
			if (i_56_ < 50) i_56_ = 50;
			try {
				if (((Lobby) this).connector != null) {
					/* empty */
				}
				Thread.sleep((long) i_56_);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
		if (((Lobby) this).conon == 2) {
			int i_57_ = 20;
			((xtGraphics)((Lobby) this).xt).playingame = -1;
			while (i_57_ != 0) {
				String string = new StringBuilder().append("2|").append(i).append("|").toString();
				String string_58_ = "";
				boolean bool = false;
				try {
					((Lobby) this).dout.println(string);
					string_58_ = ((Lobby) this).din.readLine();
					if (string_58_ == null) bool = true;
				} catch (Exception exception) {
					bool = true;
				}
				if (bool) {
					try {
						((Lobby) this).socket.close();
						((Lobby) this).socket = null;
						((Lobby) this).din.close();
						((Lobby) this).din = null;
						((Lobby) this).dout.close();
						((Lobby) this).dout = null;
					} catch (Exception exception) {
						/* empty */
					}
					try {
						((Lobby) this).socket = new Socket((((xtGraphics)((Lobby) this).xt)
							.server), (((xtGraphics)((Lobby) this).xt)
							.servport));
						((Lobby) this).din = (new BufferedReader(new InputStreamReader(((Lobby) this).socket.getInputStream())));
						((Lobby) this).dout = new PrintWriter(((Lobby) this).socket.getOutputStream(),
						true);
						((Lobby) this).dout.println(string);
						string_58_ = ((Lobby) this).din.readLine();
						if (string_58_ != null) bool = false;
					} catch (Exception exception) {
						/* empty */
					}
				}
				if (bool) {
					try {
						((Lobby) this).socket.close();
						((Lobby) this).socket = null;
					} catch (Exception exception) {
						/* empty */
					}
					((Lobby) this).conon = 0;
					((Lobby) this).lg.exitfromlobby();
					hideinputs();
					((Lobby) this).connector.stop();
				}
				if (!((xtGraphics)((Lobby) this).xt).lan)
				((xtGraphics)((Lobby) this).xt).gameport = getvalue(string_58_, 0);
				else {
					((xtGraphics)((Lobby) this).xt).gameport = -1;
					((xtGraphics)((Lobby) this).xt).localserver = getSevervalue(string_58_, 0);
					if (!((xtGraphics)((Lobby) this).xt).localserver.equals(""))
					((xtGraphics)((Lobby) this).xt).gameport = 0;
				}
				if (((xtGraphics)((Lobby) this).xt).gameport != -1) {
					int i_59_ = 0;
					((xtGraphics)((Lobby) this).xt).im = -1;
					((xtGraphics)((Lobby) this).xt).nplayers = getvalue(string_58_, 1);
					if (((xtGraphics)((Lobby) this).xt).nplayers < 1)
					((xtGraphics)((Lobby) this).xt).nplayers = 1;
					if (((xtGraphics)((Lobby) this).xt).nplayers > 8)
					((xtGraphics)((Lobby) this).xt).nplayers = 8;
					for (int i_60_ = 0;
					i_60_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_60_++) {
						((xtGraphics)((Lobby) this).xt).plnames[i_60_] = getSvalue(string_58_, 2 + i_60_);
						if (((xtGraphics)((Lobby) this).xt).nickname.equals(((xtGraphics)((Lobby) this).xt).plnames[i_60_]))
						((xtGraphics)((Lobby) this).xt).im = i_60_;
					}
					int i_61_ = 2 + ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_62_ = 0;
					i_62_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_62_++) {
						String string_63_ = getSvalue(string_58_, i_61_ + i_62_);
						if (string_63_.startsWith("C")) {
							string_63_ = string_63_.substring(1);
							if (!string_63_.equals("")) {
								int i_64_ = 0;
								for (int i_65_ = 16; i_65_ < 56; i_65_++) {
									if (string_63_.equals(((CarDefine)
									((Lobby) this).cd)
										.names[i_65_])) {
										i_64_ = i_65_;
										break;
									}
								}
								for ( /**/ ; i_64_ == 0 && i_59_ < 100;
								i_59_++) {
									boolean bool_66_ = false;
									for (int i_67_ = 0;
									(i_67_ < (((CarDefine)((Lobby) this).cd)
										.nl));
									i_67_++) {
										if (string_63_.equals(((CarDefine)
										(((Lobby) this)
											.cd))
											.loadnames[i_67_])) bool_66_ = true;
									}
									if (!bool_66_ && (((CarDefine)((Lobby) this).cd).nl < 20)) {
										((CarDefine)((Lobby) this).cd)
											.loadnames[(((CarDefine)((Lobby) this).cd)
											.nl)] = string_63_;
										((CarDefine)((Lobby) this).cd).nl++;
									}
									((Lobby) this).cd.sparkcarloader();
									try {
										if (((Lobby) this).connector != null) {
											/* empty */
										}
										Thread.sleep(100L);
									} catch (InterruptedException interruptedexception) {
										/* empty */
									}
									for (int i_68_ = 16; i_68_ < 56; i_68_++) {
										if (string_63_.equals(((CarDefine)
										(((Lobby) this)
											.cd))
											.names[i_68_])) i_64_ = i_68_;
									}
								}
								if (i_64_ != 0) {
									((xtGraphics)((Lobby) this).xt).sc[i_62_] = i_64_;
									for (int i_69_ = 0;
									i_69_ < ((Lobby) this).npo; i_69_++) {
										if (((Lobby) this).pcarnames[i_69_].equals(string_63_))
										((Lobby) this).pcars[i_69_] = i_64_;
									}
								} else((xtGraphics)((Lobby) this).xt).im = -1;
							} else((xtGraphics)((Lobby) this).xt).im = -1;
						} else {
							((xtGraphics)((Lobby) this).xt).sc[i_62_] = getvalue(string_58_, i_61_ + i_62_);
							if (((xtGraphics)((Lobby) this).xt).sc[i_62_] == -1)
							((xtGraphics)((Lobby) this).xt).im = -1;
						}
					}
					i_61_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_70_ = 0;
					i_70_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_70_++)
					((xtGraphics)((Lobby) this).xt).xstart[i_70_] = getvalue(string_58_, i_61_ + i_70_);
					i_61_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_71_ = 0;
					i_71_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_71_++)
					((xtGraphics)((Lobby) this).xt).zstart[i_71_] = getvalue(string_58_, i_61_ + i_71_);
					i_61_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_72_ = 0;
					i_72_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_72_++) {
						for (int i_73_ = 0; i_73_ < 6; i_73_++)
						((xtGraphics)((Lobby) this).xt).allrnp[i_72_]
						[i_73_] = ((float) getvalue(string_58_,
						i_61_ + i_72_ * 6 + i_73_) / 100.0F);
					}
					if (((xtGraphics)((Lobby) this).xt).im != -1) {
						((xtGraphics)((Lobby) this).xt).playingame = i;
						int i_74_ = 0;
						for (int i_75_ = 0; i_75_ < ((Lobby) this).ngm;
						i_75_++) {
							if (i == ((Lobby) this).gnum[i_75_]) i_74_ = i_75_;
						}
						if (((Lobby) this).gwarb[i_74_] != 0) {
							((xtGraphics)((Lobby) this).xt).clangame = ((Lobby) this).gwtyp[i_74_];
							((xtGraphics)((Lobby) this).xt).clanchat = true;
							((xtGraphics)((Lobby) this).xt).gaclan = ((Lobby) this).gaclan[i_74_];
							for (int i_76_ = 0;
							(i_76_ < ((xtGraphics)((Lobby) this).xt).nplayers);
							i_76_++) {
								for (int i_77_ = 0; i_77_ < ((Lobby) this).npo;
								i_77_++) {
									if ((((xtGraphics)((Lobby) this).xt)
										.plnames[i_76_].equals(((Lobby) this).pnames[i_77_])) && ((Lobby) this).pgames[i_77_] == i)
									((xtGraphics)((Lobby) this).xt)
										.pclan[i_76_] = ((Lobby) this).pclan[i_77_];
								}
							}
						} else((xtGraphics)((Lobby) this).xt).clangame = 0;
					} else {
						((xtGraphics)((Lobby) this).xt).playingame = -1;
						((xtGraphics)((Lobby) this).xt).im = 0;
					}
					i_57_ = 0;
				} else i_57_--;
				try {
					if (((Lobby) this).connector != null) {
						/* empty */
					}
					Thread.sleep(1000L);
				} catch (InterruptedException interruptedexception) {
					/* empty */
				}
			}
			try {
				((Lobby) this).socket.close();
				((Lobby) this).socket = null;
				((Lobby) this).din.close();
				((Lobby) this).din = null;
				((Lobby) this).dout.close();
				((Lobby) this).dout = null;
			} catch (Exception exception) {
				/* empty */
			}
			if (((xtGraphics)((Lobby) this).xt).playingame != -1) {
				if (!((xtGraphics)((Lobby) this).xt).lan && !((xtGraphics)((Lobby) this).xt).logged) {
					((xtGraphics)((Lobby) this).xt).nfreeplays++;
					try {
						((Lobby) this).socket = new Socket((((Login)((Lobby) this).lg).servers[0]),
						7061);
						((Lobby) this).din = (new BufferedReader(new InputStreamReader(((Lobby) this).socket.getInputStream())));
						((Lobby) this).dout = new PrintWriter(((Lobby) this).socket.getOutputStream(),
						true);
						((Lobby) this).dout.println(new StringBuilder().append("7|").append(((xtGraphics)
						((Lobby) this).xt)
							.nfreeplays)
							.append("|").toString());
						String string = ((Lobby) this).din.readLine();
						((xtGraphics)((Lobby) this).xt).hours = getvalue(string, 0);
						((Lobby) this).socket.close();
						((Lobby) this).socket = null;
						((Lobby) this).din.close();
						((Lobby) this).din = null;
						((Lobby) this).dout.close();
						((Lobby) this).dout = null;
					} catch (Exception exception) {
						/* empty */
					}
				}
				hideinputs();
				((xtGraphics)((Lobby) this).xt).multion = 1;
				((Lobby) this).fase = 76;
				System.gc();
			} else inishlobby();
		}
		if (((Lobby) this).conon == 3) {
			int i_78_ = 20;
			((xtGraphics)((Lobby) this).xt).playingame = -1;
			while (i_78_ != 0) {
				String string = new StringBuilder().append("4|").append(((Lobby) this).ongame).append("|").toString();
				String string_79_ = "";
				boolean bool = false;
				try {
					((Lobby) this).dout.println(string);
					string_79_ = ((Lobby) this).din.readLine();
					if (string_79_ == null) bool = true;
				} catch (Exception exception) {
					bool = true;
				}
				if (bool) {
					try {
						((Lobby) this).socket.close();
						((Lobby) this).socket = null;
						((Lobby) this).din.close();
						((Lobby) this).din = null;
						((Lobby) this).dout.close();
						((Lobby) this).dout = null;
					} catch (Exception exception) {
						/* empty */
					}
					try {
						((Lobby) this).socket = new Socket((((xtGraphics)((Lobby) this).xt)
							.server), (((xtGraphics)((Lobby) this).xt)
							.servport));
						((Lobby) this).din = (new BufferedReader(new InputStreamReader(((Lobby) this).socket.getInputStream())));
						((Lobby) this).dout = new PrintWriter(((Lobby) this).socket.getOutputStream(),
						true);
						((Lobby) this).dout.println(string);
						string_79_ = ((Lobby) this).din.readLine();
						if (string_79_ != null) bool = false;
					} catch (Exception exception) {
						/* empty */
					}
				}
				if (bool) {
					try {
						((Lobby) this).socket.close();
						((Lobby) this).socket = null;
					} catch (Exception exception) {
						/* empty */
					}
					((Lobby) this).conon = 0;
					((Lobby) this).lg.exitfromlobby();
					hideinputs();
					((Lobby) this).connector.stop();
				}
				if (!((xtGraphics)((Lobby) this).xt).lan)
				((xtGraphics)((Lobby) this).xt).gameport = getvalue(string_79_, 0);
				else {
					((xtGraphics)((Lobby) this).xt).gameport = -1;
					((xtGraphics)((Lobby) this).xt).localserver = getSevervalue(string_79_, 0);
					if (!((xtGraphics)((Lobby) this).xt).localserver.equals(""))
					((xtGraphics)((Lobby) this).xt).gameport = 0;
				}
				if (((xtGraphics)((Lobby) this).xt).gameport != -1) {
					int i_80_ = 0;
					((xtGraphics)((Lobby) this).xt).nplayers = getvalue(string_79_, 1);
					if (((xtGraphics)((Lobby) this).xt).nplayers < 1)
					((xtGraphics)((Lobby) this).xt).nplayers = 1;
					if (((xtGraphics)((Lobby) this).xt).nplayers > 8)
					((xtGraphics)((Lobby) this).xt).nplayers = 8;
					((xtGraphics)((Lobby) this).xt).im = (getvalue(string_79_, 2) + ((xtGraphics)((Lobby) this).xt).nplayers);
					for (int i_81_ = 0;
					i_81_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_81_++)
					((xtGraphics)((Lobby) this).xt).plnames[i_81_] = getSvalue(string_79_, 3 + i_81_);
					int i_82_ = 3 + ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_83_ = 0;
					i_83_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_83_++) {
						String string_84_ = getSvalue(string_79_, i_82_ + i_83_);
						if (string_84_.startsWith("C")) {
							string_84_ = string_84_.substring(1);
							if (!string_84_.equals("")) {
								int i_85_ = 0;
								for (int i_86_ = 16; i_86_ < 56; i_86_++) {
									if (string_84_.equals(((CarDefine)
									((Lobby) this).cd)
										.names[i_86_])) {
										i_85_ = i_86_;
										break;
									}
								}
								for ( /**/ ; i_85_ == 0 && i_80_ < 100;
								i_80_++) {
									boolean bool_87_ = false;
									for (int i_88_ = 0;
									(i_88_ < (((CarDefine)((Lobby) this).cd)
										.nl));
									i_88_++) {
										if (string_84_.equals(((CarDefine)
										(((Lobby) this)
											.cd))
											.loadnames[i_88_])) bool_87_ = true;
									}
									if (!bool_87_ && (((CarDefine)((Lobby) this).cd).nl < 20)) {
										((CarDefine)((Lobby) this).cd)
											.loadnames[(((CarDefine)((Lobby) this).cd)
											.nl)] = string_84_;
										((CarDefine)((Lobby) this).cd).nl++;
									}
									((Lobby) this).cd.sparkcarloader();
									try {
										if (((Lobby) this).connector != null) {
											/* empty */
										}
										Thread.sleep(100L);
									} catch (InterruptedException interruptedexception) {
										/* empty */
									}
									for (int i_89_ = 16; i_89_ < 56; i_89_++) {
										if (string_84_.equals(((CarDefine)
										(((Lobby) this)
											.cd))
											.names[i_89_])) i_85_ = i_89_;
									}
								}
								if (i_85_ != 0) {
									((xtGraphics)((Lobby) this).xt).sc[i_83_] = i_85_;
									for (int i_90_ = 0;
									i_90_ < ((Lobby) this).npo; i_90_++) {
										if (((Lobby) this).pcarnames[i_90_].equals(string_84_))
										((Lobby) this).pcars[i_90_] = i_85_;
									}
								} else((xtGraphics)((Lobby) this).xt).im = -1;
							} else((xtGraphics)((Lobby) this).xt).im = -1;
						} else {
							((xtGraphics)((Lobby) this).xt).sc[i_83_] = getvalue(string_79_, i_82_ + i_83_);
							if (((xtGraphics)((Lobby) this).xt).sc[i_83_] == -1)
							((xtGraphics)((Lobby) this).xt).im = -1;
						}
					}
					i_82_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_91_ = 0;
					i_91_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_91_++)
					((xtGraphics)((Lobby) this).xt).xstart[i_91_] = getvalue(string_79_, i_82_ + i_91_);
					i_82_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_92_ = 0;
					i_92_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_92_++)
					((xtGraphics)((Lobby) this).xt).zstart[i_92_] = getvalue(string_79_, i_82_ + i_92_);
					i_82_ += ((xtGraphics)((Lobby) this).xt).nplayers;
					for (int i_93_ = 0;
					i_93_ < ((xtGraphics)((Lobby) this).xt).nplayers;
					i_93_++) {
						for (int i_94_ = 0; i_94_ < 6; i_94_++)
						((xtGraphics)((Lobby) this).xt).allrnp[i_93_]
						[i_94_] = ((float) getvalue(string_79_,
						i_82_ + i_93_ * 6 + i_94_) / 100.0F);
					}
					if ((((xtGraphics)((Lobby) this).xt).im >= ((xtGraphics)((Lobby) this).xt).nplayers) && (((xtGraphics)((Lobby) this).xt).im < ((xtGraphics)((Lobby) this).xt).nplayers + 3)) {
						((xtGraphics)((Lobby) this).xt).playingame = ((Lobby) this).ongame;
						int i_95_ = 0;
						for (int i_96_ = 0; i_96_ < ((Lobby) this).ngm;
						i_96_++) {
							if (((Lobby) this).ongame == ((Lobby) this).gnum[i_96_]) i_95_ = i_96_;
						}
						if (((Lobby) this).gwarb[i_95_] != 0) {
							((xtGraphics)((Lobby) this).xt).clangame = ((Lobby) this).gwtyp[i_95_];
							((xtGraphics)((Lobby) this).xt).gaclan = ((Lobby) this).gaclan[i_95_];
							if ((((xtGraphics)((Lobby) this).xt).clan.toLowerCase().equals(((Lobby) this).gaclan[i_95_].toLowerCase())) || (((xtGraphics)((Lobby) this).xt).clan.toLowerCase().equals(((Lobby) this).gvclan[i_95_].toLowerCase())))
							((xtGraphics)((Lobby) this).xt).clanchat = true;
							for (int i_97_ = 0;
							(i_97_ < ((xtGraphics)((Lobby) this).xt).nplayers);
							i_97_++) {
								for (int i_98_ = 0; i_98_ < ((Lobby) this).npo;
								i_98_++) {
									if ((((xtGraphics)((Lobby) this).xt)
										.plnames[i_97_].equals(((Lobby) this).pnames[i_98_])) && (((Lobby) this).pgames[i_98_] == ((Lobby) this).ongame))
									((xtGraphics)((Lobby) this).xt)
										.pclan[i_97_] = ((Lobby) this).pclan[i_98_];
								}
							}
						} else((xtGraphics)((Lobby) this).xt).clangame = 0;
					} else {
						((xtGraphics)((Lobby) this).xt).playingame = -1;
						((xtGraphics)((Lobby) this).xt).im = 0;
					}
					i_78_ = 0;
				} else i_78_--;
				try {
					if (((Lobby) this).connector != null) {
						/* empty */
					}
					Thread.sleep(1000L);
				} catch (InterruptedException interruptedexception) {
					/* empty */
				}
			}
			try {
				((Lobby) this).socket.close();
				((Lobby) this).socket = null;
				((Lobby) this).din.close();
				((Lobby) this).din = null;
				((Lobby) this).dout.close();
				((Lobby) this).dout = null;
			} catch (Exception exception) {
				/* empty */
			}
			if (((xtGraphics)((Lobby) this).xt).playingame != -1) {
				hideinputs();
				((xtGraphics)((Lobby) this).xt).multion = 3;
				((Lobby) this).fase = 76;
				System.gc();
			} else inishlobby();
		}
	}

	public void stopallnow() {
		((Lobby) this).conon = 0;
		try {
			((Lobby) this).socket.close();
			((Lobby) this).socket = null;
			((Lobby) this).din.close();
			((Lobby) this).din = null;
			((Lobby) this).dout.close();
			((Lobby) this).dout = null;
		} catch (Exception exception) {
			/* empty */
		}
		if (((Lobby) this).connector != null) {
			((Lobby) this).connector.stop();
			((Lobby) this).connector = null;
		}
	}

	public void lobby(int i, int i_99_, boolean bool, int i_100_,
	CheckPoints checkpoints, Control control,
	ContO[] contos) {
		((Lobby) this).pre1 = false;
		((Lobby) this).pre2 = false;
		int i_101_ = 0;
		if (((xtGraphics)((Lobby) this).xt).warning == 0 || ((xtGraphics)((Lobby) this).xt).warning == 210) {
			if (!((Lobby) this).regnow) {
				if (((Lobby) this).onjoin == -1) {
					((Lobby) this).xt.mainbg(3);
					if (((Lobby) this).britchl == -1) {
						((Lobby) this).ongame = -1;
						((Lobby) this).britchl = 0;
					}
					((Lobby) this).btn = 0;
					((Lobby) this).pbtn = 0;
					((Lobby) this).zeromsw = false;
					int i_102_ = ((Lobby) this).npo;
					if (((Lobby) this).invo) {
						i_102_ = 0;
						for (int i_103_ = 0; i_103_ < ((Lobby) this).npo;
						i_103_++) {
							if (((Lobby) this).pgames[i_103_] == -1) i_102_++;
						}
						i_102_ += 2;
					}
					int i_104_ = (i_102_ - 11) * 30;
					if (i_104_ < 0) i_104_ = 0;
					int i_105_ = (int)((float)((Lobby) this).spos / 295.0F * (float) i_104_);
					int i_106_ = 0;
					int i_107_ = -1;
					int i_108_ = -1;
					if (((Lobby) this).conon == 1) {
						if (!((Lobby) this).invo) {
							for (int i_109_ = 0; i_109_ < ((Lobby) this).npo;
							i_109_++) {
								if (((Lobby) this).pgames[i_109_] != -1) {
									int i_110_ = 0;
									for (int i_111_ = 0;
									i_111_ < ((Lobby) this).ngm;
									i_111_++) {
										if (((Lobby) this).pgames[i_109_] == ((Lobby) this).gnum[i_111_]) i_110_ = i_111_;
									}
									if (((Lobby) this).wait[i_110_] > 0) {
										if (82 + 30 * i_106_ - i_105_ > 50 && (82 + 30 * (i_106_ - 1) - i_105_ < 415)) {
											boolean bool_112_ = false;
											if (i > 70 && i < 185 && i_99_ > (52 + 30 * i_106_ - i_105_) && i_99_ < (82 + 30 * i_106_ - i_105_)) {
												if ((((Lobby) this).pgames[((Lobby) this).im]) == -1 && (((Lobby) this).join == -1) && (((Lobby) this).chalngd >= -1)) {
													if (bool || ((((Lobby) this)
														.mousonp) == i_109_)) {
														((Lobby) this).rd.setColor(color2k(255, 255,
														255));
														((Lobby) this).mousonp = i_109_;
														i_108_ = (52 + 30 * i_106_ - i_105_);
														if (bool) {
															if ((((Lobby) this)
																.cmonp) == i_109_)
															((Lobby) this)
																.ongame = (((Lobby)
															this)
																.pgames[i_109_]);
															((Lobby) this)
																.chalngd = -1;
														} else {
															if ((((Lobby) this)
																.cmonp) == -1) {
																((Lobby) this)
																	.ongame = -1;
																((Lobby) this)
																	.cmonp = i_109_;
															}
															if ((((Lobby) this)
																.ongame) == (((Lobby)
															this)
																.pgames[i_109_]))
															((Lobby) this)
																.mousonp = -1;
														}
													} else((Lobby) this).rd.setColor(color2k(220, 220,
													220));
													((Lobby) this).rd.fillRect(70, (53 + 30 * i_106_ - i_105_),
													116, 29);
													i_107_ = i_109_;
												}
												bool_112_ = true;
												if (((Control) control)
													.handb) {
													((GameSparker)
													((Lobby) this).gs)
														.cmsg.setText(new StringBuilder().append(((GameSparker)
													(((Lobby) this)
														.gs))
														.cmsg.getText())
														.append("").append(((Lobby) this)
														.pnames[i_109_])
														.toString());
													((Control) control).handb = false;
												}
											}
											if ((((Lobby) this).pgames[((Lobby) this).im]) == -1 && ((Lobby) this).join == -1 && (((Lobby) this).chalngd >= -1))
											((Lobby) this).rd.setColor(new Color(49, 79, 0));
											else((Lobby) this).rd.setColor(new Color(34, 55, 0));
											boolean bool_113_ = (((Lobby) this).gb.drawl(((Lobby) this).rd, (((Lobby) this).pnames[i_109_]),
											68,
											53 + 30 * i_106_ - i_105_,
											bool_112_));
											if (!bool_112_ || !bool_113_) {
												((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.drawString((((Lobby) this).pnames[i_109_]),
												127 - ((((Lobby) this)
													.ftm.stringWidth(((Lobby) this)
													.pnames[i_109_])) / 2), (66 + 30 * i_106_ - i_105_));
												((Lobby) this).rd.setFont(new Font("Arial", 0, 10));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.drawString((((Lobby) this).pcarnames[i_109_]),
												127 - (((Lobby) this)
													.ftm.stringWidth(((Lobby) this)
													.pcarnames[i_109_])) / 2, (78 + 30 * i_106_ - i_105_));
											}
											((Lobby) this).rd.setColor(color2k(150, 150, 150));
											((Lobby) this).rd.drawLine(70, 82 + 30 * i_106_ - i_105_,
											185,
											82 + 30 * i_106_ - i_105_);
										}
										i_106_++;
									}
								}
							}
						}
						int i_114_ = -1;
						if (((Lobby) this).invo) {
							for (int i_115_ = 0; i_115_ < ((Lobby) this).ngm;
							i_115_++) {
								if (((Lobby) this).gwarb[i_115_] != 0 && ((((Lobby) this).pgames[((Lobby) this).im]) == ((Lobby) this).gnum[i_115_])) i_114_ = i_115_;
							}
							((Lobby) this).rd.setColor(new Color(0, 0, 0));
							((Lobby) this).rd.setFont(new Font("Arial", 1,
							12));
							((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
							if (i_114_ == -1)
							((Lobby) this).rd.drawString("Free Players",
							127 - (((Lobby) this).ftm.stringWidth("Free Players") / 2),
							75 - i_105_);
							else((Lobby) this).rd.drawString("Members of Clans", (127 - (((Lobby) this).ftm.stringWidth("Members of Clans") / 2)),
							75 - i_105_);
							((Lobby) this).rd.setFont(new Font("Arial", 0,
							10));
							((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
							((Lobby) this).rd.drawString("Click a player to invite:",
							127 - (((Lobby) this).ftm.stringWidth("Click a player to invite:")) / 2,
							92 - i_105_);
							((Lobby) this).rd.setColor(color2k(150, 150, 150));
							((Lobby) this).rd.drawLine(70, 112 - i_105_, 185,
							112 - i_105_);
							i_106_ += 2;
						}
						for (int i_116_ = 0; i_116_ < ((Lobby) this).npo;
						i_116_++) {
							boolean bool_117_ = false;
							if (((Lobby) this).invo) {
								if (((Lobby) this).im == i_116_) bool_117_ = true;
								for (int i_118_ = 0; i_118_ < 7; i_118_++) {
									if ((((Lobby) this).invos[i_118_].equals(((Lobby) this).pnames[i_116_])) && !bool_117_) bool_117_ = true;
								}
								if (i_114_ != -1 && !(((Lobby) this).pclan[i_116_].toLowerCase().equals(((Lobby) this).gaclan[i_114_].toLowerCase())) && !(((Lobby) this).pclan[i_116_].toLowerCase().equals(((Lobby) this).gvclan[i_114_].toLowerCase()))) bool_117_ = true;
							}
							if (((Lobby) this).pgames[i_116_] == -1 && !bool_117_) {
								if (82 + 30 * i_106_ - i_105_ > 50 && 82 + 30 * (i_106_ - 1) - i_105_ < 415) {
									boolean bool_119_ = false;
									if (i > 70 && i < 185 && i_99_ > 52 + 30 * i_106_ - i_105_ && i_99_ < 82 + 30 * i_106_ - i_105_) {
										if (((Lobby) this).invo) {
											if (bool) {
												((Lobby) this).rd.setColor(color2k(255, 255, 255));
												((Lobby) this).mousonp = i_116_;
											} else {
												((Lobby) this).rd.setColor(color2k(220, 220, 220));
												if (((Lobby) this).mousonp == i_116_) {
													int i_120_ = 0;
													for (boolean bool_121_ = false;
													(i_120_ < 7 && !bool_121_);
													i_120_++) {
														if (((Lobby) this)
															.invos[i_120_].equals("")) {
															((Lobby) this)
																.invos[i_120_] = (((Lobby)
															this)
																.pnames[i_116_]);
															bool_121_ = true;
														}
													}
													((Lobby) this).mousonp = -1;
													((Lobby) this).invo = false;
												}
											}
											((Lobby) this).rd.fillRect(70, 53 + 30 * i_106_ - i_105_,
											116, 29);
											i_107_ = i_116_;
										} else if ((((Lobby) this).pgames[((Lobby) this).im]) == -1 && ((Lobby) this).join == -1 && (((Lobby) this).chalngd >= -1)) {
											i_101_ = 12;
											if (bool) {
												if (!((Globe)
												((Lobby) this).gb)
													.proname.equals(((Lobby) this).pnames[i_116_])) {
													((Globe)((Lobby) this).gb)
														.proname = (((Lobby) this)
														.pnames[i_116_]);
													((Globe)((Lobby) this).gb)
														.loadedp = false;
												}
												((Globe)((Lobby) this).gb).tab = 1;
												((Globe)((Lobby) this).gb)
													.open = 2;
												((Globe)((Lobby) this).gb).upo = true;
											}
										}
										bool_119_ = true;
										if (((Control) control).handb) {
											((GameSparker)((Lobby) this).gs)
												.cmsg.setText(new StringBuilder().append(((GameSparker)
											((Lobby) this).gs)
												.cmsg.getText())
												.append("").append(((Lobby) this).pnames[i_116_])
												.toString());
											((Control) control).handb = false;
										}
									}
									if (((Lobby) this).invo)
									((Lobby) this).rd.setColor(new Color(62, 98, 0));
									else((Lobby) this).rd.setColor(new Color(0, 0, 0));
									boolean bool_122_ = (((Lobby) this).gb.drawl(((Lobby) this).rd, ((Lobby) this).pnames[i_116_], 68,
									53 + 30 * i_106_ - i_105_,
									bool_119_));
									if (!bool_119_ || !bool_122_) {
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString(((Lobby) this).pnames[i_116_],
										127 - (((Lobby) this).ftm.stringWidth(((Lobby) this).pnames[i_116_])) / 2,
										66 + 30 * i_106_ - i_105_);
										((Lobby) this).rd.setFont(new Font("Arial", 0, 10));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString(((Lobby) this).pcarnames[i_116_],
										127 - (((Lobby) this).ftm.stringWidth(((Lobby) this).pcarnames[i_116_])) / 2,
										78 + 30 * i_106_ - i_105_);
									}
									((Lobby) this).rd.setColor(color2k(150, 150, 150));
									((Lobby) this).rd.drawLine(70, 82 + 30 * i_106_ - i_105_, 185,
									82 + 30 * i_106_ - i_105_);
								}
								i_106_++;
							}
						}
						if (((Lobby) this).invo && i_106_ == 2)
						((Lobby) this).invo = false;
						if (!((Lobby) this).invo) {
							for (int i_123_ = ((Lobby) this).npo - 1;
							i_123_ >= 0; i_123_--) {
								if (((Lobby) this).pgames[i_123_] != -1) {
									int i_124_ = 0;
									for (int i_125_ = 0;
									i_125_ < ((Lobby) this).ngm;
									i_125_++) {
										if (((Lobby) this).pgames[i_123_] == ((Lobby) this).gnum[i_125_]) i_124_ = i_125_;
									}
									if (((Lobby) this).wait[i_124_] <= 0) {
										boolean bool_126_ = false;
										for (int i_127_ = 0;
										i_127_ < ((Lobby) this).npo;
										i_127_++) {
											if (i_123_ != i_127_ && (((Lobby) this).pnames[i_123_].equals(((Lobby) this).pnames[i_127_]))) {
												if ((((Lobby) this).pgames[i_127_]) == -1) bool_126_ = true;
												else {
													for (int i_128_ = 0;
													(i_128_ < (((Lobby) this)
														.ngm));
													i_128_++) {
														if (((((Lobby) this)
															.pgames[i_127_]) == (((Lobby) this)
															.gnum[i_128_])) && ((((Lobby) this)
															.wait[i_128_]) > 0)) bool_126_ = true;
													}
												}
											}
										}
										if (!bool_126_) {
											if (82 + 30 * i_106_ - i_105_ > 50 && (82 + 30 * (i_106_ - 1) - i_105_) < 415) {
												boolean bool_129_ = false;
												if (i > 70 && i < 185 && i_99_ > (52 + 30 * i_106_ - i_105_) && i_99_ < (82 + 30 * i_106_ - i_105_)) {
													if (((((Lobby) this).pgames[((Lobby) this).im]) == -1) && (((Lobby) this).join == -1) && (((Lobby) this)
														.chalngd) >= -1) {
														if (bool || ((((Lobby) this)
															.mousonp) == i_123_)) {
															((Lobby) this)
																.rd.setColor(color2k(255,
															255,
															255));
															((Lobby) this)
																.mousonp = i_123_;
															i_108_ = (52 + (30 * i_106_) - i_105_);
															if (bool) {
																if ((((Lobby)
																this)
																	.cmonp) == i_123_)
																((Lobby)
																this)
																	.ongame = (((Lobby)
																this)
																	.pgames[i_123_]);
																((Lobby) this)
																	.chalngd = -1;
															} else {
																if ((((Lobby)
																this)
																	.cmonp) == -1) {
																	((Lobby)
																	this)
																		.ongame = -1;
																	((Lobby)
																	this)
																		.cmonp = i_123_;
																}
																if ((((Lobby)
																this)
																	.ongame) == (((Lobby)
																this)
																	.pgames[i_123_]))
																((Lobby)
																this)
																	.mousonp = -1;
															}
														} else((Lobby) this)
															.rd.setColor(color2k(220,
														220,
														220));
														((Lobby) this).rd.fillRect(70, (53 + 30 * i_106_ - i_105_),
														116, 29);
														i_107_ = i_123_;
													}
													bool_129_ = true;
													if (((Control) control)
														.handb) {
														((GameSparker)
														((Lobby) this).gs)
															.cmsg.setText(new StringBuilder().append(((GameSparker)
														((Lobby)
														this).gs)
															.cmsg.getText())
															.append("").append(((Lobby)
														this)
															.pnames[i_123_])
															.toString());
														((Control) control)
															.handb = false;
													}
												}
												if ((((Lobby) this).pgames[((Lobby) this).im]) == -1 && (((Lobby) this).join == -1) && (((Lobby) this).chalngd >= -1)) {
													if ((((Lobby) this).wait[i_124_]) == 0)
													((Lobby) this).rd.setColor(new Color(117, 67,
													0));
													else((Lobby) this).rd.setColor(color2k(0, 28,
													102));
												} else if ((((Lobby) this).wait[i_124_]) == 0)
												((Lobby) this).rd.setColor(new Color(82, 47, 0));
												else((Lobby) this).rd.setColor(color2k(0, 20, 71));
												boolean bool_130_ = (((Lobby) this).gb.drawl(((Lobby) this).rd, (((Lobby) this).pnames[i_123_]),
												68, (53 + 30 * i_106_ - i_105_),
												bool_129_));
												if (!bool_129_ || !bool_130_) {
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													12));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString((((Lobby) this).pnames[i_123_]), (127 - (((Lobby) this)
														.ftm.stringWidth(((Lobby) this)
														.pnames[i_123_])) / 2), (66 + 30 * i_106_ - i_105_));
													((Lobby) this).rd.setFont(new Font("Arial", 0,
													10));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString((((Lobby) this)
														.pcarnames[i_123_]), (127 - (((Lobby) this)
														.ftm.stringWidth(((Lobby) this)
														.pcarnames[i_123_])) / 2), (78 + 30 * i_106_ - i_105_));
												}
												((Lobby) this).rd.setColor(color2k(150, 150, 150));
												((Lobby) this).rd.drawLine(70,
												82 + 30 * i_106_ - i_105_,
												185, (82 + 30 * i_106_ - i_105_));
											}
											i_106_++;
										}
									}
								}
							}
						}
					}
					if (((Lobby) this).mousonp != i_107_) {
						((Lobby) this).mousonp = -1;
						((Lobby) this).cmonp = -1;
					}
					if (((Lobby) this).npo == 0) {
						((Lobby) this).rd.setColor(new Color(0, 0, 0));
						((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
						((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
						((Lobby) this).rd.drawString("|  Loading Players  |",
						127 - (((Lobby) this).ftm.stringWidth("|  Loading Players  |") / 2),
						95);
					}
					((Lobby) this).rd.setColor(color2k(205, 205, 205));
					((Lobby) this).rd.fillRect(65, 25, 145, 28);
					((Lobby) this).rd.setColor(color2k(150, 150, 150));
					((Lobby) this).rd.drawLine(65, 50, 190, 50);
					((Lobby) this).rd.setColor(color2k(205, 205, 205));
					((Lobby) this).rd.fillRect(65, 413, 145, 12);
					((Lobby) this).rd.setColor(color2k(150, 150, 150));
					((Lobby) this).rd.drawLine(65, 415, 190, 415);
					((Lobby) this).rd.setColor(color2k(205, 205, 205));
					((Lobby) this).rd.fillRect(193, 53, 17, 360);
					((Lobby) this).rd.setColor(new Color(0, 0, 0));
					((Lobby) this).rd.drawLine(211, 25, 211, 425);
					((Lobby) this).rd.drawImage(((xtGraphics)
					((Lobby) this).xt).roomp,
					72, 30, null);
					if (((Lobby) this).mscro == 131 || i_104_ == 0) {
						if (i_104_ == 0)
						((Lobby) this).rd.setColor(color2k(205, 205, 205));
						else((Lobby) this).rd.setColor(color2k(215, 215, 215));
						((Lobby) this).rd.fillRect(193, 53, 17, 17);
					} else {
						((Lobby) this).rd.setColor(color2k(220, 220, 220));
						((Lobby) this).rd.fill3DRect(193, 53, 17, 17, true);
					}
					if (i_104_ != 0)
					((Lobby) this).rd.drawImage(((xtGraphics)
					((Lobby) this).xt).asu,
					198, 59, null);
					if (((Lobby) this).mscro == 132 || i_104_ == 0) {
						if (i_104_ == 0)
						((Lobby) this).rd.setColor(color2k(205, 205, 205));
						else((Lobby) this).rd.setColor(color2k(215, 215, 215));
						((Lobby) this).rd.fillRect(193, 396, 17, 17);
					} else {
						((Lobby) this).rd.setColor(color2k(220, 220, 220));
						((Lobby) this).rd.fill3DRect(193, 396, 17, 17, true);
					}
					if (i_104_ != 0)
					((Lobby) this).rd.drawImage(((xtGraphics)
					((Lobby) this).xt).asd,
					198, 403, null);
					if (i_104_ != 0 && ((Lobby) this).conon == 1) {
						if (((Lobby) this).lspos != ((Lobby) this).spos) {
							((Lobby) this).rd.setColor(color2k(215, 215, 215));
							((Lobby) this).rd.fillRect(193, (70 + ((Lobby) this).spos),
							17, 31);
						} else {
							if (((Lobby) this).mscro == 131)
							((Lobby) this).rd.setColor(color2k(215, 215,
							215));
							((Lobby) this).rd.fill3DRect(193,
							70 + (((Lobby) this)
								.spos),
							17, 31, true);
						}
						((Lobby) this).rd.setColor(color2k(150, 150, 150));
						((Lobby) this).rd.drawLine(198,
						83 + ((Lobby) this).spos,
						204,
						83 + ((Lobby) this).spos);
						((Lobby) this).rd.drawLine(198,
						85 + ((Lobby) this).spos,
						204,
						85 + ((Lobby) this).spos);
						((Lobby) this).rd.drawLine(198,
						87 + ((Lobby) this).spos,
						204,
						87 + ((Lobby) this).spos);
						if (((Lobby) this).mscro > 101 && ((Lobby) this).lspos != ((Lobby) this).spos)
						((Lobby) this).lspos = ((Lobby) this).spos;
						if (bool) {
							if (((Lobby) this).mscro == 125 && i > 193 && i < 210 && i_99_ > 70 + ((Lobby) this).spos && i_99_ < ((Lobby) this).spos + 101)
							((Lobby) this).mscro = i_99_ - ((Lobby) this).spos;
							if (((Lobby) this).mscro == 125 && i > 191 && i < 212 && i_99_ > 51 && i_99_ < 72)
							((Lobby) this).mscro = 131;
							if (((Lobby) this).mscro == 125 && i > 191 && i < 212 && i_99_ > 394 && i_99_ < 415)
							((Lobby) this).mscro = 132;
							if (((Lobby) this).mscro == 125 && i > 193 && i < 210 && i_99_ > 70 && i_99_ < 396) {
								((Lobby) this).mscro = 85;
								((Lobby) this).spos = i_99_ - ((Lobby) this).mscro;
							}
							int i_131_ = 1350 / i_104_;
							if (i_131_ < 1) i_131_ = 1;
							if (((Lobby) this).mscro == 131) {
								((Lobby) this).spos -= i_131_;
								if (((Lobby) this).spos > 295)
								((Lobby) this).spos = 295;
								if (((Lobby) this).spos < 0)
								((Lobby) this).spos = 0;
								((Lobby) this).lspos = ((Lobby) this).spos;
							}
							if (((Lobby) this).mscro == 132) {
								((Lobby) this).spos += i_131_;
								if (((Lobby) this).spos > 295)
								((Lobby) this).spos = 295;
								if (((Lobby) this).spos < 0)
								((Lobby) this).spos = 0;
								((Lobby) this).lspos = ((Lobby) this).spos;
							}
							if (((Lobby) this).mscro <= 101) {
								((Lobby) this).spos = i_99_ - ((Lobby) this).mscro;
								if (((Lobby) this).spos > 295)
								((Lobby) this).spos = 295;
								if (((Lobby) this).spos < 0)
								((Lobby) this).spos = 0;
							}
							if (((Lobby) this).mscro == 125)
							((Lobby) this).mscro = 225;
						} else if (((Lobby) this).mscro != 125)
						((Lobby) this).mscro = 125;
						if (i_100_ != 0 && i > 65 && i < 170 && i_99_ > 93 && i_99_ < 413) {
							((Lobby) this).spos -= i_100_;
							((Lobby) this).zeromsw = true;
							if (((Lobby) this).spos > 295) {
								((Lobby) this).spos = 295;
								((Lobby) this).zeromsw = false;
							}
							if (((Lobby) this).spos < 0) {
								((Lobby) this).spos = 0;
								((Lobby) this).zeromsw = false;
							}
							((Lobby) this).lspos = ((Lobby) this).spos;
						}
					}
					if (((Lobby) this).ongame == -1) {
						if (((Lobby) this).opengame >= 2) {
							if (((Lobby) this).opengame >= 27)
							((Lobby) this).opengame = 26;
							int i_132_ = 229 + ((Lobby) this).opengame;
							if (i_132_ > 255) i_132_ = 255;
							if (i_132_ < 0) i_132_ = 0;
							((Lobby) this).rd.setColor(color2k(i_132_, i_132_,
							i_132_));
							((Lobby) this).rd.fillRoundRect(225,
							59 - (int)((float)((Lobby) this).opengame * 2.23F),
							495, 200 + ((Lobby) this).opengame * 8, 20,
							20);
							((Lobby) this).rd.setColor(new Color(0, 0, 0));
							((Lobby) this).rd.drawRoundRect(225,
							59 - (int)((float)((Lobby) this).opengame * 2.23F),
							495, 200 + ((Lobby) this).opengame * 8, 20,
							20);
							if (!((xtGraphics)((Lobby) this).xt).lan) {
								((Lobby) this).rd.setColor(color2k(217, 217,
								217));
								((Lobby) this).rd.fillRoundRect(225, 263 + ((Lobby) this).opengame * 7,
								495, 157, 20, 20);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.drawRoundRect(225, 263 + ((Lobby) this).opengame * 7,
								495, 157, 20, 20);
							}
							((Lobby) this).btn = 0;
							if (((Lobby) this).prevloaded != -1)
							((Lobby) this).prevloaded = -1;
							if (((Lobby) this).updatec != -1)
							((Lobby) this).updatec = -1;
							if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
								((GameSparker)((Lobby) this).gs).cmsg.hide();
								((Lobby) this).gs.requestFocus();
							}
							((Lobby) this).opengame -= 2;
							if (((Lobby) this).opengame == 0 && ((Lobby) this).longame != -1 && ((Lobby) this).chalngd == -1) {
								((Lobby) this).ongame = ((Lobby) this).longame;
								((Lobby) this).longame = -1;
							}
							if (((Lobby) this).invo)
							((Lobby) this).invo = false;
							for (int i_133_ = 0; i_133_ < 7; i_133_++) {
								if (!((Lobby) this).invos[i_133_].equals(""))
								((Lobby) this).invos[i_133_] = "";
								if (!((Lobby) this).dinvi[i_133_].equals(""))
								((Lobby) this).dinvi[i_133_] = "";
							}
							if (((Lobby) this).fstart)
							((Lobby) this).fstart = false;
							for (int i_134_ = 0; i_134_ < 9; i_134_++) {
								if (((Lobby) this).cac[i_134_] != -1)
								((Lobby) this).cac[i_134_] = -1;
							}
							if (((Lobby) this).dispcar != -1)
							((Lobby) this).dispcar = -1;
						} else {
							if (!((xtGraphics)((Lobby) this).xt).lan) {
								drawSbutton((((xtGraphics)((Lobby) this).xt)
									.cgame),
								292, 42);
								drawSbutton((((xtGraphics)((Lobby) this).xt)
									.ccar),
								442, 42);
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								13));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.setColor(color2k(60, 60,
								60));
								if (!((GameSparker)((Lobby) this).gs)
									.rooms.isShowing())
								((GameSparker)((Lobby) this).gs).rooms.show();
								((GameSparker)((Lobby) this).gs).rooms.move(580 - (((Smenu)((GameSparker)
								((Lobby) this).gs).rooms)
									.w) / 2,
								29);
								if (((Smenu)(((GameSparker)((Lobby) this).gs)
									.rooms)).sel != 0) {
									stopallnow();
									int i_135_ = (((Smenu)((GameSparker)
									((Lobby) this).gs).rooms)
										.iroom[((Smenu)
									(((GameSparker)((Lobby) this).gs)
										.rooms)).sel]);
									if (i_135_ < 1000) {
										if (i_135_ >= 1 && i_135_ <= 5)
										((xtGraphics)((Lobby) this).xt)
											.servport = 7070 + i_135_;
									} else {
										i_135_ -= 1000;
										if (i_135_ >= 0 && (i_135_ < (((Login)((Lobby) this).lg)
											.nservers))) {
											((xtGraphics)((Lobby) this).xt)
												.servport = 7071;
											((xtGraphics)((Lobby) this).xt)
												.server = (((Login)((Lobby) this).lg)
												.servers[i_135_]);
											((xtGraphics)((Lobby) this).xt)
												.servername = (((Login)((Lobby) this).lg)
												.snames[i_135_]);
										}
									}
									inishlobby();
									((Smenu)(((GameSparker)((Lobby) this).gs)
										.rooms)).kmoused = 20;
								}
								if (((Smenu)(((GameSparker)((Lobby) this).gs)
									.rooms)).kmoused != 0) {
									i = -1;
									i_99_ = -1;
									bool = false;
									((Smenu)(((GameSparker)((Lobby) this).gs)
										.rooms)).kmoused--;
								}
							} else {
								((Lobby) this).rd.drawImage(((xtGraphics)
								(((Lobby) this)
									.xt)).lanm,
								241, 31, null);
								if (((Lobby) this).npo <= 1) {
									drawSbutton(((xtGraphics)
									((Lobby) this).xt).cgame,
									292, -1000);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									if (((Lobby) this).ncnt == 0)
									((Lobby) this).rd.setColor(new Color(188, 111, 0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 13));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(((Lobby) this).lmsg,
									472 - (((Lobby) this).ftm.stringWidth(((Lobby) this).lmsg)) / 2,
									295);
									if ((((Lobby) this).lmsg.equals(". . . | Searching/Waiting for other LAN Players | . . .")) && ((Lobby) this).ncnt == 0) {
										((Lobby) this).lmsg = "| Searching/Waiting for other LAN Players |";
										((Lobby) this).ncnt = 5;
									}
									if ((((Lobby) this).lmsg.equals(". . | Searching/Waiting for other LAN Players | . .")) && ((Lobby) this).ncnt == 0) {
										((Lobby) this).lmsg = ". . . | Searching/Waiting for other LAN Players | . . .";
										((Lobby) this).ncnt = 5;
									}
									if ((((Lobby) this).lmsg.equals(". | Searching/Waiting for other LAN Players | .")) && ((Lobby) this).ncnt == 0) {
										((Lobby) this).lmsg = ". . | Searching/Waiting for other LAN Players | . .";
										((Lobby) this).ncnt = 5;
									}
									if ((((Lobby) this).lmsg.equals("| Searching/Waiting for other LAN Players |")) && ((Lobby) this).ncnt == 0) {
										((Lobby) this).lmsg = ". | Searching/Waiting for other LAN Players | .";
										((Lobby) this).ncnt = 5;
									}
									if (((Lobby) this).ncnt != 0)
									((Lobby) this).ncnt--;
									((Lobby) this).rd.setColor(color2k(70, 70,
									70));
									((Lobby) this).rd.drawString("Hacked by Chris",
									225, 325);
									((Lobby) this).rd.drawString("A feature to use a custom IP will be added eventually",
									225, 345);
									((Lobby) this).rd.drawString("For now, just use Hamachi or something...", 225, 365);
								}/* else if (!((Lobby) this).lanlogged) {
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 13));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString("You have played the allowed 3 LAN games per day!", (472 - ((((Lobby) this).ftm.stringWidth("You have played the allowed 3 LAN games per day!")) / 2)),
									295);
									((Lobby) this).rd.setColor(color2k(70, 70,
									70));
									((Lobby) this).rd.drawString("There needs to be at least one of the LAN players in the lobby with a registered",
									225, 325);
									((Lobby) this).rd.drawString("account to be able to play LAN unlimitedly...",
									225, 345);
									((Lobby) this).rd.drawString("Just one registered user allows everyone in the LAN game to play unlimitedly!",
									225, 365);
									((Lobby) this).rd.drawString("Please register now!", 225, 385);
									drawSbutton(((xtGraphics)
									((Lobby) this).xt).register,
									472, 395);
								}*/ else {
									((Lobby) this).rd.setColor(color2k(90, 90,
									90));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(new StringBuilder().append("[  ")
										.append(i_106_).append(" Players Connected  ]")
										.toString(),
									472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("[  ").append(i_106_).append(" Players Connected  ]")
										.toString())) / 2,
									295);
									drawSbutton(((xtGraphics)
									((Lobby) this).xt).cgame,
									472, 325);
								}
								drawSbutton((((xtGraphics)((Lobby) this).xt)
									.ccar),
								442, -1000);
							}
							drawSbutton(((xtGraphics)((Lobby) this).xt).exit,
							690, 42);
							if (((Control) control).enter && !((GameSparker)((Lobby) this).gs).cmsg.getText().equals("Type here...") && !((GameSparker)((Lobby) this).gs).cmsg.getText().equals("")) {
								if (((Lobby) this).chalngd == -1)
								((Lobby) this).pessd[2] = true;
								else((Lobby) this).pessd[5] = true;
								((Control) control).enter = false;
								String string = ((GameSparker)((Lobby) this).gs)
									.cmsg.getText().replace('|', ':');
								if ((string.toLowerCase().indexOf(((GameSparker)((Lobby) this).gs)
									.tpass.getText().toLowerCase())) != -1) string = " ";
								if (!((Lobby) this).xt.msgcheck(string) && ((Lobby) this).updatec > -12) {
									for (int i_136_ = 0; i_136_ < 6;
									i_136_++) {
										((Lobby) this).sentn[i_136_] = ((Lobby) this).sentn[i_136_ + 1];
										((Lobby) this).cnames[i_136_] = (((Lobby) this).cnames[i_136_ + 1]);
									}
									((Lobby) this).sentn[6] = string;
									((Lobby) this).cnames[6] = (((Lobby) this).pnames[((Lobby) this).im]);
									if (((Lobby) this).updatec > -11)
									((Lobby) this).updatec = -11;
									else((Lobby) this).updatec--;
									((Lobby) this).spos3 = 28;
								} else((xtGraphics)((Lobby) this).xt).warning++;
								((GameSparker)((Lobby) this).gs).cmsg.setText("");
							}
							if (((Lobby) this).chalngd == -1) {
								((Lobby) this).rd.setColor(color2k(230, 230,
								230));
								((Lobby) this).rd.fillRoundRect(225, 59, 495,
								200, 20, 20);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.drawRoundRect(225, 59, 495,
								200, 20, 20);
								if (((Lobby) this).britchl != 0)
								((Lobby) this).britchl = 0;
								i_104_ = (((Lobby) this).ngm - 5) * 24;
								if (i_104_ < 0) i_104_ = 0;
								i_105_ = (int)(((float)((Lobby) this).spos2 / 82.0F * (float) i_104_) - 2.0F);
								int[] is = new int[((Lobby) this).ngm];
								int[] is_137_ = new int[((Lobby) this).ngm];
								for (int i_138_ = 0;
								i_138_ < ((Lobby) this).ngm; i_138_++)
								is[i_138_] = 0;
								for (int i_139_ = 0;
								i_139_ < ((Lobby) this).ngm; i_139_++) {
									for (int i_140_ = i_139_ + 1;
									i_140_ < ((Lobby) this).ngm;
									i_140_++) {
										if (((Lobby) this).wait[i_139_] != ((Lobby) this).wait[i_140_]) {
											if ((((Lobby) this).wait[i_139_] <= 0) && (((Lobby) this).wait[i_140_] <= 0)) {
												if (((Lobby) this).wait[i_139_] < (((Lobby) this).wait[i_140_])) is[i_139_]++;
												else is[i_140_]++;
											} else if ((((((Lobby) this).wait[i_139_]) > (((Lobby) this).wait[i_140_])) || (((Lobby) this).wait[i_139_]) <= 0) && (((Lobby) this).wait[i_140_]) > 0) is[i_139_]++;
											else is[i_140_]++;
										} else if (i_140_ < i_139_) is[i_139_]++;
										else is[i_140_]++;
									}
									is_137_[is[i_139_]] = i_139_;
								}
								if (((Control) control).down) {
									((Lobby) this).opselect++;
									for (boolean bool_141_ = false;
									((80 + 24 * ((Lobby) this).opselect - i_105_) > 202 && !bool_141_);
									i_105_ = (int)(((float)(((Lobby) this)
										.spos2) / 82.0F * (float) i_104_) - 2.0F)) {
										((Lobby) this).spos2++;
										if (((Lobby) this).spos2 > 82) {
											((Lobby) this).spos2 = 82;
											bool_141_ = true;
										}
										if (((Lobby) this).spos2 < 0) {
											((Lobby) this).spos2 = 0;
											bool_141_ = true;
										}
									}
									((Control) control).down = false;
								}
								if (((Control) control).up) {
									((Lobby) this).opselect--;
									for (boolean bool_142_ = false;
									((80 + 24 * ((Lobby) this).opselect - i_105_) < 80 && !bool_142_);
									i_105_ = (int)(((float)(((Lobby) this)
										.spos2) / 82.0F * (float) i_104_) - 2.0F)) {
										((Lobby) this).spos2--;
										if (((Lobby) this).spos2 > 82) {
											((Lobby) this).spos2 = 82;
											bool_142_ = true;
										}
										if (((Lobby) this).spos2 < 0) {
											((Lobby) this).spos2 = 0;
											bool_142_ = true;
										}
									}
									((Control) control).up = false;
								}
								int i_143_ = -1;
								if (((Lobby) this).mousonp != -1) {
									int i_144_ = 0;
									for (int i_145_ = 0;
									i_145_ < ((Lobby) this).ngm;
									i_145_++) {
										if ((((Lobby) this).pgames[((Lobby) this).mousonp]) == ((Lobby) this).gnum[i_145_]) i_144_ = i_145_;
									}
									i_143_ = 91 + 24 * is[i_144_] - i_105_;
									if (80 + 24 * is[i_144_] - i_105_ > 202) {
										int i_146_ = 1000 / i_104_;
										if (i_146_ < 1) i_146_ = 1;
										((Lobby) this).spos2 += i_146_;
										i_143_ = -1;
									}
									if (80 + 24 * is[i_144_] - i_105_ < 80) {
										int i_147_ = 1000 / i_104_;
										if (i_147_ < 1) i_147_ = 1;
										((Lobby) this).spos2 -= i_147_;
										i_143_ = -1;
									}
									if (((Lobby) this).spos2 > 82)
									((Lobby) this).spos2 = 82;
									if (((Lobby) this).spos2 < 0)
									((Lobby) this).spos2 = 0;
									i_105_ = (int)(((float)((Lobby) this).spos2 / 82.0F * (float) i_104_) - 2.0F);
									((Lobby) this).opselect = is[i_144_];
								}
								if (((Lobby) this).opselect <= -1)
								((Lobby) this).opselect = 0;
								if (((Lobby) this).opselect >= ((Lobby) this).ngm)
								((Lobby) this).opselect = ((Lobby) this).ngm - 1;
								int i_148_ = 0;
								for (int i_149_ = 0;
								i_149_ < ((Lobby) this).ngm; i_149_++) {
									if (80 + 24 * i_149_ - i_105_ < 224 && 80 + 24 * i_149_ - i_105_ > 56) {
										if (((Lobby) this).opselect == i_149_) {
											if (80 + 24 * i_149_ - i_105_ >= 224)
											((Lobby) this).opselect--;
											if (80 + 24 * i_149_ - i_105_ < 62)
											((Lobby) this).opselect++;
										}
										boolean bool_150_ = false;
										boolean bool_151_ = false;
										if (!((GameSparker)((Lobby) this).gs)
											.openm) {
											if (i > 241 && i < 692 && i_99_ > (92 + 24 * i_149_ - i_105_) && i_99_ < (110 + 24 * i_149_ - i_105_)) {
												if (((Lobby) this).lxm != i || (((Lobby) this).lym != i_99_))
												((Lobby) this).opselect = i_149_;
												bool_150_ = true;
												if (bool) {
													if (((Lobby) this).clicked == -1)
													((Lobby) this).clicked = is_137_[i_149_];
												} else {
													if (((Lobby) this).clicked == is_137_[i_149_]) {
														((Lobby) this).ongame = (((Lobby) this)
															.gnum[(is_137_[i_149_])]);
														((Lobby) this).opengame = 0;
														if (i >= 641 && i <= 689 && (i_99_ > (92 + (24 * i_149_) - i_105_)) && (i_99_ < (110 + (24 * i_149_) - i_105_)) && ((((Lobby) this)
															.wait[(is_137_[i_149_])]) > 0)) {
															boolean bool_152_ = false;
															if ((((Lobby) this)
																.gwarb[(is_137_[i_149_])]) == 0) {
																if (((Lobby)
																this)
																	.gplyrs[(is_137_[i_149_])].equals("") || (((Lobby)
																this)
																	.gplyrs[is_137_[i_149_]].indexOf(((Lobby)
																this)
																	.pnames[(((Lobby)
																this)
																	.im)])) != -1) bool_152_ = true;
															} else if ((((xtGraphics)
															(((Lobby)
															this)
																.xt))
																.clan.toLowerCase()
																.equals(((Lobby)
															this)
																.gaclan[is_137_[i_149_]].toLowerCase())) || (((xtGraphics)
															((Lobby)
															this).xt).clan.toLowerCase().equals(((Lobby)
															this).gvclan[is_137_[i_149_]].toLowerCase()))) bool_152_ = true;
															if (bool_152_) {
																((Lobby) this)
																	.join = (((Lobby)
																this)
																	.gnum[(is_137_[i_149_])]);
																((Lobby) this)
																	.msg = "| Joining Game |";
																((Lobby) this)
																	.spos = 0;
															}
														}
														((Lobby) this).clicked = -1;
													}
													i_148_++;
												}
											} else i_148_++;
											if (i >= 641 && i <= 689 && i_99_ > (92 + 24 * i_149_ - i_105_) && i_99_ < (110 + 24 * i_149_ - i_105_) && bool) bool_151_ = true;
										}
										if (((Lobby) this).opselect == i_149_) {
											if (bool_150_ && bool || ((Control) control).enter) {
												((Lobby) this).rd.setColor(color2k(200, 200, 200));
												if (((Control) control)
													.enter) {
													((Lobby) this).ongame = (((Lobby) this).gnum[is_137_[i_149_]]);
													((Lobby) this).opengame = 0;
													((Control) control).enter = false;
												}
											} else((Lobby) this).rd.setColor(color2k(255, 255, 255));
											((Lobby) this).rd.fillRect(241,
											92 + 24 * i_149_ - i_105_,
											451, 18);
											if (bool_150_) {
												((Lobby) this).rd.setColor(color2k(150, 150, 150));
												((Lobby) this).rd.drawRect(239,
												90 + 24 * i_149_ - i_105_,
												454, 21);
											}
										}
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString((((Lobby) this).gstages[is_137_[i_149_]]),
										382 - (((Lobby) this).ftm.stringWidth(((Lobby) this).gstages[is_137_[i_149_]])) / 2,
										105 + 24 * i_149_ - i_105_);
										((Lobby) this).rd.drawString("|", 525,
										105 + 24 * i_149_ - i_105_);
										((Lobby) this).rd.drawString("|", 584,
										105 + 24 * i_149_ - i_105_);
										if ((((Lobby) this).wait[is_137_[i_149_]]) > 0) {
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).npls[is_137_[i_149_]])
												.append(" / ").append(((Lobby) this).mnpls[is_137_[i_149_]])
												.append("").toString(), (556 - (((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("").append(((Lobby) this).npls[is_137_[i_149_]])
												.append(" / ").append(((Lobby) this).mnpls[is_137_[i_149_]])
												.append("")
												.toString())) / 2),
											105 + 24 * i_149_ - i_105_);
											((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
											((Lobby) this).rd.setColor(new Color(80, 128, 0));
											((Lobby) this).rd.drawString("Waiting", 593,
											105 + 24 * i_149_ - i_105_);
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											if (!bool_151_) {
												((Lobby) this).rd.setColor(color2k(230, 230, 230));
												((Lobby) this).rd.fill3DRect(641,
												92 + 24 * i_149_ - i_105_,
												48, 18, true);
												((Lobby) this).rd.fill3DRect(642,
												93 + 24 * i_149_ - i_105_,
												46, 16, true);
											} else {
												((Lobby) this).rd.setColor(color2k(230, 230, 230));
												((Lobby) this).rd.fillRect(641,
												92 + 24 * i_149_ - i_105_,
												48, 18);
											}
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
											boolean bool_153_ = false;
											if ((((Lobby) this).gwarb[is_137_[i_149_]]) == 0) {
												if (((Lobby) this).gplyrs[is_137_[i_149_]].equals("") || ((((Lobby) this)
													.gplyrs[is_137_[i_149_]].indexOf(((Lobby) this).pnames[((Lobby) this).im])) != -1)) bool_153_ = true;
											} else if ((((xtGraphics)
											((Lobby) this).xt)
												.clan.toLowerCase().equals(((Lobby) this)
												.gaclan[is_137_[i_149_]].toLowerCase())) || (((xtGraphics)
											((Lobby) this).xt)
												.clan.toLowerCase().equals(((Lobby) this)
												.gvclan[(is_137_[i_149_])].toLowerCase()))) bool_153_ = true;
											if (bool_153_)
											((Lobby) this).rd.drawString("Join",
											665 - (((Lobby) this)
												.ftm.stringWidth("Join")) / 2, (105 + 24 * i_149_ - i_105_));
											else((Lobby) this).rd.drawString("View",
											665 - (((Lobby) this)
												.ftm.stringWidth("View")) / 2, (105 + 24 * i_149_ - i_105_));
										} else {
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).npls[is_137_[i_149_]])
												.append("").toString(), (556 - ((((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("").append(((Lobby) this).npls[is_137_[i_149_]])
												.append("").toString())) / 2)),
											105 + 24 * i_149_ - i_105_);
											((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											if ((((Lobby) this).wait[is_137_[i_149_]]) == 0) {
												((Lobby) this).rd.setColor(new Color(128, 73, 0));
												((Lobby) this).rd.drawString("Started", 594, (105 + 24 * i_149_ - i_105_));
											} else {
												((Lobby) this).rd.setColor(color2k(100, 100, 100));
												((Lobby) this).rd.drawString("Finished", 590, (105 + 24 * i_149_ - i_105_));
											}
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											if (!bool_151_) {
												((Lobby) this).rd.setColor(color2k(230, 230, 230));
												((Lobby) this).rd.fill3DRect(641,
												92 + 24 * i_149_ - i_105_,
												48, 18, true);
											} else {
												((Lobby) this).rd.setColor(color2k(230, 230, 230));
												((Lobby) this).rd.fillRect(641,
												92 + 24 * i_149_ - i_105_,
												48, 18);
											}
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
											((Lobby) this).rd.drawString("View", (665 - (((Lobby) this).ftm.stringWidth("View") / 2)),
											105 + 24 * i_149_ - i_105_);
										}
									} else {
										if (((Lobby) this).opselect == i_149_) {
											if (80 + 24 * i_149_ - i_105_ >= 224)
											((Lobby) this).opselect--;
											if (80 + 24 * i_149_ - i_105_ <= 56)
											((Lobby) this).opselect++;
										}
										i_148_++;
									}
								}
								if (i_148_ == ((Lobby) this).ngm && ((Lobby) this).clicked != -1)
								((Lobby) this).clicked = -1;
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								12));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								if (((Lobby) this).ngm == 0) {
									if (!((Lobby) this).lloaded)
									((Lobby) this).rd.drawString("|  Loading Games  |", (472 - (((Lobby) this).ftm.stringWidth("|  Loading Games  |")) / 2),
									165);
									else if (!((xtGraphics)((Lobby) this).xt)
										.lan)
									((Lobby) this).rd.drawString("No Games Created",
									472 - (((Lobby) this).ftm.stringWidth("No Games Created")) / 2,
									165);
								}
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(235, 65, 480, 25);
								((Lobby) this).rd.drawImage(((xtGraphics)
								(((Lobby) this)
									.xt)).games,
								241, 69, null);
								((Lobby) this).rd.setColor(color2k(70, 70,
								70));
								((Lobby) this).rd.drawString("Stage Name",
								382 - ((Lobby) this).ftm.stringWidth("Stage Name") / 2,
								81);
								((Lobby) this).rd.drawString("|", 525, 81);
								((Lobby) this).rd.drawString("Players",
								556 - ((Lobby) this).ftm.stringWidth("Players") / 2,
								81);
								((Lobby) this).rd.drawString("|", 584, 81);
								((Lobby) this).rd.drawString("Status",
								641 - ((Lobby) this).ftm.stringWidth("Status") / 2,
								81);
								((Lobby) this).rd.setColor(color2k(150, 150,
								150));
								((Lobby) this).rd.drawLine(235, 87, 696, 87);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(235, 237, 480, 17);
								((Lobby) this).rd.setColor(color2k(150, 150,
								150));
								((Lobby) this).rd.drawLine(235, 239, 696, 239);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(698, 107, 17, 113);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(231, 65, 4, 189);
								if (((Lobby) this).mscro2 == 141 || i_104_ == 0) {
									if (i_104_ == 0)
									((Lobby) this).rd.setColor(color2k(205, 205, 205));
									else((Lobby) this).rd.setColor(color2k(215, 215, 215));
									((Lobby) this).rd.fillRect(698, 90, 17,
									17);
								} else {
									((Lobby) this).rd.setColor(color2k(220, 220, 220));
									((Lobby) this).rd.fill3DRect(698, 90, 17,
									17, true);
								}
								if (i_104_ != 0)
								((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).asu,
								703, 96, null);
								if (((Lobby) this).mscro2 == 142 || i_104_ == 0) {
									if (i_104_ == 0)
									((Lobby) this).rd.setColor(color2k(205, 205, 205));
									else((Lobby) this).rd.setColor(color2k(215, 215, 215));
									((Lobby) this).rd.fillRect(698, 220, 17,
									17);
								} else {
									((Lobby) this).rd.setColor(color2k(220, 220, 220));
									((Lobby) this).rd.fill3DRect(698, 220, 17,
									17, true);
								}
								if (i_104_ != 0)
								((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).asd,
								703, 226, null);
								if (i_104_ != 0) {
									if (((Lobby) this).lspos2 != ((Lobby) this).spos2) {
										((Lobby) this).rd.setColor(color2k(215, 215, 215));
										((Lobby) this).rd.fillRect(698, 107 + ((Lobby) this).spos2,
										17, 31);
									} else {
										if (((Lobby) this).mscro2 == 141)
										((Lobby) this).rd.setColor(color2k(215, 215, 215));
										((Lobby) this).rd.fill3DRect(698, 107 + ((Lobby) this).spos2,
										17, 31, true);
									}
									((Lobby) this).rd.setColor(color2k(150, 150, 150));
									((Lobby) this).rd.drawLine(703, 120 + ((Lobby) this).spos2, 709,
									120 + ((Lobby) this).spos2);
									((Lobby) this).rd.drawLine(703, 122 + ((Lobby) this).spos2, 709,
									122 + ((Lobby) this).spos2);
									((Lobby) this).rd.drawLine(703, 124 + ((Lobby) this).spos2, 709,
									124 + ((Lobby) this).spos2);
									if (((Lobby) this).mscro2 > 138 && (((Lobby) this).lspos2 != ((Lobby) this).spos2))
									((Lobby) this).lspos2 = ((Lobby) this).spos2;
									if (bool) {
										if (((Lobby) this).mscro2 == 145 && i > 698 && i < 715 && (i_99_ > 107 + ((Lobby) this).spos2) && (i_99_ < ((Lobby) this).spos2 + 138))
										((Lobby) this).mscro2 = i_99_ - ((Lobby) this).spos2;
										if (((Lobby) this).mscro2 == 145 && i > 696 && i < 717 && i_99_ > 88 && i_99_ < 109)
										((Lobby) this).mscro2 = 141;
										if (((Lobby) this).mscro2 == 145 && i > 696 && i < 717 && i_99_ > 218 && i_99_ < 239)
										((Lobby) this).mscro2 = 142;
										if (((Lobby) this).mscro2 == 145 && i > 698 && i < 715 && i_99_ > 107 && i_99_ < 220) {
											((Lobby) this).mscro2 = 122;
											((Lobby) this).spos2 = (i_99_ - ((Lobby) this).mscro2);
										}
										int i_154_ = 400 / i_104_;
										if (i_154_ < 1) i_154_ = 1;
										if (((Lobby) this).mscro2 == 141) {
											((Lobby) this).spos2 -= i_154_;
											if (((Lobby) this).spos2 > 82)
											((Lobby) this).spos2 = 82;
											if (((Lobby) this).spos2 < 0)
											((Lobby) this).spos2 = 0;
											((Lobby) this).lspos2 = ((Lobby) this).spos2;
										}
										if (((Lobby) this).mscro2 == 142) {
											((Lobby) this).spos2 += i_154_;
											if (((Lobby) this).spos2 > 82)
											((Lobby) this).spos2 = 82;
											if (((Lobby) this).spos2 < 0)
											((Lobby) this).spos2 = 0;
											((Lobby) this).lspos2 = ((Lobby) this).spos2;
										}
										if (((Lobby) this).mscro2 <= 138) {
											((Lobby) this).spos2 = (i_99_ - ((Lobby) this).mscro2);
											if (((Lobby) this).spos2 > 82)
											((Lobby) this).spos2 = 82;
											if (((Lobby) this).spos2 < 0)
											((Lobby) this).spos2 = 0;
										}
										if (((Lobby) this).mscro2 == 145)
										((Lobby) this).mscro2 = 225;
									} else if (((Lobby) this).mscro2 != 145)
									((Lobby) this).mscro2 = 145;
									if (i_100_ != 0 && i > 235 && i < 698 && i_99_ > 87 && i_99_ < 239) {
										((Lobby) this).spos2 -= i_100_;
										((Lobby) this).zeromsw = true;
										if (((Lobby) this).spos2 > 82) {
											((Lobby) this).spos2 = 82;
											((Lobby) this).zeromsw = false;
										}
										if (((Lobby) this).spos2 < 0) {
											((Lobby) this).spos2 = 0;
											((Lobby) this).zeromsw = false;
										}
										((Lobby) this).lspos2 = ((Lobby) this).spos2;
									}
								}
								if (((Lobby) this).mousonp != -1 && i_143_ != -1) {
									((Lobby) this).rd.setColor(color2k(255, 255, 255));
									int[] is_155_ = {
										185, 241, 241, 185
									};
									int[] is_156_ = {
										i_108_, i_143_, i_143_ + 19,
										i_108_ + 30
									};
									((Lobby) this).rd.fillPolygon(is_155_,
									is_156_, 4);
									((Lobby) this).rd.setColor(color2k(150, 150, 150));
									((Lobby) this).rd.drawLine(185, i_108_,
									241, i_143_);
									((Lobby) this).rd.drawLine(185,
									i_108_ + 30,
									241,
									i_143_ + 19);
									((Lobby) this).rd.drawLine(241, i_143_,
									692, i_143_);
									((Lobby) this).rd.drawLine(241,
									i_143_ + 19,
									692,
									i_143_ + 19);
								}
							} else {
								int i_157_ = 230 + ((Lobby) this).britchl;
								if (i_157_ > 255) i_157_ = 255;
								if (i_157_ < 0) i_157_ = 0;
								((Lobby) this).rd.setColor(color2k(i_157_, i_157_, i_157_));
								((Lobby) this).rd.fillRoundRect(225, 59, 495,
								200, 20, 20);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.drawRoundRect(225, 59, 495,
								200, 20, 20);
								if (((Lobby) this).britchl < 25)
								((Lobby) this).britchl += 5;
								if (((Lobby) this).chalngd > -1) {
									int i_158_ = 0;
									for (int i_159_ = 0;
									i_159_ < ((Lobby) this).ngm;
									i_159_++) {
										if (((Lobby) this).chalngd == ((Lobby) this).gnum[i_159_]) i_158_ = i_159_;
									}
									if (((Lobby) this).cflk % 4 != 0 || ((Lobby) this).cflk == 0) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString(new StringBuilder().append("You have been invited by ")
											.append(((Lobby) this).chalby).append(" to join a game!")
											.toString(), (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("You have been invited by ")
											.append(((Lobby) this).chalby)
											.append(" to join a game!")
											.toString())) / 2),
										95);
										((Lobby) this).rd.setColor(new Color(117, 67, 0));
										((Lobby) this).rd.drawString(((Lobby) this).chalby, (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("You have been invited by ")
											.append(((Lobby) this).chalby)
											.append(" to join a game!")
											.toString())) / 2 + (((Lobby) this).ftm.stringWidth("You have been invited by "))),
										95);
									}
									if (((Lobby) this).cflk != 0)
									((Lobby) this).cflk--;
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(new StringBuilder().append("Stage:  ").append(((Lobby) this).gstages[i_158_])
										.append(" ,  Laps: ").append(((Lobby) this).gnlaps[i_158_])
										.append("").toString(),
									472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Stage:  ").append(((Lobby) this).gstages[i_158_])
										.append(" ,  Laps: ").append(((Lobby) this).gnlaps[i_158_])
										.append("").toString())) / 2,
									130);
									((Lobby) this).rd.setColor(new Color(62, 98, 0));
									((Lobby) this).rd.drawString(((Lobby) this).gstages[i_158_], (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Stage:  ").append(((Lobby) this).gstages[i_158_])
										.append(" ,  Laps: ").append(((Lobby) this).gnlaps[i_158_])
										.append("").toString())) / 2 + ((Lobby) this).ftm.stringWidth("Stage:  ")),
									130);
									((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gnlaps[i_158_])
										.append("").toString(), (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Stage:  ").append(((Lobby) this).gstages[i_158_])
										.append(" ,  Laps: ").append(((Lobby) this).gnlaps[i_158_])
										.append("").toString())) / 2 + (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Stage:  ").append(((Lobby) this).gstages[i_158_])
										.append(" ,  Laps: ").toString()))),
									130);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.drawString(new StringBuilder().append("Players:  ").append(((Lobby) this).mnpls[i_158_])
										.append("").toString(),
									472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Players:  ").append(((Lobby) this).mnpls[i_158_])
										.append("").toString())) / 2,
									150);
									((Lobby) this).rd.setColor(new Color(62, 98, 0));
									((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).mnpls[i_158_])
										.append("").toString(), (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Players:  ").append(((Lobby) this).mnpls[i_158_])
										.append("").toString())) / 2 + ((Lobby) this).ftm.stringWidth("Players:  ")),
									150);
									Date date = new Date();
									long l = date.getTime();
									if (((Lobby) this).ptime == 0L || l > ((Lobby) this).ptime + 1000L) {
										if (((Lobby) this).ptime != 0L)
										((Lobby) this).ctime--;
										((Lobby) this).ptime = l;
									}
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									0, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(new StringBuilder().append("( ")
										.append(((Lobby) this).ctime).append(" )").toString(),
									472 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("( ").append(((Lobby) this).ctime)
										.append(" )").toString())) / 2,
									170);
									if (((Lobby) this).ctime == 0) {
										((Lobby) this).ongame = ((Lobby) this).longame;
										((Lobby) this).chalngd = -1;
										((Lobby) this).longame = -1;
									}
									stringbutton("   View Game   ", 352, 215,
									2);
									stringbutton("   Join Game   ", 462, 215,
									2);
									stringbutton("   Decline X   ", 599, 215,
									2);
								} else {
									if (((Lobby) this).chalngd != -5) stringbutton(" Cancel X ", 669, 85, 2);
									if (((Lobby) this).chalngd == -6) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
										((Lobby) this).rd.drawString("This room already has a game that has started.",
										288, 120);
										((Lobby) this).rd.drawString("Please switch to another room to create a new game.",
										288, 140);
										((Lobby) this).rd.drawString("Or wait for the game to finish.",
										288, 160);
										((Lobby) this).rd.drawString("Use the dropdown menu above to change room or server.",
										288, 180);
										int[] is = {
											580, 569, 576, 576, 584,
											584, 591
										};
										int[] is_160_ = {
											66, 77, 77, 102, 102, 77, 77
										};
										((Lobby) this).rd.fillPolygon(is, is_160_, 7);
										stringbutton("     OK     ", 472, 215,
										1);
									}
									if (((Lobby) this).chalngd == -2) {
										boolean bool_161_ = false;
										boolean bool_162_ = false;
										if (!((GameSparker)((Lobby) this).gs)
											.wgame.isShowing())
										((GameSparker)((Lobby) this).gs)
											.wgame.show();
										((GameSparker)((Lobby) this).gs)
											.wgame.move(236, 68);
										if (((GameSparker)((Lobby) this).gs)
											.wgame.getSelectedIndex() == 0) {
											if (((Lobby) this).inwab) {
												((Lobby) this).inwab = false;
												((GameSparker)
												((Lobby) this).gs)
													.warb.hide();
												((Lobby) this).loadstage = 0;
											}
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
											((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											if (((Lobby) this).sflk % 4 != 0 || ((Lobby) this).sflk == 0)
											((Lobby) this).rd.drawString("Select Stage",
											472 - ((((Lobby) this)
												.ftm.stringWidth("Select Stage")) / 2),
											85);
											if (((Lobby) this).sflk != 0)
											((Lobby) this).sflk--;
											int i_163_ = 0;
											((GameSparker)((Lobby) this).gs)
												.sgame.setSize(139, 22);
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 0) {
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.snfmm.getWidth()) / 2));
												((Lobby) this).sgflag = 0;
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 1) {
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.snfm1.getWidth()) / 2));
												((Lobby) this).sgflag = 1;
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 2) {
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.snfm2.getWidth()) / 2));
												((Lobby) this).sgflag = 2;
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 3) {
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.setSize(338, 22);
												if (((Lobby) this).sgflag != 3) {
													((Lobby) this).gstage = 0;
													if (((xtGraphics)
													((Lobby) this).xt)
														.logged) {
														if (((CarDefine)
														(((Lobby) this)
															.cd)).msloaded != 1) {
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.removeAll();
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.add(((Lobby)
															this).rd,
																"Loading your stages now, please wait...");
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.select(0);
															((Lobby) this)
																.msload = 1;
														}
													} else {
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.removeAll();
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.add(((Lobby) this).rd,
															"You need to have a full account to access this.");
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.select(0);
														((CarDefine)
														((Lobby) this).cd)
															.msloaded = 0;
													}
													((Lobby) this).sgflag = 3;
												}
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.mstgs.getWidth()) / 2));
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 4) {
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.setSize(338, 22);
												if (((Lobby) this).sgflag != 4) {
													((Lobby) this).gstage = 0;
													if (((xtGraphics)
													((Lobby) this).xt)
														.logged) {
														if (((CarDefine)
														(((Lobby) this)
															.cd)).msloaded != 7) {
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.removeAll();
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.add(((Lobby)
															this).rd,
																"Loading your stages now, please wait...");
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.select(0);
															((Lobby) this)
																.msload = 7;
														}
													} else {
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.removeAll();
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.add(((Lobby) this).rd,
															"You need to have a full account to access this.");
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.select(0);
														((CarDefine)
														((Lobby) this).cd)
															.msloaded = 0;
													}
													((Lobby) this).sgflag = 4;
												}
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.mstgs.getWidth()) / 2));
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 5) {
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.setSize(338, 22);
												if (((Lobby) this).sgflag != 5) {
													((Lobby) this).gstage = 0;
													if (((xtGraphics)
													((Lobby) this).xt)
														.logged) {
														if (((CarDefine)
														(((Lobby) this)
															.cd)).msloaded != 3) {
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.removeAll();
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.add(((Lobby)
															this).rd,
																"Loading your stages now, please wait...");
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.select(0);
															((Lobby) this)
																.msload = 3;
														}
													} else {
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.removeAll();
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.add(((Lobby) this).rd,
															"You need to have a full account to access this.");
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.select(0);
														((CarDefine)
														((Lobby) this).cd)
															.msloaded = 0;
													}
													((Lobby) this).sgflag = 5;
												}
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.mstgs.getWidth()) / 2));
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 6) {
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.setSize(338, 22);
												if (((Lobby) this).sgflag != 6) {
													((Lobby) this).gstage = 0;
													if (((xtGraphics)
													((Lobby) this).xt)
														.logged) {
														if (((CarDefine)
														(((Lobby) this)
															.cd)).msloaded != 4) {
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.removeAll();
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.add(((Lobby)
															this).rd,
																"Loading your stages now, please wait...");
															((GameSparker)
															((Lobby) this).gs)
																.mstgs.select(0);
															((Lobby) this)
																.msload = 4;
														}
													} else {
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.removeAll();
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.add(((Lobby) this).rd,
															"You need to have a full account to access this.");
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.select(0);
														((CarDefine)
														((Lobby) this).cd)
															.msloaded = 0;
													}
													((Lobby) this).sgflag = 6;
												}
												i_163_ = (472 - ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getWidth() + 6 + ((GameSparker)
												(((Lobby) this)
													.gs))
													.mstgs.getWidth()) / 2));
											}
											if (!((GameSparker)
											((Lobby) this).gs)
												.sgame.isShowing()) {
												((GameSparker)
												((Lobby) this).gs)
													.sgame.show();
												((Lobby) this).remstage = 0;
												if (((Lobby) this).loadstage == 0) {
													int i_164_ = (int)(Math.random() * 3.0);
													if (i_164_ == 3) i_164_ = 2;
													((GameSparker)
													((Lobby) this).gs)
														.sgame.select(i_164_);
												}
											}
											((GameSparker)((Lobby) this).gs)
												.sgame.move(i_163_, 105);
											i_163_ += ((GameSparker)
											((Lobby) this).gs)
												.sgame.getWidth() + 6;
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 0) {
												if (!((GameSparker)
												((Lobby) this).gs)
													.snfmm.isShowing()) {
													((GameSparker)
													((Lobby) this).gs)
														.snfmm.show();
													if ((((Lobby) this)
														.loadstage) == 0)
													((GameSparker)
													((Lobby) this).gs)
														.snfmm.select(0);
												}
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.move(i_163_, 105);
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm1.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm2.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.mstgs.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.hide();
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 0) && ((GameSparker)
											((Lobby) this).gs)
												.snfmm.getSelectedIndex() != 0 && (((Lobby) this).gstage != (((GameSparker)
											((Lobby) this).gs)
												.snfmm.getSelectedIndex() + 27))) {
												((Lobby) this).loadstage = (((GameSparker)
												((Lobby) this).gs)
													.snfmm.getSelectedIndex() + 27);
												((Lobby) this).gstage = ((Lobby) this).loadstage;
												((Lobby) this).gs.requestFocus();
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 1) {
												if (!((GameSparker)
												((Lobby) this).gs)
													.snfm2.isShowing()) {
													((GameSparker)
													((Lobby) this).gs)
														.snfm2.show();
													if ((((Lobby) this)
														.loadstage) == 0)
													((GameSparker)
													((Lobby) this).gs)
														.snfm2.select(0);
												}
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.move(i_163_, 105);
												if (((GameSparker)
												((Lobby) this).gs)
													.snfmm.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm1.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.mstgs.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.hide();
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 1) && ((GameSparker)
											((Lobby) this).gs)
												.snfm2.getSelectedIndex() != 0 && (((Lobby) this).gstage != (((GameSparker)
											((Lobby) this).gs)
												.snfm2.getSelectedIndex() + 10))) {
												((Lobby) this).loadstage = (((GameSparker)
												((Lobby) this).gs)
													.snfm2.getSelectedIndex() + 10);
												((Lobby) this).gstage = ((Lobby) this).loadstage;
												((Lobby) this).gs.requestFocus();
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 2) {
												if (!((GameSparker)
												((Lobby) this).gs)
													.snfm1.isShowing()) {
													((GameSparker)
													((Lobby) this).gs)
														.snfm1.show();
													if ((((Lobby) this)
														.loadstage) == 0)
													((GameSparker)
													((Lobby) this).gs)
														.snfm1.select(0);
												}
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.move(i_163_, 105);
												if (((GameSparker)
												((Lobby) this).gs)
													.snfmm.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm2.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.mstgs.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.hide();
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 2) && ((GameSparker)
											((Lobby) this).gs)
												.snfm1.getSelectedIndex() != 0 && (((Lobby) this).gstage != (((GameSparker)
											((Lobby) this).gs)
												.snfm1.getSelectedIndex()))) {
												((Lobby) this).loadstage = ((GameSparker)
												((Lobby) this).gs)
													.snfm1.getSelectedIndex();
												((Lobby) this).gstage = ((Lobby) this).loadstage;
												((Lobby) this).gs.requestFocus();
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() == 3) {
												if (!((GameSparker)
												((Lobby) this).gs)
													.mstgs.isShowing()) {
													((GameSparker)
													((Lobby) this).gs)
														.mstgs.show();
													if ((((Lobby) this)
														.loadstage) == 0)
													((GameSparker)
													((Lobby) this).gs)
														.mstgs.select(0);
												}
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.move(i_163_, 105);
												if (((GameSparker)
												((Lobby) this).gs)
													.snfmm.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm1.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm2.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.hide();
											}
											if (((Lobby) this).remstage != 2) {
												if ((((GameSparker)
												((Lobby) this).gs)
													.sgame.getSelectedIndex() == 3) && (((GameSparker)
												((Lobby) this).gs)
													.mstgs.getSelectedIndex() != 0)) {
													if (((Lobby) this).gstage != (((GameSparker)
													((Lobby) this).gs)
														.mstgs.getSelectedIndex()) + 100) {
														((Lobby) this)
															.loadstage = (((GameSparker)
														(((Lobby) this)
															.gs))
															.mstgs.getSelectedIndex()) + 100;
														((Lobby) this).gstage = (((Lobby) this)
															.loadstage);
														((Lobby) this).gs.requestFocus();
														((Lobby) this).remstage = 0;
													}
													if ((((Lobby) this)
														.loadstage) <= 0 && (((Lobby) this)
														.remstage) == 0 && (((Lobby) this)
														.xt.drawcarb(true, null, "X",
													674, 136, i,
													i_99_, bool)))
													((Lobby) this).remstage = 1;
												} else if ((((Lobby) this)
													.remstage) != 0)
												((Lobby) this).remstage = 0;
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() >= 4) {
												if (!((GameSparker)
												((Lobby) this).gs)
													.mstgs.isShowing()) {
													((GameSparker)
													((Lobby) this).gs)
														.mstgs.show();
													if ((((Lobby) this)
														.loadstage) == 0)
													((GameSparker)
													((Lobby) this).gs)
														.mstgs.select(0);
												}
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.move(i_163_, 105);
												if (((GameSparker)
												((Lobby) this).gs)
													.snfmm.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm1.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.hide();
												if (((GameSparker)
												((Lobby) this).gs)
													.snfm2.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.hide();
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() >= 4) && ((GameSparker)
											((Lobby) this).gs)
												.mstgs.getSelectedIndex() != 0 && (((Lobby) this).gstage != (((GameSparker)
											((Lobby) this).gs)
												.mstgs.getSelectedIndex() + 100))) {
												((Lobby) this).loadstage = (((GameSparker)
												((Lobby) this).gs)
													.mstgs.getSelectedIndex() + 100);
												((Lobby) this).gstage = ((Lobby) this).loadstage;
												((Lobby) this).gs.requestFocus();
											}
											if (((Lobby) this).loadstage > 0 && (((Lobby) this).remstage == 0)) {
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.drawString("Loading stage, please wait...", (472 - ((((Lobby) this)
													.ftm.stringWidth("Loading Stage, please wait...")) / 2)),
												165);
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.sgame.getSelectedIndex() >= 3) && !(((xtGraphics)
											((Lobby) this).xt)
												.logged)) {
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.drawString("You are currently using a trial account.", (472 - ((((Lobby) this)
													.ftm.stringWidth("You are currently using a trial account.")) / 2)),
												155);
												((Lobby) this).rd.drawString("You need to upgrade your account to access and publish custom stages!", (472 - ((((Lobby) this)
													.ftm.stringWidth("You need to upgrade your account to access and publish custom stages!")) / 2)),
												175);
												((Lobby) this).rd.setColor(color2k(200, 200, 200));
												((Lobby) this).rd.fillRoundRect(382, 185, 180, 50, 20,
												20);
												drawSbutton(((xtGraphics)
												(((Lobby) this)
													.xt)).upgrade,
												472, 210);
												if (((GameSparker)
												((Lobby) this).gs)
													.slaps.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.slaps.hide();
											} else {
												if ((((Lobby) this).loadstage < 0) && (((Lobby) this).remstage == 0)) {
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													12));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this)
														.gstagename)
														.append("  -  Laps:              ")
														.toString(), (472 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("").append(((Lobby)
													this)
														.gstagename)
														.append("  -  Laps:              ")
														.toString())) / 2),
													155);
													if (!((GameSparker)
													((Lobby) this).gs)
														.slaps.isShowing()) {
														((GameSparker)
														((Lobby) this).gs)
															.slaps.show();
														((GameSparker)
														((Lobby) this).gs)
															.slaps.select((((Lobby) this)
															.gstagelaps) - 1);
													}
													((GameSparker)
													((Lobby) this).gs)
														.slaps.move((472 + (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("").append(((Lobby)
													this)
														.gstagename)
														.append("  -  Laps:              ")
														.toString())) / 2 - 35),
													138);
													if (((GameSparker)
													((Lobby) this).gs)
														.slaps.getSelectedIndex() != (((Lobby) this)
														.gstagelaps) - 1) {
														((Lobby) this)
															.gstagelaps = (((GameSparker)
														(((Lobby) this)
															.gs))
															.slaps.getSelectedIndex()) + 1;
														((Lobby) this).gs.requestFocus();
													}
													stringbutton("    Preview Stage    ",
													472, 185, 2);
												} else if (((GameSparker)
												((Lobby) this).gs)
													.slaps.isShowing())
												((GameSparker)
												((Lobby) this).gs)
													.slaps.hide();
												if (((Lobby) this).remstage == 3) {
													if ((((Lobby) this)
														.loadstage) < 0) stringbutton("    Preview Stage    ",
													472, -160, 2);
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													13));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).xt.drawlprom(135, 75);
													((Lobby) this).rd.drawString("Failed to remove stage, server error, please try again later.", (472 - ((((Lobby) this)
														.ftm.stringWidth("Failed to remove stage, server error, please try again later.")) / 2)),
													155);
													if (((Lobby) this).xt.drawcarb(true, null, " OK ",
													451, 175, i, i_99_,
													bool)) {
														((Lobby) this).remstage = 0;
														((GameSparker)
														((Lobby) this).gs)
															.mouses = 0;
													}
												}
												if (((Lobby) this).remstage == 2) {
													if ((((Lobby) this)
														.loadstage) < 0) stringbutton("    Preview Stage    ",
													472, -160, 2);
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													13));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).xt.drawlprom(135, 75);
													((Lobby) this).rd.drawString("Removing stage from your account...", (472 - ((((Lobby) this)
														.ftm.stringWidth("Removing stage from your account...")) / 2)),
													175);
													if ((((CarDefine)
													((Lobby) this).cd)
														.staction) == 0) {
														((Lobby) this).gstage = 0;
														((Lobby) this)
															.loadstage = 0;
														((Lobby) this).remstage = 0;
													}
													if ((((CarDefine)
													((Lobby) this).cd)
														.staction) == -1) {
														((Lobby) this).remstage = 3;
														((GameSparker)
														((Lobby) this).gs)
															.mouses = 0;
													}
												}
												if (((Lobby) this).remstage == 1) {
													if ((((Lobby) this)
														.loadstage) < 0) stringbutton("    Preview Stage    ",
													472, -160, 2);
													((Lobby) this).xt.drawlprom(135, 75);
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													13));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString("Remove this stage from your account?", (472 - ((((Lobby) this)
														.ftm.stringWidth("Remove this stage from your account?")) / 2)),
													155);
													if (((Lobby) this).xt.drawcarb(true, null, " Yes ",
													426, 175, i, i_99_,
													bool)) {
														((Lobby) this).remstage = 2;
														((CarDefine)
														((Lobby) this).cd)
															.onstage = (((GameSparker)
														(((Lobby) this)
															.gs))
															.mstgs.getSelectedItem());
														((CarDefine)
														((Lobby) this).cd)
															.staction = 1;
														((Lobby) this).cd.sparkstageaction();
														((GameSparker)
														((Lobby) this).gs)
															.mouses = 0;
													}
													if (((Lobby) this).xt.drawcarb(true, null, " No ",
													480, 175, i, i_99_,
													bool)) {
														((Lobby) this).remstage = 0;
														((GameSparker)
														((Lobby) this).gs)
															.mouses = 0;
													}
												}
												stringbutton("   Next >   ",
												472, 235, 1);
											}
										} else {
											if (!((Lobby) this).inwab) {
												((GameSparker)
												((Lobby) this).gs)
													.sgame.hide();
												((GameSparker)
												((Lobby) this).gs)
													.mstgs.hide();
												((GameSparker)
												((Lobby) this).gs)
													.slaps.hide();
												((GameSparker)
												((Lobby) this).gs)
													.snfm1.hide();
												((GameSparker)
												((Lobby) this).gs)
													.snfmm.hide();
												((GameSparker)
												((Lobby) this).gs)
													.snfm2.hide();
											}
											if (!((xtGraphics)
											((Lobby) this).xt)
												.clan.equals("")) {
												if (!((Lobby) this).inwab) {
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													12));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString("Loading your clan's wars and battles, please wait...", (472 - ((((Lobby) this)
														.ftm.stringWidth("Loading your clan's wars and battles, please wait...")) / 2)),
													155);
													((Lobby) this).loadwarb = true;
													((Lobby) this).warbsel = 0;
													((Lobby) this).cancreate = 0;
												} else {
													if (!((GameSparker)
													((Lobby) this).gs)
														.warb.isShowing())
													((GameSparker)
													((Lobby) this).gs)
														.warb.show();
													((GameSparker)
													((Lobby) this).gs)
														.warb.move(472 - ((Smenu)
													(((GameSparker)
													((Lobby)
													this).gs)
														.warb)).w / 2,
													105);
													if (((Smenu)
													(((GameSparker)
													((Lobby) this).gs)
														.warb)).sel != 0) {
														if (((Smenu)
														((GameSparker)
														(((Lobby) this)
															.gs)).warb).sel != (((Lobby) this)
															.warbsel)) {
															((Globe)
															((Lobby) this).gb)
																.loadwbgames = 1;
															((Lobby) this)
																.rd.setColor(new Color(0,
															0,
															0));
															((Lobby) this)
																.rd.setFont(new Font("Arial", 1,
															12));
															((Lobby) this).ftm = (((Lobby)
															this)
																.rd.getFontMetrics());
															((Lobby) this)
																.rd.drawString("Loading scheduled games, please wait...", (472 - ((((Lobby)
															this)
																.ftm.stringWidth("Loading scheduled games, please wait...")) / 2)),
															165);
															((Lobby) this)
																.warbsel = ((Smenu)
															(((GameSparker)
															((Lobby)
															this).gs)
																.warb)).sel;
															((Smenu)
															((GameSparker)
															(((Lobby) this)
																.gs)).vnpls).sel = 0;
															((Smenu)
															((GameSparker)
															(((Lobby) this)
																.gs)).vtyp).sel = 0;
															((Lobby) this)
																.pgamesel = 0;
															((Lobby) this)
																.cancreate = 0;
														} else {
															if ((((Globe)
															((Lobby)
															this).gb)
																.loadwbgames) == 7) {
																((Lobby) this)
																	.rd.setColor(new Color(0, 0,
																0));
																((Lobby) this)
																	.rd.setFont(new Font("Arial",
																1, 12));
																((Lobby) this)
																	.ftm = (((Lobby)
																this)
																	.rd.getFontMetrics());
																((Lobby) this)
																	.rd.drawString("Redoing last game, please wait...", (472 - (((Lobby)
																this)
																	.ftm.stringWidth("Redoing last game, please wait...") / 2)),
																155);
															}
															if ((((Globe)
															((Lobby)
															this).gb)
																.loadwbgames) == 2) {
																((Lobby) this)
																	.rd.setColor(new Color(0, 0,
																0));
																((Lobby) this)
																	.rd.setFont(new Font("Arial",
																1, 12));
																((Lobby) this)
																	.ftm = (((Lobby)
																this)
																	.rd.getFontMetrics());
																if (((GameSparker)
																((Lobby)
																this).gs)
																	.wgame.getSelectedIndex() == 1) {
																	((Lobby)
																	this)
																		.rd.drawString(new StringBuilder()
																		.append("[ ")
																		.append(((Globe)
																	((Lobby) this).gb)
																		.gameturndisp)
																		.append(" ]")
																		.toString(), (472 - ((Lobby)
																	this).ftm.stringWidth(new StringBuilder().append("[ ").append(((Globe)((Lobby) this).gb).gameturndisp).append(" ]").toString()) / 2),
																	155);
																	bool_162_ = true;
																	int i_165_ = (472 - (((Smenu)
																	((GameSparker)((Lobby) this).gs).vnpls).w + ((Smenu)((GameSparker)((Lobby) this).gs).vtyp).w + 10) / 2);
																	((GameSparker)
																	((Lobby)
																	this).gs)
																		.vnpls.move(i_165_,
																	168);
																	i_165_ += ((Smenu)
																	((GameSparker)
																	((Lobby)
																	this).gs).vnpls).w + 10;
																	((GameSparker)
																	((Lobby)
																	this).gs)
																		.vtyp.move(i_165_,
																	168);
																	if (!((Globe)
																	(((Lobby)
																	this)
																		.gb))
																		.lwbwinner.toLowerCase()
																		.equals(((xtGraphics)
																	((Lobby)
																	this).xt)
																		.clan.toLowerCase())) {
																		if (((Smenu)
																		((GameSparker)
																		((Lobby)
																		this).gs).vnpls).sel != 0) {
																			if (((Lobby) this).pgamesel != -((Smenu)((GameSparker)((Lobby) this).gs).vnpls).sel) {
																				((Lobby) this).gstagename = ((Globe)((Lobby) this).gb).wbstages[((Globe)((Lobby) this).gb).gameturn];
																				((Lobby) this).cancreate = 0;
																				((Lobby) this).pgamesel = -((Smenu)((GameSparker)((Lobby) this).gs).vnpls).sel;
																			}
																			if (((Lobby) this).cancreate == 1)
																			((Lobby) this).cancreate = 2;
																			if (((Lobby) this).cancreate == 0) {
																				if (((Globe)((Lobby) this).gb).wbstage[((Globe)((Lobby) this).gb).gameturn] == 101)
																				((Lobby) this).cancreate = 2;
																				else {
																					((Lobby) this).loadstage = ((Globe)((Lobby) this).gb).wbstage[((Globe)((Lobby) this).gb).gameturn];
																					((Lobby) this).cancreate = 1;
																				}
																			}
																			if (((Lobby) this).cancreate == 1)
																			((Lobby) this).rd.drawString("Loading...", 472 - ((Lobby) this).ftm.stringWidth("Loading...") / 2, 235);
																			if (((Lobby) this).cancreate == 2) stringbutton("   Create Game   ", 472, 235, 1);
																		}
																	} else {
																		if (((Lobby)
																		this).sflk != 0)
																		((Lobby)
																		this).sflk--;
																		else {
																			((Lobby)
																			this).sflk = 4;
																			((Lobby)
																			this).rd.setColor(new Color(117, 67, 0));
																		}
																		((Lobby)
																		this)
																			.rd.drawString(new StringBuilder().append("Your clan won the last game.  ").append(((Globe)((Lobby) this).gb).vclan).append(" must create this game!").toString(),
																		472 - ((Lobby) this).ftm.stringWidth(new StringBuilder().append("Your clan won the last game.  ").append(((Globe)((Lobby) this).gb).vclan).append(" must create this game!").toString()) / 2,
																		211);
																	}
																	if (((Globe)
																	(((Lobby)
																	this)
																		.gb))
																		.canredo) stringbutton(" Redo last game  < ",
																	644,
																	242,
																	1);
																}
																if (((GameSparker)
																((Lobby)
																this).gs)
																	.wgame.getSelectedIndex() == 2) {
																	bool_161_ = true;
																	((GameSparker)
																	((Lobby)
																	this).gs)
																		.pgame.move((472 - ((Smenu)
																	((GameSparker)
																	((Lobby)
																	this).gs).pgame).w / 2),
																	150);
																	if (((Smenu)
																	(((GameSparker)
																	((Lobby)
																	this).gs)
																		.pgame)).sel != 0) {
																		if (((Lobby)
																		this).pgamesel != ((Smenu)((GameSparker)((Lobby) this).gs).pgame).sel) {
																			((Lobby)
																			this).gstagename = ((Globe)((Lobby) this).gb).wbstages[((Smenu)((GameSparker)((Lobby) this).gs).pgame).sel - 1];
																			((Lobby)
																			this).cancreate = 0;
																			((Lobby)
																			this).pgamesel = ((Smenu)((GameSparker)((Lobby) this).gs).pgame).sel;
																		}
																		if (((Lobby)
																		this).cancreate == 1)
																		((Lobby)
																		this).cancreate = 2;
																		if (((Lobby)
																		this).cancreate == 0) {
																			if (((Globe)((Lobby) this).gb).wbstage[((Smenu)((GameSparker)((Lobby) this).gs).pgame).sel - 1] == 101)
																			((Lobby) this).cancreate = 2;
																			else {
																				((Lobby) this).loadstage = ((Globe)((Lobby) this).gb).wbstage[((Smenu)((GameSparker)((Lobby) this).gs).pgame).sel - 1];
																				((Lobby) this).cancreate = 1;
																			}
																		}
																		if (((Lobby)
																		this).cancreate == 1)
																		((Lobby)
																		this).rd.drawString("Loading...", 472 - ((Lobby) this).ftm.stringWidth("Loading...") / 2, 235);
																		if (((Lobby)
																		this).cancreate == 2) stringbutton("   Create Practice Game   ", 472, 235, 1);
																	}
																}
															}
															if ((((Globe)
															((Lobby)
															this).gb)
																.loadwbgames) == 3)
															((Lobby) this)
																.rd.drawString("Failed to load scheduled games, please try again later...", (472 - (((Lobby)
															this)
																.ftm.stringWidth("Failed to load scheduled games, please try again later...") / 2)),
															165);
															if ((((Globe)
															((Lobby)
															this).gb)
																.loadwbgames) == 4)
															((Lobby) this)
																.rd.drawString("This war or battle was not found, it may have been expired.", (472 - (((Lobby)
															this)
																.ftm.stringWidth("This war or battle was not found, it may have been expired.") / 2)),
															165);
															if ((((Globe)
															((Lobby)
															this).gb)
																.loadwbgames) == 6)
															((Lobby) this)
																.rd.drawString("Failed to undo the last game, please try again later...", (472 - (((Lobby)
															this)
																.ftm.stringWidth("Failed to undo the last game, please try again later...") / 2)),
															165);
														}
													}
												}
											} else {
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.drawString("You must join a clan first to play wars and battles!", (472 - ((((Lobby) this)
													.ftm.stringWidth("You must join a clan first to play wars and battles!")) / 2)),
												145);
												stringbutton("    Find a clan to join    ",
												472, 185, 2);
											}
											if (!((Lobby) this).inwab)
											((Lobby) this).inwab = true;
										}
										if (bool_161_)
										((GameSparker)((Lobby) this).gs)
											.pgame.show();
										else((GameSparker)((Lobby) this).gs)
											.pgame.hide();
										if (bool_162_) {
											((GameSparker)((Lobby) this).gs)
												.vnpls.show();
											((GameSparker)((Lobby) this).gs)
												.vtyp.show();
										} else {
											((GameSparker)((Lobby) this).gs)
												.vnpls.hide();
											((GameSparker)((Lobby) this).gs)
												.vtyp.hide();
										}
									}
									if (((Lobby) this).chalngd == -3) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if (((Lobby) this).sflk % 4 != 0 || ((Lobby) this).sflk == 0)
										((Lobby) this).rd.drawString("Select Number of Players", (472 - ((((Lobby) this).ftm.stringWidth("Select Number of Players")) / 2)),
										85);
										if (((Lobby) this).sflk != 0)
										((Lobby) this).sflk--;
										int i_166_ = 0;
										if (((xtGraphics)((Lobby) this).xt)
											.lan) i_166_ = 59;
										((Lobby) this).rd.drawString("Players", 413 - i_166_, 122);
										if (!((GameSparker)((Lobby) this).gs)
											.snpls.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.snpls.show();
											((GameSparker)((Lobby) this).gs)
												.snpls.select(((Lobby) this).gnpls - 1);
										}
										((GameSparker)((Lobby) this).gs)
											.snpls.move(467 - i_166_, 105);
										boolean bool_167_ = false;
										if (((GameSparker)((Lobby) this).gs)
											.snpls.getSelectedIndex() != 0 && (((GameSparker)
										((Lobby) this).gs)
											.snpls.getSelectedIndex() != ((Lobby) this).gnpls - 1)) {
											((Lobby) this).gnpls = ((GameSparker)
											((Lobby) this).gs)
												.snpls.getSelectedIndex() + 1;
											bool_167_ = true;
											((GameSparker)((Lobby) this).gs)
												.swait.hide();
										}
										if (((xtGraphics)((Lobby) this).xt)
											.lan) {
											((Lobby) this).rd.drawString("Bots", 490, 122);
											if (!((GameSparker)
											((Lobby) this).gs)
												.snbts.isShowing()) {
												((GameSparker)
												((Lobby) this).gs)
													.snbts.show();
												((GameSparker)
												((Lobby) this).gs)
													.snbts.select(0);
												((Lobby) this).gnbts = 0;
											}
											((GameSparker)((Lobby) this).gs)
												.snbts.move(524, 105);
											if ((((GameSparker)
											((Lobby) this).gs)
												.snbts.getSelectedIndex() != ((Lobby) this).gnbts) || bool_167_) {
												for (((Lobby) this).gnbts = (((GameSparker)
												((Lobby) this).gs)
													.snbts.getSelectedIndex());
												((((Lobby) this).gnbts + ((Lobby) this).gnpls) > 8);
												((Lobby) this).gnbts--) {
													/* empty */
												}
												((GameSparker)
												((Lobby) this).gs)
													.snbts.select(((Lobby) this).gnbts);
											}
										}
										((Lobby) this).rd.drawString("Wait",
										414, 162);
										if (!((GameSparker)((Lobby) this).gs)
											.swait.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.swait.show();
											if (((Lobby) this).gwait == 0)
											((GameSparker)
											((Lobby) this).gs)
												.swait.select(1);
										}
										((GameSparker)((Lobby) this).gs)
											.swait.move(451, 145);
										if ((((GameSparker)((Lobby) this).gs)
											.swait.getSelectedIndex() + 1) * 60 != ((Lobby) this).gwait)
										((Lobby) this).gwait = (((GameSparker)
										((Lobby) this).gs)
											.swait.getSelectedIndex() + 1) * 60;
										((Lobby) this).rd.setColor(color2k(90, 90, 90));
										((Lobby) this).rd.setFont(new Font("Arial", 0, 11));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("( Maximum time to wait for all players to `join. )", (472 - ((((Lobby) this).ftm.stringWidth("( Maximum time to wait for all players to join. )")) / 2)),
										179);
										stringbutton("   < Back   ", 422, 235,
										1);
										stringbutton("   Next >   ", 522, 235,
										1);
									}
									if (((Lobby) this).chalngd == -4) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if (((Lobby) this).sflk % 4 != 0 || ((Lobby) this).sflk == 0)
										((Lobby) this).rd.drawString("Game Options",
										472 - (((Lobby) this).ftm.stringWidth("Game Options")) / 2,
										85);
										if (((Lobby) this).sflk != 0)
										((Lobby) this).sflk--;
										int i_168_ = 472 - (((GameSparker)
										((Lobby) this).gs)
											.scars.getWidth() + ((GameSparker)
										((Lobby) this).gs)
											.sclass.getWidth() + ((GameSparker)
										((Lobby) this).gs)
											.sfix.getWidth() + 16) / 2;
										if (!((GameSparker)((Lobby) this).gs)
											.scars.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.scars.show();
											if (((Lobby) this).gcars >= 0 && ((Lobby) this).gcars <= 2)
											((GameSparker)
											((Lobby) this).gs)
												.scars.select(((Lobby) this).gcars);
											else((GameSparker)
											((Lobby) this).gs)
												.scars.select(0);
										}
										((GameSparker)((Lobby) this).gs)
											.scars.move(i_168_, 105);
										i_168_ += ((GameSparker)
										((Lobby) this).gs)
											.scars.getWidth() + 8;
										if (!((GameSparker)((Lobby) this).gs)
											.sclass.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.sclass.show();
											if (((Lobby) this).gclass >= 0 && ((Lobby) this).gclass <= 5)
											((GameSparker)
											((Lobby) this).gs)
												.sclass.select(((Lobby) this).gclass);
											else((GameSparker)
											((Lobby) this).gs)
												.sclass.select(0);
										}
										((GameSparker)((Lobby) this).gs)
											.sclass.move(i_168_, 105);
										i_168_ += ((GameSparker)
										((Lobby) this).gs)
											.sclass.getWidth() + 8;
										if (!((GameSparker)((Lobby) this).gs)
											.sfix.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.sfix.show();
											if (((Lobby) this).gfix >= 0 && ((Lobby) this).gfix <= 5)
											((GameSparker)
											((Lobby) this).gs)
												.sfix.select(((Lobby) this).gfix);
											else((GameSparker)
											((Lobby) this).gs)
												.sfix.select(0);
										}
										((GameSparker)((Lobby) this).gs)
											.sfix.move(i_168_, 105);
										i_168_ += ((GameSparker)
										((Lobby) this).gs)
											.sfix.getWidth();
										if (!((GameSparker)((Lobby) this).gs)
											.openm)
										((Lobby) this).gs.movefield(((GameSparker)
										((Lobby) this).gs).notp,
										i_168_ - 112, 131, 150, 17);
										else((Lobby) this).gs.movefield(((GameSparker)
										((Lobby) this).gs).notp,
										i_168_ - 112, -2000, 150, 17);
										if (!((GameSparker)((Lobby) this).gs)
											.notp.isShowing()) {
											((GameSparker)((Lobby) this).gs)
												.notp.show();
											if (((Lobby) this).gnotp == 0)
											((GameSparker)
											((Lobby) this).gs)
												.notp.setState(false);
											else((GameSparker)
											((Lobby) this).gs)
												.notp.setState(true);
										}
										if ((((xtGraphics)((Lobby) this).xt)
											.sc[0]) < 16) {
											if (!((GameSparker)
											((Lobby) this).gs).openm)
											((Lobby) this).gs.movefield(((GameSparker)
											((Lobby) this).gs).mycar, (472 - (((GameSparker)
											((Lobby) this).gs)
												.scars.getWidth() + ((GameSparker)
											((Lobby) this).gs)
												.sclass.getWidth() + ((GameSparker)
											((Lobby) this).gs)
												.sfix.getWidth() + 16) / 2),
											131, 150, 17);
											else((Lobby) this).gs.movefield(((GameSparker)
											((Lobby) this).gs).mycar,
											410, -2000, 150, 17);
											if (!((GameSparker)
											((Lobby) this).gs)
												.mycar.isShowing()) {
												((GameSparker)
												((Lobby) this).gs)
													.mycar.show();
												((GameSparker)
												((Lobby) this).gs)
													.mycar.setLabel(new StringBuilder().append("").append(((CarDefine)
												((Lobby) this).cd)
													.names[(((xtGraphics)
												((Lobby) this).xt)
													.sc[0])])
													.append(" Game!")
													.toString());
												if (((Lobby) this).gclass <= -2)
												((GameSparker)
												((Lobby) this).gs)
													.mycar.setState(true);
												else((GameSparker)
												((Lobby) this).gs)
													.mycar.setState(false);
											}
										} else if (((GameSparker)
										((Lobby) this).gs)
											.mycar.getState())
										((GameSparker)((Lobby) this).gs)
											.mycar.setState(false);
										if (((GameSparker)((Lobby) this).gs)
											.mycar.getState()) {
											if (((GameSparker)
											((Lobby) this).gs)
												.sclass.isEnabled())
											((GameSparker)
											((Lobby) this).gs)
												.sclass.disable();
											if (((GameSparker)
											((Lobby) this).gs)
												.scars.isEnabled())
											((GameSparker)
											((Lobby) this).gs)
												.scars.disable();
										} else {
											if (!((GameSparker)
											((Lobby) this).gs)
												.sclass.isEnabled())
											((GameSparker)
											((Lobby) this).gs)
												.sclass.enable();
											if (!((GameSparker)
											((Lobby) this).gs)
												.scars.isEnabled())
											((GameSparker)
											((Lobby) this).gs)
												.scars.enable();
											if (((GameSparker)
											((Lobby) this).gs)
												.sclass.getSelectedIndex() != ((Lobby) this).gclass) {
												((Lobby) this).gclass = ((GameSparker)
												((Lobby) this).gs)
													.sclass.getSelectedIndex();
												((GameSparker)
												((Lobby) this).gs)
													.mycar.hide();
											}
											if (((GameSparker)
											((Lobby) this).gs)
												.scars.getSelectedIndex() != ((Lobby) this).gcars)
											((Lobby) this).gcars = ((GameSparker)
											((Lobby) this).gs)
												.scars.getSelectedIndex();
										}
										if (((GameSparker)((Lobby) this).gs)
											.sfix.getSelectedIndex() != ((Lobby) this).gfix)
										((Lobby) this).gfix = ((GameSparker)
										((Lobby) this).gs)
											.sfix.getSelectedIndex();
										String string = "Public Game, anyone can join...";
										int i_169_ = 0;
										for (int i_170_ = 0; i_170_ < 7;
										i_170_++) {
											if (!((Lobby) this).invos[i_170_].equals("")) i_169_++;
										}
										if (i_169_ > 0) {
											string = "Players Allowed:  ";
											int i_171_ = 0;
											for (int i_172_ = 0; i_172_ < 7;
											i_172_++) {
												if (!((Lobby) this).invos[i_172_].equals("")) {
													string = new StringBuilder().append(string).append(((Lobby) this)
														.invos[i_172_])
														.toString();
													if (++i_171_ != i_169_) {
														if (i_171_ == i_169_ - 1) string = new StringBuilder().append(string)
															.append(" and ")
															.toString();
														else string = (new StringBuilder()
															.append(string)
															.append(", ")
															.toString());
													}
												}
											}
										}
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										if (i_169_ < ((Lobby) this).gnpls - 1) {
											((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
											((Lobby) this).rd.drawString(new StringBuilder().append("Private Game, only specific players allowed to join?  ")
												.append(i_169_).append("/").append(((Lobby) this).gnpls - 1)
												.append("").toString(),
											330, 180);
											stringbutton("<   Select   ", 281,
											180, 2);
											((Lobby) this).rd.setFont(new Font("Tahoma", 0, 11));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											((Lobby) this).rd.drawString(string, (472 - (((Lobby) this).ftm.stringWidth(string) / 2)),
											203);
										} else {
											((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(i_169_).append(" Allowed Players Selected")
												.toString(), (472 - (((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("").append(i_169_).append(" Allowed Players Selected")
												.toString())) / 2),
											180);
											((Lobby) this).rd.setFont(new Font("Tahoma", 0, 11));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											((Lobby) this).rd.drawString(string, (472 - (((Lobby) this).ftm.stringWidth(string) / 2)),
											203);
										}
										stringbutton("   < Back   ", 422, 235,
										1);
										stringbutton("   Finish!   ", 522, 235,
										1);
									}
									if (((Lobby) this).chalngd == -5) {
										if (((Lobby) this).fstart)
										((Lobby) this).fstart = false;
										((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString(((Lobby) this).msg,
										472 - (((Lobby) this).ftm.stringWidth(((Lobby) this).msg)) / 2,
										145);
										if ((((Lobby) this).msg.equals(". . . | Creating Game | . . .")) && ((Lobby) this).ncnt == 0) {
											((Lobby) this).msg = "| Creating Game |";
											((Lobby) this).ncnt = 5;
										}
										if ((((Lobby) this).msg.equals(". . | Creating Game | . .")) && ((Lobby) this).ncnt == 0) {
											((Lobby) this).msg = ". . . | Creating Game | . . .";
											((Lobby) this).ncnt = 5;
										}
										if ((((Lobby) this).msg.equals(". | Creating Game | .")) && ((Lobby) this).ncnt == 0) {
											((Lobby) this).msg = ". . | Creating Game | . .";
											((Lobby) this).ncnt = 5;
										}
										if (((Lobby) this).msg.equals("| Creating Game |") && ((Lobby) this).ncnt == 0) {
											((Lobby) this).msg = ". | Creating Game | .";
											((Lobby) this).ncnt = 5;
										}
										if (((Lobby) this).ncnt != 0)
										((Lobby) this).ncnt--;
									}
								}
							}
							if (!((xtGraphics)((Lobby) this).xt).lan) {
								((Lobby) this).rd.setColor(color2k(230, 230,
								230));
								((Lobby) this).rd.fillRoundRect(225, 263, 495,
								157, 20, 20);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.drawRoundRect(225, 263, 495,
								157, 20, 20);
								String[] strings = new String[14];
								String[] strings_173_ = new String[14];
								boolean[] bools = new boolean[14];
								for (int i_174_ = 0; i_174_ < 14; i_174_++) {
									strings[i_174_] = "";
									strings_173_[i_174_] = "";
									bools[i_174_] = false;
								}
								int i_175_ = 0;
								((Lobby) this).rd.setFont(new Font("Tahoma", 0,
								11));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								if (((Lobby) this).updatec != -1) {
									for (int i_176_ = 0; i_176_ < 7;
									i_176_++) {
										strings[i_175_] = "";
										strings_173_[i_175_] = ((Lobby) this).cnames[i_176_];
										int i_177_ = 0;
										int i_178_ = 0;
										int i_179_ = 0;
										int i_180_ = 0;
										int i_181_ = 0;
										for ( /**/ ;
										i_177_ < ((Lobby) this).sentn[i_176_].length();
										i_177_++) {
											String string = new StringBuilder().append("").append(((Lobby) this).sentn[i_176_].charAt(i_177_))
												.toString();
											if (string.equals(" ")) {
												i_178_ = i_179_;
												i_180_ = i_177_;
												i_181_++;
											} else i_181_ = 0;
											if (i_181_ <= 1) {
												StringBuilder stringbuilder = new StringBuilder();
												String[] strings_182_ = strings;
												int i_183_ = i_175_;
												strings_182_[i_183_] = stringbuilder.append(strings_182_[i_183_])
													.append(string).toString();
												i_179_++;
												if ((((Lobby) this).ftm.stringWidth(strings[i_175_])) > 367) {
													if (i_178_ != 0) {
														strings[i_175_] = (strings[i_175_].substring(0, i_178_));
														if (i_175_ == 13) {
															for (int i_184_ = 0;
															i_184_ < 13;
															i_184_++) {
																strings[i_184_] = (strings[(i_184_ + 1)]);
																strings_173_[i_184_] = (strings_173_[(i_184_ + 1)]);
																bools[i_184_] = (bools[(i_184_ + 1)]);
															}
															strings[i_175_] = "";
															bools[i_175_] = true;
														} else {
															i_175_++;
															strings_173_[i_175_] = (((Lobby)
															this)
																.cnames[i_176_]);
														}
														i_177_ = i_180_;
														i_179_ = 0;
														i_178_ = 0;
													} else {
														strings[i_175_] = "";
														i_179_ = 0;
													}
												}
											}
										}
										if (i_175_ == 13 && i_176_ != 6) {
											for (int i_185_ = 0; i_185_ < 13;
											i_185_++) {
												strings[i_185_] = strings[i_185_ + 1];
												strings_173_[i_185_] = strings_173_[i_185_ + 1];
												bools[i_185_] = bools[i_185_ + 1];
											}
										} else i_175_++;
									}
									i_104_ = (i_175_ - 6) * 15;
									if (i_104_ < 0) i_104_ = 0;
									i_105_ = (int)((float)((Lobby) this).spos3 / 28.0F * (float) i_104_);
									String string = "";
									((Lobby) this).rd.setFont(new Font("Tahoma", 1, 11));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									for (int i_186_ = 0; i_186_ < i_175_;
									i_186_++) {
										if (!string.equals(strings_173_[i_186_])) {
											if ((280 + i_186_ * 15 - i_105_ > 266) && (280 + i_186_ * 15 - i_105_ < 370))
											((Lobby) this).rd.drawString(new StringBuilder().append(strings_173_[i_186_])
												.append(":").toString(),
											320 - (((Lobby) this)
												.ftm.stringWidth(new StringBuilder().append(strings_173_[i_186_])
												.append(":")
												.toString())), (305 + i_186_ * 15 - i_105_));
											string = strings_173_[i_186_];
										}
									}
									((Lobby) this).rd.setFont(new Font("Tahoma", 0, 11));
									for (int i_187_ = 0; i_187_ < i_175_;
									i_187_++) {
										if (bools[i_187_] && i_187_ == 0 && (strings[i_187_].indexOf(" ") != -1)) strings[i_187_] = new StringBuilder().append("...").append(strings[i_187_].substring(strings[i_187_].indexOf(" "),
										strings[i_187_].length()))
											.append("").toString();
										if (280 + i_187_ * 15 - i_105_ > 266 && (280 + i_187_ * 15 - i_105_ < 370))
										((Lobby) this).rd.drawString(strings[i_187_], 325,
										305 + i_187_ * 15 - i_105_);
									}
								} else {
									i_104_ = 0;
									boolean bool_188_ = false;
									((Lobby) this).rd.drawString("Loading chat...",
									465 - (((Lobby) this).ftm.stringWidth("Loading chat...")) / 2,
									325);
								}
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(235, 269, 480, 25);
								((Lobby) this).rd.drawImage(((xtGraphics)
								(((Lobby) this)
									.xt)).chat,
								241, 273, null);
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								12));
								((Lobby) this).rd.setColor(color2k(120, 120,
								120));
								((Lobby) this).rd.drawString("( Room Chat )",
								299, 285);
								((Lobby) this).rd.setColor(color2k(150, 150,
								150));
								((Lobby) this).rd.drawLine(235, 291, 696, 291);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(235, 387, 480, 28);
								((Lobby) this).rd.setColor(color2k(150, 150,
								150));
								((Lobby) this).rd.drawLine(235, 389, 696, 389);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(698, 311, 17, 59);
								((Lobby) this).rd.setColor(color2k(205, 205,
								205));
								((Lobby) this).rd.fillRect(231, 269, 4, 146);
								if (((Lobby) this).mscro3 == 351 || i_104_ == 0) {
									if (i_104_ == 0)
									((Lobby) this).rd.setColor(color2k(205, 205, 205));
									else((Lobby) this).rd.setColor(color2k(215, 215, 215));
									((Lobby) this).rd.fillRect(698, 294, 17,
									17);
								} else {
									((Lobby) this).rd.setColor(color2k(220, 220, 220));
									((Lobby) this).rd.fill3DRect(698, 294, 17,
									17, true);
								}
								if (i_104_ != 0)
								((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).asu,
								703, 300, null);
								if (((Lobby) this).mscro3 == 352 || i_104_ == 0) {
									if (i_104_ == 0)
									((Lobby) this).rd.setColor(color2k(205, 205, 205));
									else((Lobby) this).rd.setColor(color2k(215, 215, 215));
									((Lobby) this).rd.fillRect(698, 370, 17,
									17);
								} else {
									((Lobby) this).rd.setColor(color2k(220, 220, 220));
									((Lobby) this).rd.fill3DRect(698, 370, 17,
									17, true);
								}
								if (i_104_ != 0)
								((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).asd,
								703, 376, null);
								if (i_104_ != 0) {
									if (((Lobby) this).lspos3 != ((Lobby) this).spos3) {
										((Lobby) this).rd.setColor(color2k(215, 215, 215));
										((Lobby) this).rd.fillRect(698, 311 + ((Lobby) this).spos3,
										17, 31);
									} else {
										if (((Lobby) this).mscro3 == 141)
										((Lobby) this).rd.setColor(color2k(215, 215, 215));
										((Lobby) this).rd.fill3DRect(698, 311 + ((Lobby) this).spos3,
										17, 31, true);
									}
									((Lobby) this).rd.setColor(color2k(150, 150, 150));
									((Lobby) this).rd.drawLine(703, 324 + ((Lobby) this).spos3, 709,
									324 + ((Lobby) this).spos3);
									((Lobby) this).rd.drawLine(703, 326 + ((Lobby) this).spos3, 709,
									326 + ((Lobby) this).spos3);
									((Lobby) this).rd.drawLine(703, 328 + ((Lobby) this).spos3, 709,
									328 + ((Lobby) this).spos3);
									if (((Lobby) this).mscro3 > 342 && (((Lobby) this).lspos3 != ((Lobby) this).spos3))
									((Lobby) this).lspos3 = ((Lobby) this).spos3;
									if (bool) {
										if (((Lobby) this).mscro3 == 345 && i > 698 && i < 715 && (i_99_ > 311 + ((Lobby) this).spos3) && (i_99_ < ((Lobby) this).spos3 + 342))
										((Lobby) this).mscro3 = i_99_ - ((Lobby) this).spos3;
										if (((Lobby) this).mscro3 == 345 && i > 696 && i < 717 && i_99_ > 292 && i_99_ < 313)
										((Lobby) this).mscro3 = 351;
										if (((Lobby) this).mscro3 == 345 && i > 696 && i < 717 && i_99_ > 368 && i_99_ < 389)
										((Lobby) this).mscro3 = 352;
										if (((Lobby) this).mscro3 == 345 && i > 698 && i < 715 && i_99_ > 311 && i_99_ < 370) {
											((Lobby) this).mscro3 = 326;
											((Lobby) this).spos3 = (i_99_ - ((Lobby) this).mscro3);
										}
										int i_189_ = 100 / i_104_;
										if (i_189_ < 1) i_189_ = 1;
										if (((Lobby) this).mscro3 == 351) {
											((Lobby) this).spos3 -= i_189_;
											if (((Lobby) this).spos3 > 28)
											((Lobby) this).spos3 = 28;
											if (((Lobby) this).spos3 < 0)
											((Lobby) this).spos3 = 0;
											((Lobby) this).lspos3 = ((Lobby) this).spos3;
										}
										if (((Lobby) this).mscro3 == 352) {
											((Lobby) this).spos3 += i_189_;
											if (((Lobby) this).spos3 > 28)
											((Lobby) this).spos3 = 28;
											if (((Lobby) this).spos3 < 0)
											((Lobby) this).spos3 = 0;
											((Lobby) this).lspos3 = ((Lobby) this).spos3;
										}
										if (((Lobby) this).mscro3 <= 342) {
											((Lobby) this).spos3 = (i_99_ - ((Lobby) this).mscro3);
											if (((Lobby) this).spos3 > 28)
											((Lobby) this).spos3 = 28;
											if (((Lobby) this).spos3 < 0)
											((Lobby) this).spos3 = 0;
										}
										if (((Lobby) this).mscro3 == 345)
										((Lobby) this).mscro3 = 425;
									} else if (((Lobby) this).mscro3 != 345)
									((Lobby) this).mscro3 = 345;
									if (i_100_ != 0 && i > 235 && i < 698 && i_99_ > 291 && i_99_ < 389) {
										((Lobby) this).spos3 -= i_100_ / 2;
										((Lobby) this).zeromsw = true;
										if (((Lobby) this).spos3 > 28) {
											((Lobby) this).spos3 = 28;
											((Lobby) this).zeromsw = false;
										}
										if (((Lobby) this).spos3 < 0) {
											((Lobby) this).spos3 = 0;
											((Lobby) this).zeromsw = false;
										}
										((Lobby) this).lspos3 = ((Lobby) this).spos3;
									}
								}
								((Lobby) this).pre1 = true;
								stringbutton("Send Message", 657, 406, 3);
							}
							if ((((Lobby) this).chalngd == -1 || ((Lobby) this).chalngd == -6) && ((Login)((Lobby) this).lg).gamec != -1) {
								if (((Login)((Lobby) this).lg).cntgame >= 0 && (((Login)((Lobby) this).lg).cntgame < 10))
								((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, (float)(((Login)((Lobby) this).lg)
									.cntgame) / 10.0F));
								if (((Login)((Lobby) this).lg).cntgame > 390 && (((Login)((Lobby) this).lg).cntgame < 400))
								((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, (float)(400 - (((Login)
								((Lobby) this).lg)
									.cntgame)) / 10.0F));
								((Lobby) this).rd.setColor(color2k(245, 245,
								245));
								((Lobby) this).rd.fillRoundRect(383, 242, 337,
								46, 20, 20);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.drawRoundRect(383, 242, 337,
								46, 20, 20);
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								12));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Login)((Lobby) this).lg).gmaker)
									.append(" created a game in ").append(((Login)((Lobby) this).lg).gservern)
									.append(" :: Room ").append(((Login)((Lobby) this).lg).groom)
									.append("").toString(),
								551 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("")
									.append(((Login)((Lobby) this).lg)
									.gmaker)
									.append(" created a game in ").append(((Login)((Lobby) this).lg)
									.gservern)
									.append(" :: Room ").append(((Login)((Lobby) this).lg)
									.groom)
									.append("").toString())) / 2,
								260);
								if (i > 488 && i < 614 && i_99_ > 264 && i_99_ < 287) {
									if (bool)
									((Lobby) this).grprsd = true;
									else if (((Lobby) this).grprsd) {
										for (int i_190_ = 0;
										(i_190_ < (((Login)((Lobby) this).lg)
											.nservers));
										i_190_++) {
											if (((Login)((Lobby) this).lg)
												.gservern.equals(((Login)((Lobby) this).lg)
												.snames[i_190_])) {
												stopallnow();
												((xtGraphics)
												((Lobby) this).xt).server = (((Login)
												((Lobby) this).lg)
													.servers[i_190_]);
												((xtGraphics)
												((Lobby) this).xt).servername = (((Login)
												((Lobby) this).lg)
													.snames[i_190_]);
												((xtGraphics)
												((Lobby) this).xt).servport = 7070 + ((Login)
												(((Lobby) this)
													.lg)).groom;
												inishlobby();
												break;
											}
										}
										((Lobby) this).grprsd = false;
									}
								} else if (((Lobby) this).grprsd)
								((Lobby) this).grprsd = false;
								if (!((Lobby) this).grprsd) {
									((Lobby) this).rd.setColor(color2k(230, 230, 230));
									((Lobby) this).rd.fill3DRect(490, 266, 122,
									19, true);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
								} else {
									((Lobby) this).rd.setColor(color2k(230, 230, 230));
									((Lobby) this).rd.fillRect(490, 266, 122,
									19);
									((Lobby) this).rd.setColor(color2k(60, 60,
									60));
								}
								((Lobby) this).rd.drawString("View / Join Game", (551 - (((Lobby) this).ftm.stringWidth("View / Join Game") / 2)),
								280);
								if ((((Login)((Lobby) this).lg).cntgame >= 0 && (((Login)((Lobby) this).lg).cntgame < 10)) || ((((Login)((Lobby) this).lg).cntgame > 390) && (((Login)((Lobby) this).lg).cntgame < 400)))
								((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
								((Login)((Lobby) this).lg).cntgame++;
								if (((Login)((Lobby) this).lg).cntgame == 400)
								((Login)((Lobby) this).lg).gamec = -1;
							}
						}
					} else if (((Lobby) this).opengame < 26) {
						int i_191_ = 229 + ((Lobby) this).opengame;
						if (i_191_ > 255) i_191_ = 255;
						if (i_191_ < 0) i_191_ = 0;
						((Lobby) this).rd.setColor(color2k(i_191_, i_191_,
						i_191_));
						((Lobby) this).rd.fillRoundRect(225,
						59 - (int)((float)((Lobby) this).opengame * 2.23F),
						495, 200 + ((Lobby) this).opengame * 8, 20, 20);
						((Lobby) this).rd.setColor(new Color(0, 0, 0));
						((Lobby) this).rd.drawRoundRect(225,
						59 - (int)((float)((Lobby) this).opengame * 2.23F),
						495, 200 + ((Lobby) this).opengame * 8, 20, 20);
						if (!((xtGraphics)((Lobby) this).xt).lan) {
							((Lobby) this).rd.setColor(color2k(217, 217, 217));
							((Lobby) this).rd.fillRoundRect(225, 263 + ((Lobby) this).opengame * 7, 495,
							157, 20, 20);
							((Lobby) this).rd.setColor(new Color(0, 0, 0));
							((Lobby) this).rd.drawRoundRect(225, 263 + ((Lobby) this).opengame * 7, 495,
							157, 20, 20);
						}
						((Lobby) this).btn = 0;
						if (((Lobby) this).prevloaded != -1)
						((Lobby) this).prevloaded = -1;
						if (((Lobby) this).updatec != -1)
						((Lobby) this).updatec = -1;
						if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
							((GameSparker)((Lobby) this).gs).cmsg.hide();
							((Lobby) this).gs.requestFocus();
						}
						if (((GameSparker)((Lobby) this).gs).rooms.isShowing())
						((GameSparker)((Lobby) this).gs).rooms.hide();
						if (((Lobby) this).fstart)
						((Lobby) this).fstart = false;
						for (int i_192_ = 0; i_192_ < 9; i_192_++) {
							if (((Lobby) this).cac[i_192_] != -1)
							((Lobby) this).cac[i_192_] = -1;
						}
						if (((Lobby) this).dispcar != -1)
						((Lobby) this).dispcar = -1;
						((Lobby) this).opengame += 2;
					} else {
						((Lobby) this).rd.setColor(color2k(255, 255, 255));
						((Lobby) this).rd.fillRoundRect(225, 1, 495, 417, 20,
						20);
						((Lobby) this).rd.setColor(new Color(0, 0, 0));
						((Lobby) this).rd.drawRoundRect(225, 1, 495, 417, 20,
						20);
						if ((((Lobby) this).join > -1 && (((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).join)) || ((Lobby) this).join == -2) {
							if (((Lobby) this).join > -1 && (((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).join)) {
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								13));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.drawString(((Lobby) this).msg, (472 - (((Lobby) this).ftm.stringWidth(((Lobby) this).msg) / 2)),
								195);
								if (((Lobby) this).msg.equals(". . . | Joining Game | . . .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = "| Joining Game |";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals(". . | Joining Game | . .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". . . | Joining Game | . . .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals(". | Joining Game | .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". . | Joining Game | . .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals("| Joining Game |") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". | Joining Game | .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).ncnt != 0)
								((Lobby) this).ncnt--;
							}
							if (((Lobby) this).join == -2) {
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								13));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.drawString(((Lobby) this).msg, (472 - (((Lobby) this).ftm.stringWidth(((Lobby) this).msg) / 2)),
								195);
								if (((Lobby) this).msg.equals(". . . | Leaving Game | . . .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = "| Leaving Game |";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals(". . | Leaving Game | . .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". . . | Leaving Game | . . .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals(". | Leaving Game | .") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". . | Leaving Game | . .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).msg.equals("| Leaving Game |") && ((Lobby) this).ncnt == 0) {
									((Lobby) this).msg = ". | Leaving Game | .";
									((Lobby) this).ncnt = 5;
								}
								if (((Lobby) this).ncnt != 0)
								((Lobby) this).ncnt--;
							}
							if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
								((GameSparker)((Lobby) this).gs).cmsg.hide();
								((Lobby) this).gs.requestFocus();
							}
						} else {
							int i_193_ = 0;
							for (int i_194_ = 0; i_194_ < ((Lobby) this).ngm;
							i_194_++) {
								if (((Lobby) this).ongame == ((Lobby) this).gnum[i_194_]) i_193_ = i_194_;
							}
							((Lobby) this).rd.setFont(new Font("Arial", 1,
							11));
							((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
							((Lobby) this).rd.setColor(new Color(0, 0, 0));
							int i_195_ = 23;
							int i_196_ = 0;
							if (((Lobby) this).gwarb[i_193_] != 0) {
								i_195_ = 28;
								i_196_ = 2;
								String string = "Clan war";
								if (((Lobby) this).gwarb[i_193_] == 2) string = "Car battle";
								if (((Lobby) this).gwarb[i_193_] == 3) string = "Stage battle";
								((Lobby) this).rd.drawString(new StringBuilder().append("").append(string).append(" between ").append(((Lobby) this).gaclan[i_193_]).append(" and ").append(((Lobby) this).gvclan[i_193_]).append("").toString(),
								243, 14);
							}
							String string = "";
							String string_197_ = "";
							String string_198_ = "";
							if (((Lobby) this).conon == 1) {
								if (((Lobby) this).wait[i_193_] > 0) {
									if (((Lobby) this).gwarb[i_193_] == 0) {
										String string_199_ = "";
										if (((Lobby) this).gplyrs[i_193_].equals("")) string_199_ = "Public Game";
										else string_199_ = "Private Game";
										if (((Lobby) this).gfx[i_193_] == 1) string_199_ = new StringBuilder().append(string_199_).append(" | 4 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 2) string_199_ = new StringBuilder().append(string_199_).append(" | 3 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 3) string_199_ = new StringBuilder().append(string_199_).append(" | 2 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 4) string_199_ = new StringBuilder().append(string_199_).append(" | 1 Fix").toString();
										if (((Lobby) this).gfx[i_193_] == 5) string_199_ = new StringBuilder().append(string_199_).append(" | No Fixing")
											.toString();
										String string_200_ = "";
										if (((Lobby) this).gclss[i_193_] > -2) {
											if (((Lobby) this).gcrs[i_193_] == 1) string_200_ = "Custom Cars";
											if (((Lobby) this).gcrs[i_193_] == 2) string_200_ = "Game Cars";
											String string_201_ = "";
											if (((Lobby) this).gclss[i_193_] == 1) string_201_ = "Class C";
											if (((Lobby) this).gclss[i_193_] == 2) string_201_ = "Class B & C";
											if (((Lobby) this).gclss[i_193_] == 3) string_201_ = "Class B";
											if (((Lobby) this).gclss[i_193_] == 4) string_201_ = "Class A & B";
											if (((Lobby) this).gclss[i_193_] == 5) string_201_ = "Class A";
											if (!string_200_.equals("") && !string_201_.equals("")) string_200_ = new StringBuilder()
												.append(string_200_).append(" | ").append(string_201_)
												.toString();
											else string_200_ = new StringBuilder()
												.append(string_200_).append(string_201_)
												.toString();
										} else string_200_ = new StringBuilder().append("").append(((CarDefine)
										((Lobby) this).cd)
											.names[Math.abs((((Lobby)
										this)
											.gclss[i_193_]) + 2)])
											.append("").toString();
										if (string_200_.equals("")) {
											((Lobby) this).rd.drawString("Type:", 243, 23);
											((Lobby) this).rd.setColor(new Color(80, 128, 0));
											((Lobby) this).rd.drawString(string_199_, 279, 23);
										} else {
											((Lobby) this).rd.drawString("Type:", 243, 14);
											((Lobby) this).rd.drawString("Cars:", 244, 28);
											((Lobby) this).rd.setColor(new Color(80, 128, 0));
											((Lobby) this).rd.drawString(string_199_, 279, 14);
											((Lobby) this).rd.drawString(string_200_, 279, 28);
										}
									} else {
										String string_202_ = new StringBuilder().append("Game #").append(((Lobby) this).gameturn[i_193_])
											.append("").toString();
										if (((Lobby) this).gcrs[i_193_] == 1) string_202_ = new StringBuilder().append(string_202_).append(" | Clan Cars")
											.toString();
										if (((Lobby) this).gcrs[i_193_] == 2) string_202_ = new StringBuilder().append(string_202_).append(" | Game Cars")
											.toString();
										if (((Lobby) this).gclss[i_193_] == 1) string_202_ = new StringBuilder().append(string_202_).append(" | Class C")
											.toString();
										if (((Lobby) this).gclss[i_193_] == 2) string_202_ = new StringBuilder().append(string_202_).append(" | Class B & C")
											.toString();
										if (((Lobby) this).gclss[i_193_] == 3) string_202_ = new StringBuilder().append(string_202_).append(" | Class B")
											.toString();
										if (((Lobby) this).gclss[i_193_] == 4) string_202_ = new StringBuilder().append(string_202_).append(" | Class A & B")
											.toString();
										if (((Lobby) this).gclss[i_193_] == 5) string_202_ = new StringBuilder().append(string_202_).append(" | Class A")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 1) string_202_ = new StringBuilder().append(string_202_).append(" | 4 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 2) string_202_ = new StringBuilder().append(string_202_).append(" | 3 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 3) string_202_ = new StringBuilder().append(string_202_).append(" | 2 Fixes")
											.toString();
										if (((Lobby) this).gfx[i_193_] == 4) string_202_ = new StringBuilder().append(string_202_).append(" | 1 Fix").toString();
										if (((Lobby) this).gfx[i_193_] == 5) string_202_ = new StringBuilder().append(string_202_).append(" | No Fixing")
											.toString();
										((Lobby) this).rd.setColor(new Color(80, 128, 0));
										((Lobby) this).rd.drawString(string_202_, 243, 28);
									}
								}
								if (((Lobby) this).wait[i_193_] == 0) {
									((Lobby) this).rd.drawString("Status:",
									241 + i_196_,
									i_195_);
									((Lobby) this).rd.setColor(new Color(128, 73, 0));
									if (((Lobby) this).prevloaded == 0)
									((Lobby) this).rd.drawString("Starting...", 286 + i_196_,
									i_195_);
									else((Lobby) this).rd.drawString("Started", 286 + i_196_, i_195_);
								}
								if (((Lobby) this).wait[i_193_] == -1) {
									((Lobby) this).rd.drawString("Status:",
									241 + i_196_,
									i_195_);
									((Lobby) this).rd.setColor(color2k(100, 100, 100));
									((Lobby) this).rd.drawString("Finished",
									286 + i_196_,
									i_195_);
								}
							} else {
								((Lobby) this).rd.drawString("Status:",
								241 + i_196_,
								i_195_);
								((Lobby) this).rd.setColor(new Color(128, 73,
								0));
								((Lobby) this).rd.drawString("Starting...",
								286 + i_196_,
								i_195_);
							}
							if (((Lobby) this).gwarb[i_193_] == 0) {
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								if (((Lobby) this).gmaker[i_193_].equals(((Lobby) this).pnames[((Lobby) this).im]))
								((Lobby) this).rd.drawString("Created by You", 449, 23);
								else {
									((Lobby) this).rd.drawString("Created by",
									449, 23);
									((Lobby) this).rd.drawString(":", 511, 23);
									((Lobby) this).rd.drawString((((Lobby)
									this)
										.gmaker[i_193_]),
									520, 23);
								}
							} else if (((Lobby) this).wait[i_193_] == 0 || ((Lobby) this).wait[i_193_] == -1 || ((Lobby) this).conon != 1) {
								((Lobby) this).rd.setColor(color2k(200, 200,
								200));
								((Lobby) this).rd.drawRect(349, 16, 253, 16);
								((Lobby) this).rd.setFont(new Font("Arial", 0,
								11));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								int i_203_ = 0;
								int i_204_ = 0;
								if (((Lobby) this).wait[i_193_] == -1) {
									String[] strings = {
										"", "", "", "", "", "", "", ""
									};
									for (int i_205_ = 0;
									i_205_ < ((Lobby) this).prnpo;
									i_205_++) {
										for (int i_206_ = 0;
										i_206_ < ((Lobby) this).npo;
										i_206_++) {
											if ((((Lobby) this).prnames[i_205_].equals(((Lobby) this).pnames[i_206_])) && ((((Lobby) this).pgames[i_206_]) == (((Lobby) this).gnum[i_193_]))) strings[i_205_] = (((Lobby) this).pclan[i_206_]);
										}
									}
									for (int i_207_ = 0;
									i_207_ < ((Lobby) this).prnpo;
									i_207_++) {
										if (((Lobby) this).ppos[i_207_] == 0) {
											string = strings[i_207_];
											break;
										}
									}
									if (!string.equals("")) {
										if (((Lobby) this).gwtyp[i_193_] == 2) {
											boolean bool_208_ = false;
											for (int i_209_ = 0;
											i_209_ < ((Lobby) this).prnpo;
											i_209_++) {
												if (!(strings[i_209_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_209_]) < 55 && (((Lobby) this).pdam[i_209_]) != -17) {
													bool_208_ = true;
													break;
												}
											}
											if (!bool_208_) {
												string_198_ = new StringBuilder()
													.append("").append(string).append(" should have raced in this game!")
													.toString();
												string = "";
											}
										}
										if (((Lobby) this).gwtyp[i_193_] == 3) {
											boolean bool_210_ = true;
											for (int i_211_ = 0;
											i_211_ < ((Lobby) this).prnpo;
											i_211_++) {
												if (!(strings[i_211_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_211_]) < 55 && (((Lobby) this).pdam[i_211_]) != -17) {
													bool_210_ = false;
													break;
												}
											}
											if (!bool_210_) {
												string_198_ = new StringBuilder()
													.append("").append(string).append(" should have wasted in this game!")
													.toString();
												string = "";
											}
										}
										if (((Lobby) this).gwtyp[i_193_] == 4) {
											if (string.toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase())) {
												boolean bool_212_ = true;
												for (int i_213_ = 0;
												(i_213_ < ((Lobby) this).prnpo);
												i_213_++) {
													if (!(strings[i_213_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_213_]) < 55 && (((Lobby) this).pdam[i_213_]) != -17) {
														bool_212_ = false;
														break;
													}
												}
												if (!bool_212_) {
													string_198_ = new StringBuilder().append("").append(string).append(" should have wasted in this game!")
														.toString();
													string = "";
												}
											} else {
												boolean bool_214_ = false;
												for (int i_215_ = 0;
												(i_215_ < ((Lobby) this).prnpo);
												i_215_++) {
													if (!(strings[i_215_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_215_]) < 55 && (((Lobby) this).pdam[i_215_]) != -17) {
														bool_214_ = true;
														break;
													}
												}
												if (!bool_214_) {
													string_198_ = new StringBuilder().append("").append(string).append(" should have raced in this game!")
														.toString();
													string = "";
												}
											}
										}
										if (((Lobby) this).gwtyp[i_193_] == 5) {
											if (!string.toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase())) {
												boolean bool_216_ = true;
												for (int i_217_ = 0;
												(i_217_ < ((Lobby) this).prnpo);
												i_217_++) {
													if (!(strings[i_217_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_217_]) < 55 && (((Lobby) this).pdam[i_217_]) != -17) {
														bool_216_ = false;
														break;
													}
												}
												if (!bool_216_) {
													string_198_ = new StringBuilder().append("").append(string).append(" should have wasted in this game!")
														.toString();
													string = "";
												}
											} else {
												boolean bool_218_ = false;
												for (int i_219_ = 0;
												(i_219_ < ((Lobby) this).prnpo);
												i_219_++) {
													if (!(strings[i_219_].toLowerCase().equals(string.toLowerCase())) && (((Lobby) this).pdam[i_219_]) < 55 && (((Lobby) this).pdam[i_219_]) != -17) {
														bool_218_ = true;
														break;
													}
												}
												if (!bool_218_) {
													string_198_ = new StringBuilder().append("").append(string).append(" should have raced in this game!")
														.toString();
													string = "";
												}
											}
										}
									} else string_198_ = "No one finished first - no one survived!";
									if (string.toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase())) i_203_ = 1;
									if (string.toLowerCase().equals(((Lobby) this).gvclan[i_193_].toLowerCase())) i_204_ = 1;
								}
								((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_]).append(" : ").append(((Lobby) this).gascore[i_193_] + i_203_)
									.append("     |     ").append(((Lobby) this).gvclan[i_193_]).append(" : ").append(((Lobby) this).gvscore[i_193_] + i_204_)
									.append("").toString(), (474 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_])
									.append(" : ").append(((Lobby) this).gascore[i_193_])
									.append("     |     ").append(((Lobby) this).gvclan[i_193_])
									.append(" : ").append(((Lobby) this).gvscore[i_193_])
									.append("").toString())) / 2),
								28);
								if (((Lobby) this).gwarb[i_193_] == 1) {
									if (((Lobby) this).gascore[i_193_] + i_203_ >= 5) string_197_ = new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_])
										.append(" wins the war!")
										.toString();
									if (((Lobby) this).gvscore[i_193_] + i_204_ >= 5) string_197_ = new StringBuilder().append("").append(((Lobby) this).gvclan[i_193_])
										.append(" wins the war!")
										.toString();
								} else {
									if (((Lobby) this).gascore[i_193_] + i_203_ >= 3) string_197_ = new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_])
										.append(" wins the battle!")
										.toString();
									if (((Lobby) this).gvscore[i_193_] + i_204_ >= 3) string_197_ = new StringBuilder().append("").append(((Lobby) this).gvclan[i_193_])
										.append(" wins the battle!")
										.toString();
								}
							}
							((Lobby) this).rd.setColor(color2k(200, 200, 200));
							((Lobby) this).rd.drawLine(233, 32, 602, 32);
							((Lobby) this).rd.drawLine(602, 7, 602, 32);
							if (((Lobby) this).conon == 1) {
								if (((Lobby) this).pgames[((Lobby) this).im] == ((Lobby) this).ongame) stringbutton("Leave Game X", 660, 26, 0);
								else stringbutton("Close X", 679, 26, 0);
							}
							((Lobby) this).rd.drawImage((((xtGraphics)
							((Lobby) this).xt)
								.pls),
							292, 39, null);
							if (((Lobby) this).opengame != 27) {
								((Medium)((Lobby) this).m).crs = true;
								((Medium)((Lobby) this).m).x = -335;
								((Medium)((Lobby) this).m).y = 0;
								((Medium)((Lobby) this).m).z = -50;
								((Medium)((Lobby) this).m).xz = 0;
								((Medium)((Lobby) this).m).zy = 20;
								((Medium)((Lobby) this).m).ground = -2000;
								((Lobby) this).pend = 0;
								((Lobby) this).pendb = false;
								((Lobby) this).ptime = 0L;
								((Lobby) this).opengame = 27;
							}
							int i_220_ = 0;
							int i_221_ = -1;
							for (int i_222_ = 0; i_222_ < ((Lobby) this).npo;
							i_222_++) {
								if (((Lobby) this).pgames[i_222_] == ((Lobby) this).ongame) {
									((Lobby) this).rd.setColor(color2k(240, 240, 240));
									if (i_222_ == ((Lobby) this).im && ((Lobby) this).wait[i_193_] != -1) {
										if (((Lobby) this).nflk == 0 || ((Lobby) this).conon == 2) {
											((Lobby) this).rd.setColor(color2k(255, 255, 255));
											((Lobby) this).nflk = 3;
										} else((Lobby) this).nflk--;
									}
									((Lobby) this).rd.fillRect(237, (54 + i_220_ * 42),
									170, 40);
									((Lobby) this).rd.setColor(color2k(200, 200, 200));
									if (((Lobby) this).gwarb[i_193_] != 0) {
										if (((Lobby) this).pclan[i_222_].toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase()))
										((Lobby) this).rd.setColor(new Color(255, 128, 0));
										if (((Lobby) this).pclan[i_222_].toLowerCase().equals(((Lobby) this).gvclan[i_193_].toLowerCase()))
										((Lobby) this).rd.setColor(new Color(0, 128, 255));
										if (((Lobby) this).wait[i_193_] == -1 && ((Lobby) this).prevloaded == 1 && (string.toLowerCase().equals(((Lobby) this).pclan[i_222_].toLowerCase())) && ((Lobby) this).nflk == 0)
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
									} else if ((((Lobby) this).wait[i_193_] == -1) && (((Lobby) this).prevloaded == 1)) {
										for (int i_223_ = 0;
										i_223_ < ((Lobby) this).prnpo;
										i_223_++) {
											if ((((Lobby) this).pnames[i_222_].equals(((Lobby) this).prnames[i_223_])) && (((Lobby) this).ppos[i_223_] == 0) && ((Lobby) this).nflk == 0)
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
										}
									}
									((Lobby) this).rd.drawRect(237, (54 + i_220_ * 42),
									170, 40);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(((Lobby) this).pnames[i_222_],
									282 - (((Lobby) this).ftm.stringWidth(((Lobby) this).pnames[i_222_])) / 2,
									72 + i_220_ * 42);
									((Lobby) this).rd.setFont(new Font("Arial",
									0, 10));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(((Lobby) this).pcarnames[i_222_],
									282 - (((Lobby) this).ftm.stringWidth(((Lobby) this).pcarnames[i_222_])) / 2,
									84 + i_220_ * 42);
									((Medium)((Lobby) this).m).crs = true;
									((Medium)((Lobby) this).m).x = -335;
									((Medium)((Lobby) this).m).y = 0;
									((Medium)((Lobby) this).m).z = -50;
									((Medium)((Lobby) this).m).xz = 0;
									((Medium)((Lobby) this).m).zy = 20;
									((Medium)((Lobby) this).m).ground = -2000;
									if (((Lobby) this).pcars[i_222_] != -1) {
										for (int i_224_ = 0;
										(i_224_ < ((ContO)
										contos[(((Lobby) this).pcars[i_222_])]).npl);
										i_224_++) {
											((Plane)
											(((ContO) contos[(((Lobby) this)
												.pcars[i_222_])])
												.p[i_224_])).flx = 0;
											if (((Plane)
											(((ContO)
											contos[(((Lobby) this).pcars[i_222_])])
												.p[i_224_])).colnum == 1) {
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[0] = (((Lobby) this).pcols[i_222_][0]);
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[1] = (((Lobby) this).pcols[i_222_][1]);
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[2] = 1.0F - (((Lobby) this)
													.pcols[i_222_]
												[2]);
											}
											if (((Plane)
											(((ContO)
											contos[(((Lobby) this).pcars[i_222_])])
												.p[i_224_])).colnum == 2) {
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[0] = (((Lobby) this).pcols[i_222_][3]);
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[1] = (((Lobby) this).pcols[i_222_][4]);
												((Plane)
												(((ContO)
												contos[(((Lobby) this).pcars[i_222_])])
													.p[i_224_])).hsb[2] = 1.0F - (((Lobby) this)
													.pcols[i_222_]
												[5]);
											}
										}
										if (((Lobby) this).cac[i_220_] != ((Lobby) this).pcars[i_222_]) {
											int i_225_ = (((Plane)
											(((ContO)
											contos[(((Lobby) this)
												.pcars[i_222_])])
												.p[0]))
												.oz[0]);
											int i_226_ = i_225_;
											int i_227_ = (((Plane)
											(((ContO)
											contos[(((Lobby) this)
												.pcars[i_222_])])
												.p[0]))
												.oy[0]);
											int i_228_ = i_227_;
											for (int i_229_ = 0;
											(i_229_ < (((ContO)
											contos[(((Lobby) this)
												.pcars[i_222_])])
												.npl));
											i_229_++) {
												for (int i_230_ = 0;
												(i_230_ < ((Plane)
												(((ContO)
												(contos[(((Lobby) this)
													.pcars[i_222_])]))
													.p[i_229_])).n);
												i_230_++) {
													if ((((Plane)
													(((ContO)
													(contos[(((Lobby) this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oz[i_230_]) < i_225_) i_225_ = (((Plane)
													(((ContO)
													(contos[(((Lobby)
													this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oz[i_230_]);
													if ((((Plane)
													(((ContO)
													(contos[(((Lobby) this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oz[i_230_]) > i_226_) i_226_ = (((Plane)
													(((ContO)
													(contos[(((Lobby)
													this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oz[i_230_]);
													if ((((Plane)
													(((ContO)
													(contos[(((Lobby) this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oy[i_230_]) < i_227_) i_227_ = (((Plane)
													(((ContO)
													(contos[(((Lobby)
													this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oy[i_230_]);
													if ((((Plane)
													(((ContO)
													(contos[(((Lobby) this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oy[i_230_]) > i_228_) i_228_ = (((Plane)
													(((ContO)
													(contos[(((Lobby)
													this)
														.pcars[i_222_])]))
														.p[i_229_]))
														.oy[i_230_]);
												}
											}
											((Lobby) this).cax[i_220_] = (i_226_ + i_225_) / 2;
											((Lobby) this).cay[i_220_] = (i_228_ + i_227_) / 2;
											((Lobby) this).cac[i_220_] = ((Lobby) this).pcars[i_222_];
										}
										if (i > 327 && i < 402 && i_99_ > 57 + i_220_ * 42 && i_99_ < 91 + i_220_ * 42) {
											i_101_ = 12;
											i_221_ = i_222_;
											for (int i_231_ = 0;
											(i_231_ < (((ContO)
											contos[(((Lobby) this)
												.pcars[i_222_])])
												.npl));
											i_231_++)
											((Plane)
											(((ContO)
											contos[(((Lobby) this).pcars[i_222_])])
												.p[i_231_])).flx = 77;
										}
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).z = 2500 - i_220_ * 80;
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).y = (150 + 250 * i_220_ - ((Lobby) this).cay[i_220_]);
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).x = (-145 - ((Lobby) this).cax[i_220_]);
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).zy = 0;
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).xz = -90;
										((ContO) contos[(((Lobby) this).pcars[i_222_])]).xy = ((Lobby) this).pend - i_220_ * 5;
										((Lobby) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, (RenderingHints.VALUE_ANTIALIAS_OFF));
										contos[((Lobby) this).pcars[i_222_]].d(((Lobby) this).rd);
										((Lobby) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, (RenderingHints.VALUE_ANTIALIAS_ON));
									} else {
										((Lobby) this).rd.setFont(new Font("Arial", 1, 11));
										((Lobby) this).rd.setColor(color2k(80, 80, 80));
										((Lobby) this).rd.drawString("Loading...", 339,
										77 + i_220_ * 42);
									}
									i_220_++;
								}
							}
							if (!((Lobby) this).pendb) {
								((Lobby) this).pend += 2;
								if (((Lobby) this).pend > 80)
								((Lobby) this).pendb = true;
							} else {
								((Lobby) this).pend -= 2;
								if (((Lobby) this).pend < -10)
								((Lobby) this).pendb = false;
							}
							if (i_221_ != -1) {
								if (bool)
								((Lobby) this).mousedout = true;
								else if (((Lobby) this).mousedout) {
									if (((Lobby) this).dispcar != i_221_ && i_221_ != -1 && (((CarDefine)((Lobby) this).cd)
										.action) != 6) {
										((CarDefine)((Lobby) this).cd).action = 0;
										((Lobby) this).dispcar = i_221_;
										((Lobby) this).forcar = ((Lobby) this).pcars[i_221_];
										((Lobby) this).dispco = null;
										System.gc();
										((Lobby) this).dispco = new ContO(contos[(((Lobby) this)
											.forcar)],
										0, 0, 0, 0);
									} else((Lobby) this).dispcar = -1;
									((Lobby) this).mousedout = false;
								}
							} else if (((Lobby) this).mousedout)
							((Lobby) this).mousedout = false;
							for (int i_232_ = 0; i_232_ < 7; i_232_++) {
								for (int i_233_ = 0;
								i_233_ < ((Lobby) this).npo; i_233_++) {
									if ((((Lobby) this).pgames[i_233_] == ((Lobby) this).ongame) && (((Lobby) this).invos[i_232_].equals(((Lobby) this).pnames[i_233_])) && (((Lobby) this).dinvi[i_232_].equals(((Lobby) this).invos[i_232_]))) {
										for (int i_234_ = i_232_; i_234_ < 6;
										i_234_++) {
											((Lobby) this).invos[i_234_] = (((Lobby) this).invos[i_234_ + 1]);
											((Lobby) this).dinvi[i_234_] = (((Lobby) this).dinvi[i_234_ + 1]);
										}
										((Lobby) this).invos[6] = "";
										((Lobby) this).dinvi[6] = "";
									}
								}
							}
							if (((Lobby) this).wait[i_193_] > 0) {
								int i_235_ = 0;
								for (int i_236_ = i_220_;
								i_236_ < ((Lobby) this).mnpls[i_193_];
								i_236_++) {
									((Lobby) this).rd.setColor(color2k(200, 200, 200));
									((Lobby) this).rd.drawRect(237, (54 + i_236_ * 42),
									170, 40);
									boolean bool_237_ = false;
									if ((((Lobby) this).pgames[((Lobby) this).im]) == ((Lobby) this).ongame) {
										if (!((Lobby) this).gplyrs[i_193_].equals("")) bool_237_ = true;
									} else if (((Lobby) this).gwarb[i_193_] == 0) {
										if (!((Lobby) this).gplyrs[i_193_].equals("") && (((Lobby) this).gplyrs[i_193_].indexOf(((Lobby) this).pnames[((Lobby) this).im])) == -1) bool_237_ = true;
									} else if (!(((xtGraphics)
									((Lobby) this).xt)
										.clan.toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase())) && !(((xtGraphics)
									((Lobby) this).xt)
										.clan.toLowerCase().equals(((Lobby) this).gvclan[i_193_].toLowerCase()))) bool_237_ = true;
									if (i > 237 && i < 407 && i_99_ > 54 + i_236_ * 42 && i_99_ < 94 + i_236_ * 42 && !bool_237_) {
										if ((((Lobby) this).pgames[((Lobby) this).im]) == ((Lobby) this).ongame) stringbutton("<     Invite Player      ",
										322, 79 + i_236_ * 42, 0);
										else stringbutton("    Join Game    ",
										322, 79 + i_236_ * 42,
										0);
										((Lobby) this).pbtn = 1;
									} else if (((Lobby) this).invos[i_235_].equals("")) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("Empty",
										322 - (((Lobby) this).ftm.stringWidth("Empty") / 2),
										72 + i_236_ * 42);
										((Lobby) this).rd.setFont(new Font("Arial", 0, 10));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("Waiting for player...",
										322 - ((((Lobby) this).ftm.stringWidth("Waiting for player...")) / 2),
										84 + i_236_ * 42);
									} else if (!((Lobby) this).dinvi[i_235_].equals(((Lobby) this).invos[i_235_])) {
										if (((Lobby) this).nflk != 0) {
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
											((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											((Lobby) this).rd.drawString("Inviting player...", (322 - ((((Lobby) this).ftm.stringWidth("Inviting player...")) / 2)),
											79 + i_236_ * 42);
										}
									} else {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("Player Invited!",
										322 - (((Lobby) this).ftm.stringWidth("Player Invited!")) / 2,
										71 + i_236_ * 42);
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString(((Lobby) this).invos[i_235_],
										322 - (((Lobby) this).ftm.stringWidth(((Lobby) this).invos[i_235_])) / 2,
										87 + i_236_ * 42);
									}
									i_235_++;
								}
							}
							if (((xtGraphics)((Lobby) this).xt).lan && ((Lobby) this).mnbts[i_193_] != 0) {
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								12));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.drawString(new StringBuilder().append("Plus ").append(((Lobby) this).mnbts[i_193_]).append(" MadBots!").toString(),
								322 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Plus ").append(((Lobby) this).mnbts[i_193_])
									.append(" MadBots!")
									.toString())) / 2,
								73 + ((Lobby) this).mnpls[i_193_] * 42);
							}
							if (((Lobby) this).dispcar == -1 || ((Lobby) this).conon != 1) {
								((Lobby) this).rd.drawImage(((xtGraphics)
								(((Lobby) this)
									.xt)).sts,
								537, 39, null);
								((Lobby) this).rd.setColor(color2k(200, 200,
								200));
								((Lobby) this).rd.drawRect(415, 54, 293, 166);
								if (((Lobby) this).conon == 1) {
									if (((Lobby) this).wait[i_193_] > 0) {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if (((Lobby) this).gwarb[i_193_] == 0) {
											if ((((Lobby) this).wait[i_193_] > 30) || (((Lobby) this).npls[i_193_] <= 1)) {
												String string_238_ = "s";
												if (((((Lobby) this).mnpls[i_193_]) - (((Lobby) this).npls[i_193_])) == 1) string_238_ = "";
												((Lobby) this).rd.drawString(new StringBuilder().append("Waiting for ")
													.append((((Lobby) this).mnpls[i_193_]) - (((Lobby) this)
													.npls[i_193_]))
													.append(" more player")
													.append(string_238_).append(" to join to start.")
													.toString(), (561 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Waiting for ")
													.append((((Lobby) this)
													.mnpls[i_193_]) - (((Lobby)
												this)
													.npls[i_193_]))
													.append(" more player")
													.append(string_238_)
													.append(" to join to start.")
													.toString())) / 2),
												98);
												((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												int i_239_ = 134;
												if (!(((Lobby) this).gmaker[i_193_].equals("Coach Insano")) && !(((Lobby) this)
													.gmaker[i_193_].equals(((Lobby) this).pnames[(((Lobby) this)
													.im)]))) {
													boolean bool_240_ = false;
													for (int i_241_ = 0;
													(i_241_ < (((Lobby) this)
														.npo));
													i_241_++) {
														if (((((Lobby) this)
															.pgames[i_241_]) == (((Lobby) this)
															.ongame)) && (((Lobby) this)
															.gmaker[i_193_].equals(((Lobby) this)
															.pnames[i_241_]))) bool_240_ = true;
													}
													if (bool_240_) {
														i_239_ = 144;
														((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby)
														this)
															.gmaker[i_193_])
															.append(" can start this game at anytime.")
															.toString(), (561 - (((Lobby) this)
															.ftm.stringWidth(new StringBuilder().append("")
															.append(((Lobby)
														this)
															.gmaker[i_193_])
															.append(" can start this game at anytime.")
															.toString())) / 2),
														124);
													}
												}
												if (((Lobby) this).npls[i_193_] > 1) {
													String string_242_ = new StringBuilder().append("").append(((Lobby) this)
														.wait[i_193_])
														.append(" seconds")
														.toString();
													if ((((Lobby) this).wait[i_193_]) > 60) string_242_ = new StringBuilder().append("").append((float)(int)((float)((Lobby) this).wait[i_193_] / 60.0F * 100.0F) / 100.0F)
														.append(" minutes")
														.toString();
													((Lobby) this).rd.drawString(new StringBuilder().append("( Waiting ")
														.append(string_242_)
														.append(" maximum! )")
														.toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("( Waiting ")
														.append(string_242_)
														.append(" maximum! )")
														.toString())) / 2),
													i_239_);
												}
											} else {
												Date date = new Date();
												long l = date.getTime();
												if (((Lobby) this).ptime == 0L || l > (((Lobby) this)
													.ptime) + 1500L) {
													if (((Lobby) this).ptime != 0L) {
														((Lobby) this).wait[i_193_]--;
														if ((((Lobby) this)
															.wait[i_193_]) < 1)
														((Lobby) this)
															.wait[i_193_] = 1;
													}
													((Lobby) this).ptime = l;
												}
												if (((((Lobby) this).pgames[((Lobby) this).im]) == ((Lobby) this).ongame) || (((Lobby) this).nflk != 0)) {
													((Lobby) this).rd.drawString(new StringBuilder().append("Game starts in ")
														.append(((Lobby) this)
														.wait[i_193_])
														.append(" seconds!")
														.toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("Game starts in ")
														.append(((Lobby)
													this)
														.wait[i_193_])
														.append(" seconds!")
														.toString())) / 2),
													124);
													if ((((Lobby) this).pgames[((Lobby) this).im]) != (((Lobby) this)
														.ongame))
													((Lobby) this).nflk--;
												} else if ((((Lobby) this)
													.pgames[(((Lobby) this)
													.im)]) != (((Lobby) this)
													.ongame))
												((Lobby) this).nflk = 3;
											}
											if ((((Lobby) this).pgames[((Lobby) this).im]) != ((Lobby) this).ongame) {
												if (((Lobby) this).gplyrs[i_193_].equals("") || ((((Lobby) this)
													.gplyrs[i_193_].indexOf(((Lobby) this).pnames[((Lobby) this).im])) != -1)) stringbutton("    Join this Game    ",
												561, 182, 0);
												else {
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													12));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.setColor(new Color(128, 73,
													0));
													((Lobby) this).rd.drawString("Private Game, only specific players allowed.", (561 - ((((Lobby) this)
														.ftm.stringWidth("Private Game, only specific players allowed.")) / 2)),
													180);
													stringbutton("    Join this Game    ",
													561, -1000, 0);
												}
											} else if (((Lobby) this)
												.gmaker[i_193_].equals(((Lobby) this).pnames[((Lobby) this).im])) {
												if (((Lobby) this).npls[i_193_] > 1) {
													if (!((Lobby) this).fstart) stringbutton("    Start this Game Now!    ",
													561, 182, 0);
													else stringbutton("    Starting game now, one moment...    ",
													561, 182, 0);
												} else {
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													12));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.setColor(new Color(128, 73,
													0));
													((Lobby) this).rd.drawString("You have created this game.", (561 - ((((Lobby) this)
														.ftm.stringWidth("You have created this game.")) / 2)),
													180);
												}
											} else {
												((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.setColor(new Color(80, 128, 0));
												((Lobby) this).rd.drawString("You have joined this game.", (561 - ((((Lobby) this)
													.ftm.stringWidth("You have joined this game.")) / 2)),
												180);
											}
										} else {
											String string_243_ = "s";
											if ((((Lobby) this).mnpls[i_193_] - ((Lobby) this).npls[i_193_]) == 1) string_243_ = "";
											((Lobby) this).rd.drawString(new StringBuilder().append("Waiting for ").append((((Lobby) this).mnpls[i_193_]) - (((Lobby) this).npls[i_193_]))
												.append(" clan member").append(string_243_).append(" to join to start.")
												.toString(), (561 - (((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("Waiting for ")
												.append((((Lobby) this)
												.mnpls[i_193_]) - (((Lobby) this)
												.npls[i_193_]))
												.append(" clan member")
												.append(string_243_).append(" to join to start.")
												.toString())) / 2),
											72);
											int i_244_ = (((Lobby) this).mnpls[i_193_] / 2);
											int i_245_ = (((Lobby) this).mnpls[i_193_] / 2);
											for (int i_246_ = 0;
											i_246_ < ((Lobby) this).npo;
											i_246_++) {
												if ((((Lobby) this).pgames[i_246_]) == (((Lobby) this).gnum[i_193_])) {
													if ((((Lobby) this)
														.pclan[i_246_].toLowerCase().equals(((Lobby) this)
														.gaclan[i_193_].toLowerCase())) && --i_244_ < 0) i_244_ = 0;
													if ((((Lobby) this)
														.pclan[i_246_].toLowerCase().equals(((Lobby) this)
														.gvclan[i_193_].toLowerCase())) && --i_245_ < 0) i_245_ = 0;
												}
											}
											((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											((Lobby) this).rd.drawString(new StringBuilder().append("( ").append(i_244_).append(" of ").append(((Lobby) this).gaclan[i_193_])
												.append("  &  ").append(i_245_).append(" of ").append(((Lobby) this).gvclan[i_193_])
												.append(" )").toString(),
											561 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("( ").append(i_244_).append(" of ").append(((Lobby) this)
												.gaclan[i_193_])
												.append("  &  ").append(i_245_).append(" of ").append(((Lobby) this)
												.gvclan[i_193_])
												.append(" )")
												.toString())) / 2,
											87);
											((Lobby) this).rd.drawString(((Lobby) this).gaclan[i_193_],
											491 - (((Lobby) this).ftm.stringWidth(((Lobby) this).gaclan[i_193_])) / 2,
											125);
											((Lobby) this).rd.drawString(((Lobby) this).gvclan[i_193_],
											631 - (((Lobby) this).ftm.stringWidth(((Lobby) this).gvclan[i_193_])) / 2,
											125);
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											String string_247_ = "War";
											if (((Lobby) this).gwarb[i_193_] > 1) string_247_ = "Battle";
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(string_247_).append(" Score").toString(),
											561 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(string_247_)
												.append(" Score")
												.toString())) / 2,
											107);
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gascore[i_193_])
												.append("").toString(),
											491 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(((Lobby) this)
												.gascore[i_193_])
												.append("")
												.toString())) / 2,
											139);
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gvscore[i_193_])
												.append("").toString(),
											631 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(((Lobby) this)
												.gascore[i_193_])
												.append("")
												.toString())) / 2,
											139);
											((Lobby) this).rd.drawRect(421, 111, 280, 33);
											((Lobby) this).rd.drawLine(561, 111, 561, 144);
											((Lobby) this).rd.setColor(new Color(255, 128, 0));
											((Lobby) this).rd.drawRect(422, 112, 138, 31);
											((Lobby) this).rd.setColor(new Color(0, 128, 255));
											((Lobby) this).rd.drawRect(562, 112, 138, 31);
											if ((((Lobby) this).pgames[((Lobby) this).im]) != ((Lobby) this).ongame) {
												if ((((xtGraphics)
												((Lobby) this).xt)
													.clan.toLowerCase().equals(((Lobby) this).gaclan[i_193_].toLowerCase())) || (((xtGraphics)
												((Lobby) this).xt)
													.clan.toLowerCase().equals(((Lobby) this)
													.gvclan[i_193_].toLowerCase()))) stringbutton("    Join this Game    ",
												561, 200, 0);
												else {
													((Lobby) this).rd.setColor(new Color(128, 73,
													0));
													((Lobby) this).rd.drawString("You must be a member of either clan to join.", (561 - ((((Lobby) this)
														.ftm.stringWidth("You must be a member of either clan to join.")) / 2)),
													198);
												}
											} else {
												if ((((Lobby) this).gmaker[i_193_].equals(((Lobby) this).pnames[((Lobby) this).im])) && (((Lobby) this).npls[i_193_]) > 1) stringbutton("    Start this Game Now!    ",
												561, -1000, 0);
												((Lobby) this).rd.setColor(new Color(80, 128, 0));
												((Lobby) this).rd.drawString("You have joined this game.", (561 - ((((Lobby) this)
													.ftm.stringWidth("You have joined this game.")) / 2)),
												198);
											}
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											if (((Lobby) this).gwtyp[i_193_] == 1) {
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.drawString("This is a normal clan game.", (561 - ((((Lobby) this)
													.ftm.stringWidth("This is a normal clan game.")) / 2)),
												161);
												((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.drawString("Any clan can win by racing or wasting.", (561 - ((((Lobby) this)
													.ftm.stringWidth("Any clan can win by racing or wasting.")) / 2)),
												176);
											}
											if (((Lobby) this).gwtyp[i_193_] == 2) {
												if (((Lobby) this).sflk != 0) {
													((Lobby) this).sflk--;
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
												} else {
													((Lobby) this).sflk = 3;
													((Lobby) this).rd.setColor(new Color(117, 67,
													0));
												}
												((Lobby) this).rd.drawString("This is a racing only game!", (561 - ((((Lobby) this)
													.ftm.stringWidth("This is a racing only game!")) / 2)),
												161);
												((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.drawString("A clan can only win by racing.", (561 - ((((Lobby) this)
													.ftm.stringWidth("A clan can only win by racing.")) / 2)),
												176);
											}
											if (((Lobby) this).gwtyp[i_193_] == 3) {
												if (((Lobby) this).sflk != 0) {
													((Lobby) this).sflk--;
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
												} else {
													((Lobby) this).sflk = 3;
													((Lobby) this).rd.setColor(new Color(117, 67,
													0));
												}
												((Lobby) this).rd.drawString("This is a wasting only game!", (561 - ((((Lobby) this)
													.ftm.stringWidth("This is a wasting only game!")) / 2)),
												161);
												((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.drawString("A clan can only win by wasting.", (561 - ((((Lobby) this)
													.ftm.stringWidth("A clan can only win by wasting.")) / 2)),
												176);
											}
											if (((Lobby) this).gwtyp[i_193_] == 4) {
												if (((Lobby) this).sflk != 0) {
													((Lobby) this).sflk--;
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
												} else {
													((Lobby) this).sflk = 3;
													((Lobby) this).rd.setColor(new Color(117, 67,
													0));
												}
												((Lobby) this).rd.drawString("This is Racers VS Wasters game!", (561 - ((((Lobby) this)
													.ftm.stringWidth("This is Racers VS Wasters game!")) / 2)),
												161);
												((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_])
													.append(" wastes & ").append(((Lobby) this).gvclan[i_193_])
													.append(" races.")
													.toString(), (561 - ((((Lobby) this)
													.ftm.stringWidth(new StringBuilder().append("").append(((Lobby) this)
													.gaclan[i_193_])
													.append(" wastes & ")
													.append(((Lobby) this)
													.gvclan[i_193_])
													.append(" races.")
													.toString())) / 2)),
												176);
											}
											if (((Lobby) this).gwtyp[i_193_] == 5) {
												if (((Lobby) this).sflk != 0) {
													((Lobby) this).sflk--;
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
												} else {
													((Lobby) this).sflk = 3;
													((Lobby) this).rd.setColor(new Color(117, 67,
													0));
												}
												((Lobby) this).rd.drawString("This is Racers VS Wasters game!", (561 - ((((Lobby) this)
													.ftm.stringWidth("This is Racers VS Wasters game!")) / 2)),
												161);
												((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gaclan[i_193_])
													.append(" races & ").append(((Lobby) this).gvclan[i_193_])
													.append(" wastes.")
													.toString(), (561 - ((((Lobby) this)
													.ftm.stringWidth(new StringBuilder().append("").append(((Lobby) this)
													.gaclan[i_193_])
													.append(" races & ")
													.append(((Lobby) this)
													.gvclan[i_193_])
													.append(" wastes.")
													.toString())) / 2)),
												176);
											}
										}
									} else if (((Lobby) this).prevloaded == 1) {
										int i_248_ = (int)(80.0 + ((double)(float)(((Lobby)
										this)
											.rerr) / 1.243));
										if (i_248_ > 255) i_248_ = 255;
										if (i_248_ < 0) i_248_ = 0;
										int i_249_ = (int)(128.0 + ((double)(float)(((Lobby)
										this)
											.rerr) / 2.428));
										if (i_249_ > 255) i_249_ = 255;
										if (i_249_ < 0) i_249_ = 0;
										int i_250_ = ((Lobby) this).rerr;
										if (i_250_ > 255) i_250_ = 255;
										if (i_250_ < 0) i_250_ = 0;
										if (((Lobby) this).wait[i_193_] == 0) {
											((Lobby) this).rd.setColor(new Color(i_248_, i_249_,
											i_250_));
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).rd.drawString("Live Info!", 621, 51);
											((Lobby) this).rd.drawString("Live Info!", 451, 51);
										}
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Tahoma", 1, 11));
										((Lobby) this).rd.drawString("Player       Position   Laps      Power        Damage",
										439, 69);
										((Lobby) this).rd.setColor(color2k(200, 200, 200));
										((Lobby) this).rd.drawLine(489, 61,
										489, 162);
										((Lobby) this).rd.drawLine(542, 61,
										542, 162);
										((Lobby) this).rd.drawLine(579, 61,
										579, 162);
										((Lobby) this).rd.drawLine(641, 61,
										641, 162);
										((Lobby) this).rd.drawLine(422, 72,
										702, 72);
										((Lobby) this).rd.drawLine(422, 163,
										702, 163);
										i_220_ = 0;
										for (int i_251_ = 0;
										i_251_ < ((Lobby) this).prnpo;
										i_251_++) {
											for (int i_252_ = 0;
											i_252_ < ((Lobby) this).prnpo;
											i_252_++) {
												if (((Lobby) this).ppos[i_252_] == i_251_) {
													((Lobby) this).rd.setFont(new Font("Tahoma", 0,
													11));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.setColor(new Color(0, 44,
													124));
													((Lobby) this).rd.drawString((((Lobby) this)
														.prnames[i_252_]), (455 - (((Lobby) this)
														.ftm.stringWidth(((Lobby) this)
														.prnames[i_252_])) / 2),
													83 + 11 * i_220_);
													if ((((Lobby) this).pdam[i_252_]) < 55 && (((Lobby) this).pdam[i_252_]) != -17) {
														((Lobby) this).rd.setColor(new Color(80, 128,
														0));
														String string_253_ = "th";
														if ((((Lobby) this)
															.ppos[i_252_]) == 0) string_253_ = "st";
														if ((((Lobby) this)
															.ppos[i_252_]) == 1) string_253_ = "nd";
														if ((((Lobby) this)
															.ppos[i_252_]) == 2) string_253_ = "rd";
														((Lobby) this).rd.drawString(new StringBuilder().append("").append((((Lobby)
														this)
															.ppos[i_252_]) + 1)
															.append("").append(string_253_)
															.toString(), (515 - (((Lobby) this)
															.ftm.stringWidth(new StringBuilder().append("")
															.append((((Lobby)
														this)
															.ppos[i_252_]) + 1)
															.append("")
															.append(string_253_)
															.toString())) / 2),
														83 + 11 * i_220_);
														((Lobby) this).rd.setColor(new Color(128, 73,
														0));
														if ((((Lobby) this)
															.plap[i_252_]) > (((Lobby) this)
															.gnlaps[i_193_]) - 1)
														((Lobby) this)
															.plap[i_252_] = ((((Lobby)
														this)
															.gnlaps[i_193_]) - 1);
														((Lobby) this).rd.drawString(new StringBuilder().append("").append((((Lobby)
														this)
															.plap[i_252_]) + 1)
															.append(" / ").append(((Lobby)
														this)
															.gnlaps[i_193_])
															.append("")
															.toString(), (560 - (((Lobby) this)
															.ftm.stringWidth(new StringBuilder().append("")
															.append((((Lobby)
														this)
															.plap[i_252_]) + 1)
															.append(" / ")
															.append(((Lobby)
														this)
															.gnlaps[i_193_])
															.append("")
															.toString())) / 2),
														83 + 11 * i_220_);
														((Lobby) this).rd.setColor(new Color(0, 128,
														255));
														((Lobby) this).rd.drawRect(582,
														76 + 11 * i_220_,
														56, 6);
														((Lobby) this).rd.fillRect(583,
														79 + 11 * i_220_, (((Lobby) this)
															.ppow[i_252_]),
														3);
														((Lobby) this).rd.setColor(new Color(128,
														210,
														255));
														((Lobby) this).rd.fillRect(583,
														77 + 11 * i_220_, (((Lobby) this)
															.ppow[i_252_]),
														2);
														((Lobby) this).rd.setColor(new Color(255, 0,
														0));
														((Lobby) this).rd.drawRect(645,
														76 + 11 * i_220_,
														56, 6);
														((Lobby) this).rd.fillRect(646,
														79 + 11 * i_220_, (((Lobby) this)
															.pdam[i_252_]),
														3);
														((Lobby) this).rd.setColor(new Color(255,
														155,
														64));
														((Lobby) this).rd.fillRect(646,
														77 + 11 * i_220_, (((Lobby) this)
															.pdam[i_252_]),
														2);
													} else {
														i_248_ = (int)(85.0 + ((double)(float)(((Lobby) this).rerr * 2) / 1.5));
														if (i_248_ > 255) i_248_ = 255;
														if (i_248_ < 0) i_248_ = 0;
														((Lobby) this).rd.setColor(color2k(i_248_,
														i_248_,
														i_248_));
														((Lobby) this).rd.fillRect(490,
														75 + 11 * i_220_,
														213, 9);
														((Lobby) this).rd.setFont(new Font("Tahoma",
														1, 11));
														((Lobby) this).ftm = (((Lobby) this)
															.rd.getFontMetrics());
														i_248_ = 255 - ((((Lobby)
														this)
															.rerr) * 2);
														if (i_248_ > 255) i_248_ = 255;
														if (i_248_ < 0) i_248_ = 0;
														i_249_ = (int)(155.0 - ((double)(float)(((Lobby) this).rerr * 2) / 1.645));
														if (i_249_ > 255) i_249_ = 255;
														if (i_249_ < 0) i_249_ = 0;
														i_250_ = (int)(64.0 - ((double)(float)(((Lobby) this).rerr * 2) / 3.984));
														if (i_250_ > 255) i_250_ = 255;
														if (i_250_ < 0) i_250_ = 0;
														((Lobby) this).rd.setColor(new Color(i_248_, i_249_,
														i_250_));
														if ((((Lobby) this)
															.pdam[i_252_]) != -17)
														((Lobby) this)
															.rd.drawString("=   =   =   =    W A S T E D    =   =   =   =", (597 - ((((Lobby)
														this)
															.ftm.stringWidth("=   =   =   =    W A S T E D    =   =   =   =")) / 2)), (84 + (11 * i_220_)));
														else((Lobby) this)
															.rd.drawString("=   =   =   DISCONNECTED   =   =   =", (597 - ((((Lobby)
														this)
															.ftm.stringWidth("=   =   =   DISCONNECTED   =   =   =")) / 2)), (84 + (11 * i_220_)));
													}
													i_220_++;
												}
											}
										}
										if (((Lobby) this).wait[i_193_] == 0) stringbutton("    Watch Live Now!    ",
										561, 196, 0);
										else {
											((Lobby) this).rd.setColor(new Color(0, 0, 0));
											((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
											((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
											int i_254_ = 186;
											if (!((Lobby) this).lapsname.equals("") && !((Lobby) this)
												.wastename.equals("") && !((Lobby) this)
												.stuntname.equals("")) i_254_ = 183;
											if (((Lobby) this).gwarb[i_193_] == 0) {
												String string_255_ = "";
												for (int i_256_ = 0;
												(i_256_ < ((Lobby) this).prnpo);
												i_256_++) {
													if ((((Lobby) this).ppos[i_256_]) == 0) {
														string_255_ = (((Lobby) this)
															.prnames[i_256_]);
														break;
													}
												}
												if (string_255_.equals(""))
												((Lobby) this).rd.drawString("Game Finished!    Nobody Won!", (561 - ((((Lobby) this)
													.ftm.stringWidth("Game Finished!    Nobody Won!")) / 2)),
												i_254_);
												else {
													((Lobby) this).rd.drawString(new StringBuilder().append("Game Finished!    Winner:  ")
														.append(string_255_)
														.append("").toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("Game Finished!    Winner:  ")
														.append(string_255_)
														.append("").toString())) / 2),
													i_254_);
													if (((Lobby) this).nflk == 0) {
														((Lobby) this).rd.setColor(new Color(255,
														176,
														67));
														((Lobby) this).nflk = 3;
													} else((Lobby) this).nflk--;
													((Lobby) this).rd.drawString(new StringBuilder().append("").append(string_255_)
														.append("").toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("Game Finished!    Winner:  ")
														.append(string_255_)
														.append("").toString())) / 2 + (((Lobby) this)
														.ftm.stringWidth("Game Finished!    Winner:  "))),
													i_254_);
												}
												((Lobby) this).rd.setColor(new Color(0, 0, 0));
												((Lobby) this).rd.setFont(new Font("Arial", 0, 11));
												((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
												String string_257_ = "    ";
												int i_258_ = 0;
												if (!((Lobby) this)
													.lapsname.equals("")) {
													string_257_ = new StringBuilder().append(string_257_)
														.append("Fastest lap: ")
														.append(((Lobby) this)
														.lapsname)
														.append("    ")
														.toString();
													i_258_++;
												}
												if (!((Lobby) this)
													.wastename.equals("")) {
													string_257_ = new StringBuilder().append(string_257_)
														.append("Deadliest waster: ")
														.append(((Lobby) this)
														.wastename)
														.append("    ")
														.toString();
													i_258_++;
												}
												if (i_258_ == 2) {
													if (!((Lobby) this)
														.stuntname.equals("")) {
														((Lobby) this).rd.drawString(string_257_, (561 - ((((Lobby)
														this)
															.ftm.stringWidth(string_257_)) / 2)),
														199);
														((Lobby) this).rd.drawString(new StringBuilder().append("Best stunt: ")
															.append(((Lobby)
														this)
															.stuntname)
															.append("")
															.toString(), (561 - (((Lobby) this)
															.ftm.stringWidth(new StringBuilder().append("Best stunt: ")
															.append(((Lobby)
														this)
															.stuntname)
															.append("")
															.toString())) / 2),
														213);
													} else((Lobby) this).rd.drawString(string_257_, (561 - ((((Lobby)
													this)
														.ftm.stringWidth(string_257_)) / 2)),
													206);
												} else {
													if (!((Lobby) this)
														.stuntname.equals("")) string_257_ = new StringBuilder().append(string_257_)
														.append("Best stunt: ")
														.append(((Lobby)
													this)
														.stuntname)
														.append("    ")
														.toString();
													((Lobby) this).rd.drawString(string_257_, (561 - ((((Lobby) this)
														.ftm.stringWidth(string_257_)) / 2)),
													206);
												}
											} else if (string_197_.equals("")) {
												if (string.equals("")) {
													((Lobby) this).rd.drawString("Game Finished!    Nobody Won!", (561 - ((((Lobby) this)
														.ftm.stringWidth("Game Finished!    Nobody Won!")) / 2)),
													186);
													((Lobby) this).rd.setFont(new Font("Arial", 1,
													11));
													((Lobby) this).ftm = (((Lobby) this)
														.rd.getFontMetrics());
													((Lobby) this).rd.drawString(string_198_, (561 - ((((Lobby) this)
														.ftm.stringWidth(string_198_)) / 2)),
													206);
												} else {
													((Lobby) this).rd.drawString(new StringBuilder().append("Game Finished!    ")
														.append(string).append("  Wins!")
														.toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("Game Finished!    ")
														.append(string)
														.append("  Wins!")
														.toString())) / 2),
													196);
													if (((Lobby) this).nflk == 0) {
														((Lobby) this).rd.setColor(new Color(255,
														176,
														67));
														((Lobby) this).nflk = 3;
													} else((Lobby) this).nflk--;
													((Lobby) this).rd.drawString(new StringBuilder().append("").append(string).append("").toString(), (561 - (((Lobby) this)
														.ftm.stringWidth(new StringBuilder().append("Game Finished!    ")
														.append(string)
														.append("  Wins!")
														.toString())) / 2 + (((Lobby) this)
														.ftm.stringWidth("Game Finished!    "))),
													196);
												}
											} else {
												if (((Lobby) this).nflk == 0) {
													((Lobby) this).rd.setColor(new Color(255, 176,
													67));
													((Lobby) this).nflk = 3;
												} else((Lobby) this).nflk--;
												((Lobby) this).rd.drawString(string_197_,
												561 - (((Lobby) this)
													.ftm.stringWidth(string_197_)) / 2,
												196);
											}
										}
										((Lobby) this).rerr += 3;
									} else {
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if (((Lobby) this).prevloaded == -1) {
											if (!((xtGraphics)
											((Lobby) this).xt).lan)
											((Lobby) this).rd.drawString("Loading Info...", (561 - ((((Lobby) this)
												.ftm.stringWidth("Loading Info...")) / 2)),
											134);
											else if ((((Lobby) this).pgames[((Lobby) this).im]) == ((Lobby) this).ongame)
											((Lobby) this).rd.drawString("About to Start...", (561 - ((((Lobby) this)
												.ftm.stringWidth("About to Start...")) / 2)),
											134);
											else {
												((Lobby) this).rd.drawString("Game Started",
												561 - ((((Lobby) this)
													.ftm.stringWidth("Game Started")) / 2),
												117);
												stringbutton("    Watch this Game    ",
												561, 154, 0);
											}
										} else((Lobby) this).rd.drawString("About to Start...",
										561 - ((((Lobby) this).ftm.stringWidth("About to Start...")) / 2),
										134);
									}
								} else {
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									if (((Lobby) this).conon == 2)
									((Lobby) this).rd.drawString("Starting Game Now!", (561 - (((Lobby) this).ftm.stringWidth("Starting Game Now!")) / 2),
									124);
									if (((Lobby) this).conon == 3)
									((Lobby) this).rd.drawString("Opening Game Now!",
									561 - (((Lobby) this).ftm.stringWidth("Opening Game Now!")) / 2,
									124);
									((Lobby) this).rd.setFont(new Font("Arial",
									0, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString("Please Wait...", (561 - (((Lobby) this).ftm.stringWidth("Please Wait...") / 2)),
									154);
								}
								((Lobby) this).rd.setColor(color2k(200, 200,
								200));
								((Lobby) this).rd.drawRect(415, 222, 293, 40);
								((Lobby) this).rd.drawImage(((xtGraphics)
								(((Lobby) this)
									.xt)).stg,
								422, 227, null);
								((Lobby) this).rd.setColor(new Color(0, 0, 0));
								((Lobby) this).rd.setFont(new Font("Arial", 1,
								10));
								((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
								((Lobby) this).rd.drawString(new StringBuilder().append("Laps: ")
									.append(((Lobby) this).gnlaps[i_193_]).append("").toString(),
								660, 235);
								if (i > 415 && i < 708 && i_99_ > 222 && i_99_ < 262 && (((Lobby) this).wait[i_193_] > 0 || ((Lobby) this).gstgn[i_193_] < 0) && ((Lobby) this).conon == 1) {
									stringbutton("       Preview Stage       ",
									562, 247, 0);
									((Lobby) this).pbtn = 2;
								} else {
									if (((Lobby) this).gstgn[i_193_] > 0) {
										String string_259_ = "NFM 1";
										int i_260_ = ((Lobby) this).gstgn[i_193_];
										if (((Lobby) this).gstgn[i_193_] > 10) {
											string_259_ = "NFM 2";
											i_260_ = (((Lobby) this).gstgn[i_193_] - 10);
										}
										if (((Lobby) this).gstgn[i_193_] > 27) {
											string_259_ = "Multiplayer";
											i_260_ = (((Lobby) this).gstgn[i_193_] - 27);
										}
										((Lobby) this).rd.drawString(new StringBuilder().append("")
											.append(string_259_).append(" - Stage ").append(i_260_).append("").toString(),
										562 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(string_259_).append(" - Stage ").append(i_260_).append("").toString())) / 2,
										237);
									} else((Lobby) this).rd.drawString("Custom Stage",
									562 - (((Lobby) this).ftm.stringWidth("Custom Stage")) / 2,
									237);
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 12));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString(((Lobby) this).gstages[i_193_],
									562 - (((Lobby) this).ftm.stringWidth(((Lobby) this).gstages[i_193_])) / 2,
									254);
								}
								if (!((xtGraphics)((Lobby) this).xt).lan) {
									int i_261_ = 237;
									int i_262_ = 471;
									if (((Lobby) this).wait[i_193_] > 0) {
										if (((Lobby) this).mnpls[i_193_] > 5) {
											i_261_ = 415;
											i_262_ = 293;
										}
									} else if (((Lobby) this).npls[i_193_] > 5) {
										i_261_ = 415;
										i_262_ = 293;
									}
									((Lobby) this).rd.setColor(color2k(200, 200, 200));
									((Lobby) this).rd.drawRect(i_261_, 264,
									i_262_, 124);
									((Lobby) this).rd.setColor(color2k(240, 240, 240));
									((Lobby) this).rd.fillRect(i_261_ + 1, 265,
									i_262_ - 1, 21);
									((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).gmc,
									i_261_ + 7, 269, null);
									((Lobby) this).rd.setFont(new Font("Tahoma", 0, 11));
									((Lobby) this).rd.setColor(color2k(110, 110, 110));
									((Lobby) this).rd.drawString("( Game Chat )", i_261_ + 57, 278);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									if (((Lobby) this).updatec != -1) {
										String[] strings = new String[7];
										String[] strings_263_ = new String[7];
										boolean[] bools = {
											false, false, false, false,
											false, false, false
										};
										for (int i_264_ = 0; i_264_ < 7;
										i_264_++) {
											strings[i_264_] = "";
											strings_263_[i_264_] = (((Lobby) this).cnames[i_264_]);
											int i_265_ = 0;
											int i_266_ = 0;
											int i_267_ = 0;
											int i_268_ = 0;
											int i_269_ = 0;
											for ( /**/ ;
											(i_265_ < ((Lobby) this).sentn[i_264_].length());
											i_265_++) {
												String string_270_ = new StringBuilder()
													.append("").append(((Lobby) this)
													.sentn[i_264_].charAt(i_265_))
													.toString();
												if (string_270_.equals(" ")) {
													i_266_ = i_267_;
													i_268_ = i_265_;
													i_269_++;
												} else i_269_ = 0;
												if (i_269_ <= 1) {
													StringBuilder stringbuilder = new StringBuilder();
													String[] strings_271_ = strings;
													int i_272_ = i_264_;
													strings_271_[i_272_] = stringbuilder.append(strings_271_[i_272_])
														.append(string_270_)
														.toString();
													i_267_++;
													if ((((Lobby) this).ftm.stringWidth(strings[i_264_])) > i_262_ - 94) {
														if (i_266_ != 0) {
															strings[i_264_] = (strings[i_264_].substring(0,
															i_266_));
															for (int i_273_ = 0;
															(i_273_ < i_264_);
															i_273_++) {
																strings[i_273_] = (strings[(i_273_ + 1)]);
																strings_263_[i_273_] = (strings_263_[(i_273_ + 1)]);
																bools[i_273_] = (bools[(i_273_ + 1)]);
															}
															strings[i_264_] = "";
															bools[i_264_] = true;
															i_265_ = i_268_;
															i_267_ = 0;
															i_266_ = 0;
														} else {
															strings[i_264_] = "";
															i_267_ = 0;
														}
													}
												}
											}
										}
										String string_274_ = "";
										((Lobby) this).rd.setFont(new Font("Tahoma", 1, 11));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										for (int i_275_ = 0; i_275_ < 7;
										i_275_++) {
											if (!string_274_.equals(strings_263_[i_275_])) {
												((Lobby) this).rd.drawString(new StringBuilder().append(strings_263_[i_275_])
													.append(":").toString(), (i_261_ + 84 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append(strings_263_[i_275_])
													.append(":")
													.toString()))),
												299 + i_275_ * 14);
												string_274_ = strings_263_[i_275_];
											}
										}
										((Lobby) this).rd.setFont(new Font("Tahoma", 0, 11));
										for (int i_276_ = 0; i_276_ < 7;
										i_276_++) {
											if (bools[i_276_] && i_276_ == 0 && strings[i_276_].indexOf(" ") != -1) strings[i_276_] = new StringBuilder()
												.append("...").append(strings[i_276_].substring(strings[i_276_].indexOf(" "),
											strings[i_276_].length()))
												.append("").toString();
											((Lobby) this).rd.drawString(strings[i_276_], i_261_ + 88,
											299 + i_276_ * 14);
										}
									} else((Lobby) this).rd.drawString("Loading chat...", (i_261_ + i_262_ / 2 - (((Lobby) this).ftm.stringWidth("Loading chat...")) / 2),
									315);
									if (((Lobby) this).conon == 1)
									((Lobby) this).pre2 = true;
									else hideinputs();
									if (((Control) control).enter && !((GameSparker)((Lobby) this).gs)
										.cmsg.getText().equals("Type here...") && !((GameSparker)((Lobby) this).gs)
										.cmsg.getText().equals("")) {
										((Lobby) this).pessd[(((Lobby) this)
											.btn)] = true;
										((Control) control).enter = false;
										String string_277_ = ((GameSparker)((Lobby) this).gs)
											.cmsg.getText().replace('|', ':');
										if ((string_277_.toLowerCase().indexOf(((GameSparker)((Lobby) this).gs)
											.tpass.getText().toLowerCase())) != -1) string_277_ = " ";
										if (!((Lobby) this).xt.msgcheck(string_277_) && ((Lobby) this).updatec > -12) {
											for (int i_278_ = 0; i_278_ < 6;
											i_278_++) {
												((Lobby) this).sentn[i_278_] = (((Lobby) this).sentn[i_278_ + 1]);
												((Lobby) this).cnames[i_278_] = (((Lobby) this).cnames[i_278_ + 1]);
											}
											((Lobby) this).sentn[6] = string_277_;
											((Lobby) this).cnames[6] = (((Lobby) this).pnames[((Lobby) this).im]);
											if (((Lobby) this).updatec > -11)
											((Lobby) this).updatec = -11;
											else((Lobby) this).updatec--;
										} else((xtGraphics)((Lobby) this).xt)
											.warning++;
										((GameSparker)((Lobby) this).gs)
											.cmsg.setText("");
									}
									stringbutton("Send Message", 655, 405, 3);
								}
							} else {
								if (((GameSparker)((Lobby) this).gs).cmsg.isShowing())
								((GameSparker)((Lobby) this).gs).cmsg.hide();
								if (((((Lobby) this).pcars[((Lobby) this).dispcar]) == ((Lobby) this).forcar) && ((Lobby) this).forcar != -1) {
									((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).crd,
									517, 81, null);
									((Lobby) this).rd.setColor(new Color(16, 198, 255));
									((Lobby) this).rd.drawRect(415, 96, 293,
									315);
									((Lobby) this).rd.setColor(color2k(240, 240, 240));
									((Lobby) this).rd.fillRect(416, 97, 4,
									314);
									((Lobby) this).rd.fillRect(704, 97, 4,
									314);
									((Lobby) this).rd.fillRect(416, 97, 292,
									4);
									((Lobby) this).rd.fillRect(416, 407, 292,
									4);
									if (((Lobby) this).flks >= 0) {
										((Lobby) this).rd.setColor(new Color(239, 234, 177));
										((Lobby) this).flks++;
										if (((Lobby) this).flks > 3)
										((Lobby) this).flks = -1;
									} else {
										((Lobby) this).rd.setColor(new Color(224, 226, 176));
										((Lobby) this).flks--;
										if (((Lobby) this).flks < -4)
										((Lobby) this).flks = 0;
									}
									((Lobby) this).rd.fillRect(445, 120, 233,
									127);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 13));
									((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
									((Lobby) this).rd.drawString((((CarDefine)((Lobby) this).cd).names[((Lobby) this).forcar]), (561 - ((((Lobby) this).ftm.stringWidth(((CarDefine)((Lobby) this).cd)
										.names[((Lobby) this).forcar])) / 2)),
									117);
									for (int i_279_ = 0;
									(i_279_ < (((ContO)((Lobby) this).dispco)
										.npl));
									i_279_++) {
										if (((Plane)
										(((ContO)
										contos[((Lobby) this).forcar])
											.p[i_279_])).colnum == 1) {
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[0] = (((Lobby) this).pcols[((Lobby) this).dispcar]
											[0]);
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[1] = (((Lobby) this).pcols[((Lobby) this).dispcar]
											[1]);
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[2] = (1.0F - (((Lobby) this).pcols[((Lobby) this).dispcar]
											[2]));
										}
										if (((Plane)
										(((ContO)
										contos[((Lobby) this).forcar])
											.p[i_279_])).colnum == 2) {
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[0] = (((Lobby) this).pcols[((Lobby) this).dispcar]
											[3]);
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[1] = (((Lobby) this).pcols[((Lobby) this).dispcar]
											[4]);
											((Plane)
											(((ContO)((Lobby) this).dispco).p[i_279_])).hsb[2] = (1.0F - (((Lobby) this).pcols[((Lobby) this).dispcar]
											[5]));
										}
									}
									((Medium)((Lobby) this).m).cx = 561;
									((ContO)((Lobby) this).dispco).z = 1200;
									((ContO)((Lobby) this).dispco).y = 605 - ((ContO)
									((Lobby) this).dispco).grat;
									((ContO)((Lobby) this).dispco).x = 225;
									((ContO)((Lobby) this).dispco).zy = 0;
									((ContO)((Lobby) this).dispco).xz = ((Lobby) this).mrot;
									((Lobby) this).mrot -= 5;
									if (((Lobby) this).mrot < -360)
									((Lobby) this).mrot += 360;
									((ContO)((Lobby) this).dispco).xy = 0;
									((ContO)((Lobby) this).dispco).wzy -= 10;
									if (((ContO)((Lobby) this).dispco).wzy < -45)
									((ContO)((Lobby) this).dispco).wzy += 45;
									((Lobby) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
									RenderingHints.VALUE_ANTIALIAS_OFF);
									((Lobby) this).dispco.d(((Lobby) this).rd);
									((Lobby) this).rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
									RenderingHints.VALUE_ANTIALIAS_ON);
									((Medium)((Lobby) this).m).cx = 400;
									((Lobby) this).rd.setFont(new Font("Arial",
									1, 11));
									int i_280_ = 424;
									int i_281_ = -55;
									((Lobby) this).rd.setColor(new Color(0, 63,
									128));
									((Lobby) this).rd.drawString("Top Speed:",
									30 + i_280_,
									318 + i_281_);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statb),
									97 + i_280_, 312 + i_281_, null);
									((Lobby) this).rd.drawString("Acceleration:", 20 + i_280_,
									333 + i_281_);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statb),
									97 + i_280_, 327 + i_281_, null);
									((Lobby) this).rd.setColor(color2k(255, 255, 255));
									float f = (float)((((CarDefine)
									((Lobby) this).cd)
										.swits[((Lobby) this).forcar][2]) - 220) / 90.0F;
									if ((double) f < 0.2) f = 0.2F;
									((Lobby) this).rd.fillRect((int)(97.0F + 156.0F * f) + i_280_,
									312 + i_281_, (int)(156.0F * (1.0F - f) + 1.0F),
									7);
									f = ((((CarDefine)((Lobby) this).cd).acelf[((Lobby) this).forcar][1]) * (((CarDefine)((Lobby) this).cd)
										.acelf[((Lobby) this).forcar][0]) * (((CarDefine)((Lobby) this).cd)
										.acelf[((Lobby) this).forcar][2]) * (((CarDefine)((Lobby) this).cd)
										.grip[((Lobby) this).forcar]) / 7700.0F);
									if (f > 1.0F) f = 1.0F;
									((Lobby) this).rd.fillRect((int)(97.0F + 156.0F * f) + i_280_,
									327 + i_281_, (int)(156.0F * (1.0F - f) + 1.0F),
									7);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statbo),
									97 + i_280_, 312 + i_281_, null);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statbo),
									97 + i_280_, 327 + i_281_, null);
									i_280_ = 50;
									i_281_ = -25;
									((Lobby) this).rd.setColor(new Color(0, 63,
									128));
									((Lobby) this).rd.drawString("Stunts:",
									427 + i_280_,
									318 + i_281_);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statb),
									471 + i_280_, 312 + i_281_, null);
									((Lobby) this).rd.drawString("Strength:",
									415 + i_280_,
									333 + i_281_);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statb),
									471 + i_280_, 327 + i_281_, null);
									((Lobby) this).rd.drawString("Endurance:",
									405 + i_280_,
									348 + i_281_);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statb),
									471 + i_280_, 342 + i_281_, null);
									((Lobby) this).rd.setColor(color2k(255, 255, 255));
									f = (((float)(((CarDefine)
									((Lobby) this).cd)
										.airc[((Lobby) this).forcar]) * (((CarDefine)((Lobby) this).cd)
										.airs[((Lobby) this).forcar]) * (((CarDefine)((Lobby) this).cd)
										.bounce[((Lobby) this).forcar])) + 28.0F) / 139.0F;
									if (f > 1.0F) f = 1.0F;
									((Lobby) this).rd.fillRect((int)(471.0F + 156.0F * f) + i_280_,
									312 + i_281_, (int)(156.0F * (1.0F - f) + 1.0F),
									7);
									float f_282_ = 0.5F;
									f = ((((CarDefine)((Lobby) this).cd)
										.moment[((Lobby) this).forcar]) + f_282_) / 2.6F;
									if (f > 1.0F) f = 1.0F;
									((Lobby) this).rd.fillRect((int)(471.0F + 156.0F * f) + i_280_,
									327 + i_281_, (int)(156.0F * (1.0F - f) + 1.0F),
									7);
									f = (((CarDefine)((Lobby) this).cd).outdam[((Lobby) this).forcar]);
									((Lobby) this).rd.fillRect((int)(471.0F + 156.0F * f) + i_280_,
									342 + i_281_, (int)(156.0F * (1.0F - f) + 1.0F),
									7);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statbo),
									471 + i_280_, 312 + i_281_, null);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statbo),
									471 + i_280_, 327 + i_281_, null);
									((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
										.statbo),
									471 + i_280_, 342 + i_281_, null);
									((Lobby) this).rd.setColor(new Color(0, 0,
									0));
									if (((Lobby) this).forcar < 16) {
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("Created by Radicalplay.com", (561 - ((((Lobby) this).ftm.stringWidth("Created by Radicalplay.com")) / 2)),
										347);
										String string_283_ = "Game Car";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 0) string_283_ = "Class C ,  Game Car";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 1) string_283_ = "Class B & C ,  Game Car";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 2) string_283_ = "Class B ,  Game Car";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 3) string_283_ = "Class A & B ,  Game Car";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 4) string_283_ = "Class A ,  Game Car";
										((Lobby) this).rd.drawString(string_283_, (561 - (((Lobby) this).ftm.stringWidth(string_283_) / 2)),
										367);
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										((Lobby) this).rd.drawString("You already have this car.", (561 - ((((Lobby) this).ftm.stringWidth("You already have this car.")) / 2)),
										395);
									} else {
										((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if (!((CarDefine)((Lobby) this).cd)
											.createdby[((Lobby) this).forcar - 16].equals(((xtGraphics)((Lobby) this).xt)
											.nickname)) {
											((Lobby) this).rd.drawString(new StringBuilder().append("Created by :  ").append(((CarDefine)
											((Lobby) this).cd)
												.createdby[(((Lobby) this).forcar - 16)])
												.append("").toString(), (561 - ((((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("Created by :  ")
												.append(((CarDefine)
											((Lobby) this).cd)
												.createdby[(((Lobby) this)
												.forcar) - 16])
												.append("").toString())) / 2)),
											347);
											int i_284_ = (((Lobby) this).ftm.stringWidth(((CarDefine)
											((Lobby) this).cd)
												.createdby[(((Lobby) this).forcar - 16)]));
											int i_285_ = (561 - (((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("Created by :  ")
												.append(((CarDefine)
											((Lobby) this).cd)
												.createdby[(((Lobby) this)
												.forcar) - 16])
												.append("")
												.toString())) / 2 + (((Lobby) this).ftm.stringWidth(new StringBuilder()
												.append("Created by :  ")
												.append(((CarDefine)
											((Lobby) this).cd)
												.createdby[(((Lobby) this)
												.forcar) - 16])
												.append("").toString())) - i_284_);
											((Lobby) this).rd.drawLine(i_285_, 349,
											i_285_ + i_284_ - 2, 349);
											if (i > i_285_ - 2 && i < i_285_ + i_284_ && i_99_ > 334 && i_99_ < 351) {
												if (bool) {
													if (!((Globe)
													((Lobby) this).gb)
														.proname.equals(((CarDefine)
													((Lobby) this).cd)
														.createdby[(((Lobby) this)
														.forcar) - 16])) {
														((Globe)
														((Lobby) this).gb)
															.proname = (((CarDefine)
														(((Lobby) this)
															.cd))
															.createdby[(((Lobby)
														this).forcar - 16)]);
														((Globe)
														((Lobby) this).gb)
															.loadedp = false;
													}
													((Globe)((Lobby) this).gb)
														.tab = 1;
													((Globe)((Lobby) this).gb)
														.open = 2;
													((Globe)((Lobby) this).gb)
														.upo = true;
												}
												i_101_ = 12;
											}
										} else((Lobby) this).rd.drawString("Created by You",
										561 - ((((Lobby) this).ftm.stringWidth("Created by You")) / 2),
										347);
										((Lobby) this).rd.setColor(new Color(128, 73, 0));
										String string_286_ = "";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 0) string_286_ = "Class C ,  ";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 1) string_286_ = "Class B & C ,  ";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 2) string_286_ = "Class B ,  ";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 3) string_286_ = "Class A & B ,  ";
										if ((((CarDefine)((Lobby) this).cd)
											.cclass[((Lobby) this).forcar]) == 4) string_286_ = "Class A ,  ";
										if ((((CarDefine)((Lobby) this).cd)
											.publish[((Lobby) this).forcar - 16]) == 0) string_286_ = new StringBuilder().append(string_286_).append("Private Car")
											.toString();
										if ((((CarDefine)((Lobby) this).cd)
											.publish[((Lobby) this).forcar - 16]) == 1) {
											string_286_ = new StringBuilder().append(string_286_).append("Public Car")
												.toString();
											((Lobby) this).rd.setColor(new Color(0, 64, 128));
										}
										if ((((CarDefine)((Lobby) this).cd)
											.publish[((Lobby) this).forcar - 16]) == 2) {
											string_286_ = new StringBuilder().append(string_286_).append("Super Public Car")
												.toString();
											((Lobby) this).rd.setColor(new Color(0, 64, 128));
										}
										((Lobby) this).rd.drawString(string_286_, (561 - (((Lobby) this).ftm.stringWidth(string_286_) / 2)),
										367);
										((Lobby) this).rd.setColor(new Color(0, 0, 0));
										((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
										((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
										if ((((CarDefine)((Lobby) this).cd)
											.publish[((Lobby) this).forcar - 16]) == 1 || (((CarDefine)((Lobby) this).cd)
											.publish[(((Lobby) this).forcar - 16)]) == 2) {
											if (((CarDefine)
											((Lobby) this).cd).action == -9)
											((Lobby) this).rd.drawString("Failed to add car!  Unknown error!", (561 - ((((Lobby) this)
												.ftm.stringWidth("Failed to add car!  Unknown error!")) / 2)),
											395);
											if (((CarDefine)
											((Lobby) this).cd).action == -8)
											((Lobby) this).rd.drawString("Failed!  You already have 20 cars!", (561 - ((((Lobby) this)
												.ftm.stringWidth("Failed!  You already have 20 cars!")) / 2)),
											395);
											if (((CarDefine)
											((Lobby) this).cd).action == 7)
											((Lobby) this).rd.drawString(new StringBuilder().append("").append(((CarDefine)
											((Lobby) this).cd)
												.names[(((CarDefine)
											((Lobby) this).cd)
												.ac)])
												.append(" has been added to your cars!")
												.toString(), (561 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("").append(((CarDefine)
											(((Lobby) this)
												.cd))
												.names[(((CarDefine)
											((Lobby)
											this).cd)
												.ac)])
												.append(" has been added to your cars!")
												.toString())) / 2),
											395);
											if (((CarDefine)
											((Lobby) this).cd).action == -7)
											((Lobby) this).rd.drawString("You already have this car.", (561 - ((((Lobby) this)
												.ftm.stringWidth("You already have this car.")) / 2)),
											395);
											if (((CarDefine)
											((Lobby) this).cd).action == 6)
											((Lobby) this).rd.drawString("Adding Car...",
											561 - ((((Lobby) this)
												.ftm.stringWidth("Adding Car...")) / 2),
											395);
											if (((CarDefine)
											((Lobby) this).cd).action == -6) {
												String string_287_ = "Upgrade to a full account to add custom cars!";
												int i_288_ = (561 - (((Lobby) this)
													.ftm.stringWidth(string_287_)) / 2);
												int i_289_ = (i_288_ + (((Lobby) this)
													.ftm.stringWidth(string_287_)));
												((Lobby) this).rd.drawString(string_287_, i_288_, 395);
												if (((Lobby) this).waitlink != -1)
												((Lobby) this).rd.drawLine(i_288_, 396, i_289_,
												396);
												if (i > i_288_ && i < i_289_ && i_99_ > 384 && i_99_ < 397) {
													if (((Lobby) this).waitlink != -1) i_101_ = 12;
													if (bool && (((Lobby) this)
														.waitlink) == 0) {
														((Lobby) this).gs.editlink(((xtGraphics)
														(((Lobby) this)
															.xt)).nickname,
														true);
														((Lobby) this).waitlink = -1;
													}
												}
												if (((Lobby) this).waitlink > 0)
												((Lobby) this).waitlink--;
											}
											if (((CarDefine)
											((Lobby) this).cd).action == 0 && (((Lobby) this).xt.drawcarb(true, null,
												" Add to My Cars ", 503,
											375, i, i_99_, bool))) {
												if (((xtGraphics)
												((Lobby) this).xt)
													.logged) {
													if ((((CarDefine)
													((Lobby) this).cd)
														.lastload) != 2 || (((Lobby) this)
														.forcar) >= 36) {
														((CarDefine)
														((Lobby) this).cd)
															.action = 6;
														((CarDefine)
														((Lobby) this).cd).ac = (((Lobby) this)
															.forcar);
														((Lobby) this).cd.sparkactionloader();
													} else((CarDefine)
													((Lobby) this).cd)
														.action = -7;
												} else {
													((CarDefine)
													((Lobby) this).cd).action = -6;
													((Lobby) this).waitlink = 20;
												}
											}
										} else((Lobby) this).rd.drawString("Private Car.  Cannot be added to account.", (561 - ((((Lobby) this).ftm.stringWidth("Private Car.  Cannot be added to account.")) / 2)),
										395);
									}
									if (((Lobby) this).xt.drawcarb(true, null,
										"X", 682,
									99, i,
									i_99_,
									bool))
									((Lobby) this).dispcar = -1;
								} else((Lobby) this).dispcar = -1;
							}
						}
					}
				} else {
					if (!((Lobby) this).jflexo) {
						((Lobby) this).xt.jflexo();
						((Lobby) this).jflexo = true;
					}
					((Lobby) this).btn = 0;
					if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
						((GameSparker)((Lobby) this).gs).cmsg.hide();
						((Lobby) this).gs.requestFocus();
					}
					((Lobby) this).rd.setColor(color2k(255, 255, 255));
					((Lobby) this).rd.fillRoundRect(155, 148, 490, 127, 20,
					20);
					((Lobby) this).rd.setColor(new Color(0, 0, 0));
					((Lobby) this).rd.drawRoundRect(155, 148, 490, 127, 20,
					20);
					if (((Lobby) this).ontyp != 76) {
						String string = "";
						int i_290_ = 0;
						if (((Lobby) this).ontyp >= 10) {
							i_290_ = 10;
							string = "Custom Cars";
							if (((Lobby) this).ontyp > 10) string = new StringBuilder().append(string).append(", ").toString();
						}
						if (((Lobby) this).ontyp >= 20) {
							i_290_ = 20;
							string = "Game Cars";
							if (((Lobby) this).ontyp > 20) string = new StringBuilder().append(string).append(", ").toString();
						}
						if (((Lobby) this).ontyp >= 30) {
							i_290_ = 30;
							string = "Clan Cars";
							if (((Lobby) this).ontyp > 30) string = new StringBuilder().append(string).append(", ").toString();
						}
						if (((Lobby) this).ontyp - i_290_ == 1) string = new StringBuilder().append(string).append("Class C").toString();
						if (((Lobby) this).ontyp - i_290_ == 2) string = new StringBuilder().append(string).append("Class B & C").toString();
						if (((Lobby) this).ontyp - i_290_ == 3) string = new StringBuilder().append(string).append("Class B").toString();
						if (((Lobby) this).ontyp - i_290_ == 4) string = new StringBuilder().append(string).append("Class A & B").toString();
						if (((Lobby) this).ontyp - i_290_ == 5) string = new StringBuilder().append(string).append("Class A").toString();
						if (((Lobby) this).ontyp <= -2) {
							if (Math.abs(((Lobby) this).ontyp + 2) == 13) string = new StringBuilder().append(" ").append(((CarDefine)((Lobby) this).cd)
								.names[Math.abs(((Lobby) this).ontyp + 2)])
								.append("  Game").toString();
							else string = new StringBuilder().append("").append(((CarDefine)((Lobby) this).cd)
								.names[Math.abs(((Lobby) this).ontyp + 2)])
								.append(" Game").toString();
						}
						((Lobby) this).rd.setColor(new Color(0, 0, 0));
						((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
						((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
						((Lobby) this).rd.drawString(new StringBuilder().append(": :   ").append(string).append("   : :").toString(),
						400 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append(": :   ")
							.append(string).append("   : :").toString())) / 2,
						175);
						string = "a";
						if (((Lobby) this).ontyp - i_290_ == 1) string = "a class C";
						if (((Lobby) this).ontyp - i_290_ == 2) string = "a class B or C";
						if (((Lobby) this).ontyp - i_290_ == 3) string = "a class B";
						if (((Lobby) this).ontyp - i_290_ == 4) string = "a class A or B";
						if (((Lobby) this).ontyp - i_290_ == 5) string = "a class A";
						if (i_290_ == 0) string = new StringBuilder().append(string).append(" car").toString();
						if (i_290_ == 10) string = new StringBuilder().append(string).append(" custom car").toString();
						if (i_290_ == 20) string = new StringBuilder().append(string).append(" game car").toString();
						if (i_290_ == 30) string = new StringBuilder().append(string).append(" clan car").toString();
						if (((Lobby) this).ontyp <= -2) {
							if (Math.abs(((Lobby) this).ontyp + 2) == 13) string = new StringBuilder().append(" ").append(((CarDefine)((Lobby) this).cd)
								.names[Math.abs(((Lobby) this).ontyp + 2)])
								.append(" ").toString();
							else string = new StringBuilder().append("").append(((CarDefine)((Lobby) this).cd)
								.names[Math.abs(((Lobby) this).ontyp + 2)])
								.append("").toString();
						}
						((Lobby) this).rd.drawString(new StringBuilder().append("To join this game you need to have ").append(string).append("!").toString(), (400 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("To join this game you need to have ")
							.append(string).append("!").toString())) / 2),
						206);
						stringbutton(new StringBuilder().append("  Get ")
							.append(string).append(" now  ").toString(),
						400, 247, 0);
						stringbutton("  Cancel X  ", 593, 259, 2);
						if (((Globe)((Lobby) this).gb).open > 0 && ((Globe)((Lobby) this).gb).upo)
						((Lobby) this).onjoin = -1;
					} else {
						((Lobby) this).rd.setColor(new Color(0, 0, 0));
						((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
						((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
						((Lobby) this).rd.drawString(": :   Custom Stage   : :", (400 - (((Lobby) this).ftm.stringWidth(": :   Custom Stage   : :") / 2)),
						175);
						((Lobby) this).rd.drawString("You need to upgrade to a full account to join this game!", (400 - ((((Lobby) this).ftm.stringWidth("You need to upgrade to a full account to join this game!")) / 2)),
						202);
						((Lobby) this).rd.setColor(color2k(200, 200, 200));
						((Lobby) this).rd.fillRoundRect(310, 215, 180, 50, 20,
						20);
						drawSbutton(((xtGraphics)((Lobby) this).xt).upgrade,
						400, 240);
						stringbutton("  Cancel X  ", 593, 259, 2);
					}
				}
			} else {
				((Lobby) this).xt.mainbg(3);
				((Lobby) this).btn = 0;
				if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
					((GameSparker)((Lobby) this).gs).cmsg.hide();
					((Lobby) this).gs.requestFocus();
				}
				((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
				((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt)
					.bggo),
				0, 0, null);
				((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				((Lobby) this).rd.setColor(new Color(0, 0, 0));
				((Lobby) this).rd.fillRect(65, 425, 670, 25);
				((Lobby) this).rd.fillRect(0, 0, 65, 450);
				((Lobby) this).rd.fillRect(735, 0, 65, 450);
				((Lobby) this).rd.fillRect(65, 0, 670, 25);
				float f = 1.0F - (float)(((Login)((Lobby) this).lg).flipo - 10) / 80.0F;
				if (f > 1.0F) f = 1.0F;
				if (f < 0.0F) f = 0.0F;
				((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3,
				f));
				if (((Login)((Lobby) this).lg).flipo > 10)
				((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).logomadnes,
				97 + (int)(2.0 - Math.random() * 4.0),
				36 + (int)(2.0 - Math.random() * 4.0), null);
				else((Lobby) this).rd.drawImage(((xtGraphics)
				((Lobby) this).xt).logomadnes,
				97, 36, null);
				((Login)((Lobby) this).lg).flipo++;
				if (((Login)((Lobby) this).lg).flipo > 50)
				((Login)((Lobby) this).lg).flipo = 0;
				int i_291_ = 30;
				((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
				((Lobby) this).rd.setColor(new Color(203, 227, 253));
				((Lobby) this).rd.fillRoundRect(115, 57 + i_291_, 570, 307, 20,
				20);
				((Lobby) this).rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
				((Lobby) this).rd.setColor(color2k(90, 90, 90));
				((Lobby) this).rd.drawRoundRect(115, 57 + i_291_, 570, 307, 20,
				20);
				((Lobby) this).rd.setFont(new Font("Arial", 1, 13));
				((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
				((Lobby) this).rd.setColor(color2k(0, 0, 0));
				((Lobby) this).rd.drawString("You are allowed 5 multiplayer turns per day to try the game with your trial account.",
				135, 85 + i_291_);
				((Lobby) this).rd.drawString("Upgrade your account to a full account to purchase and play the multiplayer game.",
				135, 105 + i_291_);
				drawSbutton(((xtGraphics)((Lobby) this).xt).upgrade, 400,
				130 + i_291_);
				((Lobby) this).rd.setColor(new Color(30, 70, 110));
				((Lobby) this).rd.drawString("You can upgrade your account by just sharing the game & posting about it online!",
				135, 165 + i_291_);
				((Lobby) this).rd.drawString("Click 'Upgrade' for more details.", 135, 185 + i_291_);
				((Lobby) this).rd.drawString("Or try the multiplayer again tomorrow.", 135,
				205 + i_291_);
				((Lobby) this).rd.setColor(color2k(0, 0, 0));
				((Lobby) this).rd.drawString("For now to preview and try the multiplayer more, with your trial account you can:",
				135, 245 + i_291_);
				((Lobby) this).rd.setColor(new Color(30, 70, 110));
				((Lobby) this).rd.drawString("-  Watch online multiplayer games.", 135, 265 + i_291_);
				((Lobby) this).rd.drawString("-  Access the multiplayer dome.",
				135, 285 + i_291_);
				((Lobby) this).rd.drawString("-  Play LAN multiplayer games (unlimitedly).", 135,
				305 + i_291_);
				drawSbutton(((xtGraphics)((Lobby) this).xt).exit, 400,
				336 + i_291_);
			}
		} else {
			((Lobby) this).xt.drawWarning();
			if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
				((GameSparker)((Lobby) this).gs).cmsg.hide();
				((Lobby) this).gs.requestFocus();
			}
			if (((xtGraphics)((Lobby) this).xt).warning > 220) {
				((Lobby) this).conon = 0;
				try {
					((Lobby) this).socket.close();
					((Lobby) this).socket = null;
					((Lobby) this).din.close();
					((Lobby) this).din = null;
					((Lobby) this).dout.close();
					((Lobby) this).dout = null;
				} catch (Exception exception) {
					/* empty */
				}
			}
			((xtGraphics)((Lobby) this).xt).warning++;
		}
		if (i_101_ != ((Lobby) this).pcurs) {
			((Lobby) this).gs.setCursor(new Cursor(i_101_));
			((Lobby) this).pcurs = i_101_;
		}
	}

	public void preforma(int i, int i_292_) {
		if (((Lobby) this).pre1) {
			boolean bool = false;
			if (!((GameSparker)((Lobby) this).gs).openm && ((Globe)((Lobby) this).gb).open == 0) {
				if (((Lobby) this).conon != 0) bool = true;
			} else if (((GameSparker)((Lobby) this).gs).cmsg.isShowing())
			((GameSparker)((Lobby) this).gs).cmsg.hide();
			((Lobby) this).gs.movefieldd((((GameSparker)((Lobby) this).gs)
				.cmsg),
			235, 390, 360, 22, bool);
			if (((GameSparker)((Lobby) this).gs).cmsg.getText()
				.equals("Type here...") && i > 234 && i < 603 && i_292_ > 385 && i_292_ < 417)
			((GameSparker)((Lobby) this).gs).cmsg.setText("");
		}
		if (((Lobby) this).pre2) {
			boolean bool = false;
			if (!((GameSparker)((Lobby) this).gs).openm && ((Globe)((Lobby) this).gb).open == 0) bool = true;
			else if (((GameSparker)((Lobby) this).gs).cmsg.isShowing())
			((GameSparker)((Lobby) this).gs).cmsg.hide();
			((Lobby) this).gs.movefieldd((((GameSparker)((Lobby) this).gs)
				.cmsg),
			237, 390, 360, 22, bool);
			if (((GameSparker)((Lobby) this).gs).cmsg.getText()
				.equals("Type here...") && i > 232 && i < 601 && i_292_ > 385 && i_292_ < 417)
			((GameSparker)((Lobby) this).gs).cmsg.setText("");
		}
		if (((Lobby) this).pre1 || ((Lobby) this).pre2) {
			if (((GameSparker)((Lobby) this).gs).cmsg.getText().length() > 100) {
				((GameSparker)((Lobby) this).gs).cmsg.setText(((GameSparker)((Lobby) this).gs).cmsg.getText()
					.substring(0, 100));
				((GameSparker)((Lobby) this).gs).cmsg.select(100, 100);
			}
			((Lobby) this).pre1 = false;
			((Lobby) this).pre2 = false;
		}
	}

	public void stageselect(CheckPoints checkpoints, Control control, int i,
	int i_293_, boolean bool) {
		((Lobby) this).rd.setColor(new Color(0, 0, 0));
		((Lobby) this).rd.fillRect(0, 0, 65, 450);
		((Lobby) this).rd.fillRect(735, 0, 65, 450);
		((Lobby) this).rd.fillRect(65, 0, 670, 25);
		((Lobby) this).rd.fillRect(65, 425, 670, 25);
		((Lobby) this).btn = 0;
		int i_294_ = 0;
		((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).br, 65,
		25, null);
		if (((Lobby) this).britchl == -1) {
			((Lobby) this).ongame = -1;
			((Lobby) this).britchl = 0;
		}
		int i_295_ = 0;
		for (int i_296_ = 0; i_296_ < ((Lobby) this).ngm; i_296_++) {
			if (((Lobby) this).ongame == ((Lobby) this).gnum[i_296_]) i_295_ = i_296_;
		}
		if (((Lobby) this).chalngd != -2 && ((Lobby) this).ongame != -1) {
			((Lobby) this).rd.setColor(color2k(20, 20, 20));
			((Lobby) this).rd.fillRect(80, 0, 640, 40);
			((Lobby) this).rd.setColor(color2k(70, 70, 70));
			((Lobby) this).rd.drawLine(80, 40, 720, 40);
			((Lobby) this).rd.drawLine(80, 40, 80, 0);
			((Lobby) this).rd.drawLine(720, 40, 720, 0);
			((Lobby) this).rd.setColor(new Color(193, 106, 0));
			((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
			((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
			if (((Lobby) this).wait[i_295_] > 0) {
				if (((Lobby) this).gwarb[i_295_] == 0) {
					if (((Lobby) this).wait[i_295_] > 30 || ((Lobby) this).npls[i_295_] <= 1) {
						String string = "";
						if (((Lobby) this).npls[i_295_] > 1) {
							Date date = new Date();
							long l = date.getTime();
							if (((Lobby) this).ptime == 0L || l > ((Lobby) this).ptime + 1500L) {
								if (((Lobby) this).ptime != 0L) {
									((Lobby) this).wait[i_295_]--;
									if (((Lobby) this).wait[i_295_] < 1)
									((Lobby) this).wait[i_295_] = 1;
								}
								((Lobby) this).ptime = l;
							}
							string = new StringBuilder().append(" (waiting ").append(((Lobby) this).wait[i_295_]).append(" seconds maximum)").toString();
							if (((Lobby) this).wait[i_295_] > 60) string = new StringBuilder().append(" (waiting ").append((float)(int)((float)(((Lobby)
							this)
								.wait[i_295_]) / 60.0F * 100.0F) / 100.0F)
								.append(" minutes maximum)").toString();
						}
						((Lobby) this).rd.drawString(new StringBuilder().append("Waiting for ").append(((Lobby) this).mnpls[i_295_] - ((Lobby) this).npls[i_295_])
							.append(" more players to join to start this game")
							.append(string).append("!").toString(),
						95, 15);
						((Lobby) this).rd.setFont(new Font("Arial", 0, 12));
						if (!((Lobby) this).gmaker[i_295_].equals("Coach Insano") && !(((Lobby) this).gmaker[i_295_].equals(((Lobby) this).pnames[((Lobby) this).im]))) {
							boolean bool_297_ = false;
							for (int i_298_ = 0; i_298_ < ((Lobby) this).npo;
							i_298_++) {
								if ((((Lobby) this).pgames[i_298_] == ((Lobby) this).ongame) && (((Lobby) this).gmaker[i_295_].equals(((Lobby) this).pnames[i_298_]))) bool_297_ = true;
							}
							if (bool_297_)
							((Lobby) this).rd.drawString(new StringBuilder().append("").append(((Lobby) this).gmaker[i_295_]).append(" can start this game at anytime (the game creator)...")
								.toString(),
							95, 31);
						}
					} else {
						Date date = new Date();
						long l = date.getTime();
						if (((Lobby) this).ptime == 0L || l > ((Lobby) this).ptime + 1500L) {
							if (((Lobby) this).ptime != 0L) {
								((Lobby) this).wait[i_295_]--;
								if (((Lobby) this).wait[i_295_] < 1)
								((Lobby) this).wait[i_295_] = 1;
							}
							((Lobby) this).ptime = l;
						}
						if ((((Lobby) this).pgames[((Lobby) this).im] == ((Lobby) this).ongame) || ((Lobby) this).nflk != 0) {
							((Lobby) this).rd.drawString(new StringBuilder().append("Game starts in ").append(((Lobby) this).wait[i_295_]).append(" seconds!").toString(),
							400 - (((Lobby) this).ftm.stringWidth(new StringBuilder().append("Game starts in ").append(((Lobby) this).wait[i_295_])
								.append(" seconds!").toString())) / 2,
							23);
							if (((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).ongame)
							((Lobby) this).nflk--;
						} else if (((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).ongame)
						((Lobby) this).nflk = 3;
					}
				} else((Lobby) this).rd.drawString(new StringBuilder().append("Waiting for ").append(((Lobby) this).mnpls[i_295_] - ((Lobby) this).npls[i_295_])
					.append(" clan members to join to start this game!")
					.toString(),
				95, 23);
				if (((Lobby) this).pgames[((Lobby) this).im] != ((Lobby) this).ongame) {
					boolean bool_299_ = false;
					if (((Lobby) this).gwarb[i_295_] == 0) {
						if (((Lobby) this).gplyrs[i_295_].equals("") || ((((Lobby) this).gplyrs[i_295_].indexOf(((Lobby) this).pnames[((Lobby) this).im])) != -1)) bool_299_ = true;
					} else if ((((xtGraphics)((Lobby) this).xt).clan.toLowerCase().equals(((Lobby) this).gaclan[i_295_].toLowerCase())) || (((xtGraphics)((Lobby) this).xt).clan.toLowerCase().equals(((Lobby) this).gvclan[i_295_].toLowerCase()))) bool_299_ = true;
					if (bool_299_) stringbutton(" Join Game ", 660, 23, 2);
				}
			} else {
				((Lobby) this).rd.setColor(color2k(120, 120, 120));
				if (((Lobby) this).wait[i_295_] == 0)
				((Lobby) this).rd.drawString("Game Started",
				400 - (((Lobby) this).ftm.stringWidth("Game Started") / 2),
				20);
				else((Lobby) this).rd.drawString("Game Finished",
				400 - (((Lobby) this).ftm.stringWidth("Game Finished") / 2),
				20);
			}
		}
		((Lobby) this).rd.setFont(new Font("Arial", 1, 11));
		((xtGraphics)((Lobby) this).xt).ftm = ((Lobby) this).rd.getFontMetrics();
		((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
		String string = "";
		if (((CheckPoints) checkpoints).stage < 0) string = "Custom Stage";
		if (((CheckPoints) checkpoints).stage > 0 && ((CheckPoints) checkpoints).stage <= 10) string = new StringBuilder().append("Stage ").append(((CheckPoints) checkpoints).stage).append(" NFM 1").toString();
		if (((CheckPoints) checkpoints).stage > 10 && ((CheckPoints) checkpoints).stage <= 27) string = new StringBuilder().append("Stage ").append(((CheckPoints) checkpoints).stage - 10).append(" NFM 2").toString();
		if (((CheckPoints) checkpoints).stage > 27) string = new StringBuilder().append("Multiplayer Stage ").append(((CheckPoints) checkpoints).stage - 27).append("").toString();
		((Lobby) this).xt.drawcs(85, new StringBuilder().append("Previewing ").append(string).append("  >").toString(), 255, 138, 0, 5);
		((Lobby) this).xt.drawcs(105,
		new StringBuilder().append("| ").append(((CheckPoints) checkpoints).name).append(" |").toString(),
		255, 176, 85, 5);
		((Lobby) this).rd.drawImage((((xtGraphics)((Lobby) this).xt).back[((Lobby) this).pback]),
		532, 285, null);
		if (((Lobby) this).plsndt == 0) {
			String string_300_ = "Play Soundtrack >";
			int i_301_ = 562 - ((Lobby) this).ftm.stringWidth(string_300_) / 2;
			int i_302_ = i_301_ + ((Lobby) this).ftm.stringWidth(string_300_);
			((Lobby) this).rd.setColor(new Color(0, 0, 0));
			((Lobby) this).rd.drawString(string_300_, i_301_ + 1, 326);
			((Lobby) this).rd.drawLine(i_301_ + 1, 328, i_302_ + 1, 328);
			((Lobby) this).rd.setColor(new Color(255, 138, 0));
			((Lobby) this).rd.drawString(string_300_, i_301_, 325);
			((Lobby) this).rd.drawLine(i_301_, 327, i_302_, 327);
			if (i > i_301_ && i < i_302_ && i_293_ > 314 && i_293_ < 327) {
				i_294_ = 12;
				if (bool)
				((Lobby) this).plsndt = 1;
			}
		}
		if (((Lobby) this).plsndt == 1)
		((Lobby) this).xt.drawcs(190, "Loading Soundtrack, please wait...",
		255, 138, 0, 5);
		if (((CheckPoints) checkpoints).stage < 0) {
			((Lobby) this).rd.setColor(new Color(255, 138, 0));
			((Lobby) this).rd.drawString(new StringBuilder().append("Created by: ").append(((CheckPoints) checkpoints)
				.maker)
				.append("").toString(),
			85, 413);
			if (((CheckPoints) checkpoints).pubt > 0) {
				if (((CheckPoints) checkpoints).pubt == 2)
				((Lobby) this).xt.drawcs(413, "Super Public Stage", 41,
				177, 255, 3);
				else((Lobby) this).xt.drawcs(413, "Public Stage", 41, 177, 255,
				3);
				if (((Lobby) this).addstage == 0 && ((Lobby) this).xt.drawcarb(true, null,
					" Add to My Stages ", 334,
				420, i, i_293_, bool)) {
					if (((xtGraphics)((Lobby) this).xt).logged) {
						((CarDefine)((Lobby) this).cd).onstage = ((CheckPoints) checkpoints).name;
						((CarDefine)((Lobby) this).cd).staction = 2;
						((Lobby) this).cd.sparkstageaction();
						((Lobby) this).addstage = 2;
					} else {
						((Lobby) this).addstage = 1;
						((Lobby) this).waitlink = 20;
					}
				}
				if (((Lobby) this).addstage == 1) {
					((Lobby) this).rd.setFont(new Font("Arial", 1, 11));
					((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
					((Lobby) this).rd.setColor(new Color(193, 106, 0));
					String string_303_ = "Upgrade to a full account to add custom stages!";
					int i_304_ = (400 - ((Lobby) this).ftm.stringWidth(string_303_) / 2);
					int i_305_ = i_304_ + ((Lobby) this).ftm.stringWidth(string_303_);
					((Lobby) this).rd.drawString(string_303_, i_304_, 435);
					if (((Lobby) this).waitlink != -1)
					((Lobby) this).rd.drawLine(i_304_, 437, i_305_, 437);
					if (i > i_304_ && i < i_305_ && i_293_ > 424 && i_293_ < 437) {
						if (((Lobby) this).waitlink != -1) i_294_ = 12;
						if (bool && ((Lobby) this).waitlink == 0) {
							((Lobby) this).gs.editlink((((xtGraphics)
							((Lobby) this).xt)
								.nickname),
							true);
							((Lobby) this).waitlink = -1;
						}
					}
					if (((Lobby) this).waitlink > 0)
					((Lobby) this).waitlink--;
				}
				if (((Lobby) this).addstage == 2) {
					((Lobby) this).xt.drawcs(435,
						"Adding stage please wait...",
					193, 106, 0, 3);
					if (((CarDefine)((Lobby) this).cd).staction == 0)
					((Lobby) this).addstage = 3;
					if (((CarDefine)((Lobby) this).cd).staction == -2)
					((Lobby) this).addstage = 4;
					if (((CarDefine)((Lobby) this).cd).staction == -3)
					((Lobby) this).addstage = 5;
					if (((CarDefine)((Lobby) this).cd).staction == -1)
					((Lobby) this).addstage = 6;
				}
				if (((Lobby) this).addstage == 3)
				((Lobby) this).xt.drawcs(435,
					"Stage has been successfully added to your stages!",
				193, 106, 0, 3);
				if (((Lobby) this).addstage == 4)
				((Lobby) this).xt.drawcs(435,
					"You already have this stage!",
				193, 106, 0, 3);
				if (((Lobby) this).addstage == 5)
				((Lobby) this).xt.drawcs(435,
					"Cannot add more then 20 stages to your account!",
				193, 106, 0, 3);
				if (((Lobby) this).addstage == 6)
				((Lobby) this).xt.drawcs(435,
					"Failed to add stage, unknown error, please try again later.",
				193, 106, 0, 3);
			} else((Lobby) this).xt.drawcs(435, "Private Stage", 193, 106, 0, 3);
		}
		if (((Control) control).enter || ((Lobby) this).conon == 2 || ((Lobby) this).ongame == -1 && ((Lobby) this).chalngd != -2) {
			((Medium)((Lobby) this).m).trk = 0;
			if (((xtGraphics)((Lobby) this).xt).loadedt)
			((xtGraphics)((Lobby) this).xt).strack.unload();
			((Medium)((Lobby) this).m).focus_point = 400;
			((Medium)((Lobby) this).m).crs = true;
			((Medium)((Lobby) this).m).x = -335;
			((Medium)((Lobby) this).m).y = 0;
			((Medium)((Lobby) this).m).z = -50;
			((Medium)((Lobby) this).m).xz = 0;
			((Medium)((Lobby) this).m).zy = 20;
			((Medium)((Lobby) this).m).ground = -2000;
			((Lobby) this).fase = 1;
			((Control) control).enter = false;
		}
		if (i_294_ != ((Lobby) this).pcurs) {
			((Lobby) this).gs.setCursor(new Cursor(i_294_));
			((Lobby) this).pcurs = i_294_;
		}
	}

	public void ctachm(int i, int i_306_, int i_307_, Control control) {
		int i_308_ = -1;
		if (((Lobby) this).fase == 1 || ((Lobby) this).fase == 4) {
			for (int i_309_ = 0; i_309_ < ((Lobby) this).btn; i_309_++) {
				if ((Math.abs(i - ((Lobby) this).bx[i_309_]) < ((Lobby) this).bw[i_309_] / 2 + 12) && Math.abs(i_306_ - ((Lobby) this).by[i_309_]) < 14 && (i_307_ == 1 || i_307_ == 11))
				((Lobby) this).pessd[i_309_] = true;
				else((Lobby) this).pessd[i_309_] = false;
				if ((Math.abs(i - ((Lobby) this).bx[i_309_]) < ((Lobby) this).bw[i_309_] / 2 + 12) && Math.abs(i_306_ - ((Lobby) this).by[i_309_]) < 14 && i_307_ <= -1) {
					i_308_ = i_309_;
					((GameSparker)((Lobby) this).gs).mouses = 0;
				}
			}
		}
		if (((Lobby) this).conon == 1) {
			if (!((Lobby) this).regnow) {
				if (((Lobby) this).onjoin == -1) {
					if (((Lobby) this).fase == 4) {
						if (i > 532 && i < 592 && i_306_ > 285 && i_306_ < 306 && (i_307_ == 1 || i_307_ == 11))
						((Lobby) this).pback = 1;
						else((Lobby) this).pback = 0;
						if (i > 532 && i < 592 && i_306_ > 285 && i_306_ < 306 && i_307_ <= -1) {
							((GameSparker)((Lobby) this).gs).mouses = 0;
							((Medium)((Lobby) this).m).trk = 0;
							if (((xtGraphics)((Lobby) this).xt).loadedt)
							((xtGraphics)((Lobby) this).xt).strack.unload();
							((Medium)((Lobby) this).m).focus_point = 400;
							((Medium)((Lobby) this).m).crs = true;
							((Medium)((Lobby) this).m).x = -335;
							((Medium)((Lobby) this).m).y = 0;
							((Medium)((Lobby) this).m).z = -50;
							((Medium)((Lobby) this).m).xz = 0;
							((Medium)((Lobby) this).m).zy = 20;
							((Medium)((Lobby) this).m).ground = -2000;
							((Lobby) this).fase = 1;
						}
						if (i_308_ == 0 && ((Lobby) this).chalngd == -1) {
							i_308_ = -1;
							((Lobby) this).join = ((Lobby) this).ongame;
							((Lobby) this).msg = "| Joining Game |";
							((Lobby) this).spos = 0;
							((Medium)((Lobby) this).m).trk = 0;
							if (((xtGraphics)((Lobby) this).xt).loadedt)
							((xtGraphics)((Lobby) this).xt).strack.unload();
							((Medium)((Lobby) this).m).focus_point = 400;
							((Medium)((Lobby) this).m).crs = true;
							((Medium)((Lobby) this).m).x = -335;
							((Medium)((Lobby) this).m).y = 0;
							((Medium)((Lobby) this).m).z = -50;
							((Medium)((Lobby) this).m).xz = 0;
							((Medium)((Lobby) this).m).zy = 20;
							((Medium)((Lobby) this).m).ground = -2000;
							((Lobby) this).fase = 1;
						}
					}
					if (((Lobby) this).fase == 1) {
						if (((Lobby) this).ongame == -1) {
							if (i_308_ == 0) {
								if (((Lobby) this).chalngd == -1) {
									if (((xtGraphics)((Lobby) this).xt).lan && !((Lobby) this).lanlogged)
									((Lobby) this).gs.reglink();
									else {
										boolean bool = false;
										for (int i_310_ = 0;
										i_310_ < ((Lobby) this).ngm;
										i_310_++) {
											if (((Lobby) this).wait[i_310_] == 0) {
												bool = true;
												break;
											}
										}
										if (!bool || ((xtGraphics)
										((Lobby) this).xt).lan) {
											((Lobby) this).loadstage = 0;
											((Lobby) this).remstage = 0;
											((Lobby) this).gstage = 0;
											((Lobby) this).gnpls = 8;
											((Lobby) this).gwait = 0;
											((Lobby) this).gnbts = 0;
											((Lobby) this).gclass = 0;
											((Lobby) this).gcars = 0;
											((Lobby) this).gfix = 0;
											((Lobby) this).gnotp = 0;
											((Lobby) this).gplayers = "";
											((GameSparker)((Lobby) this).gs)
												.wgame.select(0);
											((Lobby) this).chalngd = -2;
										} else((Lobby) this).chalngd = -6;
									}
								} else if (((Lobby) this).chalngd != -5) {
									if (((Lobby) this).invo)
									((Lobby) this).invo = false;
									for (int i_311_ = 0; i_311_ < 7;
									i_311_++) {
										if (!((Lobby) this).invos[i_311_].equals(""))
										((Lobby) this).invos[i_311_] = "";
										if (!((Lobby) this).dinvi[i_311_].equals(""))
										((Lobby) this).dinvi[i_311_] = "";
									}
									((GameSparker)((Lobby) this).gs).swait.hide();
									((GameSparker)((Lobby) this).gs).snpls.hide();
									((GameSparker)((Lobby) this).gs).snbts.hide();
									((GameSparker)((Lobby) this).gs).sgame.hide();
									((GameSparker)((Lobby) this).gs).wgame.hide();
									((GameSparker)((Lobby) this).gs).pgame.hide();
									((GameSparker)((Lobby) this).gs).vnpls.hide();
									((GameSparker)((Lobby) this).gs).vtyp.hide();
									((GameSparker)((Lobby) this).gs).warb.hide();
									((GameSparker)((Lobby) this).gs).mstgs.hide();
									((GameSparker)((Lobby) this).gs).slaps.hide();
									((GameSparker)((Lobby) this).gs).snfm1.hide();
									((GameSparker)((Lobby) this).gs).snfmm.hide();
									((GameSparker)((Lobby) this).gs).snfm2.hide();
									((GameSparker)((Lobby) this).gs)
										.sclass.hide();
									((GameSparker)((Lobby) this).gs).scars.hide();
									((GameSparker)((Lobby) this).gs).sfix.hide();
									((GameSparker)((Lobby) this).gs).mycar.hide();
									((GameSparker)((Lobby) this).gs).notp.hide();
									((Lobby) this).gs.requestFocus();
									((Lobby) this).chalngd = -1;
								}
							}
							if (i_308_ == 1)
							((xtGraphics)((Lobby) this).xt).fase = 23;
							if (i_308_ == 2) {
								((Lobby) this).conon = 0;
								((Lobby) this).lg.exitfromlobby();
								try {
									((Lobby) this).socket.close();
									((Lobby) this).socket = null;
									((Lobby) this).din.close();
									((Lobby) this).din = null;
									((Lobby) this).dout.close();
									((Lobby) this).dout = null;
								} catch (Exception exception) {
									/* empty */
								}
								hideinputs();
							}
							int i_312_ = 3;
							if (((Lobby) this).chalngd > -1) {
								if (i_308_ == 3) {
									((Lobby) this).ongame = ((Lobby) this).chalngd;
									((Lobby) this).chalngd = -1;
								}
								if (i_308_ == 4) {
									((Lobby) this).ongame = ((Lobby) this).chalngd;
									((Lobby) this).join = ((Lobby) this).chalngd;
									((Lobby) this).msg = "| Joining Game |";
									((Lobby) this).chalngd = -1;
									((Lobby) this).longame = -1;
								}
								if (i_308_ == 5) {
									((Lobby) this).ongame = ((Lobby) this).longame;
									((Lobby) this).chalngd = -1;
									((Lobby) this).longame = -1;
								}
								i_312_ = 6;
							} else {
								if (((Lobby) this).chalngd != -1 && ((Lobby) this).chalngd != -5 && i_308_ == 3) {
									if (((Lobby) this).invo)
									((Lobby) this).invo = false;
									for (int i_313_ = 0; i_313_ < 7;
									i_313_++) {
										if (!((Lobby) this).invos[i_313_].equals(""))
										((Lobby) this).invos[i_313_] = "";
										if (!((Lobby) this).dinvi[i_313_].equals(""))
										((Lobby) this).dinvi[i_313_] = "";
									}
									((GameSparker)((Lobby) this).gs).swait.hide();
									((GameSparker)((Lobby) this).gs).snpls.hide();
									((GameSparker)((Lobby) this).gs).snbts.hide();
									((GameSparker)((Lobby) this).gs).sgame.hide();
									((GameSparker)((Lobby) this).gs).wgame.hide();
									((GameSparker)((Lobby) this).gs).pgame.hide();
									((GameSparker)((Lobby) this).gs).vnpls.hide();
									((GameSparker)((Lobby) this).gs).vtyp.hide();
									((GameSparker)((Lobby) this).gs).warb.hide();
									((GameSparker)((Lobby) this).gs).mstgs.hide();
									((GameSparker)((Lobby) this).gs).slaps.hide();
									((GameSparker)((Lobby) this).gs).snfm1.hide();
									((GameSparker)((Lobby) this).gs).snfmm.hide();
									((GameSparker)((Lobby) this).gs).snfm2.hide();
									((GameSparker)((Lobby) this).gs)
										.sclass.hide();
									((GameSparker)((Lobby) this).gs).scars.hide();
									((GameSparker)((Lobby) this).gs).sfix.hide();
									((GameSparker)((Lobby) this).gs).mycar.hide();
									((GameSparker)((Lobby) this).gs).notp.hide();
									((Lobby) this).gs.requestFocus();
									((Lobby) this).chalngd = -1;
								}
								if (((Lobby) this).chalngd == -6 && i_308_ == 4)
								((Lobby) this).chalngd = -1;
								if (((Lobby) this).chalngd == -2) {
									if (((GameSparker)((Lobby) this).gs)
										.wgame.getSelectedIndex() == 0) {
										if (((GameSparker)((Lobby) this).gs)
											.sgame.getSelectedIndex() >= 3 && !((xtGraphics)
										((Lobby) this).xt).logged) {
											if (i_308_ == 4)
											((Lobby) this).gs.editlink((((xtGraphics)
											((Lobby) this).xt)
												.nickname),
											true);
											i_312_ = 5;
										} else {
											if (i_308_ == 4) {
												if (((Lobby) this).loadstage < 0) {
													((Lobby) this).rd.setColor(new Color(0, 0, 0));
													((Lobby) this).rd.fillRect(0, 0, 670, 400);
													((Lobby) this).gs.repaint();
													((GameSparker)
													((Lobby) this).gs)
														.rooms.hide();
													((GameSparker)
													((Lobby) this).gs)
														.cmsg.hide();
													((GameSparker)
													((Lobby) this).gs)
														.sgame.hide();
													((GameSparker)
													((Lobby) this).gs)
														.wgame.hide();
													((GameSparker)
													((Lobby) this).gs)
														.warb.hide();
													((GameSparker)
													((Lobby) this).gs)
														.pgame.hide();
													((GameSparker)
													((Lobby) this).gs)
														.vnpls.hide();
													((GameSparker)
													((Lobby) this).gs)
														.vtyp.hide();
													((GameSparker)
													((Lobby) this).gs)
														.mstgs.hide();
													((GameSparker)
													((Lobby) this).gs)
														.slaps.hide();
													((GameSparker)
													((Lobby) this).gs)
														.snfm1.hide();
													((GameSparker)
													((Lobby) this).gs)
														.snfmm.hide();
													((GameSparker)
													((Lobby) this).gs)
														.snfm2.hide();
													((Lobby) this).gs.requestFocus();
													((Medium)((Lobby) this).m)
														.ptr = 0;
													((Medium)((Lobby) this).m)
														.ptcnt = -10;
													((Medium)((Lobby) this).m)
														.hit = 20000;
													((Medium)((Lobby) this).m)
														.fallen = 0;
													((Medium)((Lobby) this).m)
														.nrnd = 0;
													((Medium)((Lobby) this).m)
														.ih = 25;
													((Medium)((Lobby) this).m)
														.iw = 65;
													((Medium)((Lobby) this).m)
														.h = 425;
													((Medium)((Lobby) this).m)
														.w = 735;
													((Medium)((Lobby) this).m)
														.trk = 4;
													((Lobby) this).plsndt = 0;
													((Lobby) this).addstage = 0;
													((Lobby) this).fase = 4;
												} else((Lobby) this).sflk = 25;
											}
											if (((Lobby) this).loadstage >= 0) i_312_ = 5;
											else {
												if (i_308_ == 5) {
													if (((Lobby) this).gstage != 0) {
														((GameSparker)
														((Lobby) this).gs)
															.sgame.hide();
														((GameSparker)
														((Lobby) this).gs)
															.wgame.hide();
														((GameSparker)
														((Lobby) this).gs)
															.pgame.hide();
														((GameSparker)
														((Lobby) this).gs)
															.vnpls.hide();
														((GameSparker)
														((Lobby) this).gs)
															.vtyp.hide();
														((GameSparker)
														((Lobby) this).gs)
															.warb.hide();
														((GameSparker)
														((Lobby) this).gs)
															.mstgs.hide();
														((GameSparker)
														((Lobby) this).gs)
															.slaps.hide();
														((GameSparker)
														((Lobby) this).gs)
															.snfm1.hide();
														((GameSparker)
														((Lobby) this).gs)
															.snfmm.hide();
														((GameSparker)
														((Lobby) this).gs)
															.snfm2.hide();
														((Lobby) this).gs.requestFocus();
														((Lobby) this).chalngd = -3;
														i_308_ = -1;
													} else((Lobby) this).sflk = 25;
												}
												i_312_ = 6;
											}
										}
									} else if (!((xtGraphics)
									((Lobby) this).xt)
										.clan.equals("")) {
										int i_314_ = 4;
										if ((((Smenu)((GameSparker)
										((Lobby) this).gs).warb)
											.sel) != 0 && (((Globe)((Lobby) this).gb)
											.loadwbgames) == 2) {
											if ((((GameSparker)
											((Lobby) this).gs)
												.wgame.getSelectedIndex() == 1) && (((Smenu)((GameSparker)
											(((Lobby) this)
												.gs)).vnpls).sel != 0) && (((Lobby) this).cancreate == 2)) {
												if (i_308_ == 4) {
													if (((Lobby) this).invo)
													((Lobby) this).invo = false;
													((Lobby) this).msg = "| Creating Game |";
													((Lobby) this).gplayers = new StringBuilder().append("#warb#").append(((Globe)
													(((Lobby) this)
														.gb)).warb)
														.append("#").append(((Globe)
													(((Lobby) this)
														.gb)).warbnum)
														.append("#").append(((Globe)
													(((Lobby) this)
														.gb)).gameturn + 1)
														.append("#").append(((xtGraphics)
													(((Lobby) this)
														.xt)).clan)
														.append("#").append(((Globe)
													(((Lobby) this)
														.gb)).vclan)
														.append("#").append(((Globe)
													(((Lobby) this)
														.gb)).ascore)
														.append("#").append(((Globe)
													(((Lobby) this)
														.gb)).vscore)
														.append("#").append(((Smenu)
													(((GameSparker)
													((Lobby)
													this).gs)
														.vtyp)).sel + 1)
														.append("#").toString();
													((Lobby) this).gstage = (((Globe)
													((Lobby) this).gb)
														.wbstage[((Globe)
													(((Lobby) this)
														.gb)).gameturn]);
													((Lobby) this).gstagelaps = (((Globe)
													((Lobby) this).gb)
														.wblaps[((Globe)
													(((Lobby) this)
														.gb)).gameturn]);
													((Lobby) this).gcars = ((((Globe)
													((Lobby) this).gb)
														.wbcars[((Globe)
													(((Lobby) this)
														.gb)).gameturn]) - 1);
													((Lobby) this).gclass = (((Globe)
													((Lobby) this).gb)
														.wbclass[((Globe)
													(((Lobby) this)
														.gb)).gameturn]);
													((Lobby) this).gfix = (((Globe)
													((Lobby) this).gb)
														.wbfix[((Globe)
													(((Lobby) this)
														.gb)).gameturn]);
													((Lobby) this).gnpls = 8;
													if (((Smenu)
													(((GameSparker)
													((Lobby) this).gs)
														.vnpls)).sel == 1)
													((Lobby) this).gnpls = 4;
													if (((Smenu)
													(((GameSparker)
													((Lobby) this).gs)
														.vnpls)).sel == 2)
													((Lobby) this).gnpls = 6;
													((Lobby) this).gwait = 120;
													((Lobby) this).gnotp = 0;
													((GameSparker)
													((Lobby) this).gs)
														.wgame.hide();
													((GameSparker)
													((Lobby) this).gs)
														.pgame.hide();
													((GameSparker)
													((Lobby) this).gs)
														.vnpls.hide();
													((GameSparker)
													((Lobby) this).gs)
														.vtyp.hide();
													((GameSparker)
													((Lobby) this).gs)
														.warb.hide();
													((Lobby) this).gs.requestFocus();
													((Lobby) this).chalngd = -5;
												}
												i_314_++;
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.wgame.getSelectedIndex() == 2) && (((Smenu)((GameSparker)
											(((Lobby) this)
												.gs)).pgame).sel != 0) && i_308_ == 4) {
												if (((Lobby) this).invo)
												((Lobby) this).invo = false;
												((Lobby) this).msg = "| Creating Game |";
												((Lobby) this).gstage = (((Globe)
												((Lobby) this).gb)
													.wbstage[((Smenu)
												(((GameSparker)
												((Lobby) this).gs)
													.pgame)).sel - 1]);
												((Lobby) this).gstagelaps = (((Globe)
												((Lobby) this).gb)
													.wblaps[((Smenu)
												(((GameSparker)
												((Lobby) this).gs)
													.pgame)).sel - 1]);
												((Lobby) this).gcars = ((((Globe)
												((Lobby) this).gb)
													.wbcars[((Smenu)
												(((GameSparker)
												((Lobby) this).gs)
													.pgame)).sel - 1]) - 1);
												((Lobby) this).gclass = (((Globe)
												((Lobby) this).gb)
													.wbclass[((Smenu)
												(((GameSparker)
												((Lobby) this).gs)
													.pgame)).sel - 1]);
												((Lobby) this).gfix = (((Globe)
												((Lobby) this).gb)
													.wbfix[((Smenu)
												(((GameSparker)
												((Lobby) this).gs)
													.pgame)).sel - 1]);
												((Lobby) this).gnpls = 8;
												((Lobby) this).gwait = 120;
												((Lobby) this).gnotp = 0;
												((Lobby) this).gplayers = "";
												((GameSparker)
												((Lobby) this).gs)
													.wgame.hide();
												((GameSparker)
												((Lobby) this).gs)
													.pgame.hide();
												((GameSparker)
												((Lobby) this).gs)
													.vnpls.hide();
												((GameSparker)
												((Lobby) this).gs)
													.vtyp.hide();
												((GameSparker)
												((Lobby) this).gs)
													.warb.hide();
												((Lobby) this).gs.requestFocus();
												((Lobby) this).chalngd = -5;
											}
											if ((((GameSparker)
											((Lobby) this).gs)
												.wgame.getSelectedIndex() == 1) && (((Globe)((Lobby) this).gb)
												.canredo) && i_308_ == i_314_)
											((Globe)((Lobby) this).gb)
												.loadwbgames = 7;
										}
									} else if (i_308_ == 4) {
										((Globe)((Lobby) this).gb).tab = 3;
										((Globe)((Lobby) this).gb).cfase = 2;
										((Globe)((Lobby) this).gb).em = 1;
										((Globe)((Lobby) this).gb).msg = "Clan Search";
										((Globe)((Lobby) this).gb).smsg = "Listing clans with recent activity...";
										((Globe)((Lobby) this).gb).nclns = 0;
										((Globe)((Lobby) this).gb).spos5 = 0;
										((Globe)((Lobby) this).gb).lspos5 = 0;
										((Globe)((Lobby) this).gb).flko = 0;
										((Globe)((Lobby) this).gb).open = 2;
										((Globe)((Lobby) this).gb).upo = true;
									}
								}
								if (((Lobby) this).chalngd == -3) {
									if (i_308_ == 4) {
										((Lobby) this).chalngd = -2;
										((GameSparker)((Lobby) this).gs)
											.snpls.hide();
										((GameSparker)((Lobby) this).gs)
											.snbts.hide();
										((GameSparker)((Lobby) this).gs)
											.swait.hide();
										((Lobby) this).gs.requestFocus();
									}
									if (i_308_ == 5) {
										if (((Lobby) this).gnpls != 0 && (((GameSparker)
										((Lobby) this).gs)
											.snpls.getSelectedIndex() != 0)) {
											((Lobby) this).chalngd = -4;
											for (int i_315_ = 0; i_315_ < 7;
											i_315_++) {
												if (!((Lobby) this).invos[i_315_].equals(""))
												((Lobby) this).invos[i_315_] = "";
												if (!((Lobby) this).dinvi[i_315_].equals(""))
												((Lobby) this).dinvi[i_315_] = "";
											}
											i_308_ = -1;
											((GameSparker)((Lobby) this).gs)
												.snpls.hide();
											((GameSparker)((Lobby) this).gs)
												.snbts.hide();
											((GameSparker)((Lobby) this).gs)
												.swait.hide();
											((Lobby) this).gs.requestFocus();
										} else((Lobby) this).sflk = 25;
									}
									i_312_ = 6;
								}
								if (((Lobby) this).chalngd == -4) {
									i_312_ = 7;
									int i_316_ = 0;
									for (int i_317_ = 0; i_317_ < 7;
									i_317_++) {
										if (!((Lobby) this).invos[i_317_].equals("")) i_316_++;
									}
									if (i_316_ < ((Lobby) this).gnpls - 1) {
										if (i_308_ == 4) {
											if (!((Lobby) this).invo)
											((Lobby) this).invo = true;
											else((Lobby) this).invo = false;
										}
									} else i_312_ = 6;
									if (i_308_ == i_312_ - 2) {
										if (((Lobby) this).invo)
										((Lobby) this).invo = false;
										if (((GameSparker)((Lobby) this).gs)
											.mycar.getState() && (((xtGraphics)
										((Lobby) this).xt).sc[0] < 16)) {
											((Lobby) this).gclass = -(((xtGraphics)
											((Lobby) this).xt).sc[0] + 2);
											((Lobby) this).gcars = 0;
										}
										if (((GameSparker)((Lobby) this).gs)
											.notp.getState())
										((Lobby) this).gnotp = 1;
										else((Lobby) this).gnotp = 0;
										((Lobby) this).gplayers = "";
										((GameSparker)((Lobby) this).gs)
											.sclass.hide();
										((GameSparker)((Lobby) this).gs)
											.scars.hide();
										((GameSparker)((Lobby) this).gs)
											.sfix.hide();
										((GameSparker)((Lobby) this).gs)
											.mycar.hide();
										((GameSparker)((Lobby) this).gs)
											.notp.hide();
										((Lobby) this).gs.requestFocus();
										((Lobby) this).chalngd = -3;
									}
									if (i_308_ == i_312_ - 1) {
										if (((Lobby) this).invo)
										((Lobby) this).invo = false;
										((Lobby) this).msg = "| Creating Game |";
										if (((GameSparker)((Lobby) this).gs)
											.mycar.getState() && (((xtGraphics)
										((Lobby) this).xt).sc[0] < 16)) {
											((Lobby) this).gclass = -(((xtGraphics)
											((Lobby) this).xt).sc[0] + 2);
											((Lobby) this).gcars = 0;
										}
										if (((Lobby) this).gclass != 0)
										((Lobby) this).gwait = 120;
										if (((GameSparker)((Lobby) this).gs)
											.notp.getState())
										((Lobby) this).gnotp = 1;
										else((Lobby) this).gnotp = 0;
										((Lobby) this).gplayers = "";
										if (i_316_ != 0) {
											((Lobby) this).gnpls = i_316_ + 1;
											((Lobby) this).gplayers = new StringBuilder().append("").append(((Lobby) this).pnames[((Lobby) this).im])
												.append("#").toString();
											for (int i_318_ = 0;
											i_318_ < i_316_; i_318_++) {
												StringBuilder stringbuilder = new StringBuilder();
												Lobby lobby_319_ = this;
												((Lobby) lobby_319_).gplayers = stringbuilder.append(((Lobby) lobby_319_)
													.gplayers)
													.append(((Lobby) this).invos[i_318_])
													.append("#").toString();
											}
										}
										((GameSparker)((Lobby) this).gs)
											.sclass.hide();
										((GameSparker)((Lobby) this).gs)
											.scars.hide();
										((GameSparker)((Lobby) this).gs)
											.sfix.hide();
										((GameSparker)((Lobby) this).gs)
											.mycar.hide();
										((GameSparker)((Lobby) this).gs)
											.notp.hide();
										((Lobby) this).gs.requestFocus();
										((Lobby) this).chalngd = -5;
									}
								}
							}
							if (i_308_ == i_312_ && !((xtGraphics)((Lobby) this).xt).lan && !((GameSparker)((Lobby) this).gs).cmsg.getText().equals("Type here...") && !((GameSparker)((Lobby) this).gs).cmsg.getText().equals("")) {
								String string = ((GameSparker)((Lobby) this).gs)
									.cmsg.getText().replace('|', ':');
								if ((string.toLowerCase().indexOf(((GameSparker)((Lobby) this).gs)
									.tpass.getText().toLowerCase())) != -1) string = " ";
								if (!((Lobby) this).xt.msgcheck(string) && ((Lobby) this).updatec > -12) {
									for (int i_320_ = 0; i_320_ < 6;
									i_320_++) {
										((Lobby) this).sentn[i_320_] = ((Lobby) this).sentn[i_320_ + 1];
										((Lobby) this).cnames[i_320_] = (((Lobby) this).cnames[i_320_ + 1]);
									}
									((Lobby) this).sentn[6] = string;
									((Lobby) this).cnames[6] = (((Lobby) this).pnames[((Lobby) this).im]);
									if (((Lobby) this).updatec > -11)
									((Lobby) this).updatec = -11;
									else((Lobby) this).updatec--;
									((Lobby) this).spos3 = 28;
								} else((xtGraphics)((Lobby) this).xt).warning++;
								((GameSparker)((Lobby) this).gs).cmsg.setText("");
							}
						} else if (((Lobby) this).dispcar == -1) {
							int i_321_ = 0;
							for (int i_322_ = 0; i_322_ < ((Lobby) this).ngm;
							i_322_++) {
								if (((Lobby) this).ongame == ((Lobby) this).gnum[i_322_]) i_321_ = i_322_;
							}
							boolean bool = false;
							if (((Lobby) this).gwarb[i_321_] == 0) {
								if (!((Lobby) this).gplyrs[i_321_].equals("") && (((Lobby) this).gplyrs[i_321_].indexOf(((Lobby) this).pnames[((Lobby) this).im])) == -1) bool = true;
							} else if (!(((xtGraphics)((Lobby) this).xt)
								.clan.toLowerCase().equals(((Lobby) this).gaclan[i_321_].toLowerCase())) && !(((xtGraphics)((Lobby) this).xt)
								.clan.toLowerCase().equals(((Lobby) this).gvclan[i_321_].toLowerCase()))) bool = true;
							if (((Control) control).enter && ((Lobby) this).wait[i_321_] > 0 && (((Lobby) this).pgames[((Lobby) this).im] == -1) && !bool) {
								((Lobby) this).join = ((Lobby) this).ongame;
								((Lobby) this).msg = "| Joining Game |";
								((Lobby) this).spos = 0;
								if (((Lobby) this).pbtn == 0)
								((Lobby) this).pessd[1] = true;
							}
							if (((Lobby) this).wait[i_321_] == -1 && (((Lobby) this).pgames[((Lobby) this).im] == -1) && ((Control) control).enter) {
								i_308_ = 0;
								((Lobby) this).pessd[0] = true;
							}
							if (((Lobby) this).pgames[((Lobby) this).im] == -1 && ((Control) control).exit) {
								i_308_ = 0;
								((Lobby) this).pessd[0] = true;
							}
							if (i_308_ == 0) {
								if (((Lobby) this).pgames[((Lobby) this).im] == -1) {
									((Lobby) this).ongame = -1;
									((Lobby) this).chalngd = -1;
								} else {
									((Lobby) this).join = -2;
									((Lobby) this).msg = "| Leaving Game |";
									((Lobby) this).longame = -1;
								}
							}
							if (((Lobby) this).pbtn == 0) {
								if (i_308_ == 1) {
									if (((Lobby) this).wait[i_321_] > 0) {
										if ((((Lobby) this).pgames[((Lobby) this).im]) == -1) {
											((Lobby) this).join = ((Lobby) this).ongame;
											((Lobby) this).msg = "| Joining Game |";
											((Lobby) this).spos = 0;
										} else if ((((Lobby) this).gmaker[i_321_].equals(((Lobby) this).pnames[((Lobby) this).im])) && (((Lobby) this).npls[i_321_]) > 1)
										((Lobby) this).fstart = true;
										else i_308_ = 2;
									} else {
										if (((Lobby) this).wait[i_321_] == 0 && (((Lobby) this).prevloaded == 1)) {
											((Lobby) this).laps = (((Lobby) this).gnlaps[i_321_]);
											((Lobby) this).stage = ((Lobby) this).gstgn[i_321_];
											((Lobby) this).stagename = (((Lobby) this).gstages[i_321_]);
											((Lobby) this).nfix = ((Lobby) this).gfx[i_321_];
											if (((Lobby) this).gntb[i_321_] == 1)
											((Lobby) this).notb = true;
											else((Lobby) this).notb = false;
											((Lobby) this).gs.setCursor(new Cursor(3));
											((Lobby) this).conon = 3;
										} else i_308_ = 2;
										if (((Lobby) this).wait[i_321_] == 0 && ((xtGraphics)
										((Lobby) this).xt).lan) {
											((Lobby) this).laps = (((Lobby) this).gnlaps[i_321_]);
											((Lobby) this).stage = ((Lobby) this).gstgn[i_321_];
											((Lobby) this).stagename = (((Lobby) this).gstages[i_321_]);
											((Lobby) this).nfix = ((Lobby) this).gfx[i_321_];
											if (((Lobby) this).gntb[i_321_] == 1)
											((Lobby) this).notb = true;
											else((Lobby) this).notb = false;
											((Lobby) this).gs.setCursor(new Cursor(3));
											((Lobby) this).conon = 3;
										}
									}
								}
								if (i_308_ == 2 && !((xtGraphics)((Lobby) this).xt).lan && !((GameSparker)((Lobby) this).gs)
									.cmsg.getText().equals("Type here...") && !((GameSparker)((Lobby) this).gs)
									.cmsg.getText().equals("")) {
									String string = ((GameSparker)((Lobby) this).gs)
										.cmsg.getText().replace('|', ':');
									if ((string.toLowerCase().indexOf(((GameSparker)((Lobby) this).gs)
										.tpass.getText().toLowerCase())) != -1) string = " ";
									if (!((Lobby) this).xt.msgcheck(string) && ((Lobby) this).updatec > -12) {
										for (int i_323_ = 0; i_323_ < 6;
										i_323_++) {
											((Lobby) this).sentn[i_323_] = (((Lobby) this).sentn[i_323_ + 1]);
											((Lobby) this).cnames[i_323_] = (((Lobby) this).cnames[i_323_ + 1]);
										}
										((Lobby) this).sentn[6] = string;
										((Lobby) this).cnames[6] = (((Lobby) this).pnames[((Lobby) this).im]);
										if (((Lobby) this).updatec > -11)
										((Lobby) this).updatec = -11;
										else((Lobby) this).updatec--;
									} else((xtGraphics)((Lobby) this).xt)
										.warning++;
									((GameSparker)((Lobby) this).gs).cmsg.setText("");
								}
							}
							if (((Lobby) this).pbtn == 1 && i_308_ == 1) {
								if (((Lobby) this).pgames[((Lobby) this).im] == -1) {
									((Lobby) this).join = ((Lobby) this).ongame;
									((Lobby) this).msg = "| Joining Game |";
									((Lobby) this).spos = 0;
								} else if (!((Lobby) this).invo)
								((Lobby) this).invo = true;
								else((Lobby) this).invo = false;
							}
							if (((Lobby) this).pbtn == 2 && (i_308_ == 1 || i_308_ == 2)) {
								((Lobby) this).fase = 2;
								((Medium)((Lobby) this).m).ptr = 0;
								((Medium)((Lobby) this).m).ptcnt = -10;
								((Medium)((Lobby) this).m).hit = 20000;
								((Medium)((Lobby) this).m).fallen = 500;
								((Medium)((Lobby) this).m).nrnd = 0;
								((Medium)((Lobby) this).m).ih = 25;
								((Medium)((Lobby) this).m).iw = 65;
								((Medium)((Lobby) this).m).h = 425;
								((Medium)((Lobby) this).m).w = 735;
								((Medium)((Lobby) this).m).trk = 4;
								((Lobby) this).plsndt = 0;
								if (((GameSparker)((Lobby) this).gs).cmsg.isShowing()) {
									((GameSparker)((Lobby) this).gs).cmsg.hide();
									((Lobby) this).gs.requestFocus();
								}
							}
						} else {
							if (i_308_ == 0) {
								if (((Lobby) this).pgames[((Lobby) this).im] == -1) {
									((Lobby) this).ongame = -1;
									((Lobby) this).chalngd = -1;
								} else {
									((Lobby) this).join = -2;
									((Lobby) this).msg = "| Leaving Game |";
									((Lobby) this).longame = -1;
								}
							}
							if (((Lobby) this).pbtn == 1 && i_308_ == 1) {
								if (((Lobby) this).pgames[((Lobby) this).im] == -1) {
									((Lobby) this).join = ((Lobby) this).ongame;
									((Lobby) this).msg = "| Joining Game |";
									((Lobby) this).spos = 0;
								} else if (!((Lobby) this).invo)
								((Lobby) this).invo = true;
								else((Lobby) this).invo = false;
							}
						}
					}
				} else if (((Lobby) this).ontyp != 76) {
					if (i_308_ == 0) {
						if (((Lobby) this).ontyp < 30) {
							((xtGraphics)((Lobby) this).xt).onjoin = ((Lobby) this).onjoin;
							((xtGraphics)((Lobby) this).xt).ontyp = ((Lobby) this).ontyp;
							((xtGraphics)((Lobby) this).xt).playingame = -101;
							((xtGraphics)((Lobby) this).xt).fase = 23;
						} else {
							if (!((Globe)((Lobby) this).gb).claname.equals(((xtGraphics)((Lobby) this).xt).clan)) {
								((Globe)((Lobby) this).gb).claname = ((xtGraphics)((Lobby) this).xt).clan;
								((Globe)((Lobby) this).gb).loadedc = false;
							}
							((Globe)((Lobby) this).gb).spos5 = 0;
							((Globe)((Lobby) this).gb).lspos5 = 0;
							((Globe)((Lobby) this).gb).cfase = 3;
							((Globe)((Lobby) this).gb).loadedcars = -1;
							((Globe)((Lobby) this).gb).loadedcar = 0;
							((Globe)((Lobby) this).gb).ctab = 2;
							((Globe)((Lobby) this).gb).tab = 3;
							((Globe)((Lobby) this).gb).open = 2;
							((Globe)((Lobby) this).gb).upo = true;
							((Lobby) this).onjoin = -1;
						}
					}
					if (i_308_ == 1)
					((Lobby) this).onjoin = -1;
				} else {
					if (i_308_ == 0) {
						((Lobby) this).gs.editlink((((xtGraphics)
						((Lobby) this).xt)
							.nickname),
						true);
						((Lobby) this).onjoin = -1;
					}
					if (i_308_ == 1)
					((Lobby) this).onjoin = -1;
				}
			} else {
				if (i_308_ == 0)
				((Lobby) this).gs.editlink(((xtGraphics)
				((Lobby) this).xt).nickname,
				true);
				if (i_308_ == 1)
				((Lobby) this).regnow = false;
			}
		}
		((Lobby) this).lxm = i;
		((Lobby) this).lym = i_306_;
		((Control) control).enter = false;
		((Control) control).exit = false;
	}

	public void hideinputs() {
		((GameSparker)((Lobby) this).gs).cmsg.hide();
		((GameSparker)((Lobby) this).gs).swait.hide();
		((GameSparker)((Lobby) this).gs).snpls.hide();
		((GameSparker)((Lobby) this).gs).snbts.hide();
		((GameSparker)((Lobby) this).gs).sgame.hide();
		((GameSparker)((Lobby) this).gs).wgame.hide();
		((GameSparker)((Lobby) this).gs).pgame.hide();
		((GameSparker)((Lobby) this).gs).vnpls.hide();
		((GameSparker)((Lobby) this).gs).vtyp.hide();
		((GameSparker)((Lobby) this).gs).warb.hide();
		((GameSparker)((Lobby) this).gs).mstgs.hide();
		((GameSparker)((Lobby) this).gs).snfm1.hide();
		((GameSparker)((Lobby) this).gs).snfmm.hide();
		((GameSparker)((Lobby) this).gs).slaps.hide();
		((GameSparker)((Lobby) this).gs).snfm2.hide();
		((GameSparker)((Lobby) this).gs).sclass.hide();
		((GameSparker)((Lobby) this).gs).scars.hide();
		((GameSparker)((Lobby) this).gs).sfix.hide();
		((GameSparker)((Lobby) this).gs).mycar.hide();
		((GameSparker)((Lobby) this).gs).notp.hide();
		((GameSparker)((Lobby) this).gs).rooms.hide();
		((Lobby) this).gs.requestFocus();
	}

	public void drawSbutton(Image image, int i, int i_324_) {
		((Lobby) this).bx[((Lobby) this).btn] = i;
		((Lobby) this).by[((Lobby) this).btn] = i_324_;
		((Lobby) this).bw[((Lobby) this).btn] = image.getWidth(((Lobby) this).ob);
		if (!((Lobby) this).pessd[((Lobby) this).btn]) {
			((Lobby) this).rd.drawImage(image, i - ((Lobby) this).bw[((Lobby) this).btn] / 2,
			i_324_ - image.getHeight(((Lobby) this).ob) / 2 - 1, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bols,
			i - (((Lobby) this).bw[((Lobby) this).btn]) / 2 - 15,
			i_324_ - 13, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bors,
			i + (((Lobby) this).bw[((Lobby) this).btn]) / 2 + 9,
			i_324_ - 13, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bot,
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_324_ - 13, ((Lobby) this).bw[((Lobby) this).btn] + 18, 3,
			null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bob,
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_324_ + 10, ((Lobby) this).bw[((Lobby) this).btn] + 18, 3,
			null);
		} else {
			((Lobby) this).rd.drawImage(image, i - ((Lobby) this).bw[((Lobby) this).btn] / 2 + 1,
			i_324_ - image.getHeight(((Lobby) this).ob) / 2, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bolps,
			i - (((Lobby) this).bw[((Lobby) this).btn]) / 2 - 15,
			i_324_ - 13, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).borps,
			i + (((Lobby) this).bw[((Lobby) this).btn]) / 2 + 9,
			i_324_ - 13, null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bob,
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_324_ - 13, ((Lobby) this).bw[((Lobby) this).btn] + 18, 3,
			null);
			((Lobby) this).rd.drawImage(((xtGraphics)((Lobby) this).xt).bot,
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_324_ + 10, ((Lobby) this).bw[((Lobby) this).btn] + 18, 3,
			null);
		}
		((Lobby) this).btn++;
	}

	public void stringbutton(String string, int i, int i_325_, int i_326_) {
		((Lobby) this).rd.setFont(new Font("Arial", 1, 12));
		((Lobby) this).ftm = ((Lobby) this).rd.getFontMetrics();
		((Lobby) this).bx[((Lobby) this).btn] = i;
		((Lobby) this).by[((Lobby) this).btn] = i_325_ - 5;
		((Lobby) this).bw[((Lobby) this).btn] = ((Lobby) this).ftm.stringWidth(string);
		if (!((Lobby) this).pessd[((Lobby) this).btn]) {
			((Lobby) this).rd.setColor(color2k(220, 220, 220));
			((Lobby) this).rd.fillRect(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_), ((Lobby) this).bw[((Lobby) this).btn] + 20, 25 - i_326_ * 2);
			((Lobby) this).rd.setColor(color2k(240, 240, 240));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (17 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (18 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (18 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_325_ - (19 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 9,
			i_325_ - (19 - i_326_));
			((Lobby) this).rd.setColor(color2k(200, 200, 200));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 11,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 11,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 12,
			i_325_ - (16 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 12,
			i_325_ + (6 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (7 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (8 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (8 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_325_ + (9 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 9,
			i_325_ + (9 - i_326_));
			((Lobby) this).rd.setColor(color2k(240, 240, 240));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 11,
			i_325_ - (17 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 11,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 12,
			i_325_ - (16 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 12,
			i_325_ + (6 - i_326_));
			((Lobby) this).rd.setColor(new Color(0, 0, 0));
			((Lobby) this).rd.drawString(string,
			i - (((Lobby) this).bw[((Lobby) this).btn]) / 2,
			i_325_);
		} else {
			((Lobby) this).rd.setColor(color2k(210, 210, 210));
			((Lobby) this).rd.fillRect(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_), ((Lobby) this).bw[((Lobby) this).btn] + 20, 25 - i_326_ * 2);
			((Lobby) this).rd.setColor(color2k(200, 200, 200));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (17 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (18 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (18 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_325_ - (19 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 9,
			i_325_ - (19 - i_326_));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 11,
			i_325_ - (17 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 11,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 12,
			i_325_ - (16 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 12,
			i_325_ + (6 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (7 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (8 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 10,
			i_325_ + (8 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 9,
			i_325_ + (9 - i_326_),
			i + ((Lobby) this).bw[((Lobby) this).btn] / 2 + 9,
			i_325_ + (9 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ - (17 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 10,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 11,
			i_325_ - (17 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 11,
			i_325_ + (7 - i_326_));
			((Lobby) this).rd.drawLine(i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 12,
			i_325_ - (16 - i_326_),
			i - ((Lobby) this).bw[((Lobby) this).btn] / 2 - 12,
			i_325_ + (6 - i_326_));
			((Lobby) this).rd.setColor(new Color(0, 0, 0));
			((Lobby) this).rd.drawString(string,
			i - (((Lobby) this).bw[((Lobby) this).btn]) / 2 + 1,
			i_325_);
		}
		((Lobby) this).btn++;
	}

	public Color color2k(int i, int i_327_, int i_328_) {
		Color color = new Color(i, i_327_, i_328_);
		float[] fs = new float[3];
		Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
		fs[0] = 0.13F;
		fs[1] = 0.35F;
		return Color.getHSBColor(fs[0], fs[1], fs[2]);
	}

	public int getvalue(String string, int i) {
		int i_329_ = -1;
		try {
			int i_330_ = 0;
			int i_331_ = 0;
			int i_332_ = 0;
			String string_333_ = "";
			String string_334_ = "";
			for ( /**/ ; i_330_ < string.length() && i_332_ != 2; i_330_++) {
				string_333_ = new StringBuilder().append("").append(string.charAt(i_330_)).toString();
				if (string_333_.equals("|")) {
					i_331_++;
					if (i_332_ == 1 || i_331_ > i) i_332_ = 2;
				} else if (i_331_ == i) {
					string_334_ = new StringBuilder().append(string_334_).append(string_333_).toString();
					i_332_ = 1;
				}
			}
			if (string_334_.equals("")) string_334_ = "-1";
			i_329_ = Integer.valueOf(string_334_).intValue();
		} catch (Exception exception) {
			/* empty */
		}
		return i_329_;
	}

	public String getSvalue(String string, int i) {
		String string_335_ = "";
		try {
			int i_336_ = 0;
			int i_337_ = 0;
			int i_338_ = 0;
			String string_339_ = "";
			String string_340_ = "";
			for ( /**/ ; i_336_ < string.length() && i_338_ != 2; i_336_++) {
				string_339_ = new StringBuilder().append("").append(string.charAt(i_336_)).toString();
				if (string_339_.equals("|")) {
					i_337_++;
					if (i_338_ == 1 || i_337_ > i) i_338_ = 2;
				} else if (i_337_ == i) {
					string_340_ = new StringBuilder().append(string_340_).append(string_339_).toString();
					i_338_ = 1;
				}
			}
			string_335_ = string_340_;
		} catch (Exception exception) {
			/* empty */
		}
		return string_335_;
	}

	public int getHvalue(String string, int i) {
		int i_341_ = -1;
		try {
			int i_342_ = 0;
			int i_343_ = 0;
			int i_344_ = 0;
			String string_345_ = "";
			String string_346_ = "";
			for ( /**/ ; i_342_ < string.length() && i_344_ != 2; i_342_++) {
				string_345_ = new StringBuilder().append("").append(string.charAt(i_342_)).toString();
				if (string_345_.equals("#")) {
					i_343_++;
					if (i_344_ == 1 || i_343_ > i) i_344_ = 2;
				} else if (i_343_ == i) {
					string_346_ = new StringBuilder().append(string_346_).append(string_345_).toString();
					i_344_ = 1;
				}
			}
			if (string_346_.equals("")) string_346_ = "-1";
			i_341_ = Integer.valueOf(string_346_).intValue();
		} catch (Exception exception) {
			/* empty */
		}
		return i_341_;
	}

	public String getHSvalue(String string, int i) {
		String string_347_ = "";
		try {
			int i_348_ = 0;
			int i_349_ = 0;
			int i_350_ = 0;
			String string_351_ = "";
			String string_352_ = "";
			for ( /**/ ; i_348_ < string.length() && i_350_ != 2; i_348_++) {
				string_351_ = new StringBuilder().append("").append(string.charAt(i_348_)).toString();
				if (string_351_.equals("#")) {
					i_349_++;
					if (i_350_ == 1 || i_349_ > i) i_350_ = 2;
				} else if (i_349_ == i) {
					string_352_ = new StringBuilder().append(string_352_).append(string_351_).toString();
					i_350_ = 1;
				}
			}
			string_347_ = string_352_;
		} catch (Exception exception) {
			/* empty */
		}
		return string_347_;
	}

	public String getSevervalue(String string, int i) {
		String string_353_ = "";
		if (!string.equals("")) {
			try {
				boolean bool = false;
				int i_354_ = 0;
				int i_355_ = 0;
				int i_356_ = 0;
				String string_357_ = "";
				String string_358_ = "";
				for ( /**/ ; i_354_ < string.length() && i_356_ != 2; i_354_++) {
					string_357_ = new StringBuilder().append("").append(string.charAt(i_354_)).toString();
					if (string_357_.equals("|")) {
						i_355_++;
						if (i_356_ == 1 || i_355_ > i) i_356_ = 2;
					} else if (i_355_ == i) {
						string_358_ = new StringBuilder().append(string_358_).append(string_357_).toString();
						i_356_ = 1;
					}
				}
				string_353_ = string_358_;
			} catch (Exception exception) {
				string_353_ = "";
			}
		}
		return string_353_;
	}
}