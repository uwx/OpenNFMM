/* CheckPoints - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class CheckPoints
{
    int[] x = new int[10000];
    int[] z = new int[10000];
    int[] y = new int[10000];
    int[] typ = new int[10000];
    int pcs = 0;
    int nsp = 0;
    int n = 0;
    int[] fx = new int[5];
    int[] fz = new int[5];
    int[] fy = new int[5];
    boolean[] roted = new boolean[5];
    boolean[] special = new boolean[5];
    int fn = 0;
    int stage = (int) (Math.random() * 27.0) + 1;
    int nlaps = 0;
    int nfix = 0;
    boolean notb = false;
    String name = "hogan rewish";
    String maker = "";
    int pubt = 0;
    String trackname = "";
    int trackvol = 200;
    int top20 = 0;
    int nto = 0;
    int[] pos = { 7, 7, 7, 7, 7, 7, 7, 7 };
    int[] clear = { 0, 0, 0, 0, 0, 0, 0, 0 };
    int[] dested = { 0, 0, 0, 0, 0, 0, 0, 0 };
    float[] magperc = { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F };
    int wasted = 0;
    boolean haltall = false;
    int pcleared = 0;
    int[] opx = new int[8];
    int[] opz = new int[8];
    int[] onscreen = new int[8];
    int[] omxz = new int[8];
    int catchfin = 0;
    int postwo = 0;
    float prox = 0.0F;
    
    public void checkstat(Mad[] mads, ContO[] contos, Record record, int i,
			  int i_0_, int i_1_) {
	if (!((CheckPoints) this).haltall) {
	    ((CheckPoints) this).pcleared = ((Mad) mads[i_0_]).pcleared;
	    for (int i_2_ = 0; i_2_ < i; i_2_++) {
		((CheckPoints) this).magperc[i_2_]
		    = ((float) ((Mad) mads[i_2_]).hitmag
		       / (float) (((CarDefine) ((Mad) mads[i_2_]).cd).maxmag
				  [((Mad) mads[i_2_]).cn]));
		if (((CheckPoints) this).magperc[i_2_] > 1.0F)
		    ((CheckPoints) this).magperc[i_2_] = 1.0F;
		((CheckPoints) this).pos[i_2_] = 0;
		((CheckPoints) this).onscreen[i_2_]
		    = ((ContO) contos[i_2_]).dist;
		((CheckPoints) this).opx[i_2_] = ((ContO) contos[i_2_]).x;
		((CheckPoints) this).opz[i_2_] = ((ContO) contos[i_2_]).z;
		((CheckPoints) this).omxz[i_2_] = ((Mad) mads[i_2_]).mxz;
		if (((CheckPoints) this).dested[i_2_] == 0)
		    ((CheckPoints) this).clear[i_2_]
			= ((Mad) mads[i_2_]).clear;
		else
		    ((CheckPoints) this).clear[i_2_] = -1;
		((Mad) mads[i_2_]).outshakedam = ((Mad) mads[i_2_]).shakedam;
		((Mad) mads[i_2_]).shakedam = 0;
	    }
	    for (int i_3_ = 0; i_3_ < i; i_3_++) {
		for (int i_4_ = i_3_ + 1; i_4_ < i; i_4_++) {
		    if (((CheckPoints) this).clear[i_3_]
			!= ((CheckPoints) this).clear[i_4_]) {
			if (((CheckPoints) this).clear[i_3_]
			    < ((CheckPoints) this).clear[i_4_])
			    ((CheckPoints) this).pos[i_3_]++;
			else
			    ((CheckPoints) this).pos[i_4_]++;
		    } else {
			int i_5_ = ((Mad) mads[i_3_]).pcleared + 1;
			if (i_5_ >= ((CheckPoints) this).n)
			    i_5_ = 0;
			while (((CheckPoints) this).typ[i_5_] <= 0) {
			    if (++i_5_ >= ((CheckPoints) this).n)
				i_5_ = 0;
			}
			if (py(((ContO) contos[i_3_]).x / 100,
			       ((CheckPoints) this).x[i_5_] / 100,
			       ((ContO) contos[i_3_]).z / 100,
			       ((CheckPoints) this).z[i_5_] / 100)
			    > py(((ContO) contos[i_4_]).x / 100,
				 ((CheckPoints) this).x[i_5_] / 100,
				 ((ContO) contos[i_4_]).z / 100,
				 ((CheckPoints) this).z[i_5_] / 100))
			    ((CheckPoints) this).pos[i_3_]++;
			else
			    ((CheckPoints) this).pos[i_4_]++;
		    }
		}
	    }
	    if (((CheckPoints) this).stage > 2) {
		for (int i_6_ = 0; i_6_ < i; i_6_++) {
		    if ((((CheckPoints) this).clear[i_6_]
			 == (((CheckPoints) this).nlaps
			     * ((CheckPoints) this).nsp))
			&& ((CheckPoints) this).pos[i_6_] == 0) {
			if (i_6_ == i_0_) {
			    for (int i_7_ = 0; i_7_ < i; i_7_++) {
				if (((CheckPoints) this).pos[i_7_] == 1)
				    ((CheckPoints) this).postwo = i_7_;
			    }
			    if ((py(((CheckPoints) this).opx[i_0_] / 100,
				    (((CheckPoints) this).opx
				     [((CheckPoints) this).postwo]) / 100,
				    ((CheckPoints) this).opz[i_0_] / 100,
				    (((CheckPoints) this).opz
				     [((CheckPoints) this).postwo]) / 100)
				 < 14000)
				&& (((CheckPoints) this).clear[i_0_]
				    - (((CheckPoints) this).clear
				       [((CheckPoints) this).postwo])) == 1)
				((CheckPoints) this).catchfin = 30;
			} else if (((CheckPoints) this).pos[i_0_] == 1
				   && (py(((CheckPoints) this).opx[i_0_] / 100,
					  ((CheckPoints) this).opx[i_6_] / 100,
					  ((CheckPoints) this).opz[i_0_] / 100,
					  ((CheckPoints) this).opz[i_6_] / 100)
				       < 14000)
				   && ((((CheckPoints) this).clear[i_6_]
					- ((CheckPoints) this).clear[i_0_])
				       == 1)) {
			    ((CheckPoints) this).catchfin = 30;
			    ((CheckPoints) this).postwo = i_6_;
			}
		    }
		}
	    }
	}
	((CheckPoints) this).wasted = 0;
	for (int i_8_ = 0; i_8_ < i; i_8_++) {
	    if ((i_0_ != i_8_ || i_1_ >= 2) && ((Mad) mads[i_8_]).dest)
		((CheckPoints) this).wasted++;
	}
	if (((CheckPoints) this).catchfin != 0 && i_1_ < 2) {
	    ((CheckPoints) this).catchfin--;
	    if (((CheckPoints) this).catchfin == 0) {
		record.cotchinow(((CheckPoints) this).postwo);
		((Record) record).closefinish
		    = ((CheckPoints) this).pos[i_0_] + 1;
	    }
	}
    }
    
    public void calprox() {
	int i = 0;
	for (int i_9_ = 0; i_9_ < ((CheckPoints) this).n - 1; i_9_++) {
	    for (int i_10_ = i_9_ + 1; i_10_ < ((CheckPoints) this).n;
		 i_10_++) {
		if (Math.abs(((CheckPoints) this).x[i_9_]
			     - ((CheckPoints) this).x[i_10_])
		    > i)
		    i = Math.abs(((CheckPoints) this).x[i_9_]
				 - ((CheckPoints) this).x[i_10_]);
		if (Math.abs(((CheckPoints) this).z[i_9_]
			     - ((CheckPoints) this).z[i_10_])
		    > i)
		    i = Math.abs(((CheckPoints) this).z[i_9_]
				 - ((CheckPoints) this).z[i_10_]);
	    }
	}
	((CheckPoints) this).prox = (float) i / 90.0F;
    }
    
    public int py(int i, int i_11_, int i_12_, int i_13_) {
	return (i - i_11_) * (i - i_11_) + (i_12_ - i_13_) * (i_12_ - i_13_);
    }
}
