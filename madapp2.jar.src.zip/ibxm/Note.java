package ibxm;

public class Note
{
  public int key;
  public int instrument;
  public int volume;
  public int effect;
  public int param;
}


/* Location:              E:\Games\Need For Madness\data\madapp.jar!\ibxm\Note.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */