package ibxm;

public class GlobalVol
{
  public int volume;
}


/* Location:              E:\Games\Need For Madness\data\madapp.jar!\ibxm\GlobalVol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */