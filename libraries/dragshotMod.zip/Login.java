// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Login.java

import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.*;
import java.net.*;
import java.util.Date;

public class Login
    implements Runnable
{

    public Login(Medium medium, Graphics2D graphics2d, xtGraphics var_xtGraphics, GameSparker gamesparker)
    {
        nmsgs = 0;
        nconf = 0;
        nfreq = 0;
        ncreq = 0;
        fclan = 0;
        fplayer = 0;
        clanapv = "";
        justlog = false;
        cntgame = 0;
        gamec = -1;
        groom = 0;
        gmaker = "";
        gservern = "";
        fase = 0;
        btn = 0;
        nflk = 0;
        ncnt = 0;
        errcnt = 0;
        lrgfase = 0;
        msg = "";
        lnick = "";
        lpass = "";
        lemail = "";
        onf = false;
        nickero = false;
        jflk = false;
        ond = false;
        opselect = 0;
        trans = 0;
        cntcl = 0;
        contrb = false;
        nservers = 2;
        IPAddress = new InetAddress[3];
        dSocket = new DatagramSocket[3];
        socketson = false;
        srvtrn = 0;
        recom = 0;
        resofaso = false;
        checknote = false;
        pend = 0;
        pendb = false;
        gotcai = false;
        cax = 0;
        cay = 0;
        btroom = false;
        showtf = false;
        flipo = 0;
        xrl = 0;
        xrr = 0;
        onr = false;
        oxm = 0;
        oym = 0;
        lxm = 0;
        lym = 0;
        m = medium;
        rd = graphics2d;
        xt = var_xtGraphics;
        gs = gamesparker;
        if(xt.playingame != -1)
            fase = 18;
        if(xt.nofull)
            nservers = 1;
    }

    public void inishmulti()
    {
        gs.tnick.hide();
        gs.tnick.enable();
        gs.tnick.setForeground(new Color(0, 0, 0));
        gs.tnick.setBackground(color2k(240, 240, 240));
        gs.tpass.hide();
        gs.tpass.enable();
        gs.tpass.setForeground(new Color(0, 0, 0));
        gs.tpass.setBackground(color2k(240, 240, 240));
        gs.temail.hide();
        gs.temail.enable();
        gs.temail.setForeground(new Color(0, 0, 0));
        gs.temail.setBackground(color2k(240, 240, 240));
        gs.keplo.hide();
        gs.keplo.enable();
        gs.keplo.setForeground(new Color(0, 0, 0));
        gs.keplo.setBackground(new Color(193, 181, 142));
        gs.requestFocus();
        if(gs.tnick.getText().equals(""))
            gs.tnick.setText("Nickname");
        for(int i = 0; i < 6; i++)
            pessd[i] = false;

        nflk = 0;
        ncnt = 0;
        errcnt = 0;
        onf = false;
        ond = false;
        msg = "";
        btroom = false;
        gotcai = false;
        m.crs = true;
        m.x = -335;
        m.y = 0;
        m.z = -50;
        m.xz = 0;
        m.zy = 20;
        m.ground = -2000;
        pend = 0;
        pendb = false;
        resofaso = false;
        for(int i = 0; i < nservers; i++)
        {
            serverdone[i] = -1;
            servestart[i] = 0L;
        }

        checknote = false;
        if(xt.gotlog)
        {
            checknote = true;
            socketson = false;
            fase = 12;
            connector = new Thread(this);
            connector.start();
        } else
        {
            msg = "Login to access the multiplayer madness!";
            gs.tnick.setText(xt.nickname);
            fase = 3;
        }
    }

    public void exitfromlobby()
    {
        if(!xt.lan)
            opselect = 0;
        else
            opselect = 1;
        for(int i = 0; i < nservers; i++)
        {
            serverdone[i] = -1;
            servestart[i] = 0L;
        }

        for(int i = 0; i < 6; i++)
            pessd[i] = false;

        gotcai = false;
        btroom = false;
        m.crs = true;
        m.x = -335;
        m.y = 0;
        m.z = -50;
        m.xz = 0;
        m.zy = 20;
        m.ground = -2000;
        pend = 0;
        pendb = false;
        gamec = -1;
        socketson = false;
        if(!xt.lan)
        {
            msg = "| Connecting to Servers |";
            trans = 0;
            fase = 13;
            nflk = 0;
        } else
        {
            fase = 12;
        }
        System.gc();
        connector = new Thread(this);
        connector.start();
    }

    public void endcons()
    {
        for(int i = 0; i < nservers; i++)
            try
            {
                dSocket[i].close();
                dSocket[i] = null;
            }
            catch(Exception exception) { }

        try
        {
            socket.close();
            socket = null;
            din.close();
            din = null;
            dout.close();
            dout = null;
        }
        catch(Exception exception) { }
    }

    public void checknotifcations()
    {
        int i = 0;
        int i_0 = 0;
        int i_1 = 0;
        int i_2 = 0;
        int i_3 = 0;
        String string = "";
        int i_4 = 0;
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(xt.nickname).append("/notify.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_5 = url.openConnection().getContentType();
            if(string_5.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_6 = "";
                for(int i_7 = 0; (string_6 = datainputstream.readLine()) != null && i_7 < 5; i_7++)
                {
                    string_6 = string_6.trim();
                    if(i_7 == 0)
                    {
                        for(String string_8 = getSvalue(string_6, i); !string_8.equals(""); string_8 = getSvalue(string_6, i))
                        {
                            if(string_8.startsWith("clan: "))
                                i_0++;
                            else
                            if(!string_8.startsWith("your clan"))
                                i_1++;
                            i++;
                        }

                    }
                    if(i_7 == 1)
                    {
                        boolean bool = false;
                        int i_9;
                        try
                        {
                            i_9 = Integer.valueOf(string_6).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_9 = 0;
                        }
                        i_2 = i_9;
                    }
                    if(i_7 == 2)
                    {
                        boolean bool = false;
                        int i_10;
                        try
                        {
                            i_10 = Integer.valueOf(string_6).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_10 = 0;
                        }
                        i_3 = i_10;
                    }
                    if(i_7 == 3)
                        string = getSvalue(string_6, 0);
                    if(i_7 != 4)
                        continue;
                    for(String string_11 = getSvalue(string_6, i_4); !string_11.equals(""); string_11 = getSvalue(string_6, i_4))
                        i_4++;

                }

                datainputstream.close();
            }
        }
        catch(Exception exception) { }
        nmsgs = i;
        fclan = i_0;
        fplayer = i_1;
        nfreq = i_2;
        nconf = i_3;
        clanapv = string;
        ncreq = i_4;
    }

    public void gamealert()
    {
        try
        {
            socket = new Socket(servers[0], 7061);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
            dout.println((new StringBuilder()).append("101|20|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(xt.servername).append("|").append(xt.servport - 7070).append("|").toString());
            String string = din.readLine();
            socket.close();
            din.close();
            dout.close();
        }
        catch(Exception exception) { }
    }

    public void checkgamealerts()
    {
        try
        {
            socket = new Socket(servers[0], 7061);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
            dout.println("101|21|");
            String string = din.readLine();
            if(string != null)
            {
                int i = getvalue(string, 0);
                if(i != -1 && i != gamec)
                {
                    String string_12 = getSvalue(string, 2);
                    int i_13 = getvalue(string, 3);
                    boolean bool = false;
                    if(!string_12.equals(xt.servername) || i_13 != xt.servport - 7070)
                    {
                        for(int i_14 = 0; i_14 < nservers; i_14++)
                            if(string_12.equals(snames[i_14]) && xt.delays[i_14] < 300)
                                bool = true;

                    }
                    if(bool)
                    {
                        gmaker = getSvalue(string, 1);
                        if(gmaker.equals(xt.nickname))
                            gmaker = "You";
                        groom = i_13;
                        gservern = string_12;
                        gamec = i;
                        cntgame = 0;
                    }
                }
            }
            socket.close();
            din.close();
            dout.close();
        }
        catch(Exception exception) { }
    }

    public void run()
    {
        if(checknote)
        {
            checknotifcations();
            checknote = false;
        }
        if(fase == 2)
        {
            gs.setCursor(new Cursor(3));
            int i = -1;
            int i_15 = -1;
            try
            {
                socket = new Socket(servers[0], 7061);
                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                dout.println((new StringBuilder()).append("0|").append(gs.tnick.getText()).append("|").toString());
                String string = din.readLine();
                if(string != null)
                {
                    i = getvalue(string, 0);
                    if(i == 0)
                    {
                        i_15 = getvalue(string, 1);
                        xt.hours = getvalue(string, 2);
                        xt.nickey = getSvalue(string, 3);
                        System.out.println((new StringBuilder()).append("Nickey: ").append(xt.nickey).toString());
                    }
                }
                socket.close();
                din.close();
                dout.close();
            }
            catch(Exception exception) { }
            gs.tnick.enable();
            if(i == -1)
            {
                msg = "Unable to connect to any server at this moment.  Please try again later.";
                fase = 1;
            }
            if(i == 0)
            {
                xt.nickname = gs.tnick.getText();
                if(i_15 != -1)
                    xt.nfreeplays = i_15;
                gs.tnick.hide();
                gs.tpass.hide();
                gs.temail.hide();
                gs.keplo.hide();
                gs.requestFocus();
                xt.logged = false;
                fase = 12;
                System.gc();
            }
            if(i == 1)
            {
                msg = "This Nickname is being used by someone else right now.  Please use another.";
                nickero = true;
                gs.tnick.setForeground(new Color(255, 0, 0));
                gs.tnick.requestFocus();
                errcnt = 30;
                fase = 1;
            }
            if(i == 2)
            {
                msg = "Nickname registerd.  Please use another or click 'Login' bellow to login to this Nickname.";
                nickero = true;
                gs.tnick.setForeground(new Color(255, 0, 0));
                gs.tnick.requestFocus();
                errcnt = 30;
                fase = 1;
            }
            gs.setCursor(new Cursor(0));
        }
        if(fase == 4)
        {
            gs.setCursor(new Cursor(3));
            int i = -1;
            int i_16 = -1;
            String string = "";
            try
            {
                socket = new Socket(servers[0], 7061);
                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                dout.println((new StringBuilder()).append("1|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").toString());
                string = din.readLine();
                if(string != null)
                {
                    i = getvalue(string, 0);
                    if(i == 0 || i == 3 || i > 10 || i == -167)
                    {
                        xt.nickey = getSvalue(string, 1);
                        if(i != -167)
                        {
                            xt.clan = getSvalue(string, 2);
                            xt.clankey = getSvalue(string, 3);
                        } else
                        {
                            xt.clan = "";
                            xt.clankey = "";
                            i_16 = getvalue(string, 2);
                            xt.hours = getvalue(string, 3);
                        }
                        System.out.println((new StringBuilder()).append("Nickey: ").append(xt.nickey).append(", Clankey: ").append(xt.clankey).toString());
                    }
                }
                socket.close();
                din.close();
                dout.close();
            }
            catch(Exception exception) { }
            gs.tnick.enable();
            gs.tpass.enable();
            gs.keplo.enable();
            if(i == -1)
            {
                msg = "Unable to connect to server at this moment.  Please try again later.";
                fase = 3;
            }
            if(i == 0 || i == 3 || i > 10 || i == -167 || i == 111)
            {
                xt.nickname = gs.tnick.getText();
                showtf = false;
                gs.tnick.hide();
                gs.tpass.hide();
                gs.temail.hide();
                gs.keplo.hide();
                gs.requestFocus();
                gs.setloggedcookie();
                btroom = false;
                xt.logged = true;
                xt.gotlog = true;
                if(i == 0)
                    xt.acexp = 0;
                if(i > 10)
                    xt.acexp = i - 10;
                if(i == 3)
                    xt.acexp = -1;
                if(i == -167)
                {
                    xt.logged = false;
                    if(i_16 != -1)
                    {
                        xt.nfreeplays = i_16;
                        System.out.println((new StringBuilder()).append("xt.nfreeplays=").append(xt.nfreeplays).toString());
                    }
                }
                if(xt.logged)
                    xt.backlog = xt.nickname;
                fase = 12;
                justlog = true;
                checknotifcations();
                System.gc();
            }
            if(i == 1)
            {
                msg = "Sorry.  The Nickname you have entered is incorrect or does not exist.";
                gs.tnick.setForeground(new Color(255, 0, 0));
                gs.tnick.requestFocus();
                errcnt = 40;
                fase = 3;
            }
            if(i == 2)
            {
                msg = "Sorry.  The Password you have entered is incorrect.";
                gs.tpass.setForeground(new Color(255, 0, 0));
                gs.tpass.requestFocus();
                errcnt = 40;
                fase = 3;
            }
            gs.setCursor(new Cursor(0));
        }
        if(fase == 8)
        {
            gs.setCursor(new Cursor(3));
            int i = -1;
            try
            {
                socket = new Socket(servers[0], 7061);
                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                dout.println((new StringBuilder()).append("2|").append(gs.temail.getText().toLowerCase()).append("|").toString());
                String string = din.readLine();
                if(string != null)
                    i = getvalue(string, 0);
                socket.close();
                din.close();
                dout.close();
            }
            catch(Exception exception) { }
            gs.temail.enable();
            if(i == -1)
            {
                msg = "Unable to connect to server at this moment.  Please try again later.";
                fase = 7;
            }
            if(i == 0)
            {
                showtf = false;
                gs.temail.hide();
                msg = (new StringBuilder()).append("Please check your Email: ").append(gs.temail.getText()).append(" to login.").toString();
                gs.temail.setText("");
                gs.tnick.setText("");
                gs.tpass.setText("");
                fase = 3;
            }
            if(i == 1)
            {
                msg = "Sorry.  This Email Address does not exist in our system!";
                gs.temail.setForeground(new Color(255, 0, 0));
                errcnt = 40;
                fase = 7;
            }
            gs.setCursor(new Cursor(0));
        }
        if((fase == 12 || fase == 13 || fase == 14 || fase == 15) && !socketson)
        {
            for(int i = 0; i < nservers; i++)
                try
                {
                    serverdone[i] = -1;
                    IPAddress[i] = InetAddress.getByName(servers[i]);
                    dSocket[i] = new DatagramSocket(7001 + i);
                }
                catch(Exception exception)
                {
                    serverdone[i] = 5;
                }

            srvtrn = 0;
            socketson = true;
        }
        while(fase == 12 || fase == 13 || fase == 14 || fase == 15) 
        {
            if(srvtrn < nservers)
            {
                for(; serverdone[srvtrn] < xt.cntptrys; serverdone[srvtrn]++)
                {
                    if(serverdone[srvtrn] == -1)
                        serverdone[srvtrn] = 0;
                    Date date = new Date();
                    servestart[srvtrn] = date.getTime();
                    try
                    {
                        byte is[] = new byte[4];
                        DatagramPacket datagrampacket = new DatagramPacket(is, is.length, IPAddress[srvtrn], 7000);
                        String string = (new StringBuilder()).append("").append(xt.nickname).append("|").toString();
                        byte is_17[] = string.getBytes();
                        datagrampacket.setData(is_17);
                        dSocket[srvtrn].send(datagrampacket);
                        dSocket[srvtrn].receive(datagrampacket);
                        String string_18 = new String(datagrampacket.getData());
                        if(!string_18.startsWith("OK"))
                            continue;
                        date = new Date();
                        if(date.getTime() - servestart[srvtrn] < (long)xt.delays[srvtrn])
                            xt.delays[srvtrn] = (int)(date.getTime() - servestart[srvtrn]);
                        continue;
                    }
                    catch(Exception exception)
                    {
                        xt.delays[srvtrn] = 600;
                    }
                    serverdone[srvtrn] = 5;
                }

                srvtrn++;
            } else
            if(fase == 13)
            {
                int i = -1;
                boolean bool = false;
                for(int i_19 = 0; i_19 < nservers; i_19++)
                {
                    if(xt.delays[i_19] < i || i == -1)
                    {
                        i = xt.delays[i_19];
                        opselect = i_19;
                    }
                    if(xt.delays[i_19] >= 600)
                        bool = true;
                }

                if(!bool)
                {
                    xt.cntptrys -= 2;
                    if(xt.cntptrys < 1)
                        xt.cntptrys = 1;
                }
                fase = 14;
            }
            try
            {
                if(connector == null);
                Thread.sleep(5L);
            }
            catch(InterruptedException interruptedexception) { }
        }
        if(fase != 12 && fase != 13 && fase != 14 && fase != 15 && fase != 5 && socketson)
        {
            for(int i = 0; i < nservers; i++)
                try
                {
                    dSocket[i].close();
                    dSocket[i] = null;
                }
                catch(Exception exception) { }

            socketson = false;
        }
        if(fase == 16 || fase == 17)
        {
            boolean bool = false;
            int i = 0;
            int i_20 = -1;
            recom = 0;
            try
            {
                socket = new Socket(xt.server, 7067);
                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
            }
            catch(Exception exception) { }
            do
            {
                if(fase != 16 && fase != 17 || i == 3)
                    break;
                String string = "";
                if(!bool)
                {
                    try
                    {
                        dout.println("10|");
                        String string_21 = din.readLine();
                        if(string_21 == null)
                            bool = true;
                        else
                            string = string_21;
                    }
                    catch(Exception exception)
                    {
                        bool = true;
                    }
                    if(bool)
                    {
                        try
                        {
                            socket.close();
                            socket = null;
                            din.close();
                            din = null;
                            dout.close();
                            dout = null;
                        }
                        catch(Exception exception) { }
                        try
                        {
                            socket = new Socket(xt.server, 7067);
                            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                            dout.println("10|");
                            String string_22 = din.readLine();
                            if(string_22 != null)
                                bool = false;
                            else
                                string = string_22;
                        }
                        catch(Exception exception)
                        {
                            bool = true;
                        }
                    }
                    if(bool)
                        try
                        {
                            socket.close();
                            socket = null;
                        }
                        catch(Exception exception) { }
                }
                if(!bool)
                {
                    for(int i_23 = 0; i_23 < 5; i_23++)
                    {
                        rmps[i_23] = getvalue(string, i_23 * 2);
                        rmwt[i_23] = getvalue(string, 1 + i_23 * 2);
                    }

                    int i_24 = 1000;
                    for(int i_25 = 0; i_25 < 5; i_25++)
                        if(Math.abs(rmps[i_25] - 6) < i_24)
                        {
                            recom = i_25;
                            i_24 = Math.abs(rmps[i_25] - 6);
                        }

                    if(recom != i_20)
                    {
                        opselect = recom;
                        i_20 = recom;
                    }
                    if(fase == 16)
                        fase = 17;
                } else
                {
                    msg = "Failed to connect to this Server!";
                    i++;
                }
                if(i != 3)
                    try
                    {
                        if(connector == null);
                        Thread.sleep(2000L);
                    }
                    catch(InterruptedException interruptedexception) { }
            } while(true);
            try
            {
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception) { }
            if(i == 3)
                resofaso = true;
        }
    }

    public void stopallnow()
    {
        if(connector != null)
        {
            connector.stop();
            connector = null;
        }
        endcons();
    }

    public void multimode(ContO contos[])
    {
        btn = 0;
        xt.mainbg(4);
        for(int i = 0; i < 3; i++)
        {
            rd.drawImage(xt.bgmain, 65, bgmy[i], null);
            bgmy[i] -= 4;
            if(bgmy[i] <= -400)
                bgmy[i] = 800;
        }

        rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
        rd.drawImage(xt.bggo, 0, 0, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(65, 425, 670, 25);
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        float f = 1.0F - (float)(flipo - 10) / 80F;
        if(f > 1.0F)
            f = 1.0F;
        if(f < 0.0F)
            f = 0.0F;
        rd.setComposite(AlphaComposite.getInstance(3, f));
        if(flipo > 10)
            rd.drawImage(xt.logomadnes, 96 + (int)(2D - Math.random() * 4D), 11 + (int)(2D - Math.random() * 4D), null);
        else
            rd.drawImage(xt.logomadnes, 96, 11, null);
        flipo++;
        if(flipo > 50)
            flipo = 0;
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        drawSbutton(xt.exit, 690, 17);
        rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
        rd.setColor(new Color(203, 227, 253));
        rd.fillRoundRect(319, 83, 180, 96, 20, 20);
        rd.fillRoundRect(173, 83, 132, 32, 20, 20);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setColor(color2k(90, 90, 90));
        rd.drawRoundRect(319, 83, 180, 96, 20, 20);
        rd.drawRoundRect(173, 83, 132, 32, 20, 20);
        if(!gotcai)
        {
            int i = contos[xt.sc[0]].p[0].oz[0];
            int i_26 = i;
            int i_27 = contos[xt.sc[0]].p[0].oy[0];
            int i_28 = i_27;
            for(int i_29 = 0; i_29 < contos[xt.sc[0]].npl; i_29++)
            {
                for(int i_30 = 0; i_30 < contos[xt.sc[0]].p[i_29].n; i_30++)
                {
                    if(contos[xt.sc[0]].p[i_29].oz[i_30] < i)
                        i = contos[xt.sc[0]].p[i_29].oz[i_30];
                    if(contos[xt.sc[0]].p[i_29].oz[i_30] > i_26)
                        i_26 = contos[xt.sc[0]].p[i_29].oz[i_30];
                    if(contos[xt.sc[0]].p[i_29].oy[i_30] < i_27)
                        i_27 = contos[xt.sc[0]].p[i_29].oy[i_30];
                    if(contos[xt.sc[0]].p[i_29].oy[i_30] > i_28)
                        i_28 = contos[xt.sc[0]].p[i_29].oy[i_30];
                }

            }

            cax = (i_26 + i) / 2;
            cay = (i_28 + i_27) / 2;
            gotcai = true;
        }
        contos[xt.sc[0]].z = 1500;
        contos[xt.sc[0]].y = 380 - cay;
        contos[xt.sc[0]].x = 100 - cax;
        contos[xt.sc[0]].zy = 0;
        contos[xt.sc[0]].xz = -90;
        contos[xt.sc[0]].xy = pend;
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        contos[xt.sc[0]].d(rd);
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if(!pendb)
        {
            pend += 2;
            if(pend > 80)
                pendb = true;
        } else
        {
            pend -= 2;
            if(pend < -10)
                pendb = false;
        }
        rd.setFont(new Font("Arial", 1, 13));
        ftm = rd.getFontMetrics();
        rd.setColor(new Color(0, 0, 0));
        rd.drawString(xt.nickname, 239 - ftm.stringWidth(xt.nickname) / 2, 105);
        rd.setColor(color2k(90, 90, 90));
        rd.drawString((new StringBuilder()).append("").append(xt.cd.names[xt.sc[0]]).append("").toString(), 409 - ftm.stringWidth((new StringBuilder()).append("").append(xt.cd.names[xt.sc[0]]).append("").toString()) / 2, 81);
        rd.drawString("Nickname", 239 - ftm.stringWidth("Nickname") / 2, 81);
        drawbutton(xt.change, 570, 98);
        drawSbutton(xt.logout, 239, 135);
        rd.setColor(new Color(98, 56, 0));
        rd.drawString("Edit my Account", 239 - ftm.stringWidth("Edit my Account") / 2, 168);
        if(ond)
            rd.drawLine(239 - ftm.stringWidth("Edit my Account") / 2, 169, (239 - ftm.stringWidth("Edit my Account") / 2) + ftm.stringWidth("Edit my Account"), 169);
        if(fase == 12 || fase == 13 || fase == 14 || fase == 15)
        {
            int i = srvtrn;
            if(i < nservers && serverdone[i] != -1)
            {
                Date date = new Date();
                if(date.getTime() - servestart[i] > 1500L)
                {
                    if(connector != null)
                    {
                        connector.stop();
                        connector = null;
                    }
                    xt.delays[i] = 600;
                    serverdone[i] = 5;
                    connector = new Thread(this);
                    connector.start();
                }
            }
        }
        if(fase == 12)
            if(xt.acexp == 0 || contrb)
            {
                rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                rd.setColor(new Color(203, 227, 253));
                rd.fillRoundRect(205, 225, 390, 120, 20, 20);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                rd.setColor(color2k(90, 90, 90));
                rd.drawString("Multiplayer Mode", 400 - ftm.stringWidth("Multiplayer Mode") / 2, 220);
                rd.drawRoundRect(205, 225, 390, 120, 20, 20);
                if(opselect == 0 && !pessd[3])
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                    rd.setColor(new Color(203, 227, 253));
                    rd.fillRect(387 - xt.pon.getWidth(ob) / 2, 242, xt.pon.getWidth(ob) + 26, 26);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                }
                drawbutton(xt.pon, 400, 255);
                if(opselect == 1 && !pessd[4])
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                    rd.setColor(new Color(203, 227, 253));
                    rd.fillRect(387 - xt.pln.getWidth(ob) / 2, 302, xt.pln.getWidth(ob) + 26, 26);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                }
                drawbutton(xt.pln, 400, 315);
                if(!xt.logged)
                {
                    rd.setColor(new Color(30, 70, 110));
                    rd.drawString("You can play 1 multiplayer turn per day to try the game with your trial account.", 400 - ftm.stringWidth("You can play 1 multiplayer turn per day to try the game with your trial account.") / 2, 368);
                    rd.drawString("Upgrade your account to purchase the game.", 400 - ftm.stringWidth("You can play 1 multiplayer turn per day to try the game with your trial account.") / 2, 385);
                    drawSbutton(xt.upgrade, 400, 406);
                }
            } else
            {
                rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                rd.setColor(new Color(203, 227, 253));
                rd.fillRoundRect(165, 219, 470, 135, 20, 20);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                rd.setColor(color2k(90, 90, 90));
                rd.drawRoundRect(165, 219, 470, 135, 20, 20);
                if(xt.acexp > 0)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Dear ").append(xt.nickname).append(",").toString(), 185, 245);
                    rd.drawString((new StringBuilder()).append("Your account is due to expire in ").append(xt.acexp).append(" days.").toString(), 185, 265);
                    rd.drawString("Renew your registration soon!", 185, 295);
                    stringbutton("Renew my Account Registration now!", 345, 332, 0);
                    stringbutton("Renew Later", 524, 332, 0);
                }
                if(xt.acexp == -1)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Dear ").append(xt.nickname).append(",").toString(), 185, 245);
                    rd.drawString("Your Need for Madness account registration has expired.", 185, 265);
                    rd.drawString("Please renew your registration.", 185, 295);
                    stringbutton("Renew my account registration now!", 362, 332, 0);
                    stringbutton("Cancel", 524, 332, 0);
                }
                if(xt.acexp == -2)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Dear ").append(xt.nickname).append(",").toString(), 185, 245);
                    rd.drawString("Trial accounts are not allowed to access the downloaded game.", 185, 265);
                    rd.drawString("You can only play the game online using your trial account.", 185, 295);
                    stringbutton("Play the multiplayer online!", 362, 332, 0);
                    stringbutton("Cancel", 524, 332, 0);
                }
                if(xt.acexp == -3)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Some one else is already logged in the game with your account.", 185, 245);
                    rd.drawString("If you where just in the game then quitted it suddenly, it could just", 185, 265);
                    rd.drawString("be your 'ghost entry', if so please wait a few minutes and try again.", 185, 285);
                    rd.drawString("Otherwise please consider changing your password.", 185, 305);
                    stringbutton("Change Password", 332, 336, 0);
                    stringbutton("Try Again", 494, 336, 0);
                }
            }
        if(fase == 13 || fase == 14 || fase == 16 || fase == 17)
        {
            if(trans < 40)
                rd.drawImage(xt.pon, 400 - xt.pon.getWidth(ob) / 2, 255 - xt.pon.getHeight(ob) / 2 - 12 - trans, null);
            else
                rd.drawImage(xt.pon, 400 - xt.pon.getWidth(ob) / 2, 215 - xt.pon.getHeight(ob) / 2 - 12, null);
            if(trans >= 40)
            {
                rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                rd.setColor(new Color(203, 227, 253));
                rd.fillRoundRect(165, 219, 470, 150, 20, 20);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                rd.setColor(color2k(90, 90, 90));
                rd.drawRoundRect(165, 219, 470, 150, 20, 20);
                drawbutton(xt.cancel, 583, 395);
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(fase == 13)
                {
                    rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 295);
                    if(msg.equals(". . . | Connecting to Servers | . . .") && ncnt == 0)
                    {
                        msg = "| Connecting to Servers |";
                        ncnt = 5;
                    }
                    if(msg.equals(". . | Connecting to Servers | . .") && ncnt == 0)
                    {
                        msg = ". . . | Connecting to Servers | . . .";
                        ncnt = 5;
                    }
                    if(msg.equals(". | Connecting to Servers | .") && ncnt == 0)
                    {
                        msg = ". . | Connecting to Servers | . .";
                        ncnt = 5;
                    }
                    if(msg.equals("| Connecting to Servers |") && ncnt == 0)
                    {
                        msg = ". | Connecting to Servers | .";
                        ncnt = 5;
                    }
                    if(ncnt != 0)
                        ncnt--;
                }
                if(fase == 16)
                {
                    rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 295);
                    if(msg.equals(". . . | Finding Rooms | . . .") && ncnt == 0)
                    {
                        msg = "| Finding Rooms |";
                        ncnt = 5;
                    }
                    if(msg.equals(". . | Finding Rooms | . .") && ncnt == 0)
                    {
                        msg = ". . . | Finding Rooms | . . .";
                        ncnt = 5;
                    }
                    if(msg.equals(". | Finding Rooms | .") && ncnt == 0)
                    {
                        msg = ". . | Finding Rooms | . .";
                        ncnt = 5;
                    }
                    if(msg.equals("| Finding Rooms |") && ncnt == 0)
                    {
                        msg = ". | Finding Rooms | .";
                        ncnt = 5;
                    }
                    if(ncnt != 0)
                        ncnt--;
                }
                if(fase == 14)
                {
                    msg = "";
                    int i = 0;
                    if(!xt.nofull)
                    {
                        for(int i_31 = 0; i_31 < nservers; i_31++)
                            if(xt.delays[i_31] >= 400)
                                i++;

                    }
                    if(i != nservers)
                    {
                        boolean bool = false;
                        int i_32 = 0;
                        for(int i_33 = 0; i_33 < nservers; i_33++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(opselect == i_33)
                            {
                                rd.setColor(new Color(98, 56, 0));
                                rd.fillRoundRect(175, 230 + i_33 * 40, 450, 40, 14, 14);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawRoundRect(175, 230 + i_33 * 40, 450, 40, 14, 14);
                                rd.setColor(color2k(255, 255, 255));
                                if(xt.delays[i_33] >= 400)
                                {
                                    msg = "Your connection to this server is too slow!";
                                    i_32 = 1;
                                }
                                if(xt.delays[i_33] == 600)
                                {
                                    msg = "This server is not responding!";
                                    i_32 = 1;
                                }
                                if(xt.delays[i_33] < 400)
                                {
                                    for(int i_34 = 0; i_34 < nservers; i_34++)
                                        if(xt.delays[i_34] < xt.delays[i_33] && i_33 != i_34)
                                            bool = true;

                                    if(bool)
                                        msg = "It is recommended to choose the fastest server.";
                                    else
                                    if(xt.delays[i_33] >= 300)
                                        msg = "Your connection speed is not perfect.  You may encounter delay!";
                                }
                            }
                            int i_35 = 0;
                            int i_36 = 0;
                            int bars = 0;
                            String string = (new StringBuilder()).append(xt.delays[i_33]).append("ms").toString();
                            if(xt.delays[i_33] < 75)
                            {
                                bars = 5;
                                i_35 = 62;
                                i_36 = 100;
                            }
                            if(xt.delays[i_33] >= 75 && xt.delays[i_33] < 150)
                            {
                                bars = 4;
                                i_35 = 62;
                                i_36 = 100;
                            }
                            if(xt.delays[i_33] >= 150 && xt.delays[i_33] < 250)
                            {
                                bars = 3;
                                i_35 = 81;
                                i_36 = 100;
                            }
                            if(xt.delays[i_33] >= 250 && xt.delays[i_33] < 400)
                            {
                                bars = 2;
                                i_35 = 100;
                                i_36 = 100;
                            }
                            if(xt.delays[i_33] >= 400 && xt.delays[i_33] < 600)
                            {
                                bars = 1;
                                i_35 = 100;
                                i_36 = 0;
                            }
                            if(xt.delays[i_33] == 600)
                                string = "Not Responding";
                            if(opselect == i_33)
                            {
                                i_35 = (int)((float)i_35 * 2.55F);
                                i_36 = (int)((float)i_36 * 2.55F);
                            }
                            if(i_35 > 255)
                                i_35 = 255;
                            if(i_35 < 0)
                                i_35 = 0;
                            if(i_36 > 255)
                                i_36 = 255;
                            if(i_36 < 0)
                                i_36 = 0;
                            rd.setColor(new Color(i_35, i_36, 0));
                            rd.setFont(new Font("Arial", 3, 24));
                            rd.drawString(snames[i_33], 185, 258 + i_33 * 40);
                            for(int l = 0; l < 5; l++)
                            {
                                if(l >= bars)
                                    rd.setColor(new Color(0, 0, 0, 75));
                                rd.fillRect(576 + 9 * l, (257 - 5 * l) + i_33 * 40, 7, 7 + 5 * l);
                            }

                            rd.setColor(opselect != i_33 ? Color.BLACK : Color.WHITE);
                            rd.setFont(new Font("Arial", 1, 13));
                            rd.drawString(string, 568 - ftm.stringWidth(string), 264 + i_33 * 40);
                        }

                        if(!xt.logged && xt.nfreeplays - xt.ndisco >= 1 && i_32 == 0)
                        {
                            msg = "You have played your trial game today, please upgrade your account.";
                            i_32 = 2;
                        }
                        if(xt.nofull)
                        {
                            if(nflk % 4 != 0 || nflk == 0)
                            {
                                rd.setFont(new Font("Arial", 0, 13));
                                ftm = rd.getFontMetrics();
                                rd.setColor(new Color(200, 0, 0));
                                rd.drawString("Warning! You did not allow the game full permissions when you started it.", 175, 275);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString("(You didn't click 'Run' at the prompt that came up at the start of the game).", 175, 292);
                                rd.drawString("Because of this you will be able to connect to ONLY the game's main server:", 175, 309);
                                rd.drawString((new StringBuilder()).append("'").append(snames[0]).append("', which is not necessarily the fastest server you can connect to.").toString(), 175, 326);
                                rd.drawString("Please allow Java full permissions next time to be able to play on all servers!", 175, 343);
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                            }
                        } else
                        {
                            if(i_32 == 0)
                                rd.setColor(new Color(98, 56, 0));
                            if(i_32 == 1)
                                rd.setColor(new Color(200, 0, 0));
                            if(i_32 == 2)
                                rd.setColor(new Color(30, 70, 110));
                            if(nflk % 4 != 0 || nflk == 0)
                                rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 360);
                            if(nflk != 0)
                                nflk--;
                        }
                    } else
                    {
                        if(nflk % 4 != 0 || nflk == 0)
                        {
                            rd.setColor(new Color(200, 0, 0));
                            rd.drawString("Sorry.  Your connection is currently not fast enough to play online!", 400 - ftm.stringWidth("Sorry.  Your connection is currently not fast enough to play online!") / 2, 242);
                        }
                        if(nflk != 0)
                            nflk--;
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 0, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Please make sure you or anyone else using this connection is not slowing", 181, 265);
                        rd.drawString("it down right now by downloading or streaming.", 181, 282);
                        rd.drawString("Also please make sure you don't have any other programs running on your", 181, 299);
                        rd.drawString("computer that maybe consuming your bandwidth.", 181, 316);
                        rd.drawString("Otherwise you may need to upgrade your connection speed to play!", 181, 333);
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Press 'Cancel' to try again or to try playing a Lan game instead.", 400 - ftm.stringWidth("Press 'Cancel' to try again or to try playing a Lan game instead.") / 2, 357);
                    }
                    drawbutton(xt.play, 400, 395);
                }
                if(fase == 17)
                {
                    int i = 14;
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append(": :   ").append(xt.servername).append("   : :").toString(), 400 - ftm.stringWidth((new StringBuilder()).append(": :   ").append(xt.servername).append("   : :").toString()) / 2, 239);
                    for(int i_37 = 0; i_37 < 5; i_37++)
                    {
                        if(opselect == i_37)
                        {
                            rd.setColor(new Color(98, 56, 0));
                            rd.fillRoundRect(300, 230 + i_37 * 20 + i, 200, 20, 14, 14);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(300, 230 + i_37 * 20 + i, 200, 20, 14, 14);
                            rd.setColor(color2k(255, 255, 255));
                        }
                        rd.drawString((new StringBuilder()).append("Room ").append(i_37 + 1).append(" :").toString(), 329, 245 + i_37 * 20 + i);
                        rd.drawString((new StringBuilder()).append("").append(rmps[i_37]).append("  Players").toString(), 471 - ftm.stringWidth((new StringBuilder()).append("").append(rmps[i_37]).append("  Players").toString()), 245 + i_37 * 20 + i);
                        if(i_37 == recom)
                            if(opselect != i_37)
                                rd.setColor(new Color(125, 200, 0));
                            else
                                rd.setColor(new Color(160, 255, 0));
                        rd.setColor(new Color(0, 0, 0));
                    }

                    drawbutton(xt.play, 400, 395);
                }
            } else
            {
                trans += 8;
            }
        }
        if(fase == 15)
        {
            if(trans < 100)
                rd.drawImage(xt.pln, 400 - xt.pln.getWidth(ob) / 2, 315 - xt.pln.getHeight(ob) / 2 - 12 - trans, null);
            else
                rd.drawImage(xt.pln, 400 - xt.pln.getWidth(ob) / 2, 215 - xt.pln.getHeight(ob) / 2 - 12, null);
            if(trans >= 100)
            {
                rd.setColor(color2k(255, 255, 255));
                rd.fillRoundRect(165, 219, 470, 150, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(165, 219, 470, 150, 20, 20);
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(xt.nofull)
                {
                    if(nflk % 4 != 0 || nflk == 0)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(200, 0, 0));
                        rd.drawString("Sorry. You did not allow the game full permissions when you started it.", 175, 242);
                        rd.setFont(new Font("Arial", 0, 13));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("(You didn't click 'Run' at the prompt that came up at the start of the game).", 175, 262);
                        rd.drawString("Because of this the game will not be able to create LAN connections!", 175, 288);
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Please restart the game and allow Java full permissions to be able to", 175, 315);
                        rd.drawString("play LAN games!", 175, 332);
                        rd.setFont(new Font("Arial", 0, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("( Close ALL browser windows including this one then", 295, 332);
                        rd.drawString("start the game again but click 'Run' when asked to 'run this application'. )", 175, 349);
                    }
                    if(nflk != 0)
                        nflk--;
                } else
                {
                    rd.drawString("Play a multiplayer game across your Local Area Network (LAN).", 179, 245);
                    rd.drawString("Experience the game live with zero delay and 100% real-time action!", 179, 262);
                    rd.setFont(new Font("Arial", 0, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("This is for if there is more then one computer connected to your network or", 179, 292);
                    rd.drawString("if you are in a computer lab or in an internet caf\351.", 179, 309);
                    rd.drawString("You can also invite your friends to come over with their Laptop PCs or Macs", 179, 335);
                    rd.drawString("to log on to your internet connection/network and play with you!", 179, 352);
                }
                drawbutton(xt.cancel, 583, 395);
                drawbutton(xt.play, 400, 395);
            } else
            {
                trans += 10;
            }
        }
        if(resofaso)
        {
            resofaso = false;
            if(connector != null)
            {
                connector.stop();
                connector = null;
            }
            socketson = false;
            msg = "| Connecting to Servers |";
            fase = 13;
            connector = new Thread(this);
            connector.start();
        }
    }

    public void multistart(ContO contos[], int i, int i_38, boolean bool)
    {
        btn = 0;
        xt.mainbg(4);
        for(int i_39 = 0; i_39 < 3; i_39++)
        {
            rd.drawImage(xt.bgmain, 65, bgmy[i_39], null);
            bgmy[i_39] -= 4;
            if(bgmy[i_39] <= -400)
                bgmy[i_39] = 800;
        }

        rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
        rd.drawImage(xt.bggo, 0, 0, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(65, 425, 670, 25);
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        float f = 1.0F - (float)(flipo - 10) / 80F;
        if(f > 1.0F)
            f = 1.0F;
        if(f < 0.0F)
            f = 0.0F;
        rd.setComposite(AlphaComposite.getInstance(3, f));
        if(flipo > 10)
            rd.drawImage(xt.logomadnes, 96 + (int)(2D - Math.random() * 4D), 11 + (int)(2D - Math.random() * 4D), null);
        else
            rd.drawImage(xt.logomadnes, 96, 11, null);
        flipo++;
        if(flipo > 50)
            flipo = 0;
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        int i_40 = 0;
        if(i != oxm || i_38 != oym)
        {
            i_40 = 1;
            oxm = i;
            oym = i_38;
        }
        if(bool)
            i_40 = 2;
        rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
        rd.drawImage(xt.dude[i_40], 87, 76, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.drawImage(xt.redy, 445, 153, null);
        drawSbutton(xt.exit, 690, 17);
        rd.setFont(new Font("Arial", 1, 13));
        ftm = rd.getFontMetrics();
        if(fase != 5)
        {
            rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
            rd.setColor(new Color(203, 227, 253));
            rd.fillRoundRect(246, 83, 180, 96, 20, 20);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.setColor(color2k(90, 90, 90));
            rd.drawString((new StringBuilder()).append("").append(xt.cd.names[xt.sc[0]]).append("").toString(), 336 - ftm.stringWidth((new StringBuilder()).append("").append(xt.cd.names[xt.sc[0]]).append("").toString()) / 2, 81);
            rd.drawRoundRect(246, 83, 180, 96, 20, 20);
            if(!gotcai)
            {
                int i_41 = contos[xt.sc[0]].p[0].oz[0];
                int i_42 = i_41;
                int i_43 = contos[xt.sc[0]].p[0].oy[0];
                int i_44 = i_43;
                for(int i_45 = 0; i_45 < contos[xt.sc[0]].npl; i_45++)
                {
                    for(int i_46 = 0; i_46 < contos[xt.sc[0]].p[i_45].n; i_46++)
                    {
                        if(contos[xt.sc[0]].p[i_45].oz[i_46] < i_41)
                            i_41 = contos[xt.sc[0]].p[i_45].oz[i_46];
                        if(contos[xt.sc[0]].p[i_45].oz[i_46] > i_42)
                            i_42 = contos[xt.sc[0]].p[i_45].oz[i_46];
                        if(contos[xt.sc[0]].p[i_45].oy[i_46] < i_43)
                            i_43 = contos[xt.sc[0]].p[i_45].oy[i_46];
                        if(contos[xt.sc[0]].p[i_45].oy[i_46] > i_44)
                            i_44 = contos[xt.sc[0]].p[i_45].oy[i_46];
                    }

                }

                cax = (i_42 + i_41) / 2;
                cay = (i_44 + i_43) / 2;
                gotcai = true;
            }
            contos[xt.sc[0]].z = 1500;
            contos[xt.sc[0]].y = 380 - cay;
            contos[xt.sc[0]].x = -170 - cax;
            contos[xt.sc[0]].zy = 0;
            contos[xt.sc[0]].xz = -90;
            contos[xt.sc[0]].xy = pend;
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            contos[xt.sc[0]].d(rd);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if(!pendb)
            {
                pend += 2;
                if(pend > 80)
                    pendb = true;
            } else
            {
                pend -= 2;
                if(pend < -10)
                    pendb = false;
            }
            drawbutton(xt.change, 497, 98);
        }
        if(fase == 1 || fase == 2)
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 205);
            rd.drawString("Enter a Nickname:", 400 - ftm.stringWidth("Enter a Nickname:") - 14, 241);
            if(fase == 2)
            {
                if(msg.equals(". . . | Checking Nickname | . . .") && ncnt == 0)
                {
                    msg = "| Checking Nickname |";
                    ncnt = 5;
                }
                if(msg.equals(". . | Checking Nickname | . .") && ncnt == 0)
                {
                    msg = ". . . | Checking Nickname | . . .";
                    ncnt = 5;
                }
                if(msg.equals(". | Checking Nickname | .") && ncnt == 0)
                {
                    msg = ". . | Checking Nickname | . .";
                    ncnt = 5;
                }
                if(msg.equals("| Checking Nickname |") && ncnt == 0)
                {
                    msg = ". | Checking Nickname | .";
                    ncnt = 5;
                }
                if(ncnt != 0)
                    ncnt--;
                pessd[2] = true;
            }
            if(fase == 1 && !gs.tnick.isShowing())
            {
                gs.tnick.show();
                gs.tnick.requestFocus();
                if(gs.tnick.getText().equals("Nickname"))
                    gs.tnick.select(8, 8);
            }
            if(errcnt != 0)
            {
                errcnt--;
                if(errcnt == 0)
                    gs.tnick.setForeground(new Color(0, 0, 0));
            }
            drawbutton(xt.play, 400, 285);
            if(nflk > 0)
            {
                if(gs.tnick.getText().equals(""))
                {
                    gs.tnick.setText("Nickname");
                    if(nflk == 1)
                        gs.tnick.select(8, 8);
                } else
                {
                    gs.tnick.setText("");
                }
                nflk--;
            }
            drawbutton(xt.login, 400, 340);
            drawbutton(xt.register, 400, 395);
            gs.movefield(gs.tnick, 400, 225, 129, 23);
            for(; ftm.stringWidth(gs.tnick.getText()) > 86; gs.tnick.select(gs.tnick.getText().length(), gs.tnick.getText().length()))
                gs.tnick.setText(gs.tnick.getText().substring(0, gs.tnick.getText().length() - 1));

            if(!gs.tnick.getText().equals(lnick))
            {
                fixtext(gs.tnick);
                lnick = gs.tnick.getText();
            }
            if(xt.msgcheck(gs.tnick.getText()))
                gs.tnick.setText("");
            if(gs.tnick.getText().toLowerCase().indexOf("madbot") != -1)
                gs.tnick.setText("");
        }
        if(fase == 3 || fase == 4)
        {
            rd.drawImage(xt.ntrg, 97, 388, null);
            rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
            rd.setColor(new Color(203, 227, 253));
            rd.fillRoundRect(246, 212, 308, 142, 20, 20);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.setColor(color2k(90, 90, 90));
            rd.drawRoundRect(246, 212, 308, 142, 20, 20);
            rd.setColor(new Color(0, 0, 0));
            if(nflk % 4 != 0 || nflk == 0)
                rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 205);
            if(nflk != 0)
                nflk--;
            rd.drawString("Nickname:", 376 - ftm.stringWidth("Nickname:") - 14, 237);
            rd.drawString("Password:", 376 - ftm.stringWidth("Password:") - 14, 267);
            if(fase == 4)
            {
                if(msg.equals(". . . | Logging In | . . .") && ncnt == 0)
                {
                    msg = "| Logging In |";
                    ncnt = 5;
                }
                if(msg.equals(". . | Logging In | . .") && ncnt == 0)
                {
                    msg = ". . . | Logging In | . . .";
                    ncnt = 5;
                }
                if(msg.equals(". | Logging In | .") && ncnt == 0)
                {
                    msg = ". . | Logging In | . .";
                    ncnt = 5;
                }
                if(msg.equals("| Logging In |") && ncnt == 0)
                {
                    msg = ". | Logging In | .";
                    ncnt = 5;
                }
                if(ncnt != 0)
                    ncnt--;
                pessd[2] = true;
            }
            if(fase == 3)
            {
                showtf = true;
                if(!gs.applejava)
                {
                    if(!gs.tpass.isShowing())
                    {
                        gs.tpass.show();
                        if(!gs.tnick.getText().equals(""))
                            gs.tpass.requestFocus();
                    }
                    if(!gs.tnick.isShowing())
                    {
                        gs.tnick.show();
                        if(gs.tnick.getText().equals(""))
                            gs.tnick.requestFocus();
                    }
                }
            }
            if(errcnt != 0)
            {
                errcnt--;
                if(errcnt == 0)
                {
                    gs.tpass.setText("");
                    gs.tnick.setForeground(new Color(0, 0, 0));
                    gs.tpass.setForeground(new Color(0, 0, 0));
                }
            }
            drawbutton(xt.login, 400, 315);
            if(onf)
                rd.setColor(color2k(0, 72, 255));
            else
                rd.setColor(color2k(120, 120, 120));
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            rd.drawString("Forgot your nickname or password?", 400 - ftm.stringWidth("Forgot your nickname or password?") / 2, 345);
            rd.setColor(new Color(0, 0, 0));
            rd.setFont(new Font("Arial", 1, 12));
            ftm = rd.getFontMetrics();
            String string = "Register a full account here!";
            xrl = 400 - ftm.stringWidth(string) / 2;
            xrr = xrl + ftm.stringWidth(string);
            rd.drawString(string, xrl, 371);
            rd.drawLine(xrl, 372, xrr, 372);
            drawbutton(xt.register, 400, 395);
            gs.movefieldd(gs.tnick, 376, 221, 129, 23, showtf);
            if(!gs.tnick.getText().equals(lnick))
            {
                fixtext(gs.tnick);
                lnick = gs.tnick.getText();
            }
            gs.movefieldd(gs.tpass, 376, 251, 129, 23, showtf);
            if(!gs.tpass.getText().equals(lpass))
            {
                fixtext(gs.tpass);
                lpass = gs.tpass.getText();
            }
            if(fase == 3 && (!gs.tpass.getText().equals("") && !gs.tnick.getText().equals("") || !gs.applejava) && !gs.keplo.isShowing())
                gs.keplo.show();
            gs.movefield(gs.keplo, 376, 275, 129, 23);
        }
        if(fase == 5)
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawString("Nickname:", 376 - ftm.stringWidth("Nickname:") - 14, 141);
            gs.movefield(gs.tnick, 376, 125, 129, 23);
            for(; ftm.stringWidth(gs.tnick.getText()) > 86; gs.tnick.select(gs.tnick.getText().length(), gs.tnick.getText().length()))
                gs.tnick.setText(gs.tnick.getText().substring(0, gs.tnick.getText().length() - 1));

            if(!gs.tnick.getText().equals(lnick))
            {
                fixtext(gs.tnick);
                lnick = gs.tnick.getText();
            }
            if(!gs.tnick.isShowing())
                gs.tnick.show();
            drawbutton(xt.register, 400, 325);
            drawbutton(xt.cancel, 400, 375);
        }
        if(fase == 7 || fase == 8)
        {
            rd.setColor(new Color(0, 0, 0));
            if(nflk % 4 != 0 || nflk == 0)
                rd.drawString(msg, 400 - ftm.stringWidth(msg) / 2, 205);
            if(nflk != 0)
                nflk--;
            rd.drawString("Your Email:", 344 - ftm.stringWidth("Your Email:") - 14, 241);
            if(fase == 8)
            {
                if(msg.equals(". . . | Checking Email | . . .") && ncnt == 0)
                {
                    msg = "| Checking Email |";
                    ncnt = 5;
                }
                if(msg.equals(". . | Checking Email | . .") && ncnt == 0)
                {
                    msg = ". . . | Checking Email | . . .";
                    ncnt = 5;
                }
                if(msg.equals(". | Checking Email | .") && ncnt == 0)
                {
                    msg = ". . | Checking Email | . .";
                    ncnt = 5;
                }
                if(msg.equals("| Checking Email |") && ncnt == 0)
                {
                    msg = ". | Checking Email | .";
                    ncnt = 5;
                }
                if(ncnt != 0)
                    ncnt--;
                pessd[2] = true;
            }
            if(fase == 7)
            {
                showtf = true;
                if(!gs.applejava && !gs.temail.isShowing())
                {
                    gs.temail.show();
                    gs.temail.requestFocus();
                }
            }
            if(errcnt != 0)
            {
                errcnt--;
                if(errcnt == 0)
                    gs.temail.setForeground(new Color(0, 0, 0));
            }
            drawbutton(xt.sdets, 400, 280);
            drawbutton(xt.cancel, 400, 375);
            gs.movefieldd(gs.temail, 344, 225, 199, 23, showtf);
            if(!gs.temail.getText().equals(lemail))
            {
                fixtext(gs.temail);
                lemail = gs.temail.getText();
            }
        }
    }

    public void ctachm(int i, int i_47, int i_48, Control control, Lobby lobby)
    {
        int i_49 = -1;
        if(fase != 2 && fase != 4 && fase != 6 && fase != 8 && fase != 9)
        {
            for(int i_50 = 0; i_50 < btn; i_50++)
            {
                if(Math.abs(i - bx[i_50]) < bw[i_50] / 2 + 12 && Math.abs(i_47 - by[i_50]) < 14 && (i_48 == 1 || i_48 == 11))
                    pessd[i_50] = true;
                else
                    pessd[i_50] = false;
                if(Math.abs(i - bx[i_50]) < bw[i_50] / 2 + 12 && Math.abs(i_47 - by[i_50]) < 14 && i_48 <= -1)
                {
                    gs.mouses = 0;
                    i_49 = i_50;
                }
                if(fase == 12 && Math.abs(i - bx[i_50]) < bw[i_50] / 2 + 12 && Math.abs(i_47 - by[i_50]) < 14 && (i_50 == 3 || i_50 == 4) && (i != lxm || i_47 != lym))
                    opselect = i_50 - 3;
            }

        }
        if(i_49 == 0)
        {
            gs.tnick.hide();
            gs.tpass.hide();
            gs.keplo.hide();
            gs.temail.hide();
            gs.requestFocus();
            xt.fase = 24;
        }
        if(i_49 == 1 && fase != 5)
        {
            gs.tnick.hide();
            gs.tpass.hide();
            gs.keplo.hide();
            gs.temail.hide();
            gs.requestFocus();
            xt.fase = 23;
        }
        int i_51 = 2;
        if(fase == 12 || fase == 13 || fase == 14 || fase == 15 || fase == 16 || fase == 17)
        {
            if(i > 176 && i_47 > 152 && i < 296 && i_47 < 174)
            {
                if(!ond)
                {
                    ond = true;
                    gs.setCursor(new Cursor(12));
                }
            } else
            if(ond)
            {
                ond = false;
                gs.setCursor(new Cursor(0));
            }
            if(cntcl == 0)
            {
                if(ond && i_48 == 11)
                {
                    gs.editlink(xt.nickname, false);
                    cntcl = 10;
                }
            } else
            {
                cntcl--;
            }
            if(i_49 == i_51)
            {
                i_49 = -1;
                if(xt.sc[0] >= 16)
                {
                    xt.sc[0] = 15;
                    gotcai = false;
                }
                xt.logged = false;
                xt.gotlog = false;
                gs.keplo.setState(false);
                gs.setloggedcookie();
                xt.cd.msloaded = 0;
                xt.cd.lastload = 0;
                msg = "Login to access the multiplayer madness!";
                fase = 3;
            }
        }
        if(fase == 12)
            if(xt.acexp == 0 || contrb)
            {
                if(control.up)
                {
                    opselect--;
                    if(opselect == -1)
                        opselect = 1;
                    control.up = false;
                }
                if(control.down)
                {
                    opselect++;
                    if(opselect == 2)
                        opselect = 0;
                    control.down = false;
                }
                if(control.enter)
                {
                    i_49 = opselect + 3;
                    control.enter = false;
                }
                if(i_49 == i_51 + 1)
                {
                    msg = "| Connecting to Servers |";
                    opselect = 0;
                    trans = 0;
                    fase = 13;
                    nflk = 0;
                    i_49 = -1;
                }
                if(i_49 == i_51 + 2)
                {
                    trans = 0;
                    fase = 15;
                    i_49 = -1;
                }
                if(!xt.logged && i_49 == i_51 + 3)
                    gs.editlink(xt.nickname, true);
            } else
            {
                if(xt.acexp > 0)
                {
                    if(i_49 == i_51 + 1 || control.enter)
                    {
                        gs.editlink(xt.nickname, false);
                        i_49 = -1;
                    }
                    if(i_49 == i_51 + 2)
                    {
                        opselect = 0;
                        contrb = true;
                        i_49 = -1;
                    }
                }
                if(xt.acexp == -1)
                {
                    if(i_49 == i_51 + 1 || control.enter)
                    {
                        gs.editlink(xt.nickname, false);
                        i_49 = -1;
                    }
                    if(i_49 == i_51 + 2)
                    {
                        i_49 = -1;
                        if(xt.sc[0] >= 16)
                        {
                            xt.sc[0] = 15;
                            gotcai = false;
                        }
                        xt.logged = false;
                        xt.cd.lastload = 0;
                        msg = "Login to access the multiplayer madness!";
                        fase = 3;
                    }
                }
                if(xt.acexp == -2)
                {
                    if(i_49 == i_51 + 1 || control.enter)
                    {
                        gs.multlink();
                        i_49 = -1;
                    }
                    if(i_49 == i_51 + 2)
                    {
                        i_49 = -1;
                        if(xt.sc[0] >= 16)
                        {
                            xt.sc[0] = 15;
                            gotcai = false;
                        }
                        xt.logged = false;
                        xt.cd.lastload = 0;
                        msg = "Login to access the multiplayer madness!";
                        fase = 3;
                    }
                }
                if(xt.acexp == -3)
                {
                    if(i_49 == i_51 + 1 || control.enter)
                    {
                        gs.editlink(xt.nickname, false);
                        i_49 = -1;
                    }
                    if(i_49 == i_51 + 2)
                    {
                        i_49 = -1;
                        if(xt.sc[0] >= 16)
                        {
                            xt.sc[0] = 15;
                            gotcai = false;
                        }
                        xt.logged = false;
                        xt.cd.lastload = 0;
                        msg = "Login to access the multiplayer madness!";
                        fase = 3;
                    }
                }
            }
        if(fase == 13 || fase == 14 || fase == 15 || fase == 16 || fase == 17)
        {
            if(control.exit)
                i_49 = 3;
            if(i_49 == i_51 + 1)
            {
                if(fase == 15)
                    opselect = 1;
                else
                    opselect = 0;
                if(fase == 16 || fase == 17)
                {
                    if(connector != null)
                    {
                        connector.stop();
                        connector = null;
                    }
                    try
                    {
                        socket.close();
                        socket = null;
                        din.close();
                        din = null;
                        dout.close();
                        dout = null;
                    }
                    catch(Exception exception) { }
                    fase = 12;
                    connector = new Thread(this);
                    connector.start();
                }
                if(fase == 14)
                {
                    if(connector != null)
                    {
                        connector.stop();
                        connector = null;
                    }
                    for(int i_52 = 0; i_52 < nservers; i_52++)
                        try
                        {
                            dSocket[i_52].close();
                            dSocket[i_52] = null;
                        }
                        catch(Exception exception) { }

                    socketson = false;
                    fase = 12;
                    connector = new Thread(this);
                    connector.start();
                }
                fase = 12;
                gs.setCursor(new Cursor(0));
            }
        }
        if(fase == 14)
        {
            if(control.enter)
            {
                i_49 = 4;
                pessd[4] = true;
            }
            if(control.up)
            {
                opselect--;
                if(opselect == -1)
                    opselect = nservers - 1;
                control.up = false;
            }
            if(control.down)
            {
                opselect++;
                if(opselect == nservers)
                    opselect = 0;
                control.down = false;
            }
            for(int i_53 = 0; i_53 < nservers; i_53++)
                if(i > 175 && i_47 > 230 + i_53 * 40 && i < 625 && i_47 < 250 + i_53 * 40 + 20 && i_48 == 1)
                    opselect = i_53;

            if(i_49 == i_51 + 2)
                if(xt.delays[opselect] >= 400 && !xt.nickname.equals("Fyre"))
                {
                    nflk = 30;
                } else
                {
                    xt.server = servers[opselect];
                    xt.servername = snames[opselect];
                    msg = "| Finding Rooms |";
                    opselect = 0;
                    nflk = 0;
                    i_49 = -1;
                    fase = 16;
                }
        }
        if(fase == 15)
        {
            if(control.enter)
            {
                i_49 = 4;
                pessd[4] = true;
            }
            if(i_49 == i_51 + 2)
                if(xt.nofull)
                {
                    nflk = 30;
                } else
                {
                    xt.server = servers[1];
                    xt.servername = snames[1];
                    xt.servport = 7067;
                    xt.lan = true;
                    i_49 = -1;
                    fase = 18;
                    lobby.fase = 0;
                }
        }
        if(fase == 17)
        {
            if(control.enter)
            {
                i_49 = 4;
                pessd[4] = true;
            }
            if(control.up)
            {
                opselect--;
                if(opselect == -1)
                    opselect = 4;
                control.up = false;
            }
            if(control.down)
            {
                opselect++;
                if(opselect == 5)
                    opselect = 0;
                control.down = false;
            }
            for(int i_54 = 0; i_54 < 5; i_54++)
                if(i > 175 && i_47 > 230 + i_54 * 20 + 14 && i < 625 && i_47 < 250 + i_54 * 20 + 14 && i_48 == 1)
                    opselect = i_54;

            if(i_49 == i_51 + 2)
            {
                xt.servport = 7071 + opselect;
                xt.lan = false;
                i_49 = -1;
                fase = 18;
                lobby.fase = 0;
            }
        }
        if(fase == 3)
        {
            if(i > 295 && i_47 > 334 && i < 505 && i_47 < 348)
            {
                if(!onf)
                {
                    onf = true;
                    gs.setCursor(new Cursor(12));
                }
            } else
            if(onf)
            {
                onf = false;
                gs.setCursor(new Cursor(0));
            }
            if(onf && i_48 == 11)
            {
                msg = "Please enter your Email Address to recover your account details.";
                gs.tnick.setForeground(new Color(0, 0, 0));
                gs.tpass.setForeground(new Color(0, 0, 0));
                gs.tnick.hide();
                gs.tpass.hide();
                gs.keplo.hide();
                onf = false;
                gs.setCursor(new Cursor(0));
                fase = 7;
            }
            if(i > xrl && i < xrr && i_47 > 360 && i_47 < 373)
            {
                if(!onr)
                {
                    onr = true;
                    gs.setCursor(new Cursor(12));
                }
            } else
            if(onr)
            {
                onr = false;
                gs.setCursor(new Cursor(0));
            }
            if(onr && i_48 == 11)
            {
                gs.reglink();
                gs.mouses = 0;
            }
        }
        if(fase == 1)
        {
            if(control.enter)
            {
                i_49 = 2;
                pessd[2] = true;
            }
            if(i_49 == 2)
                if(gs.tnick.getText().equals("Fyre") || gs.tnick.getText().equals("Nickname") || gs.tnick.getText().equals(""))
                {
                    msg = "Type in any Nickname to play...";
                    gs.tnick.setText("Nickname");
                    nflk = 30;
                } else
                {
                    msg = "| Checking Nickname |";
                    gs.tnick.disable();
                    fase = 2;
                    connector = new Thread(this);
                    connector.start();
                }
            if(i_49 == 3)
            {
                if(gs.tnick.getText().equals("Nickname") || msg.startsWith("This"))
                    gs.tnick.setText("");
                msg = "Login to access the multiplayer madness!";
                gs.tnick.setForeground(new Color(0, 0, 0));
                fase = 3;
                i_49 = -1;
            }
            if(i_49 == 4)
            {
                if(nickero || gs.tnick.getText().equals("Nickname"))
                {
                    gs.tnick.setText("");
                    nickero = false;
                }
                gs.tnick.setForeground(new Color(0, 0, 0));
                gs.reglink();
            }
        }
        if(fase == 3)
        {
            if(control.enter || xt.autolog)
            {
                i_49 = 2;
                pessd[2] = true;
                xt.autolog = false;
            }
            if(control.exit)
                i_49 = 3;
            if(i_49 == 2)
                if(gs.tnick.getText().equals(""))
                {
                    msg = "Enter your Nickname!";
                    nflk = 30;
                } else
                if(gs.tpass.getText().equals(""))
                {
                    msg = "Enter your Password!";
                    nflk = 30;
                } else
                {
                    msg = "| Logging In |";
                    gs.tnick.disable();
                    gs.tpass.disable();
                    gs.keplo.disable();
                    fase = 4;
                    connector = new Thread(this);
                    connector.start();
                }
            if(i_49 == 3)
                gs.regnew();
        }
        if(fase == 5)
        {
            if(control.enter)
            {
                i_49 = 1;
                pessd[1] = true;
            }
            if(control.exit)
                i_49 = 2;
            if(i_49 == 1);
            if(i_49 == 2)
            {
                fase = lrgfase;
                if(fase == 12)
                {
                    gs.tnick.hide();
                    connector = new Thread(this);
                    connector.start();
                }
            }
        }
        if(fase == 7)
        {
            if(control.enter)
            {
                i_49 = 2;
                pessd[2] = true;
            }
            if(control.exit)
                i_49 = 3;
            if(i_49 == 2)
            {
                nflk = 0;
                if(gs.temail.getText().equals(""))
                {
                    msg = "Please type in your Email Address!";
                    nflk = 30;
                }
                if(nflk == 0)
                {
                    String string = gs.temail.getText();
                    int i_55 = 0;
                    int i_56 = 0;
                    for(; i_55 < string.length(); i_55++)
                    {
                        String string_57 = (new StringBuilder()).append("").append(string.charAt(i_55)).toString();
                        if(string_57.equals("@") && i_56 == 0 && i_55 != 0)
                            i_56 = 1;
                        if(string_57.equals(".") && i_56 == 1 && i_55 != string.length() - 1)
                            i_56 = 2;
                    }

                    if(i_56 != 2)
                    {
                        msg = "Please type in your Email Address correctly!";
                        nflk = 30;
                        errcnt = 40;
                        gs.temail.setForeground(new Color(255, 0, 0));
                    }
                }
                if(nflk == 0)
                {
                    msg = "| Checking Email |";
                    gs.temail.disable();
                    fase = 8;
                    connector = new Thread(this);
                    connector.start();
                }
            }
            if(i_49 == 3)
            {
                inishmulti();
                gs.temail.setText("");
                gs.tpass.setText("");
            }
        }
        lxm = i;
        lym = i_47;
        control.enter = false;
        control.exit = false;
    }

    public void drawSbutton(Image image, int i, int i_58)
    {
        bx[btn] = i;
        by[btn] = i_58;
        bw[btn] = image.getWidth(ob);
        if(!pessd[btn])
        {
            rd.drawImage(image, i - bw[btn] / 2, i_58 - image.getHeight(ob) / 2 - 1, null);
            rd.drawImage(xt.bols, i - bw[btn] / 2 - 15, i_58 - 13, null);
            rd.drawImage(xt.bors, i + bw[btn] / 2 + 9, i_58 - 13, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_58 - 13, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_58 + 10, bw[btn] + 18, 3, null);
        } else
        {
            rd.drawImage(image, (i - bw[btn] / 2) + 1, i_58 - image.getHeight(ob) / 2, null);
            rd.drawImage(xt.bolps, i - bw[btn] / 2 - 15, i_58 - 13, null);
            rd.drawImage(xt.borps, i + bw[btn] / 2 + 9, i_58 - 13, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_58 - 13, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_58 + 10, bw[btn] + 18, 3, null);
        }
        btn++;
    }

    public void drawbutton(Image image, int i, int i_59)
    {
        bx[btn] = i;
        by[btn] = i_59;
        bw[btn] = image.getWidth(ob);
        if(!pessd[btn])
        {
            rd.drawImage(image, i - bw[btn] / 2, i_59 - image.getHeight(ob) / 2, null);
            rd.drawImage(xt.bol, i - bw[btn] / 2 - 15, i_59 - 16, null);
            rd.drawImage(xt.bor, i + bw[btn] / 2 + 9, i_59 - 16, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_59 - 16, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_59 + 13, bw[btn] + 18, 3, null);
        } else
        {
            rd.drawImage(image, (i - bw[btn] / 2) + 1, (i_59 - image.getHeight(ob) / 2) + 1, null);
            rd.drawImage(xt.bolp, i - bw[btn] / 2 - 15, i_59 - 16, null);
            rd.drawImage(xt.borp, i + bw[btn] / 2 + 9, i_59 - 16, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_59 - 16, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_59 + 13, bw[btn] + 18, 3, null);
        }
        btn++;
    }

    public void stringbutton(String string, int i, int i_60, int i_61)
    {
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        bx[btn] = i;
        by[btn] = i_60 - 5;
        bw[btn] = ftm.stringWidth(string);
        if(!pessd[btn])
        {
            rd.setColor(color2k(220, 220, 220));
            rd.fillRect(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), bw[btn] + 20, 25 - i_61 * 2);
            rd.setColor(color2k(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), i + bw[btn] / 2 + 10, i_60 - (17 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (18 - i_61), i + bw[btn] / 2 + 10, i_60 - (18 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 9, i_60 - (19 - i_61), i + bw[btn] / 2 + 9, i_60 - (19 - i_61));
            rd.setColor(color2k(200, 200, 200));
            rd.drawLine(i + bw[btn] / 2 + 10, i_60 - (17 - i_61), i + bw[btn] / 2 + 10, i_60 + (7 - i_61));
            rd.drawLine(i + bw[btn] / 2 + 11, i_60 - (17 - i_61), i + bw[btn] / 2 + 11, i_60 + (7 - i_61));
            rd.drawLine(i + bw[btn] / 2 + 12, i_60 - (16 - i_61), i + bw[btn] / 2 + 12, i_60 + (6 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 + (7 - i_61), i + bw[btn] / 2 + 10, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 + (8 - i_61), i + bw[btn] / 2 + 10, i_60 + (8 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 9, i_60 + (9 - i_61), i + bw[btn] / 2 + 9, i_60 + (9 - i_61));
            rd.setColor(color2k(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), i - bw[btn] / 2 - 10, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 11, i_60 - (17 - i_61), i - bw[btn] / 2 - 11, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 12, i_60 - (16 - i_61), i - bw[btn] / 2 - 12, i_60 + (6 - i_61));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(string, i - bw[btn] / 2, i_60);
        } else
        {
            rd.setColor(color2k(210, 210, 210));
            rd.fillRect(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), bw[btn] + 20, 25 - i_61 * 2);
            rd.setColor(color2k(200, 200, 200));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), i + bw[btn] / 2 + 10, i_60 - (17 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (18 - i_61), i + bw[btn] / 2 + 10, i_60 - (18 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 9, i_60 - (19 - i_61), i + bw[btn] / 2 + 9, i_60 - (19 - i_61));
            rd.drawLine(i + bw[btn] / 2 + 10, i_60 - (17 - i_61), i + bw[btn] / 2 + 10, i_60 + (7 - i_61));
            rd.drawLine(i + bw[btn] / 2 + 11, i_60 - (17 - i_61), i + bw[btn] / 2 + 11, i_60 + (7 - i_61));
            rd.drawLine(i + bw[btn] / 2 + 12, i_60 - (16 - i_61), i + bw[btn] / 2 + 12, i_60 + (6 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 + (7 - i_61), i + bw[btn] / 2 + 10, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 + (8 - i_61), i + bw[btn] / 2 + 10, i_60 + (8 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 9, i_60 + (9 - i_61), i + bw[btn] / 2 + 9, i_60 + (9 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 10, i_60 - (17 - i_61), i - bw[btn] / 2 - 10, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 11, i_60 - (17 - i_61), i - bw[btn] / 2 - 11, i_60 + (7 - i_61));
            rd.drawLine(i - bw[btn] / 2 - 12, i_60 - (16 - i_61), i - bw[btn] / 2 - 12, i_60 + (6 - i_61));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(string, (i - bw[btn] / 2) + 1, i_60);
        }
        btn++;
    }

    public Color color2k(int i, int i_62, int i_63)
    {
        Color color = new Color(i, i_62, i_63);
        float fs[] = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
        fs[0] = 0.13F;
        fs[1] = 0.35F;
        return Color.getHSBColor(fs[0], fs[1], fs[2]);
    }

    public void fixtext(TextField textfield)
    {
        String string = textfield.getText();
        string = string.replace('"', '#');
        String string_64 = "\\";
        String string_65 = "";
        int i = 0;
        int i_66 = -1;
        for(; i < string.length(); i++)
        {
            String string_67 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
            if(string_67.equals("|") || string_67.equals(",") || string_67.equals("(") || string_67.equals(")") || string_67.equals("#") || string_67.equals(string_64) || string_67.equals("!") || string_67.equals("?") || string_67.equals(" ") || string_67.equals("~") || string_67.equals("$") || string_67.equals("%") || string_67.equals("^") || string_67.equals("&") || string_67.equals("*") || string_67.equals("+") || string_67.equals("=") || string_67.equals(">") || string_67.equals("<") || string_67.equals("/") || string_67.equals("'") || string_67.equals(";") || string_67.equals(":") || string_67.equals("\240"))
                i_66 = i;
            else
                string_65 = (new StringBuilder()).append(string_65).append(string_67).toString();
        }

        if(i_66 != -1)
        {
            textfield.setText(string_65);
            textfield.select(i_66, i_66);
        }
    }

    public int getvalue(String string, int i)
    {
        int i_68 = -1;
        try
        {
            int i_69 = 0;
            int i_70 = 0;
            int i_71 = 0;
            String string_72 = "";
            String string_73 = "";
            for(; i_69 < string.length() && i_71 != 2; i_69++)
            {
                string_72 = (new StringBuilder()).append("").append(string.charAt(i_69)).toString();
                if(string_72.equals("|"))
                {
                    i_70++;
                    if(i_71 == 1 || i_70 > i)
                        i_71 = 2;
                    continue;
                }
                if(i_70 == i)
                {
                    string_73 = (new StringBuilder()).append(string_73).append(string_72).toString();
                    i_71 = 1;
                }
            }

            if(string_73.equals(""))
                string_73 = "-1";
            i_68 = Integer.valueOf(string_73).intValue();
        }
        catch(Exception exception) { }
        return i_68;
    }

    public String getSvalue(String string, int i)
    {
        String string_74 = "";
        try
        {
            int i_75 = 0;
            int i_76 = 0;
            int i_77 = 0;
            String string_78 = "";
            String string_79 = "";
            for(; i_75 < string.length() && i_77 != 2; i_75++)
            {
                string_78 = (new StringBuilder()).append("").append(string.charAt(i_75)).toString();
                if(string_78.equals("|"))
                {
                    i_76++;
                    if(i_77 == 1 || i_76 > i)
                        i_77 = 2;
                    continue;
                }
                if(i_76 == i)
                {
                    string_79 = (new StringBuilder()).append(string_79).append(string_78).toString();
                    i_77 = 1;
                }
            }

            string_74 = string_79;
        }
        catch(Exception exception) { }
        return string_74;
    }

    Graphics2D rd;
    xtGraphics xt;
    Medium m;
    FontMetrics ftm;
    ImageObserver ob;
    GameSparker gs;
    int nmsgs;
    int nconf;
    int nfreq;
    int ncreq;
    int fclan;
    int fplayer;
    String clanapv;
    boolean justlog;
    int cntgame;
    int gamec;
    int groom;
    String gmaker;
    String gservern;
    Thread connector;
    int fase;
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    boolean pessd[] = {
        false, false, false, false, false, false
    };
    int bx[] = {
        0, 0, 0, 0, 0, 0
    };
    int by[] = {
        0, 0, 0, 0, 0, 0
    };
    int bw[] = {
        0, 0, 0, 0, 0, 0
    };
    int btn;
    int nflk;
    int ncnt;
    int errcnt;
    int lrgfase;
    String msg;
    String lnick;
    String lpass;
    String lemail;
    boolean onf;
    boolean nickero;
    boolean jflk;
    boolean ond;
    int opselect;
    int trans;
    int cntcl;
    boolean contrb;
    int nservers;
    String servers[] = {
        "multiplayer.needformadness.com", "avenger.needformadness.com", "ghostrider.needformadness.com"
    };
    InetAddress IPAddress[];
    DatagramSocket dSocket[];
    int serverdone[] = {
        -1, -1, -1
    };
    long servestart[] = {
        0L, 0L, 0L
    };
    String snames[] = {
        "Dominion", "Avenger", "Ghostrider"
    };
    boolean socketson;
    int srvtrn;
    int rmps[] = {
        0, 0, 0, 0, 0
    };
    int rmwt[] = {
        0, 0, 0, 0, 0
    };
    int recom;
    boolean resofaso;
    boolean checknote;
    int pend;
    boolean pendb;
    boolean gotcai;
    int cax;
    int cay;
    boolean btroom;
    boolean showtf;
    int bgmy[] = {
        0, 400, 800
    };
    int flipo;
    int xrl;
    int xrr;
    boolean onr;
    int oxm;
    int oym;
    int lxm;
    int lym;
}
