// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Mad.java

import java.awt.Color;

public class Mad
{

    public Mad(CarDefine cardefine, Medium medium, Record record, xtGraphics var_xtGraphics, int i)
    {
        cn = 0;
        im = 0;
        mxz = 0;
        cxz = 0;
        dominate = new boolean[8];
        caught = new boolean[8];
        pzy = 0;
        pxy = 0;
        speed = 0.0F;
        forca = 0.0F;
        scy = new float[4];
        scz = new float[4];
        scx = new float[4];
        drag = 0.5F;
        mtouch = false;
        wtouch = false;
        cntouch = 0;
        capsized = false;
        txz = 0;
        fxz = 0;
        pmlt = 1;
        nmlt = 1;
        dcnt = 0;
        skid = 0;
        pushed = false;
        gtouch = false;
        pl = false;
        pr = false;
        pd = false;
        pu = false;
        loop = 0;
        ucomp = 0.0F;
        dcomp = 0.0F;
        lcomp = 0.0F;
        rcomp = 0.0F;
        lxz = 0;
        travxy = 0;
        travzy = 0;
        travxz = 0;
        trcnt = 0;
        capcnt = 0;
        srfcnt = 0;
        rtab = false;
        ftab = false;
        btab = false;
        surfer = false;
        powerup = 0.0F;
        xtpower = 0;
        tilt = 0.0F;
        crank = new int[4][4];
        lcrank = new int[4][4];
        squash = 0;
        nbsq = 0;
        hitmag = 0;
        cntdest = 0;
        dest = false;
        newcar = false;
        pan = 0;
        pcleared = 0;
        clear = 0;
        nlaps = 0;
        focus = -1;
        power = 75F;
        missedcp = 0;
        lastcolido = 0;
        point = 0;
        nofocus = false;
        rpdcatch = 0;
        newedcar = 0;
        fixes = -1;
        shakedam = 0;
        outshakedam = 0;
        colidim = false;
        cd = cardefine;
        m = medium;
        rpd = record;
        xt = var_xtGraphics;
        im = i;
    }

    public void reseto(int i, ContO conto, CheckPoints checkpoints)
    {
        cn = i;
        for(int i_0 = 0; i_0 < 8; i_0++)
        {
            dominate[i_0] = false;
            caught[i_0] = false;
        }

        mxz = 0;
        cxz = 0;
        pzy = 0;
        pxy = 0;
        speed = 0.0F;
        for(int i_1 = 0; i_1 < 4; i_1++)
        {
            scy[i_1] = 0.0F;
            scx[i_1] = 0.0F;
            scz[i_1] = 0.0F;
        }

        forca = (((float)Math.sqrt(conto.keyz[0] * conto.keyz[0] + conto.keyx[0] * conto.keyx[0]) + (float)Math.sqrt(conto.keyz[1] * conto.keyz[1] + conto.keyx[1] * conto.keyx[1]) + (float)Math.sqrt(conto.keyz[2] * conto.keyz[2] + conto.keyx[2] * conto.keyx[2]) + (float)Math.sqrt(conto.keyz[3] * conto.keyz[3] + conto.keyx[3] * conto.keyx[3])) / 10000F) * (float)((double)cd.bounce[cn] - 0.29999999999999999D);
        mtouch = false;
        wtouch = false;
        txz = 0;
        fxz = 0;
        pmlt = 1;
        nmlt = 1;
        dcnt = 0;
        skid = 0;
        pushed = false;
        gtouch = false;
        pl = false;
        pr = false;
        pd = false;
        pu = false;
        loop = 0;
        ucomp = 0.0F;
        dcomp = 0.0F;
        lcomp = 0.0F;
        rcomp = 0.0F;
        lxz = 0;
        travxy = 0;
        travzy = 0;
        travxz = 0;
        rtab = false;
        ftab = false;
        btab = false;
        powerup = 0.0F;
        xtpower = 0;
        trcnt = 0;
        capcnt = 0;
        tilt = 0.0F;
        for(int i_2 = 0; i_2 < 4; i_2++)
        {
            for(int i_3 = 0; i_3 < 4; i_3++)
            {
                crank[i_2][i_3] = 0;
                lcrank[i_2][i_3] = 0;
            }

        }

        pan = 0;
        pcleared = checkpoints.pcs;
        clear = 0;
        nlaps = 0;
        focus = -1;
        missedcp = 0;
        nofocus = false;
        power = 98F;
        lastcolido = 0;
        checkpoints.dested[im] = 0;
        squash = 0;
        nbsq = 0;
        hitmag = 0;
        cntdest = 0;
        dest = false;
        newcar = false;
        if(im == xt.im)
        {
            m.checkpoint = -1;
            m.lastcheck = false;
        }
        rpdcatch = 0;
        newedcar = 0;
        fixes = -1;
        if(checkpoints.nfix == 1)
            fixes = 4;
        if(checkpoints.nfix == 2)
            fixes = 3;
        if(checkpoints.nfix == 3)
            fixes = 2;
        if(checkpoints.nfix == 4)
            fixes = 1;
    }

    public void drive(Control control, ContO conto, Trackers trackers, CheckPoints checkpoints)
    {
        int i = 1;
        int i_4 = 1;
        boolean bool = false;
        boolean bool_5 = false;
        boolean bool_6 = false;
        capsized = false;
        int i_7;
        for(i_7 = Math.abs(pzy); i_7 > 270; i_7 -= 360);
        i_7 = Math.abs(i_7);
        if(i_7 > 90)
            bool = true;
        boolean bool_8 = false;
        int i_9;
        for(i_9 = Math.abs(pxy); i_9 > 270; i_9 -= 360);
        i_9 = Math.abs(i_9);
        if(i_9 > 90)
        {
            bool_8 = true;
            i_4 = -1;
        }
        int i_10 = conto.grat;
        if(bool)
        {
            if(bool_8)
            {
                bool_8 = false;
                bool_5 = true;
            } else
            {
                bool_8 = true;
                capsized = true;
            }
            i = -1;
        } else
        if(bool_8)
            capsized = true;
        if(capsized)
            i_10 = cd.flipy[cn] + squash;
        control.zyinv = bool;
        float f = 0.0F;
        float f_11 = 0.0F;
        float f_12 = 0.0F;
        if(mtouch)
            loop = 0;
        if(wtouch)
        {
            if(loop == 2 || loop == -1)
            {
                loop = -1;
                if(control.left)
                    pl = true;
                if(control.right)
                    pr = true;
                if(control.up)
                    pu = true;
                if(control.down)
                    pd = true;
            }
            ucomp = 0.0F;
            dcomp = 0.0F;
            lcomp = 0.0F;
            rcomp = 0.0F;
        }
        if(control.handb)
        {
            if(!pushed)
                if(!wtouch)
                {
                    if(loop == 0)
                        loop = 1;
                } else
                if(gtouch)
                    pushed = true;
        } else
        {
            pushed = false;
        }
        if(loop == 1)
        {
            float f_13 = (scy[0] + scy[1] + scy[2] + scy[3]) / 4F;
            for(int i_14 = 0; i_14 < 4; i_14++)
                scy[i_14] = f_13;

            loop = 2;
        }
        if(!dest)
            if(loop == 2)
            {
                if(control.up)
                {
                    if(ucomp == 0.0F)
                    {
                        ucomp = 10F + (scy[0] + 50F) / 20F;
                        if(ucomp < 5F)
                            ucomp = 5F;
                        if(ucomp > 10F)
                            ucomp = 10F;
                        ucomp *= cd.airs[cn];
                    }
                    if(ucomp < 20F)
                        ucomp += 0.5D * (double)cd.airs[cn];
                    f = (float)(-cd.airc[cn]) * m.sin(conto.xz) * (float)i_4;
                    f_11 = (float)cd.airc[cn] * m.cos(conto.xz) * (float)i_4;
                } else
                if(ucomp != 0.0F && ucomp > -2F)
                    ucomp -= 0.5D * (double)cd.airs[cn];
                if(control.down)
                {
                    if(dcomp == 0.0F)
                    {
                        dcomp = 10F + (scy[0] + 50F) / 20F;
                        if(dcomp < 5F)
                            dcomp = 5F;
                        if(dcomp > 10F)
                            dcomp = 10F;
                        dcomp *= cd.airs[cn];
                    }
                    if(dcomp < 20F)
                        dcomp += 0.5D * (double)cd.airs[cn];
                    f_12 = -cd.airc[cn];
                } else
                if(dcomp != 0.0F && ucomp > -2F)
                    dcomp -= 0.5D * (double)cd.airs[cn];
                if(control.left)
                {
                    if(lcomp == 0.0F)
                        lcomp = 5F;
                    if(lcomp < 20F)
                        lcomp += 2.0F * cd.airs[cn];
                    f = (float)(-cd.airc[cn]) * m.cos(conto.xz) * (float)i;
                    f_11 = (float)(-cd.airc[cn]) * m.sin(conto.xz) * (float)i;
                } else
                if(lcomp > 0.0F)
                    lcomp -= 2.0F * cd.airs[cn];
                if(control.right)
                {
                    if(rcomp == 0.0F)
                        rcomp = 5F;
                    if(rcomp < 20F)
                        rcomp += 2.0F * cd.airs[cn];
                    f = (float)cd.airc[cn] * m.cos(conto.xz) * (float)i;
                    f_11 = (float)cd.airc[cn] * m.sin(conto.xz) * (float)i;
                } else
                if(rcomp > 0.0F)
                    rcomp -= 2.0F * cd.airs[cn];
                pzy += (dcomp - ucomp) * m.cos(pxy);
                if(bool)
                    conto.xz += (dcomp - ucomp) * m.sin(pxy);
                else
                    conto.xz -= (dcomp - ucomp) * m.sin(pxy);
                pxy += rcomp - lcomp;
            } else
            {
                float f_15 = power;
                if(f_15 < 40F)
                    f_15 = 40F;
                if(control.down)
                    if(speed > 0.0F)
                    {
                        speed -= cd.handb[cn] / 2;
                    } else
                    {
                        int i_16 = 0;
                        for(int i_17 = 0; i_17 < 2; i_17++)
                            if(speed <= -((float)(cd.swits[cn][i_17] / 2) + (f_15 * (float)cd.swits[cn][i_17]) / 196F))
                                i_16++;

                        if(i_16 != 2)
                            speed -= cd.acelf[cn][i_16] / 2.0F + (f_15 * cd.acelf[cn][i_16]) / 196F;
                        else
                            speed = -((float)(cd.swits[cn][1] / 2) + (f_15 * (float)cd.swits[cn][1]) / 196F);
                    }
                if(control.up)
                    if(speed < 0.0F)
                    {
                        speed += cd.handb[cn];
                    } else
                    {
                        int i_18 = 0;
                        for(int i_19 = 0; i_19 < 3; i_19++)
                            if(speed >= (float)(cd.swits[cn][i_19] / 2) + (f_15 * (float)cd.swits[cn][i_19]) / 196F)
                                i_18++;

                        if(i_18 != 3)
                            speed += cd.acelf[cn][i_18] / 2.0F + (f_15 * cd.acelf[cn][i_18]) / 196F;
                        else
                            speed = (float)(cd.swits[cn][2] / 2) + (f_15 * (float)cd.swits[cn][2]) / 196F;
                    }
                if(control.handb && Math.abs(speed) > (float)cd.handb[cn])
                    if(speed < 0.0F)
                        speed += cd.handb[cn];
                    else
                        speed -= cd.handb[cn];
                if(loop == -1 && conto.y < 100)
                {
                    if(control.left)
                    {
                        if(!pl)
                        {
                            if(lcomp == 0.0F)
                                lcomp = 5F * cd.airs[cn];
                            if(lcomp < 20F)
                                lcomp += 2.0F * cd.airs[cn];
                        }
                    } else
                    {
                        if(lcomp > 0.0F)
                            lcomp -= 2.0F * cd.airs[cn];
                        pl = false;
                    }
                    if(control.right)
                    {
                        if(!pr)
                        {
                            if(rcomp == 0.0F)
                                rcomp = 5F * cd.airs[cn];
                            if(rcomp < 20F)
                                rcomp += 2.0F * cd.airs[cn];
                        }
                    } else
                    {
                        if(rcomp > 0.0F)
                            rcomp -= 2.0F * cd.airs[cn];
                        pr = false;
                    }
                    if(control.up)
                    {
                        if(!pu)
                        {
                            if(ucomp == 0.0F)
                                ucomp = 5F * cd.airs[cn];
                            if(ucomp < 20F)
                                ucomp += 2.0F * cd.airs[cn];
                        }
                    } else
                    {
                        if(ucomp > 0.0F)
                            ucomp -= 2.0F * cd.airs[cn];
                        pu = false;
                    }
                    if(control.down)
                    {
                        if(!pd)
                        {
                            if(dcomp == 0.0F)
                                dcomp = 5F * cd.airs[cn];
                            if(dcomp < 20F)
                                dcomp += 2.0F * cd.airs[cn];
                        }
                    } else
                    {
                        if(dcomp > 0.0F)
                            dcomp -= 2.0F * cd.airs[cn];
                        pd = false;
                    }
                    pzy += (dcomp - ucomp) * m.cos(pxy);
                    if(bool)
                        conto.xz += (dcomp - ucomp) * m.sin(pxy);
                    else
                        conto.xz -= (dcomp - ucomp) * m.sin(pxy);
                    pxy += rcomp - lcomp;
                }
            }
        float f_20 = (20F * speed) / (154F * cd.simag[cn]);
        if(f_20 > 20F)
            f_20 = 20F;
        conto.wzy -= f_20;
        if(conto.wzy < -30)
            conto.wzy += 30;
        if(conto.wzy > 30)
            conto.wzy -= 30;
        if(control.right)
        {
            conto.wxz -= cd.turn[cn];
            if(conto.wxz < -36)
                conto.wxz = -36;
        }
        if(control.left)
        {
            conto.wxz += cd.turn[cn];
            if(conto.wxz > 36)
                conto.wxz = 36;
        }
        if(conto.wxz != 0 && !control.left && !control.right)
            if(Math.abs(speed) < 10F)
            {
                if(Math.abs(conto.wxz) == 1)
                    conto.wxz = 0;
                if(conto.wxz > 0)
                    conto.wxz--;
                if(conto.wxz < 0)
                    conto.wxz++;
            } else
            {
                if(Math.abs(conto.wxz) < cd.turn[cn] * 2)
                    conto.wxz = 0;
                if(conto.wxz > 0)
                    conto.wxz -= cd.turn[cn] * 2;
                if(conto.wxz < 0)
                    conto.wxz += cd.turn[cn] * 2;
            }
        int i_21 = (int)(3600F / (speed * speed));
        if(i_21 < 5)
            i_21 = 5;
        if(speed < 0.0F)
            i_21 = -i_21;
        if(wtouch)
        {
            if(!capsized)
            {
                if(!control.handb)
                    fxz = conto.wxz / (i_21 * 3);
                else
                    fxz = conto.wxz / i_21;
                conto.xz += conto.wxz / i_21;
            }
            wtouch = false;
            gtouch = false;
        } else
        {
            conto.xz += fxz;
        }
        if(speed > 30F || speed < -100F)
        {
            do
            {
                if(Math.abs(mxz - cxz) <= 180)
                    break;
                if(cxz > mxz)
                    cxz -= 360;
                else
                if(cxz < mxz)
                    cxz += 360;
            } while(true);
            if(Math.abs(mxz - cxz) < 30)
            {
                cxz += (float)(mxz - cxz) / 4F;
            } else
            {
                if(cxz > mxz)
                    cxz -= 10;
                if(cxz < mxz)
                    cxz += 10;
            }
        }
        float fs[] = new float[4];
        float fs_22[] = new float[4];
        float fs_23[] = new float[4];
        for(int i_24 = 0; i_24 < 4; i_24++)
        {
            fs[i_24] = conto.keyx[i_24] + conto.x;
            fs_23[i_24] = i_10 + conto.y;
            fs_22[i_24] = conto.z + conto.keyz[i_24];
            scy[i_24] += 7F;
        }

        rot(fs, fs_23, conto.x, conto.y, pxy, 4);
        rot(fs_23, fs_22, conto.y, conto.z, pzy, 4);
        rot(fs, fs_22, conto.x, conto.z, conto.xz, 4);
        boolean bool_25 = false;
        double d = 0.0D;
        int i_26 = (int)((scx[0] + scx[1] + scx[2] + scx[3]) / 4F);
        int i_27 = (int)((scz[0] + scz[1] + scz[2] + scz[3]) / 4F);
        for(int i_28 = 0; i_28 < 4; i_28++)
        {
            if(scx[i_28] - (float)i_26 > 200F)
                scx[i_28] = 200 + i_26;
            if(scx[i_28] - (float)i_26 < -200F)
                scx[i_28] = i_26 - 200;
            if(scz[i_28] - (float)i_27 > 200F)
                scz[i_28] = 200 + i_27;
            if(scz[i_28] - (float)i_27 < -200F)
                scz[i_28] = i_27 - 200;
        }

        for(int i_29 = 0; i_29 < 4; i_29++)
        {
            fs_23[i_29] += scy[i_29];
            fs[i_29] += (scx[0] + scx[1] + scx[2] + scx[3]) / 4F;
            fs_22[i_29] += (scz[0] + scz[1] + scz[2] + scz[3]) / 4F;
        }

        int i_30 = (conto.x - trackers.sx) / 3000;
        if(i_30 > trackers.ncx)
            i_30 = trackers.ncx;
        if(i_30 < 0)
            i_30 = 0;
        int i_31 = (conto.z - trackers.sz) / 3000;
        if(i_31 > trackers.ncz)
            i_31 = trackers.ncz;
        if(i_31 < 0)
            i_31 = 0;
        int i_32 = 1;
        for(int i_33 = 0; i_33 < trackers.sect[i_30][i_31].length; i_33++)
        {
            int i_34 = trackers.sect[i_30][i_31][i_33];
            if(Math.abs(trackers.zy[i_34]) != 90 && Math.abs(trackers.xy[i_34]) != 90 && Math.abs(conto.x - trackers.x[i_34]) < trackers.radx[i_34] && Math.abs(conto.z - trackers.z[i_34]) < trackers.radz[i_34] && (!trackers.decor[i_34] || m.resdown != 2 || xt.multion != 0))
                i_32 = trackers.skd[i_34];
        }

        if(mtouch)
        {
            float f_35 = cd.grip[cn];
            f_35 -= ((float)Math.abs(txz - conto.xz) * speed) / 250F;
            if(control.handb)
                f_35 -= Math.abs(txz - conto.xz) * 4;
            if(f_35 < cd.grip[cn])
            {
                if(skid != 2)
                    skid = 1;
                speed -= speed / 100F;
            } else
            if(skid == 1)
                skid = 2;
            if(i_32 == 1)
                f_35 = (float)((double)f_35 * 0.75D);
            if(i_32 == 2)
                f_35 = (float)((double)f_35 * 0.55000000000000004D);
            int i_36 = -(int)(speed * m.sin(conto.xz) * m.cos(pzy));
            int i_37 = (int)(speed * m.cos(conto.xz) * m.cos(pzy));
            int i_38 = -(int)(speed * m.sin(pzy));
            if(capsized || dest || checkpoints.haltall)
            {
                i_36 = 0;
                i_37 = 0;
                i_38 = 0;
                f_35 = cd.grip[cn] / 5F;
                if(speed > 0.0F)
                    speed -= 2.0F;
                else
                    speed += 2.0F;
            }
            if(Math.abs(speed) > drag)
            {
                if(speed > 0.0F)
                    speed -= drag;
                else
                    speed += drag;
            } else
            {
                speed = 0.0F;
            }
            if(cn == 8 && f_35 < 5F)
                f_35 = 5F;
            if(f_35 < 1.0F)
                f_35 = 1.0F;
            float f_39 = 0.0F;
            float f_40 = 0.0F;
            for(int i_41 = 0; i_41 < 4; i_41++)
            {
                if(Math.abs(scx[i_41] - (float)i_36) > f_35)
                {
                    if(scx[i_41] < (float)i_36)
                        scx[i_41] += f_35;
                    else
                        scx[i_41] -= f_35;
                } else
                {
                    scx[i_41] = i_36;
                }
                if(Math.abs(scz[i_41] - (float)i_37) > f_35)
                {
                    if(scz[i_41] < (float)i_37)
                        scz[i_41] += f_35;
                    else
                        scz[i_41] -= f_35;
                } else
                {
                    scz[i_41] = i_37;
                }
                if(Math.abs(scy[i_41] - (float)i_38) > f_35)
                {
                    if(scy[i_41] < (float)i_38)
                        scy[i_41] += f_35;
                    else
                        scy[i_41] -= f_35;
                } else
                {
                    scy[i_41] = i_38;
                }
                if(f_35 < cd.grip[cn])
                {
                    if(txz != conto.xz)
                        dcnt++;
                    else
                    if(dcnt != 0)
                        dcnt = 0;
                    if((float)dcnt > (40F * f_35) / cd.grip[cn] || capsized)
                    {
                        float f_42 = 1.0F;
                        if(i_32 != 0)
                            f_42 = 1.2F;
                        if((double)m.random() > 0.65000000000000002D)
                        {
                            conto.dust(i_41, fs[i_41], fs_23[i_41], fs_22[i_41], (int)scx[i_41], (int)scz[i_41], f_42 * cd.simag[cn], (int)tilt, capsized && mtouch);
                            if(im == xt.im && !capsized)
                                xt.skid(i_32, (float)Math.sqrt(scx[i_41] * scx[i_41] + scz[i_41] * scz[i_41]));
                        }
                    } else
                    {
                        if(i_32 == 1 && (double)m.random() > 0.80000000000000004D)
                            conto.dust(i_41, fs[i_41], fs_23[i_41], fs_22[i_41], (int)scx[i_41], (int)scz[i_41], 1.1F * cd.simag[cn], (int)tilt, capsized && mtouch);
                        if((i_32 == 2 || i_32 == 3) && (double)m.random() > 0.59999999999999998D)
                            conto.dust(i_41, fs[i_41], fs_23[i_41], fs_22[i_41], (int)scx[i_41], (int)scz[i_41], 1.15F * cd.simag[cn], (int)tilt, capsized && mtouch);
                    }
                } else
                if(dcnt != 0)
                {
                    dcnt -= 2;
                    if(dcnt < 0)
                        dcnt = 0;
                }
                if(i_32 == 3)
                {
                    int i_43 = (int)(m.random() * 4F);
                    scy[i_43] = (float)((double)(-100F * m.random() * (speed / (float)cd.swits[cn][2])) * ((double)cd.bounce[cn] - 0.29999999999999999D));
                }
                if(i_32 == 4)
                {
                    int i_44 = (int)(m.random() * 4F);
                    scy[i_44] = (float)((double)(-150F * m.random() * (speed / (float)cd.swits[cn][2])) * ((double)cd.bounce[cn] - 0.29999999999999999D));
                }
                f_39 += scx[i_41];
                f_40 += scz[i_41];
            }

            txz = conto.xz;
            if(f_39 > 0.0F)
                i = -1;
            else
                i = 1;
            d = (double)f_40 / Math.sqrt(f_39 * f_39 + f_40 * f_40);
            mxz = (int)((Math.acos(d) / 0.017453292519943295D) * (double)i);
            if(skid == 2)
            {
                if(!capsized)
                {
                    f_39 /= 4F;
                    f_40 /= 4F;
                    if(bool_5)
                        speed = -((float)Math.sqrt(f_39 * f_39 + f_40 * f_40) * m.cos(mxz - conto.xz));
                    else
                        speed = (float)Math.sqrt(f_39 * f_39 + f_40 * f_40) * m.cos(mxz - conto.xz);
                }
                skid = 0;
            }
            if(capsized && f_39 == 0.0F && f_40 == 0.0F)
                i_32 = 0;
            mtouch = false;
            bool_25 = true;
        } else
        if(skid != 2)
            skid = 2;
        int i_45 = 0;
        boolean bools[] = new boolean[4];
        boolean bools_46[] = new boolean[4];
        boolean bools_47[] = new boolean[4];
        float f_48 = 0.0F;
        for(int i_49 = 0; i_49 < 4; i_49++)
        {
            bools_46[i_49] = false;
            bools_47[i_49] = false;
            if(fs_23[i_49] > 245F)
            {
                i_45++;
                wtouch = true;
                gtouch = true;
                if(!bool_25 && scy[i_49] != 7F)
                {
                    float f_50 = scy[i_49] / 333.33F;
                    if((double)f_50 > 0.29999999999999999D)
                        f_50 = 0.3F;
                    if(i_32 == 0)
                        f_50 = (float)((double)f_50 + 1.1000000000000001D);
                    else
                        f_50 = (float)((double)f_50 + 1.2D);
                    conto.dust(i_49, fs[i_49], fs_23[i_49], fs_22[i_49], (int)scx[i_49], (int)scz[i_49], f_50 * cd.simag[cn], 0, capsized && mtouch);
                }
                fs_23[i_49] = 250F;
                bools_47[i_49] = true;
                f_48 += fs_23[i_49] - 250F;
                float f_51 = Math.abs(m.sin(pxy)) + Math.abs(m.sin(pzy));
                f_51 /= 3F;
                if((double)f_51 > 0.40000000000000002D)
                    f_51 = 0.4F;
                f_51 += cd.bounce[cn];
                if((double)f_51 < 1.1000000000000001D)
                    f_51 = 1.1F;
                regy(i_49, Math.abs(scy[i_49] * f_51), conto);
                if(scy[i_49] > 0.0F)
                    scy[i_49] -= Math.abs(scy[i_49] * f_51);
                if(capsized)
                    bools_46[i_49] = true;
            }
            bools[i_49] = false;
        }

        if(i_45 != 0)
        {
            f_48 /= i_45;
            for(int i_52 = 0; i_52 < 4; i_52++)
                if(!bools_47[i_52])
                    fs_23[i_52] -= f_48;

        }
        int i_53 = 0;
        for(int i_54 = 0; i_54 < trackers.sect[i_30][i_31].length; i_54++)
        {
            int i_55 = trackers.sect[i_30][i_31][i_54];
            int i_56 = 0;
            int i_57 = 0;
            for(int i_58 = 0; i_58 < 4; i_58++)
            {
                if(bools_46[i_58] && (trackers.skd[i_55] == 0 || trackers.skd[i_55] == 1) && fs[i_58] > (float)(trackers.x[i_55] - trackers.radx[i_55]) && fs[i_58] < (float)(trackers.x[i_55] + trackers.radx[i_55]) && fs_22[i_58] > (float)(trackers.z[i_55] - trackers.radz[i_55]) && fs_22[i_58] < (float)(trackers.z[i_55] + trackers.radz[i_55]))
                {
                    conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 1);
                    if(im == xt.im)
                        xt.gscrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                }
                if(bools[i_58] || fs[i_58] <= (float)(trackers.x[i_55] - trackers.radx[i_55]) || fs[i_58] >= (float)(trackers.x[i_55] + trackers.radx[i_55]) || fs_22[i_58] <= (float)(trackers.z[i_55] - trackers.radz[i_55]) || fs_22[i_58] >= (float)(trackers.z[i_55] + trackers.radz[i_55]) || fs_23[i_58] <= (float)(trackers.y[i_55] - trackers.rady[i_55]) || fs_23[i_58] >= (float)(trackers.y[i_55] + trackers.rady[i_55]) || trackers.decor[i_55] && m.resdown == 2 && xt.multion == 0)
                    continue;
                if(trackers.xy[i_55] == 0 && trackers.zy[i_55] == 0 && trackers.y[i_55] != 250 && fs_23[i_58] > (float)(trackers.y[i_55] - 5))
                {
                    i_57++;
                    wtouch = true;
                    gtouch = true;
                    if(!bool_25 && scy[i_58] != 7F)
                    {
                        float f_59 = scy[i_58] / 333.33F;
                        if((double)f_59 > 0.29999999999999999D)
                            f_59 = 0.3F;
                        if(i_32 == 0)
                            f_59 = (float)((double)f_59 + 1.1000000000000001D);
                        else
                            f_59 = (float)((double)f_59 + 1.2D);
                        conto.dust(i_58, fs[i_58], fs_23[i_58], fs_22[i_58], (int)scx[i_58], (int)scz[i_58], f_59 * cd.simag[cn], 0, capsized && mtouch);
                    }
                    fs_23[i_58] = trackers.y[i_55];
                    if(capsized && (trackers.skd[i_55] == 0 || trackers.skd[i_55] == 1))
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 1);
                        if(im == xt.im)
                            xt.gscrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    float f_60 = Math.abs(m.sin(pxy)) + Math.abs(m.sin(pzy));
                    f_60 /= 3F;
                    if((double)f_60 > 0.40000000000000002D)
                        f_60 = 0.4F;
                    f_60 += cd.bounce[cn];
                    if((double)f_60 < 1.1000000000000001D)
                        f_60 = 1.1F;
                    regy(i_58, Math.abs(scy[i_58] * f_60), conto);
                    if(scy[i_58] > 0.0F)
                        scy[i_58] -= Math.abs(scy[i_58] * f_60);
                    bools[i_58] = true;
                }
                if(trackers.zy[i_55] == -90 && fs_22[i_58] < (float)(trackers.z[i_55] + trackers.radz[i_55]) && (scz[i_58] < 0.0F || trackers.radz[i_55] == 287))
                {
                    for(int i_61 = 0; i_61 < 4; i_61++)
                        if(i_58 != i_61 && fs_22[i_61] >= (float)(trackers.z[i_55] + trackers.radz[i_55]))
                            fs_22[i_61] -= fs_22[i_58] - (float)(trackers.z[i_55] + trackers.radz[i_55]);

                    fs_22[i_58] = trackers.z[i_55] + trackers.radz[i_55];
                    if(trackers.skd[i_55] != 2)
                        crank[0][i_58]++;
                    if(trackers.skd[i_55] == 5 && m.random() > m.random())
                        crank[0][i_58]++;
                    if(crank[0][i_58] > 1)
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 0);
                        if(im == xt.im)
                            xt.scrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    float f_62 = Math.abs(m.cos(pxy)) + Math.abs(m.cos(pzy));
                    f_62 /= 4F;
                    if((double)f_62 > 0.29999999999999999D)
                        f_62 = 0.3F;
                    if(bool_25)
                        f_62 = 0.0F;
                    f_62 = (float)((double)f_62 + ((double)cd.bounce[cn] - 0.20000000000000001D));
                    if((double)f_62 < 1.1000000000000001D)
                        f_62 = 1.1F;
                    regz(i_58, Math.abs(scz[i_58] * f_62 * (float)trackers.dam[i_55]), conto);
                    scz[i_58] += Math.abs(scz[i_58] * f_62);
                    skid = 2;
                    bool_6 = true;
                    bools[i_58] = true;
                    if(!trackers.notwall[i_55])
                        control.wall = i_55;
                }
                if(trackers.zy[i_55] == 90 && fs_22[i_58] > (float)(trackers.z[i_55] - trackers.radz[i_55]) && (scz[i_58] > 0.0F || trackers.radz[i_55] == 287))
                {
                    for(int i_63 = 0; i_63 < 4; i_63++)
                        if(i_58 != i_63 && fs_22[i_63] <= (float)(trackers.z[i_55] - trackers.radz[i_55]))
                            fs_22[i_63] -= fs_22[i_58] - (float)(trackers.z[i_55] - trackers.radz[i_55]);

                    fs_22[i_58] = trackers.z[i_55] - trackers.radz[i_55];
                    if(trackers.skd[i_55] != 2)
                        crank[1][i_58]++;
                    if(trackers.skd[i_55] == 5 && m.random() > m.random())
                        crank[1][i_58]++;
                    if(crank[1][i_58] > 1)
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 0);
                        if(im == xt.im)
                            xt.scrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    float f_64 = Math.abs(m.cos(pxy)) + Math.abs(m.cos(pzy));
                    f_64 /= 4F;
                    if((double)f_64 > 0.29999999999999999D)
                        f_64 = 0.3F;
                    if(bool_25)
                        f_64 = 0.0F;
                    f_64 = (float)((double)f_64 + ((double)cd.bounce[cn] - 0.20000000000000001D));
                    if((double)f_64 < 1.1000000000000001D)
                        f_64 = 1.1F;
                    regz(i_58, -Math.abs(scz[i_58] * f_64 * (float)trackers.dam[i_55]), conto);
                    scz[i_58] -= Math.abs(scz[i_58] * f_64);
                    skid = 2;
                    bool_6 = true;
                    bools[i_58] = true;
                    if(!trackers.notwall[i_55])
                        control.wall = i_55;
                }
                if(trackers.xy[i_55] == -90 && fs[i_58] < (float)(trackers.x[i_55] + trackers.radx[i_55]) && (scx[i_58] < 0.0F || trackers.radx[i_55] == 287))
                {
                    for(int i_65 = 0; i_65 < 4; i_65++)
                        if(i_58 != i_65 && fs[i_65] >= (float)(trackers.x[i_55] + trackers.radx[i_55]))
                            fs[i_65] -= fs[i_58] - (float)(trackers.x[i_55] + trackers.radx[i_55]);

                    fs[i_58] = trackers.x[i_55] + trackers.radx[i_55];
                    if(trackers.skd[i_55] != 2)
                        crank[2][i_58]++;
                    if(trackers.skd[i_55] == 5 && m.random() > m.random())
                        crank[2][i_58]++;
                    if(crank[2][i_58] > 1)
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 0);
                        if(im == xt.im)
                            xt.scrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    float f_66 = Math.abs(m.cos(pxy)) + Math.abs(m.cos(pzy));
                    f_66 /= 4F;
                    if((double)f_66 > 0.29999999999999999D)
                        f_66 = 0.3F;
                    if(bool_25)
                        f_66 = 0.0F;
                    f_66 = (float)((double)f_66 + ((double)cd.bounce[cn] - 0.20000000000000001D));
                    if((double)f_66 < 1.1000000000000001D)
                        f_66 = 1.1F;
                    regx(i_58, Math.abs(scx[i_58] * f_66 * (float)trackers.dam[i_55]), conto);
                    scx[i_58] += Math.abs(scx[i_58] * f_66);
                    skid = 2;
                    bool_6 = true;
                    bools[i_58] = true;
                    if(!trackers.notwall[i_55])
                        control.wall = i_55;
                }
                if(trackers.xy[i_55] == 90 && fs[i_58] > (float)(trackers.x[i_55] - trackers.radx[i_55]) && (scx[i_58] > 0.0F || trackers.radx[i_55] == 287))
                {
                    for(int i_67 = 0; i_67 < 4; i_67++)
                        if(i_58 != i_67 && fs[i_67] <= (float)(trackers.x[i_55] - trackers.radx[i_55]))
                            fs[i_67] -= fs[i_58] - (float)(trackers.x[i_55] - trackers.radx[i_55]);

                    fs[i_58] = trackers.x[i_55] - trackers.radx[i_55];
                    if(trackers.skd[i_55] != 2)
                        crank[3][i_58]++;
                    if(trackers.skd[i_55] == 5 && m.random() > m.random())
                        crank[3][i_58]++;
                    if(crank[3][i_58] > 1)
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 0);
                        if(im == xt.im)
                            xt.scrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    float f_68 = Math.abs(m.cos(pxy)) + Math.abs(m.cos(pzy));
                    f_68 /= 4F;
                    if((double)f_68 > 0.29999999999999999D)
                        f_68 = 0.3F;
                    if(bool_25)
                        f_68 = 0.0F;
                    f_68 = (float)((double)f_68 + ((double)cd.bounce[cn] - 0.20000000000000001D));
                    if((double)f_68 < 1.1000000000000001D)
                        f_68 = 1.1F;
                    regx(i_58, -Math.abs(scx[i_58] * f_68 * (float)trackers.dam[i_55]), conto);
                    scx[i_58] -= Math.abs(scx[i_58] * f_68);
                    skid = 2;
                    bool_6 = true;
                    bools[i_58] = true;
                    if(!trackers.notwall[i_55])
                        control.wall = i_55;
                }
                if(trackers.zy[i_55] != 0 && trackers.zy[i_55] != 90 && trackers.zy[i_55] != -90)
                {
                    int i_69 = 90 + trackers.zy[i_55];
                    float f_70 = 1.0F + (float)(50 - Math.abs(trackers.zy[i_55])) / 30F;
                    if(f_70 < 1.0F)
                        f_70 = 1.0F;
                    float f_71 = (float)trackers.y[i_55] + ((fs_23[i_58] - (float)trackers.y[i_55]) * m.cos(i_69) - (fs_22[i_58] - (float)trackers.z[i_55]) * m.sin(i_69));
                    float f_72 = (float)trackers.z[i_55] + ((fs_23[i_58] - (float)trackers.y[i_55]) * m.sin(i_69) + (fs_22[i_58] - (float)trackers.z[i_55]) * m.cos(i_69));
                    if(f_72 > (float)trackers.z[i_55] && f_72 < (float)(trackers.z[i_55] + 200))
                    {
                        scy[i_58] -= (f_72 - (float)trackers.z[i_55]) / f_70;
                        f_72 = trackers.z[i_55];
                    }
                    if(f_72 > (float)(trackers.z[i_55] - 30))
                    {
                        if(trackers.skd[i_55] == 2)
                            i_56++;
                        else
                            i_53++;
                        wtouch = true;
                        gtouch = false;
                        if(capsized && (trackers.skd[i_55] == 0 || trackers.skd[i_55] == 1))
                        {
                            conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 1);
                            if(im == xt.im)
                                xt.gscrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                        }
                        if(!bool_25 && i_32 != 0)
                        {
                            float f_73 = 1.4F;
                            conto.dust(i_58, fs[i_58], fs_23[i_58], fs_22[i_58], (int)scx[i_58], (int)scz[i_58], f_73 * cd.simag[cn], 0, capsized && mtouch);
                        }
                    }
                    fs_23[i_58] = (float)trackers.y[i_55] + ((f_71 - (float)trackers.y[i_55]) * m.cos(-i_69) - (f_72 - (float)trackers.z[i_55]) * m.sin(-i_69));
                    fs_22[i_58] = (float)trackers.z[i_55] + ((f_71 - (float)trackers.y[i_55]) * m.sin(-i_69) + (f_72 - (float)trackers.z[i_55]) * m.cos(-i_69));
                    bools[i_58] = true;
                }
                if(trackers.xy[i_55] == 0 || trackers.xy[i_55] == 90 || trackers.xy[i_55] == -90)
                    continue;
                int i_74 = 90 + trackers.xy[i_55];
                float f_75 = 1.0F + (float)(50 - Math.abs(trackers.xy[i_55])) / 30F;
                if(f_75 < 1.0F)
                    f_75 = 1.0F;
                float f_76 = (float)trackers.y[i_55] + ((fs_23[i_58] - (float)trackers.y[i_55]) * m.cos(i_74) - (fs[i_58] - (float)trackers.x[i_55]) * m.sin(i_74));
                float f_77 = (float)trackers.x[i_55] + ((fs_23[i_58] - (float)trackers.y[i_55]) * m.sin(i_74) + (fs[i_58] - (float)trackers.x[i_55]) * m.cos(i_74));
                if(f_77 > (float)trackers.x[i_55] && f_77 < (float)(trackers.x[i_55] + 200))
                {
                    scy[i_58] -= (f_77 - (float)trackers.x[i_55]) / f_75;
                    f_77 = trackers.x[i_55];
                }
                if(f_77 > (float)(trackers.x[i_55] - 30))
                {
                    if(trackers.skd[i_55] == 2)
                        i_56++;
                    else
                        i_53++;
                    wtouch = true;
                    gtouch = false;
                    if(capsized && (trackers.skd[i_55] == 0 || trackers.skd[i_55] == 1))
                    {
                        conto.sprk(fs[i_58], fs_23[i_58], fs_22[i_58], scx[i_58], scy[i_58], scz[i_58], 1);
                        if(im == xt.im)
                            xt.gscrape((int)scx[i_58], (int)scy[i_58], (int)scz[i_58]);
                    }
                    if(!bool_25 && i_32 != 0)
                    {
                        float f_78 = 1.4F;
                        conto.dust(i_58, fs[i_58], fs_23[i_58], fs_22[i_58], (int)scx[i_58], (int)scz[i_58], f_78 * cd.simag[cn], 0, capsized && mtouch);
                    }
                }
                fs_23[i_58] = (float)trackers.y[i_55] + ((f_76 - (float)trackers.y[i_55]) * m.cos(-i_74) - (f_77 - (float)trackers.x[i_55]) * m.sin(-i_74));
                fs[i_58] = (float)trackers.x[i_55] + ((f_76 - (float)trackers.y[i_55]) * m.sin(-i_74) + (f_77 - (float)trackers.x[i_55]) * m.cos(-i_74));
                bools[i_58] = true;
            }

            if(i_56 == 4)
                mtouch = true;
            if(i_57 == 4)
                i_45 = 4;
        }

        if(i_53 == 4)
            mtouch = true;
        for(int i_79 = 0; i_79 < 4; i_79++)
        {
            for(int i_80 = 0; i_80 < 4; i_80++)
            {
                if(crank[i_79][i_80] == lcrank[i_79][i_80])
                    crank[i_79][i_80] = 0;
                lcrank[i_79][i_80] = crank[i_79][i_80];
            }

        }

        int i_81 = 0;
        int i_82 = 0;
        int i_83 = 0;
        int i_84 = 0;
        if(scy[2] != scy[0])
        {
            if(scy[2] < scy[0])
                i = -1;
            else
                i = 1;
            d = Math.sqrt((fs_22[0] - fs_22[2]) * (fs_22[0] - fs_22[2]) + (fs_23[0] - fs_23[2]) * (fs_23[0] - fs_23[2]) + (fs[0] - fs[2]) * (fs[0] - fs[2])) / (double)(Math.abs(conto.keyz[0]) + Math.abs(conto.keyz[2]));
            if(d >= 0.99980000000000002D)
                i_81 = i;
            else
                i_81 = (int)((Math.acos(d) / 0.017453292519943295D) * (double)i);
        }
        if(scy[3] != scy[1])
        {
            if(scy[3] < scy[1])
                i = -1;
            else
                i = 1;
            d = Math.sqrt((fs_22[1] - fs_22[3]) * (fs_22[1] - fs_22[3]) + (fs_23[1] - fs_23[3]) * (fs_23[1] - fs_23[3]) + (fs[1] - fs[3]) * (fs[1] - fs[3])) / (double)(Math.abs(conto.keyz[1]) + Math.abs(conto.keyz[3]));
            if(d >= 0.99980000000000002D)
                i_82 = i;
            else
                i_82 = (int)((Math.acos(d) / 0.017453292519943295D) * (double)i);
        }
        if(scy[1] != scy[0])
        {
            if(scy[1] < scy[0])
                i = -1;
            else
                i = 1;
            d = Math.sqrt((fs_22[0] - fs_22[1]) * (fs_22[0] - fs_22[1]) + (fs_23[0] - fs_23[1]) * (fs_23[0] - fs_23[1]) + (fs[0] - fs[1]) * (fs[0] - fs[1])) / (double)(Math.abs(conto.keyx[0]) + Math.abs(conto.keyx[1]));
            if(d >= 0.99980000000000002D)
                i_83 = i;
            else
                i_83 = (int)((Math.acos(d) / 0.017453292519943295D) * (double)i);
        }
        if(scy[3] != scy[2])
        {
            if(scy[3] < scy[2])
                i = -1;
            else
                i = 1;
            d = Math.sqrt((fs_22[2] - fs_22[3]) * (fs_22[2] - fs_22[3]) + (fs_23[2] - fs_23[3]) * (fs_23[2] - fs_23[3]) + (fs[2] - fs[3]) * (fs[2] - fs[3])) / (double)(Math.abs(conto.keyx[2]) + Math.abs(conto.keyx[3]));
            if(d >= 0.99980000000000002D)
                i_84 = i;
            else
                i_84 = (int)((Math.acos(d) / 0.017453292519943295D) * (double)i);
        }
        if(bool_6)
        {
            int i_85;
            for(i_85 = Math.abs(conto.xz + 45); i_85 > 180; i_85 -= 360);
            if(Math.abs(i_85) > 90)
                pmlt = 1;
            else
                pmlt = -1;
            for(i_85 = Math.abs(conto.xz - 45); i_85 > 180; i_85 -= 360);
            if(Math.abs(i_85) > 90)
                nmlt = 1;
            else
                nmlt = -1;
        }
        conto.xz += forca * (((((scz[0] * (float)nmlt - scz[1] * (float)pmlt) + scz[2] * (float)pmlt) - scz[3] * (float)nmlt) + scx[0] * (float)pmlt + scx[1] * (float)nmlt) - scx[2] * (float)nmlt - scx[3] * (float)pmlt);
        if(Math.abs(i_82) > Math.abs(i_81))
            i_81 = i_82;
        if(Math.abs(i_84) > Math.abs(i_83))
            i_83 = i_84;
        if(!bool)
            pzy += i_81;
        else
            pzy -= i_81;
        if(!bool_8)
            pxy += i_83;
        else
            pxy -= i_83;
        if(i_45 == 4)
        {
            int i_86 = 0;
            while(pzy < 360) 
            {
                pzy += 360;
                conto.zy += 360;
            }
            while(pzy > 360) 
            {
                pzy -= 360;
                conto.zy -= 360;
            }
            if(pzy < 190 && pzy > 170)
            {
                pzy = 180;
                conto.zy = 180;
                i_86++;
            }
            if(pzy > 350 || pzy < 10)
            {
                pzy = 0;
                conto.zy = 0;
                i_86++;
            }
            while(pxy < 360) 
            {
                pxy += 360;
                conto.xy += 360;
            }
            while(pxy > 360) 
            {
                pxy -= 360;
                conto.xy -= 360;
            }
            if(pxy < 190 && pxy > 170)
            {
                pxy = 180;
                conto.xy = 180;
                i_86++;
            }
            if(pxy > 350 || pxy < 10)
            {
                pxy = 0;
                conto.xy = 0;
                i_86++;
            }
            if(i_86 == 2)
                mtouch = true;
        }
        if(!mtouch && wtouch)
        {
            if(cntouch == 10)
                mtouch = true;
            else
                cntouch++;
        } else
        {
            cntouch = 0;
        }
        conto.y = (int)(((fs_23[0] + fs_23[1] + fs_23[2] + fs_23[3]) / 4F - (float)i_10 * m.cos(pzy) * m.cos(pxy)) + f_12);
        if(bool)
            i = -1;
        else
            i = 1;
        conto.x = (int)(((((((((((fs[0] - (float)conto.keyx[0] * m.cos(conto.xz)) + (float)(i * conto.keyz[0]) * m.sin(conto.xz) + fs[1]) - (float)conto.keyx[1] * m.cos(conto.xz)) + (float)(i * conto.keyz[1]) * m.sin(conto.xz) + fs[2]) - (float)conto.keyx[2] * m.cos(conto.xz)) + (float)(i * conto.keyz[2]) * m.sin(conto.xz) + fs[3]) - (float)conto.keyx[3] * m.cos(conto.xz)) + (float)(i * conto.keyz[3]) * m.sin(conto.xz)) / 4F + (float)i_10 * m.sin(pxy) * m.cos(conto.xz)) - (float)i_10 * m.sin(pzy) * m.sin(conto.xz)) + f);
        conto.z = (int)((((((((((fs_22[0] - (float)(i * conto.keyz[0]) * m.cos(conto.xz) - (float)conto.keyx[0] * m.sin(conto.xz)) + fs_22[1]) - (float)(i * conto.keyz[1]) * m.cos(conto.xz) - (float)conto.keyx[1] * m.sin(conto.xz)) + fs_22[2]) - (float)(i * conto.keyz[2]) * m.cos(conto.xz) - (float)conto.keyx[2] * m.sin(conto.xz)) + fs_22[3]) - (float)(i * conto.keyz[3]) * m.cos(conto.xz) - (float)conto.keyx[3] * m.sin(conto.xz)) / 4F + (float)i_10 * m.sin(pxy) * m.sin(conto.xz)) - (float)i_10 * m.sin(pzy) * m.cos(conto.xz)) + f_11);
        if(Math.abs(speed) > 10F || !mtouch)
        {
            if(Math.abs(pxy - conto.xy) >= 4)
            {
                if(pxy > conto.xy)
                    conto.xy += 2 + (pxy - conto.xy) / 2;
                else
                    conto.xy -= 2 + (conto.xy - pxy) / 2;
            } else
            {
                conto.xy = pxy;
            }
            if(Math.abs(pzy - conto.zy) >= 4)
            {
                if(pzy > conto.zy)
                    conto.zy += 2 + (pzy - conto.zy) / 2;
                else
                    conto.zy -= 2 + (conto.zy - pzy) / 2;
            } else
            {
                conto.zy = pzy;
            }
        }
        if(wtouch && !capsized)
        {
            float f_87 = (float)((double)((speed / (float)cd.swits[cn][2]) * 14F) * ((double)cd.bounce[cn] - 0.40000000000000002D));
            if(control.left && tilt < f_87 && tilt >= 0.0F)
                tilt += 0.40000000000000002D;
            else
            if(control.right && tilt > -f_87 && tilt <= 0.0F)
                tilt -= 0.40000000000000002D;
            else
            if((double)Math.abs(tilt) > 3D * ((double)cd.bounce[cn] - 0.40000000000000002D))
            {
                if(tilt > 0.0F)
                    tilt -= 3D * ((double)cd.bounce[cn] - 0.29999999999999999D);
                else
                    tilt += 3D * ((double)cd.bounce[cn] - 0.29999999999999999D);
            } else
            {
                tilt = 0.0F;
            }
            conto.xy += tilt;
            if(gtouch)
                conto.y -= (double)tilt / 1.5D;
        } else
        if(tilt != 0.0F)
            tilt = 0.0F;
        if(wtouch && i_32 == 2)
        {
            conto.zy += (int)((double)((m.random() * 6F * speed) / (float)cd.swits[cn][2] - (3F * speed) / (float)cd.swits[cn][2]) * ((double)cd.bounce[cn] - 0.29999999999999999D));
            conto.xy += (int)((double)((m.random() * 6F * speed) / (float)cd.swits[cn][2] - (3F * speed) / (float)cd.swits[cn][2]) * ((double)cd.bounce[cn] - 0.29999999999999999D));
        }
        if(wtouch && i_32 == 1)
        {
            conto.zy += (int)((double)((m.random() * 4F * speed) / (float)cd.swits[cn][2] - (2.0F * speed) / (float)cd.swits[cn][2]) * ((double)cd.bounce[cn] - 0.29999999999999999D));
            conto.xy += (int)((double)((m.random() * 4F * speed) / (float)cd.swits[cn][2] - (2.0F * speed) / (float)cd.swits[cn][2]) * ((double)cd.bounce[cn] - 0.29999999999999999D));
        }
        if(hitmag >= cd.maxmag[cn] && !dest)
        {
            distruct(conto);
            if(cntdest == 7)
                dest = true;
            else
                cntdest++;
            if(cntdest == 1)
                rpd.dest[im] = 300;
        }
        if(conto.dist == 0)
        {
            for(int i_88 = 0; i_88 < conto.npl; i_88++)
            {
                if(conto.p[i_88].chip != 0)
                    conto.p[i_88].chip = 0;
                if(conto.p[i_88].embos != 0)
                    conto.p[i_88].embos = 13;
            }

        }
        int i_89 = 0;
        int i_90 = 0;
        int i_91 = 0;
        if(nofocus)
            i_4 = 1;
        else
            i_4 = 7;
        for(int i_92 = 0; i_92 < checkpoints.n; i_92++)
        {
            if(checkpoints.typ[i_92] > 0)
            {
                i_91++;
                if(checkpoints.typ[i_92] == 1)
                {
                    if(clear == i_91 + nlaps * checkpoints.nsp)
                        i_4 = 1;
                    if((float)Math.abs(conto.z - checkpoints.z[i_92]) < 60F + Math.abs(scz[0] + scz[1] + scz[2] + scz[3]) / 4F && Math.abs(conto.x - checkpoints.x[i_92]) < 700 && Math.abs((conto.y - checkpoints.y[i_92]) + 350) < 450 && clear == (i_91 + nlaps * checkpoints.nsp) - 1)
                    {
                        clear = i_91 + nlaps * checkpoints.nsp;
                        pcleared = i_92;
                        focus = -1;
                    }
                }
                if(checkpoints.typ[i_92] == 2)
                {
                    if(clear == i_91 + nlaps * checkpoints.nsp)
                        i_4 = 1;
                    if((float)Math.abs(conto.x - checkpoints.x[i_92]) < 60F + Math.abs(scx[0] + scx[1] + scx[2] + scx[3]) / 4F && Math.abs(conto.z - checkpoints.z[i_92]) < 700 && Math.abs((conto.y - checkpoints.y[i_92]) + 350) < 450 && clear == (i_91 + nlaps * checkpoints.nsp) - 1)
                    {
                        clear = i_91 + nlaps * checkpoints.nsp;
                        pcleared = i_92;
                        focus = -1;
                    }
                }
            }
            if(py(conto.x / 100, checkpoints.x[i_92] / 100, conto.z / 100, checkpoints.z[i_92] / 100) * i_4 < i_90 || i_90 == 0)
            {
                i_89 = i_92;
                i_90 = py(conto.x / 100, checkpoints.x[i_92] / 100, conto.z / 100, checkpoints.z[i_92] / 100) * i_4;
            }
        }

        if(clear == i_91 + nlaps * checkpoints.nsp)
        {
            nlaps++;
            if(xt.multion == 1 && im == xt.im)
            {
                if(xt.laptime < xt.fastestlap || xt.fastestlap == 0)
                    xt.fastestlap = xt.laptime;
                xt.laptime = 0;
            }
        }
        if(im == xt.im)
        {
            if(xt.multion == 1 && xt.starcnt == 0)
                xt.laptime++;
            for(m.checkpoint = clear; m.checkpoint >= checkpoints.nsp; m.checkpoint -= checkpoints.nsp);
            if(clear == checkpoints.nlaps * checkpoints.nsp - 1)
                m.lastcheck = true;
            if(checkpoints.haltall)
                m.lastcheck = false;
        }
        if(focus == -1)
        {
            if(im == xt.im)
                i_89 += 2;
            else
                i_89++;
            if(!nofocus)
            {
                i_91 = pcleared + 1;
                if(i_91 >= checkpoints.n)
                    i_91 = 0;
                do
                {
                    if(checkpoints.typ[i_91] > 0)
                        break;
                    if(++i_91 >= checkpoints.n)
                        i_91 = 0;
                } while(true);
                if(i_89 > i_91 && (clear != nlaps * checkpoints.nsp || i_89 < pcleared))
                {
                    i_89 = i_91;
                    focus = i_89;
                }
            }
            if(i_89 >= checkpoints.n)
                i_89 -= checkpoints.n;
            if(checkpoints.typ[i_89] == -3)
                i_89 = 0;
            if(im == xt.im)
            {
                if(missedcp != -1)
                    missedcp = -1;
            } else
            if(missedcp != 0)
                missedcp = 0;
        } else
        {
            i_89 = focus;
            if(im == xt.im)
            {
                if(missedcp == 0 && mtouch && Math.sqrt(py(conto.x / 10, checkpoints.x[focus] / 10, conto.z / 10, checkpoints.z[focus] / 10)) > 800D)
                    missedcp = 1;
                if(missedcp == -2 && Math.sqrt(py(conto.x / 10, checkpoints.x[focus] / 10, conto.z / 10, checkpoints.z[focus] / 10)) < 400D)
                    missedcp = 0;
                if(missedcp != 0 && mtouch && Math.sqrt(py(conto.x / 10, checkpoints.x[focus] / 10, conto.z / 10, checkpoints.z[focus] / 10)) < 250D)
                    missedcp = 68;
            } else
            {
                missedcp = 1;
            }
            if(nofocus)
            {
                focus = -1;
                missedcp = 0;
            }
        }
        if(nofocus)
            nofocus = false;
        point = i_89;
        if(fixes != 0)
        {
            if(m.noelec == 0)
            {
                for(int i_93 = 0; i_93 < checkpoints.fn; i_93++)
                    if(!checkpoints.roted[i_93])
                    {
                        if(Math.abs(conto.z - checkpoints.fz[i_93]) < 200 && py(conto.x / 100, checkpoints.fx[i_93] / 100, conto.y / 100, checkpoints.fy[i_93] / 100) < 30)
                        {
                            if(conto.dist == 0)
                            {
                                conto.fcnt = 8;
                            } else
                            {
                                if(im == xt.im && !conto.fix && !xt.mutes)
                                    xt.carfixed.play();
                                conto.fix = true;
                            }
                            rpd.fix[im] = 300;
                        }
                    } else
                    if(Math.abs(conto.x - checkpoints.fx[i_93]) < 200 && py(conto.z / 100, checkpoints.fz[i_93] / 100, conto.y / 100, checkpoints.fy[i_93] / 100) < 30)
                    {
                        if(conto.dist == 0)
                        {
                            conto.fcnt = 8;
                        } else
                        {
                            if(im == xt.im && !conto.fix && !xt.mutes)
                                xt.carfixed.play();
                            conto.fix = true;
                        }
                        rpd.fix[im] = 300;
                    }

            }
        } else
        {
            for(int i_94 = 0; i_94 < checkpoints.fn; i_94++)
                if(rpy(conto.x / 100, checkpoints.fx[i_94] / 100, conto.y / 100, checkpoints.fy[i_94] / 100, conto.z / 100, checkpoints.fz[i_94] / 100) < 760)
                    m.noelec = 2;

        }
        if(conto.fcnt == 7 || conto.fcnt == 8)
        {
            squash = 0;
            nbsq = 0;
            hitmag = 0;
            cntdest = 0;
            dest = false;
            newcar = true;
            conto.fcnt = 9;
            if(fixes > 0)
                fixes--;
        }
        if(newedcar != 0)
        {
            newedcar--;
            if(newedcar == 10)
                newcar = false;
        }
        if(!mtouch)
        {
            if(trcnt != 1)
            {
                trcnt = 1;
                lxz = conto.xz;
            }
            if(loop == 2 || loop == -1)
            {
                travxy += rcomp - lcomp;
                if(Math.abs(travxy) > 135)
                    rtab = true;
                travzy += ucomp - dcomp;
                if(travzy > 135)
                    ftab = true;
                if(travzy < -135)
                    btab = true;
            }
            if(lxz != conto.xz)
            {
                travxz += lxz - conto.xz;
                lxz = conto.xz;
            }
            if(srfcnt < 10)
            {
                if(control.wall != -1)
                    surfer = true;
                srfcnt++;
            }
        } else
        if(!dest)
        {
            if(!capsized)
            {
                if(capcnt != 0)
                    capcnt = 0;
                if(gtouch && trcnt != 0)
                {
                    if(trcnt == 9)
                    {
                        powerup = 0.0F;
                        if(Math.abs(travxy) > 90)
                            powerup += (float)Math.abs(travxy) / 24F;
                        else
                        if(rtab)
                            powerup += 30F;
                        if(Math.abs(travzy) > 90)
                        {
                            powerup += (float)Math.abs(travzy) / 18F;
                        } else
                        {
                            if(ftab)
                                powerup += 40F;
                            if(btab)
                                powerup += 40F;
                        }
                        if(Math.abs(travxz) > 90)
                            powerup += (float)Math.abs(travxz) / 18F;
                        if(surfer)
                            powerup += 30F;
                        power += powerup;
                        if(im == xt.im && (int)powerup > rpd.powered && rpd.wasted == 0 && (powerup > 60F || checkpoints.stage == 1 || checkpoints.stage == 2))
                        {
                            rpdcatch = 30;
                            if(rpd.hcaught)
                                rpd.powered = (int)powerup;
                            if(xt.multion == 1 && powerup > (float)xt.beststunt)
                                xt.beststunt = (int)powerup;
                        }
                        if(power > 98F)
                        {
                            power = 98F;
                            if(powerup > 150F)
                                xtpower = 200;
                            else
                                xtpower = 100;
                        }
                    }
                    if(trcnt == 10)
                    {
                        travxy = 0;
                        travzy = 0;
                        travxz = 0;
                        ftab = false;
                        rtab = false;
                        btab = false;
                        trcnt = 0;
                        srfcnt = 0;
                        surfer = false;
                    } else
                    {
                        trcnt++;
                    }
                }
            } else
            {
                if(trcnt != 0)
                {
                    travxy = 0;
                    travzy = 0;
                    travxz = 0;
                    ftab = false;
                    rtab = false;
                    btab = false;
                    trcnt = 0;
                    srfcnt = 0;
                    surfer = false;
                }
                if(capcnt == 0)
                {
                    int i_95 = 0;
                    for(int i_96 = 0; i_96 < 4; i_96++)
                        if(Math.abs(scz[i_96]) < 70F && Math.abs(scx[i_96]) < 70F)
                            i_95++;

                    if(i_95 == 4)
                        capcnt = 1;
                } else
                {
                    capcnt++;
                    if(capcnt == 30)
                    {
                        speed = 0.0F;
                        conto.y += cd.flipy[cn];
                        pxy += 180;
                        conto.xy += 180;
                        capcnt = 0;
                    }
                }
            }
            if(trcnt == 0 && speed != 0.0F)
                if(xtpower == 0)
                {
                    if(power > 0.0F)
                        power -= (power * power * power) / (float)cd.powerloss[cn];
                    else
                        power = 0.0F;
                } else
                {
                    xtpower--;
                }
        }
        if(im == xt.im)
        {
            if(control.wall != -1)
                control.wall = -1;
        } else
        if(lastcolido != 0 && !dest)
            lastcolido--;
        if(dest)
        {
            if(checkpoints.dested[im] == 0)
                if(lastcolido == 0)
                    checkpoints.dested[im] = 1;
                else
                    checkpoints.dested[im] = 2;
        } else
        if(checkpoints.dested[im] != 0 && checkpoints.dested[im] != 3)
            checkpoints.dested[im] = 0;
        if(im == xt.im && rpd.wasted == 0 && rpdcatch != 0)
        {
            rpdcatch--;
            if(rpdcatch == 0)
            {
                rpd.cotchinow(im);
                if(rpd.hcaught)
                    rpd.whenwasted = (int)(185F + m.random() * 20F);
            }
        }
    }

    public void distruct(ContO conto)
    {
        for(int i = 0; i < conto.npl; i++)
            if(conto.p[i].wz == 0 || conto.p[i].gr == -17 || conto.p[i].gr == -16)
                conto.p[i].embos = 1;

    }

    public int regy(int i, float f, ContO conto)
    {
        int i_97 = 0;
        boolean bool = true;
        if(xt.multion == 1 && xt.im != im)
            bool = false;
        if(xt.multion >= 2)
            bool = false;
        if(xt.lan && xt.multion >= 1 && xt.isbot[im])
            bool = true;
        f *= cd.dammult[cn];
        if(f > 100F)
        {
            rpd.recy(i, f, mtouch, im);
            f -= 100F;
            int i_98 = 0;
            int i_99 = 0;
            int i_100 = conto.zy;
            int i_101 = conto.xy;
            for(; i_100 < 360; i_100 += 360);
            for(; i_100 > 360; i_100 -= 360);
            if(i_100 < 210 && i_100 > 150)
                i_98 = -1;
            if(i_100 > 330 || i_100 < 30)
                i_98 = 1;
            for(; i_101 < 360; i_101 += 360);
            for(; i_101 > 360; i_101 -= 360);
            if(i_101 < 210 && i_101 > 150)
                i_99 = -1;
            if(i_101 > 330 || i_101 < 30)
                i_99 = 1;
            if(i_99 * i_98 == 0)
                shakedam = (int)((Math.abs(f) + (float)shakedam) / 2.0F);
            if(im == xt.im || colidim)
                xt.crash(f, i_99 * i_98);
            if(i_99 * i_98 == 0 || mtouch)
            {
                for(int i_102 = 0; i_102 < conto.npl; i_102++)
                {
                    float f_103 = 0.0F;
                    for(int i_104 = 0; i_104 < conto.p[i_102].n; i_104++)
                    {
                        if(conto.p[i_102].wz != 0 || py(conto.keyx[i], conto.p[i_102].ox[i_104], conto.keyz[i], conto.p[i_102].oz[i_104]) >= cd.clrad[cn])
                            continue;
                        f_103 = (f / 20F) * m.random();
                        conto.p[i_102].oz[i_104] += f_103 * m.sin(i_100);
                        conto.p[i_102].ox[i_104] -= f_103 * m.sin(i_101);
                        if(bool)
                        {
                            hitmag += Math.abs(f_103);
                            i_97 = (int)((float)i_97 + Math.abs(f_103));
                        }
                    }

                    if(f_103 == 0.0F)
                        continue;
                    if(Math.abs(f_103) >= 1.0F)
                    {
                        conto.p[i_102].chip = 1;
                        conto.p[i_102].ctmag = f_103;
                    }
                    if(!conto.p[i_102].nocol && conto.p[i_102].glass != 1)
                    {
                        if(conto.p[i_102].bfase > 20 && (double)conto.p[i_102].hsb[1] > 0.25D)
                            conto.p[i_102].hsb[1] = 0.25F;
                        if(conto.p[i_102].bfase > 25 && (double)conto.p[i_102].hsb[2] > 0.69999999999999996D)
                            conto.p[i_102].hsb[2] = 0.7F;
                        if(conto.p[i_102].bfase > 30 && (double)conto.p[i_102].hsb[1] > 0.14999999999999999D)
                            conto.p[i_102].hsb[1] = 0.15F;
                        if(conto.p[i_102].bfase > 35 && (double)conto.p[i_102].hsb[2] > 0.59999999999999998D)
                            conto.p[i_102].hsb[2] = 0.6F;
                        if(conto.p[i_102].bfase > 40)
                            conto.p[i_102].hsb[0] = 0.075F;
                        if(conto.p[i_102].bfase > 50 && (double)conto.p[i_102].hsb[2] > 0.5D)
                            conto.p[i_102].hsb[2] = 0.5F;
                        if(conto.p[i_102].bfase > 60)
                            conto.p[i_102].hsb[0] = 0.05F;
                        conto.p[i_102].bfase += f_103;
                        new Color(conto.p[i_102].c[0], conto.p[i_102].c[1], conto.p[i_102].c[2]);
                        Color color = Color.getHSBColor(conto.p[i_102].hsb[0], conto.p[i_102].hsb[1], conto.p[i_102].hsb[2]);
                        conto.p[i_102].c[0] = color.getRed();
                        conto.p[i_102].c[1] = color.getGreen();
                        conto.p[i_102].c[2] = color.getBlue();
                    }
                    if(conto.p[i_102].glass == 1)
                        conto.p[i_102].gr += Math.abs((double)f_103 * 1.5D);
                }

            }
            if(i_99 * i_98 == -1)
                if(nbsq > 0)
                {
                    int i_105 = 0;
                    int i_106 = 1;
                    for(int i_107 = 0; i_107 < conto.npl; i_107++)
                    {
                        float f_108 = 0.0F;
                        for(int i_109 = 0; i_109 < conto.p[i_107].n; i_109++)
                        {
                            if(conto.p[i_107].wz != 0)
                                continue;
                            f_108 = (f / 15F) * m.random();
                            if(Math.abs(conto.p[i_107].oy[i_109] - cd.flipy[cn] - squash) >= cd.msquash[cn] * 3 && conto.p[i_107].oy[i_109] >= cd.flipy[cn] + squash || squash >= cd.msquash[cn])
                                continue;
                            conto.p[i_107].oy[i_109] += f_108;
                            i_105 = (int)((float)i_105 + f_108);
                            i_106++;
                            if(bool)
                            {
                                hitmag += Math.abs(f_108);
                                i_97 = (int)((float)i_97 + Math.abs(f_108));
                            }
                        }

                        if(conto.p[i_107].glass == 1)
                            conto.p[i_107].gr += 5;
                        else
                        if(f_108 != 0.0F)
                            conto.p[i_107].bfase += f_108;
                        if(Math.abs(f_108) >= 1.0F)
                        {
                            conto.p[i_107].chip = 1;
                            conto.p[i_107].ctmag = f_108;
                        }
                    }

                    squash += i_105 / i_106;
                    nbsq = 0;
                } else
                {
                    nbsq++;
                }
        }
        return i_97;
    }

    public int regx(int i, float f, ContO conto)
    {
        int i_110 = 0;
        boolean bool = true;
        if(xt.multion == 1 && xt.im != im)
            bool = false;
        if(xt.multion >= 2)
            bool = false;
        if(xt.lan && xt.multion >= 1 && xt.isbot[im])
            bool = true;
        f *= cd.dammult[cn];
        if(Math.abs(f) > 100F)
        {
            rpd.recx(i, f, im);
            if(f > 100F)
                f -= 100F;
            if(f < -100F)
                f += 100F;
            shakedam = (int)((Math.abs(f) + (float)shakedam) / 2.0F);
            if(im == xt.im || colidim)
                xt.crash(f, 0);
            for(int i_111 = 0; i_111 < conto.npl; i_111++)
            {
                float f_112 = 0.0F;
                for(int i_113 = 0; i_113 < conto.p[i_111].n; i_113++)
                {
                    if(conto.p[i_111].wz != 0 || py(conto.keyx[i], conto.p[i_111].ox[i_113], conto.keyz[i], conto.p[i_111].oz[i_113]) >= cd.clrad[cn])
                        continue;
                    f_112 = (f / 20F) * m.random();
                    conto.p[i_111].oz[i_113] -= f_112 * m.sin(conto.xz) * m.cos(conto.zy);
                    conto.p[i_111].ox[i_113] += f_112 * m.cos(conto.xz) * m.cos(conto.xy);
                    if(bool)
                    {
                        hitmag += Math.abs(f_112);
                        i_110 = (int)((float)i_110 + Math.abs(f_112));
                    }
                }

                if(f_112 == 0.0F)
                    continue;
                if(Math.abs(f_112) >= 1.0F)
                {
                    conto.p[i_111].chip = 1;
                    conto.p[i_111].ctmag = f_112;
                }
                if(!conto.p[i_111].nocol && conto.p[i_111].glass != 1)
                {
                    if(conto.p[i_111].bfase > 20 && (double)conto.p[i_111].hsb[1] > 0.25D)
                        conto.p[i_111].hsb[1] = 0.25F;
                    if(conto.p[i_111].bfase > 25 && (double)conto.p[i_111].hsb[2] > 0.69999999999999996D)
                        conto.p[i_111].hsb[2] = 0.7F;
                    if(conto.p[i_111].bfase > 30 && (double)conto.p[i_111].hsb[1] > 0.14999999999999999D)
                        conto.p[i_111].hsb[1] = 0.15F;
                    if(conto.p[i_111].bfase > 35 && (double)conto.p[i_111].hsb[2] > 0.59999999999999998D)
                        conto.p[i_111].hsb[2] = 0.6F;
                    if(conto.p[i_111].bfase > 40)
                        conto.p[i_111].hsb[0] = 0.075F;
                    if(conto.p[i_111].bfase > 50 && (double)conto.p[i_111].hsb[2] > 0.5D)
                        conto.p[i_111].hsb[2] = 0.5F;
                    if(conto.p[i_111].bfase > 60)
                        conto.p[i_111].hsb[0] = 0.05F;
                    conto.p[i_111].bfase += Math.abs(f_112);
                    new Color(conto.p[i_111].c[0], conto.p[i_111].c[1], conto.p[i_111].c[2]);
                    Color color = Color.getHSBColor(conto.p[i_111].hsb[0], conto.p[i_111].hsb[1], conto.p[i_111].hsb[2]);
                    conto.p[i_111].c[0] = color.getRed();
                    conto.p[i_111].c[1] = color.getGreen();
                    conto.p[i_111].c[2] = color.getBlue();
                }
                if(conto.p[i_111].glass == 1)
                    conto.p[i_111].gr += Math.abs((double)f_112 * 1.5D);
            }

        }
        return i_110;
    }

    public int regz(int i, float f, ContO conto)
    {
        int i_114 = 0;
        boolean bool = true;
        if(xt.multion == 1 && xt.im != im)
            bool = false;
        if(xt.multion >= 2)
            bool = false;
        if(xt.lan && xt.multion >= 1 && xt.isbot[im])
            bool = true;
        f *= cd.dammult[cn];
        if(Math.abs(f) > 100F)
        {
            rpd.recz(i, f, im);
            if(f > 100F)
                f -= 100F;
            if(f < -100F)
                f += 100F;
            shakedam = (int)((Math.abs(f) + (float)shakedam) / 2.0F);
            if(im == xt.im || colidim)
                xt.crash(f, 0);
            for(int i_115 = 0; i_115 < conto.npl; i_115++)
            {
                float f_116 = 0.0F;
                for(int i_117 = 0; i_117 < conto.p[i_115].n; i_117++)
                {
                    if(conto.p[i_115].wz != 0 || py(conto.keyx[i], conto.p[i_115].ox[i_117], conto.keyz[i], conto.p[i_115].oz[i_117]) >= cd.clrad[cn])
                        continue;
                    f_116 = (f / 20F) * m.random();
                    conto.p[i_115].oz[i_117] += f_116 * m.cos(conto.xz) * m.cos(conto.zy);
                    conto.p[i_115].ox[i_117] += f_116 * m.sin(conto.xz) * m.cos(conto.xy);
                    if(bool)
                    {
                        hitmag += Math.abs(f_116);
                        i_114 = (int)((float)i_114 + Math.abs(f_116));
                    }
                }

                if(f_116 == 0.0F)
                    continue;
                if(Math.abs(f_116) >= 1.0F)
                {
                    conto.p[i_115].chip = 1;
                    conto.p[i_115].ctmag = f_116;
                }
                if(!conto.p[i_115].nocol && conto.p[i_115].glass != 1)
                {
                    if(conto.p[i_115].bfase > 20 && (double)conto.p[i_115].hsb[1] > 0.25D)
                        conto.p[i_115].hsb[1] = 0.25F;
                    if(conto.p[i_115].bfase > 25 && (double)conto.p[i_115].hsb[2] > 0.69999999999999996D)
                        conto.p[i_115].hsb[2] = 0.7F;
                    if(conto.p[i_115].bfase > 30 && (double)conto.p[i_115].hsb[1] > 0.14999999999999999D)
                        conto.p[i_115].hsb[1] = 0.15F;
                    if(conto.p[i_115].bfase > 35 && (double)conto.p[i_115].hsb[2] > 0.59999999999999998D)
                        conto.p[i_115].hsb[2] = 0.6F;
                    if(conto.p[i_115].bfase > 40)
                        conto.p[i_115].hsb[0] = 0.075F;
                    if(conto.p[i_115].bfase > 50 && (double)conto.p[i_115].hsb[2] > 0.5D)
                        conto.p[i_115].hsb[2] = 0.5F;
                    if(conto.p[i_115].bfase > 60)
                        conto.p[i_115].hsb[0] = 0.05F;
                    conto.p[i_115].bfase += Math.abs(f_116);
                    new Color(conto.p[i_115].c[0], conto.p[i_115].c[1], conto.p[i_115].c[2]);
                    Color color = Color.getHSBColor(conto.p[i_115].hsb[0], conto.p[i_115].hsb[1], conto.p[i_115].hsb[2]);
                    conto.p[i_115].c[0] = color.getRed();
                    conto.p[i_115].c[1] = color.getGreen();
                    conto.p[i_115].c[2] = color.getBlue();
                }
                if(conto.p[i_115].glass == 1)
                    conto.p[i_115].gr += Math.abs((double)f_116 * 1.5D);
            }

        }
        return i_114;
    }

    public void colide(ContO conto, Mad mad_118, ContO conto_119)
    {
        float fs[] = new float[4];
        float fs_120[] = new float[4];
        float fs_121[] = new float[4];
        float fs_122[] = new float[4];
        float fs_123[] = new float[4];
        float fs_124[] = new float[4];
        int i;
        for(i = 0; i < 4; i++)
        {
            fs[i] = conto.x + conto.keyx[i];
            if(capsized)
                fs_120[i] = conto.y + cd.flipy[cn] + squash;
            else
                fs_120[i] = conto.y + conto.grat;
            fs_121[i] = conto.z + conto.keyz[i];
            fs_122[i] = conto_119.x + conto_119.keyx[i];
            if(capsized)
                fs_123[i] = conto_119.y + cd.flipy[mad_118.cn] + mad_118.squash;
            else
                fs_123[i] = conto_119.y + conto_119.grat;
            fs_124[i] = conto_119.z + conto_119.keyz[i];
        }

        rot(fs, fs_120, conto.x, conto.y, conto.xy, 4);
        rot(fs_120, fs_121, conto.y, conto.z, conto.zy, 4);
        rot(fs, fs_121, conto.x, conto.z, conto.xz, 4);
        rot(fs_122, fs_123, conto_119.x, conto_119.y, conto_119.xy, 4);
        rot(fs_123, fs_124, conto_119.y, conto_119.z, conto_119.zy, 4);
        rot(fs_122, fs_124, conto_119.x, conto_119.z, conto_119.xz, 4);
        if((double)rpy(conto.x, conto_119.x, conto.y, conto_119.y, conto.z, conto_119.z) < (double)(conto.maxR * conto.maxR + conto_119.maxR * conto_119.maxR) * 1.5D)
        {
            if(!caught[mad_118.im] && (speed != 0.0F || mad_118.speed != 0.0F))
            {
                if(Math.abs(power * speed * cd.moment[cn]) != Math.abs(mad_118.power * mad_118.speed * cd.moment[mad_118.cn]))
                {
                    if(Math.abs(power * speed * cd.moment[cn]) > Math.abs(mad_118.power * mad_118.speed * cd.moment[mad_118.cn]))
                        dominate[mad_118.im] = true;
                    else
                        dominate[mad_118.im] = false;
                } else
                if(cd.moment[cn] > cd.moment[mad_118.cn])
                    dominate[mad_118.im] = true;
                else
                    dominate[mad_118.im] = false;
                caught[mad_118.im] = true;
            }
        } else
        if(caught[mad_118.im])
            caught[mad_118.im] = false;
        i = 0;
        int i_125 = 0;
        if(dominate[mad_118.im])
        {
            int i_126 = (int)(((((((((scz[0] - mad_118.scz[0]) + scz[1]) - mad_118.scz[1]) + scz[2]) - mad_118.scz[2]) + scz[3]) - mad_118.scz[3]) * (((((((scz[0] - mad_118.scz[0]) + scz[1]) - mad_118.scz[1]) + scz[2]) - mad_118.scz[2]) + scz[3]) - mad_118.scz[3]) + (((((((scx[0] - mad_118.scx[0]) + scx[1]) - mad_118.scx[1]) + scx[2]) - mad_118.scx[2]) + scx[3]) - mad_118.scx[3]) * (((((((scx[0] - mad_118.scx[0]) + scx[1]) - mad_118.scx[1]) + scx[2]) - mad_118.scx[2]) + scx[3]) - mad_118.scx[3])) / 16F);
            int i_127 = 7000;
            float f = 1.0F;
            if(xt.multion != 0)
            {
                i_127 = 28000;
                f = 1.27F;
            }
            for(int i_128 = 0; i_128 < 4; i_128++)
            {
                for(int i_129 = 0; i_129 < 4; i_129++)
                {
                    if((float)rpy(fs[i_128], fs_122[i_129], fs_120[i_128], fs_123[i_129], fs_121[i_128], fs_124[i_129]) >= (float)(i_126 + i_127) * (cd.comprad[mad_118.cn] + cd.comprad[cn]))
                        continue;
                    if(Math.abs(scx[i_128] * cd.moment[cn]) > Math.abs(mad_118.scx[i_129] * cd.moment[mad_118.cn]))
                    {
                        float f_130 = mad_118.scx[i_129] * (float)cd.revpush[cn];
                        if(f_130 > 300F)
                            f_130 = 300F;
                        if(f_130 < -300F)
                            f_130 = -300F;
                        float f_131 = scx[i_128] * (float)cd.push[cn];
                        if(f_131 > 300F)
                            f_131 = 300F;
                        if(f_131 < -300F)
                            f_131 = -300F;
                        mad_118.scx[i_129] += f_131;
                        if(im == xt.im)
                            mad_118.colidim = true;
                        i += mad_118.regx(i_129, f_131 * cd.moment[cn] * f, conto_119);
                        if(mad_118.colidim)
                            mad_118.colidim = false;
                        scx[i_128] -= f_130;
                        i_125 += regx(i_128, -f_130 * cd.moment[cn] * f, conto);
                        scy[i_128] -= cd.revlift[cn];
                        if(im == xt.im)
                            mad_118.colidim = true;
                        i += mad_118.regy(i_129, cd.revlift[cn] * 7, conto_119);
                        if(mad_118.colidim)
                            mad_118.colidim = false;
                        if(m.random() > m.random())
                            conto_119.sprk((fs[i_128] + fs_122[i_129]) / 2.0F, (fs_120[i_128] + fs_123[i_129]) / 2.0F, (fs_121[i_128] + fs_124[i_129]) / 2.0F, (mad_118.scx[i_129] + scx[i_128]) / 4F, (mad_118.scy[i_129] + scy[i_128]) / 4F, (mad_118.scz[i_129] + scz[i_128]) / 4F, 2);
                    }
                    if(Math.abs(scz[i_128] * cd.moment[cn]) > Math.abs(mad_118.scz[i_129] * cd.moment[mad_118.cn]))
                    {
                        float f_132 = mad_118.scz[i_129] * (float)cd.revpush[cn];
                        if(f_132 > 300F)
                            f_132 = 300F;
                        if(f_132 < -300F)
                            f_132 = -300F;
                        float f_133 = scz[i_128] * (float)cd.push[cn];
                        if(f_133 > 300F)
                            f_133 = 300F;
                        if(f_133 < -300F)
                            f_133 = -300F;
                        mad_118.scz[i_129] += f_133;
                        if(im == xt.im)
                            mad_118.colidim = true;
                        i += mad_118.regz(i_129, f_133 * cd.moment[cn] * f, conto_119);
                        if(mad_118.colidim)
                            mad_118.colidim = false;
                        scz[i_128] -= f_132;
                        i_125 += regz(i_128, -f_132 * cd.moment[cn] * f, conto);
                        scy[i_128] -= cd.revlift[cn];
                        if(im == xt.im)
                            mad_118.colidim = true;
                        i += mad_118.regy(i_129, cd.revlift[cn] * 7, conto_119);
                        if(mad_118.colidim)
                            mad_118.colidim = false;
                        if(m.random() > m.random())
                            conto_119.sprk((fs[i_128] + fs_122[i_129]) / 2.0F, (fs_120[i_128] + fs_123[i_129]) / 2.0F, (fs_121[i_128] + fs_124[i_129]) / 2.0F, (mad_118.scx[i_129] + scx[i_128]) / 4F, (mad_118.scy[i_129] + scy[i_128]) / 4F, (mad_118.scz[i_129] + scz[i_128]) / 4F, 2);
                    }
                    if(im == xt.im)
                        mad_118.lastcolido = 70;
                    if(mad_118.im == xt.im)
                        lastcolido = 70;
                    mad_118.scy[i_129] -= cd.lift[cn];
                }

            }

        }
        if(xt.multion == 1)
        {
            if(mad_118.im == xt.im && i != 0)
                xt.dcrashes[im] += i;
            if(im == xt.im && i_125 != 0)
                xt.dcrashes[mad_118.im] += i_125;
        }
    }

    public void rot(float fs[], float fs_134[], int i, int i_135, int i_136, int i_137)
    {
        if(i_136 != 0)
        {
            for(int i_138 = 0; i_138 < i_137; i_138++)
            {
                float f = fs[i_138];
                float f_139 = fs_134[i_138];
                fs[i_138] = (float)i + ((f - (float)i) * m.cos(i_136) - (f_139 - (float)i_135) * m.sin(i_136));
                fs_134[i_138] = (float)i_135 + ((f - (float)i) * m.sin(i_136) + (f_139 - (float)i_135) * m.cos(i_136));
            }

        }
    }

    public int rpy(float f, float f_140, float f_141, float f_142, float f_143, float f_144)
    {
        return (int)((f - f_140) * (f - f_140) + (f_141 - f_142) * (f_141 - f_142) + (f_143 - f_144) * (f_143 - f_144));
    }

    public int py(int i, int i_145, int i_146, int i_147)
    {
        return (i - i_145) * (i - i_145) + (i_146 - i_147) * (i_146 - i_147);
    }

    Medium m;
    Record rpd;
    xtGraphics xt;
    int cn;
    int im;
    int mxz;
    int cxz;
    CarDefine cd;
    boolean dominate[];
    boolean caught[];
    int pzy;
    int pxy;
    float speed;
    float forca;
    float scy[];
    float scz[];
    float scx[];
    float drag;
    boolean mtouch;
    boolean wtouch;
    int cntouch;
    boolean capsized;
    int txz;
    int fxz;
    int pmlt;
    int nmlt;
    int dcnt;
    int skid;
    boolean pushed;
    boolean gtouch;
    boolean pl;
    boolean pr;
    boolean pd;
    boolean pu;
    int loop;
    float ucomp;
    float dcomp;
    float lcomp;
    float rcomp;
    int lxz;
    int travxy;
    int travzy;
    int travxz;
    int trcnt;
    int capcnt;
    int srfcnt;
    boolean rtab;
    boolean ftab;
    boolean btab;
    boolean surfer;
    float powerup;
    int xtpower;
    float tilt;
    int crank[][];
    int lcrank[][];
    int squash;
    int nbsq;
    int hitmag;
    int cntdest;
    boolean dest;
    boolean newcar;
    int pan;
    int pcleared;
    int clear;
    int nlaps;
    int focus;
    float power;
    int missedcp;
    int lastcolido;
    int point;
    boolean nofocus;
    int rpdcatch;
    int newedcar;
    int fixes;
    int shakedam;
    int outshakedam;
    boolean colidim;
}
