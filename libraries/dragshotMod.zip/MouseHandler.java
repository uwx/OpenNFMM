// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MouseHandler.java

import java.awt.PopupMenu;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

class MouseHandler extends MouseAdapter
{

    public MouseHandler(PopupMenu popupmenu, int i)
    {
        popupMenu = popupmenu;
        id = i;
    }

    public void mousePressed(MouseEvent mouseevent)
    {
        if(mouseevent.isPopupTrigger())
        {
            popupMenu.show(mouseevent.getComponent(), mouseevent.getX(), mouseevent.getY());
            Madness.textid = id;
            mouseevent.consume();
        }
    }

    public void mouseReleased(MouseEvent mouseevent)
    {
        if(mouseevent.isPopupTrigger())
        {
            popupMenu.show(mouseevent.getComponent(), mouseevent.getX(), mouseevent.getY());
            Madness.textid = id;
            mouseevent.consume();
        }
    }

    private PopupMenu popupMenu;
    int id;
}
