// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   soundClip.java

import java.io.*;
import javax.sound.sampled.*;

public class soundClip
{

    public soundClip(byte is[])
    {
        clip = null;
        loaded = false;
        lfrpo = -1;
        cntcheck = 0;
        try
        {
            ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(is);
            sound = AudioSystem.getAudioInputStream(bytearrayinputstream);
            sound.mark(is.length);
            if(winPC)
            {
                clip = AudioSystem.getClip();
            } else
            {
                javax.sound.sampled.DataLine.Info info = new javax.sound.sampled.DataLine.Info(javax/sound/sampled/Clip, sound.getFormat());
                clip = (Clip)AudioSystem.getLine(info);
            }
            loaded = true;
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Loading Clip error: ").append(exception).toString());
            loaded = false;
        }
    }

    public soundClip(String internalLocation)
    {
        clip = null;
        loaded = false;
        lfrpo = -1;
        cntcheck = 0;
        try
        {
            InputStream in = getClass().getResourceAsStream(internalLocation);
            sound = AudioSystem.getAudioInputStream(in);
            sound.mark(in.available());
            clip = AudioSystem.getClip();
            loaded = true;
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Loading Clip error: ").append(exception).toString());
            loaded = false;
        }
    }

    public void play()
    {
        if(loaded)
            try
            {
                if(!clip.isOpen())
                {
                    try
                    {
                        clip.open(sound);
                    }
                    catch(Exception exception) { }
                    clip.loop(0);
                } else
                {
                    clip.loop(1);
                }
                lfrpo = -1;
                cntcheck = 5;
            }
            catch(Exception exception) { }
    }

    public void loop()
    {
        if(loaded)
            try
            {
                if(!clip.isOpen())
                    try
                    {
                        clip.open(sound);
                    }
                    catch(Exception exception) { }
                clip.loop(70);
                lfrpo = -2;
                cntcheck = 0;
            }
            catch(Exception exception) { }
    }

    public void stop()
    {
        if(loaded)
            try
            {
                clip.stop();
                lfrpo = -1;
            }
            catch(Exception exception) { }
    }

    public void checkopen()
    {
        if(loaded && clip.isOpen() && lfrpo != -2)
            if(cntcheck == 0)
            {
                int i = clip.getFramePosition();
                if(lfrpo == i && !clip.isRunning())
                {
                    try
                    {
                        clip.close();
                        sound.reset();
                    }
                    catch(Exception exception) { }
                    lfrpo = -1;
                } else
                {
                    lfrpo = i;
                }
            } else
            {
                cntcheck--;
            }
    }

    static boolean winPC = System.getProperty("os.name").toLowerCase().startsWith("windows");
    Clip clip;
    AudioInputStream sound;
    boolean loaded;
    int lfrpo;
    int cntcheck;

}
