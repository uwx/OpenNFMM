// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GameSparker.java

import java.applet.Applet;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class GameSparker extends Applet
    implements Runnable
{

    public GameSparker()
    {
        mload = 1;
        exwist = false;
        apx = 0;
        apy = 0;
        apmult = 1.0F;
        reqmult = 0.0F;
        smooth = 1;
        moto = 1;
        lastw = 0;
        lasth = 0;
        onbar = false;
        oncarm = false;
        onstgm = false;
        onfulls = false;
        chkbx = new Image[2];
        carmaker = new Image[2];
        stagemaker = new Image[2];
        showsize = 0;
        u = new Control[8];
        mouses = 0;
        xm = 0;
        ym = 0;
        mousew = 0;
        lostfcs = false;
        moused = false;
        fcscnt = 0;
        nob = 0;
        notb = 0;
        view = 0;
        mvect = 100;
        lmxz = 0;
        shaka = 0;
        applejava = false;
        openm = false;
        sgame = new Smenu(9);
        wgame = new Smenu(4);
        warb = new Smenu(102);
        pgame = new Smenu(11);
        vnpls = new Smenu(5);
        vtyp = new Smenu(6);
        snfmm = new Smenu(12);
        snfm1 = new Smenu(12);
        snfm2 = new Smenu(19);
        mstgs = new Smenu(707);
        mcars = new Smenu(707);
        slaps = new Smenu(17);
        snpls = new Smenu(9);
        snbts = new Smenu(8);
        swait = new Smenu(6);
        sclass = new Smenu(7);
        scars = new Smenu(4);
        sfix = new Smenu(7);
        gmode = new Smenu(3);
        rooms = new Smenu(7);
        sendtyp = new Smenu(6);
        senditem = new Smenu(707);
        clanlev = new Smenu(8);
        clcars = new Smenu(707);
        datat = new Smenu(26);
        ilaps = new Smenu(18);
        icars = new Smenu(5);
    }

    public void run()
    {
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 800, 450);
        repaint();
        requestFocus();
        if(System.getProperty("java.vendor").toLowerCase().indexOf("apple") != -1)
            applejava = true;
        Medium medium = new Medium();
        Trackers trackers = new Trackers();
        CheckPoints checkpoints = new CheckPoints();
        ContO contos[] = new ContO[124];
        CarDefine cardefine = new CarDefine(contos, medium, trackers, this);
        xtGraphics xt = new xtGraphics(medium, cardefine, rd, this);
        sizebar = xt.getImage("data/sizebar.gif");
        blb = xt.getImage("data/b.gif");
        fulls = xt.getImage("data/fullscreen.gif");
        chkbx[0] = xt.getImage("data/checkbox1.gif");
        chkbx[1] = xt.getImage("data/checkbox2.gif");
        carmaker[0] = xt.getImage("data/carmaker1.gif");
        carmaker[1] = xt.getImage("data/carmaker2.gif");
        stagemaker[0] = xt.getImage("data/stagemaker1.gif");
        stagemaker[1] = xt.getImage("data/stagemaker2.gif");
        xt.loaddata();
        Login login = null;
        Lobby lobby = null;
        Globe globe = null;
        boolean bool = false;
        UDPMistro udpmistro = new UDPMistro();
        Record record = new Record(medium);
        loadbase(contos, medium, trackers, xt, false);
        ContO contos_0[] = new ContO[610];
        Mad mads[] = new Mad[8];
        for(int i = 0; i < 8; i++)
        {
            mads[i] = new Mad(cardefine, medium, record, xt, i);
            u[i] = new Control(medium);
        }

        float f = 47F;
        readcookies(xt, cardefine, contos);
        xt.testdrive = Madness.testdrive;
        if(xt.testdrive != 0)
            if(xt.testdrive <= 2)
            {
                xt.sc[0] = cardefine.loadcar(Madness.testcar, 16);
                if(xt.sc[0] != -1)
                {
                    xt.fase = -9;
                } else
                {
                    Madness.testcar = "Failx12";
                    Madness.carmaker();
                }
            } else
            {
                checkpoints.name = Madness.testcar;
                xt.fase = -9;
            }
        xt.stoploading();
        requestFocus();
        if(xt.testdrive == 0 && xt.firstime)
            setupini();
        System.gc();
        Date date = new Date();
        long l = 0L;
        long l_1 = date.getTime();
        float f_2 = 30F;
        boolean bool_3 = false;
        int i = 30;
        int i_4 = 530;
        int i_5 = 0;
        int i_6 = 0;
        int i_7 = 0;
        int i_8 = 0;
        int i_9 = 0;
        boolean bool_10 = false;
        long lastsec = 0L;
        int fps = 0;
        double fpsav = 21D;
        do
        {
            date = new Date();
            long l_11 = date.getTime();
            if(xt.fase == 111)
            {
                if(mouses == 1)
                    i_7 = 800;
                if(i_7 < 800)
                {
                    xt.clicknow();
                    i_7++;
                } else
                {
                    i_7 = 0;
                    if(!exwist)
                        xt.fase = 9;
                    mouses = 0;
                    lostfcs = false;
                }
            }
            if(xt.fase == 9)
                if(i_7 < 76)
                {
                    xt.rad(i_7);
                    catchlink();
                    if(mouses == 2)
                        mouses = 0;
                    if(mouses == 1)
                        mouses = 2;
                    i_7++;
                } else
                {
                    i_7 = 0;
                    xt.fase = 10;
                    mouses = 0;
                    u[0].falseo(0);
                }
            if(xt.fase == -9)
            {
                if(xt.loadedt)
                {
                    xt.mainbg(-101);
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(0, 0, 800, 450);
                    repaint();
                    xt.strack.unload();
                    xt.strack = null;
                    xt.flexpix = null;
                    xt.fleximg = null;
                    System.gc();
                    xt.loadedt = false;
                }
                if(i_7 < 2)
                {
                    xt.mainbg(-101);
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(65, 25, 670, 400);
                    i_7++;
                } else
                {
                    checkmemory(xt);
                    xt.inishcarselect(contos);
                    i_7 = 0;
                    xt.fase = 7;
                    mvect = 50;
                    mouses = 0;
                }
            }
            if(xt.fase == 8)
            {
                xt.credits(u[0], xm, ym, mouses);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(xt.flipo <= 100)
                    catchlink();
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == 10)
            {
                mvect = 100;
                xt.maini(u[0]);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == 102)
            {
                mvect = 100;
                if(xt.loadedt)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(0, 0, 800, 450);
                    repaint();
                    checkmemory(xt);
                    xt.strack.unload();
                    xt.strack = null;
                    xt.flexpix = null;
                    xt.fleximg = null;
                    System.gc();
                    xt.loadedt = false;
                }
                if(xt.testdrive == 1 || xt.testdrive == 2)
                    Madness.carmaker();
                if(xt.testdrive == 3 || xt.testdrive == 4)
                    Madness.stagemaker();
                xt.maini2(u[0], xm, ym, mouses);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == -22)
            {
                checkpoints.name = Madness.testcar;
                checkpoints.stage = -1;
                loadstage(contos_0, contos, medium, trackers, checkpoints, xt, mads, record);
                if(checkpoints.stage == -3)
                {
                    Madness.testcar = "Failx12";
                    Madness.stagemaker();
                }
            }
            if(xt.fase == 11)
            {
                xt.inst(u[0]);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == -5)
            {
                mvect = 100;
                xt.finish(checkpoints, contos, u[0], xm, ym, moused);
                drawms();
                if(!openm)
                    xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == 7)
            {
                xt.carselect(u[0], contos, mads[0], xm, ym, moused);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
                drawms();
            }
            if(xt.fase == 6)
            {
                xt.musicomp(checkpoints.stage, u[0]);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == 5)
            {
                mvect = 100;
                xt.loadmusic(checkpoints.stage, checkpoints.trackname, checkpoints.trackvol);
            }
            if(xt.fase == 4)
            {
                xt.cantgo(u[0]);
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == 3)
            {
                rd.setColor(new Color(0, 0, 0));
                rd.fillRect(65, 25, 670, 400);
                repaint();
                xt.inishstageselect(checkpoints);
            }
            if(xt.fase == 2)
            {
                mvect = 100;
                xt.loadingstage(checkpoints.stage, true);
                checkpoints.nfix = 0;
                checkpoints.notb = false;
                loadstage(contos_0, contos, medium, trackers, checkpoints, xt, mads, record);
                u[0].falseo(0);
                udpmistro.freg = 0.0F;
                mvect = 20;
            }
            if(xt.fase == 1)
            {
                xt.trackbg(false);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                if(checkpoints.stage != -3)
                {
                    medium.aroundtrack(checkpoints);
                    if(medium.hit == 5000 && mvect < 40)
                        mvect++;
                    int i_12 = 0;
                    int is[] = new int[200];
                    for(int i_13 = xt.nplayers; i_13 < notb; i_13++)
                        if(contos_0[i_13].dist != 0)
                        {
                            is[i_12] = i_13;
                            i_12++;
                        } else
                        {
                            contos_0[i_13].d(rd);
                        }

                    int is_14[] = new int[i_12];
                    for(int i_15 = 0; i_15 < i_12; i_15++)
                        is_14[i_15] = 0;

                    for(int i_16 = 0; i_16 < i_12; i_16++)
                    {
                        for(int i_17 = i_16 + 1; i_17 < i_12; i_17++)
                        {
                            if(contos_0[is[i_16]].dist != contos_0[is[i_17]].dist)
                            {
                                if(contos_0[is[i_16]].dist < contos_0[is[i_17]].dist)
                                    is_14[i_16]++;
                                else
                                    is_14[i_17]++;
                                continue;
                            }
                            if(i_17 > i_16)
                                is_14[i_16]++;
                            else
                                is_14[i_17]++;
                        }

                    }

                    for(int i_18 = 0; i_18 < i_12; i_18++)
                    {
                        for(int i_19 = 0; i_19 < i_12; i_19++)
                            if(is_14[i_19] == i_18)
                                contos_0[is[i_19]].d(rd);

                    }

                }
                if(!openm)
                    xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                xt.stageselect(checkpoints, u[0], xm, ym, moused);
                drawms();
            }
            if(xt.fase == 1177)
            {
                if(xt.loadedt)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(0, 0, 800, 450);
                    repaint();
                    checkmemory(xt);
                    xt.strack.unload();
                    xt.strack = null;
                    xt.flexpix = null;
                    xt.fleximg = null;
                    System.gc();
                    xt.loadedt = false;
                }
                mvect = 100;
                if(!bool)
                {
                    xt.intertrack.unloadimod();
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(65, 25, 670, 400);
                    if(mload > 0)
                        rd.drawImage(xt.mload, 259, 195, this);
                    repaint();
                    if(mload == 2)
                    {
                        cardefine.loadready();
                        loadbase(contos, medium, trackers, xt, true);
                        readcookies(xt, cardefine, contos);
                        mload = -1;
                    }
                    System.gc();
                    login = new Login(medium, rd, xt, this);
                    globe = new Globe(rd, xt, medium, login, cardefine, checkpoints, contos, contos_0, this);
                    lobby = new Lobby(medium, rd, login, globe, xt, cardefine, this);
                    bool = true;
                }
                if(login.fase != 18)
                {
                    boolean bool_20 = false;
                    if(login.fase == 0)
                        login.inishmulti();
                    if(login.fase >= 1 && login.fase <= 11)
                        login.multistart(contos, xm, ym, moused);
                    if(login.fase >= 12 && login.fase <= 17)
                    {
                        if(globe.open != 452)
                            login.multimode(contos);
                        else
                            bool_20 = true;
                        globe.dome(0, xm, ym, moused, u[0]);
                    }
                    if(login.justlog)
                    {
                        if(!xt.clan.equals(""))
                            globe.itab = 2;
                        login.justlog = false;
                    }
                    if(!bool_20)
                    {
                        login.ctachm(xm, ym, mouses, u[0], lobby);
                        mvect = 50;
                    } else
                    {
                        drawms();
                        mvect = 100;
                    }
                    if(mouses == 1)
                        mouses = 11;
                    if(mouses <= -1)
                    {
                        mouses--;
                        if(mouses == -4)
                            mouses = 0;
                    }
                    if(mousew != 0)
                        if(mousew > 0)
                            mousew--;
                        else
                            mousew++;
                } else
                {
                    boolean bool_21 = false;
                    if(lobby.fase == 0)
                    {
                        lobby.inishlobby();
                        mvect = 100;
                    }
                    if(lobby.fase == 1)
                    {
                        if(globe.open >= 2 && globe.open < 452)
                            openm = true;
                        if(globe.open != 452)
                            lobby.lobby(xm, ym, moused, mousew, checkpoints, u[0], contos);
                        else
                            bool_21 = true;
                        globe.dome(lobby.conon, xm, ym, moused, u[0]);
                        if(lobby.loadstage > 0)
                        {
                            setCursor(new Cursor(3));
                            drawms();
                            repaint();
                            trackers.nt = 0;
                            if(loadstagePreview(lobby.loadstage, "", contos_0, contos, medium, checkpoints))
                            {
                                lobby.gstagename = checkpoints.name;
                                lobby.gstagelaps = checkpoints.nlaps;
                                lobby.loadstage = -lobby.loadstage;
                            } else
                            {
                                lobby.loadstage = 0;
                                checkpoints.name = "";
                            }
                            setCursor(new Cursor(0));
                        }
                        if(lobby.msload != 0)
                        {
                            setCursor(new Cursor(3));
                            drawms();
                            repaint();
                            if(lobby.msload == 1)
                                cardefine.loadmystages(checkpoints);
                            if(lobby.msload == 7)
                                cardefine.loadclanstages(xt.clan);
                            if(lobby.msload == 3 || lobby.msload == 4)
                                cardefine.loadtop20(lobby.msload);
                            lobby.msload = 0;
                            setCursor(new Cursor(0));
                        }
                    }
                    if(lobby.fase == 3)
                    {
                        xt.trackbg(false);
                        medium.trk = 0;
                        medium.focus_point = 400;
                        medium.crs = true;
                        medium.x = -335;
                        medium.y = 0;
                        medium.z = -50;
                        medium.xz = 0;
                        medium.zy = 20;
                        medium.ground = -2000;
                        lobby.fase = 1;
                    }
                    if(lobby.fase == 4)
                    {
                        xt.trackbg(false);
                        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                        medium.aroundtrack(checkpoints);
                        int i_22 = 0;
                        int is[] = new int[200];
                        for(int i_23 = 0; i_23 < nob; i_23++)
                            if(contos_0[i_23].dist != 0)
                            {
                                is[i_22] = i_23;
                                i_22++;
                            } else
                            {
                                contos_0[i_23].d(rd);
                            }

                        int is_24[] = new int[i_22];
                        for(int i_25 = 0; i_25 < i_22; i_25++)
                            is_24[i_25] = 0;

                        for(int i_26 = 0; i_26 < i_22; i_26++)
                        {
                            for(int i_27 = i_26 + 1; i_27 < i_22; i_27++)
                            {
                                if(contos_0[is[i_26]].dist != contos_0[is[i_27]].dist)
                                {
                                    if(contos_0[is[i_26]].dist < contos_0[is[i_27]].dist)
                                        is_24[i_26]++;
                                    else
                                        is_24[i_27]++;
                                    continue;
                                }
                                if(i_27 > i_26)
                                    is_24[i_26]++;
                                else
                                    is_24[i_27]++;
                            }

                        }

                        for(int i_28 = 0; i_28 < i_22; i_28++)
                        {
                            for(int i_29 = 0; i_29 < i_22; i_29++)
                                if(is_24[i_29] == i_28)
                                    contos_0[is[i_29]].d(rd);

                        }

                        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        lobby.stageselect(checkpoints, u[0], xm, ym, moused);
                    }
                    if(lobby.fase == 2)
                    {
                        int i_30 = 0;
                        for(int i_31 = 0; i_31 < lobby.ngm; i_31++)
                            if(lobby.ongame == lobby.gnum[i_31])
                                i_30 = i_31;

                        boolean bool_32 = false;
                        if(lobby.gstgn[i_30] > 0)
                        {
                            if(lobby.gstgn[i_30] == -lobby.loadstage)
                                bool_32 = true;
                        } else
                        if(lobby.gstages[i_30].equals(checkpoints.name))
                            bool_32 = true;
                        if(bool_32)
                        {
                            lobby.fase = 4;
                            lobby.addstage = 0;
                        } else
                        {
                            xt.loadingstage(lobby.gstgn[i_30], false);
                            trackers.nt = 0;
                            if(loadstagePreview(lobby.gstgn[i_30], lobby.gstages[i_30], contos_0, contos, medium, checkpoints))
                            {
                                lobby.loadstage = -lobby.gstgn[i_30];
                                lobby.fase = 4;
                                lobby.addstage = 0;
                            } else
                            {
                                lobby.loadstage = 0;
                                checkpoints.name = "";
                                lobby.fase = 3;
                            }
                        }
                    }
                    if(lobby.fase == 76)
                    {
                        checkpoints.nlaps = lobby.laps;
                        checkpoints.stage = lobby.stage;
                        checkpoints.name = lobby.stagename;
                        checkpoints.nfix = lobby.nfix;
                        checkpoints.notb = lobby.notb;
                        xt.fase = 21;
                        u[0].multion = xt.multion;
                    }
                    if(globe.loadwbgames == 7)
                    {
                        repaint();
                        globe.redogame();
                    }
                    if(!openm)
                    {
                        if(!bool_21)
                            lobby.ctachm(xm, ym, mouses, u[0]);
                    } else
                    {
                        mouses = 0;
                    }
                    drawms();
                    if(lobby.fase == 1)
                        lobby.preforma(xm, ym);
                    if(lobby.loadwarb)
                    {
                        repaint();
                        globe.loadwarb();
                        lobby.loadwarb = false;
                    }
                    if(globe.loadwbgames == 1)
                    {
                        repaint();
                        globe.loadwgames();
                    }
                    if(mouses == 1)
                        mouses = 11;
                    if(mouses <= -1)
                    {
                        mouses--;
                        if(mouses == -4)
                            mouses = 0;
                    }
                    if(mousew != 0)
                    {
                        if(mousew > 0)
                            mousew--;
                        else
                            mousew++;
                        if(!lobby.zeromsw)
                            mousew = 0;
                    }
                }
            }
            if(xt.fase == 24)
            {
                login.endcons();
                login = null;
                lobby = null;
                globe = null;
                bool = false;
                System.gc();
                System.runFinalization();
                if(!xt.mtop)
                {
                    xt.fase = 102;
                    xt.opselect = 2;
                } else
                {
                    xt.fase = 10;
                    xt.opselect = 1;
                }
            }
            if(xt.fase == 23)
            {
                if(login.fase == 18)
                    xt.playingame = -101;
                login.stopallnow();
                lobby.stopallnow();
                globe.stopallnow();
                login = null;
                lobby = null;
                globe = null;
                hidefields();
                bool = false;
                System.gc();
                System.runFinalization();
                xt.fase = -9;
            }
            if(xt.fase == 22)
            {
                loadstage(contos_0, contos, medium, trackers, checkpoints, xt, mads, record);
                if(checkpoints.stage != -3)
                {
                    if(xt.lan && xt.im == 0)
                        udpmistro.UDPLanServer(xt.nplayers, xt.server, xt.servport, xt.playingame);
                    u[0].falseo(2);
                    requestFocus();
                } else
                {
                    xt.fase = 1177;
                }
            }
            if(xt.fase == 21)
            {
                login.endcons();
                login = null;
                lobby = null;
                globe = null;
                bool = false;
                System.gc();
                System.runFinalization();
                xt.fase = 22;
            }
            if(xt.fase == 0)
            {
                for(int i_33 = 0; i_33 < xt.nplayers; i_33++)
                    if(mads[i_33].newcar)
                    {
                        int i_34 = contos_0[i_33].xz;
                        int i_35 = contos_0[i_33].xy;
                        int i_36 = contos_0[i_33].zy;
                        contos_0[i_33] = new ContO(contos[mads[i_33].cn], contos_0[i_33].x, contos_0[i_33].y, contos_0[i_33].z, 0);
                        contos_0[i_33].xz = i_34;
                        contos_0[i_33].xy = i_35;
                        contos_0[i_33].zy = i_36;
                        mads[i_33].newcar = false;
                    }

                medium.d(rd);
                int i_37 = 0;
                int is[] = new int[200];
                for(int i_38 = 0; i_38 < nob; i_38++)
                    if(contos_0[i_38].dist != 0)
                    {
                        is[i_37] = i_38;
                        i_37++;
                    } else
                    {
                        contos_0[i_38].d(rd);
                    }

                int is_39[] = new int[i_37];
                int is_40[] = new int[i_37];
                for(int i_41 = 0; i_41 < i_37; i_41++)
                    is_39[i_41] = 0;

                for(int i_42 = 0; i_42 < i_37; i_42++)
                {
                    for(int i_43 = i_42 + 1; i_43 < i_37; i_43++)
                        if(contos_0[is[i_42]].dist < contos_0[is[i_43]].dist)
                            is_39[i_42]++;
                        else
                            is_39[i_43]++;

                    is_40[is_39[i_42]] = i_42;
                }

                for(int i_44 = 0; i_44 < i_37; i_44++)
                    contos_0[is[is_40[i_44]]].d(rd);

                if(xt.starcnt == 0)
                {
                    for(int i_45 = 0; i_45 < xt.nplayers; i_45++)
                    {
                        for(int i_46 = 0; i_46 < xt.nplayers; i_46++)
                            if(i_46 != i_45)
                                mads[i_45].colide(contos_0[i_45], mads[i_46], contos_0[i_46]);

                    }

                    for(int i_47 = 0; i_47 < xt.nplayers; i_47++)
                        mads[i_47].drive(u[i_47], contos_0[i_47], trackers, checkpoints);

                    for(int i_48 = 0; i_48 < xt.nplayers; i_48++)
                        record.rec(contos_0[i_48], i_48, mads[i_48].squash, mads[i_48].lastcolido, mads[i_48].cntdest, 0);

                    checkpoints.checkstat(mads, contos_0, record, xt.nplayers, xt.im, 0);
                    for(int i_49 = 1; i_49 < xt.nplayers; i_49++)
                        u[i_49].preform(mads[i_49], contos_0[i_49], checkpoints, trackers);

                    if(!xt.chrono.running && xt.nplayers == 1 && !xt.holdit && xt.chrono.ready)
                        xt.chrono.start();
                } else
                {
                    if(xt.starcnt == 130)
                    {
                        medium.adv = 1900;
                        medium.zy = 40;
                        medium.vxz = 70;
                        rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(0, 0, 800, 450);
                    }
                    if(xt.starcnt != 0)
                        xt.starcnt--;
                }
                if(xt.starcnt < 38)
                {
                    if(view == 0)
                    {
                        medium.follow(contos_0[0], mads[0].cxz, u[0].lookback);
                        xt.stat(mads[0], contos_0[0], checkpoints, u[0], true, xm, ym);
                        if(mads[0].outshakedam > 0)
                        {
                            shaka = mads[0].outshakedam / 20;
                            if(shaka > 25)
                                shaka = 25;
                        }
                        mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                        if(mvect > 90)
                            mvect = 90;
                        lmxz = medium.xz;
                    }
                    if(view == 1)
                    {
                        medium.around(contos_0[0], false);
                        xt.stat(mads[0], contos_0[0], checkpoints, u[0], false, xm, ym);
                        mvect = 80;
                    }
                    if(view == 2)
                    {
                        medium.watch(contos_0[0], mads[0].mxz);
                        xt.stat(mads[0], contos_0[0], checkpoints, u[0], false, xm, ym);
                        mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                        if(mvect > 90)
                            mvect = 90;
                        lmxz = medium.xz;
                    }
                    if(mouses == 1)
                    {
                        u[0].enter = true;
                        mouses = 0;
                    }
                } else
                {
                    int i_50 = 3;
                    if(xt.nplayers == 1)
                        i_50 = 0;
                    medium.around(contos_0[i_50], true);
                    mvect = 80;
                    if(u[0].enter || u[0].handb)
                    {
                        xt.starcnt = 38;
                        u[0].enter = false;
                        u[0].handb = false;
                    }
                    if(xt.starcnt == 38)
                    {
                        mouses = 0;
                        medium.vert = false;
                        medium.adv = 900;
                        medium.vxz = 180;
                        checkpoints.checkstat(mads, contos_0, record, xt.nplayers, xt.im, 0);
                        medium.follow(contos_0[0], mads[0].cxz, 0);
                        xt.stat(mads[0], contos_0[0], checkpoints, u[0], true, xm, ym);
                        rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(0, 0, 800, 450);
                    }
                }
            }
            if(xt.fase == 7001)
            {
                for(int i_51 = 0; i_51 < xt.nplayers; i_51++)
                    if(mads[i_51].newedcar == 0 && mads[i_51].newcar)
                    {
                        int i_52 = contos_0[i_51].xz;
                        int i_53 = contos_0[i_51].xy;
                        int i_54 = contos_0[i_51].zy;
                        xt.colorCar(contos[mads[i_51].cn], i_51);
                        contos_0[i_51] = new ContO(contos[mads[i_51].cn], contos_0[i_51].x, contos_0[i_51].y, contos_0[i_51].z, 0);
                        contos_0[i_51].xz = i_52;
                        contos_0[i_51].xy = i_53;
                        contos_0[i_51].zy = i_54;
                        mads[i_51].newedcar = 20;
                    }

                medium.d(rd);
                int i_55 = 0;
                int is[] = new int[200];
                for(int i_56 = 0; i_56 < nob; i_56++)
                    if(contos_0[i_56].dist != 0)
                    {
                        is[i_55] = i_56;
                        i_55++;
                    } else
                    {
                        contos_0[i_56].d(rd);
                    }

                int is_57[] = new int[i_55];
                int is_58[] = new int[i_55];
                for(int i_59 = 0; i_59 < i_55; i_59++)
                    is_57[i_59] = 0;

                for(int i_60 = 0; i_60 < i_55; i_60++)
                {
                    for(int i_61 = i_60 + 1; i_61 < i_55; i_61++)
                        if(contos_0[is[i_60]].dist < contos_0[is[i_61]].dist)
                            is_57[i_60]++;
                        else
                            is_57[i_61]++;

                    is_58[is_57[i_60]] = i_60;
                }

                for(int i_62 = 0; i_62 < i_55; i_62++)
                {
                    if(is[is_58[i_62]] < xt.nplayers && is[is_58[i_62]] != xt.im)
                        udpmistro.readContOinfo(contos_0[is[is_58[i_62]]], is[is_58[i_62]]);
                    contos_0[is[is_58[i_62]]].d(rd);
                }

                if(xt.starcnt == 0)
                {
                    if(xt.multion == 1)
                    {
                        int i_63 = 1;
                        for(int i_64 = 0; i_64 < xt.nplayers; i_64++)
                            if(xt.im != i_64)
                            {
                                udpmistro.readinfo(mads[i_64], contos_0[i_64], u[i_63], i_64, checkpoints.dested);
                                i_63++;
                            }

                    } else
                    {
                        for(int i_65 = 0; i_65 < xt.nplayers; i_65++)
                            udpmistro.readinfo(mads[i_65], contos_0[i_65], u[i_65], i_65, checkpoints.dested);

                    }
                    for(int i_66 = 0; i_66 < xt.nplayers; i_66++)
                    {
                        for(int i_67 = 0; i_67 < xt.nplayers; i_67++)
                            if(i_67 != i_66)
                                mads[i_66].colide(contos_0[i_66], mads[i_67], contos_0[i_67]);

                    }

                    if(xt.multion == 1)
                    {
                        int i_68 = 1;
                        for(int i_69 = 0; i_69 < xt.nplayers; i_69++)
                            if(xt.im != i_69)
                            {
                                mads[i_69].drive(u[i_68], contos_0[i_69], trackers, checkpoints);
                                i_68++;
                            } else
                            {
                                mads[i_69].drive(u[0], contos_0[i_69], trackers, checkpoints);
                            }

                        for(int i_70 = 0; i_70 < xt.nplayers; i_70++)
                            record.rec(contos_0[i_70], i_70, mads[i_70].squash, mads[i_70].lastcolido, mads[i_70].cntdest, xt.im);

                    } else
                    {
                        for(int i_71 = 0; i_71 < xt.nplayers; i_71++)
                            mads[i_71].drive(u[i_71], contos_0[i_71], trackers, checkpoints);

                    }
                    checkpoints.checkstat(mads, contos_0, record, xt.nplayers, xt.im, xt.multion);
                } else
                {
                    if(xt.starcnt == 130)
                    {
                        medium.adv = 1900;
                        medium.zy = 40;
                        medium.vxz = 70;
                        rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(0, 0, 800, 450);
                        repaint();
                        if(xt.lan)
                        {
                            udpmistro.UDPConnectLan(xt.localserver, xt.nplayers, xt.im);
                            if(xt.im == 0)
                                xt.setbots(udpmistro.isbot, udpmistro.frame);
                        } else
                        {
                            udpmistro.UDPConnectOnline(xt.server, xt.gameport, xt.nplayers, xt.im);
                        }
                        if(xt.multion >= 2)
                        {
                            xt.im = (int)(Math.random() * (double)xt.nplayers);
                            xt.starcnt = 0;
                        }
                    }
                    if(xt.starcnt == 50)
                        udpmistro.frame[udpmistro.im][0] = 0;
                    if(xt.starcnt != 39 && xt.starcnt != 0)
                        xt.starcnt--;
                    if(udpmistro.go && xt.starcnt >= 39)
                    {
                        xt.starcnt = 38;
                        if(xt.lan)
                        {
                            int i_72 = checkpoints.stage;
                            if(i_72 < 0)
                                i_72 = 33;
                            if(xt.loadedt)
                                xt.strack.play();
                        }
                    }
                }
                if(xt.lan && udpmistro.im == 0)
                {
                    for(int i_73 = 2; i_73 < xt.nplayers; i_73++)
                        if(udpmistro.isbot[i_73])
                        {
                            u[i_73].preform(mads[i_73], contos_0[i_73], checkpoints, trackers);
                            udpmistro.setinfo(mads[i_73], contos_0[i_73], u[i_73], checkpoints.pos[i_73], checkpoints.magperc[i_73], false, i_73);
                        }

                }
                if(xt.starcnt < 38)
                {
                    if(xt.multion == 1)
                    {
                        udpmistro.setinfo(mads[xt.im], contos_0[xt.im], u[0], checkpoints.pos[xt.im], checkpoints.magperc[xt.im], xt.holdit, xt.im);
                        if(view == 0)
                        {
                            medium.follow(contos_0[xt.im], mads[xt.im].cxz, u[0].lookback);
                            xt.stat(mads[xt.im], contos_0[xt.im], checkpoints, u[0], true, xm, ym);
                            if(mads[xt.im].outshakedam > 0)
                            {
                                shaka = mads[xt.im].outshakedam / 20;
                                if(shaka > 25)
                                    shaka = 25;
                            }
                            mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                            if(mvect > 90)
                                mvect = 90;
                            lmxz = medium.xz;
                        }
                        if(view == 1)
                        {
                            medium.around(contos_0[xt.im], false);
                            xt.stat(mads[xt.im], contos_0[xt.im], checkpoints, u[0], false, xm, ym);
                            mvect = 80;
                        }
                        if(view == 2)
                        {
                            medium.watch(contos_0[xt.im], mads[xt.im].mxz);
                            xt.stat(mads[xt.im], contos_0[xt.im], checkpoints, u[0], false, xm, ym);
                            mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                            if(mvect > 90)
                                mvect = 90;
                            lmxz = medium.xz;
                        }
                    } else
                    {
                        if(view == 0)
                        {
                            medium.getaround(contos_0[xt.im]);
                            mvect = 80;
                        }
                        if(view == 1)
                        {
                            medium.getfollow(contos_0[xt.im], mads[xt.im].cxz, u[0].lookback);
                            mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                            if(mvect > 90)
                                mvect = 90;
                            lmxz = medium.xz;
                        }
                        if(view == 2)
                        {
                            medium.watch(contos_0[xt.im], mads[xt.im].mxz);
                            mvect = 65 + (Math.abs(lmxz - medium.xz) / 5) * 100;
                            if(mvect > 90)
                                mvect = 90;
                            lmxz = medium.xz;
                        }
                        xt.stat(mads[xt.im], contos_0[xt.im], checkpoints, u[0], true, xm, ym);
                    }
                    if(mouses == 1)
                    {
                        if(xt.holdit && xt.exitm != 4 && xt.multion == 1)
                            u[0].enter = true;
                        mouses = 0;
                    }
                } else
                {
                    medium.around(contos_0[xt.im], true);
                    mvect = 80;
                    if(xt.starcnt == 39)
                        xt.waitenter();
                    if(xt.starcnt == 38)
                    {
                        xt.forstart = 0;
                        mouses = 0;
                        medium.vert = false;
                        medium.adv = 900;
                        medium.vxz = 180;
                        checkpoints.checkstat(mads, contos_0, record, xt.nplayers, xt.im, xt.multion);
                        medium.follow(contos_0[xt.im], mads[xt.im].cxz, 0);
                        xt.stat(mads[xt.im], contos_0[xt.im], checkpoints, u[0], true, xm, ym);
                        rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(0, 0, 800, 450);
                    }
                }
                xt.multistat(u[0], checkpoints, xm, ym, moused, udpmistro);
            }
            if(xt.fase == -1)
            {
                if(i_6 == 0)
                {
                    for(int i_74 = 0; i_74 < xt.nplayers; i_74++)
                    {
                        record.ocar[i_74] = new ContO(contos_0[i_74], 0, 0, 0, 0);
                        contos_0[i_74] = new ContO(record.car[0][i_74], 0, 0, 0, 0);
                    }

                }
                medium.d(rd);
                int i_75 = 0;
                int is[] = new int[100];
                for(int i_76 = 0; i_76 < nob; i_76++)
                    if(contos_0[i_76].dist != 0)
                    {
                        is[i_75] = i_76;
                        i_75++;
                    } else
                    {
                        contos_0[i_76].d(rd);
                    }

                int is_77[] = new int[i_75];
                for(int i_78 = 0; i_78 < i_75; i_78++)
                    is_77[i_78] = 0;

                for(int i_79 = 0; i_79 < i_75; i_79++)
                {
                    for(int i_80 = i_79 + 1; i_80 < i_75; i_80++)
                    {
                        if(contos_0[is[i_79]].dist != contos_0[is[i_80]].dist)
                        {
                            if(contos_0[is[i_79]].dist < contos_0[is[i_80]].dist)
                                is_77[i_79]++;
                            else
                                is_77[i_80]++;
                            continue;
                        }
                        if(i_80 > i_79)
                            is_77[i_79]++;
                        else
                            is_77[i_80]++;
                    }

                }

                for(int i_81 = 0; i_81 < i_75; i_81++)
                {
                    for(int i_82 = 0; i_82 < i_75; i_82++)
                        if(is_77[i_82] == i_81)
                            contos_0[is[i_82]].d(rd);

                }

                if(u[0].enter || u[0].handb || mouses == 1)
                {
                    i_6 = 299;
                    u[0].enter = false;
                    u[0].handb = false;
                    mouses = 0;
                }
                for(int i_83 = 0; i_83 < xt.nplayers; i_83++)
                {
                    if(record.fix[i_83] == i_6)
                        if(contos_0[i_83].dist == 0)
                            contos_0[i_83].fcnt = 8;
                        else
                            contos_0[i_83].fix = true;
                    if(contos_0[i_83].fcnt == 7 || contos_0[i_83].fcnt == 8)
                    {
                        contos_0[i_83] = new ContO(contos[mads[i_83].cn], 0, 0, 0, 0);
                        record.cntdest[i_83] = 0;
                    }
                    if(i_6 == 299)
                        contos_0[i_83] = new ContO(record.ocar[i_83], 0, 0, 0, 0);
                    record.play(contos_0[i_83], mads[i_83], i_83, i_6);
                }

                if(++i_6 == 300)
                {
                    i_6 = 0;
                    xt.fase = -6;
                } else
                {
                    xt.replyn();
                }
                medium.around(contos_0[0], false);
            }
            if(xt.fase == -2)
            {
                if(xt.multion >= 2)
                    record.hcaught = false;
                u[0].falseo(3);
                if(record.hcaught && record.wasted == 0 && record.whenwasted != 229 && (checkpoints.stage == 1 || checkpoints.stage == 2) && xt.looped != 0)
                    record.hcaught = false;
                if(record.hcaught)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(0, 0, 800, 450);
                    repaint();
                }
                if(xt.multion != 0)
                {
                    udpmistro.UDPquit();
                    xt.stopchat();
                    if(cmsg.isShowing())
                        cmsg.hide();
                    cmsg.setText("");
                    requestFocus();
                }
                if(record.hcaught)
                {
                    medium.vert = (double)medium.random() > 0.45000000000000001D;
                    medium.adv = (int)(900F * medium.random());
                    medium.vxz = (int)(360F * medium.random());
                    i_6 = 0;
                    xt.fase = -3;
                    i_7 = 0;
                    i_8 = 0;
                } else
                {
                    i_6 = -2;
                    xt.fase = -4;
                }
            }
            if(xt.fase == -3)
            {
                if(i_6 == 0)
                {
                    if(record.wasted == 0)
                    {
                        if(record.whenwasted == 229)
                        {
                            i_9 = 67;
                            medium.vxz += 90;
                        } else
                        {
                            i_9 = (int)(medium.random() * 4F);
                            if(i_9 == 1 || i_9 == 3)
                                i_9 = 69;
                            if(i_9 == 2 || i_9 == 4)
                                i_9 = 30;
                        }
                    } else
                    if(record.closefinish != 0 && i_8 != 0)
                        medium.vxz += 90;
                    for(int i_84 = 0; i_84 < xt.nplayers; i_84++)
                        contos_0[i_84] = new ContO(record.starcar[i_84], 0, 0, 0, 0);

                }
                medium.d(rd);
                int i_85 = 0;
                int is[] = new int[100];
                for(int i_86 = 0; i_86 < nob; i_86++)
                    if(contos_0[i_86].dist != 0)
                    {
                        is[i_85] = i_86;
                        i_85++;
                    } else
                    {
                        contos_0[i_86].d(rd);
                    }

                int is_87[] = new int[i_85];
                for(int i_88 = 0; i_88 < i_85; i_88++)
                    is_87[i_88] = 0;

                for(int i_89 = 0; i_89 < i_85; i_89++)
                {
                    for(int i_90 = i_89 + 1; i_90 < i_85; i_90++)
                    {
                        if(contos_0[is[i_89]].dist != contos_0[is[i_90]].dist)
                        {
                            if(contos_0[is[i_89]].dist < contos_0[is[i_90]].dist)
                                is_87[i_89]++;
                            else
                                is_87[i_90]++;
                            continue;
                        }
                        if(i_90 > i_89)
                            is_87[i_89]++;
                        else
                            is_87[i_90]++;
                    }

                }

                for(int i_91 = 0; i_91 < i_85; i_91++)
                {
                    for(int i_92 = 0; i_92 < i_85; i_92++)
                        if(is_87[i_92] == i_91)
                            contos_0[is[i_92]].d(rd);

                }

                for(int i_93 = 0; i_93 < xt.nplayers; i_93++)
                {
                    if(record.hfix[i_93] == i_6)
                        if(contos_0[i_93].dist == 0)
                            contos_0[i_93].fcnt = 8;
                        else
                            contos_0[i_93].fix = true;
                    if(contos_0[i_93].fcnt == 7 || contos_0[i_93].fcnt == 8)
                    {
                        contos_0[i_93] = new ContO(contos[mads[i_93].cn], 0, 0, 0, 0);
                        record.cntdest[i_93] = 0;
                    }
                    record.playh(contos_0[i_93], mads[i_93], i_93, i_6, xt.im);
                }

                if(i_8 == 2 && i_6 == 299)
                    u[0].enter = true;
                if(u[0].enter || u[0].handb)
                {
                    xt.fase = -4;
                    u[0].enter = false;
                    u[0].handb = false;
                    i_6 = -7;
                } else
                {
                    xt.levelhigh(record.wasted, record.whenwasted, record.closefinish, i_6, checkpoints.stage);
                    if(i_6 == 0 || i_6 == 1 || i_6 == 2)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.fillRect(0, 0, 800, 450);
                    }
                    if(record.wasted != xt.im)
                    {
                        if(record.closefinish == 0)
                        {
                            if(i_7 == 9 || i_7 == 11)
                            {
                                rd.setColor(new Color(255, 255, 255));
                                rd.fillRect(0, 0, 800, 450);
                            }
                            if(i_7 == 0)
                                medium.around(contos_0[xt.im], false);
                            if(i_7 > 0 && i_7 < 20)
                                medium.transaround(contos_0[xt.im], contos_0[record.wasted], i_7);
                            if(i_7 == 20)
                                medium.around(contos_0[record.wasted], false);
                            if(i_6 > record.whenwasted && i_7 != 20)
                                i_7++;
                            if((i_7 == 0 || i_7 == 20) && ++i_6 == 300)
                            {
                                i_6 = 0;
                                i_7 = 0;
                                i_8++;
                            }
                        } else
                        if(record.closefinish == 1)
                        {
                            if(i_7 == 0)
                                medium.around(contos_0[xt.im], false);
                            if(i_7 > 0 && i_7 < 20)
                                medium.transaround(contos_0[xt.im], contos_0[record.wasted], i_7);
                            if(i_7 == 20)
                                medium.around(contos_0[record.wasted], false);
                            if(i_7 > 20 && i_7 < 40)
                                medium.transaround(contos_0[record.wasted], contos_0[xt.im], i_7 - 20);
                            if(i_7 == 40)
                                medium.around(contos_0[xt.im], false);
                            if(i_7 > 40 && i_7 < 60)
                                medium.transaround(contos_0[xt.im], contos_0[record.wasted], i_7 - 40);
                            if(i_7 == 60)
                                medium.around(contos_0[record.wasted], false);
                            if(i_6 > 160 && i_7 < 20)
                                i_7++;
                            if(i_6 > 230 && i_7 < 40)
                                i_7++;
                            if(i_6 > 280 && i_7 < 60)
                                i_7++;
                            if((i_7 == 0 || i_7 == 20 || i_7 == 40 || i_7 == 60) && ++i_6 == 300)
                            {
                                i_6 = 0;
                                i_7 = 0;
                                i_8++;
                            }
                        } else
                        {
                            if(i_7 == 0)
                                medium.around(contos_0[xt.im], false);
                            if(i_7 > 0 && i_7 < 20)
                                medium.transaround(contos_0[xt.im], contos_0[record.wasted], i_7);
                            if(i_7 == 20)
                                medium.around(contos_0[record.wasted], false);
                            if(i_7 > 20 && i_7 < 40)
                                medium.transaround(contos_0[record.wasted], contos_0[xt.im], i_7 - 20);
                            if(i_7 == 40)
                                medium.around(contos_0[xt.im], false);
                            if(i_7 > 40 && i_7 < 60)
                                medium.transaround(contos_0[xt.im], contos_0[record.wasted], i_7 - 40);
                            if(i_7 == 60)
                                medium.around(contos_0[record.wasted], false);
                            if(i_7 > 60 && i_7 < 80)
                                medium.transaround(contos_0[record.wasted], contos_0[xt.im], i_7 - 60);
                            if(i_7 == 80)
                                medium.around(contos_0[xt.im], false);
                            if(i_6 > 90 && i_7 < 20)
                                i_7++;
                            if(i_6 > 160 && i_7 < 40)
                                i_7++;
                            if(i_6 > 230 && i_7 < 60)
                                i_7++;
                            if(i_6 > 280 && i_7 < 80)
                                i_7++;
                            if((i_7 == 0 || i_7 == 20 || i_7 == 40 || i_7 == 60 || i_7 == 80) && ++i_6 == 300)
                            {
                                i_6 = 0;
                                i_7 = 0;
                                i_8++;
                            }
                        }
                    } else
                    {
                        if(i_9 == 67 && (i_7 == 3 || i_7 == 31 || i_7 == 66))
                        {
                            rd.setColor(new Color(255, 255, 255));
                            rd.fillRect(0, 0, 800, 450);
                        }
                        if(i_9 == 69 && (i_7 == 3 || i_7 == 5 || i_7 == 31 || i_7 == 33 || i_7 == 66 || i_7 == 68))
                        {
                            rd.setColor(new Color(255, 255, 255));
                            rd.fillRect(0, 0, 800, 450);
                        }
                        if(i_9 == 30 && i_7 >= 1 && i_7 < 30)
                            if(i_7 % (int)(2.0F + medium.random() * 3F) == 0 && !bool_10)
                            {
                                rd.setColor(new Color(255, 255, 255));
                                rd.fillRect(0, 0, 800, 450);
                                bool_10 = true;
                            } else
                            {
                                bool_10 = false;
                            }
                        if(i_6 > record.whenwasted && i_7 != i_9)
                            i_7++;
                        medium.around(contos_0[xt.im], false);
                        if((i_7 == 0 || i_7 == i_9) && ++i_6 == 300)
                        {
                            i_6 = 0;
                            i_7 = 0;
                            i_8++;
                        }
                    }
                }
            }
            if(xt.fase == -4)
            {
                if(i_6 == 0)
                {
                    xt.sendwin(checkpoints);
                    if(xt.winner && xt.multion == 0 && xt.gmode != 0 && checkpoints.stage != 27 && checkpoints.stage == xt.unlocked[xt.gmode - 1] + (xt.gmode - 1) * 10)
                    {
                        xt.unlocked[xt.gmode - 1]++;
                        setcarcookie(xt.sc[0], cardefine.names[xt.sc[0]], xt.arnp, xt.gmode, xt.unlocked, false);
                        xt.unlocked[xt.gmode - 1]--;
                    }
                }
                if(i_6 <= 0)
                {
                    rd.drawImage(xt.mdness, 289, 30, null);
                    rd.drawImage(xt.dude[0], 135, 10, null);
                }
                if(i_6 >= 0)
                    xt.fleximage(offImage, i_6, checkpoints.stage);
                if(++i_6 == 7)
                {
                    xt.fase = -5;
                    rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                }
            }
            if(xt.fase == -6)
            {
                repaint();
                xt.pauseimage(offImage);
                xt.fase = -7;
                mouses = 0;
            }
            if(xt.fase == -7)
            {
                xt.pausedgame(checkpoints.stage, u[0], record);
                if(i_6 != 0)
                    i_6 = 0;
                xt.ctachm(xm, ym, mouses, u[0]);
                if(mouses == 2)
                    mouses = 0;
                if(mouses == 1)
                    mouses = 2;
            }
            if(xt.fase == -8)
            {
                xt.cantreply();
                if(++i_6 == 150 || u[0].enter || u[0].handb || mouses == 1)
                {
                    xt.fase = -7;
                    mouses = 0;
                    u[0].enter = false;
                    u[0].handb = false;
                }
            }
            if(lostfcs && xt.fase == 7001)
                if(fcscnt == 0)
                {
                    if(u[0].chatup == 0)
                        requestFocus();
                    fcscnt = 10;
                } else
                {
                    fcscnt--;
                }
            if(!cmsg.isVisible() && (xt.fase == 7001 || xt.fase == 0))
            {
                if(u[0].chron)
                {
                    Madness.chronon++;
                    if(Madness.chronon > 4)
                        Madness.chronon = 0;
                    u[0].chron = false;
                }
                if(u[0].spd)
                {
                    Madness.speedon++;
                    if(Madness.speedon > 4)
                        Madness.speedon = 0;
                    u[0].spd = false;
                }
                if(u[0].mod)
                {
                    Madness.modon++;
                    GadgetPainter.modc = 150;
                    if(Madness.modon > 4)
                        Madness.modon = 0;
                    u[0].mod = false;
                }
                if(u[0].pos)
                {
                    Madness.poson++;
                    if(Madness.poson > 4)
                        Madness.poson = 0;
                    u[0].pos = false;
                }
                if(u[0].dampwr)
                {
                    Madness.staton++;
                    if(Madness.staton > 4)
                        Madness.staton = 0;
                    u[0].dampwr = false;
                }
                if(u[0].arr)
                {
                    Madness.arrowon++;
                    if(Madness.arrowon > 4)
                        Madness.arrowon = 0;
                    u[0].arr = false;
                }
            }
            if(Madness.sshot)
                Madness.saveSnap(offImage);
            if(!msg.equals("") && msgc > 0)
            {
                xt.showMessage(msg);
                msgc--;
            }
            repaint();
            if(xt.im > -1 && xt.im < 8)
            {
                int i_94 = 0;
                if(xt.multion == 2 || xt.multion == 3)
                {
                    i_94 = xt.im;
                    u[i_94].mutem = u[0].mutem;
                    u[i_94].mutes = u[0].mutes;
                }
                xt.playsounds(mads[xt.im], u[i_94], checkpoints.stage);
            }
            date = new Date();
            long l_95 = date.getTime();
            if(xt.fase == 0 || xt.fase == -1 || xt.fase == -3 || xt.fase == 7001 || xt.fase == -6 || xt.fase == -7 || xt.fase == -8)
            {
                if(!bool_3)
                {
                    i = 15;
                    f_2 = f;
                    if(f_2 < 30F)
                        f_2 = 30F;
                    bool_3 = true;
                    i_5 = 0;
                }
                if(i_5 == 10)
                {
                    float f_96 = (((float)i_4 + udpmistro.freg) - (float)(l_95 - l_1)) / 20F;
                    if(f_96 > 40F)
                        f_96 = 40F;
                    if(f_96 < -40F)
                        f_96 = -40F;
                    f_2 += f_96;
                    if(f_2 < 5F)
                        f_2 = 5F;
                    medium.adjstfade(f_2, f_96, xt.starcnt, this);
                    l_1 = l_95;
                    i_5 = 0;
                } else
                {
                    i_5++;
                }
            } else
            {
                if(bool_3)
                {
                    i = 30;
                    f = f_2;
                    bool_3 = false;
                    i_5 = 0;
                }
                if(i_5 == 10)
                {
                    if(l_95 - l_1 < 400L)
                    {
                        f_2 = (float)((double)f_2 + 3.5D);
                    } else
                    {
                        f_2 = (float)((double)f_2 - 3.5D);
                        if(f_2 < 5F)
                            f_2 = 5F;
                    }
                    l_1 = l_95;
                    i_5 = 0;
                } else
                {
                    i_5++;
                }
            }
            if(exwist)
            {
                rd.dispose();
                xt.stopallnow();
                cardefine.stopallnow();
                udpmistro.UDPquit();
                if(bool)
                {
                    lobby.stopallnow();
                    login.stopallnow();
                    globe.stopallnow();
                }
                System.gc();
                if(Madness.endadv == 2)
                    Madness.advopen();
                gamer.stop();
                gamer = null;
            }
            l = (long)Math.round(f_2) - (l_95 - l_11);
            if(l < (long)i)
                l = i;
            if(xt.fase == 0 || xt.fase == -1 || xt.fase == -3 || xt.fase == 7001 || xt.fase == -6 || xt.fase == -7 || xt.fase == -8)
            {
                l_11 = l_95 / 1000L;
                if(l_11 != lastsec)
                {
                    if(l_11 == lastsec + 1L)
                    {
                        fpsav = fpsav != 0.0D ? fpsav * 0.59999999999999998D + (double)fps * 0.40000000000000002D : fps;
                        if(fpsav < 21.199999999999999D && i_4 > 510)
                            i_4--;
                        if(fpsav > 21.300000000000001D && i_4 < 530)
                            i_4++;
                    }
                    fps = 0;
                    lastsec = l_11;
                }
                fps++;
            }
            try
            {
                if(gamer == null);
                Thread.sleep(l);
            }
            catch(InterruptedException interruptedexception) { }
        } while(true);
    }

    public void checkmemory(xtGraphics xt)
    {
        if(xt.macn && Runtime.getRuntime().freeMemory() / 0x100000L < 50L || applejava)
            xt.badmac = true;
    }

    public void paint(Graphics graphics)
    {
        Graphics2D graphics2d = (Graphics2D)graphics;
        if(lastw != getWidth() || lasth != getHeight())
        {
            lastw = getWidth();
            lasth = getHeight();
            showsize = 100;
            if(lastw <= 800 || lasth <= 550)
                reqmult = 0.0F;
            if(Madness.fullscreen)
            {
                apx = (int)((float)(getWidth() / 2) - 400F * apmult);
                apy = (int)((float)(getHeight() / 2) - 225F * apmult);
            }
        }
        int i = 0;
        int i_97 = 0;
        if(moto == 1 && shaka > 0)
        {
            i = (int)(((double)(shaka * 2) * Math.random() - (double)shaka) * (double)apmult);
            i_97 = (int)(((double)(shaka * 2) * Math.random() - (double)shaka) * (double)apmult);
            shaka--;
        }
        if(!Madness.fullscreen)
        {
            if(showsize != 0)
            {
                if(showsize == 100 || showsize == 70)
                    graphics2d.clearRect(0, 0, getWidth(), getHeight());
                float f = (float)(getWidth() - 40) / 800F - 1.0F;
                if(f > (float)(getHeight() - 70) / 450F - 1.0F)
                    f = (float)(getHeight() - 70) / 450F - 1.0F;
                if(f > 1.0F)
                    f = 1.0F;
                if(f < 0.0F)
                    f = 0.0F;
                apmult = 1.0F + f * reqmult;
                if(!oncarm)
                    graphics2d.drawImage(carmaker[0], 50, 14, this);
                else
                    graphics2d.drawImage(carmaker[1], 50, 14, this);
                if(!onstgm)
                    graphics2d.drawImage(stagemaker[0], getWidth() - 208, 14, this);
                else
                    graphics2d.drawImage(stagemaker[1], getWidth() - 208, 14, this);
                graphics2d.drawImage(sizebar, getWidth() / 2 - 230, 23, this);
                graphics2d.drawImage(blb, (int)((float)(getWidth() / 2 - 222) + 141F * reqmult), 23, this);
                graphics2d.drawImage(chkbx[smooth], getWidth() / 2 - 53, 23, this);
                graphics2d.setFont(new Font("Arial", 1, 11));
                graphics2d.setColor(new Color(74, 99, 125));
                graphics2d.drawString("Screen Size:", getWidth() / 2 - 224, 17);
                graphics2d.drawString("Smooth", getWidth() / 2 - 36, 34);
                graphics2d.drawImage(fulls, getWidth() / 2 + 27, 15, this);
                graphics2d.setColor(new Color(94, 126, 159));
                graphics2d.drawString("Fullscreen", getWidth() / 2 + 63, 30);
                graphics2d.drawImage(chkbx[Madness.anti], getWidth() / 2 + 135, 9, this);
                graphics2d.drawString("Antialiasing", getWidth() / 2 + 152, 20);
                graphics2d.drawImage(chkbx[moto], getWidth() / 2 + 135, 26, this);
                graphics2d.drawString("Motion Effects", getWidth() / 2 + 152, 37);
                graphics2d.setColor(new Color(0, 0, 0));
                graphics2d.fillRect(getWidth() / 2 - 153, 5, 80, 16);
                graphics2d.setColor(new Color(121, 135, 152));
                String string = (new StringBuilder()).append("").append((int)(apmult * 100F)).append("%").toString();
                if(reqmult == 0.0F)
                    string = "Original";
                if(reqmult == 1.0F)
                    string = "Maximum";
                graphics2d.drawString(string, getWidth() / 2 - 150, 17);
                if(!oncarm && !onstgm)
                    showsize--;
                if(showsize == 0)
                {
                    graphics2d.setColor(new Color(0, 0, 0));
                    graphics2d.fillRect(getWidth() / 2 - 260, 0, 520, 40);
                    graphics2d.fillRect(50, 14, 142, 23);
                    graphics2d.fillRect(getWidth() - 208, 14, 158, 23);
                }
            }
            apx = (int)((float)(getWidth() / 2) - 400F * apmult);
            apy = (int)((float)(getHeight() / 2) - 225F * apmult - 50F);
            if(apy < 50)
                apy = 50;
            if(apmult > 1.0F)
            {
                if(smooth == 1)
                {
                    graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    if(moto == 1)
                    {
                        graphics2d.setComposite(AlphaComposite.getInstance(3, (float)mvect / 100F));
                        rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
                        graphics2d.drawImage(offImage, apx + i, apy + i_97, (int)(800F * apmult), (int)(450F * apmult), this);
                        cropit(graphics2d, i, i_97);
                    } else
                    {
                        if(xtGraphics.blowEffect > 0.0F && Madness.bluron && Madness.graphs == 0)
                            graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F - xtGraphics.blowEffect));
                        graphics2d.drawImage(offImage, apx, apy, (int)(800F * apmult), (int)(450F * apmult), this);
                    }
                } else
                if(moto == 1)
                {
                    graphics2d.setComposite(AlphaComposite.getInstance(3, (float)mvect / 100F));
                    rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
                    graphics2d.drawImage(offImage, apx + i, apy + i_97, (int)(800F * apmult), (int)(450F * apmult), this);
                    cropit(graphics2d, i, i_97);
                } else
                {
                    if(xtGraphics.blowEffect > 0.0F && Madness.bluron && Madness.graphs == 0)
                        graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F - xtGraphics.blowEffect));
                    graphics2d.drawImage(offImage, apx, apy, (int)(800F * apmult), (int)(450F * apmult), this);
                }
            } else
            if(moto == 1)
            {
                graphics2d.setComposite(AlphaComposite.getInstance(3, (float)mvect / 100F));
                rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
                graphics2d.drawImage(offImage, apx + i, apy + i_97, this);
                cropit(graphics2d, i, i_97);
            } else
            {
                if(xtGraphics.blowEffect > 0.0F && Madness.bluron && Madness.graphs == 0)
                    graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F - xtGraphics.blowEffect));
                graphics2d.drawImage(offImage, apx, apy, this);
            }
        } else
        if(moto == 1)
        {
            graphics2d.setComposite(AlphaComposite.getInstance(3, (float)mvect / 100F));
            rd.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
            graphics2d.drawImage(offImage, apx + i, apy + i_97, this);
            cropit(graphics2d, i, i_97);
        } else
        {
            if(xtGraphics.blowEffect > 0.0F && Madness.bluron && Madness.graphs == 0)
                graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F - xtGraphics.blowEffect));
            graphics2d.drawImage(offImage, apx, apy, this);
        }
    }

    public void cropit(Graphics2D graphics2d, int i, int i_98)
    {
        if(i != 0 || i_98 != 0)
        {
            graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
            graphics2d.setColor(new Color(0, 0, 0));
        }
        if(i != 0)
            if(i < 0)
                graphics2d.fillRect(apx + i, apy - (int)(25F * apmult), Math.abs(i), (int)(500F * apmult));
            else
                graphics2d.fillRect(apx + (int)(800F * apmult), apy - (int)(25F * apmult), i, (int)(500F * apmult));
        if(i_98 != 0)
            if(i_98 < 0)
                graphics2d.fillRect(apx - (int)(25F * apmult), apy + i_98, (int)(850F * apmult), Math.abs(i_98));
            else
                graphics2d.fillRect(apx - (int)(25F * apmult), apy + (int)(450F * apmult), (int)(850F * apmult), i_98);
    }

    public void update(Graphics graphics)
    {
        paint(graphics);
    }

    public void init()
    {
        setBackground(new Color(0, 0, 0));
        offImage = createImage(800, 450);
        if(offImage != null)
            rd = (Graphics2D)offImage.getGraphics();
        rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        setLayout(null);
        tnick = new TextField("Nickbname");
        tnick.setFont(new Font("Arial", 1, 13));
        tpass = new TextField("");
        tpass.setFont(new Font("Arial", 1, 13));
        tpass.setEchoCharacter('*');
        temail = new TextField("");
        temail.setFont(new Font("Arial", 1, 13));
        cmsg = new TextField("");
        mmsg = new TextArea("", 200, 20, 3);
        cmsg.setFont(new Font("Tahoma", 0, 11));
        mmsg.setFont(new Font("Tahoma", 0, 11));
        mycar = new Checkbox("Sword of Justice Game!");
        notp = new Checkbox("No Trees & Piles");
        keplo = new Checkbox("Stay logged in");
        keplo.setState(true);
        add(tnick);
        add(tpass);
        add(temail);
        add(cmsg);
        add(mmsg);
        add(mycar);
        add(notp);
        add(keplo);
        sgame.setFont(new Font("Arial", 1, 13));
        wgame.setFont(new Font("Arial", 1, 13));
        warb.setFont(new Font("Arial", 1, 13));
        pgame.setFont(new Font("Arial", 1, 12));
        vnpls.setFont(new Font("Arial", 1, 13));
        vtyp.setFont(new Font("Arial", 1, 13));
        snfmm.setFont(new Font("Arial", 1, 13));
        snfm1.setFont(new Font("Arial", 1, 13));
        snfm2.setFont(new Font("Arial", 1, 13));
        mstgs.setFont(new Font("Arial", 1, 13));
        mcars.setFont(new Font("Arial", 1, 13));
        slaps.setFont(new Font("Arial", 1, 13));
        snpls.setFont(new Font("Arial", 0, 13));
        snbts.setFont(new Font("Arial", 0, 13));
        swait.setFont(new Font("Arial", 0, 12));
        sclass.setFont(new Font("Arial", 1, 12));
        scars.setFont(new Font("Arial", 1, 12));
        sfix.setFont(new Font("Arial", 1, 12));
        mycar.setFont(new Font("Arial", 1, 12));
        notp.setFont(new Font("Arial", 1, 12));
        keplo.setFont(new Font("Arial", 1, 12));
        gmode.setFont(new Font("Arial", 1, 13));
        rooms.setFont(new Font("Arial", 1, 13));
        sendtyp.setFont(new Font("Arial", 1, 12));
        senditem.setFont(new Font("Arial", 1, 12));
        datat.setFont(new Font("Arial", 1, 12));
        clanlev.setFont(new Font("Arial", 1, 12));
        clcars.setFont(new Font("Arial", 1, 12));
        clcars.alphad = true;
        ilaps.setFont(new Font("Arial", 1, 13));
        icars.setFont(new Font("Arial", 1, 12));
        sgame.add(rd, " NFM 1     ");
        sgame.add(rd, " NFM 2     ");
        sgame.add(rd, " My Stages ");
        sgame.add(rd, " Weekly Top20 ");
        sgame.add(rd, " Monthly Top20 ");
        sgame.add(rd, " All Time Top20 ");
        sgame.add(rd, " Stage Maker ");
        wgame.add(rd, " Normal Game");
        wgame.add(rd, " War / Battle");
        wgame.add(rd, " War / Battle - Practice");
        warb.add(rd, " Loading your clan's wars and battles, please wait...");
        pgame.add(rd, " Select the game you want to practice");
        vnpls.add(rd, "Players");
        vnpls.add(rd, " 2 VS 2");
        vnpls.add(rd, " 3 VS 3");
        vnpls.add(rd, " 4 VS 4");
        vtyp.add(rd, "Normal clan game");
        vtyp.add(rd, "Racing only");
        vtyp.add(rd, "Wasting only");
        vtyp.add(rd, "Racers VS Wasters - my clan wastes");
        vtyp.add(rd, "Racers VS Wasters - my clan races");
        snfmm.add(rd, "Select Stage");
        snfm1.add(rd, "Select Stage");
        snfm2.add(rd, "Select Stage");
        mstgs.add(rd, "Suddenly the King becomes Santa's Little Helper");
        mcars.add(rd, "Sword of Justice");
        snpls.add(rd, "Select");
        swait.add(rd, "1 Minute");
        ilaps.add(rd, "Laps");
        ilaps.add(rd, "1 Lap");
        for(int i = 0; i < 5; i++)
            snfmm.add(rd, (new StringBuilder()).append(" Stage ").append(i + 1).append("").toString());

        for(int i = 0; i < 10; i++)
            snfm1.add(rd, (new StringBuilder()).append(" Stage ").append(i + 1).append("").toString());

        for(int i = 0; i < 17; i++)
            snfm2.add(rd, (new StringBuilder()).append(" Stage ").append(i + 1).append("").toString());

        for(int i = 0; i < 7; i++)
            snpls.add(rd, (new StringBuilder()).append("    ").append(i + 2).append("").toString());

        for(int i = 0; i < 7; i++)
            snbts.add(rd, (new StringBuilder()).append("    ").append(i).append("    ").toString());

        for(int i = 0; i < 2; i++)
            swait.add(rd, (new StringBuilder()).append("").append(i + 2).append(" Minutes").toString());

        for(int i = 0; i < 15; i++)
            slaps.add(rd, (new StringBuilder()).append("").append(i + 1).append("").toString());

        for(int i = 0; i < 14; i++)
            ilaps.add(rd, (new StringBuilder()).append("").append(i + 2).append(" Laps").toString());

        sclass.add(rd, "All Classes");
        sclass.add(rd, "Class C Cars");
        sclass.add(rd, "Class B & C Cars");
        sclass.add(rd, "Class B Cars");
        sclass.add(rd, "Class A & B Cars");
        sclass.add(rd, "Class A Cars");
        scars.add(rd, "All Cars");
        scars.add(rd, "Custom Cars");
        scars.add(rd, "Game Cars");
        sfix.add(rd, "Unlimited Fixing");
        sfix.add(rd, "4 Fixes");
        sfix.add(rd, "3 Fixes");
        sfix.add(rd, "2 Fixes");
        sfix.add(rd, "1 Fix");
        sfix.add(rd, "No Fixing");
        icars.add(rd, "Type of Cars");
        icars.add(rd, "All Cars");
        icars.add(rd, "Clan Cars");
        icars.add(rd, "Game Cars");
        icars.w = 140;
        gmode.add(rd, " Normal Game ");
        gmode.add(rd, " Practice Game ");
        rooms.rooms = true;
        rooms.add(rd, "Ghostrider :: 1");
        sendtyp.add(rd, "Write a Message");
        sendtyp.add(rd, "Share a Custom Car");
        sendtyp.add(rd, "Share a Custom Stage");
        sendtyp.add(rd, "Send a Clan Invitation");
        sendtyp.add(rd, "Share a Relative Date");
        senditem.add(rd, "Suddenly the King becomes Santa's Little Helper");
        for(int i = 0; i < 6; i++)
            clanlev.add(rd, (new StringBuilder()).append("").append(i + 1).append("").toString());

        clanlev.add(rd, "7 - Admin");
        String names[] = {
            "Tornado Shark", "Formula 7", "Wow Caninaro", "La Vita Crab", "Nimi", "MAX Revenge", "Lead Oxide", "Kool Kat", "Drifter X", "Sword of Justice", 
            "High Rider", "EL KING", "Mighty Eight", "M A S H E E N", "Radical One", "DR Monstaa"
        };
        mgmcars = new Smenu(names.length + 1);
        String arr$[] = names;
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            String name = arr$[i$];
            mgmcars.add(rd, name);
        }

        mscores = new Smenu(5);
        mscores.add(rd, "Last 30 Days");
        mscores.add(rd, "Last 90 Days");
        mscores.add(rd, "Last 180 Days");
        mscores.add(rd, "All-Times");
        mscores.setBackground(new Color(0, 0, 0));
        mscores.setForeground(new Color(253, 166, 0));
        mscores.move(385, 339);
        hidefields();
    }

    public void hidefields()
    {
        ilaps.hide();
        icars.hide();
        clcars.hide();
        clanlev.hide();
        mmsg.hide();
        datat.hide();
        senditem.hide();
        sendtyp.hide();
        rooms.hide();
        mcars.hide();
        mstgs.hide();
        gmode.hide();
        sclass.hide();
        scars.hide();
        sfix.hide();
        mycar.hide();
        notp.hide();
        keplo.hide();
        tnick.hide();
        tpass.hide();
        temail.hide();
        cmsg.hide();
        sgame.hide();
        wgame.hide();
        pgame.hide();
        vnpls.hide();
        vtyp.hide();
        warb.hide();
        slaps.hide();
        snfm1.hide();
        snfmm.hide();
        snfm2.hide();
        snpls.hide();
        snbts.hide();
        swait.hide();
        mgmcars.hide();
        mscores.hide();
    }

    public void drawms()
    {
        openm = false;
        if(gmode.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(swait.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(slaps.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(snpls.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(snbts.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(scars.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(sgame.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(snfm1.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(snfm2.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(snfmm.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(mstgs.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(mcars.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(pgame.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(vnpls.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(vtyp.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(warb.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(wgame.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(rooms.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(sendtyp.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(senditem.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(datat.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(clanlev.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(clcars.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(ilaps.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(icars.draw(rd, xm, ym, moused, 450, true))
            openm = true;
        if(sfix.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(sclass.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(mgmcars.draw(rd, xm, ym, moused, 450, false))
            openm = true;
        if(mscores.draw(rd, xm, ym, moused, 450, false))
            openm = true;
    }

    public void movefield(Component component, int i, int i_99, int i_100, int i_101)
    {
        if(i_100 == 360 || i_100 == 576)
        {
            i = (int)((float)i * apmult + (float)apx + (float)(component.getWidth() / 2) * (apmult - 1.0F));
            i_99 = (int)((float)i_99 * apmult + (float)apy + 12F * (apmult - 1.0F));
        } else
        {
            i = (int)((float)i * apmult + (float)apx);
            i_99 = (int)((float)i_99 * apmult + (float)apy + 12F * (apmult - 1.0F));
        }
        if(component.getX() != i || component.getY() != i_99)
            component.setBounds(i, i_99, i_100, i_101);
    }

    public void movefieldd(TextField textfield, int i, int i_102, int i_103, int i_104, boolean bool)
    {
        if(applejava)
        {
            if(bool)
                if(xm > i && xm < i + i_103 && ym > i_102 && ym < i_102 + i_104 || !textfield.getText().equals(""))
                {
                    if(!textfield.isShowing())
                    {
                        textfield.show();
                        textfield.requestFocus();
                    }
                    if(i_103 == 360 || i_103 == 576)
                    {
                        i = (int)((float)i * apmult + (float)apx + (float)(textfield.getWidth() / 2) * (apmult - 1.0F));
                        i_102 = (int)((float)i_102 * apmult + (float)apy + 12F * (apmult - 1.0F));
                    } else
                    {
                        i = (int)((float)i * apmult + (float)apx);
                        i_102 = (int)((float)i_102 * apmult + (float)apy + 12F * (apmult - 1.0F));
                    }
                    if(textfield.getX() != i || textfield.getY() != i_102)
                        textfield.setBounds(i, i_102, i_103, i_104);
                } else
                {
                    if(textfield.isShowing())
                    {
                        textfield.hide();
                        requestFocus();
                    }
                    rd.setColor(textfield.getBackground());
                    rd.fillRect(i, i_102, i_103 - 1, i_104 - 1);
                    rd.setColor(textfield.getBackground().darker());
                    rd.drawRect(i, i_102, i_103 - 1, i_104 - 1);
                }
        } else
        {
            if(bool && !textfield.isShowing())
                textfield.show();
            movefield(textfield, i, i_102, i_103, i_104);
        }
    }

    public void movefielda(TextArea textarea, int i, int i_105, int i_106, int i_107)
    {
        if(applejava)
        {
            if(xm > i && xm < i + i_106 && ym > i_105 && ym < i_105 + i_107 || !textarea.getText().equals(" "))
            {
                if(!textarea.isShowing())
                {
                    textarea.show();
                    textarea.requestFocus();
                }
                if(i_106 == 360 || i_106 == 576)
                {
                    i = (int)((float)i * apmult + (float)apx + (float)(textarea.getWidth() / 2) * (apmult - 1.0F));
                    i_105 = (int)((float)i_105 * apmult + (float)apy + 12F * (apmult - 1.0F));
                } else
                {
                    i = (int)((float)i * apmult + (float)apx);
                    i_105 = (int)((float)i_105 * apmult + (float)apy + 12F * (apmult - 1.0F));
                }
                if(textarea.getX() != i || textarea.getY() != i_105)
                    textarea.setBounds(i, i_105, i_106, i_107);
            } else
            {
                if(textarea.isShowing())
                {
                    textarea.hide();
                    requestFocus();
                }
                rd.setColor(textarea.getBackground());
                rd.fillRect(i, i_105, i_106 - 1, i_107 - 1);
                rd.setColor(textarea.getBackground().darker());
                rd.drawRect(i, i_105, i_106 - 1, i_107 - 1);
            }
        } else
        {
            if(!textarea.isShowing())
                textarea.show();
            movefield(textarea, i, i_105, i_106, i_107);
        }
    }

    public void loadstage(ContO contos[], ContO contos_108[], Medium medium, Trackers trackers, CheckPoints checkpoints, xtGraphics xt, Mad mads[], 
            Record record)
    {
        if(xt.testdrive == 2 || xt.testdrive == 4)
            xt.nplayers = 1;
        if(xt.gmode == 1)
        {
            xt.nplayers = 5;
            xt.xstart[4] = 0;
            xt.zstart[4] = 760;
        }
        if(xt.gmode == 1 || xt.gmode == 2 || xt.gmode == 0 && xt.notrees && xt.multion == 0)
            checkpoints.notb = true;
        trackers.nt = 0;
        nob = xt.nplayers;
        notb = 0;
        checkpoints.n = 0;
        checkpoints.nsp = 0;
        checkpoints.fn = 0;
        checkpoints.trackname = "";
        checkpoints.haltall = false;
        checkpoints.wasted = 0;
        checkpoints.catchfin = 0;
        medium.resdown = Madness.ographs = Madness.graphs;
        medium.rescnt = 5;
        medium.lightson = false;
        medium.noelec = 0;
        medium.ground = 250;
        medium.trk = 0;
        view = 0;
        int i = 0;
        int i_109 = 100;
        int i_110 = 0;
        int i_111 = 100;
        xt.newparts = false;
        String string = "";
        try
        {
            DataInputStream datainputstream;
            if(xt.multion == 0 && checkpoints.stage != -2)
            {
                String string_112 = (new StringBuilder()).append("stages/").append(checkpoints.stage).append("").toString();
                if(checkpoints.stage == -1)
                    string_112 = (new StringBuilder()).append("mystages/").append(checkpoints.name).append("").toString();
                File file = new File((new StringBuilder()).append("").append(string_112).append(".txt").toString());
                if(checkpoints.stage > 0)
                    xt.sumid[checkpoints.stage - 1] = (int)file.length();
                datainputstream = new DataInputStream(new FileInputStream(file));
            } else
            if(checkpoints.stage > 0)
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/stages/").append(checkpoints.stage).append(".txt").toString());
                datainputstream = new DataInputStream(url.openStream());
            } else
            {
                String string_113 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(URLEncoder.encode(checkpoints.name.replace(' ', '_'), "UTF-8")).append(".radq").toString();
                URL url = new URL(string_113);
                int i_114 = url.openConnection().getContentLength();
                DataInputStream datainputstream_115 = new DataInputStream(url.openStream());
                byte is[] = new byte[i_114];
                datainputstream_115.readFully(is);
                ZipInputStream zipinputstream;
                if(is[0] == 80 && is[1] == 75 && is[2] == 3)
                {
                    zipinputstream = new ZipInputStream(new ByteArrayInputStream(is));
                } else
                {
                    byte is_116[] = new byte[i_114 - 40];
                    for(int i_117 = 0; i_117 < i_114 - 40; i_117++)
                    {
                        int i_118 = 20;
                        if(i_117 >= 500)
                            i_118 = 40;
                        is_116[i_117] = is[i_117 + i_118];
                    }

                    zipinputstream = new ZipInputStream(new ByteArrayInputStream(is_116));
                }
                ZipEntry zipentry = zipinputstream.getNextEntry();
                int i_119 = Integer.valueOf(zipentry.getName()).intValue();
                byte is_120[] = new byte[i_119];
                int i_121 = 0;
                int i_122;
                for(; i_119 > 0; i_119 -= i_122)
                {
                    i_122 = zipinputstream.read(is_120, i_121, i_119);
                    i_121 += i_122;
                }

                zipinputstream.close();
                datainputstream_115.close();
                datainputstream = new DataInputStream(new ByteArrayInputStream(is_120));
            }
            do
            {
                String string_123;
                if((string_123 = datainputstream.readLine()) == null)
                    break;
                string = (new StringBuilder()).append("").append(string_123.trim()).toString();
                if(string.startsWith("snap"))
                    medium.setsnap(getint("snap", string, 0), getint("snap", string, 1), getint("snap", string, 2));
                if(string.startsWith("sky"))
                {
                    medium.setsky(getint("sky", string, 0), getint("sky", string, 1), getint("sky", string, 2));
                    xt.snap(checkpoints.stage);
                }
                if(string.startsWith("ground"))
                    medium.setgrnd(getint("ground", string, 0), getint("ground", string, 1), getint("ground", string, 2));
                if(string.startsWith("polys"))
                    medium.setpolys(getint("polys", string, 0), getint("polys", string, 1), getint("polys", string, 2));
                if(string.startsWith("fog"))
                    medium.setfade(getint("fog", string, 0), getint("fog", string, 1), getint("fog", string, 2));
                if(string.startsWith("texture"))
                    medium.setexture(getint("texture", string, 0), getint("texture", string, 1), getint("texture", string, 2), getint("texture", string, 3));
                if(string.startsWith("clouds"))
                    medium.setcloads(getint("clouds", string, 0), getint("clouds", string, 1), getint("clouds", string, 2), getint("clouds", string, 3), getint("clouds", string, 4));
                if(string.startsWith("density"))
                {
                    medium.fogd = (getint("density", string, 0) + 1) * 2 - 1;
                    if(medium.fogd < 1)
                        medium.fogd = 1;
                    if(medium.fogd > 30)
                        medium.fogd = 30;
                }
                if(string.startsWith("fadefrom"))
                    medium.fadfrom(getint("fadefrom", string, 0));
                if(string.startsWith("lightson"))
                    medium.lightson = true;
                if(string.startsWith("mountains"))
                    medium.mgen = getint("mountains", string, 0);
                if(string.startsWith("set"))
                {
                    int i_124 = getint("set", string, 0);
                    if(xt.nplayers == 8)
                    {
                        if(i_124 == 47)
                            i_124 = 76;
                        if(i_124 == 48)
                            i_124 = 77;
                    }
                    boolean bool = true;
                    if(i_124 >= 65 && i_124 <= 75 && checkpoints.notb)
                        bool = false;
                    if(bool)
                    {
                        if(i_124 == 49 || i_124 == 64 || i_124 >= 56 && i_124 <= 61)
                            xt.newparts = true;
                        if((checkpoints.stage < 0 || checkpoints.stage >= 28) && i_124 >= 10 && i_124 <= 25)
                            medium.loadnew = true;
                        i_124 += 46;
                        contos[nob] = new ContO(contos_108[i_124], getint("set", string, 1), medium.ground - contos_108[i_124].grat, getint("set", string, 2), getint("set", string, 3));
                        if(string.indexOf(")p") != -1)
                        {
                            checkpoints.x[checkpoints.n] = getint("set", string, 1);
                            checkpoints.z[checkpoints.n] = getint("set", string, 2);
                            checkpoints.y[checkpoints.n] = 0;
                            checkpoints.typ[checkpoints.n] = 0;
                            if(string.indexOf(")pt") != -1)
                                checkpoints.typ[checkpoints.n] = -1;
                            if(string.indexOf(")pr") != -1)
                                checkpoints.typ[checkpoints.n] = -2;
                            if(string.indexOf(")po") != -1)
                                checkpoints.typ[checkpoints.n] = -3;
                            if(string.indexOf(")ph") != -1)
                                checkpoints.typ[checkpoints.n] = -4;
                            if(string.indexOf("out") != -1)
                                System.out.println((new StringBuilder()).append("out: ").append(checkpoints.n).toString());
                            checkpoints.n++;
                            notb = nob + 1;
                        }
                        nob++;
                        if(medium.loadnew)
                            medium.loadnew = false;
                    }
                }
                if(string.startsWith("chk"))
                {
                    int i_125 = getint("chk", string, 0);
                    i_125 += 46;
                    int i_126 = medium.ground - contos_108[i_125].grat;
                    if(i_125 == 110)
                        i_126 = getint("chk", string, 4);
                    contos[nob] = new ContO(contos_108[i_125], getint("chk", string, 1), i_126, getint("chk", string, 2), getint("chk", string, 3));
                    checkpoints.x[checkpoints.n] = getint("chk", string, 1);
                    checkpoints.z[checkpoints.n] = getint("chk", string, 2);
                    checkpoints.y[checkpoints.n] = i_126;
                    if(getint("chk", string, 3) == 0)
                        checkpoints.typ[checkpoints.n] = 1;
                    else
                        checkpoints.typ[checkpoints.n] = 2;
                    checkpoints.pcs = checkpoints.n;
                    checkpoints.n++;
                    contos[nob].checkpoint = checkpoints.nsp + 1;
                    checkpoints.nsp++;
                    nob++;
                    notb = nob;
                }
                if(checkpoints.nfix != 5 && string.startsWith("fix"))
                {
                    int i_127 = getint("fix", string, 0);
                    i_127 += 46;
                    contos[nob] = new ContO(contos_108[i_127], getint("fix", string, 1), getint("fix", string, 3), getint("fix", string, 2), getint("fix", string, 4));
                    checkpoints.fx[checkpoints.fn] = getint("fix", string, 1);
                    checkpoints.fz[checkpoints.fn] = getint("fix", string, 2);
                    checkpoints.fy[checkpoints.fn] = getint("fix", string, 3);
                    contos[nob].elec = true;
                    if(getint("fix", string, 4) != 0)
                    {
                        checkpoints.roted[checkpoints.fn] = true;
                        contos[nob].roted = true;
                    } else
                    {
                        checkpoints.roted[checkpoints.fn] = false;
                    }
                    if(string.indexOf(")s") != -1)
                        checkpoints.special[checkpoints.fn] = true;
                    else
                        checkpoints.special[checkpoints.fn] = false;
                    checkpoints.fn++;
                    nob++;
                    notb = nob;
                }
                if(!checkpoints.notb && string.startsWith("pile"))
                {
                    contos[nob] = new ContO(getint("pile", string, 0), getint("pile", string, 1), getint("pile", string, 2), medium, trackers, getint("pile", string, 3), getint("pile", string, 4), medium.ground);
                    nob++;
                }
                if(xt.multion == 0 && string.startsWith("nlaps"))
                {
                    checkpoints.nlaps = getint("nlaps", string, 0);
                    if(checkpoints.nlaps < 1)
                        checkpoints.nlaps = 1;
                    if(checkpoints.nlaps > 15)
                        checkpoints.nlaps = 15;
                }
                if(checkpoints.stage > 0 && string.startsWith("name"))
                    checkpoints.name = getstring("name", string, 0).replace('|', ',');
                if(string.startsWith("stagemaker"))
                    checkpoints.maker = getstring("stagemaker", string, 0);
                if(string.startsWith("publish"))
                    checkpoints.pubt = getint("publish", string, 0);
                if(string.startsWith("soundtrack"))
                {
                    checkpoints.trackname = getstring("soundtrack", string, 0);
                    checkpoints.trackvol = getint("soundtrack", string, 1);
                    if(checkpoints.trackvol < 50)
                        checkpoints.trackvol = 50;
                    if(checkpoints.trackvol > 300)
                        checkpoints.trackvol = 300;
                    xt.sndsize[32] = getint("soundtrack", string, 2);
                }
                if(string.startsWith("maxr"))
                {
                    int i_128 = getint("maxr", string, 0);
                    int i_129 = getint("maxr", string, 1);
                    i = i_129;
                    int i_130 = getint("maxr", string, 2);
                    for(int i_131 = 0; i_131 < i_128; i_131++)
                    {
                        contos[nob] = new ContO(contos_108[85], i_129, medium.ground - contos_108[85].grat, i_131 * 4800 + i_130, 0);
                        nob++;
                    }

                    trackers.y[trackers.nt] = -5000;
                    trackers.rady[trackers.nt] = 7100;
                    trackers.x[trackers.nt] = i_129 + 500;
                    trackers.radx[trackers.nt] = 600;
                    trackers.z[trackers.nt] = ((i_128 * 4800) / 2 + i_130) - 2400;
                    trackers.radz[trackers.nt] = (i_128 * 4800) / 2;
                    trackers.xy[trackers.nt] = 90;
                    trackers.zy[trackers.nt] = 0;
                    trackers.dam[trackers.nt] = 167;
                    trackers.decor[trackers.nt] = false;
                    trackers.skd[trackers.nt] = 0;
                    trackers.nt++;
                }
                if(string.startsWith("maxl"))
                {
                    int i_132 = getint("maxl", string, 0);
                    int i_133 = getint("maxl", string, 1);
                    i_109 = i_133;
                    int i_134 = getint("maxl", string, 2);
                    for(int i_135 = 0; i_135 < i_132; i_135++)
                    {
                        contos[nob] = new ContO(contos_108[85], i_133, medium.ground - contos_108[85].grat, i_135 * 4800 + i_134, 180);
                        nob++;
                    }

                    trackers.y[trackers.nt] = -5000;
                    trackers.rady[trackers.nt] = 7100;
                    trackers.x[trackers.nt] = i_133 - 500;
                    trackers.radx[trackers.nt] = 600;
                    trackers.z[trackers.nt] = ((i_132 * 4800) / 2 + i_134) - 2400;
                    trackers.radz[trackers.nt] = (i_132 * 4800) / 2;
                    trackers.xy[trackers.nt] = -90;
                    trackers.zy[trackers.nt] = 0;
                    trackers.dam[trackers.nt] = 167;
                    trackers.decor[trackers.nt] = false;
                    trackers.skd[trackers.nt] = 0;
                    trackers.nt++;
                }
                if(string.startsWith("maxt"))
                {
                    int i_136 = getint("maxt", string, 0);
                    int i_137 = getint("maxt", string, 1);
                    i_110 = i_137;
                    int i_138 = getint("maxt", string, 2);
                    for(int i_139 = 0; i_139 < i_136; i_139++)
                    {
                        contos[nob] = new ContO(contos_108[85], i_139 * 4800 + i_138, medium.ground - contos_108[85].grat, i_137, 90);
                        nob++;
                    }

                    trackers.y[trackers.nt] = -5000;
                    trackers.rady[trackers.nt] = 7100;
                    trackers.z[trackers.nt] = i_137 + 500;
                    trackers.radz[trackers.nt] = 600;
                    trackers.x[trackers.nt] = ((i_136 * 4800) / 2 + i_138) - 2400;
                    trackers.radx[trackers.nt] = (i_136 * 4800) / 2;
                    trackers.zy[trackers.nt] = 90;
                    trackers.xy[trackers.nt] = 0;
                    trackers.dam[trackers.nt] = 167;
                    trackers.decor[trackers.nt] = false;
                    trackers.skd[trackers.nt] = 0;
                    trackers.nt++;
                }
                if(string.startsWith("maxb"))
                {
                    int i_140 = getint("maxb", string, 0);
                    int i_141 = getint("maxb", string, 1);
                    i_111 = i_141;
                    int i_142 = getint("maxb", string, 2);
                    for(int i_143 = 0; i_143 < i_140; i_143++)
                    {
                        contos[nob] = new ContO(contos_108[85], i_143 * 4800 + i_142, medium.ground - contos_108[85].grat, i_141, -90);
                        nob++;
                    }

                    trackers.y[trackers.nt] = -5000;
                    trackers.rady[trackers.nt] = 7100;
                    trackers.z[trackers.nt] = i_141 - 500;
                    trackers.radz[trackers.nt] = 600;
                    trackers.x[trackers.nt] = ((i_140 * 4800) / 2 + i_142) - 2400;
                    trackers.radx[trackers.nt] = (i_140 * 4800) / 2;
                    trackers.zy[trackers.nt] = -90;
                    trackers.xy[trackers.nt] = 0;
                    trackers.dam[trackers.nt] = 167;
                    trackers.decor[trackers.nt] = false;
                    trackers.skd[trackers.nt] = 0;
                    trackers.nt++;
                }
            } while(true);
            if(checkpoints.stage > 0)
                xt.sumid[checkpoints.stage - 1] += checkpoints.nlaps;
            datainputstream.close();
            medium.newpolys(i_109, i - i_109, i_111, i_110 - i_111, trackers, notb);
            medium.newclouds(i_109, i, i_111, i_110);
            medium.newmountains(i_109, i, i_111, i_110);
            medium.newstars();
            trackers.devidetrackers(i_109, i - i_109, i_111, i_110 - i_111);
        }
        catch(Exception exception)
        {
            checkpoints.stage = -3;
            System.out.println((new StringBuilder()).append("Error in stage ").append(checkpoints.stage).toString());
            System.out.println((new StringBuilder()).append("").append(exception).toString());
            System.out.println((new StringBuilder()).append("At line: ").append(string).toString());
        }
        if(checkpoints.nsp < 2)
            checkpoints.stage = -3;
        if(medium.nrw * medium.ncl >= 16000)
            checkpoints.stage = -3;
        if(checkpoints.stage != -3)
        {
            checkpoints.top20 = Math.abs(checkpoints.top20);
            if(checkpoints.stage == 26)
                medium.lightn = 0;
            else
                medium.lightn = -1;
            if(checkpoints.stage == 1 || checkpoints.stage == 11)
                medium.nochekflk = false;
            else
                medium.nochekflk = true;
            for(int i_144 = 0; i_144 < xt.nplayers; i_144++)
                u[i_144].reset(checkpoints, xt.sc[i_144]);

            xt.resetstat(checkpoints.stage);
            checkpoints.calprox();
            for(int i_145 = 0; i_145 < xt.nplayers; i_145++)
            {
                if(xt.fase == 22)
                    xt.colorCar(contos_108[xt.sc[i_145]], i_145);
                contos[i_145] = new ContO(contos_108[xt.sc[i_145]], xt.xstart[i_145], 250 - contos_108[xt.sc[i_145]].grat, xt.zstart[i_145], 0);
                mads[i_145].reseto(xt.sc[i_145], contos[i_145], checkpoints);
            }

            if(xt.fase == 2 || xt.fase == -22)
            {
                medium.trx = (i_109 + i) / 2;
                medium.trz = (i_110 + i_111) / 2;
                medium.ptr = 0;
                medium.ptcnt = -10;
                medium.hit = 45000;
                medium.fallen = 0;
                medium.nrnd = 0;
                medium.trk = 1;
                medium.ih = 25;
                medium.iw = 65;
                medium.h = 425;
                medium.w = 735;
                xt.fase = 1;
                mouses = 0;
            }
            if(xt.fase == 22)
            {
                medium.crs = false;
                xt.fase = 5;
            }
            if(checkpoints.stage > 0)
            {
                int i_146 = checkpoints.stage;
                if(i_146 > 27)
                    i_146 -= 27;
                else
                if(i_146 > 10)
                    i_146 -= 10;
                xt.asay = (new StringBuilder()).append("Stage ").append(i_146).append(":  ").append(checkpoints.name).append(" ").toString();
            } else
            {
                xt.asay = (new StringBuilder()).append("Custom Stage:  ").append(checkpoints.name).append(" ").toString();
            }
            record.reset(contos);
        } else
        if(xt.fase == 2)
            xt.fase = 1;
        System.gc();
    }

    public boolean loadstagePreview(int i, String string, ContO contos[], ContO contos_147[], Medium medium, CheckPoints checkpoints)
    {
        boolean bool = true;
        if(i < 100)
        {
            checkpoints.stage = i;
            if(checkpoints.stage < 0)
                checkpoints.name = string;
        } else
        {
            checkpoints.stage = -2;
            if(sgame.getSelectedIndex() == 3 || sgame.getSelectedIndex() == 4)
            {
                checkpoints.name = mstgs.getSelectedItem();
            } else
            {
                int i_148 = mstgs.getSelectedItem().indexOf(" ") + 1;
                if(i_148 > 0)
                    checkpoints.name = mstgs.getSelectedItem().substring(i_148);
            }
        }
        nob = 0;
        checkpoints.n = 0;
        checkpoints.nsp = 0;
        checkpoints.fn = 0;
        checkpoints.haltall = false;
        checkpoints.wasted = 0;
        checkpoints.catchfin = 0;
        medium.ground = 250;
        view = 0;
        medium.trx = 0L;
        medium.trz = 0L;
        String string_149 = "";
        try
        {
            Object object = null;
            DataInputStream datainputstream;
            if(checkpoints.stage > 0)
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/stages/").append(checkpoints.stage).append(".txt").toString());
                datainputstream = new DataInputStream(url.openStream());
            } else
            {
                String string_150 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(URLEncoder.encode(checkpoints.name.replace(' ', '_'), "UTF-8")).append(".radq").toString();
                URL url = new URL(string_150);
                int i_151 = url.openConnection().getContentLength();
                DataInputStream datainputstream_152 = new DataInputStream(url.openStream());
                byte is[] = new byte[i_151];
                datainputstream_152.readFully(is);
                ZipInputStream zipinputstream;
                if(is[0] == 80 && is[1] == 75 && is[2] == 3)
                {
                    zipinputstream = new ZipInputStream(new ByteArrayInputStream(is));
                } else
                {
                    byte is_153[] = new byte[i_151 - 40];
                    for(int i_154 = 0; i_154 < i_151 - 40; i_154++)
                    {
                        int i_155 = 20;
                        if(i_154 >= 500)
                            i_155 = 40;
                        is_153[i_154] = is[i_154 + i_155];
                    }

                    zipinputstream = new ZipInputStream(new ByteArrayInputStream(is_153));
                }
                ZipEntry zipentry = zipinputstream.getNextEntry();
                int i_156 = Integer.valueOf(zipentry.getName()).intValue();
                byte is_157[] = new byte[i_156];
                int i_158 = 0;
                int i_159;
                for(; i_156 > 0; i_156 -= i_159)
                {
                    i_159 = zipinputstream.read(is_157, i_158, i_156);
                    i_158 += i_159;
                }

                zipinputstream.close();
                datainputstream_152.close();
                datainputstream = new DataInputStream(new ByteArrayInputStream(is_157));
            }
            do
            {
                String string_160;
                if((string_160 = datainputstream.readLine()) == null)
                    break;
                string_149 = (new StringBuilder()).append("").append(string_160.trim()).toString();
                if(string_149.startsWith("set"))
                {
                    int i_161 = getint("set", string_149, 0);
                    i_161 += 46;
                    contos[nob] = new ContO(contos_147[i_161], getint("set", string_149, 1), medium.ground - contos_147[i_161].grat, getint("set", string_149, 2), getint("set", string_149, 3));
                    if(string_149.indexOf(")p") != -1)
                    {
                        checkpoints.x[checkpoints.n] = getint("chk", string_149, 1);
                        checkpoints.z[checkpoints.n] = getint("chk", string_149, 2);
                        checkpoints.y[checkpoints.n] = 0;
                        checkpoints.typ[checkpoints.n] = 0;
                        if(string_149.indexOf(")pt") != -1)
                            checkpoints.typ[checkpoints.n] = -1;
                        if(string_149.indexOf(")pr") != -1)
                            checkpoints.typ[checkpoints.n] = -2;
                        if(string_149.indexOf(")po") != -1)
                            checkpoints.typ[checkpoints.n] = -3;
                        if(string_149.indexOf(")ph") != -1)
                            checkpoints.typ[checkpoints.n] = -4;
                        if(string_149.indexOf("out") != -1)
                            System.out.println((new StringBuilder()).append("out: ").append(checkpoints.n).toString());
                        checkpoints.n++;
                    }
                    nob++;
                }
                if(string_149.startsWith("chk"))
                {
                    int i_162 = getint("chk", string_149, 0);
                    i_162 += 46;
                    int i_163 = medium.ground - contos_147[i_162].grat;
                    if(i_162 == 110)
                        i_163 = getint("chk", string_149, 4);
                    contos[nob] = new ContO(contos_147[i_162], getint("chk", string_149, 1), i_163, getint("chk", string_149, 2), getint("chk", string_149, 3));
                    checkpoints.x[checkpoints.n] = getint("chk", string_149, 1);
                    checkpoints.z[checkpoints.n] = getint("chk", string_149, 2);
                    checkpoints.y[checkpoints.n] = i_163;
                    if(getint("chk", string_149, 3) == 0)
                        checkpoints.typ[checkpoints.n] = 1;
                    else
                        checkpoints.typ[checkpoints.n] = 2;
                    checkpoints.pcs = checkpoints.n;
                    checkpoints.n++;
                    contos[nob].checkpoint = checkpoints.nsp + 1;
                    checkpoints.nsp++;
                    nob++;
                }
                if(string_149.startsWith("fix"))
                {
                    int i_164 = getint("fix", string_149, 0);
                    i_164 += 46;
                    contos[nob] = new ContO(contos_147[i_164], getint("fix", string_149, 1), getint("fix", string_149, 3), getint("fix", string_149, 2), getint("fix", string_149, 4));
                    checkpoints.fx[checkpoints.fn] = getint("fix", string_149, 1);
                    checkpoints.fz[checkpoints.fn] = getint("fix", string_149, 2);
                    checkpoints.fy[checkpoints.fn] = getint("fix", string_149, 3);
                    contos[nob].elec = true;
                    if(getint("fix", string_149, 4) != 0)
                    {
                        checkpoints.roted[checkpoints.fn] = true;
                        contos[nob].roted = true;
                    } else
                    {
                        checkpoints.roted[checkpoints.fn] = false;
                    }
                    if(string_149.indexOf(")s") != -1)
                        checkpoints.special[checkpoints.fn] = true;
                    else
                        checkpoints.special[checkpoints.fn] = false;
                    checkpoints.fn++;
                    nob++;
                }
                if(string_149.startsWith("nlaps"))
                {
                    checkpoints.nlaps = getint("nlaps", string_149, 0);
                    if(checkpoints.nlaps < 1)
                        checkpoints.nlaps = 1;
                    if(checkpoints.nlaps > 15)
                        checkpoints.nlaps = 15;
                }
                if(checkpoints.stage > 0 && string_149.startsWith("name"))
                    checkpoints.name = getstring("name", string_149, 0).replace('|', ',');
                if(string_149.startsWith("stagemaker"))
                    checkpoints.maker = getstring("stagemaker", string_149, 0);
                if(string_149.startsWith("publish"))
                    checkpoints.pubt = getint("publish", string_149, 0);
                if(string_149.startsWith("maxr"))
                {
                    int i_165 = getint("maxr", string_149, 1);
                    medium.trx += i_165;
                }
                if(string_149.startsWith("maxl"))
                {
                    int i_166 = getint("maxl", string_149, 1);
                    medium.trx += i_166;
                }
                if(string_149.startsWith("maxt"))
                {
                    int i_167 = getint("maxt", string_149, 1);
                    medium.trz += i_167;
                }
                if(string_149.startsWith("maxb"))
                {
                    int i_168 = getint("maxb", string_149, 1);
                    medium.trz += i_168;
                }
            } while(true);
            datainputstream.close();
        }
        catch(Exception exception)
        {
            bool = false;
            System.out.println((new StringBuilder()).append("Error in stage ").append(checkpoints.stage).toString());
            System.out.println((new StringBuilder()).append("").append(exception).toString());
            System.out.println((new StringBuilder()).append("At line: ").append(string_149).toString());
        }
        if(checkpoints.nsp < 2)
            bool = false;
        medium.trx = medium.trx / 2L;
        medium.trz = medium.trz / 2L;
        System.gc();
        return bool;
    }

    public void loadbase(ContO contos[], Medium medium, Trackers trackers, xtGraphics xt, boolean bool)
    {
        String strings[] = {
            "2000tornados", "formula7", "canyenaro", "lescrab", "nimi", "maxrevenge", "leadoxide", "koolkat", "drifter", "policecops", 
            "mustang", "king", "audir8", "masheen", "radicalone", "drmonster"
        };
        String strings_169[] = {
            "road", "froad", "twister2", "twister1", "turn", "offroad", "bumproad", "offturn", "nroad", "nturn", 
            "roblend", "noblend", "rnblend", "roadend", "offroadend", "hpground", "ramp30", "cramp35", "dramp15", "dhilo15", 
            "slide10", "takeoff", "sramp22", "offbump", "offramp", "sofframp", "halfpipe", "spikes", "rail", "thewall", 
            "checkpoint", "fixpoint", "offcheckpoint", "sideoff", "bsideoff", "uprise", "riseroad", "sroad", "soffroad", "tside", 
            "launchpad", "thenet", "speedramp", "offhill", "slider", "uphill", "roll1", "roll2", "roll3", "roll4", 
            "roll5", "roll6", "opile1", "opile2", "aircheckpoint", "tree1", "tree2", "tree3", "tree4", "tree5", 
            "tree6", "tree7", "tree8", "cac1", "cac2", "cac3", "8sroad", "8soffroad"
        };
        int i = 0;
        xt.dnload += 6;
        try
        {
            Object object = null;
            ZipInputStream zipinputstream;
            if(!bool)
            {
                File file = new File("data/models.zip");
                zipinputstream = new ZipInputStream(new FileInputStream(file));
            } else
            {
                URL url = new URL("http://multiplayer.needformadness.com/data/models.zip");
                zipinputstream = new ZipInputStream(url.openStream());
            }
            ZipEntry zipentry = zipinputstream.getNextEntry();
            Object object_170 = null;
            for(; zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i_171 = 0;
                for(int i_172 = 0; i_172 < 16; i_172++)
                    if(zipentry.getName().startsWith(strings[i_172]))
                        i_171 = i_172;

                for(int i_173 = 0; i_173 < 68; i_173++)
                    if(zipentry.getName().startsWith(strings_169[i_173]))
                        i_171 = i_173 + 56;

                int i_174 = (int)zipentry.getSize();
                i += i_174;
                byte is[] = new byte[i_174];
                int i_175 = 0;
                int i_176;
                for(; i_174 > 0; i_174 -= i_176)
                {
                    i_176 = zipinputstream.read(is, i_175, i_174);
                    i_175 += i_176;
                }

                contos[i_171] = new ContO(is, medium, trackers);
                xt.dnload++;
            }

            zipinputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Reading Models: ").append(exception).toString());
        }
        System.gc();
        if(mload != -1 && i != 0x964f7)
            mload = 2;
    }

    public static int getint(String string, String string_177, int i)
    {
        int i_178 = 0;
        String string_179 = "";
        for(int i_180 = string.length() + 1; i_180 < string_177.length(); i_180++)
        {
            String string_181 = (new StringBuilder()).append("").append(string_177.charAt(i_180)).toString();
            if(string_181.equals(",") || string_181.equals(")"))
            {
                i_178++;
                i_180++;
            }
            if(i_178 == i)
                string_179 = (new StringBuilder()).append(string_179).append(string_177.charAt(i_180)).toString();
        }

        return Integer.valueOf(string_179).intValue();
    }

    public String getstring(String string, String string_182, int i)
    {
        int i_183 = 0;
        String string_184 = "";
        for(int i_185 = string.length() + 1; i_185 < string_182.length(); i_185++)
        {
            String string_186 = (new StringBuilder()).append("").append(string_182.charAt(i_185)).toString();
            if(string_186.equals(",") || string_186.equals(")"))
            {
                i_183++;
                i_185++;
            }
            if(i_183 == i)
                string_184 = (new StringBuilder()).append(string_184).append(string_182.charAt(i_185)).toString();
        }

        return string_184;
    }

    public void start()
    {
        if(gamer == null)
            gamer = new Thread(this);
        gamer.start();
    }

    public void stop()
    {
        if(exwist && gamer != null)
        {
            System.gc();
            gamer.stop();
            gamer = null;
        }
        exwist = true;
    }

    public static void savePreferences()
    {
        try
        {
            File file = new File("data/prefs.data");
            String strings[] = {
                "", "", "", "", "", "", "", "", "", "", 
                "", "", "", ""
            };
            strings[0] = (new StringBuilder()).append("glasson(").append(Madness.glasson ? 1 : 0).append(")").toString();
            strings[1] = (new StringBuilder()).append("speedon(").append(Madness.speedon).append(")").toString();
            strings[2] = (new StringBuilder()).append("modon(").append(Madness.modon).append(")").toString();
            strings[3] = (new StringBuilder()).append("chronon(").append(Madness.chronon).append(")").toString();
            strings[4] = (new StringBuilder()).append("landscp(").append(Madness.landscp ? 1 : 0).append(")").toString();
            strings[5] = (new StringBuilder()).append("hidemod(").append(Madness.hidemod ? 1 : 0).append(")").toString();
            strings[6] = (new StringBuilder()).append("graphs(").append(Madness.graphs).append(")").toString();
            strings[7] = (new StringBuilder()).append("position(").append(Madness.poson).append(")").toString();
            strings[8] = (new StringBuilder()).append("arrow(").append(Madness.arrowon).append(")").toString();
            strings[9] = (new StringBuilder()).append("stats(").append(Madness.staton).append(")").toString();
            strings[10] = (new StringBuilder()).append("blur(").append(Madness.bluron ? 1 : 0).append(")").toString();
            strings[11] = (new StringBuilder()).append("keyon(").append(Madness.keyon ? 1 : 0).append(")").toString();
            strings[12] = (new StringBuilder()).append("fade(").append(Madness.fade).append(")").toString();
            strings[13] = (new StringBuilder()).append("color(").append(GadgetPainter.ci).append(")").toString();
            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
            for(int j = 0; j < 14; j++)
            {
                bufferedwriter.write(strings[j]);
                bufferedwriter.newLine();
            }

            bufferedwriter.close();
        }
        catch(Exception exception) { }
    }

    public static void loadPreferences()
    {
        try
        {
            File file = new File("data/prefs.data");
            String strings[] = {
                "", "", "", "", "", "", "", "", "", "", 
                "", "", "", ""
            };
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string;
                for(int i = 0; (string = bufferedreader.readLine()) != null && i < 14; i++)
                    strings[i] = string;

                bufferedreader.close();
            }
            if(strings[0].startsWith("glasson"))
            {
                int i = getint("glasson", strings[0], 0);
                Madness.glasson = i == 1;
            }
            if(strings[1].startsWith("speedon"))
            {
                int i = getint("speedon", strings[1], 0);
                if(i >= 0)
                    Madness.speedon = i;
                else
                    Madness.speedon = 1;
            }
            if(strings[2].startsWith("modon"))
            {
                int i = getint("modon", strings[2], 0);
                if(i >= 0)
                    Madness.modon = i;
                else
                    Madness.modon = 1;
            }
            if(strings[3].startsWith("chronon"))
            {
                int i = getint("chronon", strings[3], 0);
                if(i >= 0)
                    Madness.chronon = i;
                else
                    Madness.chronon = 1;
            }
            if(strings[4].startsWith("landscp"))
            {
                int i = getint("landscp", strings[4], 0);
                Madness.landscp = i == 1;
            }
            if(strings[5].startsWith("hidemod"))
            {
                int i = getint("hidemod", strings[5], 0);
                Madness.hidemod = i == 1;
            }
            if(strings[6].startsWith("graphs"))
            {
                int i = getint("graphs", strings[6], 0);
                if(i >= 0)
                    Madness.ographs = Madness.graphs = i;
                else
                    Madness.ographs = Madness.graphs = 1;
            }
            if(strings[7].startsWith("position"))
            {
                int i = getint("position", strings[7], 0);
                if(i >= 0)
                    Madness.poson = i;
                else
                    Madness.poson = 0;
            }
            if(strings[8].startsWith("arrow"))
            {
                int i = getint("arrow", strings[8], 0);
                if(i >= 0)
                    Madness.arrowon = i;
                else
                    Madness.arrowon = 0;
            }
            if(strings[9].startsWith("stats"))
            {
                int i = getint("stats", strings[9], 0);
                if(i >= 0)
                    Madness.staton = i;
                else
                    Madness.staton = 0;
            }
            if(strings[10].startsWith("blur"))
            {
                int i = getint("blur", strings[10], 0);
                Madness.bluron = i == 1;
            }
            if(strings[11].startsWith("keyon"))
            {
                int i = getint("keyon", strings[11], 0);
                Madness.keyon = i == 1;
            }
            if(strings[12].startsWith("fade"))
            {
                int i = getint("fade", strings[12], 0);
                Madness.fade = i;
            }
            if(strings[13].startsWith("color"))
            {
                int i = getint("color", strings[13], 0);
                GadgetPainter.ci = i;
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public void setcarcookie(int i, String string, float fs[], int i_187, int is[], boolean bool)
    {
        try
        {
            File file = new File("data/user.data");
            String strings[] = {
                "", "", "", "", ""
            };
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string_188;
                for(int i_189 = 0; (string_188 = bufferedreader.readLine()) != null && i_189 < 5; i_189++)
                    strings[i_189] = string_188;

                bufferedreader.close();
            }
            if(i_187 == 0)
                strings[1] = (new StringBuilder()).append("lastcar(").append(i).append(",").append((int)(fs[0] * 100F)).append(",").append((int)(fs[1] * 100F)).append(",").append((int)(fs[2] * 100F)).append(",").append((int)(fs[3] * 100F)).append(",").append((int)(fs[4] * 100F)).append(",").append((int)(fs[5] * 100F)).append(",").append(string).append(")").toString();
            if(i_187 == 1)
                strings[2] = (new StringBuilder()).append("NFM1(").append(i).append(",").append(is[0]).append(")").toString();
            if(i_187 == 2)
                strings[3] = (new StringBuilder()).append("NFM2(").append(i).append(",").append(is[1]).append(")").toString();
            strings[4] = (new StringBuilder()).append("graphics(").append(moto).append(",").append(Madness.anti).append(")").toString();
            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
            for(int i_191 = 0; i_191 < 5; i_191++)
            {
                bufferedwriter.write(strings[i_191]);
                bufferedwriter.newLine();
            }

            bufferedwriter.close();
        }
        catch(Exception exception) { }
    }

    public void setloggedcookie()
    {
        try
        {
            File file = new File("data/user.data");
            String strings[] = {
                "", "", "", "", ""
            };
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string;
                for(int i = 0; (string = bufferedreader.readLine()) != null && i < 5; i++)
                    strings[i] = string;

                bufferedreader.close();
            }
            if(keplo.getState())
                strings[0] = (new StringBuilder()).append("lastuser(").append(tnick.getText()).append(",").append(tpass.getText()).append(")").toString();
            else
                strings[0] = (new StringBuilder()).append("lastuser(").append(tnick.getText()).append(")").toString();
            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
            for(int i = 0; i < 5; i++)
            {
                bufferedwriter.write(strings[i]);
                bufferedwriter.newLine();
            }

            bufferedwriter.close();
        }
        catch(Exception exception) { }
    }

    public void readcookies(xtGraphics xt, CarDefine cardefine, ContO contos[])
    {
        xt.nickname = "";
        try
        {
            File file = new File("data/user.data");
            String strings[] = {
                "", "", "", "", ""
            };
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string;
                for(int i = 0; (string = bufferedreader.readLine()) != null && i < 5; i++)
                    strings[i] = string;

                bufferedreader.close();
            }
            if(strings[0].startsWith("lastuser"))
            {
                xt.nickname = getstring("lastuser", strings[0], 0);
                String string = "";
                try
                {
                    string = getstring("lastuser", strings[0], 1);
                }
                catch(Exception exception)
                {
                    string = "";
                }
                if(!string.equals(""))
                {
                    tnick.setText(xt.nickname);
                    tpass.setText(string);
                    xt.autolog = true;
                }
            }
            if(strings[2].startsWith("NFM1"))
            {
                int i = getint("NFM1", strings[2], 0);
                if(i >= 0 && i < 16)
                {
                    xt.scm[0] = i;
                    xt.firstime = false;
                }
                i = getint("NFM1", strings[2], 1);
                if(i >= 1 && i <= 11)
                    xt.unlocked[0] = i;
            }
            if(strings[3].startsWith("NFM2"))
            {
                int i = getint("NFM2", strings[3], 0);
                if(i >= 0 && i < 16)
                {
                    xt.scm[1] = i;
                    xt.firstime = false;
                }
                i = getint("NFM2", strings[3], 1);
                if(i >= 1 && i <= 17)
                    xt.unlocked[1] = i;
            }
            if(strings[4].startsWith("graphics"))
            {
                int i = getint("graphics", strings[4], 0);
                if(i >= 0 && i <= 1)
                    moto = i;
                i = getint("graphics", strings[4], 1);
                if(i >= 0 && i <= 1)
                    Madness.anti = i;
            }
            if(strings[1].startsWith("lastcar"))
            {
                int i = getint("lastcar", strings[1], 0);
                cardefine.lastcar = getstring("lastcar", strings[1], 7);
                if(i >= 0 && i < 36)
                {
                    xt.osc = i;
                    xt.firstime = false;
                }
                int i_194 = 0;
                for(int i_195 = 0; i_195 < 6; i_195++)
                {
                    i = getint("lastcar", strings[1], i_195 + 1);
                    if(i >= 0 && i <= 100)
                    {
                        xt.arnp[i_195] = (float)i / 100F;
                        i_194++;
                    }
                }

                if(i_194 == 6 && xt.osc >= 0 && xt.osc <= 15)
                {
                    Color color = Color.getHSBColor(xt.arnp[0], xt.arnp[1], 1.0F - xt.arnp[2]);
                    Color color_196 = Color.getHSBColor(xt.arnp[3], xt.arnp[4], 1.0F - xt.arnp[5]);
                    for(int i_197 = 0; i_197 < contos[xt.osc].npl; i_197++)
                        if(contos[xt.osc].p[i_197].colnum == 1)
                        {
                            contos[xt.osc].p[i_197].c[0] = color.getRed();
                            contos[xt.osc].p[i_197].c[1] = color.getGreen();
                            contos[xt.osc].p[i_197].c[2] = color.getBlue();
                        }

                    for(int i_198 = 0; i_198 < contos[xt.osc].npl; i_198++)
                        if(contos[xt.osc].p[i_198].colnum == 2)
                        {
                            contos[xt.osc].p[i_198].c[0] = color_196.getRed();
                            contos[xt.osc].p[i_198].c[1] = color_196.getGreen();
                            contos[xt.osc].p[i_198].c[2] = color_196.getBlue();
                        }

                }
            }
        }
        catch(Exception exception) { }
    }

    public void regprom()
    {
    }

    public boolean mouseUp(Event event, int i, int i_199)
    {
        if(!exwist)
        {
            if(mouses == 11)
            {
                xm = (int)((float)(i - apx) / apmult);
                ym = (int)((float)(i_199 - apy) / apmult);
                mouses = -1;
            }
            moused = false;
        }
        if(!Madness.fullscreen)
        {
            if(i > getWidth() / 2 - 55 && i < getWidth() / 2 + 7 && i_199 > 21 && i_199 < 38 && !onbar)
            {
                if(smooth == 1)
                    smooth = 0;
                else
                    smooth = 1;
                showsize = 60;
            }
            if(i > getWidth() / 2 + 133 && i < getWidth() / 2 + 231 && i_199 > 7 && i_199 < 24 && !onbar)
            {
                if(Madness.anti == 0)
                    Madness.anti = 1;
                else
                    Madness.anti = 0;
                showsize = 60;
            }
            if(i > getWidth() / 2 + 133 && i < getWidth() / 2 + 231 && i_199 > 24 && i_199 < 41 && !onbar)
            {
                if(moto == 0)
                    moto = 1;
                else
                    moto = 0;
                showsize = 60;
            }
            if(oncarm)
                Madness.carmaker();
            if(onstgm)
                Madness.stagemaker();
            if(onfulls)
                Madness.gofullscreen();
            onbar = false;
        }
        return false;
    }

    public boolean mouseDown(Event event, int i, int i_200)
    {
        requestFocus();
        if(!exwist)
        {
            if(mouses == 0)
            {
                xm = (int)((float)(i - apx) / apmult);
                ym = (int)((float)(i_200 - apy) / apmult);
                mouses = 1;
            }
            moused = true;
        }
        if(!Madness.fullscreen)
            sizescreen(i, i_200);
        return false;
    }

    public boolean mouseMove(Event event, int i, int i_201)
    {
        if(!exwist && !lostfcs)
        {
            xm = (int)((float)(i - apx) / apmult);
            ym = (int)((float)(i_201 - apy) / apmult);
        }
        if(!Madness.fullscreen)
        {
            if(showsize < 20)
                showsize = 20;
            if(i > 50 && i < 192 && i_201 > 14 && i_201 < 37)
            {
                if(!oncarm)
                {
                    oncarm = true;
                    setCursor(new Cursor(12));
                }
            } else
            if(oncarm)
            {
                oncarm = false;
                setCursor(new Cursor(0));
            }
            if(i > getWidth() - 208 && i < getWidth() - 50 && i_201 > 14 && i_201 < 37)
            {
                if(!onstgm)
                {
                    onstgm = true;
                    setCursor(new Cursor(12));
                }
            } else
            if(onstgm)
            {
                onstgm = false;
                setCursor(new Cursor(0));
            }
            if(i > getWidth() / 2 + 22 && i < getWidth() / 2 + 122 && i_201 > 14 && i_201 < 37)
            {
                if(!onfulls)
                {
                    onfulls = true;
                    setCursor(new Cursor(12));
                }
            } else
            if(onfulls)
            {
                onfulls = false;
                setCursor(new Cursor(0));
            }
        }
        return false;
    }

    public boolean mouseDrag(Event event, int i, int i_202)
    {
        if(!exwist && !lostfcs)
        {
            xm = (int)((float)(i - apx) / apmult);
            ym = (int)((float)(i_202 - apy) / apmult);
        }
        if(!Madness.fullscreen)
            sizescreen(i, i_202);
        return false;
    }

    public boolean lostFocus(Event event, Object object)
    {
        if(!exwist && !lostfcs)
        {
            lostfcs = true;
            fcscnt = 10;
            if(u[0] != null)
            {
                if(u[0].multion == 0)
                    u[0].falseo(1);
                else
                if(u[0].chatup == 0)
                    requestFocus();
                setCursor(new Cursor(0));
            }
        }
        return false;
    }

    public boolean gotFocus(Event event, Object object)
    {
        if(!exwist && lostfcs)
            lostfcs = false;
        return false;
    }

    public void mouseW(int i)
    {
        if(!exwist)
            mousew += i * 4;
    }

    public void sizescreen(int i, int i_203)
    {
        if(i > getWidth() / 2 - 230 && i < getWidth() / 2 - 68 && i_203 > 21 && i_203 < 39 || onbar)
        {
            reqmult = (float)(i - (getWidth() / 2 - 222)) / 141F;
            if((double)reqmult < 0.10000000000000001D)
                reqmult = 0.0F;
            if(reqmult > 1.0F)
                reqmult = 1.0F;
            onbar = true;
            showsize = 100;
        }
    }

    public void catchlink()
    {
        if(!lostfcs)
            if(xm > 65 && xm < 735 && ym > 135 && ym < 194 || xm > 275 && xm < 525 && ym > 265 && ym < 284)
            {
                setCursor(new Cursor(12));
                if(mouses == 2)
                    openurl("http://www.radicalplay.com/");
            } else
            {
                setCursor(new Cursor(0));
            }
    }

    public void customlink(String string, int x, int y, int w)
    {
        if(!lostfcs && xm > x && xm < x + w && ym > y - 12 && ym < y + 2 && mouses == 1)
        {
            if(string.startsWith("http://") || string.startsWith("https://"))
                openurl(string);
            else
                openurl((new StringBuilder()).append("http://").append(string).toString());
            postMessage("Opening URL...");
            msgc = 50;
            mouses = 0;
        }
    }

    public void musiclink()
    {
        openurl("http://multiplayer.needformadness.com/music.html");
    }

    public void reglink()
    {
        openurl("http://multiplayer.needformadness.com/register.html?ref=game");
    }

    public void madlink()
    {
        openurl("http://www.needformadness.com/");
    }

    public void editlink(String string, boolean bool)
    {
        String string_204 = "";
        if(bool)
            string_204 = "?display=upgrade";
        openurl((new StringBuilder()).append("http://multiplayer.needformadness.com/edit.pl").append(string_204).append("#").append(string).append("").toString());
    }

    public void multlink()
    {
        openurl("http://multiplayer.needformadness.com/");
    }

    public void regnew()
    {
        openurl("http://multiplayer.needformadness.com/registernew.pl");
    }

    public void setupini()
    {
        Madness.inisetup = true;
        try
        {
            File file = new File("Madness.ini");
            if(file.exists())
            {
                String strings[] = new String[40];
                int i = 0;
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string;
                for(; (string = bufferedreader.readLine()) != null && i < 40; i++)
                {
                    strings[i] = string;
                    if(strings[i].startsWith("Class Path"))
                        if(strings[i].indexOf("madapps.jar") != -1)
                            strings[i] = "Class Path=\\data\\madapps.jar;";
                        else
                            strings[i] = "Class Path=\\data\\madapp.jar;";
                    if(strings[i].startsWith("JRE Path"))
                        strings[i] = "JRE Path=data\\jre\\";
                }

                bufferedreader.close();
                Object object_205 = null;
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                for(int i_206 = 0; i_206 < i; i_206++)
                {
                    bufferedwriter.write(strings[i_206]);
                    bufferedwriter.newLine();
                }

                bufferedwriter.close();
            }
        }
        catch(Exception exception) { }
        Madness.inisetup = false;
    }

    public void openurl(String string)
    {
        if(Desktop.isDesktopSupported())
            try
            {
                Desktop.getDesktop().browse(new URI(string));
            }
            catch(Exception exception) { }
        else
            try
            {
                Runtime.getRuntime().exec((new StringBuilder()).append("").append(Madness.urlopen()).append(" ").append(string).append("").toString());
            }
            catch(Exception exception) { }
    }

    public boolean keyDown(Event event, int i)
    {
        if(!exwist)
        {
            if(u[0].multion < 2)
            {
                if(i == 1004)
                    u[0].up = true;
                if(i == 1005)
                    u[0].down = true;
                if(i == 1007)
                    u[0].right = true;
                if(i == 1006)
                    u[0].left = true;
                if(i == 32)
                    u[0].handb = true;
            }
            if(i == 10)
                u[0].enter = true;
            if(i == 27)
            {
                u[0].exit = true;
                if(u[0].chatup != 0)
                    u[0].chatup = 0;
            }
            if((i == 67 || i == 99) && u[0].multion != 0 && u[0].chatup == 0)
            {
                u[0].chatup = 2;
                view = 0;
            }
            if(u[0].chatup == 0)
            {
                if(i == 120 || i == 88)
                    u[0].lookback = -1;
                if(i == 122 || i == 90)
                    u[0].lookback = 1;
                if(i == 77 || i == 109)
                    if(u[0].mutem)
                        u[0].mutem = false;
                    else
                        u[0].mutem = true;
                if(i == 78 || i == 110)
                    if(u[0].mutes)
                        u[0].mutes = false;
                    else
                        u[0].mutes = true;
                if(i == 97 || i == 65)
                    if(u[0].arrace)
                        u[0].arrace = false;
                    else
                        u[0].arrace = true;
                if(i == 113 || i == 81)
                    u[0].radar = !u[0].radar;
                if(i == 118 || i == 86)
                {
                    view++;
                    if(view == 3)
                        view = 0;
                }
                if(Madness.keyon)
                {
                    if(i == 102 || i == 70)
                        u[0].chron = true;
                    if(i == 115 || i == 83)
                        u[0].spd = true;
                    if(i == 100 || i == 68)
                        u[0].mod = true;
                    if(i == 119 || i == 87)
                        u[0].pos = true;
                    if(i == 101 || i == 69)
                        u[0].arr = true;
                    if(i == 114 || i == 82)
                        u[0].dampwr = true;
                }
                if(i == 1015)
                    u[0].chatquit = true;
            }
            if(i == 1019)
                Madness.sshot = true;
        }
        return false;
    }

    public boolean keyUp(Event event, int i)
    {
        if(!exwist)
        {
            if(u[0].multion < 2)
            {
                if(i == 1004)
                    u[0].up = false;
                if(i == 1005)
                    u[0].down = false;
                if(i == 1007)
                    u[0].right = false;
                if(i == 1006)
                    u[0].left = false;
                if(i == 32)
                    u[0].handb = false;
            }
            if(i == 27)
            {
                u[0].exit = false;
                if(Madness.fullscreen)
                    Madness.exitfullscreen();
            }
            if(i == 120 || i == 88 || i == 122 || i == 90)
                u[0].lookback = 0;
            if(i == 102 || i == 70)
                u[0].chron = false;
            if(i == 115 || i == 83)
                u[0].spd = false;
            if(i == 100 || i == 68)
                u[0].mod = false;
            if(i == 119 || i == 87)
                u[0].pos = false;
            if(i == 101 || i == 69)
                u[0].arr = false;
            if(i == 114 || i == 82)
                u[0].dampwr = false;
            if(i == 1015)
                u[0].chatquit = false;
            if(i == 1009)
                Madness.switchMenuBar();
            if(i == 1018)
            {
                Madness.gui = !Madness.gui;
                postMessage(Madness.gui ? "Game UI showing" : "Game UI hidden", 60);
            }
        }
        return false;
    }

    public static void postMessage(String str)
    {
        postMessage(str, 120);
    }

    public static void postMessage(String str, int len)
    {
        msg = str;
        msgc = len;
    }

    Graphics2D rd;
    Image offImage;
    Thread gamer;
    int mload;
    boolean exwist;
    int apx;
    int apy;
    float apmult;
    float reqmult;
    int smooth;
    int moto;
    int lastw;
    int lasth;
    boolean onbar;
    boolean oncarm;
    boolean onstgm;
    boolean onfulls;
    Image sizebar;
    Image blb;
    Image fulls;
    Image chkbx[];
    Image carmaker[];
    Image stagemaker[];
    int showsize;
    Control u[];
    int mouses;
    int xm;
    int ym;
    int mousew;
    boolean lostfcs;
    boolean moused;
    int fcscnt;
    int nob;
    int notb;
    int view;
    int mvect;
    int lmxz;
    int shaka;
    boolean applejava;
    TextField tnick;
    TextField tpass;
    TextField temail;
    TextField cmsg;
    TextArea mmsg;
    Checkbox mycar;
    Checkbox notp;
    Checkbox keplo;
    boolean openm;
    Smenu sgame;
    Smenu wgame;
    Smenu warb;
    Smenu pgame;
    Smenu vnpls;
    Smenu vtyp;
    Smenu snfmm;
    Smenu snfm1;
    Smenu snfm2;
    Smenu mstgs;
    Smenu mcars;
    Smenu slaps;
    Smenu snpls;
    Smenu snbts;
    Smenu swait;
    Smenu sclass;
    Smenu scars;
    Smenu sfix;
    Smenu gmode;
    Smenu rooms;
    Smenu sendtyp;
    Smenu senditem;
    Smenu clanlev;
    Smenu clcars;
    Smenu datat;
    Smenu ilaps;
    Smenu icars;
    Smenu mgmcars;
    Smenu mscores;
    static int msgc = 0;
    static String msg = "";

}
