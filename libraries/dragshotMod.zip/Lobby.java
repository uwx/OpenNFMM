// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Lobby.java

import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;
import javax.swing.ImageIcon;

public class Lobby
    implements Runnable
{

    public Lobby(Medium medium, Graphics2D graphics2d, Login login, Globe globe, xtGraphics var_xtGraphics, CarDefine cardefine, GameSparker gamesparker)
    {
        conon = 0;
        regnow = false;
        lanlogged = false;
        fase = 0;
        stage = 0;
        laps = 3;
        stagename = "";
        nfix = 0;
        notb = false;
        btn = 0;
        pbtn = 0;
        nflk = 0;
        ncnt = 0;
        rerr = 0;
        pback = 0;
        cflk = 0;
        sflk = 0;
        msg = "";
        lmsg = "| Searching/Waiting for other LAN Players |";
        opselect = 0;
        lloaded = false;
        npo = 0;
        pnames = new String[200];
        pcars = new int[200];
        pcarnames = new String[200];
        pclan = new String[200];
        pgames = new int[200];
        pcols = new float[200][6];
        prnpo = 0;
        prevloaded = -1;
        stuntname = "";
        lapsname = "";
        wastename = "";
        ngm = 0;
        gnum = new int[500];
        gstgn = new int[500];
        gstages = new String[500];
        gnlaps = new int[500];
        mnpls = new int[500];
        mnbts = new int[500];
        wait = new int[500];
        gcrs = new int[500];
        gclss = new int[500];
        gfx = new int[500];
        gntb = new int[500];
        gplyrs = new String[500];
        gwarb = new int[500];
        gwarbnum = new String[500];
        gameturn = new int[500];
        gaclan = new String[500];
        gvclan = new String[500];
        gascore = new int[500];
        gvscore = new int[500];
        gwtyp = new int[500];
        gmaker = new String[500];
        npls = new int[500];
        ongame = -1;
        join = -1;
        chalngd = -1;
        im = 0;
        longame = -1;
        onjoin = -1;
        ontyp = 0;
        dispcar = -1;
        forcar = -1;
        addstage = 0;
        dispco = null;
        fstart = false;
        jflexo = false;
        chalby = "";
        ctime = 0;
        invo = false;
        updatec = -1;
        loadstage = 0;
        gstage = 0;
        gstagelaps = 0;
        gnpls = 8;
        gwait = 0;
        gnbts = 0;
        gclass = 0;
        gfix = 0;
        gnotp = 0;
        remstage = 0;
        msload = 0;
        sgflag = 0;
        gstagename = "";
        gplayers = "";
        inwab = false;
        loadwarb = false;
        warbsel = 0;
        cancreate = 0;
        pgamesel = 0;
        cntchkn = 0;
        spos = 0;
        spos2 = 0;
        spos3 = 28;
        mscro = 125;
        lspos = 0;
        mscro2 = 145;
        lspos2 = 0;
        mscro3 = 345;
        lspos3 = 0;
        clicked = -1;
        opengame = 0;
        britchl = 0;
        zeromsw = false;
        mousonp = -1;
        cmonp = -1;
        ptime = 0L;
        pcurs = 0;
        grprsd = false;
        pend = 0;
        mrot = 0;
        pendb = false;
        mousedout = false;
        flks = 0;
        waitlink = 0;
        pre1 = false;
        pre2 = false;
        prereq = 0;
        lxm = 0;
        lym = 0;
        m = medium;
        rd = graphics2d;
        xt = var_xtGraphics;
        cd = cardefine;
        gs = gamesparker;
        lg = login;
        gb = globe;
        gs.cmsg.setBackground(color2k(240, 240, 240));
        gs.swait.setBackground(color2k(220, 220, 220));
        gs.snpls.setBackground(color2k(220, 220, 220));
        gs.snbts.setBackground(color2k(220, 220, 220));
        gs.sgame.setBackground(color2k(200, 200, 200));
        gs.wgame.setBackground(color2k(200, 200, 200));
        gs.pgame.setBackground(color2k(200, 200, 200));
        gs.vnpls.setBackground(color2k(200, 200, 200));
        gs.vtyp.setBackground(color2k(200, 200, 200));
        gs.warb.setBackground(color2k(200, 200, 200));
        gs.snfmm.setBackground(color2k(200, 200, 200));
        gs.snfm1.setBackground(color2k(200, 200, 200));
        gs.snfm2.setBackground(color2k(200, 200, 200));
        gs.mstgs.setBackground(color2k(230, 230, 230));
        gs.slaps.setBackground(color2k(200, 200, 200));
        gs.sclass.setBackground(color2k(220, 220, 220));
        gs.scars.setBackground(color2k(220, 220, 220));
        gs.sfix.setBackground(color2k(220, 220, 220));
        gs.mycar.setBackground(color2k(255, 255, 255));
        gs.notp.setBackground(color2k(255, 255, 255));
        gs.rooms.setBackground(color2k(170, 170, 170));
        gs.swait.setForeground(new Color(0, 0, 0));
        gs.snpls.setForeground(new Color(0, 0, 0));
        gs.snbts.setForeground(new Color(0, 0, 0));
        gs.sgame.setForeground(new Color(0, 0, 0));
        gs.wgame.setForeground(new Color(0, 0, 0));
        gs.pgame.setForeground(new Color(0, 0, 0));
        gs.vnpls.setForeground(new Color(0, 0, 0));
        gs.vtyp.setForeground(new Color(0, 0, 0));
        gs.warb.setForeground(new Color(0, 0, 0));
        gs.snfmm.setForeground(new Color(0, 0, 0));
        gs.snfm1.setForeground(new Color(0, 0, 0));
        gs.slaps.setForeground(new Color(0, 0, 0));
        gs.snfm2.setForeground(new Color(0, 0, 0));
        gs.mstgs.setForeground(new Color(0, 0, 0));
        gs.sclass.setForeground(new Color(0, 0, 0));
        gs.scars.setForeground(new Color(0, 0, 0));
        gs.sfix.setForeground(new Color(0, 0, 0));
        gs.mycar.setForeground(new Color(0, 0, 0));
        gs.notp.setForeground(new Color(0, 0, 0));
        gs.rooms.setForeground(new Color(0, 0, 0));
        gs.sgame.removeAll();
        gs.sgame.add(rd, " NFM Multiplayer ");
        gs.sgame.add(rd, " NFM 2     ");
        gs.sgame.add(rd, " NFM 1     ");
        gs.sgame.add(rd, " My Stages ");
        gs.sgame.add(rd, " My Clan Stages ");
        gs.sgame.add(rd, " Weekly Top 20 ");
        gs.sgame.add(rd, " Monthly Top 20 ");
        lockicn = (new ImageIcon("data/lock.png")).getImage();
    }

    public void inishlobby()
    {
        gs.tnick.hide();
        gs.tpass.hide();
        gs.temail.hide();
        hideinputs();
        gs.mycar.setBackground(color2k(255, 255, 255));
        gs.mycar.setForeground(new Color(0, 0, 0));
        gs.rooms.removeAll();
        gs.rooms.add(rd, (new StringBuilder()).append("").append(xt.servername).append(" :: ").append(xt.servport - 7070).append("").toString());
        gs.rooms.select(0);
        gs.requestFocus();
        cd.loadready();
        for(int i = 0; i < 500; i++)
        {
            gnum[i] = -2;
            gstgn[i] = 0;
            gstages[i] = "";
            gnlaps[i] = 0;
            mnpls[i] = 0;
            mnbts[i] = 0;
            wait[i] = 0;
            gmaker[i] = "";
            gcrs[i] = 0;
            gclss[i] = 0;
            gfx[i] = 0;
            gntb[i] = 0;
            gplyrs[i] = "";
            npls[i] = 0;
            gwarb[i] = 0;
            gwarbnum[i] = "";
            gameturn[i] = 0;
            gaclan[i] = "";
            gvclan[i] = "";
            gascore[i] = 0;
            gvscore[i] = 0;
            gwtyp[i] = 0;
        }

        for(int i = 0; i < 200; i++)
        {
            pnames[i] = "";
            pcars[i] = 0;
            pcarnames[i] = "";
            pgames[i] = -1;
            pclan[i] = "";
            for(int i_0 = 0; i_0 < 6; i_0++)
                pcols[i][i_0] = 0.0F;

        }

        ongame = -1;
        join = -1;
        onjoin = -1;
        chalngd = -1;
        dispcar = -1;
        forcar = -1;
        chalby = "";
        im = 0;
        fstart = false;
        updatec = -1;
        prevloaded = -1;
        spos = 0;
        spos2 = 0;
        spos3 = 0;
        ngm = 0;
        npo = 0;
        fase = 1;
        lloaded = false;
        lg.gamec = -1;
        try
        {
            socket = new Socket(xt.server, xt.servport);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
        }
        catch(Exception exception) { }
        conon = 1;
        connector = new Thread(this);
        connector.start();
    }

    public void run()
    {
        int i = -1;
        while(conon == 1) 
        {
            Date date = new Date();
            long l = date.getTime();
            if(!lloaded)
                gs.setCursor(new Cursor(3));
            if(!xt.logged && !xt.lan && xt.nfreeplays - xt.ndisco >= 1)
            {
                if(join >= 0)
                {
                    join = -1;
                    regnow = true;
                }
                if(pgames[im] != -1)
                {
                    join = -2;
                    regnow = true;
                }
            }
            if((join >= 0 || pgames[im] != -1) && !regnow)
            {
                int i_1 = -1;
                for(int i_2 = 0; i_2 < ngm; i_2++)
                    if(join == gnum[i_2] || pgames[im] == gnum[i_2])
                        i_1 = i_2;

                if(i_1 != -1)
                {
                    boolean bool = false;
                    ontyp = 0;
                    if(gcrs[i_1] == 1 && pcars[im] < 16)
                    {
                        bool = true;
                        ontyp = 10;
                        if(gclss[i_1] > 0 && gclss[i_1] <= 5)
                            ontyp += gclss[i_1];
                    }
                    if(gcrs[i_1] == 2 && pcars[im] >= 16)
                    {
                        bool = true;
                        ontyp = 20;
                        if(gclss[i_1] > 0 && gclss[i_1] <= 5)
                            ontyp += gclss[i_1];
                    }
                    if(gcrs[i_1] == 1 && gwarb[i_1] != 0 && xt.sc[0] != 36)
                    {
                        bool = true;
                        ontyp = 30;
                        if(gclss[i_1] > 0 && gclss[i_1] <= 5)
                            ontyp += gclss[i_1];
                    }
                    if(gclss[i_1] > 0 && gclss[i_1] <= 5 && Math.abs(cd.cclass[pcars[im]] - (gclss[i_1] - 1)) > 1)
                    {
                        bool = true;
                        if(gcrs[i_1] == 1)
                            if(gwarb[i_1] == 0)
                                ontyp = 10;
                            else
                                ontyp = 30;
                        if(gcrs[i_1] == 2)
                            ontyp = 20;
                        ontyp += gclss[i_1];
                    }
                    if(gclss[i_1] <= -2 && pcars[im] != Math.abs(gclss[i_1] + 2))
                    {
                        bool = true;
                        ontyp = gclss[i_1];
                    }
                    if(gstgn[i_1] == -2 && !xt.logged)
                    {
                        bool = true;
                        ontyp = 76;
                    }
                    if(bool)
                    {
                        onjoin = gnum[i_1];
                        jflexo = false;
                        if(join >= 0)
                            join = -1;
                        if(pgames[im] != -1)
                            join = -2;
                    }
                }
            }
            if(xt.onjoin != -1)
            {
                join = xt.onjoin;
                ongame = xt.onjoin;
                xt.onjoin = -1;
            }
            if(updatec < -17)
                updatec = -17;
            boolean bool = false;
            if(lloaded)
            {
                i = pgames[im];
                if(i != -1)
                {
                    for(int i_3 = 0; i_3 < ngm; i_3++)
                    {
                        if(i != gnum[i_3])
                            continue;
                        laps = gnlaps[i_3];
                        stage = gstgn[i_3];
                        stagename = gstages[i_3];
                        nfix = gfx[i_3];
                        if(gntb[i_3] == 1)
                            notb = true;
                        else
                            notb = false;
                    }

                }
            }
            String string = (new StringBuilder()).append("").append(xt.sc[0]).append("").toString();
            if(xt.sc[0] >= 16)
                string = (new StringBuilder()).append("C").append(cd.names[xt.sc[0]]).append("").toString();
            String string_4 = (new StringBuilder()).append("1|").append(xt.nickname).append(":").append(xt.nickey).append("|").append(xt.clan).append("|").append(xt.clankey).append("|").append(string).append("|").append(join).append("|").append((int)(xt.arnp[0] * 100F)).append("|").append((int)(xt.arnp[1] * 100F)).append("|").append((int)(xt.arnp[2] * 100F)).append("|").append((int)(xt.arnp[3] * 100F)).append("|").append((int)(xt.arnp[4] * 100F)).append("|").append((int)(xt.arnp[5] * 100F)).append("|").append(ongame).append("|").toString();
            if(!xt.lan)
            {
                string_4 = (new StringBuilder()).append(string_4).append("").append(updatec).append("|").toString();
                if(updatec <= -11)
                {
                    for(int i_5 = 0; i_5 < -updatec - 10; i_5++)
                        string_4 = (new StringBuilder()).append(string_4).append("").append(cnames[6 - i_5]).append("|").append(sentn[6 - i_5]).append("|").toString();

                    updatec = -2;
                }
            } else
            {
                String string_6 = "Nonex";
                try
                {
                    string_6 = InetAddress.getLocalHost().getHostName();
                    if(string_6.indexOf("|") != -1)
                        string_6 = InetAddress.getLocalHost().getHostAddress();
                }
                catch(Exception exception)
                {
                    string_6 = "Nonex";
                }
                int i_7 = 0;
                if(xt.logged)
                    i_7 = 1;
                string_4 = (new StringBuilder()).append(string_4).append("").append(string_6).append("|").append(i_7).append("|").toString();
            }
            if(fstart)
            {
                string_4 = (new StringBuilder()).append(string_4).append("3|").toString();
                bool = true;
            }
            if(chalngd == -5 && !fstart)
            {
                string_4 = (new StringBuilder()).append(string_4).append("11|").append(gstage).append("|").append(gstagename).append("|").append(gstagelaps).append("|").append(gnpls).append("|").append(gwait).append("|").append(pnames[im]).append("|").append(gcars).append("|").append(gclass).append("|").append(gfix).append("|").append(gnotp).append("|").append(gplayers).append("|").toString();
                if(xt.lan)
                    string_4 = (new StringBuilder()).append(string_4).append("").append(gnbts).append("|").toString();
            }
            if(ongame != -1 && chalngd != -5 && !fstart)
            {
                boolean bool_8 = false;
                for(int i_9 = 0; i_9 < 7; i_9++)
                {
                    if(invos[i_9].equals("") || dinvi[i_9].equals(invos[i_9]))
                        continue;
                    if(!bool_8)
                    {
                        string_4 = (new StringBuilder()).append(string_4).append("2|").append(ongame).append("|").toString();
                        bool_8 = true;
                    }
                    string_4 = (new StringBuilder()).append(string_4).append("").append(invos[i_9]).append("|").toString();
                    dinvi[i_9] = invos[i_9];
                }

            }
            String string_10 = "";
            boolean bool_11 = false;
            try
            {
                dout.println(string_4);
                string_10 = din.readLine();
                if(string_10 == null)
                    bool_11 = true;
            }
            catch(Exception exception)
            {
                bool_11 = true;
            }
            if(bool_11)
            {
                try
                {
                    socket.close();
                    socket = null;
                    din.close();
                    din = null;
                    dout.close();
                    dout = null;
                }
                catch(Exception exception) { }
                try
                {
                    socket = new Socket(xt.server, xt.servport);
                    din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                    dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                    dout.println(string_4);
                    string_10 = din.readLine();
                    if(string_10 != null)
                        bool_11 = false;
                }
                catch(Exception exception) { }
            }
            if(bool_11)
            {
                try
                {
                    socket.close();
                    socket = null;
                }
                catch(Exception exception) { }
                conon = 0;
                lg.exitfromlobby();
                hideinputs();
                connector.stop();
            }
            if(regnow && join == -2)
                join = -1;
            npo = getvalue(string_10, 0);
            if(npo < 0)
                npo = 0;
            im = getvalue(string_10, 1);
            if(im < 0)
                im = 0;
            for(int i_12 = 0; i_12 < npo; i_12++)
            {
                pnames[i_12] = getSvalue(string_10, 2 + i_12 * 10);
                if(pnames[i_12].equals(""))
                    pnames[i_12] = "Unknown";
                String string_13 = getSvalue(string_10, 3 + i_12 * 10);
                if(string_13.startsWith("C"))
                {
                    pcarnames[i_12] = string_13.substring(1);
                    if(!pcarnames[i_12].equals(""))
                    {
                        int i_14 = 0;
                        int i_15 = 16;
                        do
                        {
                            if(i_15 >= 56)
                                break;
                            if(pcarnames[i_12].equals(cd.names[i_15]))
                            {
                                i_14 = i_15;
                                break;
                            }
                            i_15++;
                        } while(true);
                        if(i_14 == 0)
                        {
                            pcars[i_12] = -1;
                            boolean bool_16 = false;
                            for(int i_17 = 0; i_17 < cd.nl; i_17++)
                                if(pcarnames[i_12].equals(cd.loadnames[i_17]))
                                    bool_16 = true;

                            if(!bool_16 && cd.nl < 20 && cd.nl >= 0)
                            {
                                cd.loadnames[cd.nl] = pcarnames[i_12];
                                cd.nl++;
                            }
                            cd.sparkcarloader();
                        } else
                        {
                            pcars[i_12] = i_14;
                        }
                    } else
                    {
                        pcars[i_12] = 0;
                        pcarnames[i_12] = cd.names[pcars[i_12]];
                    }
                } else
                {
                    pcars[i_12] = getvalue(string_10, 3 + i_12 * 10);
                    if(pcars[i_12] == -1)
                        pcars[i_12] = 0;
                    pcarnames[i_12] = cd.names[pcars[i_12]];
                }
                pclan[i_12] = getSvalue(string_10, 4 + i_12 * 10);
                pgames[i_12] = getvalue(string_10, 5 + i_12 * 10);
                pcols[i_12][0] = (float)getvalue(string_10, 6 + i_12 * 10) / 100F;
                if(pcols[i_12][0] == -1F)
                    pcols[i_12][0] = 0.0F;
                pcols[i_12][1] = (float)getvalue(string_10, 7 + i_12 * 10) / 100F;
                if(pcols[i_12][1] == -1F)
                    pcols[i_12][1] = 0.0F;
                pcols[i_12][2] = (float)getvalue(string_10, 8 + i_12 * 10) / 100F;
                if(pcols[i_12][2] == -1F)
                    pcols[i_12][2] = 0.0F;
                pcols[i_12][3] = (float)getvalue(string_10, 9 + i_12 * 10) / 100F;
                if(pcols[i_12][3] == -1F)
                    pcols[i_12][3] = 0.0F;
                pcols[i_12][4] = (float)getvalue(string_10, 10 + i_12 * 10) / 100F;
                if(pcols[i_12][4] == -1F)
                    pcols[i_12][4] = 0.0F;
                pcols[i_12][5] = (float)getvalue(string_10, 11 + i_12 * 10) / 100F;
                if(pcols[i_12][5] == -1F)
                    pcols[i_12][5] = 0.0F;
            }

            int i_18 = 12 + (npo - 1) * 10;
            ngm = getvalue(string_10, i_18);
            if(ngm < 0)
                ngm = 0;
            int i_19 = 12;
            if(xt.lan)
                i_19 = 13;
            for(int i_20 = 0; i_20 < ngm; i_20++)
            {
                gnum[i_20] = getvalue(string_10, i_18 + 1 + i_20 * i_19);
                gstgn[i_20] = getvalue(string_10, i_18 + 2 + i_20 * i_19);
                gstgn[i_20] = Math.abs(gstgn[i_20]);
                if(gstgn[i_20] > 100)
                    gstgn[i_20] = -2;
                gstages[i_20] = getSvalue(string_10, i_18 + 3 + i_20 * i_19);
                gnlaps[i_20] = getvalue(string_10, i_18 + 4 + i_20 * i_19);
                mnpls[i_20] = getvalue(string_10, i_18 + 5 + i_20 * i_19);
                wait[i_20] = getvalue(string_10, i_18 + 6 + i_20 * i_19);
                gmaker[i_20] = getSvalue(string_10, i_18 + 7 + i_20 * i_19);
                gcrs[i_20] = getvalue(string_10, i_18 + 8 + i_20 * i_19);
                gclss[i_20] = getvalue(string_10, i_18 + 9 + i_20 * i_19);
                gfx[i_20] = getvalue(string_10, i_18 + 10 + i_20 * i_19);
                gntb[i_20] = getvalue(string_10, i_18 + 11 + i_20 * i_19);
                gplyrs[i_20] = getSvalue(string_10, i_18 + 12 + i_20 * i_19);
                if(gplyrs[i_20].startsWith("#warb#"))
                {
                    gwarb[i_20] = getHvalue(gplyrs[i_20], 2);
                    gwarbnum[i_20] = getHSvalue(gplyrs[i_20], 3);
                    gameturn[i_20] = getHvalue(gplyrs[i_20], 4);
                    gaclan[i_20] = getHSvalue(gplyrs[i_20], 5);
                    gvclan[i_20] = getHSvalue(gplyrs[i_20], 6);
                    gascore[i_20] = getHvalue(gplyrs[i_20], 7);
                    gvscore[i_20] = getHvalue(gplyrs[i_20], 8);
                    gwtyp[i_20] = getHvalue(gplyrs[i_20], 9);
                    if(gwtyp[i_20] < 1 || gwtyp[i_20] > 5)
                        gwtyp[i_20] = 1;
                    gplyrs[i_20] = "";
                } else
                {
                    gwarb[i_20] = 0;
                    gwarbnum[i_20] = "";
                    gameturn[i_20] = 0;
                    gaclan[i_20] = "";
                    gvclan[i_20] = "";
                    gascore[i_20] = 0;
                    gvscore[i_20] = 0;
                    gwtyp[i_20] = 0;
                }
                if(xt.lan)
                    mnbts[i_20] = getvalue(string_10, i_18 + 13 + i_20 * i_19);
                if(xt.playingame > -1 && xt.playingame == gnum[i_20] && !xt.lan)
                    ongame = gnum[i_20];
                if(i != gnum[i_20] || wait[i_20] != 0 || !lloaded || i == -1)
                    continue;
                int i_21 = 0;
                do
                {
                    if(i_21 >= npo)
                        break;
                    if(pgames[i_21] == gnum[i_20] && pnames[i_21].equals(xt.nickname))
                    {
                        im = i_21;
                        break;
                    }
                    i_21++;
                } while(true);
                conon = 2;
                gs.setCursor(new Cursor(3));
            }

            for(int i_22 = 0; i_22 < ngm; i_22++)
            {
                npls[i_22] = 0;
                for(int i_23 = 0; i_23 < npo; i_23++)
                    if(pgames[i_23] == gnum[i_22])
                        npls[i_22]++;

            }

            if(conon != 0 && xt.playingame != -1)
                xt.playingame = -1;
            if(ongame != -1)
            {
                boolean bool_24 = false;
                for(int i_25 = 0; i_25 < ngm; i_25++)
                    if(ongame == gnum[i_25])
                        bool_24 = true;

                if(!bool_24)
                    britchl = -1;
            }
            if(join > -1)
            {
                boolean bool_26 = false;
                for(int i_27 = 0; i_27 < ngm; i_27++)
                    if(join == gnum[i_27])
                        bool_26 = true;

                if(!bool_26)
                    join = -1;
            }
            for(int i_28 = 0; i_28 < npo; i_28++)
            {
                if(pgames[i_28] == -1)
                    continue;
                boolean bool_29 = false;
                for(int i_30 = 0; i_30 < ngm; i_30++)
                    if(pgames[i_28] == gnum[i_30])
                        bool_29 = true;

                if(!bool_29)
                    pgames[i_28] = -1;
            }

            if(xt.lan)
                i_18 += 14 + (ngm - 1) * 13;
            else
                i_18 += 13 + (ngm - 1) * 12;
            if(!xt.lan)
            {
                int i_31 = getvalue(string_10, i_18);
                int i_32 = getvalue(string_10, i_18 + 1);
                i_18 += 2;
                if(updatec != i_31 && updatec >= -2 && i_32 == ongame)
                {
                    for(int i_33 = 0; i_33 < 7; i_33++)
                    {
                        cnames[i_33] = getSvalue(string_10, i_18 + i_33 * 2);
                        sentn[i_33] = getSvalue(string_10, i_18 + 1 + i_33 * 2);
                    }

                    updatec = i_31;
                    if(ongame == -1)
                        spos3 = 28;
                    i_18 += 14;
                }
                if(ongame != -1)
                {
                    if(prevloaded != -1)
                        prevloaded = -1;
                    boolean bool_34 = false;
                    for(int i_35 = 0; i_35 < ngm; i_35++)
                        if(ongame == gnum[i_35] && wait[i_35] <= 0)
                            bool_34 = true;

                    if(bool_34)
                    {
                        prevloaded = getvalue(string_10, i_18);
                        i_18++;
                        if(prevloaded == 1)
                        {
                            prnpo = getvalue(string_10, i_18);
                            i_18++;
                            for(int i_36 = 0; i_36 < prnpo; i_36++)
                            {
                                prnames[i_36] = getSvalue(string_10, i_18);
                                i_18++;
                            }

                            for(int i_37 = 0; i_37 < prnpo; i_37++)
                            {
                                ppos[i_37] = getvalue(string_10, i_18);
                                i_18++;
                            }

                            for(int i_38 = 0; i_38 < prnpo; i_38++)
                            {
                                plap[i_38] = getvalue(string_10, i_18);
                                i_18++;
                            }

                            for(int i_39 = 0; i_39 < prnpo; i_39++)
                            {
                                ppow[i_39] = (int)(((float)getvalue(string_10, i_18) / 9800F) * 55F);
                                i_18++;
                            }

                            for(int i_40 = 0; i_40 < prnpo; i_40++)
                            {
                                int i_41 = getvalue(string_10, i_18);
                                if(i_41 != -17)
                                    pdam[i_40] = (int)(((float)i_41 / 100F) * 55F);
                                else
                                    pdam[i_40] = -17;
                                i_18++;
                            }

                            stuntname = getSvalue(string_10, i_18);
                            i_18++;
                            lapsname = getSvalue(string_10, i_18);
                            i_18++;
                            wastename = getSvalue(string_10, i_18);
                            i_18++;
                        }
                    }
                }
            } else
            {
                int i_42 = getvalue(string_10, i_18);
                if(i_42 == 1)
                    lanlogged = true;
                else
                    lanlogged = false;
                i_18++;
            }
            int i_43 = getvalue(string_10, i_18);
            if(i_43 != -1)
            {
                int i_44 = 0;
                for(int i_45 = 0; i_45 < ngm; i_45++)
                    if(i_43 == gnum[i_45])
                        i_44 = i_45;

                boolean bool_46 = false;
                if(gwarb[i_44] != 0)
                {
                    if(xt.clan.toLowerCase().equals(gaclan[i_44].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[i_44].toLowerCase()))
                        bool_46 = true;
                } else
                {
                    bool_46 = true;
                }
                if((pgames[im] != ongame || ongame == -1) && i_43 != ongame && chalngd == -1 && join == -1 && fase == 1 && wait[i_44] > 0 && bool_46)
                {
                    chalngd = i_43;
                    chalby = getSvalue(string_10, i_18 + 1);
                    cflk = 20;
                    ctime = 20;
                    ptime = 0L;
                    longame = ongame;
                    if(gs.rooms.open)
                        gs.rooms.open = false;
                    if(ongame != -1)
                        britchl = -1;
                }
                i_18++;
            }
            if(!xt.lan)
            {
                int i_47 = 1;
                for(int i_48 = 1; i_48 < 6; i_48++)
                {
                    if(i_48 == xt.servport - 7070)
                        continue;
                    int i_49 = getvalue(string_10, i_18 + i_48);
                    if(i_49 != -1)
                    {
                        gs.rooms.sopts[i_47] = (new StringBuilder()).append("Room ").append(i_48).append("  ::  ").append(i_49).append("").toString();
                        gs.rooms.opts[i_47] = "";
                        gs.rooms.iroom[i_47] = i_48;
                        i_47++;
                    }
                }

                for(int i_50 = 0; i_50 < lg.nservers; i_50++)
                    if(!xt.server.equals(lg.servers[i_50]) && xt.delays[i_50] < 300)
                    {
                        gs.rooms.sopts[i_47] = (new StringBuilder()).append(":: ").append(lg.snames[i_50]).append("").toString();
                        gs.rooms.opts[i_47] = "";
                        gs.rooms.iroom[i_47] = 1000 + i_50;
                        i_47++;
                    }

                gs.rooms.no = i_47;
            }
            if(join > -1)
            {
                boolean bool_51 = false;
                for(int i_52 = 0; i_52 < ngm; i_52++)
                    if(join == gnum[i_52] && wait[i_52] == 0)
                        bool_51 = true;

                if(pgames[im] == join || bool_51)
                {
                    join = -1;
                    nflk = 3;
                }
            }
            if(join == -2)
            {
                boolean bool_53 = false;
                for(int i_54 = 0; i_54 < ngm; i_54++)
                    if(pgames[im] == gnum[i_54] && wait[i_54] == 0)
                        bool_53 = true;

                if(pgames[im] == -1 || bool_53)
                {
                    join = -1;
                    if(!bool_53)
                        ongame = -1;
                }
            }
            if(chalngd == -5 && pgames[im] != -1)
            {
                ongame = pgames[im];
                chalngd = -1;
                if(!xt.lan && gplayers.equals(""))
                    lg.gamealert();
            }
            if(fstart && bool)
                fstart = false;
            rerr = 0;
            if(!lloaded)
            {
                gs.setCursor(new Cursor(0));
                lloaded = true;
            }
            if(!gb.domon)
            {
                gb.roomlogos(pnames, npo);
                if(ongame == -1)
                {
                    if(cntchkn == 5)
                        lg.checkgamealerts();
                } else
                if(lg.gamec != -1)
                    lg.gamec = -1;
                if(cntchkn == 5)
                {
                    lg.checknotifcations();
                    cntchkn = 0;
                } else
                {
                    cntchkn++;
                }
            } else
            if(lg.gamec != -1)
                lg.gamec = -1;
            date = new Date();
            long l_55 = date.getTime();
            int i_56 = 700 - (int)(l_55 - l);
            if(i_56 < 50)
                i_56 = 50;
            try
            {
                if(connector == null);
                Thread.sleep(i_56);
            }
            catch(InterruptedException interruptedexception) { }
        }
        if(conon == 2)
        {
            int i_57 = 20;
            xt.playingame = -1;
            while(i_57 != 0) 
            {
                String string = (new StringBuilder()).append("2|").append(i).append("|").toString();
                String string_58 = "";
                boolean bool = false;
                try
                {
                    dout.println(string);
                    string_58 = din.readLine();
                    if(string_58 == null)
                        bool = true;
                }
                catch(Exception exception)
                {
                    bool = true;
                }
                if(bool)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                        din.close();
                        din = null;
                        dout.close();
                        dout = null;
                    }
                    catch(Exception exception) { }
                    try
                    {
                        socket = new Socket(xt.server, xt.servport);
                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                        dout.println(string);
                        string_58 = din.readLine();
                        if(string_58 != null)
                            bool = false;
                    }
                    catch(Exception exception) { }
                }
                if(bool)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                    }
                    catch(Exception exception) { }
                    conon = 0;
                    lg.exitfromlobby();
                    hideinputs();
                    connector.stop();
                }
                if(!xt.lan)
                {
                    xt.gameport = getvalue(string_58, 0);
                } else
                {
                    xt.gameport = -1;
                    xt.localserver = getSevervalue(string_58, 0);
                    if(!xt.localserver.equals(""))
                        xt.gameport = 0;
                }
                if(xt.gameport != -1)
                {
                    int i_59 = 0;
                    xt.im = -1;
                    xt.nplayers = getvalue(string_58, 1);
                    if(xt.nplayers < 1)
                        xt.nplayers = 1;
                    if(xt.nplayers > 8)
                        xt.nplayers = 8;
                    for(int i_60 = 0; i_60 < xt.nplayers; i_60++)
                    {
                        xt.plnames[i_60] = getSvalue(string_58, 2 + i_60);
                        if(xt.nickname.equals(xt.plnames[i_60]))
                            xt.im = i_60;
                    }

                    int i_61 = 2 + xt.nplayers;
label0:
                    for(int i_62 = 0; i_62 < xt.nplayers; i_62++)
                    {
                        String string_63 = getSvalue(string_58, i_61 + i_62);
                        if(string_63.startsWith("C"))
                        {
                            string_63 = string_63.substring(1);
                            if(!string_63.equals(""))
                            {
                                int i_64 = 0;
                                int i_65 = 16;
                                do
                                {
                                    if(i_65 >= 56)
                                        break;
                                    if(string_63.equals(cd.names[i_65]))
                                    {
                                        i_64 = i_65;
                                        break;
                                    }
                                    i_65++;
                                } while(true);
                                for(; i_64 == 0 && i_59 < 100; i_59++)
                                {
                                    boolean bool_66 = false;
                                    for(int i_67 = 0; i_67 < cd.nl; i_67++)
                                        if(string_63.equals(cd.loadnames[i_67]))
                                            bool_66 = true;

                                    if(!bool_66 && cd.nl < 20)
                                    {
                                        cd.loadnames[cd.nl] = string_63;
                                        cd.nl++;
                                    }
                                    cd.sparkcarloader();
                                    try
                                    {
                                        if(connector == null);
                                        Thread.sleep(100L);
                                    }
                                    catch(InterruptedException interruptedexception) { }
                                    for(int i_68 = 16; i_68 < 56; i_68++)
                                        if(string_63.equals(cd.names[i_68]))
                                            i_64 = i_68;

                                }

                                if(i_64 != 0)
                                {
                                    xt.sc[i_62] = i_64;
                                    int i_69 = 0;
                                    do
                                    {
                                        if(i_69 >= npo)
                                            continue label0;
                                        if(pcarnames[i_69].equals(string_63))
                                            pcars[i_69] = i_64;
                                        i_69++;
                                    } while(true);
                                }
                                xt.im = -1;
                            } else
                            {
                                xt.im = -1;
                            }
                            continue;
                        }
                        xt.sc[i_62] = getvalue(string_58, i_61 + i_62);
                        if(xt.sc[i_62] == -1)
                            xt.im = -1;
                    }

                    i_61 += xt.nplayers;
                    for(int i_70 = 0; i_70 < xt.nplayers; i_70++)
                        xt.xstart[i_70] = getvalue(string_58, i_61 + i_70);

                    i_61 += xt.nplayers;
                    for(int i_71 = 0; i_71 < xt.nplayers; i_71++)
                        xt.zstart[i_71] = getvalue(string_58, i_61 + i_71);

                    i_61 += xt.nplayers;
                    for(int i_72 = 0; i_72 < xt.nplayers; i_72++)
                    {
                        for(int i_73 = 0; i_73 < 6; i_73++)
                            xt.allrnp[i_72][i_73] = (float)getvalue(string_58, i_61 + i_72 * 6 + i_73) / 100F;

                    }

                    if(xt.im != -1)
                    {
                        xt.playingame = i;
                        int i_74 = 0;
                        for(int i_75 = 0; i_75 < ngm; i_75++)
                            if(i == gnum[i_75])
                                i_74 = i_75;

                        if(gwarb[i_74] != 0)
                        {
                            xt.clangame = gwtyp[i_74];
                            xt.clanchat = true;
                            xt.gaclan = gaclan[i_74];
                            for(int i_76 = 0; i_76 < xt.nplayers; i_76++)
                            {
                                for(int i_77 = 0; i_77 < npo; i_77++)
                                    if(xt.plnames[i_76].equals(pnames[i_77]) && pgames[i_77] == i)
                                        xt.pclan[i_76] = pclan[i_77];

                            }

                        } else
                        {
                            xt.clangame = 0;
                        }
                    } else
                    {
                        xt.playingame = -1;
                        xt.im = 0;
                    }
                    i_57 = 0;
                } else
                {
                    i_57--;
                }
                try
                {
                    if(connector == null);
                    Thread.sleep(1000L);
                }
                catch(InterruptedException interruptedexception) { }
            }
            try
            {
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception) { }
            if(xt.playingame != -1)
            {
                if(!xt.lan && !xt.logged)
                {
                    xt.nfreeplays++;
                    try
                    {
                        socket = new Socket(lg.servers[0], 7061);
                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                        dout.println((new StringBuilder()).append("7|").append(xt.nfreeplays).append("|").toString());
                        String string = din.readLine();
                        xt.hours = getvalue(string, 0);
                        socket.close();
                        socket = null;
                        din.close();
                        din = null;
                        dout.close();
                        dout = null;
                    }
                    catch(Exception exception) { }
                }
                hideinputs();
                xt.multion = 1;
                fase = 76;
                System.gc();
            } else
            {
                inishlobby();
            }
        }
        if(conon == 3)
        {
            int i_78 = 20;
            xt.playingame = -1;
            while(i_78 != 0) 
            {
                String string = (new StringBuilder()).append("4|").append(ongame).append("|").toString();
                String string_79 = "";
                boolean bool = false;
                try
                {
                    dout.println(string);
                    string_79 = din.readLine();
                    if(string_79 == null)
                        bool = true;
                }
                catch(Exception exception)
                {
                    bool = true;
                }
                if(bool)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                        din.close();
                        din = null;
                        dout.close();
                        dout = null;
                    }
                    catch(Exception exception) { }
                    try
                    {
                        socket = new Socket(xt.server, xt.servport);
                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                        dout.println(string);
                        string_79 = din.readLine();
                        if(string_79 != null)
                            bool = false;
                    }
                    catch(Exception exception) { }
                }
                if(bool)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                    }
                    catch(Exception exception) { }
                    conon = 0;
                    lg.exitfromlobby();
                    hideinputs();
                    connector.stop();
                }
                if(!xt.lan)
                {
                    xt.gameport = getvalue(string_79, 0);
                } else
                {
                    xt.gameport = -1;
                    xt.localserver = getSevervalue(string_79, 0);
                    if(!xt.localserver.equals(""))
                        xt.gameport = 0;
                }
                if(xt.gameport != -1)
                {
                    int i_80 = 0;
                    xt.nplayers = getvalue(string_79, 1);
                    if(xt.nplayers < 1)
                        xt.nplayers = 1;
                    if(xt.nplayers > 8)
                        xt.nplayers = 8;
                    xt.im = getvalue(string_79, 2) + xt.nplayers;
                    for(int i_81 = 0; i_81 < xt.nplayers; i_81++)
                        xt.plnames[i_81] = getSvalue(string_79, 3 + i_81);

                    int i_82 = 3 + xt.nplayers;
label1:
                    for(int i_83 = 0; i_83 < xt.nplayers; i_83++)
                    {
                        String string_84 = getSvalue(string_79, i_82 + i_83);
                        if(string_84.startsWith("C"))
                        {
                            string_84 = string_84.substring(1);
                            if(!string_84.equals(""))
                            {
                                int i_85 = 0;
                                int i_86 = 16;
                                do
                                {
                                    if(i_86 >= 56)
                                        break;
                                    if(string_84.equals(cd.names[i_86]))
                                    {
                                        i_85 = i_86;
                                        break;
                                    }
                                    i_86++;
                                } while(true);
                                for(; i_85 == 0 && i_80 < 100; i_80++)
                                {
                                    boolean bool_87 = false;
                                    for(int i_88 = 0; i_88 < cd.nl; i_88++)
                                        if(string_84.equals(cd.loadnames[i_88]))
                                            bool_87 = true;

                                    if(!bool_87 && cd.nl < 20)
                                    {
                                        cd.loadnames[cd.nl] = string_84;
                                        cd.nl++;
                                    }
                                    cd.sparkcarloader();
                                    try
                                    {
                                        if(connector == null);
                                        Thread.sleep(100L);
                                    }
                                    catch(InterruptedException interruptedexception) { }
                                    for(int i_89 = 16; i_89 < 56; i_89++)
                                        if(string_84.equals(cd.names[i_89]))
                                            i_85 = i_89;

                                }

                                if(i_85 != 0)
                                {
                                    xt.sc[i_83] = i_85;
                                    int i_90 = 0;
                                    do
                                    {
                                        if(i_90 >= npo)
                                            continue label1;
                                        if(pcarnames[i_90].equals(string_84))
                                            pcars[i_90] = i_85;
                                        i_90++;
                                    } while(true);
                                }
                                xt.im = -1;
                            } else
                            {
                                xt.im = -1;
                            }
                            continue;
                        }
                        xt.sc[i_83] = getvalue(string_79, i_82 + i_83);
                        if(xt.sc[i_83] == -1)
                            xt.im = -1;
                    }

                    i_82 += xt.nplayers;
                    for(int i_91 = 0; i_91 < xt.nplayers; i_91++)
                        xt.xstart[i_91] = getvalue(string_79, i_82 + i_91);

                    i_82 += xt.nplayers;
                    for(int i_92 = 0; i_92 < xt.nplayers; i_92++)
                        xt.zstart[i_92] = getvalue(string_79, i_82 + i_92);

                    i_82 += xt.nplayers;
                    for(int i_93 = 0; i_93 < xt.nplayers; i_93++)
                    {
                        for(int i_94 = 0; i_94 < 6; i_94++)
                            xt.allrnp[i_93][i_94] = (float)getvalue(string_79, i_82 + i_93 * 6 + i_94) / 100F;

                    }

                    if(xt.im >= xt.nplayers && xt.im < xt.nplayers + 3)
                    {
                        xt.playingame = ongame;
                        int i_95 = 0;
                        for(int i_96 = 0; i_96 < ngm; i_96++)
                            if(ongame == gnum[i_96])
                                i_95 = i_96;

                        if(gwarb[i_95] != 0)
                        {
                            xt.clangame = gwtyp[i_95];
                            xt.gaclan = gaclan[i_95];
                            if(xt.clan.toLowerCase().equals(gaclan[i_95].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[i_95].toLowerCase()))
                                xt.clanchat = true;
                            for(int i_97 = 0; i_97 < xt.nplayers; i_97++)
                            {
                                for(int i_98 = 0; i_98 < npo; i_98++)
                                    if(xt.plnames[i_97].equals(pnames[i_98]) && pgames[i_98] == ongame)
                                        xt.pclan[i_97] = pclan[i_98];

                            }

                        } else
                        {
                            xt.clangame = 0;
                        }
                    } else
                    {
                        xt.playingame = -1;
                        xt.im = 0;
                    }
                    i_78 = 0;
                } else
                {
                    i_78--;
                }
                try
                {
                    if(connector == null);
                    Thread.sleep(1000L);
                }
                catch(InterruptedException interruptedexception) { }
            }
            try
            {
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception) { }
            if(xt.playingame != -1)
            {
                hideinputs();
                xt.multion = 3;
                fase = 76;
                System.gc();
            } else
            {
                inishlobby();
            }
        }
    }

    public void stopallnow()
    {
        conon = 0;
        try
        {
            socket.close();
            socket = null;
            din.close();
            din = null;
            dout.close();
            dout = null;
        }
        catch(Exception exception) { }
        if(connector != null)
        {
            connector.stop();
            connector = null;
        }
    }

    public void lobby(int i, int i_99, boolean bool, int i_100, CheckPoints checkpoints, Control control, ContO contos[])
    {
        pre1 = false;
        pre2 = false;
        int i_101 = 0;
        if(xt.warning == 210)
            xt.warning = 0;
        if(!regnow)
        {
            if(onjoin == -1)
            {
                xt.mainbg(3);
                if(britchl == -1)
                {
                    ongame = -1;
                    britchl = 0;
                }
                btn = 0;
                pbtn = 0;
                zeromsw = false;
                int i_102 = npo;
                if(invo)
                {
                    i_102 = 0;
                    for(int i_103 = 0; i_103 < npo; i_103++)
                        if(pgames[i_103] == -1)
                            i_102++;

                    i_102 += 2;
                }
                int i_104 = (i_102 - 11) * 30;
                if(i_104 < 0)
                    i_104 = 0;
                int i_105 = (int)(((float)spos / 295F) * (float)i_104);
                int i_106 = 0;
                int i_107 = -1;
                int i_108 = -1;
                if(conon == 1)
                {
                    if(!invo)
                    {
                        for(int i_109 = 0; i_109 < npo; i_109++)
                        {
                            if(pgames[i_109] == -1)
                                continue;
                            int i_110 = 0;
                            for(int i_111 = 0; i_111 < ngm; i_111++)
                                if(pgames[i_109] == gnum[i_111])
                                    i_110 = i_111;

                            if(wait[i_110] <= 0)
                                continue;
                            if((82 + 30 * i_106) - i_105 > 50 && (82 + 30 * (i_106 - 1)) - i_105 < 415)
                            {
                                boolean bool_112 = false;
                                if(i > 70 && i < 185 && i_99 > (52 + 30 * i_106) - i_105 && i_99 < (82 + 30 * i_106) - i_105)
                                {
                                    if(pgames[im] == -1 && join == -1 && chalngd >= -1)
                                    {
                                        if(bool || mousonp == i_109)
                                        {
                                            rd.setColor(color2k(255, 255, 255));
                                            mousonp = i_109;
                                            i_108 = (52 + 30 * i_106) - i_105;
                                            if(bool)
                                            {
                                                if(cmonp == i_109)
                                                    ongame = pgames[i_109];
                                                chalngd = -1;
                                            } else
                                            {
                                                if(cmonp == -1)
                                                {
                                                    ongame = -1;
                                                    cmonp = i_109;
                                                }
                                                if(ongame == pgames[i_109])
                                                    mousonp = -1;
                                            }
                                        } else
                                        {
                                            rd.setColor(color2k(220, 220, 220));
                                        }
                                        rd.fillRect(70, (53 + 30 * i_106) - i_105, 116, 29);
                                        i_107 = i_109;
                                    }
                                    bool_112 = true;
                                    if(control.handb)
                                    {
                                        gs.cmsg.setText((new StringBuilder()).append(gs.cmsg.getText()).append("").append(pnames[i_109]).toString());
                                        control.handb = false;
                                    }
                                }
                                if(pgames[im] == -1 && join == -1 && chalngd >= -1)
                                    rd.setColor(new Color(49, 79, 0));
                                else
                                    rd.setColor(new Color(34, 55, 0));
                                boolean bool_113 = gb.drawl(rd, pnames[i_109], 68, (53 + 30 * i_106) - i_105, bool_112);
                                if(!bool_112 || !bool_113)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(pnames[i_109], 127 - ftm.stringWidth(pnames[i_109]) / 2, (66 + 30 * i_106) - i_105);
                                    rd.setFont(new Font("Arial", 0, 10));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(pcarnames[i_109], 127 - ftm.stringWidth(pcarnames[i_109]) / 2, (78 + 30 * i_106) - i_105);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(70, (82 + 30 * i_106) - i_105, 185, (82 + 30 * i_106) - i_105);
                            }
                            i_106++;
                        }

                    }
                    int i_114 = -1;
                    if(invo)
                    {
                        for(int i_115 = 0; i_115 < ngm; i_115++)
                            if(gwarb[i_115] != 0 && pgames[im] == gnum[i_115])
                                i_114 = i_115;

                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        if(i_114 == -1)
                            rd.drawString("Free Players", 127 - ftm.stringWidth("Free Players") / 2, 75 - i_105);
                        else
                            rd.drawString("Members of Clans", 127 - ftm.stringWidth("Members of Clans") / 2, 75 - i_105);
                        rd.setFont(new Font("Arial", 0, 10));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Click a player to invite:", 127 - ftm.stringWidth("Click a player to invite:") / 2, 92 - i_105);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(70, 112 - i_105, 185, 112 - i_105);
                        i_106 += 2;
                    }
                    for(int i_116 = 0; i_116 < npo; i_116++)
                    {
                        boolean bool_117 = false;
                        if(invo)
                        {
                            if(im == i_116)
                                bool_117 = true;
                            for(int i_118 = 0; i_118 < 7; i_118++)
                                if(invos[i_118].equals(pnames[i_116]) && !bool_117)
                                    bool_117 = true;

                            if(i_114 != -1 && !pclan[i_116].toLowerCase().equals(gaclan[i_114].toLowerCase()) && !pclan[i_116].toLowerCase().equals(gvclan[i_114].toLowerCase()))
                                bool_117 = true;
                        }
                        if(pgames[i_116] != -1 || bool_117)
                            continue;
                        if((82 + 30 * i_106) - i_105 > 50 && (82 + 30 * (i_106 - 1)) - i_105 < 415)
                        {
                            boolean bool_119 = false;
                            if(i > 70 && i < 185 && i_99 > (52 + 30 * i_106) - i_105 && i_99 < (82 + 30 * i_106) - i_105)
                            {
                                if(invo)
                                {
                                    if(bool)
                                    {
                                        rd.setColor(color2k(255, 255, 255));
                                        mousonp = i_116;
                                    } else
                                    {
                                        rd.setColor(color2k(220, 220, 220));
                                        if(mousonp == i_116)
                                        {
                                            int i_120 = 0;
                                            for(boolean bool_121 = false; i_120 < 7 && !bool_121; i_120++)
                                                if(invos[i_120].equals(""))
                                                {
                                                    invos[i_120] = pnames[i_116];
                                                    bool_121 = true;
                                                }

                                            mousonp = -1;
                                            invo = false;
                                        }
                                    }
                                    rd.fillRect(70, (53 + 30 * i_106) - i_105, 116, 29);
                                    i_107 = i_116;
                                } else
                                if(pgames[im] == -1 && join == -1 && chalngd >= -1)
                                {
                                    i_101 = 12;
                                    if(bool)
                                    {
                                        if(!gb.proname.equals(pnames[i_116]))
                                        {
                                            gb.proname = pnames[i_116];
                                            gb.loadedp = false;
                                        }
                                        gb.tab = 1;
                                        gb.open = 2;
                                        gb.upo = true;
                                    }
                                }
                                bool_119 = true;
                                if(control.handb)
                                {
                                    gs.cmsg.setText((new StringBuilder()).append(gs.cmsg.getText()).append("").append(pnames[i_116]).toString());
                                    control.handb = false;
                                }
                            }
                            if(invo)
                                rd.setColor(new Color(62, 98, 0));
                            else
                                rd.setColor(new Color(0, 0, 0));
                            boolean bool_122 = gb.drawl(rd, pnames[i_116], 68, (53 + 30 * i_106) - i_105, bool_119);
                            if(!bool_119 || !bool_122)
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString(pnames[i_116], 127 - ftm.stringWidth(pnames[i_116]) / 2, (66 + 30 * i_106) - i_105);
                                rd.setFont(new Font("Arial", 0, 10));
                                ftm = rd.getFontMetrics();
                                rd.drawString(pcarnames[i_116], 127 - ftm.stringWidth(pcarnames[i_116]) / 2, (78 + 30 * i_106) - i_105);
                            }
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(70, (82 + 30 * i_106) - i_105, 185, (82 + 30 * i_106) - i_105);
                        }
                        i_106++;
                    }

                    if(invo && i_106 == 2)
                        invo = false;
                    if(!invo)
                    {
                        for(int i_123 = npo - 1; i_123 >= 0; i_123--)
                        {
                            if(pgames[i_123] == -1)
                                continue;
                            int i_124 = 0;
                            for(int i_125 = 0; i_125 < ngm; i_125++)
                                if(pgames[i_123] == gnum[i_125])
                                    i_124 = i_125;

                            if(wait[i_124] > 0)
                                continue;
                            boolean bool_126 = false;
                            for(int i_127 = 0; i_127 < npo; i_127++)
                            {
                                if(i_123 == i_127 || !pnames[i_123].equals(pnames[i_127]))
                                    continue;
                                if(pgames[i_127] == -1)
                                {
                                    bool_126 = true;
                                    continue;
                                }
                                for(int i_128 = 0; i_128 < ngm; i_128++)
                                    if(pgames[i_127] == gnum[i_128] && wait[i_128] > 0)
                                        bool_126 = true;

                            }

                            if(bool_126)
                                continue;
                            if((82 + 30 * i_106) - i_105 > 50 && (82 + 30 * (i_106 - 1)) - i_105 < 415)
                            {
                                boolean bool_129 = false;
                                if(i > 70 && i < 185 && i_99 > (52 + 30 * i_106) - i_105 && i_99 < (82 + 30 * i_106) - i_105)
                                {
                                    if(pgames[im] == -1 && join == -1 && chalngd >= -1)
                                    {
                                        if(bool || mousonp == i_123)
                                        {
                                            rd.setColor(color2k(255, 255, 255));
                                            mousonp = i_123;
                                            i_108 = (52 + 30 * i_106) - i_105;
                                            if(bool)
                                            {
                                                if(cmonp == i_123)
                                                    ongame = pgames[i_123];
                                                chalngd = -1;
                                            } else
                                            {
                                                if(cmonp == -1)
                                                {
                                                    ongame = -1;
                                                    cmonp = i_123;
                                                }
                                                if(ongame == pgames[i_123])
                                                    mousonp = -1;
                                            }
                                        } else
                                        {
                                            rd.setColor(color2k(220, 220, 220));
                                        }
                                        rd.fillRect(70, (53 + 30 * i_106) - i_105, 116, 29);
                                        i_107 = i_123;
                                    }
                                    bool_129 = true;
                                    if(control.handb)
                                    {
                                        gs.cmsg.setText((new StringBuilder()).append(gs.cmsg.getText()).append("").append(pnames[i_123]).toString());
                                        control.handb = false;
                                    }
                                }
                                if(pgames[im] == -1 && join == -1 && chalngd >= -1)
                                {
                                    if(wait[i_124] == 0)
                                        rd.setColor(new Color(117, 67, 0));
                                    else
                                        rd.setColor(color2k(0, 28, 102));
                                } else
                                if(wait[i_124] == 0)
                                    rd.setColor(new Color(82, 47, 0));
                                else
                                    rd.setColor(color2k(0, 20, 71));
                                boolean bool_130 = gb.drawl(rd, pnames[i_123], 68, (53 + 30 * i_106) - i_105, bool_129);
                                if(!bool_129 || !bool_130)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(pnames[i_123], 127 - ftm.stringWidth(pnames[i_123]) / 2, (66 + 30 * i_106) - i_105);
                                    rd.setFont(new Font("Arial", 0, 10));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(pcarnames[i_123], 127 - ftm.stringWidth(pcarnames[i_123]) / 2, (78 + 30 * i_106) - i_105);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(70, (82 + 30 * i_106) - i_105, 185, (82 + 30 * i_106) - i_105);
                            }
                            i_106++;
                        }

                    }
                }
                if(mousonp != i_107)
                {
                    mousonp = -1;
                    cmonp = -1;
                }
                if(npo == 0)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("|  Loading Players  |", 127 - ftm.stringWidth("|  Loading Players  |") / 2, 95);
                }
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(65, 25, 145, 28);
                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(65, 50, 190, 50);
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(65, 413, 145, 12);
                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(65, 415, 190, 415);
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(193, 53, 17, 360);
                rd.setColor(new Color(0, 0, 0));
                rd.drawLine(211, 25, 211, 425);
                rd.drawImage(xt.roomp, 72, 30, null);
                if(mscro == 131 || i_104 == 0)
                {
                    if(i_104 == 0)
                        rd.setColor(color2k(205, 205, 205));
                    else
                        rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(193, 53, 17, 17);
                } else
                {
                    rd.setColor(color2k(220, 220, 220));
                    rd.fill3DRect(193, 53, 17, 17, true);
                }
                if(i_104 != 0)
                    rd.drawImage(xt.asu, 198, 59, null);
                if(mscro == 132 || i_104 == 0)
                {
                    if(i_104 == 0)
                        rd.setColor(color2k(205, 205, 205));
                    else
                        rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(193, 396, 17, 17);
                } else
                {
                    rd.setColor(color2k(220, 220, 220));
                    rd.fill3DRect(193, 396, 17, 17, true);
                }
                if(i_104 != 0)
                    rd.drawImage(xt.asd, 198, 403, null);
                if(i_104 != 0 && conon == 1)
                {
                    if(lspos != spos)
                    {
                        rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(193, 70 + spos, 17, 31);
                    } else
                    {
                        if(mscro == 131)
                            rd.setColor(color2k(215, 215, 215));
                        rd.fill3DRect(193, 70 + spos, 17, 31, true);
                    }
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(198, 83 + spos, 204, 83 + spos);
                    rd.drawLine(198, 85 + spos, 204, 85 + spos);
                    rd.drawLine(198, 87 + spos, 204, 87 + spos);
                    if(mscro > 101 && lspos != spos)
                        lspos = spos;
                    if(bool)
                    {
                        if(mscro == 125 && i > 193 && i < 210 && i_99 > 70 + spos && i_99 < spos + 101)
                            mscro = i_99 - spos;
                        if(mscro == 125 && i > 191 && i < 212 && i_99 > 51 && i_99 < 72)
                            mscro = 131;
                        if(mscro == 125 && i > 191 && i < 212 && i_99 > 394 && i_99 < 415)
                            mscro = 132;
                        if(mscro == 125 && i > 193 && i < 210 && i_99 > 70 && i_99 < 396)
                        {
                            mscro = 85;
                            spos = i_99 - mscro;
                        }
                        int i_131 = 1350 / i_104;
                        if(i_131 < 1)
                            i_131 = 1;
                        if(mscro == 131)
                        {
                            spos -= i_131;
                            if(spos > 295)
                                spos = 295;
                            if(spos < 0)
                                spos = 0;
                            lspos = spos;
                        }
                        if(mscro == 132)
                        {
                            spos += i_131;
                            if(spos > 295)
                                spos = 295;
                            if(spos < 0)
                                spos = 0;
                            lspos = spos;
                        }
                        if(mscro <= 101)
                        {
                            spos = i_99 - mscro;
                            if(spos > 295)
                                spos = 295;
                            if(spos < 0)
                                spos = 0;
                        }
                        if(mscro == 125)
                            mscro = 225;
                    } else
                    if(mscro != 125)
                        mscro = 125;
                    if(i_100 != 0 && i > 65 && i < 170 && i_99 > 93 && i_99 < 413)
                    {
                        spos -= i_100;
                        zeromsw = true;
                        if(spos > 295)
                        {
                            spos = 295;
                            zeromsw = false;
                        }
                        if(spos < 0)
                        {
                            spos = 0;
                            zeromsw = false;
                        }
                        lspos = spos;
                    }
                }
                if(ongame == -1)
                {
                    if(opengame >= 2)
                    {
                        if(opengame >= 27)
                            opengame = 26;
                        int i_132 = 229 + opengame;
                        if(i_132 > 255)
                            i_132 = 255;
                        if(i_132 < 0)
                            i_132 = 0;
                        rd.setColor(color2k(i_132, i_132, i_132));
                        rd.fillRoundRect(225, 59 - (int)((float)opengame * 2.23F), 495, 200 + opengame * 8, 20, 20);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawRoundRect(225, 59 - (int)((float)opengame * 2.23F), 495, 200 + opengame * 8, 20, 20);
                        if(!xt.lan)
                        {
                            rd.setColor(color2k(217, 217, 217));
                            rd.fillRoundRect(225, 263 + opengame * 7, 495, 157, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(225, 263 + opengame * 7, 495, 157, 20, 20);
                        }
                        btn = 0;
                        if(prevloaded != -1)
                            prevloaded = -1;
                        if(updatec != -1)
                            updatec = -1;
                        if(gs.cmsg.isShowing())
                        {
                            gs.cmsg.hide();
                            gs.requestFocus();
                        }
                        opengame -= 2;
                        if(opengame == 0 && longame != -1 && chalngd == -1)
                        {
                            ongame = longame;
                            longame = -1;
                        }
                        if(invo)
                            invo = false;
                        for(int i_133 = 0; i_133 < 7; i_133++)
                        {
                            if(!invos[i_133].equals(""))
                                invos[i_133] = "";
                            if(!dinvi[i_133].equals(""))
                                dinvi[i_133] = "";
                        }

                        if(fstart)
                            fstart = false;
                        for(int i_134 = 0; i_134 < 9; i_134++)
                            if(cac[i_134] != -1)
                                cac[i_134] = -1;

                        if(dispcar != -1)
                            dispcar = -1;
                    } else
                    {
                        if(!xt.lan)
                        {
                            drawSbutton(xt.cgame, 292, 42);
                            drawSbutton(xt.ccar, 442, 42);
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            rd.setColor(color2k(60, 60, 60));
                            if(!gs.rooms.isShowing())
                                gs.rooms.show();
                            gs.rooms.move(580 - gs.rooms.w / 2, 29);
                            if(gs.rooms.sel != 0)
                            {
                                stopallnow();
                                int i_135 = gs.rooms.iroom[gs.rooms.sel];
                                if(i_135 < 1000)
                                {
                                    if(i_135 >= 1 && i_135 <= 5)
                                        xt.servport = 7070 + i_135;
                                } else
                                if((i_135 -= 1000) >= 0 && i_135 < lg.nservers)
                                {
                                    xt.servport = 7071;
                                    xt.server = lg.servers[i_135];
                                    xt.servername = lg.snames[i_135];
                                }
                                inishlobby();
                                gs.rooms.kmoused = 20;
                            }
                            if(gs.rooms.kmoused != 0)
                            {
                                i = -1;
                                i_99 = -1;
                                bool = false;
                                gs.rooms.kmoused--;
                            }
                        } else
                        {
                            rd.drawImage(xt.lanm, 241, 31, null);
                            if(npo <= 1)
                            {
                                drawSbutton(xt.cgame, 292, -1000);
                                rd.setColor(new Color(0, 0, 0));
                                if(ncnt == 0)
                                    rd.setColor(new Color(188, 111, 0));
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.drawString(lmsg, 472 - ftm.stringWidth(lmsg) / 2, 295);
                                if(lmsg.equals(". . . | Searching/Waiting for other LAN Players | . . .") && ncnt == 0)
                                {
                                    lmsg = "| Searching/Waiting for other LAN Players |";
                                    ncnt = 5;
                                }
                                if(lmsg.equals(". . | Searching/Waiting for other LAN Players | . .") && ncnt == 0)
                                {
                                    lmsg = ". . . | Searching/Waiting for other LAN Players | . . .";
                                    ncnt = 5;
                                }
                                if(lmsg.equals(". | Searching/Waiting for other LAN Players | .") && ncnt == 0)
                                {
                                    lmsg = ". . | Searching/Waiting for other LAN Players | . .";
                                    ncnt = 5;
                                }
                                if(lmsg.equals("| Searching/Waiting for other LAN Players |") && ncnt == 0)
                                {
                                    lmsg = ". | Searching/Waiting for other LAN Players | .";
                                    ncnt = 5;
                                }
                                if(ncnt != 0)
                                    ncnt--;
                                rd.setColor(color2k(70, 70, 70));
                                rd.drawString("So far, you are the only player connected to this network!", 225, 325);
                                rd.drawString("There needs to be at least one more player logged in here with your same", 225, 345);
                                rd.drawString("internet connection...", 225, 365);
                            } else
                            if(!lanlogged)
                            {
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.drawString("You have played the allowed 3 LAN games per day!", 472 - ftm.stringWidth("You have played the allowed 3 LAN games per day!") / 2, 295);
                                rd.setColor(color2k(70, 70, 70));
                                rd.drawString("There needs to be at least one of the LAN players in the lobby with a registered", 225, 325);
                                rd.drawString("account to be able to play LAN unlimitedly...", 225, 345);
                                rd.drawString("Just one registered user allows everyone in the LAN game to play unlimitedly!", 225, 365);
                                rd.drawString("Please register now!", 225, 385);
                                drawSbutton(xt.register, 472, 395);
                            } else
                            {
                                rd.setColor(color2k(90, 90, 90));
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("[  ").append(i_106).append(" Players Connected  ]").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("[  ").append(i_106).append(" Players Connected  ]").toString()) / 2, 295);
                                drawSbutton(xt.cgame, 472, 325);
                            }
                            drawSbutton(xt.ccar, 442, -1000);
                        }
                        drawSbutton(xt.exit, 690, 42);
                        if(control.enter && !gs.cmsg.getText().equals("Type here...") && !gs.cmsg.getText().equals(""))
                        {
                            if(chalngd == -1)
                                pessd[2] = true;
                            else
                                pessd[5] = true;
                            control.enter = false;
                            String string = xt.passRem(gs.cmsg.getText().replace('|', ':'));
                            if(!xt.msgcheck(string) && updatec > -12)
                            {
                                for(int i_136 = 0; i_136 < 6; i_136++)
                                {
                                    sentn[i_136] = sentn[i_136 + 1];
                                    cnames[i_136] = cnames[i_136 + 1];
                                }

                                sentn[6] = string;
                                cnames[6] = pnames[im];
                                if(updatec > -11)
                                    updatec = -11;
                                else
                                    updatec--;
                                spos3 = 28;
                            } else
                            {
                                xt.warning++;
                            }
                            gs.cmsg.setText("");
                        }
                        if(chalngd == -1)
                        {
                            rd.setColor(color2k(230, 230, 230));
                            rd.fillRoundRect(225, 59, 495, 200, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(225, 59, 495, 200, 20, 20);
                            if(britchl != 0)
                                britchl = 0;
                            i_104 = (ngm - 5) * 24;
                            if(i_104 < 0)
                                i_104 = 0;
                            i_105 = (int)(((float)spos2 / 82F) * (float)i_104 - 2.0F);
                            int is[] = new int[ngm];
                            int is_137[] = new int[ngm];
                            for(int i_138 = 0; i_138 < ngm; i_138++)
                                is[i_138] = 0;

                            for(int i_139 = 0; i_139 < ngm; i_139++)
                            {
                                for(int i_140 = i_139 + 1; i_140 < ngm; i_140++)
                                {
                                    if(wait[i_139] != wait[i_140])
                                    {
                                        if(wait[i_139] <= 0 && wait[i_140] <= 0)
                                        {
                                            if(wait[i_139] < wait[i_140])
                                                is[i_139]++;
                                            else
                                                is[i_140]++;
                                            continue;
                                        }
                                        if((wait[i_139] > wait[i_140] || wait[i_139] <= 0) && wait[i_140] > 0)
                                            is[i_139]++;
                                        else
                                            is[i_140]++;
                                        continue;
                                    }
                                    if(i_140 < i_139)
                                        is[i_139]++;
                                    else
                                        is[i_140]++;
                                }

                                is_137[is[i_139]] = i_139;
                            }

                            if(control.down)
                            {
                                opselect++;
                                for(boolean bool_141 = false; (80 + 24 * opselect) - i_105 > 202 && !bool_141; i_105 = (int)(((float)spos2 / 82F) * (float)i_104 - 2.0F))
                                {
                                    spos2++;
                                    if(spos2 > 82)
                                    {
                                        spos2 = 82;
                                        bool_141 = true;
                                    }
                                    if(spos2 < 0)
                                    {
                                        spos2 = 0;
                                        bool_141 = true;
                                    }
                                }

                                control.down = false;
                            }
                            if(control.up)
                            {
                                opselect--;
                                for(boolean bool_142 = false; (80 + 24 * opselect) - i_105 < 80 && !bool_142; i_105 = (int)(((float)spos2 / 82F) * (float)i_104 - 2.0F))
                                {
                                    spos2--;
                                    if(spos2 > 82)
                                    {
                                        spos2 = 82;
                                        bool_142 = true;
                                    }
                                    if(spos2 < 0)
                                    {
                                        spos2 = 0;
                                        bool_142 = true;
                                    }
                                }

                                control.up = false;
                            }
                            int i_143 = -1;
                            if(mousonp != -1)
                            {
                                int i_144 = 0;
                                for(int i_145 = 0; i_145 < ngm; i_145++)
                                    if(pgames[mousonp] == gnum[i_145])
                                        i_144 = i_145;

                                i_143 = (91 + 24 * is[i_144]) - i_105;
                                if((80 + 24 * is[i_144]) - i_105 > 202)
                                {
                                    int i_146 = 1000 / i_104;
                                    if(i_146 < 1)
                                        i_146 = 1;
                                    spos2 += i_146;
                                    i_143 = -1;
                                }
                                if((80 + 24 * is[i_144]) - i_105 < 80)
                                {
                                    int i_147 = 1000 / i_104;
                                    if(i_147 < 1)
                                        i_147 = 1;
                                    spos2 -= i_147;
                                    i_143 = -1;
                                }
                                if(spos2 > 82)
                                    spos2 = 82;
                                if(spos2 < 0)
                                    spos2 = 0;
                                i_105 = (int)(((float)spos2 / 82F) * (float)i_104 - 2.0F);
                                opselect = is[i_144];
                            }
                            if(opselect <= -1)
                                opselect = 0;
                            if(opselect >= ngm)
                                opselect = ngm - 1;
                            int i_148 = 0;
                            for(int i_149 = 0; i_149 < ngm; i_149++)
                            {
                                if((80 + 24 * i_149) - i_105 < 224 && (80 + 24 * i_149) - i_105 > 56)
                                {
                                    if(opselect == i_149)
                                    {
                                        if((80 + 24 * i_149) - i_105 >= 224)
                                            opselect--;
                                        if((80 + 24 * i_149) - i_105 < 62)
                                            opselect++;
                                    }
                                    boolean bool_150 = false;
                                    boolean bool_151 = false;
                                    if(!gs.openm)
                                    {
                                        if(i > 241 && i < 692 && i_99 > (92 + 24 * i_149) - i_105 && i_99 < (110 + 24 * i_149) - i_105)
                                        {
                                            if(lxm != i || lym != i_99)
                                                opselect = i_149;
                                            bool_150 = true;
                                            if(bool)
                                            {
                                                if(clicked == -1)
                                                    clicked = is_137[i_149];
                                            } else
                                            {
                                                if(clicked == is_137[i_149])
                                                {
                                                    ongame = gnum[is_137[i_149]];
                                                    opengame = 0;
                                                    if(i >= 641 && i <= 689 && i_99 > (92 + 24 * i_149) - i_105 && i_99 < (110 + 24 * i_149) - i_105 && wait[is_137[i_149]] > 0)
                                                    {
                                                        boolean bool_152 = false;
                                                        if(gwarb[is_137[i_149]] == 0)
                                                        {
                                                            if(gplyrs[is_137[i_149]].equals("") || gplyrs[is_137[i_149]].indexOf(pnames[im]) != -1)
                                                                bool_152 = true;
                                                        } else
                                                        if(xt.clan.toLowerCase().equals(gaclan[is_137[i_149]].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[is_137[i_149]].toLowerCase()))
                                                            bool_152 = true;
                                                        if(bool_152)
                                                        {
                                                            join = gnum[is_137[i_149]];
                                                            msg = "| Joining Game |";
                                                            spos = 0;
                                                        }
                                                    }
                                                    clicked = -1;
                                                }
                                                i_148++;
                                            }
                                        } else
                                        {
                                            i_148++;
                                        }
                                        if(i >= 641 && i <= 689 && i_99 > (92 + 24 * i_149) - i_105 && i_99 < (110 + 24 * i_149) - i_105 && bool)
                                            bool_151 = true;
                                    }
                                    if(opselect == i_149)
                                    {
                                        if(bool_150 && bool || control.enter)
                                        {
                                            rd.setColor(color2k(200, 200, 200));
                                            if(control.enter)
                                            {
                                                ongame = gnum[is_137[i_149]];
                                                opengame = 0;
                                                control.enter = false;
                                            }
                                        } else
                                        {
                                            rd.setColor(color2k(255, 255, 255));
                                        }
                                        rd.fillRect(241, (92 + 24 * i_149) - i_105, 451, 18);
                                        if(bool_150)
                                        {
                                            rd.setColor(color2k(150, 150, 150));
                                            rd.drawRect(239, (90 + 24 * i_149) - i_105, 454, 21);
                                        }
                                    }
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(gstages[is_137[i_149]], 382 - ftm.stringWidth(gstages[is_137[i_149]]) / 2, (105 + 24 * i_149) - i_105);
                                    rd.drawString("|", 525, (105 + 24 * i_149) - i_105);
                                    rd.drawString("|", 584, (105 + 24 * i_149) - i_105);
                                    if(wait[is_137[i_149]] > 0)
                                    {
                                        rd.drawString((new StringBuilder()).append("").append(npls[is_137[i_149]]).append(" / ").append(mnpls[is_137[i_149]]).append("").toString(), 556 - ftm.stringWidth((new StringBuilder()).append("").append(npls[is_137[i_149]]).append(" / ").append(mnpls[is_137[i_149]]).append("").toString()) / 2, (105 + 24 * i_149) - i_105);
                                        rd.setFont(new Font("Arial", 0, 12));
                                        boolean bool_153 = false;
                                        if(gwarb[is_137[i_149]] == 0)
                                        {
                                            if(gplyrs[is_137[i_149]].equals("") || gplyrs[is_137[i_149]].indexOf(pnames[im]) != -1)
                                                bool_153 = true;
                                        } else
                                        if(xt.clan.toLowerCase().equals(gaclan[is_137[i_149]].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[is_137[i_149]].toLowerCase()))
                                            bool_153 = true;
                                        rd.setColor(bool_153 ? new Color(80, 128, 0) : new Color(80, 80, 80));
                                        rd.drawString("Waiting", 593, (105 + 24 * i_149) - i_105);
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        if(!bool_151)
                                        {
                                            rd.setColor(color2k(230, 230, 230));
                                            rd.fill3DRect(641, (92 + 24 * i_149) - i_105, 48, 18, true);
                                            rd.fill3DRect(642, (93 + 24 * i_149) - i_105, 46, 16, true);
                                        } else
                                        {
                                            rd.setColor(color2k(230, 230, 230));
                                            rd.fillRect(641, (92 + 24 * i_149) - i_105, 48, 18);
                                        }
                                        rd.setColor(new Color(0, 0, 0));
                                        if(bool_153)
                                        {
                                            rd.drawString("Join", 665 - ftm.stringWidth("Join") / 2, (105 + 24 * i_149) - i_105);
                                        } else
                                        {
                                            rd.drawImage(lockicn, 243, (94 + 24 * i_149) - i_105, null);
                                            rd.drawString("View", 665 - ftm.stringWidth("View") / 2, (105 + 24 * i_149) - i_105);
                                        }
                                        continue;
                                    }
                                    rd.drawString((new StringBuilder()).append("").append(npls[is_137[i_149]]).append("").toString(), 556 - ftm.stringWidth((new StringBuilder()).append("").append(npls[is_137[i_149]]).append("").toString()) / 2, (105 + 24 * i_149) - i_105);
                                    rd.setFont(new Font("Arial", 0, 12));
                                    ftm = rd.getFontMetrics();
                                    if(wait[is_137[i_149]] == 0)
                                    {
                                        rd.setColor(new Color(128, 73, 0));
                                        rd.drawString("Started", 594, (105 + 24 * i_149) - i_105);
                                    } else
                                    {
                                        rd.setColor(color2k(100, 100, 100));
                                        rd.drawString("Finished", 590, (105 + 24 * i_149) - i_105);
                                    }
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    if(!bool_151)
                                    {
                                        rd.setColor(color2k(230, 230, 230));
                                        rd.fill3DRect(641, (92 + 24 * i_149) - i_105, 48, 18, true);
                                    } else
                                    {
                                        rd.setColor(color2k(230, 230, 230));
                                        rd.fillRect(641, (92 + 24 * i_149) - i_105, 48, 18);
                                    }
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("View", 665 - ftm.stringWidth("View") / 2, (105 + 24 * i_149) - i_105);
                                    continue;
                                }
                                if(opselect == i_149)
                                {
                                    if((80 + 24 * i_149) - i_105 >= 224)
                                        opselect--;
                                    if((80 + 24 * i_149) - i_105 <= 56)
                                        opselect++;
                                }
                                i_148++;
                            }

                            if(i_148 == ngm && clicked != -1)
                                clicked = -1;
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            if(ngm == 0)
                                if(!lloaded)
                                    rd.drawString("|  Loading Games  |", 472 - ftm.stringWidth("|  Loading Games  |") / 2, 165);
                                else
                                if(!xt.lan)
                                    rd.drawString("No Games Created", 472 - ftm.stringWidth("No Games Created") / 2, 165);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(235, 65, 480, 25);
                            rd.drawImage(xt.games, 241, 69, null);
                            rd.setColor(color2k(70, 70, 70));
                            rd.drawString("Stage Name", 382 - ftm.stringWidth("Stage Name") / 2, 81);
                            rd.drawString("|", 525, 81);
                            rd.drawString("Players", 556 - ftm.stringWidth("Players") / 2, 81);
                            rd.drawString("|", 584, 81);
                            rd.drawString("Status", 641 - ftm.stringWidth("Status") / 2, 81);
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(235, 87, 696, 87);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(235, 237, 480, 17);
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(235, 239, 696, 239);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(698, 107, 17, 113);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(231, 65, 4, 189);
                            if(mscro2 == 141 || i_104 == 0)
                            {
                                if(i_104 == 0)
                                    rd.setColor(color2k(205, 205, 205));
                                else
                                    rd.setColor(color2k(215, 215, 215));
                                rd.fillRect(698, 90, 17, 17);
                            } else
                            {
                                rd.setColor(color2k(220, 220, 220));
                                rd.fill3DRect(698, 90, 17, 17, true);
                            }
                            if(i_104 != 0)
                                rd.drawImage(xt.asu, 703, 96, null);
                            if(mscro2 == 142 || i_104 == 0)
                            {
                                if(i_104 == 0)
                                    rd.setColor(color2k(205, 205, 205));
                                else
                                    rd.setColor(color2k(215, 215, 215));
                                rd.fillRect(698, 220, 17, 17);
                            } else
                            {
                                rd.setColor(color2k(220, 220, 220));
                                rd.fill3DRect(698, 220, 17, 17, true);
                            }
                            if(i_104 != 0)
                                rd.drawImage(xt.asd, 703, 226, null);
                            if(i_104 != 0)
                            {
                                if(lspos2 != spos2)
                                {
                                    rd.setColor(color2k(215, 215, 215));
                                    rd.fillRect(698, 107 + spos2, 17, 31);
                                } else
                                {
                                    if(mscro2 == 141)
                                        rd.setColor(color2k(215, 215, 215));
                                    rd.fill3DRect(698, 107 + spos2, 17, 31, true);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(703, 120 + spos2, 709, 120 + spos2);
                                rd.drawLine(703, 122 + spos2, 709, 122 + spos2);
                                rd.drawLine(703, 124 + spos2, 709, 124 + spos2);
                                if(mscro2 > 138 && lspos2 != spos2)
                                    lspos2 = spos2;
                                if(bool)
                                {
                                    if(mscro2 == 145 && i > 698 && i < 715 && i_99 > 107 + spos2 && i_99 < spos2 + 138)
                                        mscro2 = i_99 - spos2;
                                    if(mscro2 == 145 && i > 696 && i < 717 && i_99 > 88 && i_99 < 109)
                                        mscro2 = 141;
                                    if(mscro2 == 145 && i > 696 && i < 717 && i_99 > 218 && i_99 < 239)
                                        mscro2 = 142;
                                    if(mscro2 == 145 && i > 698 && i < 715 && i_99 > 107 && i_99 < 220)
                                    {
                                        mscro2 = 122;
                                        spos2 = i_99 - mscro2;
                                    }
                                    int i_154 = 400 / i_104;
                                    if(i_154 < 1)
                                        i_154 = 1;
                                    if(mscro2 == 141)
                                    {
                                        spos2 -= i_154;
                                        if(spos2 > 82)
                                            spos2 = 82;
                                        if(spos2 < 0)
                                            spos2 = 0;
                                        lspos2 = spos2;
                                    }
                                    if(mscro2 == 142)
                                    {
                                        spos2 += i_154;
                                        if(spos2 > 82)
                                            spos2 = 82;
                                        if(spos2 < 0)
                                            spos2 = 0;
                                        lspos2 = spos2;
                                    }
                                    if(mscro2 <= 138)
                                    {
                                        spos2 = i_99 - mscro2;
                                        if(spos2 > 82)
                                            spos2 = 82;
                                        if(spos2 < 0)
                                            spos2 = 0;
                                    }
                                    if(mscro2 == 145)
                                        mscro2 = 225;
                                } else
                                if(mscro2 != 145)
                                    mscro2 = 145;
                                if(i_100 != 0 && i > 235 && i < 698 && i_99 > 87 && i_99 < 239)
                                {
                                    spos2 -= i_100;
                                    zeromsw = true;
                                    if(spos2 > 82)
                                    {
                                        spos2 = 82;
                                        zeromsw = false;
                                    }
                                    if(spos2 < 0)
                                    {
                                        spos2 = 0;
                                        zeromsw = false;
                                    }
                                    lspos2 = spos2;
                                }
                            }
                            if(mousonp != -1 && i_143 != -1)
                            {
                                rd.setColor(color2k(255, 255, 255));
                                int is_155[] = {
                                    185, 241, 241, 185
                                };
                                int is_156[] = {
                                    i_108, i_143, i_143 + 19, i_108 + 30
                                };
                                rd.fillPolygon(is_155, is_156, 4);
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(185, i_108, 241, i_143);
                                rd.drawLine(185, i_108 + 30, 241, i_143 + 19);
                                rd.drawLine(241, i_143, 692, i_143);
                                rd.drawLine(241, i_143 + 19, 692, i_143 + 19);
                            }
                        } else
                        {
                            int i_157 = 230 + britchl;
                            if(i_157 > 255)
                                i_157 = 255;
                            if(i_157 < 0)
                                i_157 = 0;
                            rd.setColor(color2k(i_157, i_157, i_157));
                            rd.fillRoundRect(225, 59, 495, 200, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(225, 59, 495, 200, 20, 20);
                            if(britchl < 25)
                                britchl += 5;
                            if(chalngd > -1)
                            {
                                int i_158 = 0;
                                for(int i_159 = 0; i_159 < ngm; i_159++)
                                    if(chalngd == gnum[i_159])
                                        i_158 = i_159;

                                if(cflk % 4 != 0 || cflk == 0)
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString((new StringBuilder()).append("You have been invited by ").append(chalby).append(" to join a game!").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("You have been invited by ").append(chalby).append(" to join a game!").toString()) / 2, 95);
                                    rd.setColor(new Color(117, 67, 0));
                                    rd.drawString(chalby, (472 - ftm.stringWidth((new StringBuilder()).append("You have been invited by ").append(chalby).append(" to join a game!").toString()) / 2) + ftm.stringWidth("You have been invited by "), 95);
                                }
                                if(cflk != 0)
                                    cflk--;
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("Stage:  ").append(gstages[i_158]).append(" ,  Laps: ").append(gnlaps[i_158]).append("").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("Stage:  ").append(gstages[i_158]).append(" ,  Laps: ").append(gnlaps[i_158]).append("").toString()) / 2, 130);
                                rd.setColor(new Color(62, 98, 0));
                                rd.drawString(gstages[i_158], (472 - ftm.stringWidth((new StringBuilder()).append("Stage:  ").append(gstages[i_158]).append(" ,  Laps: ").append(gnlaps[i_158]).append("").toString()) / 2) + ftm.stringWidth("Stage:  "), 130);
                                rd.drawString((new StringBuilder()).append("").append(gnlaps[i_158]).append("").toString(), (472 - ftm.stringWidth((new StringBuilder()).append("Stage:  ").append(gstages[i_158]).append(" ,  Laps: ").append(gnlaps[i_158]).append("").toString()) / 2) + ftm.stringWidth((new StringBuilder()).append("Stage:  ").append(gstages[i_158]).append(" ,  Laps: ").toString()), 130);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString((new StringBuilder()).append("Players:  ").append(mnpls[i_158]).append("").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("Players:  ").append(mnpls[i_158]).append("").toString()) / 2, 150);
                                rd.setColor(new Color(62, 98, 0));
                                rd.drawString((new StringBuilder()).append("").append(mnpls[i_158]).append("").toString(), (472 - ftm.stringWidth((new StringBuilder()).append("Players:  ").append(mnpls[i_158]).append("").toString()) / 2) + ftm.stringWidth("Players:  "), 150);
                                Date date = new Date();
                                long l = date.getTime();
                                if(ptime == 0L || l > ptime + 1000L)
                                {
                                    if(ptime != 0L)
                                        ctime--;
                                    ptime = l;
                                }
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Arial", 0, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("( ").append(ctime).append(" )").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("( ").append(ctime).append(" )").toString()) / 2, 170);
                                if(ctime == 0)
                                {
                                    ongame = longame;
                                    chalngd = -1;
                                    longame = -1;
                                }
                                stringbutton("   View Game   ", 352, 215, 2);
                                stringbutton("   Join Game   ", 462, 215, 2);
                                stringbutton("   Decline X   ", 599, 215, 2);
                            } else
                            {
                                if(chalngd != -5)
                                    stringbutton(" Cancel X ", 669, 85, 2);
                                if(chalngd == -6)
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    rd.drawString("This room already has a game that has started.", 288, 120);
                                    rd.drawString("Please switch to another room to create a new game.", 288, 140);
                                    rd.drawString("Or wait for the game to finish.", 288, 160);
                                    rd.drawString("Use the dropdown menu above to change room or server.", 288, 180);
                                    int is[] = {
                                        580, 569, 576, 576, 584, 584, 591
                                    };
                                    int is_160[] = {
                                        66, 77, 77, 102, 102, 77, 77
                                    };
                                    rd.fillPolygon(is, is_160, 7);
                                    stringbutton("     OK     ", 472, 215, 1);
                                }
                                if(chalngd == -2)
                                {
                                    boolean bool_161 = false;
                                    boolean bool_162 = false;
                                    if(!gs.wgame.isShowing())
                                        gs.wgame.show();
                                    gs.wgame.move(236, 68);
                                    if(gs.wgame.getSelectedIndex() == 0)
                                    {
                                        if(inwab)
                                        {
                                            inwab = false;
                                            gs.warb.hide();
                                            loadstage = 0;
                                        }
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.setFont(new Font("Arial", 1, 13));
                                        ftm = rd.getFontMetrics();
                                        if(sflk % 4 != 0 || sflk == 0)
                                            rd.drawString("Select Stage", 472 - ftm.stringWidth("Select Stage") / 2, 85);
                                        if(sflk != 0)
                                            sflk--;
                                        int i_163 = 0;
                                        gs.sgame.setSize(139, 22);
                                        if(gs.sgame.getSelectedIndex() == 0)
                                        {
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.snfmm.getWidth()) / 2;
                                            sgflag = 0;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 1)
                                        {
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.snfm1.getWidth()) / 2;
                                            sgflag = 1;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 2)
                                        {
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.snfm2.getWidth()) / 2;
                                            sgflag = 2;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 3)
                                        {
                                            gs.mstgs.setSize(338, 22);
                                            if(sgflag != 3)
                                            {
                                                gstage = 0;
                                                if(xt.logged)
                                                {
                                                    if(cd.msloaded != 1)
                                                    {
                                                        gs.mstgs.removeAll();
                                                        gs.mstgs.add(rd, "Loading your stages now, please wait...");
                                                        gs.mstgs.select(0);
                                                        msload = 1;
                                                    }
                                                } else
                                                {
                                                    gs.mstgs.removeAll();
                                                    gs.mstgs.add(rd, "You need to have a full account to access this.");
                                                    gs.mstgs.select(0);
                                                    cd.msloaded = 0;
                                                }
                                                sgflag = 3;
                                            }
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.mstgs.getWidth()) / 2;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 4)
                                        {
                                            gs.mstgs.setSize(338, 22);
                                            if(sgflag != 4)
                                            {
                                                gstage = 0;
                                                if(xt.logged)
                                                {
                                                    if(cd.msloaded != 7)
                                                    {
                                                        gs.mstgs.removeAll();
                                                        gs.mstgs.add(rd, "Loading your stages now, please wait...");
                                                        gs.mstgs.select(0);
                                                        msload = 7;
                                                    }
                                                } else
                                                {
                                                    gs.mstgs.removeAll();
                                                    gs.mstgs.add(rd, "You need to have a full account to access this.");
                                                    gs.mstgs.select(0);
                                                    cd.msloaded = 0;
                                                }
                                                sgflag = 4;
                                            }
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.mstgs.getWidth()) / 2;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 5)
                                        {
                                            gs.mstgs.setSize(338, 22);
                                            if(sgflag != 5)
                                            {
                                                gstage = 0;
                                                if(xt.logged)
                                                {
                                                    if(cd.msloaded != 3)
                                                    {
                                                        gs.mstgs.removeAll();
                                                        gs.mstgs.add(rd, "Loading your stages now, please wait...");
                                                        gs.mstgs.select(0);
                                                        msload = 3;
                                                    }
                                                } else
                                                {
                                                    gs.mstgs.removeAll();
                                                    gs.mstgs.add(rd, "You need to have a full account to access this.");
                                                    gs.mstgs.select(0);
                                                    cd.msloaded = 0;
                                                }
                                                sgflag = 5;
                                            }
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.mstgs.getWidth()) / 2;
                                        }
                                        if(gs.sgame.getSelectedIndex() == 6)
                                        {
                                            gs.mstgs.setSize(338, 22);
                                            if(sgflag != 6)
                                            {
                                                gstage = 0;
                                                if(xt.logged)
                                                {
                                                    if(cd.msloaded != 4)
                                                    {
                                                        gs.mstgs.removeAll();
                                                        gs.mstgs.add(rd, "Loading your stages now, please wait...");
                                                        gs.mstgs.select(0);
                                                        msload = 4;
                                                    }
                                                } else
                                                {
                                                    gs.mstgs.removeAll();
                                                    gs.mstgs.add(rd, "You need to have a full account to access this.");
                                                    gs.mstgs.select(0);
                                                    cd.msloaded = 0;
                                                }
                                                sgflag = 6;
                                            }
                                            i_163 = 472 - (gs.sgame.getWidth() + 6 + gs.mstgs.getWidth()) / 2;
                                        }
                                        if(!gs.sgame.isShowing())
                                        {
                                            gs.sgame.show();
                                            remstage = 0;
                                            if(loadstage == 0)
                                            {
                                                int i_164 = (int)(Math.random() * 3D);
                                                if(i_164 == 3)
                                                    i_164 = 2;
                                                gs.sgame.select(i_164);
                                            }
                                        }
                                        gs.sgame.move(i_163, 105);
                                        i_163 += gs.sgame.getWidth() + 6;
                                        if(gs.sgame.getSelectedIndex() == 0)
                                        {
                                            if(!gs.snfmm.isShowing())
                                            {
                                                gs.snfmm.show();
                                                if(loadstage == 0)
                                                    gs.snfmm.select(0);
                                            }
                                            gs.snfmm.move(i_163, 105);
                                            if(gs.snfm1.isShowing())
                                                gs.snfm1.hide();
                                            if(gs.snfm2.isShowing())
                                                gs.snfm2.hide();
                                            if(gs.mstgs.isShowing())
                                                gs.mstgs.hide();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 0 && gs.snfmm.getSelectedIndex() != 0 && gstage != gs.snfmm.getSelectedIndex() + 27)
                                        {
                                            loadstage = gs.snfmm.getSelectedIndex() + 27;
                                            gstage = loadstage;
                                            gs.requestFocus();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 1)
                                        {
                                            if(!gs.snfm2.isShowing())
                                            {
                                                gs.snfm2.show();
                                                if(loadstage == 0)
                                                    gs.snfm2.select(0);
                                            }
                                            gs.snfm2.move(i_163, 105);
                                            if(gs.snfmm.isShowing())
                                                gs.snfmm.hide();
                                            if(gs.snfm1.isShowing())
                                                gs.snfm1.hide();
                                            if(gs.mstgs.isShowing())
                                                gs.mstgs.hide();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 1 && gs.snfm2.getSelectedIndex() != 0 && gstage != gs.snfm2.getSelectedIndex() + 10)
                                        {
                                            loadstage = gs.snfm2.getSelectedIndex() + 10;
                                            gstage = loadstage;
                                            gs.requestFocus();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 2)
                                        {
                                            if(!gs.snfm1.isShowing())
                                            {
                                                gs.snfm1.show();
                                                if(loadstage == 0)
                                                    gs.snfm1.select(0);
                                            }
                                            gs.snfm1.move(i_163, 105);
                                            if(gs.snfmm.isShowing())
                                                gs.snfmm.hide();
                                            if(gs.snfm2.isShowing())
                                                gs.snfm2.hide();
                                            if(gs.mstgs.isShowing())
                                                gs.mstgs.hide();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 2 && gs.snfm1.getSelectedIndex() != 0 && gstage != gs.snfm1.getSelectedIndex())
                                        {
                                            loadstage = gs.snfm1.getSelectedIndex();
                                            gstage = loadstage;
                                            gs.requestFocus();
                                        }
                                        if(gs.sgame.getSelectedIndex() == 3)
                                        {
                                            if(!gs.mstgs.isShowing())
                                            {
                                                gs.mstgs.show();
                                                if(loadstage == 0)
                                                    gs.mstgs.select(0);
                                            }
                                            gs.mstgs.move(i_163, 105);
                                            if(gs.snfmm.isShowing())
                                                gs.snfmm.hide();
                                            if(gs.snfm1.isShowing())
                                                gs.snfm1.hide();
                                            if(gs.snfm2.isShowing())
                                                gs.snfm2.hide();
                                        }
                                        if(remstage != 2)
                                            if(gs.sgame.getSelectedIndex() == 3 && gs.mstgs.getSelectedIndex() != 0)
                                            {
                                                if(gstage != gs.mstgs.getSelectedIndex() + 100)
                                                {
                                                    loadstage = gs.mstgs.getSelectedIndex() + 100;
                                                    gstage = loadstage;
                                                    gs.requestFocus();
                                                    remstage = 0;
                                                }
                                                if(loadstage <= 0 && remstage == 0 && xt.drawcarb(true, null, "X", 674, 136, i, i_99, bool))
                                                    remstage = 1;
                                            } else
                                            if(remstage != 0)
                                                remstage = 0;
                                        if(gs.sgame.getSelectedIndex() >= 4)
                                        {
                                            if(!gs.mstgs.isShowing())
                                            {
                                                gs.mstgs.show();
                                                if(loadstage == 0)
                                                    gs.mstgs.select(0);
                                            }
                                            gs.mstgs.move(i_163, 105);
                                            if(gs.snfmm.isShowing())
                                                gs.snfmm.hide();
                                            if(gs.snfm1.isShowing())
                                                gs.snfm1.hide();
                                            if(gs.snfm2.isShowing())
                                                gs.snfm2.hide();
                                        }
                                        if(gs.sgame.getSelectedIndex() >= 4 && gs.mstgs.getSelectedIndex() != 0 && gstage != gs.mstgs.getSelectedIndex() + 100)
                                        {
                                            loadstage = gs.mstgs.getSelectedIndex() + 100;
                                            gstage = loadstage;
                                            gs.requestFocus();
                                        }
                                        if(loadstage > 0 && remstage == 0)
                                        {
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.setFont(new Font("Arial", 1, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.drawString("Loading stage, please wait...", 472 - ftm.stringWidth("Loading Stage, please wait...") / 2, 165);
                                        }
                                        if(gs.sgame.getSelectedIndex() >= 3 && !xt.logged)
                                        {
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.setFont(new Font("Arial", 1, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.drawString("You are currently using a trial account.", 472 - ftm.stringWidth("You are currently using a trial account.") / 2, 155);
                                            rd.drawString("You need to upgrade your account to access and publish custom stages!", 472 - ftm.stringWidth("You need to upgrade your account to access and publish custom stages!") / 2, 175);
                                            rd.setColor(color2k(200, 200, 200));
                                            rd.fillRoundRect(382, 185, 180, 50, 20, 20);
                                            drawSbutton(xt.upgrade, 472, 210);
                                            if(gs.slaps.isShowing())
                                                gs.slaps.hide();
                                        } else
                                        {
                                            if(loadstage < 0 && remstage == 0)
                                            {
                                                rd.setColor(new Color(0, 0, 0));
                                                rd.setFont(new Font("Arial", 1, 12));
                                                ftm = rd.getFontMetrics();
                                                rd.drawString((new StringBuilder()).append("").append(gstagename).append("  -  Laps:              ").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("").append(gstagename).append("  -  Laps:              ").toString()) / 2, 155);
                                                if(!gs.slaps.isShowing())
                                                {
                                                    gs.slaps.show();
                                                    gs.slaps.select(gstagelaps - 1);
                                                }
                                                gs.slaps.move((472 + ftm.stringWidth((new StringBuilder()).append("").append(gstagename).append("  -  Laps:              ").toString()) / 2) - 35, 138);
                                                if(gs.slaps.getSelectedIndex() != gstagelaps - 1)
                                                {
                                                    gstagelaps = gs.slaps.getSelectedIndex() + 1;
                                                    gs.requestFocus();
                                                }
                                                stringbutton("    Preview Stage    ", 472, 185, 2);
                                            } else
                                            if(gs.slaps.isShowing())
                                                gs.slaps.hide();
                                            if(remstage == 3)
                                            {
                                                if(loadstage < 0)
                                                    stringbutton("    Preview Stage    ", 472, -160, 2);
                                                rd.setColor(new Color(0, 0, 0));
                                                rd.setFont(new Font("Arial", 1, 13));
                                                ftm = rd.getFontMetrics();
                                                xt.drawlprom(135, 75);
                                                rd.drawString("Failed to remove stage, server error, please try again later.", 472 - ftm.stringWidth("Failed to remove stage, server error, please try again later.") / 2, 155);
                                                if(xt.drawcarb(true, null, " OK ", 451, 175, i, i_99, bool))
                                                {
                                                    remstage = 0;
                                                    gs.mouses = 0;
                                                }
                                            }
                                            if(remstage == 2)
                                            {
                                                if(loadstage < 0)
                                                    stringbutton("    Preview Stage    ", 472, -160, 2);
                                                rd.setColor(new Color(0, 0, 0));
                                                rd.setFont(new Font("Arial", 1, 13));
                                                ftm = rd.getFontMetrics();
                                                xt.drawlprom(135, 75);
                                                rd.drawString("Removing stage from your account...", 472 - ftm.stringWidth("Removing stage from your account...") / 2, 175);
                                                if(cd.staction == 0)
                                                {
                                                    gstage = 0;
                                                    loadstage = 0;
                                                    remstage = 0;
                                                }
                                                if(cd.staction == -1)
                                                {
                                                    remstage = 3;
                                                    gs.mouses = 0;
                                                }
                                            }
                                            if(remstage == 1)
                                            {
                                                if(loadstage < 0)
                                                    stringbutton("    Preview Stage    ", 472, -160, 2);
                                                xt.drawlprom(135, 75);
                                                rd.setColor(new Color(0, 0, 0));
                                                rd.setFont(new Font("Arial", 1, 13));
                                                ftm = rd.getFontMetrics();
                                                rd.drawString("Remove this stage from your account?", 472 - ftm.stringWidth("Remove this stage from your account?") / 2, 155);
                                                if(xt.drawcarb(true, null, " Yes ", 426, 175, i, i_99, bool))
                                                {
                                                    remstage = 2;
                                                    cd.onstage = gs.mstgs.getSelectedItem();
                                                    cd.staction = 1;
                                                    cd.sparkstageaction();
                                                    gs.mouses = 0;
                                                }
                                                if(xt.drawcarb(true, null, " No ", 480, 175, i, i_99, bool))
                                                {
                                                    remstage = 0;
                                                    gs.mouses = 0;
                                                }
                                            }
                                            stringbutton("   Next >   ", 472, 235, 1);
                                        }
                                    } else
                                    {
                                        if(!inwab)
                                        {
                                            gs.sgame.hide();
                                            gs.mstgs.hide();
                                            gs.slaps.hide();
                                            gs.snfm1.hide();
                                            gs.snfmm.hide();
                                            gs.snfm2.hide();
                                        }
                                        if(!xt.clan.equals(""))
                                        {
                                            if(!inwab)
                                            {
                                                rd.setColor(new Color(0, 0, 0));
                                                rd.setFont(new Font("Arial", 1, 12));
                                                ftm = rd.getFontMetrics();
                                                rd.drawString("Loading your clan's wars and battles, please wait...", 472 - ftm.stringWidth("Loading your clan's wars and battles, please wait...") / 2, 155);
                                                loadwarb = true;
                                                warbsel = 0;
                                                cancreate = 0;
                                            } else
                                            {
                                                if(!gs.warb.isShowing())
                                                    gs.warb.show();
                                                gs.warb.move(472 - gs.warb.w / 2, 105);
                                                if(gs.warb.sel != 0)
                                                    if(gs.warb.sel != warbsel)
                                                    {
                                                        gb.loadwbgames = 1;
                                                        rd.setColor(new Color(0, 0, 0));
                                                        rd.setFont(new Font("Arial", 1, 12));
                                                        ftm = rd.getFontMetrics();
                                                        rd.drawString("Loading scheduled games, please wait...", 472 - ftm.stringWidth("Loading scheduled games, please wait...") / 2, 165);
                                                        warbsel = gs.warb.sel;
                                                        gs.vnpls.sel = 0;
                                                        gs.vtyp.sel = 0;
                                                        pgamesel = 0;
                                                        cancreate = 0;
                                                    } else
                                                    {
                                                        if(gb.loadwbgames == 7)
                                                        {
                                                            rd.setColor(new Color(0, 0, 0));
                                                            rd.setFont(new Font("Arial", 1, 12));
                                                            ftm = rd.getFontMetrics();
                                                            rd.drawString("Redoing last game, please wait...", 472 - ftm.stringWidth("Redoing last game, please wait...") / 2, 155);
                                                        }
                                                        if(gb.loadwbgames == 2)
                                                        {
                                                            rd.setColor(new Color(0, 0, 0));
                                                            rd.setFont(new Font("Arial", 1, 12));
                                                            ftm = rd.getFontMetrics();
                                                            if(gs.wgame.getSelectedIndex() == 1)
                                                            {
                                                                rd.drawString((new StringBuilder()).append("[ ").append(gb.gameturndisp).append(" ]").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("[ ").append(gb.gameturndisp).append(" ]").toString()) / 2, 155);
                                                                bool_162 = true;
                                                                int i_165 = 472 - (gs.vnpls.w + gs.vtyp.w + 10) / 2;
                                                                gs.vnpls.move(i_165, 168);
                                                                i_165 += gs.vnpls.w + 10;
                                                                gs.vtyp.move(i_165, 168);
                                                                if(!gb.lwbwinner.toLowerCase().equals(xt.clan.toLowerCase()))
                                                                {
                                                                    if(gs.vnpls.sel != 0)
                                                                    {
                                                                        if(pgamesel != -gs.vnpls.sel)
                                                                        {
                                                                            gstagename = gb.wbstages[gb.gameturn];
                                                                            cancreate = 0;
                                                                            pgamesel = -gs.vnpls.sel;
                                                                        }
                                                                        if(cancreate == 1)
                                                                            cancreate = 2;
                                                                        if(cancreate == 0)
                                                                            if(gb.wbstage[gb.gameturn] == 101)
                                                                            {
                                                                                cancreate = 2;
                                                                            } else
                                                                            {
                                                                                loadstage = gb.wbstage[gb.gameturn];
                                                                                cancreate = 1;
                                                                            }
                                                                        if(cancreate == 1)
                                                                            rd.drawString("Loading...", 472 - ftm.stringWidth("Loading...") / 2, 235);
                                                                        if(cancreate == 2)
                                                                            stringbutton("   Create Game   ", 472, 235, 1);
                                                                    }
                                                                } else
                                                                {
                                                                    if(sflk != 0)
                                                                    {
                                                                        sflk--;
                                                                    } else
                                                                    {
                                                                        sflk = 4;
                                                                        rd.setColor(new Color(117, 67, 0));
                                                                    }
                                                                    rd.drawString((new StringBuilder()).append("Your clan won the last game.  ").append(gb.vclan).append(" must create this game!").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("Your clan won the last game.  ").append(gb.vclan).append(" must create this game!").toString()) / 2, 211);
                                                                }
                                                                if(gb.canredo)
                                                                    stringbutton(" Redo last game  < ", 644, 242, 1);
                                                            }
                                                            if(gs.wgame.getSelectedIndex() == 2)
                                                            {
                                                                bool_161 = true;
                                                                gs.pgame.move(472 - gs.pgame.w / 2, 150);
                                                                if(gs.pgame.sel != 0)
                                                                {
                                                                    if(pgamesel != gs.pgame.sel)
                                                                    {
                                                                        gstagename = gb.wbstages[gs.pgame.sel - 1];
                                                                        cancreate = 0;
                                                                        pgamesel = gs.pgame.sel;
                                                                    }
                                                                    if(cancreate == 1)
                                                                        cancreate = 2;
                                                                    if(cancreate == 0)
                                                                        if(gb.wbstage[gs.pgame.sel - 1] == 101)
                                                                        {
                                                                            cancreate = 2;
                                                                        } else
                                                                        {
                                                                            loadstage = gb.wbstage[gs.pgame.sel - 1];
                                                                            cancreate = 1;
                                                                        }
                                                                    if(cancreate == 1)
                                                                        rd.drawString("Loading...", 472 - ftm.stringWidth("Loading...") / 2, 235);
                                                                    if(cancreate == 2)
                                                                        stringbutton("   Create Practice Game   ", 472, 235, 1);
                                                                }
                                                            }
                                                        }
                                                        if(gb.loadwbgames == 3)
                                                            rd.drawString("Failed to load scheduled games, please try again later...", 472 - ftm.stringWidth("Failed to load scheduled games, please try again later...") / 2, 165);
                                                        if(gb.loadwbgames == 4)
                                                            rd.drawString("This war or battle was not found, it may have been expired.", 472 - ftm.stringWidth("This war or battle was not found, it may have been expired.") / 2, 165);
                                                        if(gb.loadwbgames == 6)
                                                            rd.drawString("Failed to undo the last game, please try again later...", 472 - ftm.stringWidth("Failed to undo the last game, please try again later...") / 2, 165);
                                                    }
                                            }
                                        } else
                                        {
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.setFont(new Font("Arial", 1, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.drawString("You must join a clan first to play wars and battles!", 472 - ftm.stringWidth("You must join a clan first to play wars and battles!") / 2, 145);
                                            stringbutton("    Find a clan to join    ", 472, 185, 2);
                                        }
                                        if(!inwab)
                                            inwab = true;
                                    }
                                    if(bool_161)
                                        gs.pgame.show();
                                    else
                                        gs.pgame.hide();
                                    if(bool_162)
                                    {
                                        gs.vnpls.show();
                                        gs.vtyp.show();
                                    } else
                                    {
                                        gs.vnpls.hide();
                                        gs.vtyp.hide();
                                    }
                                }
                                if(chalngd == -3)
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    if(sflk % 4 != 0 || sflk == 0)
                                        rd.drawString("Select Number of Players", 472 - ftm.stringWidth("Select Number of Players") / 2, 85);
                                    if(sflk != 0)
                                        sflk--;
                                    int i_166 = 0;
                                    if(xt.lan)
                                        i_166 = 59;
                                    rd.drawString("Players", 413 - i_166, 122);
                                    if(!gs.snpls.isShowing())
                                    {
                                        gs.snpls.show();
                                        gs.snpls.select(gnpls - 1);
                                    }
                                    gs.snpls.move(467 - i_166, 105);
                                    boolean bool_167 = false;
                                    if(gs.snpls.getSelectedIndex() != 0 && gs.snpls.getSelectedIndex() != gnpls - 1)
                                    {
                                        gnpls = gs.snpls.getSelectedIndex() + 1;
                                        bool_167 = true;
                                        gs.swait.hide();
                                    }
                                    if(xt.lan)
                                    {
                                        rd.drawString("Bots", 490, 122);
                                        if(!gs.snbts.isShowing())
                                        {
                                            gs.snbts.show();
                                            gs.snbts.select(0);
                                            gnbts = 0;
                                        }
                                        gs.snbts.move(524, 105);
                                        if(gs.snbts.getSelectedIndex() != gnbts || bool_167)
                                        {
                                            for(gnbts = gs.snbts.getSelectedIndex(); gnbts + gnpls > 8; gnbts--);
                                            gs.snbts.select(gnbts);
                                        }
                                    }
                                    rd.drawString("Wait", 414, 162);
                                    if(!gs.swait.isShowing())
                                    {
                                        gs.swait.show();
                                        if(gwait == 0)
                                            gs.swait.select(1);
                                    }
                                    gs.swait.move(451, 145);
                                    if((gs.swait.getSelectedIndex() + 1) * 60 != gwait)
                                        gwait = (gs.swait.getSelectedIndex() + 1) * 60;
                                    rd.setColor(color2k(90, 90, 90));
                                    rd.setFont(new Font("Arial", 0, 11));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("( Maximum time to wait for all players to `join. )", 472 - ftm.stringWidth("( Maximum time to wait for all players to join. )") / 2, 179);
                                    stringbutton("   < Back   ", 422, 235, 1);
                                    stringbutton("   Next >   ", 522, 235, 1);
                                }
                                if(chalngd == -4)
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    if(sflk % 4 != 0 || sflk == 0)
                                        rd.drawString("Game Options", 472 - ftm.stringWidth("Game Options") / 2, 85);
                                    if(sflk != 0)
                                        sflk--;
                                    int i_168 = 472 - (gs.scars.getWidth() + gs.sclass.getWidth() + gs.sfix.getWidth() + 16) / 2;
                                    if(!gs.scars.isShowing())
                                    {
                                        gs.scars.show();
                                        if(gcars >= 0 && gcars <= 2)
                                            gs.scars.select(gcars);
                                        else
                                            gs.scars.select(0);
                                    }
                                    gs.scars.move(i_168, 105);
                                    i_168 += gs.scars.getWidth() + 8;
                                    if(!gs.sclass.isShowing())
                                    {
                                        gs.sclass.show();
                                        if(gclass >= 0 && gclass <= 5)
                                            gs.sclass.select(gclass);
                                        else
                                            gs.sclass.select(0);
                                    }
                                    gs.sclass.move(i_168, 105);
                                    i_168 += gs.sclass.getWidth() + 8;
                                    if(!gs.sfix.isShowing())
                                    {
                                        gs.sfix.show();
                                        if(gfix >= 0 && gfix <= 5)
                                            gs.sfix.select(gfix);
                                        else
                                            gs.sfix.select(0);
                                    }
                                    gs.sfix.move(i_168, 105);
                                    i_168 += gs.sfix.getWidth();
                                    if(!gs.openm)
                                        gs.movefield(gs.notp, i_168 - 112, 131, 150, 17);
                                    else
                                        gs.movefield(gs.notp, i_168 - 112, -2000, 150, 17);
                                    if(!gs.notp.isShowing())
                                    {
                                        gs.notp.show();
                                        if(gnotp == 0)
                                            gs.notp.setState(false);
                                        else
                                            gs.notp.setState(true);
                                    }
                                    if(xt.sc[0] < 16)
                                    {
                                        if(!gs.openm)
                                            gs.movefield(gs.mycar, 472 - (gs.scars.getWidth() + gs.sclass.getWidth() + gs.sfix.getWidth() + 16) / 2, 131, 150, 17);
                                        else
                                            gs.movefield(gs.mycar, 410, -2000, 150, 17);
                                        if(!gs.mycar.isShowing())
                                        {
                                            gs.mycar.show();
                                            gs.mycar.setLabel((new StringBuilder()).append("").append(cd.names[xt.sc[0]]).append(" Game!").toString());
                                            if(gclass <= -2)
                                                gs.mycar.setState(true);
                                            else
                                                gs.mycar.setState(false);
                                        }
                                    } else
                                    if(gs.mycar.getState())
                                        gs.mycar.setState(false);
                                    if(gs.mycar.getState())
                                    {
                                        if(gs.sclass.isEnabled())
                                            gs.sclass.disable();
                                        if(gs.scars.isEnabled())
                                            gs.scars.disable();
                                    } else
                                    {
                                        if(!gs.sclass.isEnabled())
                                            gs.sclass.enable();
                                        if(!gs.scars.isEnabled())
                                            gs.scars.enable();
                                        if(gs.sclass.getSelectedIndex() != gclass)
                                        {
                                            gclass = gs.sclass.getSelectedIndex();
                                            gs.mycar.hide();
                                        }
                                        if(gs.scars.getSelectedIndex() != gcars)
                                            gcars = gs.scars.getSelectedIndex();
                                    }
                                    if(gs.sfix.getSelectedIndex() != gfix)
                                        gfix = gs.sfix.getSelectedIndex();
                                    String string = "Public Game, anyone can join...";
                                    int i_169 = 0;
                                    for(int i_170 = 0; i_170 < 7; i_170++)
                                        if(!invos[i_170].equals(""))
                                            i_169++;

                                    if(i_169 > 0)
                                    {
                                        string = "Players Allowed:  ";
                                        int i_171 = 0;
                                        for(int i_172 = 0; i_172 < 7; i_172++)
                                        {
                                            if(invos[i_172].equals(""))
                                                continue;
                                            string = (new StringBuilder()).append(string).append(invos[i_172]).toString();
                                            if(++i_171 == i_169)
                                                continue;
                                            if(i_171 == i_169 - 1)
                                                string = (new StringBuilder()).append(string).append(" and ").toString();
                                            else
                                                string = (new StringBuilder()).append(string).append(", ").toString();
                                        }

                                    }
                                    rd.setColor(new Color(0, 0, 0));
                                    if(i_169 < gnpls - 1)
                                    {
                                        rd.setFont(new Font("Arial", 1, 13));
                                        rd.drawString((new StringBuilder()).append("Private Game, only specific players allowed to join?  ").append(i_169).append("/").append(gnpls - 1).append("").toString(), 330, 180);
                                        stringbutton("<   Select   ", 281, 180, 2);
                                        rd.setFont(new Font("Tahoma", 0, 11));
                                        ftm = rd.getFontMetrics();
                                        rd.drawString(string, 472 - ftm.stringWidth(string) / 2, 203);
                                    } else
                                    {
                                        rd.setFont(new Font("Arial", 1, 13));
                                        ftm = rd.getFontMetrics();
                                        rd.drawString((new StringBuilder()).append("").append(i_169).append(" Allowed Players Selected").toString(), 472 - ftm.stringWidth((new StringBuilder()).append("").append(i_169).append(" Allowed Players Selected").toString()) / 2, 180);
                                        rd.setFont(new Font("Tahoma", 0, 11));
                                        ftm = rd.getFontMetrics();
                                        rd.drawString(string, 472 - ftm.stringWidth(string) / 2, 203);
                                    }
                                    stringbutton("   < Back   ", 422, 235, 1);
                                    stringbutton("   Finish!   ", 522, 235, 1);
                                }
                                if(chalngd == -5)
                                {
                                    if(fstart)
                                        fstart = false;
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(msg, 472 - ftm.stringWidth(msg) / 2, 145);
                                    if(msg.equals(". . . | Creating Game | . . .") && ncnt == 0)
                                    {
                                        msg = "| Creating Game |";
                                        ncnt = 5;
                                    }
                                    if(msg.equals(". . | Creating Game | . .") && ncnt == 0)
                                    {
                                        msg = ". . . | Creating Game | . . .";
                                        ncnt = 5;
                                    }
                                    if(msg.equals(". | Creating Game | .") && ncnt == 0)
                                    {
                                        msg = ". . | Creating Game | . .";
                                        ncnt = 5;
                                    }
                                    if(msg.equals("| Creating Game |") && ncnt == 0)
                                    {
                                        msg = ". | Creating Game | .";
                                        ncnt = 5;
                                    }
                                    if(ncnt != 0)
                                        ncnt--;
                                }
                            }
                        }
                        if(!xt.lan)
                        {
                            rd.setColor(color2k(230, 230, 230));
                            rd.fillRoundRect(225, 263, 495, 157, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(225, 263, 495, 157, 20, 20);
                            String strings[] = new String[14];
                            String strings_173[] = new String[14];
                            boolean bools[] = new boolean[14];
                            for(int i_174 = 0; i_174 < 14; i_174++)
                            {
                                strings[i_174] = "";
                                strings_173[i_174] = "";
                                bools[i_174] = false;
                            }

                            int i_175 = 0;
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(updatec != -1)
                            {
                                for(int i_176 = 0; i_176 < 7; i_176++)
                                {
                                    strings[i_175] = "";
                                    strings_173[i_175] = cnames[i_176];
                                    int i_177 = 0;
                                    int i_178 = 0;
                                    int i_179 = 0;
                                    int i_180 = 0;
                                    int i_181 = 0;
                                    for(; i_177 < sentn[i_176].length(); i_177++)
                                    {
                                        String string = (new StringBuilder()).append("").append(sentn[i_176].charAt(i_177)).toString();
                                        if(string.equals(" "))
                                        {
                                            i_178 = i_179;
                                            i_180 = i_177;
                                            i_181++;
                                        } else
                                        {
                                            i_181 = 0;
                                        }
                                        if(i_181 > 1)
                                            continue;
                                        StringBuilder stringbuilder = new StringBuilder();
                                        String strings_182[] = strings;
                                        int i_183 = i_175;
                                        strings_182[i_183] = stringbuilder.append(strings_182[i_183]).append(string).toString();
                                        i_179++;
                                        if(ftm.stringWidth(strings[i_175]) <= 367)
                                            continue;
                                        if(i_178 != 0)
                                        {
                                            strings[i_175] = strings[i_175].substring(0, i_178);
                                            if(i_175 == 13)
                                            {
                                                for(int i_184 = 0; i_184 < 13; i_184++)
                                                {
                                                    strings[i_184] = strings[i_184 + 1];
                                                    strings_173[i_184] = strings_173[i_184 + 1];
                                                    bools[i_184] = bools[i_184 + 1];
                                                }

                                                strings[i_175] = "";
                                                bools[i_175] = true;
                                            } else
                                            {
                                                i_175++;
                                                strings_173[i_175] = cnames[i_176];
                                            }
                                            i_177 = i_180;
                                            i_179 = 0;
                                            i_178 = 0;
                                        } else
                                        {
                                            strings[i_175] = "";
                                            i_179 = 0;
                                        }
                                    }

                                    if(i_175 == 13 && i_176 != 6)
                                    {
                                        for(int i_185 = 0; i_185 < 13; i_185++)
                                        {
                                            strings[i_185] = strings[i_185 + 1];
                                            strings_173[i_185] = strings_173[i_185 + 1];
                                            bools[i_185] = bools[i_185 + 1];
                                        }

                                    } else
                                    {
                                        i_175++;
                                    }
                                }

                                i_104 = (i_175 - 6) * 15;
                                if(i_104 < 0)
                                    i_104 = 0;
                                i_105 = (int)(((float)spos3 / 28F) * (float)i_104);
                                String string = "";
                                rd.setFont(new Font("Tahoma", 1, 11));
                                ftm = rd.getFontMetrics();
                                for(int i_186 = 0; i_186 < i_175; i_186++)
                                {
                                    if(string.equals(strings_173[i_186]))
                                        continue;
                                    if((280 + i_186 * 15) - i_105 > 266 && (280 + i_186 * 15) - i_105 < 370)
                                        rd.drawString((new StringBuilder()).append(strings_173[i_186]).append(":").toString(), 320 - ftm.stringWidth((new StringBuilder()).append(strings_173[i_186]).append(":").toString()), (305 + i_186 * 15) - i_105);
                                    string = strings_173[i_186];
                                }

                                rd.setFont(new Font("Tahoma", 0, 11));
                                for(int i_187 = 0; i_187 < i_175; i_187++)
                                {
                                    if(bools[i_187] && i_187 == 0 && strings[i_187].indexOf(" ") != -1)
                                        strings[i_187] = (new StringBuilder()).append("...").append(strings[i_187].substring(strings[i_187].indexOf(" "), strings[i_187].length())).append("").toString();
                                    if((280 + i_187 * 15) - i_105 > 266 && (280 + i_187 * 15) - i_105 < 370)
                                        if(Madness.isURL(strings[i_187]))
                                        {
                                            Color tmp = rd.getColor();
                                            rd.setColor(color2k(80, 80, 80));
                                            rd.drawString(strings[i_187], 325, (305 + i_187 * 15) - i_105);
                                            rd.drawLine(324, (307 + i_187 * 15) - i_105, 325 + rd.getFontMetrics().stringWidth(strings[i_187]), (307 + i_187 * 15) - i_105);
                                            gs.customlink(strings[i_187], 325, (305 + i_187 * 15) - i_105, rd.getFontMetrics().stringWidth(strings[i_187]));
                                            rd.setColor(tmp);
                                        } else
                                        {
                                            rd.drawString(strings[i_187], 325, (305 + i_187 * 15) - i_105);
                                        }
                                }

                            } else
                            {
                                i_104 = 0;
                                rd.drawString("Loading chat...", 465 - ftm.stringWidth("Loading chat...") / 2, 325);
                            }
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(235, 269, 480, 25);
                            rd.drawImage(xt.chat, 241, 273, null);
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.setColor(color2k(120, 120, 120));
                            rd.drawString("( Room Chat )", 299, 285);
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(235, 291, 696, 291);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(235, 387, 480, 28);
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(235, 389, 696, 389);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(698, 311, 17, 59);
                            rd.setColor(color2k(205, 205, 205));
                            rd.fillRect(231, 269, 4, 146);
                            if(mscro3 == 351 || i_104 == 0)
                            {
                                if(i_104 == 0)
                                    rd.setColor(color2k(205, 205, 205));
                                else
                                    rd.setColor(color2k(215, 215, 215));
                                rd.fillRect(698, 294, 17, 17);
                            } else
                            {
                                rd.setColor(color2k(220, 220, 220));
                                rd.fill3DRect(698, 294, 17, 17, true);
                            }
                            if(i_104 != 0)
                                rd.drawImage(xt.asu, 703, 300, null);
                            if(mscro3 == 352 || i_104 == 0)
                            {
                                if(i_104 == 0)
                                    rd.setColor(color2k(205, 205, 205));
                                else
                                    rd.setColor(color2k(215, 215, 215));
                                rd.fillRect(698, 370, 17, 17);
                            } else
                            {
                                rd.setColor(color2k(220, 220, 220));
                                rd.fill3DRect(698, 370, 17, 17, true);
                            }
                            if(i_104 != 0)
                                rd.drawImage(xt.asd, 703, 376, null);
                            if(i_104 != 0)
                            {
                                if(lspos3 != spos3)
                                {
                                    rd.setColor(color2k(215, 215, 215));
                                    rd.fillRect(698, 311 + spos3, 17, 31);
                                } else
                                {
                                    if(mscro3 == 141)
                                        rd.setColor(color2k(215, 215, 215));
                                    rd.fill3DRect(698, 311 + spos3, 17, 31, true);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(703, 324 + spos3, 709, 324 + spos3);
                                rd.drawLine(703, 326 + spos3, 709, 326 + spos3);
                                rd.drawLine(703, 328 + spos3, 709, 328 + spos3);
                                if(mscro3 > 342 && lspos3 != spos3)
                                    lspos3 = spos3;
                                if(bool)
                                {
                                    if(mscro3 == 345 && i > 698 && i < 715 && i_99 > 311 + spos3 && i_99 < spos3 + 342)
                                        mscro3 = i_99 - spos3;
                                    if(mscro3 == 345 && i > 696 && i < 717 && i_99 > 292 && i_99 < 313)
                                        mscro3 = 351;
                                    if(mscro3 == 345 && i > 696 && i < 717 && i_99 > 368 && i_99 < 389)
                                        mscro3 = 352;
                                    if(mscro3 == 345 && i > 698 && i < 715 && i_99 > 311 && i_99 < 370)
                                    {
                                        mscro3 = 326;
                                        spos3 = i_99 - mscro3;
                                    }
                                    int i_189 = 100 / i_104;
                                    if(i_189 < 1)
                                        i_189 = 1;
                                    if(mscro3 == 351)
                                    {
                                        spos3 -= i_189;
                                        if(spos3 > 28)
                                            spos3 = 28;
                                        if(spos3 < 0)
                                            spos3 = 0;
                                        lspos3 = spos3;
                                    }
                                    if(mscro3 == 352)
                                    {
                                        spos3 += i_189;
                                        if(spos3 > 28)
                                            spos3 = 28;
                                        if(spos3 < 0)
                                            spos3 = 0;
                                        lspos3 = spos3;
                                    }
                                    if(mscro3 <= 342)
                                    {
                                        spos3 = i_99 - mscro3;
                                        if(spos3 > 28)
                                            spos3 = 28;
                                        if(spos3 < 0)
                                            spos3 = 0;
                                    }
                                    if(mscro3 == 345)
                                        mscro3 = 425;
                                } else
                                if(mscro3 != 345)
                                    mscro3 = 345;
                                if(i_100 != 0 && i > 235 && i < 698 && i_99 > 291 && i_99 < 389)
                                {
                                    spos3 -= i_100 / 2;
                                    zeromsw = true;
                                    if(spos3 > 28)
                                    {
                                        spos3 = 28;
                                        zeromsw = false;
                                    }
                                    if(spos3 < 0)
                                    {
                                        spos3 = 0;
                                        zeromsw = false;
                                    }
                                    lspos3 = spos3;
                                }
                            }
                            pre1 = true;
                            stringbutton("Send Message", 657, 406, 3);
                        }
                        if((chalngd == -1 || chalngd == -6) && lg.gamec != -1)
                        {
                            if(lg.cntgame >= 0 && lg.cntgame < 10)
                                rd.setComposite(AlphaComposite.getInstance(3, (float)lg.cntgame / 10F));
                            if(lg.cntgame > 390 && lg.cntgame < 400)
                                rd.setComposite(AlphaComposite.getInstance(3, (float)(400 - lg.cntgame) / 10F));
                            rd.setColor(color2k(245, 245, 245));
                            rd.fillRoundRect(383, 242, 337, 46, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(383, 242, 337, 46, 20, 20);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("").append(lg.gmaker).append(" created a game in ").append(lg.gservern).append(" :: Room ").append(lg.groom).append("").toString(), 551 - ftm.stringWidth((new StringBuilder()).append("").append(lg.gmaker).append(" created a game in ").append(lg.gservern).append(" :: Room ").append(lg.groom).append("").toString()) / 2, 260);
                            if(i > 488 && i < 614 && i_99 > 264 && i_99 < 287)
                            {
                                if(bool)
                                    grprsd = true;
                                else
                                if(grprsd)
                                {
                                    int i_190 = 0;
                                    do
                                    {
                                        if(i_190 >= lg.nservers)
                                            break;
                                        if(lg.gservern.equals(lg.snames[i_190]))
                                        {
                                            stopallnow();
                                            xt.server = lg.servers[i_190];
                                            xt.servername = lg.snames[i_190];
                                            xt.servport = 7070 + lg.groom;
                                            inishlobby();
                                            break;
                                        }
                                        i_190++;
                                    } while(true);
                                    grprsd = false;
                                }
                            } else
                            if(grprsd)
                                grprsd = false;
                            if(!grprsd)
                            {
                                rd.setColor(color2k(230, 230, 230));
                                rd.fill3DRect(490, 266, 122, 19, true);
                                rd.setColor(new Color(0, 0, 0));
                            } else
                            {
                                rd.setColor(color2k(230, 230, 230));
                                rd.fillRect(490, 266, 122, 19);
                                rd.setColor(color2k(60, 60, 60));
                            }
                            rd.drawString("View / Join Game", 551 - ftm.stringWidth("View / Join Game") / 2, 280);
                            if(lg.cntgame >= 0 && lg.cntgame < 10 || lg.cntgame > 390 && lg.cntgame < 400)
                                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            lg.cntgame++;
                            if(lg.cntgame == 400)
                                lg.gamec = -1;
                        }
                    }
                } else
                if(opengame < 26)
                {
                    int i_191 = 229 + opengame;
                    if(i_191 > 255)
                        i_191 = 255;
                    if(i_191 < 0)
                        i_191 = 0;
                    rd.setColor(color2k(i_191, i_191, i_191));
                    rd.fillRoundRect(225, 59 - (int)((float)opengame * 2.23F), 495, 200 + opengame * 8, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(225, 59 - (int)((float)opengame * 2.23F), 495, 200 + opengame * 8, 20, 20);
                    if(!xt.lan)
                    {
                        rd.setColor(color2k(217, 217, 217));
                        rd.fillRoundRect(225, 263 + opengame * 7, 495, 157, 20, 20);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawRoundRect(225, 263 + opengame * 7, 495, 157, 20, 20);
                    }
                    btn = 0;
                    if(prevloaded != -1)
                        prevloaded = -1;
                    if(updatec != -1)
                        updatec = -1;
                    if(gs.cmsg.isShowing())
                    {
                        gs.cmsg.hide();
                        gs.requestFocus();
                    }
                    if(gs.rooms.isShowing())
                        gs.rooms.hide();
                    if(fstart)
                        fstart = false;
                    for(int i_192 = 0; i_192 < 9; i_192++)
                        if(cac[i_192] != -1)
                            cac[i_192] = -1;

                    if(dispcar != -1)
                        dispcar = -1;
                    opengame += 2;
                } else
                {
                    rd.setColor(color2k(255, 255, 255));
                    rd.fillRoundRect(225, 1, 495, 417, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(225, 1, 495, 417, 20, 20);
                    if(join > -1 && pgames[im] != join || join == -2)
                    {
                        if(join > -1 && pgames[im] != join)
                        {
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            rd.drawString(msg, 472 - ftm.stringWidth(msg) / 2, 195);
                            if(msg.equals(". . . | Joining Game | . . .") && ncnt == 0)
                            {
                                msg = "| Joining Game |";
                                ncnt = 5;
                            }
                            if(msg.equals(". . | Joining Game | . .") && ncnt == 0)
                            {
                                msg = ". . . | Joining Game | . . .";
                                ncnt = 5;
                            }
                            if(msg.equals(". | Joining Game | .") && ncnt == 0)
                            {
                                msg = ". . | Joining Game | . .";
                                ncnt = 5;
                            }
                            if(msg.equals("| Joining Game |") && ncnt == 0)
                            {
                                msg = ". | Joining Game | .";
                                ncnt = 5;
                            }
                            if(ncnt != 0)
                                ncnt--;
                        }
                        if(join == -2)
                        {
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            rd.drawString(msg, 472 - ftm.stringWidth(msg) / 2, 195);
                            if(msg.equals(". . . | Leaving Game | . . .") && ncnt == 0)
                            {
                                msg = "| Leaving Game |";
                                ncnt = 5;
                            }
                            if(msg.equals(". . | Leaving Game | . .") && ncnt == 0)
                            {
                                msg = ". . . | Leaving Game | . . .";
                                ncnt = 5;
                            }
                            if(msg.equals(". | Leaving Game | .") && ncnt == 0)
                            {
                                msg = ". . | Leaving Game | . .";
                                ncnt = 5;
                            }
                            if(msg.equals("| Leaving Game |") && ncnt == 0)
                            {
                                msg = ". | Leaving Game | .";
                                ncnt = 5;
                            }
                            if(ncnt != 0)
                                ncnt--;
                        }
                        if(gs.cmsg.isShowing())
                        {
                            gs.cmsg.hide();
                            gs.requestFocus();
                        }
                    } else
                    {
                        int i_193 = 0;
                        for(int i_194 = 0; i_194 < ngm; i_194++)
                            if(ongame == gnum[i_194])
                                i_193 = i_194;

                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        int i_195 = 23;
                        int i_196 = 0;
                        String string;
                        if(gwarb[i_193] != 0)
                        {
                            i_195 = 28;
                            i_196 = 2;
                            string = "Clan war";
                            if(gwarb[i_193] == 2)
                                string = "Car battle";
                            if(gwarb[i_193] == 3)
                                string = "Stage battle";
                            rd.drawString((new StringBuilder()).append("").append(string).append(" between ").append(gaclan[i_193]).append(" and ").append(gvclan[i_193]).append("").toString(), 243, 14);
                        }
                        string = "";
                        String string_197 = "";
                        String string_198 = "";
                        if(conon == 1)
                        {
                            if(wait[i_193] > 0)
                                if(gwarb[i_193] == 0)
                                {
                                    String string_199 = "";
                                    if(gplyrs[i_193].equals(""))
                                        string_199 = "Public Game";
                                    else
                                        string_199 = "Private Game";
                                    if(gfx[i_193] == 1)
                                        string_199 = (new StringBuilder()).append(string_199).append(" | 4 Fixes").toString();
                                    if(gfx[i_193] == 2)
                                        string_199 = (new StringBuilder()).append(string_199).append(" | 3 Fixes").toString();
                                    if(gfx[i_193] == 3)
                                        string_199 = (new StringBuilder()).append(string_199).append(" | 2 Fixes").toString();
                                    if(gfx[i_193] == 4)
                                        string_199 = (new StringBuilder()).append(string_199).append(" | 1 Fix").toString();
                                    if(gfx[i_193] == 5)
                                        string_199 = (new StringBuilder()).append(string_199).append(" | No Fixing").toString();
                                    String string_200 = "";
                                    if(gclss[i_193] > -2)
                                    {
                                        if(gcrs[i_193] == 1)
                                            string_200 = "Custom Cars";
                                        if(gcrs[i_193] == 2)
                                            string_200 = "Game Cars";
                                        String string_201 = "";
                                        if(gclss[i_193] == 1)
                                            string_201 = "Class C";
                                        if(gclss[i_193] == 2)
                                            string_201 = "Class B & C";
                                        if(gclss[i_193] == 3)
                                            string_201 = "Class B";
                                        if(gclss[i_193] == 4)
                                            string_201 = "Class A & B";
                                        if(gclss[i_193] == 5)
                                            string_201 = "Class A";
                                        if(!string_200.equals("") && !string_201.equals(""))
                                            string_200 = (new StringBuilder()).append(string_200).append(" | ").append(string_201).toString();
                                        else
                                            string_200 = (new StringBuilder()).append(string_200).append(string_201).toString();
                                    } else
                                    {
                                        string_200 = (new StringBuilder()).append("").append(cd.names[Math.abs(gclss[i_193] + 2)]).append("").toString();
                                    }
                                    if(string_200.equals(""))
                                    {
                                        rd.drawString("Type:", 243, 23);
                                        rd.setColor(new Color(80, 128, 0));
                                        rd.drawString(string_199, 279, 23);
                                    } else
                                    {
                                        rd.drawString("Type:", 243, 14);
                                        rd.drawString("Cars:", 244, 28);
                                        rd.setColor(new Color(80, 128, 0));
                                        rd.drawString(string_199, 279, 14);
                                        rd.drawString(string_200, 279, 28);
                                    }
                                } else
                                {
                                    StringBuilder builder = (new StringBuilder()).append("Game #").append(gameturn[i_193]);
                                    if(gcrs[i_193] == 1)
                                        builder.append(" | Clan Cars");
                                    if(gcrs[i_193] == 2)
                                        builder.append(" | Game Cars");
                                    if(gclss[i_193] == 1)
                                        builder.append(" | Class C");
                                    if(gclss[i_193] == 2)
                                        builder.append(" | Class B & C");
                                    if(gclss[i_193] == 3)
                                        builder.append(" | Class B");
                                    if(gclss[i_193] == 4)
                                        builder.append(" | Class A & B");
                                    if(gclss[i_193] == 5)
                                        builder.append(" | Class A");
                                    if(gfx[i_193] == 1)
                                        builder.append(" | 4 Fixes");
                                    if(gfx[i_193] == 2)
                                        builder.append(" | 3 Fixes");
                                    if(gfx[i_193] == 3)
                                        builder.append(" | 2 Fixes");
                                    if(gfx[i_193] == 4)
                                        builder.append(" | 1 Fix");
                                    if(gfx[i_193] == 5)
                                        builder.append(" | No Fixing");
                                    rd.setColor(new Color(80, 128, 0));
                                    rd.drawString(builder.toString(), 243, 28);
                                }
                            if(wait[i_193] == 0)
                            {
                                rd.drawString("Status:", 241 + i_196, i_195);
                                rd.setColor(new Color(128, 73, 0));
                                if(prevloaded == 0)
                                    rd.drawString("Starting...", 286 + i_196, i_195);
                                else
                                    rd.drawString("Started", 286 + i_196, i_195);
                            }
                            if(wait[i_193] == -1)
                            {
                                rd.drawString("Status:", 241 + i_196, i_195);
                                rd.setColor(color2k(100, 100, 100));
                                rd.drawString("Finished", 286 + i_196, i_195);
                            }
                        } else
                        {
                            rd.drawString("Status:", 241 + i_196, i_195);
                            rd.setColor(new Color(128, 73, 0));
                            rd.drawString("Starting...", 286 + i_196, i_195);
                        }
                        if(gwarb[i_193] == 0)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(gmaker[i_193].equals(pnames[im]))
                            {
                                rd.drawString("Created by You", 449, 23);
                            } else
                            {
                                rd.drawString("Created by", 449, 23);
                                rd.drawString(":", 511, 23);
                                rd.drawString(gmaker[i_193], 520, 23);
                            }
                        } else
                        if(wait[i_193] == 0 || wait[i_193] == -1 || conon != 1)
                        {
                            rd.setColor(color2k(200, 200, 200));
                            rd.drawRect(349, 16, 253, 16);
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            int i_203 = 0;
                            int i_204 = 0;
                            if(wait[i_193] == -1)
                            {
                                String strings[] = {
                                    "", "", "", "", "", "", "", ""
                                };
                                for(int i_205 = 0; i_205 < prnpo; i_205++)
                                {
                                    for(int i_206 = 0; i_206 < npo; i_206++)
                                        if(prnames[i_205].equals(pnames[i_206]) && pgames[i_206] == gnum[i_193])
                                            strings[i_205] = pclan[i_206];

                                }

                                int i_207 = 0;
                                do
                                {
                                    if(i_207 >= prnpo)
                                        break;
                                    if(ppos[i_207] == 0)
                                    {
                                        string = strings[i_207];
                                        break;
                                    }
                                    i_207++;
                                } while(true);
                                if(!string.equals(""))
                                {
                                    if(gwtyp[i_193] == 2)
                                    {
                                        boolean bool_208 = false;
                                        int i_209 = 0;
                                        do
                                        {
                                            if(i_209 >= prnpo)
                                                break;
                                            if(!strings[i_209].toLowerCase().equals(string.toLowerCase()) && pdam[i_209] < 55 && pdam[i_209] != -17)
                                            {
                                                bool_208 = true;
                                                break;
                                            }
                                            i_209++;
                                        } while(true);
                                        if(!bool_208)
                                        {
                                            string_198 = (new StringBuilder()).append("").append(string).append(" should have raced in this game!").toString();
                                            string = "";
                                        }
                                    }
                                    if(gwtyp[i_193] == 3)
                                    {
                                        boolean bool_210 = true;
                                        int i_211 = 0;
                                        do
                                        {
                                            if(i_211 >= prnpo)
                                                break;
                                            if(!strings[i_211].toLowerCase().equals(string.toLowerCase()) && pdam[i_211] < 55 && pdam[i_211] != -17)
                                            {
                                                bool_210 = false;
                                                break;
                                            }
                                            i_211++;
                                        } while(true);
                                        if(!bool_210)
                                        {
                                            string_198 = (new StringBuilder()).append("").append(string).append(" should have wasted in this game!").toString();
                                            string = "";
                                        }
                                    }
                                    if(gwtyp[i_193] == 4)
                                        if(string.toLowerCase().equals(gaclan[i_193].toLowerCase()))
                                        {
                                            boolean bool_212 = true;
                                            int i_213 = 0;
                                            do
                                            {
                                                if(i_213 >= prnpo)
                                                    break;
                                                if(!strings[i_213].toLowerCase().equals(string.toLowerCase()) && pdam[i_213] < 55 && pdam[i_213] != -17)
                                                {
                                                    bool_212 = false;
                                                    break;
                                                }
                                                i_213++;
                                            } while(true);
                                            if(!bool_212)
                                            {
                                                string_198 = (new StringBuilder()).append("").append(string).append(" should have wasted in this game!").toString();
                                                string = "";
                                            }
                                        } else
                                        {
                                            boolean bool_214 = false;
                                            int i_215 = 0;
                                            do
                                            {
                                                if(i_215 >= prnpo)
                                                    break;
                                                if(!strings[i_215].toLowerCase().equals(string.toLowerCase()) && pdam[i_215] < 55 && pdam[i_215] != -17)
                                                {
                                                    bool_214 = true;
                                                    break;
                                                }
                                                i_215++;
                                            } while(true);
                                            if(!bool_214)
                                            {
                                                string_198 = (new StringBuilder()).append("").append(string).append(" should have raced in this game!").toString();
                                                string = "";
                                            }
                                        }
                                    if(gwtyp[i_193] == 5)
                                        if(!string.toLowerCase().equals(gaclan[i_193].toLowerCase()))
                                        {
                                            boolean bool_216 = true;
                                            int i_217 = 0;
                                            do
                                            {
                                                if(i_217 >= prnpo)
                                                    break;
                                                if(!strings[i_217].toLowerCase().equals(string.toLowerCase()) && pdam[i_217] < 55 && pdam[i_217] != -17)
                                                {
                                                    bool_216 = false;
                                                    break;
                                                }
                                                i_217++;
                                            } while(true);
                                            if(!bool_216)
                                            {
                                                string_198 = (new StringBuilder()).append("").append(string).append(" should have wasted in this game!").toString();
                                                string = "";
                                            }
                                        } else
                                        {
                                            boolean bool_218 = false;
                                            int i_219 = 0;
                                            do
                                            {
                                                if(i_219 >= prnpo)
                                                    break;
                                                if(!strings[i_219].toLowerCase().equals(string.toLowerCase()) && pdam[i_219] < 55 && pdam[i_219] != -17)
                                                {
                                                    bool_218 = true;
                                                    break;
                                                }
                                                i_219++;
                                            } while(true);
                                            if(!bool_218)
                                            {
                                                string_198 = (new StringBuilder()).append("").append(string).append(" should have raced in this game!").toString();
                                                string = "";
                                            }
                                        }
                                } else
                                {
                                    string_198 = "No one finished first - no one survived!";
                                }
                                if(string.toLowerCase().equals(gaclan[i_193].toLowerCase()))
                                    i_203 = 1;
                                if(string.toLowerCase().equals(gvclan[i_193].toLowerCase()))
                                    i_204 = 1;
                            }
                            rd.drawString((new StringBuilder()).append("").append(gaclan[i_193]).append(" : ").append(gascore[i_193] + i_203).append("     |     ").append(gvclan[i_193]).append(" : ").append(gvscore[i_193] + i_204).append("").toString(), 474 - ftm.stringWidth((new StringBuilder()).append("").append(gaclan[i_193]).append(" : ").append(gascore[i_193]).append("     |     ").append(gvclan[i_193]).append(" : ").append(gvscore[i_193]).append("").toString()) / 2, 28);
                            if(gwarb[i_193] == 1)
                            {
                                if(gascore[i_193] + i_203 >= 5)
                                    string_197 = (new StringBuilder()).append("").append(gaclan[i_193]).append(" wins the war!").toString();
                                if(gvscore[i_193] + i_204 >= 5)
                                    string_197 = (new StringBuilder()).append("").append(gvclan[i_193]).append(" wins the war!").toString();
                            } else
                            {
                                if(gascore[i_193] + i_203 >= 3)
                                    string_197 = (new StringBuilder()).append("").append(gaclan[i_193]).append(" wins the battle!").toString();
                                if(gvscore[i_193] + i_204 >= 3)
                                    string_197 = (new StringBuilder()).append("").append(gvclan[i_193]).append(" wins the battle!").toString();
                            }
                        }
                        rd.setColor(color2k(200, 200, 200));
                        rd.drawLine(233, 32, 602, 32);
                        rd.drawLine(602, 7, 602, 32);
                        if(conon == 1)
                            if(pgames[im] == ongame)
                                stringbutton("Leave Game X", 660, 26, 0);
                            else
                                stringbutton("Close X", 679, 26, 0);
                        rd.drawImage(xt.pls, 292, 39, null);
                        if(opengame != 27)
                        {
                            m.crs = true;
                            m.x = -335;
                            m.y = 0;
                            m.z = -50;
                            m.xz = 0;
                            m.zy = 20;
                            m.ground = -2000;
                            pend = 0;
                            pendb = false;
                            ptime = 0L;
                            opengame = 27;
                        }
                        int i_220 = 0;
                        int i_221 = -1;
                        for(int i_222 = 0; i_222 < npo; i_222++)
                        {
                            if(pgames[i_222] != ongame)
                                continue;
                            rd.setColor(color2k(240, 240, 240));
                            if(i_222 == im && wait[i_193] != -1)
                                if(nflk == 0 || conon == 2)
                                {
                                    rd.setColor(color2k(255, 255, 255));
                                    nflk = 3;
                                } else
                                {
                                    nflk--;
                                }
                            rd.fillRect(237, 54 + i_220 * 42, 170, 40);
                            rd.setColor(color2k(200, 200, 200));
                            if(gwarb[i_193] != 0)
                            {
                                if(pclan[i_222].toLowerCase().equals(gaclan[i_193].toLowerCase()))
                                    rd.setColor(new Color(255, 128, 0));
                                if(pclan[i_222].toLowerCase().equals(gvclan[i_193].toLowerCase()))
                                    rd.setColor(new Color(0, 128, 255));
                                if(wait[i_193] == -1 && prevloaded == 1 && string.toLowerCase().equals(pclan[i_222].toLowerCase()) && nflk == 0)
                                    rd.setColor(new Color(0, 0, 0));
                            } else
                            if(wait[i_193] == -1 && prevloaded == 1)
                            {
                                for(int i_223 = 0; i_223 < prnpo; i_223++)
                                    if(pnames[i_222].equals(prnames[i_223]) && ppos[i_223] == 0 && nflk == 0)
                                        rd.setColor(new Color(0, 0, 0));

                            }
                            rd.drawRect(237, 54 + i_220 * 42, 170, 40);
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString(pnames[i_222], 282 - ftm.stringWidth(pnames[i_222]) / 2, 72 + i_220 * 42);
                            rd.setFont(new Font("Arial", 0, 10));
                            ftm = rd.getFontMetrics();
                            rd.drawString(pcarnames[i_222], 282 - ftm.stringWidth(pcarnames[i_222]) / 2, 84 + i_220 * 42);
                            m.crs = true;
                            m.x = -335;
                            m.y = 0;
                            m.z = -50;
                            m.xz = 0;
                            m.zy = 20;
                            m.ground = -2000;
                            if(pcars[i_222] != -1)
                            {
                                for(int i_224 = 0; i_224 < contos[pcars[i_222]].npl; i_224++)
                                {
                                    contos[pcars[i_222]].p[i_224].flx = 0;
                                    if(contos[pcars[i_222]].p[i_224].colnum == 1)
                                    {
                                        contos[pcars[i_222]].p[i_224].hsb[0] = pcols[i_222][0];
                                        contos[pcars[i_222]].p[i_224].hsb[1] = pcols[i_222][1];
                                        contos[pcars[i_222]].p[i_224].hsb[2] = 1.0F - pcols[i_222][2];
                                    }
                                    if(contos[pcars[i_222]].p[i_224].colnum == 2)
                                    {
                                        contos[pcars[i_222]].p[i_224].hsb[0] = pcols[i_222][3];
                                        contos[pcars[i_222]].p[i_224].hsb[1] = pcols[i_222][4];
                                        contos[pcars[i_222]].p[i_224].hsb[2] = 1.0F - pcols[i_222][5];
                                    }
                                }

                                if(cac[i_220] != pcars[i_222])
                                {
                                    int i_225 = contos[pcars[i_222]].p[0].oz[0];
                                    int i_226 = i_225;
                                    int i_227 = contos[pcars[i_222]].p[0].oy[0];
                                    int i_228 = i_227;
                                    for(int i_229 = 0; i_229 < contos[pcars[i_222]].npl; i_229++)
                                    {
                                        for(int i_230 = 0; i_230 < contos[pcars[i_222]].p[i_229].n; i_230++)
                                        {
                                            if(contos[pcars[i_222]].p[i_229].oz[i_230] < i_225)
                                                i_225 = contos[pcars[i_222]].p[i_229].oz[i_230];
                                            if(contos[pcars[i_222]].p[i_229].oz[i_230] > i_226)
                                                i_226 = contos[pcars[i_222]].p[i_229].oz[i_230];
                                            if(contos[pcars[i_222]].p[i_229].oy[i_230] < i_227)
                                                i_227 = contos[pcars[i_222]].p[i_229].oy[i_230];
                                            if(contos[pcars[i_222]].p[i_229].oy[i_230] > i_228)
                                                i_228 = contos[pcars[i_222]].p[i_229].oy[i_230];
                                        }

                                    }

                                    cax[i_220] = (i_226 + i_225) / 2;
                                    cay[i_220] = (i_228 + i_227) / 2;
                                    cac[i_220] = pcars[i_222];
                                }
                                if(i > 327 && i < 402 && i_99 > 57 + i_220 * 42 && i_99 < 91 + i_220 * 42)
                                {
                                    i_101 = 12;
                                    i_221 = i_222;
                                    for(int i_231 = 0; i_231 < contos[pcars[i_222]].npl; i_231++)
                                        contos[pcars[i_222]].p[i_231].flx = 77;

                                }
                                contos[pcars[i_222]].z = 2500 - i_220 * 80;
                                contos[pcars[i_222]].y = (150 + 250 * i_220) - cay[i_220];
                                contos[pcars[i_222]].x = -145 - cax[i_220];
                                contos[pcars[i_222]].zy = 0;
                                contos[pcars[i_222]].xz = -90;
                                contos[pcars[i_222]].xy = pend - i_220 * 5;
                                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                                contos[pcars[i_222]].d(rd);
                                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            } else
                            {
                                rd.setFont(new Font("Arial", 1, 11));
                                rd.setColor(color2k(80, 80, 80));
                                rd.drawString("Loading...", 339, 77 + i_220 * 42);
                            }
                            i_220++;
                        }

                        if(!pendb)
                        {
                            pend += 2;
                            if(pend > 80)
                                pendb = true;
                        } else
                        {
                            pend -= 2;
                            if(pend < -10)
                                pendb = false;
                        }
                        if(i_221 != -1)
                        {
                            if(bool)
                                mousedout = true;
                            else
                            if(mousedout)
                            {
                                if(dispcar != i_221 && i_221 != -1 && cd.action != 6)
                                {
                                    cd.action = 0;
                                    dispcar = i_221;
                                    forcar = pcars[i_221];
                                    dispco = null;
                                    System.gc();
                                    dispco = new ContO(contos[forcar], 0, 0, 0, 0);
                                } else
                                {
                                    dispcar = -1;
                                }
                                mousedout = false;
                            }
                        } else
                        if(mousedout)
                            mousedout = false;
                        for(int i_232 = 0; i_232 < 7; i_232++)
                        {
                            for(int i_233 = 0; i_233 < npo; i_233++)
                            {
                                if(pgames[i_233] != ongame || !invos[i_232].equals(pnames[i_233]) || !dinvi[i_232].equals(invos[i_232]))
                                    continue;
                                for(int i_234 = i_232; i_234 < 6; i_234++)
                                {
                                    invos[i_234] = invos[i_234 + 1];
                                    dinvi[i_234] = dinvi[i_234 + 1];
                                }

                                invos[6] = "";
                                dinvi[6] = "";
                            }

                        }

                        if(wait[i_193] > 0)
                        {
                            int i_235 = 0;
                            for(int i_236 = i_220; i_236 < mnpls[i_193]; i_236++)
                            {
                                rd.setColor(color2k(200, 200, 200));
                                rd.drawRect(237, 54 + i_236 * 42, 170, 40);
                                boolean bool_237 = false;
                                if(pgames[im] == ongame)
                                {
                                    if(!gplyrs[i_193].equals(""))
                                        bool_237 = true;
                                } else
                                if(gwarb[i_193] == 0)
                                {
                                    if(!gplyrs[i_193].equals("") && gplyrs[i_193].indexOf(pnames[im]) == -1)
                                        bool_237 = true;
                                } else
                                if(!xt.clan.toLowerCase().equals(gaclan[i_193].toLowerCase()) && !xt.clan.toLowerCase().equals(gvclan[i_193].toLowerCase()))
                                    bool_237 = true;
                                if(i > 237 && i < 407 && i_99 > 54 + i_236 * 42 && i_99 < 94 + i_236 * 42 && !bool_237)
                                {
                                    if(pgames[im] == ongame)
                                        stringbutton("<     Invite Player      ", 322, 79 + i_236 * 42, 0);
                                    else
                                        stringbutton("    Join Game    ", 322, 79 + i_236 * 42, 0);
                                    pbtn = 1;
                                } else
                                if(invos[i_235].equals(""))
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("Empty", 322 - ftm.stringWidth("Empty") / 2, 72 + i_236 * 42);
                                    rd.setFont(new Font("Arial", 0, 10));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("Waiting for player...", 322 - ftm.stringWidth("Waiting for player...") / 2, 84 + i_236 * 42);
                                } else
                                if(!dinvi[i_235].equals(invos[i_235]))
                                {
                                    if(nflk != 0)
                                    {
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.setFont(new Font("Arial", 0, 12));
                                        ftm = rd.getFontMetrics();
                                        rd.drawString("Inviting player...", 322 - ftm.stringWidth("Inviting player...") / 2, 79 + i_236 * 42);
                                    }
                                } else
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 0, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("Player Invited!", 322 - ftm.stringWidth("Player Invited!") / 2, 71 + i_236 * 42);
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString(invos[i_235], 322 - ftm.stringWidth(invos[i_235]) / 2, 87 + i_236 * 42);
                                }
                                i_235++;
                            }

                        }
                        if(xt.lan && mnbts[i_193] != 0)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("Plus ").append(mnbts[i_193]).append(" MadBots!").toString(), 322 - ftm.stringWidth((new StringBuilder()).append("Plus ").append(mnbts[i_193]).append(" MadBots!").toString()) / 2, 73 + mnpls[i_193] * 42);
                        }
                        if(dispcar == -1 || conon != 1)
                        {
                            rd.drawImage(xt.sts, 537, 39, null);
                            rd.setColor(color2k(200, 200, 200));
                            rd.drawRect(415, 54, 293, 166);
                            if(conon == 1)
                            {
                                if(wait[i_193] > 0)
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    if(gwarb[i_193] == 0)
                                    {
                                        if(wait[i_193] > 30 || npls[i_193] <= 1)
                                        {
                                            String string_238 = "s";
                                            if(mnpls[i_193] - npls[i_193] == 1)
                                                string_238 = "";
                                            rd.drawString((new StringBuilder()).append("Waiting for ").append(mnpls[i_193] - npls[i_193]).append(" more player").append(string_238).append(" to join to start.").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Waiting for ").append(mnpls[i_193] - npls[i_193]).append(" more player").append(string_238).append(" to join to start.").toString()) / 2, 98);
                                            rd.setFont(new Font("Arial", 0, 12));
                                            ftm = rd.getFontMetrics();
                                            int i_239 = 134;
                                            if(!gmaker[i_193].equals("Coach Insano") && !gmaker[i_193].equals(pnames[im]))
                                            {
                                                boolean bool_240 = false;
                                                for(int i_241 = 0; i_241 < npo; i_241++)
                                                    if(pgames[i_241] == ongame && gmaker[i_193].equals(pnames[i_241]))
                                                        bool_240 = true;

                                                if(bool_240)
                                                {
                                                    i_239 = 144;
                                                    rd.drawString((new StringBuilder()).append("").append(gmaker[i_193]).append(" can start this game at anytime.").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("").append(gmaker[i_193]).append(" can start this game at anytime.").toString()) / 2, 124);
                                                }
                                            }
                                            if(npls[i_193] > 1)
                                            {
                                                String string_242 = (new StringBuilder()).append("").append(wait[i_193]).append(" seconds").toString();
                                                if(wait[i_193] > 60)
                                                    string_242 = (new StringBuilder()).append("").append((float)(int)(((float)wait[i_193] / 60F) * 100F) / 100F).append(" minutes").toString();
                                                rd.drawString((new StringBuilder()).append("( Waiting ").append(string_242).append(" maximum! )").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("( Waiting ").append(string_242).append(" maximum! )").toString()) / 2, i_239);
                                            }
                                        } else
                                        {
                                            Date date = new Date();
                                            long l = date.getTime();
                                            if(ptime == 0L || l > ptime + 1500L)
                                            {
                                                if(ptime != 0L)
                                                {
                                                    wait[i_193]--;
                                                    if(wait[i_193] < 1)
                                                        wait[i_193] = 1;
                                                }
                                                ptime = l;
                                            }
                                            if(pgames[im] == ongame || nflk != 0)
                                            {
                                                rd.drawString((new StringBuilder()).append("Game starts in ").append(wait[i_193]).append(" seconds!").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Game starts in ").append(wait[i_193]).append(" seconds!").toString()) / 2, 124);
                                                if(pgames[im] != ongame)
                                                    nflk--;
                                            } else
                                            if(pgames[im] != ongame)
                                                nflk = 3;
                                        }
                                        if(pgames[im] != ongame)
                                        {
                                            if(gplyrs[i_193].equals("") || gplyrs[i_193].indexOf(pnames[im]) != -1)
                                            {
                                                stringbutton("    Join this Game    ", 561, 182, 0);
                                            } else
                                            {
                                                rd.setFont(new Font("Arial", 1, 12));
                                                ftm = rd.getFontMetrics();
                                                rd.setColor(new Color(128, 73, 0));
                                                rd.drawString("Private Game, only specific players allowed.", 561 - ftm.stringWidth("Private Game, only specific players allowed.") / 2, 180);
                                                stringbutton("    Join this Game    ", 561, -1000, 0);
                                            }
                                        } else
                                        if(gmaker[i_193].equals(pnames[im]))
                                        {
                                            if(npls[i_193] > 1)
                                            {
                                                if(!fstart)
                                                    stringbutton("    Start this Game Now!    ", 561, 182, 0);
                                                else
                                                    stringbutton("    Starting game now, one moment...    ", 561, 182, 0);
                                            } else
                                            {
                                                rd.setFont(new Font("Arial", 1, 12));
                                                ftm = rd.getFontMetrics();
                                                rd.setColor(new Color(128, 73, 0));
                                                rd.drawString("You have created this game.", 561 - ftm.stringWidth("You have created this game.") / 2, 180);
                                            }
                                        } else
                                        {
                                            rd.setFont(new Font("Arial", 1, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(80, 128, 0));
                                            rd.drawString("You have joined this game.", 561 - ftm.stringWidth("You have joined this game.") / 2, 180);
                                        }
                                    } else
                                    {
                                        String string_243 = "s";
                                        if(mnpls[i_193] - npls[i_193] == 1)
                                            string_243 = "";
                                        rd.drawString((new StringBuilder()).append("Waiting for ").append(mnpls[i_193] - npls[i_193]).append(" clan member").append(string_243).append(" to join to start.").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Waiting for ").append(mnpls[i_193] - npls[i_193]).append(" clan member").append(string_243).append(" to join to start.").toString()) / 2, 72);
                                        int i_244 = mnpls[i_193] / 2;
                                        int i_245 = mnpls[i_193] / 2;
                                        for(int i_246 = 0; i_246 < npo; i_246++)
                                        {
                                            if(pgames[i_246] != gnum[i_193])
                                                continue;
                                            if(pclan[i_246].toLowerCase().equals(gaclan[i_193].toLowerCase()) && --i_244 < 0)
                                                i_244 = 0;
                                            if(pclan[i_246].toLowerCase().equals(gvclan[i_193].toLowerCase()) && --i_245 < 0)
                                                i_245 = 0;
                                        }

                                        rd.setFont(new Font("Arial", 0, 12));
                                        ftm = rd.getFontMetrics();
                                        rd.drawString((new StringBuilder()).append("( ").append(i_244).append(" of ").append(gaclan[i_193]).append("  &  ").append(i_245).append(" of ").append(gvclan[i_193]).append(" )").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("( ").append(i_244).append(" of ").append(gaclan[i_193]).append("  &  ").append(i_245).append(" of ").append(gvclan[i_193]).append(" )").toString()) / 2, 87);
                                        rd.drawString(gaclan[i_193], 491 - ftm.stringWidth(gaclan[i_193]) / 2, 125);
                                        rd.drawString(gvclan[i_193], 631 - ftm.stringWidth(gvclan[i_193]) / 2, 125);
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        String string_247 = "War";
                                        if(gwarb[i_193] > 1)
                                            string_247 = "Battle";
                                        rd.drawString((new StringBuilder()).append("").append(string_247).append(" Score").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("").append(string_247).append(" Score").toString()) / 2, 107);
                                        rd.drawString((new StringBuilder()).append("").append(gascore[i_193]).append("").toString(), 491 - ftm.stringWidth((new StringBuilder()).append("").append(gascore[i_193]).append("").toString()) / 2, 139);
                                        rd.drawString((new StringBuilder()).append("").append(gvscore[i_193]).append("").toString(), 631 - ftm.stringWidth((new StringBuilder()).append("").append(gascore[i_193]).append("").toString()) / 2, 139);
                                        rd.drawRect(421, 111, 280, 33);
                                        rd.drawLine(561, 111, 561, 144);
                                        rd.setColor(new Color(255, 128, 0));
                                        rd.drawRect(422, 112, 138, 31);
                                        rd.setColor(new Color(0, 128, 255));
                                        rd.drawRect(562, 112, 138, 31);
                                        if(pgames[im] != ongame)
                                        {
                                            if(xt.clan.toLowerCase().equals(gaclan[i_193].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[i_193].toLowerCase()))
                                            {
                                                stringbutton("    Join this Game    ", 561, 200, 0);
                                            } else
                                            {
                                                rd.setColor(new Color(128, 73, 0));
                                                rd.drawString("You must be a member of either clan to join.", 561 - ftm.stringWidth("You must be a member of either clan to join.") / 2, 198);
                                            }
                                        } else
                                        {
                                            if(gmaker[i_193].equals(pnames[im]) && npls[i_193] > 1)
                                                stringbutton("    Start this Game Now!    ", 561, -1000, 0);
                                            rd.setColor(new Color(80, 128, 0));
                                            rd.drawString("You have joined this game.", 561 - ftm.stringWidth("You have joined this game.") / 2, 198);
                                        }
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        if(gwtyp[i_193] == 1)
                                        {
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString("This is a normal clan game.", 561 - ftm.stringWidth("This is a normal clan game.") / 2, 161);
                                            rd.setFont(new Font("Arial", 0, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString("Any clan can win by racing or wasting.", 561 - ftm.stringWidth("Any clan can win by racing or wasting.") / 2, 176);
                                        }
                                        if(gwtyp[i_193] == 2)
                                        {
                                            if(sflk != 0)
                                            {
                                                sflk--;
                                                rd.setColor(new Color(0, 0, 0));
                                            } else
                                            {
                                                sflk = 3;
                                                rd.setColor(new Color(117, 67, 0));
                                            }
                                            rd.drawString("This is a racing only game!", 561 - ftm.stringWidth("This is a racing only game!") / 2, 161);
                                            rd.setFont(new Font("Arial", 0, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString("A clan can only win by racing.", 561 - ftm.stringWidth("A clan can only win by racing.") / 2, 176);
                                        }
                                        if(gwtyp[i_193] == 3)
                                        {
                                            if(sflk != 0)
                                            {
                                                sflk--;
                                                rd.setColor(new Color(0, 0, 0));
                                            } else
                                            {
                                                sflk = 3;
                                                rd.setColor(new Color(117, 67, 0));
                                            }
                                            rd.drawString("This is a wasting only game!", 561 - ftm.stringWidth("This is a wasting only game!") / 2, 161);
                                            rd.setFont(new Font("Arial", 0, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString("A clan can only win by wasting.", 561 - ftm.stringWidth("A clan can only win by wasting.") / 2, 176);
                                        }
                                        if(gwtyp[i_193] == 4)
                                        {
                                            if(sflk != 0)
                                            {
                                                sflk--;
                                                rd.setColor(new Color(0, 0, 0));
                                            } else
                                            {
                                                sflk = 3;
                                                rd.setColor(new Color(117, 67, 0));
                                            }
                                            rd.drawString("This is Racers VS Wasters game!", 561 - ftm.stringWidth("This is Racers VS Wasters game!") / 2, 161);
                                            rd.drawString((new StringBuilder()).append("").append(gaclan[i_193]).append(" wastes & ").append(gvclan[i_193]).append(" races.").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("").append(gaclan[i_193]).append(" wastes & ").append(gvclan[i_193]).append(" races.").toString()) / 2, 176);
                                        }
                                        if(gwtyp[i_193] == 5)
                                        {
                                            if(sflk != 0)
                                            {
                                                sflk--;
                                                rd.setColor(new Color(0, 0, 0));
                                            } else
                                            {
                                                sflk = 3;
                                                rd.setColor(new Color(117, 67, 0));
                                            }
                                            rd.drawString("This is Racers VS Wasters game!", 561 - ftm.stringWidth("This is Racers VS Wasters game!") / 2, 161);
                                            rd.drawString((new StringBuilder()).append("").append(gaclan[i_193]).append(" races & ").append(gvclan[i_193]).append(" wastes.").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("").append(gaclan[i_193]).append(" races & ").append(gvclan[i_193]).append(" wastes.").toString()) / 2, 176);
                                        }
                                    }
                                } else
                                if(prevloaded == 1)
                                {
                                    int i_248 = (int)(80D + (double)(float)rerr / 1.2430000000000001D);
                                    if(i_248 > 255)
                                        i_248 = 255;
                                    if(i_248 < 0)
                                        i_248 = 0;
                                    int i_249 = (int)(128D + (double)(float)rerr / 2.4279999999999999D);
                                    if(i_249 > 255)
                                        i_249 = 255;
                                    if(i_249 < 0)
                                        i_249 = 0;
                                    int i_250 = rerr;
                                    if(i_250 > 255)
                                        i_250 = 255;
                                    if(i_250 < 0)
                                        i_250 = 0;
                                    if(wait[i_193] == 0)
                                    {
                                        rd.setColor(new Color(i_248, i_249, i_250));
                                        rd.setFont(new Font("Arial", 1, 12));
                                        rd.drawString("Live Info!", 621, 51);
                                        rd.drawString("Live Info!", 451, 51);
                                    }
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Tahoma", 1, 11));
                                    rd.drawString("Player       Position   Laps      Power        Damage", 439, 69);
                                    rd.setColor(color2k(200, 200, 200));
                                    rd.drawLine(489, 61, 489, 162);
                                    rd.drawLine(542, 61, 542, 162);
                                    rd.drawLine(579, 61, 579, 162);
                                    rd.drawLine(641, 61, 641, 162);
                                    rd.drawLine(422, 72, 702, 72);
                                    rd.drawLine(422, 163, 702, 163);
                                    i_220 = 0;
                                    for(int i_251 = 0; i_251 < prnpo; i_251++)
                                    {
                                        for(int i_252 = 0; i_252 < prnpo; i_252++)
                                        {
                                            if(ppos[i_252] != i_251)
                                                continue;
                                            rd.setFont(new Font("Tahoma", 0, 11));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(0, 44, 124));
                                            rd.drawString(prnames[i_252], 455 - ftm.stringWidth(prnames[i_252]) / 2, 83 + 11 * i_220);
                                            if(pdam[i_252] < 55 && pdam[i_252] != -17)
                                            {
                                                rd.setColor(new Color(80, 128, 0));
                                                String string_253 = "th";
                                                if(ppos[i_252] == 0)
                                                    string_253 = "st";
                                                if(ppos[i_252] == 1)
                                                    string_253 = "nd";
                                                if(ppos[i_252] == 2)
                                                    string_253 = "rd";
                                                rd.drawString((new StringBuilder()).append("").append(ppos[i_252] + 1).append("").append(string_253).toString(), 515 - ftm.stringWidth((new StringBuilder()).append("").append(ppos[i_252] + 1).append("").append(string_253).toString()) / 2, 83 + 11 * i_220);
                                                rd.setColor(new Color(128, 73, 0));
                                                if(plap[i_252] > gnlaps[i_193] - 1)
                                                    plap[i_252] = gnlaps[i_193] - 1;
                                                rd.drawString((new StringBuilder()).append("").append(plap[i_252] + 1).append(" / ").append(gnlaps[i_193]).append("").toString(), 560 - ftm.stringWidth((new StringBuilder()).append("").append(plap[i_252] + 1).append(" / ").append(gnlaps[i_193]).append("").toString()) / 2, 83 + 11 * i_220);
                                                rd.setColor(new Color(0, 128, 255));
                                                rd.drawRect(582, 76 + 11 * i_220, 56, 6);
                                                rd.fillRect(583, 79 + 11 * i_220, ppow[i_252], 3);
                                                rd.setColor(new Color(128, 210, 255));
                                                rd.fillRect(583, 77 + 11 * i_220, ppow[i_252], 2);
                                                rd.setColor(new Color(255, 0, 0));
                                                rd.drawRect(645, 76 + 11 * i_220, 56, 6);
                                                rd.fillRect(646, 79 + 11 * i_220, pdam[i_252], 3);
                                                rd.setColor(new Color(255, 155, 64));
                                                rd.fillRect(646, 77 + 11 * i_220, pdam[i_252], 2);
                                            } else
                                            {
                                                i_248 = (int)(85D + (double)(float)(rerr * 2) / 1.5D);
                                                if(i_248 > 255)
                                                    i_248 = 255;
                                                if(i_248 < 0)
                                                    i_248 = 0;
                                                rd.setColor(color2k(i_248, i_248, i_248));
                                                rd.fillRect(490, 75 + 11 * i_220, 213, 9);
                                                rd.setFont(new Font("Tahoma", 1, 11));
                                                ftm = rd.getFontMetrics();
                                                i_248 = 255 - rerr * 2;
                                                if(i_248 > 255)
                                                    i_248 = 255;
                                                if(i_248 < 0)
                                                    i_248 = 0;
                                                i_249 = (int)(155D - (double)(float)(rerr * 2) / 1.645D);
                                                if(i_249 > 255)
                                                    i_249 = 255;
                                                if(i_249 < 0)
                                                    i_249 = 0;
                                                i_250 = (int)(64D - (double)(float)(rerr * 2) / 3.984D);
                                                if(i_250 > 255)
                                                    i_250 = 255;
                                                if(i_250 < 0)
                                                    i_250 = 0;
                                                rd.setColor(new Color(i_248, i_249, i_250));
                                                if(pdam[i_252] != -17)
                                                    rd.drawString("=   =   =   =    W A S T E D    =   =   =   =", 597 - ftm.stringWidth("=   =   =   =    W A S T E D    =   =   =   =") / 2, 84 + 11 * i_220);
                                                else
                                                    rd.drawString("=   =   =   DISCONNECTED   =   =   =", 597 - ftm.stringWidth("=   =   =   DISCONNECTED   =   =   =") / 2, 84 + 11 * i_220);
                                            }
                                            i_220++;
                                        }

                                    }

                                    if(wait[i_193] == 0)
                                    {
                                        stringbutton("    Watch Live Now!    ", 561, 196, 0);
                                    } else
                                    {
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        int i_254 = 186;
                                        if(!lapsname.equals("") && !wastename.equals("") && !stuntname.equals(""))
                                            i_254 = 183;
                                        if(gwarb[i_193] == 0)
                                        {
                                            String string_255 = "";
                                            int i_256 = 0;
                                            do
                                            {
                                                if(i_256 >= prnpo)
                                                    break;
                                                if(ppos[i_256] == 0)
                                                {
                                                    string_255 = prnames[i_256];
                                                    break;
                                                }
                                                i_256++;
                                            } while(true);
                                            if(string_255.equals(""))
                                            {
                                                rd.drawString("Game Finished!    Nobody Won!", 561 - ftm.stringWidth("Game Finished!    Nobody Won!") / 2, i_254);
                                            } else
                                            {
                                                rd.drawString((new StringBuilder()).append("Game Finished!    Winner:  ").append(string_255).append("").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Game Finished!    Winner:  ").append(string_255).append("").toString()) / 2, i_254);
                                                if(nflk == 0)
                                                {
                                                    rd.setColor(new Color(255, 176, 67));
                                                    nflk = 3;
                                                } else
                                                {
                                                    nflk--;
                                                }
                                                rd.drawString((new StringBuilder()).append("").append(string_255).append("").toString(), (561 - ftm.stringWidth((new StringBuilder()).append("Game Finished!    Winner:  ").append(string_255).append("").toString()) / 2) + ftm.stringWidth("Game Finished!    Winner:  "), i_254);
                                            }
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.setFont(new Font("Arial", 0, 11));
                                            ftm = rd.getFontMetrics();
                                            String string_257 = "    ";
                                            int i_258 = 0;
                                            if(!lapsname.equals(""))
                                            {
                                                string_257 = (new StringBuilder()).append(string_257).append("Fastest lap: ").append(lapsname).append("    ").toString();
                                                i_258++;
                                            }
                                            if(!wastename.equals(""))
                                            {
                                                string_257 = (new StringBuilder()).append(string_257).append("Deadliest waster: ").append(wastename).append("    ").toString();
                                                i_258++;
                                            }
                                            if(i_258 == 2)
                                            {
                                                if(!stuntname.equals(""))
                                                {
                                                    rd.drawString(string_257, 561 - ftm.stringWidth(string_257) / 2, 199);
                                                    rd.drawString((new StringBuilder()).append("Best stunt: ").append(stuntname).append("").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Best stunt: ").append(stuntname).append("").toString()) / 2, 213);
                                                } else
                                                {
                                                    rd.drawString(string_257, 561 - ftm.stringWidth(string_257) / 2, 206);
                                                }
                                            } else
                                            {
                                                if(!stuntname.equals(""))
                                                    string_257 = (new StringBuilder()).append(string_257).append("Best stunt: ").append(stuntname).append("    ").toString();
                                                rd.drawString(string_257, 561 - ftm.stringWidth(string_257) / 2, 206);
                                            }
                                        } else
                                        if(string_197.equals(""))
                                        {
                                            if(string.equals(""))
                                            {
                                                rd.drawString("Game Finished!    Nobody Won!", 561 - ftm.stringWidth("Game Finished!    Nobody Won!") / 2, 186);
                                                rd.setFont(new Font("Arial", 1, 11));
                                                ftm = rd.getFontMetrics();
                                                rd.drawString(string_198, 561 - ftm.stringWidth(string_198) / 2, 206);
                                            } else
                                            {
                                                rd.drawString((new StringBuilder()).append("Game Finished!    ").append(string).append("  Wins!").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Game Finished!    ").append(string).append("  Wins!").toString()) / 2, 196);
                                                if(nflk == 0)
                                                {
                                                    rd.setColor(new Color(255, 176, 67));
                                                    nflk = 3;
                                                } else
                                                {
                                                    nflk--;
                                                }
                                                rd.drawString((new StringBuilder()).append("").append(string).append("").toString(), (561 - ftm.stringWidth((new StringBuilder()).append("Game Finished!    ").append(string).append("  Wins!").toString()) / 2) + ftm.stringWidth("Game Finished!    "), 196);
                                            }
                                        } else
                                        {
                                            if(nflk == 0)
                                            {
                                                rd.setColor(new Color(255, 176, 67));
                                                nflk = 3;
                                            } else
                                            {
                                                nflk--;
                                            }
                                            rd.drawString(string_197, 561 - ftm.stringWidth(string_197) / 2, 196);
                                        }
                                    }
                                    rerr += 3;
                                } else
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    if(prevloaded == -1)
                                    {
                                        if(!xt.lan)
                                            rd.drawString("Loading Info...", 561 - ftm.stringWidth("Loading Info...") / 2, 134);
                                        else
                                        if(pgames[im] == ongame)
                                        {
                                            rd.drawString("About to Start...", 561 - ftm.stringWidth("About to Start...") / 2, 134);
                                        } else
                                        {
                                            rd.drawString("Game Started", 561 - ftm.stringWidth("Game Started") / 2, 117);
                                            stringbutton("    Watch this Game    ", 561, 154, 0);
                                        }
                                    } else
                                    {
                                        rd.drawString("About to Start...", 561 - ftm.stringWidth("About to Start...") / 2, 134);
                                    }
                                }
                            } else
                            {
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                if(conon == 2)
                                    rd.drawString("Starting Game Now!", 561 - ftm.stringWidth("Starting Game Now!") / 2, 124);
                                if(conon == 3)
                                    rd.drawString("Opening Game Now!", 561 - ftm.stringWidth("Opening Game Now!") / 2, 124);
                                rd.setFont(new Font("Arial", 0, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString("Please Wait...", 561 - ftm.stringWidth("Please Wait...") / 2, 154);
                            }
                            rd.setColor(color2k(200, 200, 200));
                            rd.drawRect(415, 222, 293, 40);
                            rd.drawImage(xt.stg, 422, 227, null);
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 10));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("Laps: ").append(gnlaps[i_193]).append("").toString(), 660, 235);
                            if(i > 415 && i < 708 && i_99 > 222 && i_99 < 262 && (wait[i_193] > 0 || gstgn[i_193] < 0) && conon == 1)
                            {
                                stringbutton("       Preview Stage       ", 562, 247, 0);
                                pbtn = 2;
                            } else
                            {
                                if(gstgn[i_193] > 0)
                                {
                                    String string_259 = "NFM 1";
                                    int i_260 = gstgn[i_193];
                                    if(gstgn[i_193] > 10)
                                    {
                                        string_259 = "NFM 2";
                                        i_260 = gstgn[i_193] - 10;
                                    }
                                    if(gstgn[i_193] > 27)
                                    {
                                        string_259 = "Multiplayer";
                                        i_260 = gstgn[i_193] - 27;
                                    }
                                    rd.drawString((new StringBuilder()).append("").append(string_259).append(" - Stage ").append(i_260).append("").toString(), 562 - ftm.stringWidth((new StringBuilder()).append("").append(string_259).append(" - Stage ").append(i_260).append("").toString()) / 2, 237);
                                } else
                                {
                                    rd.drawString("Custom Stage", 562 - ftm.stringWidth("Custom Stage") / 2, 237);
                                }
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                rd.drawString(gstages[i_193], 562 - ftm.stringWidth(gstages[i_193]) / 2, 254);
                            }
                            if(!xt.lan)
                            {
                                int i_261 = 237;
                                int i_262 = 471;
                                if(wait[i_193] > 0)
                                {
                                    if(mnpls[i_193] > 5)
                                    {
                                        i_261 = 415;
                                        i_262 = 293;
                                    }
                                } else
                                if(npls[i_193] > 5)
                                {
                                    i_261 = 415;
                                    i_262 = 293;
                                }
                                rd.setColor(color2k(200, 200, 200));
                                rd.drawRect(i_261, 264, i_262, 124);
                                rd.setColor(color2k(240, 240, 240));
                                rd.fillRect(i_261 + 1, 265, i_262 - 1, 21);
                                rd.drawImage(xt.gmc, i_261 + 7, 269, null);
                                rd.setFont(new Font("Tahoma", 0, 11));
                                rd.setColor(color2k(110, 110, 110));
                                rd.drawString("( Game Chat )", i_261 + 57, 278);
                                rd.setColor(new Color(0, 0, 0));
                                if(updatec != -1)
                                {
                                    String strings[] = new String[7];
                                    String strings_263[] = new String[7];
                                    boolean bools[] = {
                                        false, false, false, false, false, false, false
                                    };
                                    for(int i_264 = 0; i_264 < 7; i_264++)
                                    {
                                        strings[i_264] = "";
                                        strings_263[i_264] = cnames[i_264];
                                        int i_265 = 0;
                                        int i_266 = 0;
                                        int i_267 = 0;
                                        int i_268 = 0;
                                        int i_269 = 0;
                                        for(; i_265 < sentn[i_264].length(); i_265++)
                                        {
                                            String string_270 = (new StringBuilder()).append("").append(sentn[i_264].charAt(i_265)).toString();
                                            if(string_270.equals(" "))
                                            {
                                                i_266 = i_267;
                                                i_268 = i_265;
                                                i_269++;
                                            } else
                                            {
                                                i_269 = 0;
                                            }
                                            if(i_269 > 1)
                                                continue;
                                            StringBuilder stringbuilder = new StringBuilder();
                                            String strings_271[] = strings;
                                            int i_272 = i_264;
                                            strings_271[i_272] = stringbuilder.append(strings_271[i_272]).append(string_270).toString();
                                            i_267++;
                                            if(ftm.stringWidth(strings[i_264]) <= i_262 - 94)
                                                continue;
                                            if(i_266 != 0)
                                            {
                                                strings[i_264] = strings[i_264].substring(0, i_266);
                                                for(int i_273 = 0; i_273 < i_264; i_273++)
                                                {
                                                    strings[i_273] = strings[i_273 + 1];
                                                    strings_263[i_273] = strings_263[i_273 + 1];
                                                    bools[i_273] = bools[i_273 + 1];
                                                }

                                                strings[i_264] = "";
                                                bools[i_264] = true;
                                                i_265 = i_268;
                                                i_267 = 0;
                                                i_266 = 0;
                                            } else
                                            {
                                                strings[i_264] = "";
                                                i_267 = 0;
                                            }
                                        }

                                    }

                                    String string_274 = "";
                                    rd.setFont(new Font("Tahoma", 1, 11));
                                    ftm = rd.getFontMetrics();
                                    for(int i_275 = 0; i_275 < 7; i_275++)
                                        if(!string_274.equals(strings_263[i_275]))
                                        {
                                            rd.drawString((new StringBuilder()).append(strings_263[i_275]).append(":").toString(), (i_261 + 84) - ftm.stringWidth((new StringBuilder()).append(strings_263[i_275]).append(":").toString()), 299 + i_275 * 14);
                                            string_274 = strings_263[i_275];
                                        }

                                    rd.setFont(new Font("Tahoma", 0, 11));
                                    for(int i_276 = 0; i_276 < 7; i_276++)
                                    {
                                        if(bools[i_276] && i_276 == 0 && strings[i_276].indexOf(" ") != -1)
                                            strings[i_276] = (new StringBuilder()).append("...").append(strings[i_276].substring(strings[i_276].indexOf(" "), strings[i_276].length())).append("").toString();
                                        if(Madness.isURL(strings[i_276]))
                                        {
                                            Color tmp = rd.getColor();
                                            rd.setColor(color2k(80, 80, 80));
                                            rd.drawString(strings[i_276], i_261 + 88, 299 + i_276 * 14);
                                            rd.drawLine(i_261 + 87, 301 + i_276 * 14, i_261 + 88 + rd.getFontMetrics().stringWidth(strings[i_276]), 301 + i_276 * 14);
                                            gs.customlink(strings[i_276], i_261 + 88, 299 + i_276 * 14, rd.getFontMetrics().stringWidth(strings[i_276]));
                                            rd.setColor(tmp);
                                        } else
                                        {
                                            rd.drawString(strings[i_276], i_261 + 88, 299 + i_276 * 14);
                                        }
                                    }

                                } else
                                {
                                    rd.drawString("Loading chat...", (i_261 + i_262 / 2) - ftm.stringWidth("Loading chat...") / 2, 315);
                                }
                                if(conon == 1)
                                    pre2 = true;
                                else
                                    hideinputs();
                                if(control.enter && !gs.cmsg.getText().equals("Type here...") && !gs.cmsg.getText().equals(""))
                                {
                                    pessd[btn] = true;
                                    control.enter = false;
                                    String string_277 = xt.passRem(gs.cmsg.getText().replace('|', ':'));
                                    if(!xt.msgcheck(string_277) && updatec > -12)
                                    {
                                        for(int i_278 = 0; i_278 < 6; i_278++)
                                        {
                                            sentn[i_278] = sentn[i_278 + 1];
                                            cnames[i_278] = cnames[i_278 + 1];
                                        }

                                        sentn[6] = string_277;
                                        cnames[6] = pnames[im];
                                        if(updatec > -11)
                                            updatec = -11;
                                        else
                                            updatec--;
                                    } else
                                    {
                                        xt.warning++;
                                    }
                                    gs.cmsg.setText("");
                                }
                                stringbutton("Send Message", 655, 405, 3);
                            }
                        } else
                        {
                            if(gs.cmsg.isShowing())
                                gs.cmsg.hide();
                            if(pcars[dispcar] == forcar && forcar != -1)
                            {
                                rd.drawImage(xt.crd, 517, 81, null);
                                rd.setColor(new Color(16, 198, 255));
                                rd.drawRect(415, 96, 293, 315);
                                rd.setColor(color2k(240, 240, 240));
                                rd.fillRect(416, 97, 4, 314);
                                rd.fillRect(704, 97, 4, 314);
                                rd.fillRect(416, 97, 292, 4);
                                rd.fillRect(416, 407, 292, 4);
                                if(flks >= 0)
                                {
                                    rd.setColor(new Color(239, 234, 177));
                                    flks++;
                                    if(flks > 3)
                                        flks = -1;
                                } else
                                {
                                    rd.setColor(new Color(224, 226, 176));
                                    flks--;
                                    if(flks < -4)
                                        flks = 0;
                                }
                                rd.fillRect(445, 120, 233, 127);
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.drawString(cd.names[forcar], 561 - ftm.stringWidth(cd.names[forcar]) / 2, 117);
                                for(int i_279 = 0; i_279 < dispco.npl; i_279++)
                                {
                                    if(contos[forcar].p[i_279].colnum == 1)
                                    {
                                        dispco.p[i_279].hsb[0] = pcols[dispcar][0];
                                        dispco.p[i_279].hsb[1] = pcols[dispcar][1];
                                        dispco.p[i_279].hsb[2] = 1.0F - pcols[dispcar][2];
                                    }
                                    if(contos[forcar].p[i_279].colnum == 2)
                                    {
                                        dispco.p[i_279].hsb[0] = pcols[dispcar][3];
                                        dispco.p[i_279].hsb[1] = pcols[dispcar][4];
                                        dispco.p[i_279].hsb[2] = 1.0F - pcols[dispcar][5];
                                    }
                                }

                                m.cx = 561;
                                dispco.z = 1200;
                                dispco.y = 605 - dispco.grat;
                                dispco.x = 225;
                                dispco.zy = 0;
                                dispco.xz = mrot;
                                mrot -= 5;
                                if(mrot < -360)
                                    mrot += 360;
                                dispco.xy = 0;
                                dispco.wzy -= 10;
                                if(dispco.wzy < -45)
                                    dispco.wzy += 45;
                                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                                dispco.d(rd);
                                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                                m.cx = 400;
                                rd.setFont(new Font("Arial", 1, 11));
                                int i_280 = 424;
                                int i_281 = -55;
                                rd.setColor(new Color(0, 63, 128));
                                rd.drawString("Top Speed:", 30 + i_280, 318 + i_281);
                                rd.drawImage(xt.statb, 97 + i_280, 312 + i_281, null);
                                rd.drawString("Acceleration:", 20 + i_280, 333 + i_281);
                                rd.drawImage(xt.statb, 97 + i_280, 327 + i_281, null);
                                rd.setColor(color2k(255, 255, 255));
                                float f = (float)(cd.swits[forcar][2] - 220) / 90F;
                                if((double)f < 0.20000000000000001D)
                                    f = 0.2F;
                                rd.fillRect((int)(97F + 156F * f) + i_280, 312 + i_281, (int)(156F * (1.0F - f) + 1.0F), 7);
                                f = (cd.acelf[forcar][1] * cd.acelf[forcar][0] * cd.acelf[forcar][2] * cd.grip[forcar]) / 7700F;
                                if(f > 1.0F)
                                    f = 1.0F;
                                rd.fillRect((int)(97F + 156F * f) + i_280, 327 + i_281, (int)(156F * (1.0F - f) + 1.0F), 7);
                                rd.drawImage(xt.statbo, 97 + i_280, 312 + i_281, null);
                                rd.drawImage(xt.statbo, 97 + i_280, 327 + i_281, null);
                                i_280 = 50;
                                i_281 = -25;
                                rd.setColor(new Color(0, 63, 128));
                                rd.drawString("Stunts:", 427 + i_280, 318 + i_281);
                                rd.drawImage(xt.statb, 471 + i_280, 312 + i_281, null);
                                rd.drawString("Strength:", 415 + i_280, 333 + i_281);
                                rd.drawImage(xt.statb, 471 + i_280, 327 + i_281, null);
                                rd.drawString("Endurance:", 405 + i_280, 348 + i_281);
                                rd.drawImage(xt.statb, 471 + i_280, 342 + i_281, null);
                                rd.setColor(color2k(255, 255, 255));
                                f = ((float)cd.airc[forcar] * cd.airs[forcar] * cd.bounce[forcar] + 28F) / 139F;
                                if(f > 1.0F)
                                    f = 1.0F;
                                rd.fillRect((int)(471F + 156F * f) + i_280, 312 + i_281, (int)(156F * (1.0F - f) + 1.0F), 7);
                                float f_282 = 0.5F;
                                f = (cd.moment[forcar] + f_282) / 2.6F;
                                if(f > 1.0F)
                                    f = 1.0F;
                                rd.fillRect((int)(471F + 156F * f) + i_280, 327 + i_281, (int)(156F * (1.0F - f) + 1.0F), 7);
                                f = cd.outdam[forcar];
                                rd.fillRect((int)(471F + 156F * f) + i_280, 342 + i_281, (int)(156F * (1.0F - f) + 1.0F), 7);
                                rd.drawImage(xt.statbo, 471 + i_280, 312 + i_281, null);
                                rd.drawImage(xt.statbo, 471 + i_280, 327 + i_281, null);
                                rd.drawImage(xt.statbo, 471 + i_280, 342 + i_281, null);
                                rd.setColor(new Color(0, 0, 0));
                                if(forcar < 16)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("Created by Radicalplay.com", 561 - ftm.stringWidth("Created by Radicalplay.com") / 2, 347);
                                    String string_283 = "Game Car";
                                    if(cd.cclass[forcar] == 0)
                                        string_283 = "Class C ,  Game Car";
                                    if(cd.cclass[forcar] == 1)
                                        string_283 = "Class B & C ,  Game Car";
                                    if(cd.cclass[forcar] == 2)
                                        string_283 = "Class B ,  Game Car";
                                    if(cd.cclass[forcar] == 3)
                                        string_283 = "Class A & B ,  Game Car";
                                    if(cd.cclass[forcar] == 4)
                                        string_283 = "Class A ,  Game Car";
                                    rd.drawString(string_283, 561 - ftm.stringWidth(string_283) / 2, 367);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 0, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString("You already have this car.", 561 - ftm.stringWidth("You already have this car.") / 2, 395);
                                } else
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    if(!cd.createdby[forcar - 16].equals(xt.nickname))
                                    {
                                        rd.drawString((new StringBuilder()).append("Created by :  ").append(cd.createdby[forcar - 16]).append("").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("Created by :  ").append(cd.createdby[forcar - 16]).append("").toString()) / 2, 347);
                                        int i_284 = ftm.stringWidth(cd.createdby[forcar - 16]);
                                        int i_285 = ((561 - ftm.stringWidth((new StringBuilder()).append("Created by :  ").append(cd.createdby[forcar - 16]).append("").toString()) / 2) + ftm.stringWidth((new StringBuilder()).append("Created by :  ").append(cd.createdby[forcar - 16]).append("").toString())) - i_284;
                                        rd.drawLine(i_285, 349, (i_285 + i_284) - 2, 349);
                                        if(i > i_285 - 2 && i < i_285 + i_284 && i_99 > 334 && i_99 < 351)
                                        {
                                            if(bool)
                                            {
                                                if(!gb.proname.equals(cd.createdby[forcar - 16]))
                                                {
                                                    gb.proname = cd.createdby[forcar - 16];
                                                    gb.loadedp = false;
                                                }
                                                gb.tab = 1;
                                                gb.open = 2;
                                                gb.upo = true;
                                            }
                                            i_101 = 12;
                                        }
                                    } else
                                    {
                                        rd.drawString("Created by You", 561 - ftm.stringWidth("Created by You") / 2, 347);
                                    }
                                    rd.setColor(new Color(128, 73, 0));
                                    String string_286 = "";
                                    if(cd.cclass[forcar] == 0)
                                        string_286 = "Class C ,  ";
                                    if(cd.cclass[forcar] == 1)
                                        string_286 = "Class B & C ,  ";
                                    if(cd.cclass[forcar] == 2)
                                        string_286 = "Class B ,  ";
                                    if(cd.cclass[forcar] == 3)
                                        string_286 = "Class A & B ,  ";
                                    if(cd.cclass[forcar] == 4)
                                        string_286 = "Class A ,  ";
                                    if(cd.publish[forcar - 16] == 0)
                                        string_286 = (new StringBuilder()).append(string_286).append("Private Car").toString();
                                    if(cd.publish[forcar - 16] == 1)
                                    {
                                        string_286 = (new StringBuilder()).append(string_286).append("Public Car").toString();
                                        rd.setColor(new Color(0, 64, 128));
                                    }
                                    if(cd.publish[forcar - 16] == 2)
                                    {
                                        string_286 = (new StringBuilder()).append(string_286).append("Super Public Car").toString();
                                        rd.setColor(new Color(0, 64, 128));
                                    }
                                    rd.drawString(string_286, 561 - ftm.stringWidth(string_286) / 2, 367);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Arial", 0, 12));
                                    ftm = rd.getFontMetrics();
                                    if(cd.publish[forcar - 16] == 1 || cd.publish[forcar - 16] == 2)
                                    {
                                        if(cd.action == -9)
                                            rd.drawString("Failed to add car!  Unknown error!", 561 - ftm.stringWidth("Failed to add car!  Unknown error!") / 2, 395);
                                        if(cd.action == -8)
                                            rd.drawString("Failed!  You already have 20 cars!", 561 - ftm.stringWidth("Failed!  You already have 20 cars!") / 2, 395);
                                        if(cd.action == 7)
                                            rd.drawString((new StringBuilder()).append("").append(cd.names[cd.ac]).append(" has been added to your cars!").toString(), 561 - ftm.stringWidth((new StringBuilder()).append("").append(cd.names[cd.ac]).append(" has been added to your cars!").toString()) / 2, 395);
                                        if(cd.action == -7)
                                            rd.drawString("You already have this car.", 561 - ftm.stringWidth("You already have this car.") / 2, 395);
                                        if(cd.action == 6)
                                            rd.drawString("Adding Car...", 561 - ftm.stringWidth("Adding Car...") / 2, 395);
                                        if(cd.action == -6)
                                        {
                                            String string_287 = "Upgrade to a full account to add custom cars!";
                                            int i_288 = 561 - ftm.stringWidth(string_287) / 2;
                                            int i_289 = i_288 + ftm.stringWidth(string_287);
                                            rd.drawString(string_287, i_288, 395);
                                            if(waitlink != -1)
                                                rd.drawLine(i_288, 396, i_289, 396);
                                            if(i > i_288 && i < i_289 && i_99 > 384 && i_99 < 397)
                                            {
                                                if(waitlink != -1)
                                                    i_101 = 12;
                                                if(bool && waitlink == 0)
                                                {
                                                    gs.editlink(xt.nickname, true);
                                                    waitlink = -1;
                                                }
                                            }
                                            if(waitlink > 0)
                                                waitlink--;
                                        }
                                        if(cd.action == 0 && xt.drawcarb(true, null, " Add to My Cars ", 503, 375, i, i_99, bool))
                                            if(xt.logged)
                                            {
                                                if(cd.lastload != 2 || forcar >= 36)
                                                {
                                                    cd.action = 6;
                                                    cd.ac = forcar;
                                                    cd.sparkactionloader();
                                                } else
                                                {
                                                    cd.action = -7;
                                                }
                                            } else
                                            {
                                                cd.action = -6;
                                                waitlink = 20;
                                            }
                                    } else
                                    {
                                        rd.drawString("Private Car.  Cannot be added to account.", 561 - ftm.stringWidth("Private Car.  Cannot be added to account.") / 2, 395);
                                    }
                                }
                                if(xt.drawcarb(true, null, "X", 682, 99, i, i_99, bool))
                                    dispcar = -1;
                            } else
                            {
                                dispcar = -1;
                            }
                        }
                    }
                }
            } else
            {
                if(!jflexo)
                {
                    xt.jflexo();
                    jflexo = true;
                }
                btn = 0;
                if(gs.cmsg.isShowing())
                {
                    gs.cmsg.hide();
                    gs.requestFocus();
                }
                rd.setColor(color2k(255, 255, 255));
                rd.fillRoundRect(155, 148, 490, 127, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(155, 148, 490, 127, 20, 20);
                if(ontyp != 76)
                {
                    String string = "";
                    int i_290 = 0;
                    if(ontyp >= 10)
                    {
                        i_290 = 10;
                        string = "Custom Cars";
                        if(ontyp > 10)
                            string = (new StringBuilder()).append(string).append(", ").toString();
                    }
                    if(ontyp >= 20)
                    {
                        i_290 = 20;
                        string = "Game Cars";
                        if(ontyp > 20)
                            string = (new StringBuilder()).append(string).append(", ").toString();
                    }
                    if(ontyp >= 30)
                    {
                        i_290 = 30;
                        string = "Clan Cars";
                        if(ontyp > 30)
                            string = (new StringBuilder()).append(string).append(", ").toString();
                    }
                    if(ontyp - i_290 == 1)
                        string = (new StringBuilder()).append(string).append("Class C").toString();
                    if(ontyp - i_290 == 2)
                        string = (new StringBuilder()).append(string).append("Class B & C").toString();
                    if(ontyp - i_290 == 3)
                        string = (new StringBuilder()).append(string).append("Class B").toString();
                    if(ontyp - i_290 == 4)
                        string = (new StringBuilder()).append(string).append("Class A & B").toString();
                    if(ontyp - i_290 == 5)
                        string = (new StringBuilder()).append(string).append("Class A").toString();
                    if(ontyp <= -2)
                        if(Math.abs(ontyp + 2) == 13)
                            string = (new StringBuilder()).append(" ").append(cd.names[Math.abs(ontyp + 2)]).append("  Game").toString();
                        else
                            string = (new StringBuilder()).append("").append(cd.names[Math.abs(ontyp + 2)]).append(" Game").toString();
                    rd.setColor(new Color(0, 0, 0));
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString((new StringBuilder()).append(": :   ").append(string).append("   : :").toString(), 400 - ftm.stringWidth((new StringBuilder()).append(": :   ").append(string).append("   : :").toString()) / 2, 175);
                    string = "a";
                    if(ontyp - i_290 == 1)
                        string = "a class C";
                    if(ontyp - i_290 == 2)
                        string = "a class B or C";
                    if(ontyp - i_290 == 3)
                        string = "a class B";
                    if(ontyp - i_290 == 4)
                        string = "a class A or B";
                    if(ontyp - i_290 == 5)
                        string = "a class A";
                    if(i_290 == 0)
                        string = (new StringBuilder()).append(string).append(" car").toString();
                    if(i_290 == 10)
                        string = (new StringBuilder()).append(string).append(" custom car").toString();
                    if(i_290 == 20)
                        string = (new StringBuilder()).append(string).append(" game car").toString();
                    if(i_290 == 30)
                        string = (new StringBuilder()).append(string).append(" clan car").toString();
                    if(ontyp <= -2)
                        if(Math.abs(ontyp + 2) == 13)
                            string = (new StringBuilder()).append(" ").append(cd.names[Math.abs(ontyp + 2)]).append(" ").toString();
                        else
                            string = (new StringBuilder()).append("").append(cd.names[Math.abs(ontyp + 2)]).append("").toString();
                    rd.drawString((new StringBuilder()).append("To join this game you need to have ").append(string).append("!").toString(), 400 - ftm.stringWidth((new StringBuilder()).append("To join this game you need to have ").append(string).append("!").toString()) / 2, 206);
                    stringbutton((new StringBuilder()).append("  Get ").append(string).append(" now  ").toString(), 400, 247, 0);
                    stringbutton("  Cancel X  ", 593, 259, 2);
                    if(gb.open > 0 && gb.upo)
                        onjoin = -1;
                } else
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString(": :   Custom Stage   : :", 400 - ftm.stringWidth(": :   Custom Stage   : :") / 2, 175);
                    rd.drawString("You need to upgrade to a full account to join this game!", 400 - ftm.stringWidth("You need to upgrade to a full account to join this game!") / 2, 202);
                    rd.setColor(color2k(200, 200, 200));
                    rd.fillRoundRect(310, 215, 180, 50, 20, 20);
                    drawSbutton(xt.upgrade, 400, 240);
                    stringbutton("  Cancel X  ", 593, 259, 2);
                }
            }
        } else
        {
            xt.mainbg(3);
            btn = 0;
            if(gs.cmsg.isShowing())
            {
                gs.cmsg.hide();
                gs.requestFocus();
            }
            float f = 1.0F - (float)(lg.flipo - 10) / 80F;
            if(f > 1.0F)
                f = 1.0F;
            if(f < 0.0F)
                f = 0.0F;
            rd.setComposite(AlphaComposite.getInstance(3, f));
            if(lg.flipo > 10)
            {
                rd.drawImage(xt.logomadbg, 65 + (int)(2D - Math.random() * 4D), 31 + (int)(2D - Math.random() * 4D), null);
                rd.drawImage(xt.logomadnes, 97 + (int)(2D - Math.random() * 4D), 36 + (int)(2D - Math.random() * 4D), null);
            } else
            {
                rd.drawImage(xt.logomadbg, 65, 31, null);
                rd.drawImage(xt.logomadnes, 97, 36, null);
            }
            lg.flipo++;
            if(lg.flipo > 50)
                lg.flipo = 0;
            int i_291 = 30;
            rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
            rd.setColor(new Color(203, 227, 253));
            rd.fillRoundRect(115, 77 + i_291, 570, 287, 20, 20);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.setColor(color2k(90, 90, 90));
            rd.drawRoundRect(115, 77 + i_291, 570, 287, 20, 20);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            rd.setColor(color2k(0, 0, 0));
            rd.drawString("You are allowed 1 multiplayer turn per day to try the game with your trial account.", 135, 105 + i_291);
            rd.drawString("Upgrade your account to a full account to purchase and play the multiplayer game.", 135, 125 + i_291);
            drawSbutton(xt.upgrade, 400, 150 + i_291);
            rd.setColor(new Color(30, 70, 110));
            rd.drawString("You can upgrade your account by just sharing the game & posting about it online!", 135, 185 + i_291);
            rd.drawString("Click 'Upgrade' for more details.", 135, 205 + i_291);
            rd.setColor(color2k(0, 0, 0));
            rd.drawString("For now to preview and try the multiplayer more, with your trial account you can:", 135, 245 + i_291);
            rd.setColor(new Color(30, 70, 110));
            rd.drawString("-  Watch online multiplayer games.", 135, 265 + i_291);
            rd.drawString("-  Access the multiplayer dome.", 135, 285 + i_291);
            rd.drawString("-  Play LAN multiplayer games (unlimitedly).", 135, 305 + i_291);
            drawSbutton(xt.exit, 400, 336 + i_291);
        }
        if(xt.warning != 0)
        {
            xt.drawWarning();
            if(gs.cmsg.isShowing())
            {
                gs.cmsg.hide();
                gs.requestFocus();
            }
            xt.warning++;
        }
        if(i_101 != pcurs)
        {
            gs.setCursor(new Cursor(i_101));
            pcurs = i_101;
        }
    }

    public void preforma(int i, int i_292)
    {
        if(pre1)
        {
            boolean bool = false;
            if(!gs.openm && gb.open == 0)
            {
                if(conon != 0 && xt.warning == 0)
                    bool = true;
            } else
            if(gs.cmsg.isShowing())
                gs.cmsg.hide();
            gs.movefieldd(gs.cmsg, 235, 390, 360, 22, bool);
            if(gs.cmsg.getText().equals("Type here...") && i > 234 && i < 603 && i_292 > 385 && i_292 < 417)
                gs.cmsg.setText("");
        }
        if(pre2)
        {
            boolean bool = false;
            if(!gs.openm && gb.open == 0)
                if(xt.warning == 0)
                    bool = true;
                else
                if(gs.cmsg.isShowing())
                    gs.cmsg.hide();
            gs.movefieldd(gs.cmsg, 237, 390, 360, 22, bool);
            if(gs.cmsg.getText().equals("Type here...") && i > 232 && i < 601 && i_292 > 385 && i_292 < 417)
                gs.cmsg.setText("");
        }
        if(pre1 || pre2)
        {
            if(gs.cmsg.getText().length() > 100)
            {
                gs.cmsg.setText(gs.cmsg.getText().substring(0, 100));
                gs.cmsg.select(100, 100);
            }
            pre1 = false;
            pre2 = false;
        }
    }

    public void stageselect(CheckPoints checkpoints, Control control, int i, int i_293, boolean bool)
    {
        btn = 0;
        int i_294 = 0;
        rd.drawImage(xt.br, 65, 25, null);
        if(britchl == -1)
        {
            ongame = -1;
            britchl = 0;
        }
        int i_295 = 0;
        for(int i_296 = 0; i_296 < ngm; i_296++)
            if(ongame == gnum[i_296])
                i_295 = i_296;

        String string;
        if(chalngd != -2 && ongame != -1)
        {
            rd.setColor(color2k(20, 20, 20));
            rd.fillRect(80, 25, 640, 40);
            rd.setColor(color2k(70, 70, 70));
            rd.drawLine(80, 65, 720, 65);
            rd.drawLine(80, 65, 80, 25);
            rd.drawLine(720, 65, 720, 25);
            rd.setColor(color2k(210, 210, 210));
            rd.setFont(new Font("Arial", 1, 12));
            ftm = rd.getFontMetrics();
            if(wait[i_295] > 0)
            {
                if(gwarb[i_295] == 0)
                {
                    if(wait[i_295] > 30 || npls[i_295] <= 1)
                    {
                        string = "";
                        if(npls[i_295] > 1)
                        {
                            Date date = new Date();
                            long l = date.getTime();
                            if(ptime == 0L || l > ptime + 1500L)
                            {
                                if(ptime != 0L)
                                {
                                    wait[i_295]--;
                                    if(wait[i_295] < 1)
                                        wait[i_295] = 1;
                                }
                                ptime = l;
                            }
                            string = (new StringBuilder()).append(" (waiting ").append(wait[i_295]).append(" seconds maximum)").toString();
                            if(wait[i_295] > 60)
                                string = (new StringBuilder()).append(" (waiting ").append((float)(int)(((float)wait[i_295] / 60F) * 100F) / 100F).append(" minutes maximum)").toString();
                        }
                        rd.drawString((new StringBuilder()).append("Waiting for ").append(mnpls[i_295] - npls[i_295]).append(" more players to join to start this game").append(string).append("!").toString(), 95, 40);
                        rd.setFont(new Font("Arial", 0, 12));
                        if(!gmaker[i_295].equals("Coach Insano") && !gmaker[i_295].equals(pnames[im]))
                        {
                            boolean bool_297 = false;
                            for(int i_298 = 0; i_298 < npo; i_298++)
                                if(pgames[i_298] == ongame && gmaker[i_295].equals(pnames[i_298]))
                                    bool_297 = true;

                            if(bool_297)
                                rd.drawString((new StringBuilder()).append("").append(gmaker[i_295]).append(" can start this game at anytime (the game creator)...").toString(), 95, 56);
                        }
                    } else
                    {
                        Date date = new Date();
                        long l = date.getTime();
                        if(ptime == 0L || l > ptime + 1500L)
                        {
                            if(ptime != 0L)
                            {
                                wait[i_295]--;
                                if(wait[i_295] < 1)
                                    wait[i_295] = 1;
                            }
                            ptime = l;
                        }
                        if(pgames[im] == ongame || nflk != 0)
                        {
                            rd.drawString((new StringBuilder()).append("Game starts in ").append(wait[i_295]).append(" seconds!").toString(), 400 - ftm.stringWidth((new StringBuilder()).append("Game starts in ").append(wait[i_295]).append(" seconds!").toString()) / 2, 48);
                            if(pgames[im] != ongame)
                                nflk--;
                        } else
                        if(pgames[im] != ongame)
                            nflk = 3;
                    }
                } else
                {
                    rd.drawString((new StringBuilder()).append("Waiting for ").append(mnpls[i_295] - npls[i_295]).append(" clan members to join to start this game!").toString(), 95, 48);
                }
                if(pgames[im] != ongame)
                {
                    boolean bool_299 = false;
                    if(gwarb[i_295] == 0)
                    {
                        if(gplyrs[i_295].equals("") || gplyrs[i_295].indexOf(pnames[im]) != -1)
                            bool_299 = true;
                    } else
                    if(xt.clan.toLowerCase().equals(gaclan[i_295].toLowerCase()) || xt.clan.toLowerCase().equals(gvclan[i_295].toLowerCase()))
                        bool_299 = true;
                    if(bool_299)
                        stringbutton(" Join Game ", 660, 48, 2);
                }
            } else
            {
                rd.setColor(color2k(120, 120, 120));
                if(wait[i_295] == 0)
                    rd.drawString("Game Started", 400 - ftm.stringWidth("Game Started") / 2, 45);
                else
                    rd.drawString("Game Finished", 400 - ftm.stringWidth("Game Finished") / 2, 45);
            }
        }
        rd.setFont(new Font("Arial", 1, 11));
        xt.ftm = rd.getFontMetrics();
        bool_299 = "";
        if(checkpoints.stage < 0)
            bool_299 = "Custom Stage";
        if(checkpoints.stage > 0 && checkpoints.stage <= 10)
            bool_299 = (new StringBuilder()).append("Stage ").append(checkpoints.stage).append(" NFM 1").toString();
        if(checkpoints.stage > 10 && checkpoints.stage <= 27)
            bool_299 = (new StringBuilder()).append("Stage ").append(checkpoints.stage - 10).append(" NFM 2").toString();
        if(checkpoints.stage > 27)
            bool_299 = (new StringBuilder()).append("Multiplayer Stage ").append(checkpoints.stage - 27).append("").toString();
        xt.drawcs(85, (new StringBuilder()).append("Previewing ").append(bool_299).append("  >").toString(), 255, 138, 0, 3);
        xt.drawcs(105, (new StringBuilder()).append("| ").append(checkpoints.name).append(" |").toString(), 255, 176, 85, 3);
        rd.drawImage(xt.back[pback], 532, 285, null);
        if(checkpoints.stage < 0)
        {
            rd.setColor(new Color(255, 138, 0));
            rd.drawString((new StringBuilder()).append("Created by: ").append(checkpoints.maker).append("").toString(), 85, 388);
            if(checkpoints.pubt > 0)
            {
                if(checkpoints.pubt == 2)
                    xt.drawcs(388, "Super Public Stage", 41, 177, 255, 3);
                else
                    xt.drawcs(388, "Public Stage", 41, 177, 255, 3);
                if(addstage == 0 && xt.drawcarb(true, null, " Add to My Stages ", 334, 395, i, i_293, bool))
                    if(xt.logged)
                    {
                        cd.onstage = checkpoints.name;
                        cd.staction = 2;
                        cd.sparkstageaction();
                        addstage = 2;
                    } else
                    {
                        addstage = 1;
                        waitlink = 20;
                    }
                if(addstage == 1)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(193, 106, 0));
                    String string_300 = "Upgrade to a full account to add custom stages!";
                    int i_301 = 400 - ftm.stringWidth(string_300) / 2;
                    int i_302 = i_301 + ftm.stringWidth(string_300);
                    rd.drawString(string_300, i_301, 410);
                    if(waitlink != -1)
                        rd.drawLine(i_301, 412, i_302, 412);
                    if(i > i_301 && i < i_302 && i_293 > 399 && i_293 < 412)
                    {
                        if(waitlink != -1)
                            i_294 = 12;
                        if(bool && waitlink == 0)
                        {
                            gs.editlink(xt.nickname, true);
                            waitlink = -1;
                        }
                    }
                    if(waitlink > 0)
                        waitlink--;
                }
                if(addstage == 2)
                {
                    xt.drawcs(410, "Adding stage please wait...", 193, 106, 0, 3);
                    if(cd.staction == 0)
                        addstage = 3;
                    if(cd.staction == -2)
                        addstage = 4;
                    if(cd.staction == -3)
                        addstage = 5;
                    if(cd.staction == -1)
                        addstage = 6;
                }
                if(addstage == 3)
                    xt.drawcs(410, "Stage has been successfully added to your stages!", 193, 106, 0, 3);
                if(addstage == 4)
                    xt.drawcs(410, "You already have this stage!", 193, 106, 0, 3);
                if(addstage == 5)
                    xt.drawcs(410, "Cannot add more then 20 stages to your account!", 193, 106, 0, 3);
                if(addstage == 6)
                    xt.drawcs(410, "Failed to add stage, unknown error, please try again later.", 193, 106, 0, 3);
            } else
            {
                xt.drawcs(410, "Private Stage", 193, 106, 0, 3);
            }
        }
        if(control.enter || conon == 2 || ongame == -1 && chalngd != -2)
        {
            m.trk = 0;
            m.focus_point = 400;
            m.crs = true;
            m.x = -335;
            m.y = 0;
            m.z = -50;
            m.xz = 0;
            m.zy = 20;
            m.ground = -2000;
            fase = 1;
            control.enter = false;
        }
        if(i_294 != pcurs)
        {
            gs.setCursor(new Cursor(i_294));
            pcurs = i_294;
        }
        if(gs.cmsg.isShowing())
            gs.cmsg.setVisible(false);
    }

    public void ctachm(int i, int i_303, int i_304, Control control)
    {
        int i_305 = -1;
        if(fase == 1 || fase == 4)
        {
            for(int i_306 = 0; i_306 < btn; i_306++)
            {
                if(Math.abs(i - bx[i_306]) < bw[i_306] / 2 + 12 && Math.abs(i_303 - by[i_306]) < 14 && (i_304 == 1 || i_304 == 11))
                    pessd[i_306] = true;
                else
                    pessd[i_306] = false;
                if(Math.abs(i - bx[i_306]) < bw[i_306] / 2 + 12 && Math.abs(i_303 - by[i_306]) < 14 && i_304 <= -1)
                {
                    i_305 = i_306;
                    gs.mouses = 0;
                }
            }

        }
        if(conon == 1)
            if(!regnow)
            {
                if(onjoin == -1)
                {
                    if(fase == 4)
                    {
                        if(i > 532 && i < 592 && i_303 > 285 && i_303 < 306 && (i_304 == 1 || i_304 == 11))
                            pback = 1;
                        else
                            pback = 0;
                        if(i > 532 && i < 592 && i_303 > 285 && i_303 < 306 && i_304 <= -1)
                        {
                            gs.mouses = 0;
                            m.trk = 0;
                            m.focus_point = 400;
                            m.crs = true;
                            m.x = -335;
                            m.y = 0;
                            m.z = -50;
                            m.xz = 0;
                            m.zy = 20;
                            m.ground = -2000;
                            fase = 1;
                        }
                        if(i_305 == 0 && chalngd == -1)
                        {
                            i_305 = -1;
                            join = ongame;
                            msg = "| Joining Game |";
                            spos = 0;
                            m.trk = 0;
                            m.focus_point = 400;
                            m.crs = true;
                            m.x = -335;
                            m.y = 0;
                            m.z = -50;
                            m.xz = 0;
                            m.zy = 20;
                            m.ground = -2000;
                            fase = 1;
                        }
                    }
                    if(fase == 1)
                        if(ongame == -1)
                        {
                            if(i_305 == 0)
                                if(chalngd == -1)
                                {
                                    if(xt.lan && !lanlogged)
                                    {
                                        gs.reglink();
                                    } else
                                    {
                                        boolean bool = false;
                                        int i_307 = 0;
                                        do
                                        {
                                            if(i_307 >= ngm)
                                                break;
                                            if(wait[i_307] == 0)
                                            {
                                                bool = true;
                                                break;
                                            }
                                            i_307++;
                                        } while(true);
                                        if(!bool || xt.lan)
                                        {
                                            loadstage = 0;
                                            remstage = 0;
                                            gstage = 0;
                                            gnpls = 8;
                                            gwait = 0;
                                            gnbts = 0;
                                            gclass = 0;
                                            gcars = 0;
                                            gfix = 0;
                                            gnotp = 0;
                                            gplayers = "";
                                            gs.wgame.select(0);
                                            chalngd = -2;
                                        } else
                                        {
                                            chalngd = -6;
                                        }
                                    }
                                } else
                                if(chalngd != -5)
                                {
                                    if(invo)
                                        invo = false;
                                    for(int i_308 = 0; i_308 < 7; i_308++)
                                    {
                                        if(!invos[i_308].equals(""))
                                            invos[i_308] = "";
                                        if(!dinvi[i_308].equals(""))
                                            dinvi[i_308] = "";
                                    }

                                    gs.swait.hide();
                                    gs.snpls.hide();
                                    gs.snbts.hide();
                                    gs.sgame.hide();
                                    gs.wgame.hide();
                                    gs.pgame.hide();
                                    gs.vnpls.hide();
                                    gs.vtyp.hide();
                                    gs.warb.hide();
                                    gs.mstgs.hide();
                                    gs.slaps.hide();
                                    gs.snfm1.hide();
                                    gs.snfmm.hide();
                                    gs.snfm2.hide();
                                    gs.sclass.hide();
                                    gs.scars.hide();
                                    gs.sfix.hide();
                                    gs.mycar.hide();
                                    gs.notp.hide();
                                    gs.requestFocus();
                                    chalngd = -1;
                                }
                            if(i_305 == 1)
                                xt.fase = 23;
                            if(i_305 == 2)
                            {
                                conon = 0;
                                lg.exitfromlobby();
                                try
                                {
                                    socket.close();
                                    socket = null;
                                    din.close();
                                    din = null;
                                    dout.close();
                                    dout = null;
                                }
                                catch(Exception exception) { }
                                hideinputs();
                            }
                            int i_309 = 3;
                            if(chalngd > -1)
                            {
                                if(i_305 == 3)
                                {
                                    ongame = chalngd;
                                    chalngd = -1;
                                }
                                if(i_305 == 4)
                                {
                                    ongame = chalngd;
                                    join = chalngd;
                                    msg = "| Joining Game |";
                                    chalngd = -1;
                                    longame = -1;
                                }
                                if(i_305 == 5)
                                {
                                    ongame = longame;
                                    chalngd = -1;
                                    longame = -1;
                                }
                                i_309 = 6;
                            } else
                            {
                                if(chalngd != -1 && chalngd != -5 && i_305 == 3)
                                {
                                    if(invo)
                                        invo = false;
                                    for(int i_310 = 0; i_310 < 7; i_310++)
                                    {
                                        if(!invos[i_310].equals(""))
                                            invos[i_310] = "";
                                        if(!dinvi[i_310].equals(""))
                                            dinvi[i_310] = "";
                                    }

                                    gs.swait.hide();
                                    gs.snpls.hide();
                                    gs.snbts.hide();
                                    gs.sgame.hide();
                                    gs.wgame.hide();
                                    gs.pgame.hide();
                                    gs.vnpls.hide();
                                    gs.vtyp.hide();
                                    gs.warb.hide();
                                    gs.mstgs.hide();
                                    gs.slaps.hide();
                                    gs.snfm1.hide();
                                    gs.snfmm.hide();
                                    gs.snfm2.hide();
                                    gs.sclass.hide();
                                    gs.scars.hide();
                                    gs.sfix.hide();
                                    gs.mycar.hide();
                                    gs.notp.hide();
                                    gs.requestFocus();
                                    chalngd = -1;
                                }
                                if(chalngd == -6 && i_305 == 4)
                                    chalngd = -1;
                                if(chalngd == -2)
                                    if(gs.wgame.getSelectedIndex() == 0)
                                    {
                                        if(gs.sgame.getSelectedIndex() >= 3 && !xt.logged)
                                        {
                                            if(i_305 == 4)
                                                gs.editlink(xt.nickname, true);
                                            i_309 = 5;
                                        } else
                                        {
                                            if(i_305 == 4)
                                                if(loadstage < 0)
                                                {
                                                    rd.setColor(new Color(0, 0, 0));
                                                    rd.fillRect(0, 0, 670, 400);
                                                    gs.repaint();
                                                    gs.rooms.hide();
                                                    gs.cmsg.hide();
                                                    gs.sgame.hide();
                                                    gs.wgame.hide();
                                                    gs.warb.hide();
                                                    gs.pgame.hide();
                                                    gs.vnpls.hide();
                                                    gs.vtyp.hide();
                                                    gs.mstgs.hide();
                                                    gs.slaps.hide();
                                                    gs.snfm1.hide();
                                                    gs.snfmm.hide();
                                                    gs.snfm2.hide();
                                                    gs.requestFocus();
                                                    m.ptr = 0;
                                                    m.ptcnt = -10;
                                                    m.hit = 45000;
                                                    m.fallen = 0;
                                                    m.nrnd = 0;
                                                    m.trk = 1;
                                                    m.ih = 25;
                                                    m.iw = 65;
                                                    m.h = 425;
                                                    m.w = 735;
                                                    addstage = 0;
                                                    fase = 4;
                                                } else
                                                {
                                                    sflk = 25;
                                                }
                                            if(loadstage >= 0)
                                            {
                                                i_309 = 5;
                                            } else
                                            {
                                                if(i_305 == 5)
                                                    if(gstage != 0)
                                                    {
                                                        gs.sgame.hide();
                                                        gs.wgame.hide();
                                                        gs.pgame.hide();
                                                        gs.vnpls.hide();
                                                        gs.vtyp.hide();
                                                        gs.warb.hide();
                                                        gs.mstgs.hide();
                                                        gs.slaps.hide();
                                                        gs.snfm1.hide();
                                                        gs.snfmm.hide();
                                                        gs.snfm2.hide();
                                                        gs.requestFocus();
                                                        chalngd = -3;
                                                        i_305 = -1;
                                                    } else
                                                    {
                                                        sflk = 25;
                                                    }
                                                i_309 = 6;
                                            }
                                        }
                                    } else
                                    if(!xt.clan.equals(""))
                                    {
                                        int i_311 = 4;
                                        if(gs.warb.sel != 0 && gb.loadwbgames == 2)
                                        {
                                            if(gs.wgame.getSelectedIndex() == 1 && gs.vnpls.sel != 0 && cancreate == 2)
                                            {
                                                if(i_305 == 4)
                                                {
                                                    if(invo)
                                                        invo = false;
                                                    msg = "| Creating Game |";
                                                    gplayers = (new StringBuilder()).append("#warb#").append(gb.warb).append("#").append(gb.warbnum).append("#").append(gb.gameturn + 1).append("#").append(xt.clan).append("#").append(gb.vclan).append("#").append(gb.ascore).append("#").append(gb.vscore).append("#").append(gs.vtyp.sel + 1).append("#").toString();
                                                    gstage = gb.wbstage[gb.gameturn];
                                                    gstagelaps = gb.wblaps[gb.gameturn];
                                                    gcars = gb.wbcars[gb.gameturn] - 1;
                                                    gclass = gb.wbclass[gb.gameturn];
                                                    gfix = gb.wbfix[gb.gameturn];
                                                    gnpls = 8;
                                                    if(gs.vnpls.sel == 1)
                                                        gnpls = 4;
                                                    if(gs.vnpls.sel == 2)
                                                        gnpls = 6;
                                                    gwait = 120;
                                                    gnotp = 0;
                                                    gs.wgame.hide();
                                                    gs.pgame.hide();
                                                    gs.vnpls.hide();
                                                    gs.vtyp.hide();
                                                    gs.warb.hide();
                                                    gs.requestFocus();
                                                    chalngd = -5;
                                                }
                                                i_311++;
                                            }
                                            if(gs.wgame.getSelectedIndex() == 2 && gs.pgame.sel != 0 && i_305 == 4)
                                            {
                                                if(invo)
                                                    invo = false;
                                                msg = "| Creating Game |";
                                                gstage = gb.wbstage[gs.pgame.sel - 1];
                                                gstagelaps = gb.wblaps[gs.pgame.sel - 1];
                                                gcars = gb.wbcars[gs.pgame.sel - 1] - 1;
                                                gclass = gb.wbclass[gs.pgame.sel - 1];
                                                gfix = gb.wbfix[gs.pgame.sel - 1];
                                                gnpls = 8;
                                                gwait = 120;
                                                gnotp = 0;
                                                gplayers = "";
                                                gs.wgame.hide();
                                                gs.pgame.hide();
                                                gs.vnpls.hide();
                                                gs.vtyp.hide();
                                                gs.warb.hide();
                                                gs.requestFocus();
                                                chalngd = -5;
                                            }
                                            if(gs.wgame.getSelectedIndex() == 1 && gb.canredo && i_305 == i_311)
                                                gb.loadwbgames = 7;
                                        }
                                    } else
                                    if(i_305 == 4)
                                    {
                                        gb.tab = 3;
                                        gb.cfase = 2;
                                        gb.em = 1;
                                        gb.msg = "Clan Search";
                                        gb.smsg = "Listing clans with recent activity...";
                                        gb.nclns = 0;
                                        gb.spos5 = 0;
                                        gb.lspos5 = 0;
                                        gb.flko = 0;
                                        gb.open = 2;
                                        gb.upo = true;
                                    }
                                if(chalngd == -3)
                                {
                                    if(i_305 == 4)
                                    {
                                        chalngd = -2;
                                        gs.snpls.hide();
                                        gs.snbts.hide();
                                        gs.swait.hide();
                                        gs.requestFocus();
                                    }
                                    if(i_305 == 5)
                                        if(gnpls != 0 && gs.snpls.getSelectedIndex() != 0)
                                        {
                                            chalngd = -4;
                                            for(int i_312 = 0; i_312 < 7; i_312++)
                                            {
                                                if(!invos[i_312].equals(""))
                                                    invos[i_312] = "";
                                                if(!dinvi[i_312].equals(""))
                                                    dinvi[i_312] = "";
                                            }

                                            i_305 = -1;
                                            gs.snpls.hide();
                                            gs.snbts.hide();
                                            gs.swait.hide();
                                            gs.requestFocus();
                                        } else
                                        {
                                            sflk = 25;
                                        }
                                    i_309 = 6;
                                }
                                if(chalngd == -4)
                                {
                                    i_309 = 7;
                                    int i_313 = 0;
                                    for(int i_314 = 0; i_314 < 7; i_314++)
                                        if(!invos[i_314].equals(""))
                                            i_313++;

                                    if(i_313 < gnpls - 1)
                                    {
                                        if(i_305 == 4)
                                            if(!invo)
                                                invo = true;
                                            else
                                                invo = false;
                                    } else
                                    {
                                        i_309 = 6;
                                    }
                                    if(i_305 == i_309 - 2)
                                    {
                                        if(invo)
                                            invo = false;
                                        if(gs.mycar.getState() && xt.sc[0] < 16)
                                        {
                                            gclass = -(xt.sc[0] + 2);
                                            gcars = 0;
                                        }
                                        if(gs.notp.getState())
                                            gnotp = 1;
                                        else
                                            gnotp = 0;
                                        gplayers = "";
                                        gs.sclass.hide();
                                        gs.scars.hide();
                                        gs.sfix.hide();
                                        gs.mycar.hide();
                                        gs.notp.hide();
                                        gs.requestFocus();
                                        chalngd = -3;
                                    }
                                    if(i_305 == i_309 - 1)
                                    {
                                        if(invo)
                                            invo = false;
                                        msg = "| Creating Game |";
                                        if(gs.mycar.getState() && xt.sc[0] < 16)
                                        {
                                            gclass = -(xt.sc[0] + 2);
                                            gcars = 0;
                                        }
                                        if(gclass != 0)
                                            gwait = 120;
                                        if(gs.notp.getState())
                                            gnotp = 1;
                                        else
                                            gnotp = 0;
                                        gplayers = "";
                                        if(i_313 != 0)
                                        {
                                            gnpls = i_313 + 1;
                                            gplayers = (new StringBuilder()).append("").append(pnames[im]).append("#").toString();
                                            for(int i_315 = 0; i_315 < i_313; i_315++)
                                            {
                                                StringBuilder stringbuilder = new StringBuilder();
                                                Lobby lobby_316 = this;
                                                lobby_316.gplayers = stringbuilder.append(lobby_316.gplayers).append(invos[i_315]).append("#").toString();
                                            }

                                        }
                                        gs.sclass.hide();
                                        gs.scars.hide();
                                        gs.sfix.hide();
                                        gs.mycar.hide();
                                        gs.notp.hide();
                                        gs.requestFocus();
                                        chalngd = -5;
                                    }
                                }
                            }
                            if(i_305 == i_309 && !xt.lan && !gs.cmsg.getText().equals("Type here...") && !gs.cmsg.getText().equals(""))
                            {
                                String string = xt.passRem(gs.cmsg.getText().replace('|', ':'));
                                if(!xt.msgcheck(string) && updatec > -12)
                                {
                                    for(int i_317 = 0; i_317 < 6; i_317++)
                                    {
                                        sentn[i_317] = sentn[i_317 + 1];
                                        cnames[i_317] = cnames[i_317 + 1];
                                    }

                                    sentn[6] = string;
                                    cnames[6] = pnames[im];
                                    if(updatec > -11)
                                        updatec = -11;
                                    else
                                        updatec--;
                                    spos3 = 28;
                                } else
                                {
                                    xt.warning++;
                                }
                                gs.cmsg.setText("");
                            }
                        } else
                        if(dispcar == -1)
                        {
                            int i_318 = 0;
                            for(int i_319 = 0; i_319 < ngm; i_319++)
                                if(ongame == gnum[i_319])
                                    i_318 = i_319;

                            boolean bool = false;
                            if(gwarb[i_318] == 0)
                            {
                                if(!gplyrs[i_318].equals("") && gplyrs[i_318].indexOf(pnames[im]) == -1)
                                    bool = true;
                            } else
                            if(!xt.clan.toLowerCase().equals(gaclan[i_318].toLowerCase()) && !xt.clan.toLowerCase().equals(gvclan[i_318].toLowerCase()))
                                bool = true;
                            if(control.enter && wait[i_318] > 0 && pgames[im] == -1 && !bool)
                            {
                                join = ongame;
                                msg = "| Joining Game |";
                                spos = 0;
                                if(pbtn == 0)
                                    pessd[1] = true;
                            }
                            if(wait[i_318] == -1 && pgames[im] == -1 && control.enter)
                            {
                                i_305 = 0;
                                pessd[0] = true;
                            }
                            if(pgames[im] == -1 && control.exit)
                            {
                                i_305 = 0;
                                pessd[0] = true;
                            }
                            if(i_305 == 0)
                                if(pgames[im] == -1)
                                {
                                    ongame = -1;
                                    chalngd = -1;
                                } else
                                {
                                    join = -2;
                                    msg = "| Leaving Game |";
                                    longame = -1;
                                }
                            if(pbtn == 0)
                            {
                                if(i_305 == 1)
                                    if(wait[i_318] > 0)
                                    {
                                        if(pgames[im] == -1)
                                        {
                                            join = ongame;
                                            msg = "| Joining Game |";
                                            spos = 0;
                                        } else
                                        if(gmaker[i_318].equals(pnames[im]) && npls[i_318] > 1)
                                            fstart = true;
                                        else
                                            i_305 = 2;
                                    } else
                                    {
                                        if(wait[i_318] == 0 && prevloaded == 1)
                                        {
                                            laps = gnlaps[i_318];
                                            stage = gstgn[i_318];
                                            stagename = gstages[i_318];
                                            nfix = gfx[i_318];
                                            if(gntb[i_318] == 1)
                                                notb = true;
                                            else
                                                notb = false;
                                            gs.setCursor(new Cursor(3));
                                            conon = 3;
                                        } else
                                        {
                                            i_305 = 2;
                                        }
                                        if(wait[i_318] == 0 && xt.lan)
                                        {
                                            laps = gnlaps[i_318];
                                            stage = gstgn[i_318];
                                            stagename = gstages[i_318];
                                            nfix = gfx[i_318];
                                            if(gntb[i_318] == 1)
                                                notb = true;
                                            else
                                                notb = false;
                                            gs.setCursor(new Cursor(3));
                                            conon = 3;
                                        }
                                    }
                                if(i_305 == 2 && !xt.lan && !gs.cmsg.getText().equals("Type here...") && !gs.cmsg.getText().equals(""))
                                {
                                    String string = xt.passRem(gs.cmsg.getText().replace('|', ':'));
                                    if(!xt.msgcheck(string) && updatec > -12)
                                    {
                                        for(int i_320 = 0; i_320 < 6; i_320++)
                                        {
                                            sentn[i_320] = sentn[i_320 + 1];
                                            cnames[i_320] = cnames[i_320 + 1];
                                        }

                                        sentn[6] = string;
                                        cnames[6] = pnames[im];
                                        if(updatec > -11)
                                            updatec = -11;
                                        else
                                            updatec--;
                                    } else
                                    {
                                        xt.warning++;
                                    }
                                    gs.cmsg.setText("");
                                }
                            }
                            if(pbtn == 1 && i_305 == 1)
                                if(pgames[im] == -1)
                                {
                                    join = ongame;
                                    msg = "| Joining Game |";
                                    spos = 0;
                                } else
                                if(!invo)
                                    invo = true;
                                else
                                    invo = false;
                            if(pbtn == 2 && (i_305 == 1 || i_305 == 2))
                            {
                                fase = 2;
                                m.ptr = 0;
                                m.ptcnt = -10;
                                m.hit = 45000;
                                m.fallen = 0;
                                m.nrnd = 0;
                                m.trk = 1;
                                m.ih = 25;
                                m.iw = 65;
                                m.h = 425;
                                m.w = 735;
                                if(gs.cmsg.isShowing())
                                {
                                    gs.cmsg.hide();
                                    gs.requestFocus();
                                }
                            }
                        } else
                        {
                            if(i_305 == 0)
                                if(pgames[im] == -1)
                                {
                                    ongame = -1;
                                    chalngd = -1;
                                } else
                                {
                                    join = -2;
                                    msg = "| Leaving Game |";
                                    longame = -1;
                                }
                            if(pbtn == 1 && i_305 == 1)
                                if(pgames[im] == -1)
                                {
                                    join = ongame;
                                    msg = "| Joining Game |";
                                    spos = 0;
                                } else
                                if(!invo)
                                    invo = true;
                                else
                                    invo = false;
                        }
                } else
                if(ontyp != 76)
                {
                    if(i_305 == 0)
                        if(ontyp < 30)
                        {
                            xt.onjoin = onjoin;
                            xt.ontyp = ontyp;
                            xt.playingame = -101;
                            xt.fase = 23;
                        } else
                        {
                            if(!gb.claname.equals(xt.clan))
                            {
                                gb.claname = xt.clan;
                                gb.loadedc = false;
                            }
                            gb.spos5 = 0;
                            gb.lspos5 = 0;
                            gb.cfase = 3;
                            gb.loadedcars = -1;
                            gb.loadedcar = 0;
                            gb.ctab = 2;
                            gb.tab = 3;
                            gb.open = 2;
                            gb.upo = true;
                            onjoin = -1;
                        }
                    if(i_305 == 1)
                        onjoin = -1;
                } else
                {
                    if(i_305 == 0)
                    {
                        gs.editlink(xt.nickname, true);
                        onjoin = -1;
                    }
                    if(i_305 == 1)
                        onjoin = -1;
                }
            } else
            {
                if(i_305 == 0)
                    gs.editlink(xt.nickname, true);
                if(i_305 == 1)
                    regnow = false;
            }
        lxm = i;
        lym = i_303;
        control.enter = false;
        control.exit = false;
    }

    public void hideinputs()
    {
        gs.cmsg.hide();
        gs.swait.hide();
        gs.snpls.hide();
        gs.snbts.hide();
        gs.sgame.hide();
        gs.wgame.hide();
        gs.pgame.hide();
        gs.vnpls.hide();
        gs.vtyp.hide();
        gs.warb.hide();
        gs.mstgs.hide();
        gs.snfm1.hide();
        gs.snfmm.hide();
        gs.slaps.hide();
        gs.snfm2.hide();
        gs.sclass.hide();
        gs.scars.hide();
        gs.sfix.hide();
        gs.mycar.hide();
        gs.notp.hide();
        gs.rooms.hide();
        gs.requestFocus();
    }

    public void drawSbutton(Image image, int i, int i_321)
    {
        bx[btn] = i;
        by[btn] = i_321;
        bw[btn] = image.getWidth(ob);
        if(!pessd[btn])
        {
            rd.drawImage(image, i - bw[btn] / 2, i_321 - image.getHeight(ob) / 2 - 1, null);
            rd.drawImage(xt.bols, i - bw[btn] / 2 - 15, i_321 - 13, null);
            rd.drawImage(xt.bors, i + bw[btn] / 2 + 9, i_321 - 13, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_321 - 13, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_321 + 10, bw[btn] + 18, 3, null);
        } else
        {
            rd.drawImage(image, (i - bw[btn] / 2) + 1, i_321 - image.getHeight(ob) / 2, null);
            rd.drawImage(xt.bolps, i - bw[btn] / 2 - 15, i_321 - 13, null);
            rd.drawImage(xt.borps, i + bw[btn] / 2 + 9, i_321 - 13, null);
            rd.drawImage(xt.bob, i - bw[btn] / 2 - 9, i_321 - 13, bw[btn] + 18, 3, null);
            rd.drawImage(xt.bot, i - bw[btn] / 2 - 9, i_321 + 10, bw[btn] + 18, 3, null);
        }
        btn++;
    }

    public void stringbutton(String string, int i, int i_322, int i_323)
    {
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        bx[btn] = i;
        by[btn] = i_322 - 5;
        bw[btn] = ftm.stringWidth(string);
        if(!pessd[btn])
        {
            rd.setColor(color2k(220, 220, 220));
            rd.fillRect(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), bw[btn] + 20, 25 - i_323 * 2);
            rd.setColor(color2k(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), i + bw[btn] / 2 + 10, i_322 - (17 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (18 - i_323), i + bw[btn] / 2 + 10, i_322 - (18 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 9, i_322 - (19 - i_323), i + bw[btn] / 2 + 9, i_322 - (19 - i_323));
            rd.setColor(color2k(200, 200, 200));
            rd.drawLine(i + bw[btn] / 2 + 10, i_322 - (17 - i_323), i + bw[btn] / 2 + 10, i_322 + (7 - i_323));
            rd.drawLine(i + bw[btn] / 2 + 11, i_322 - (17 - i_323), i + bw[btn] / 2 + 11, i_322 + (7 - i_323));
            rd.drawLine(i + bw[btn] / 2 + 12, i_322 - (16 - i_323), i + bw[btn] / 2 + 12, i_322 + (6 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 + (7 - i_323), i + bw[btn] / 2 + 10, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 + (8 - i_323), i + bw[btn] / 2 + 10, i_322 + (8 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 9, i_322 + (9 - i_323), i + bw[btn] / 2 + 9, i_322 + (9 - i_323));
            rd.setColor(color2k(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), i - bw[btn] / 2 - 10, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 11, i_322 - (17 - i_323), i - bw[btn] / 2 - 11, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 12, i_322 - (16 - i_323), i - bw[btn] / 2 - 12, i_322 + (6 - i_323));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(string, i - bw[btn] / 2, i_322);
        } else
        {
            rd.setColor(color2k(210, 210, 210));
            rd.fillRect(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), bw[btn] + 20, 25 - i_323 * 2);
            rd.setColor(color2k(200, 200, 200));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), i + bw[btn] / 2 + 10, i_322 - (17 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (18 - i_323), i + bw[btn] / 2 + 10, i_322 - (18 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 9, i_322 - (19 - i_323), i + bw[btn] / 2 + 9, i_322 - (19 - i_323));
            rd.drawLine(i + bw[btn] / 2 + 10, i_322 - (17 - i_323), i + bw[btn] / 2 + 10, i_322 + (7 - i_323));
            rd.drawLine(i + bw[btn] / 2 + 11, i_322 - (17 - i_323), i + bw[btn] / 2 + 11, i_322 + (7 - i_323));
            rd.drawLine(i + bw[btn] / 2 + 12, i_322 - (16 - i_323), i + bw[btn] / 2 + 12, i_322 + (6 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 + (7 - i_323), i + bw[btn] / 2 + 10, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 + (8 - i_323), i + bw[btn] / 2 + 10, i_322 + (8 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 9, i_322 + (9 - i_323), i + bw[btn] / 2 + 9, i_322 + (9 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 10, i_322 - (17 - i_323), i - bw[btn] / 2 - 10, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 11, i_322 - (17 - i_323), i - bw[btn] / 2 - 11, i_322 + (7 - i_323));
            rd.drawLine(i - bw[btn] / 2 - 12, i_322 - (16 - i_323), i - bw[btn] / 2 - 12, i_322 + (6 - i_323));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(string, (i - bw[btn] / 2) + 1, i_322);
        }
        btn++;
    }

    public Color color2k(int i, int i_324, int i_325)
    {
        Color color = new Color(i, i_324, i_325);
        float fs[] = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
        fs[0] = 0.13F;
        fs[1] = 0.35F;
        return Color.getHSBColor(fs[0], fs[1], fs[2]);
    }

    public int getvalue(String string, int i)
    {
        int i_326 = -1;
        try
        {
            int i_327 = 0;
            int i_328 = 0;
            int i_329 = 0;
            String string_330 = "";
            String string_331 = "";
            for(; i_327 < string.length() && i_329 != 2; i_327++)
            {
                string_330 = (new StringBuilder()).append("").append(string.charAt(i_327)).toString();
                if(string_330.equals("|"))
                {
                    i_328++;
                    if(i_329 == 1 || i_328 > i)
                        i_329 = 2;
                    continue;
                }
                if(i_328 == i)
                {
                    string_331 = (new StringBuilder()).append(string_331).append(string_330).toString();
                    i_329 = 1;
                }
            }

            if(string_331.equals(""))
                string_331 = "-1";
            i_326 = Integer.valueOf(string_331).intValue();
        }
        catch(Exception exception) { }
        return i_326;
    }

    public String getSvalue(String string, int i)
    {
        String string_332 = "";
        try
        {
            int i_333 = 0;
            int i_334 = 0;
            int i_335 = 0;
            String string_336 = "";
            String string_337 = "";
            for(; i_333 < string.length() && i_335 != 2; i_333++)
            {
                string_336 = (new StringBuilder()).append("").append(string.charAt(i_333)).toString();
                if(string_336.equals("|"))
                {
                    i_334++;
                    if(i_335 == 1 || i_334 > i)
                        i_335 = 2;
                    continue;
                }
                if(i_334 == i)
                {
                    string_337 = (new StringBuilder()).append(string_337).append(string_336).toString();
                    i_335 = 1;
                }
            }

            string_332 = string_337;
        }
        catch(Exception exception) { }
        return string_332;
    }

    public int getHvalue(String string, int i)
    {
        int i_338 = -1;
        try
        {
            int i_339 = 0;
            int i_340 = 0;
            int i_341 = 0;
            String string_342 = "";
            String string_343 = "";
            for(; i_339 < string.length() && i_341 != 2; i_339++)
            {
                string_342 = (new StringBuilder()).append("").append(string.charAt(i_339)).toString();
                if(string_342.equals("#"))
                {
                    i_340++;
                    if(i_341 == 1 || i_340 > i)
                        i_341 = 2;
                    continue;
                }
                if(i_340 == i)
                {
                    string_343 = (new StringBuilder()).append(string_343).append(string_342).toString();
                    i_341 = 1;
                }
            }

            if(string_343.equals(""))
                string_343 = "-1";
            i_338 = Integer.valueOf(string_343).intValue();
        }
        catch(Exception exception) { }
        return i_338;
    }

    public String getHSvalue(String string, int i)
    {
        String string_344 = "";
        try
        {
            int i_345 = 0;
            int i_346 = 0;
            int i_347 = 0;
            String string_348 = "";
            String string_349 = "";
            for(; i_345 < string.length() && i_347 != 2; i_345++)
            {
                string_348 = (new StringBuilder()).append("").append(string.charAt(i_345)).toString();
                if(string_348.equals("#"))
                {
                    i_346++;
                    if(i_347 == 1 || i_346 > i)
                        i_347 = 2;
                    continue;
                }
                if(i_346 == i)
                {
                    string_349 = (new StringBuilder()).append(string_349).append(string_348).toString();
                    i_347 = 1;
                }
            }

            string_344 = string_349;
        }
        catch(Exception exception) { }
        return string_344;
    }

    public String getSevervalue(String string, int i)
    {
        String string_350 = "";
        if(!string.equals(""))
            try
            {
                boolean bool = false;
                int i_351 = 0;
                int i_352 = 0;
                int i_353 = 0;
                String string_354 = "";
                String string_355 = "";
                for(; i_351 < string.length() && i_353 != 2; i_351++)
                {
                    string_354 = (new StringBuilder()).append("").append(string.charAt(i_351)).toString();
                    if(string_354.equals("|"))
                    {
                        i_352++;
                        if(i_353 == 1 || i_352 > i)
                            i_353 = 2;
                        continue;
                    }
                    if(i_352 == i)
                    {
                        string_355 = (new StringBuilder()).append(string_355).append(string_354).toString();
                        i_353 = 1;
                    }
                }

                string_350 = string_355;
            }
            catch(Exception exception)
            {
                string_350 = "";
            }
        return string_350;
    }

    Graphics2D rd;
    Login lg;
    Globe gb;
    xtGraphics xt;
    CarDefine cd;
    Medium m;
    FontMetrics ftm;
    ImageObserver ob;
    GameSparker gs;
    Thread connector;
    int conon;
    boolean regnow;
    boolean lanlogged;
    int fase;
    int stage;
    int laps;
    String stagename;
    int nfix;
    boolean notb;
    boolean pessd[] = {
        false, false, false, false, false, false, false, false
    };
    int bx[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int by[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int bw[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int btn;
    int pbtn;
    int nflk;
    int ncnt;
    int rerr;
    int pback;
    int cflk;
    int sflk;
    String msg;
    String lmsg;
    int opselect;
    boolean lloaded;
    int npo;
    String pnames[];
    int pcars[];
    String pcarnames[];
    String pclan[];
    int pgames[];
    float pcols[][];
    int prnpo;
    String prnames[] = {
        "", "", "", "", "", "", "", ""
    };
    int ppos[] = {
        6, 6, 6, 6, 6, 6, 6, 6
    };
    int plap[] = {
        6, 6, 6, 6, 6, 6, 6, 6
    };
    int ppow[] = {
        50, 50, 50, 50, 50, 50, 50, 50
    };
    int pdam[] = {
        50, 50, 50, 50, 50, 50, 50, 50
    };
    int prevloaded;
    String stuntname;
    String lapsname;
    String wastename;
    int ngm;
    int gnum[];
    int gstgn[];
    String gstages[];
    int gnlaps[];
    int mnpls[];
    int mnbts[];
    int wait[];
    int gcrs[];
    int gclss[];
    int gfx[];
    int gntb[];
    String gplyrs[];
    int gwarb[];
    String gwarbnum[];
    int gameturn[];
    String gaclan[];
    String gvclan[];
    int gascore[];
    int gvscore[];
    int gwtyp[];
    String gmaker[];
    int npls[];
    int ongame;
    int join;
    int chalngd;
    int im;
    int longame;
    int onjoin;
    int ontyp;
    int dispcar;
    int forcar;
    int addstage;
    ContO dispco;
    boolean fstart;
    boolean jflexo;
    String chalby;
    int ctime;
    boolean invo;
    String invos[] = {
        "", "", "", "", "", "", "", ""
    };
    String dinvi[] = {
        "", "", "", "", "", "", "", ""
    };
    String cnames[] = {
        "", "", "", "", "", "", ""
    };
    String sentn[] = {
        "", "", "", "", "", "", ""
    };
    int updatec;
    int loadstage;
    int gstage;
    int gstagelaps;
    int gnpls;
    int gwait;
    int gnbts;
    int gcars;
    int gclass;
    int gfix;
    int gnotp;
    int remstage;
    int msload;
    int sgflag;
    String gstagename;
    String gplayers;
    boolean inwab;
    boolean loadwarb;
    int warbsel;
    int cancreate;
    int pgamesel;
    int cntchkn;
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    int spos;
    int spos2;
    int spos3;
    int mscro;
    int lspos;
    int mscro2;
    int lspos2;
    int mscro3;
    int lspos3;
    int clicked;
    int opengame;
    int britchl;
    boolean zeromsw;
    int mousonp;
    int cmonp;
    long ptime;
    int pcurs;
    boolean grprsd;
    int pend;
    int mrot;
    boolean pendb;
    int cac[] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1
    };
    int cax[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    int cay[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    boolean mousedout;
    int flks;
    int waitlink;
    boolean pre1;
    boolean pre2;
    int prereq;
    int lxm;
    int lym;
    Image lockicn;
}
