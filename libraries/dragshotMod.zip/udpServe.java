// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   udpServe.java

import java.net.*;

public class udpServe
    implements Runnable
{

    public udpServe(UDPMistro udpmistro, int i)
    {
        mport = 7060;
        im = 0;
        um = udpmistro;
        im = i;
        mport = 7060 + im;
        servo = new Thread(this);
        servo.start();
    }

    public void stopServe()
    {
        try
        {
            dSocket.close();
            dSocket = null;
        }
        catch(Exception exception) { }
        if(servo != null)
        {
            servo.stop();
            servo = null;
        }
    }

    public void run()
    {
        try
        {
            dSocket = new DatagramSocket(mport);
            byte abyte0[] = new byte[128];
            do
            {
                DatagramPacket datagrampacket = new DatagramPacket(abyte0, abyte0.length);
                dSocket.receive(datagrampacket);
                String s = new String(datagrampacket.getData());
                String s1 = getSvalue(s, 0);
                int i = getvalue(s, 1);
                if(i == im && im < um.nplayers && um.out[i] != 76)
                {
                    int j = getvalue(s, 2);
                    int k = 0;
                    for(int i1 = 0; i1 < 3; i1++)
                        if(j != um.frame[i][i1])
                            k++;

                    if(k == 3)
                    {
                        for(int j1 = 0; j1 < 3; j1++)
                        {
                            if(j <= um.frame[i][j1])
                                continue;
                            for(int j2 = 2; j2 >= j1 + 1; j2--)
                            {
                                um.frame[i][j2] = um.frame[i][j2 - 1];
                                um.info[i][j2] = um.info[i][j2 - 1];
                            }

                            um.frame[i][j1] = j;
                            um.info[i][j1] = getSvalue(s, 3);
                            j1 = 3;
                        }

                    }
                    if(um.gocnt[i] != 0)
                    {
                        int k1 = 0;
                        for(int k2 = 0; k2 < um.nplayers; k2++)
                            if(um.frame[k2][0] >= 0)
                                k1++;

                        if(k1 == um.nplayers)
                        {
                            s1 = "1111111";
                            um.gocnt[i]--;
                        }
                    }
                    if(!um.go)
                    {
                        int l1 = 0;
                        for(int l2 = 0; l2 < um.nplayers; l2++)
                            if(um.frame[l2][0] >= 0)
                                l1++;

                        if(l1 == um.nplayers)
                            um.gocnt[0]--;
                        if(um.gocnt[0] <= 1)
                            um.go = true;
                    }
                }
                InetAddress inetaddress = datagrampacket.getAddress();
                int l = datagrampacket.getPort();
                int i2 = 0;
                while(i2 < um.nplayers) 
                {
                    if(i2 != im)
                    {
                        int i3 = -1;
                        for(int j3 = 0; j3 < 3; j3++)
                            if(um.frame[i2][j3] == lsframe[i2] + 1)
                                i3 = j3;

                        if(i3 == -1)
                        {
                            for(int k3 = 0; k3 < 3; k3++)
                                if(um.frame[i2][k3] > lsframe[i2])
                                    i3 = k3;

                        }
                        if(i3 == -1)
                            i3 = 0;
                        lsframe[i2] = um.frame[i2][i3];
                        String s2 = (new StringBuilder()).append("").append(s1).append("|").append(i2).append("|").append(um.frame[i2][i3]).append("|").append(um.info[i2][i3]).append("|").toString();
                        byte abyte1[] = s2.getBytes();
                        DatagramPacket datagrampacket1 = new DatagramPacket(abyte1, abyte1.length, inetaddress, l);
                        dSocket.send(datagrampacket1);
                    }
                    i2++;
                }
            } while(true);
        }
        catch(Exception exception)
        {
            return;
        }
    }

    public int getvalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals("|"))
                {
                    l++;
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String getSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals("|"))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    Thread servo;
    DatagramSocket dSocket;
    UDPMistro um;
    int mport;
    int im;
    int lsframe[] = {
        -1, -1, -1, -1, -1, -1, -1, -1
    };
}
