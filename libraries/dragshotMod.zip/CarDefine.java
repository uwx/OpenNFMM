// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CarDefine.java

import java.awt.TextField;
import java.io.*;
import java.net.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class CarDefine
    implements Runnable
{

    public CarDefine(ContO aconto[], Medium medium, Trackers trackers, GameSparker gamesparker)
    {
        lastload = 0;
        nlcars = 0;
        nlocars = 0;
        xnlocars = 0;
        include = new boolean[40];
        createdby = new String[40];
        publish = new int[40];
        loadnames = new String[20];
        nl = 0;
        action = 0;
        carlon = false;
        reco = -2;
        haltload = 0;
        onloadingcar = 0;
        ac = -1;
        acname = "Radical One";
        fails = "";
        tnickey = "";
        tclan = "";
        tclankey = "";
        loadlist = 0;
        viewname = "";
        staction = 0;
        onstage = "";
        inslot = -1;
        roundslot = 0;
        lastcar = "";
        msloaded = 0;
        top20adds = new int[20];
        bco = aconto;
        m = medium;
        t = trackers;
        gs = gamesparker;
    }

    public void loadstat(byte abyte0[], String s, int i, int j, int k, int l)
    {
        names[l] = s;
        boolean flag = false;
        boolean flag1 = false;
        String s1 = "";
        int ai[] = {
            128, 128, 128, 128, 128
        };
        int i1 = 640;
        int ai1[] = {
            50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 
            50
        };
        int ai2[] = {
            50, 50, 50
        };
        enginsignature[l] = 0;
        float f = 0.0F;
        publish[l - 16] = 0;
        createdby[l - 16] = "Unkown User";
        try
        {
            DataInputStream datainputstream = new DataInputStream(new ByteArrayInputStream(abyte0));
            do
            {
                String s2;
                if((s2 = datainputstream.readLine()) == null)
                    break;
                s2 = s2.trim();
                if(s2.startsWith("stat("))
                    try
                    {
                        i1 = 0;
                        for(int k1 = 0; k1 < 5; k1++)
                        {
                            ai[k1] = getvalue("stat", s2, k1);
                            if(ai[k1] > 200)
                                ai[k1] = 200;
                            if(ai[k1] < 16)
                                ai[k1] = 16;
                            i1 += ai[k1];
                        }

                        flag = true;
                    }
                    catch(Exception exception1)
                    {
                        flag = false;
                    }
                if(s2.startsWith("physics("))
                    try
                    {
                        for(int l1 = 0; l1 < 11; l1++)
                        {
                            ai1[l1] = getvalue("physics", s2, l1);
                            if(ai1[l1] > 100)
                                ai1[l1] = 100;
                            if(ai1[l1] < 0)
                                ai1[l1] = 0;
                        }

                        for(int i2 = 0; i2 < 3; i2++)
                        {
                            ai2[i2] = getvalue("physics", s2, i2 + 11);
                            if(i2 != 0 && ai2[i2] > 100)
                                ai2[i2] = 100;
                            if(ai2[i2] < 0)
                                ai2[i2] = 0;
                        }

                        enginsignature[l] = getvalue("physics", s2, 14);
                        if(enginsignature[l] > 4)
                            enginsignature[l] = 0;
                        if(enginsignature[l] < 0)
                            enginsignature[l] = 0;
                        f = getvalue("physics", s2, 15);
                        if(f > 0.0F)
                            flag1 = true;
                    }
                    catch(Exception exception2)
                    {
                        flag1 = false;
                    }
                if(s2.startsWith("handling("))
                    try
                    {
                        int j2 = getvalue("handling", s2, 0);
                        if(j2 > 200)
                            j2 = 200;
                        if(j2 < 50)
                            j2 = 50;
                        dishandle[l] = (float)j2 / 200F;
                    }
                    catch(Exception exception3) { }
                if(s2.startsWith("carmaker("))
                    createdby[l - 16] = getSvalue("carmaker", s2, 0);
                if(s2.startsWith("publish("))
                    publish[l - 16] = getvalue("publish", s2, 0);
            } while(true);
            datainputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Loading Car Stat: ").append(exception).toString());
        }
        if(flag && flag1)
        {
            int j1 = 0;
            if(i1 > 680)
                j1 = 680 - i1;
            if(i1 > 640 && i1 < 680)
                j1 = 640 - i1;
            if(i1 > 600 && i1 < 640)
                j1 = 600 - i1;
            if(i1 > 560 && i1 < 600)
                j1 = 560 - i1;
            if(i1 > 520 && i1 < 560)
                j1 = 520 - i1;
            if(i1 < 520)
                j1 = 520 - i1;
            while(j1 != 0) 
            {
                int k2 = 0;
                while(k2 < 5) 
                {
                    if(j1 > 0 && ai[k2] < 200)
                    {
                        ai[k2]++;
                        j1--;
                    }
                    if(j1 < 0 && ai[k2] > 16)
                    {
                        ai[k2]--;
                        j1++;
                    }
                    k2++;
                }
            }
            i1 = 0;
            for(int l2 = 0; l2 < 5; l2++)
                i1 += ai[l2];

            if(i1 == 520)
                cclass[l] = 0;
            if(i1 == 560)
                cclass[l] = 1;
            if(i1 == 600)
                cclass[l] = 2;
            if(i1 == 640)
                cclass[l] = 3;
            if(i1 == 680)
                cclass[l] = 4;
            byte byte0 = 0;
            byte byte1 = 0;
            float f1 = 0.5F;
            if(ai[0] == 200)
            {
                byte0 = 1;
                byte1 = 1;
            }
            if(ai[0] > 192 && ai[0] < 200)
            {
                byte0 = 12;
                byte1 = 1;
                f1 = (float)(ai[0] - 192) / 8F;
            }
            if(ai[0] == 192)
            {
                byte0 = 12;
                byte1 = 12;
            }
            if(ai[0] > 148 && ai[0] < 192)
            {
                byte0 = 14;
                byte1 = 12;
                f1 = (float)(ai[0] - 148) / 44F;
            }
            if(ai[0] == 148)
            {
                byte0 = 14;
                byte1 = 14;
            }
            if(ai[0] > 133 && ai[0] < 148)
            {
                byte0 = 10;
                byte1 = 14;
                f1 = (float)(ai[0] - 133) / 15F;
            }
            if(ai[0] == 133)
            {
                byte0 = 10;
                byte1 = 10;
            }
            if(ai[0] > 112 && ai[0] < 133)
            {
                byte0 = 15;
                byte1 = 10;
                f1 = (float)(ai[0] - 112) / 21F;
            }
            if(ai[0] == 112)
            {
                byte0 = 15;
                byte1 = 15;
            }
            if(ai[0] > 107 && ai[0] < 112)
            {
                byte0 = 11;
                byte1 = 15;
                f1 = (float)(ai[0] - 107) / 5F;
            }
            if(ai[0] == 107)
            {
                byte0 = 11;
                byte1 = 11;
            }
            if(ai[0] > 88 && ai[0] < 107)
            {
                byte0 = 13;
                byte1 = 11;
                f1 = (float)(ai[0] - 88) / 19F;
            }
            if(ai[0] == 88)
            {
                byte0 = 13;
                byte1 = 13;
            }
            if(ai[0] > 88)
            {
                swits[l][0] = (int)((float)(swits[byte1][0] - swits[byte0][0]) * f1 + (float)swits[byte0][0]);
                swits[l][1] = (int)((float)(swits[byte1][1] - swits[byte0][1]) * f1 + (float)swits[byte0][1]);
                swits[l][2] = (int)((float)(swits[byte1][2] - swits[byte0][2]) * f1 + (float)swits[byte0][2]);
            } else
            {
                f1 = (float)ai[0] / 88F;
                if((double)f1 < 0.76000000000000001D)
                    f1 = 0.76F;
                swits[l][0] = (int)(50F * f1);
                swits[l][1] = (int)(130F * f1);
                swits[l][2] = (int)(210F * f1);
            }
            byte0 = 0;
            byte1 = 0;
            f1 = 0.5F;
            if(ai[1] == 200)
            {
                byte0 = 1;
                byte1 = 1;
            }
            if(ai[1] > 150 && ai[1] < 200)
            {
                byte0 = 14;
                byte1 = 1;
                f1 = (float)(ai[1] - 150) / 50F;
            }
            if(ai[1] == 150)
            {
                byte0 = 14;
                byte1 = 14;
            }
            if(ai[1] > 144 && ai[1] < 150)
            {
                byte0 = 9;
                byte1 = 14;
                f1 = (float)(ai[1] - 144) / 6F;
            }
            if(ai[1] == 144)
            {
                byte0 = 9;
                byte1 = 9;
            }
            if(ai[1] > 139 && ai[1] < 144)
            {
                byte0 = 6;
                byte1 = 9;
                f1 = (float)(ai[1] - 139) / 5F;
            }
            if(ai[1] == 139)
            {
                byte0 = 6;
                byte1 = 6;
            }
            if(ai[1] > 128 && ai[1] < 139)
            {
                byte0 = 15;
                byte1 = 6;
                f1 = (float)(ai[1] - 128) / 11F;
            }
            if(ai[1] == 128)
            {
                byte0 = 15;
                byte1 = 15;
            }
            if(ai[1] > 122 && ai[1] < 128)
            {
                byte0 = 10;
                byte1 = 15;
                f1 = (float)(ai[1] - 122) / 6F;
            }
            if(ai[1] == 122)
            {
                byte0 = 10;
                byte1 = 10;
            }
            if(ai[1] > 119 && ai[1] < 122)
            {
                byte0 = 3;
                byte1 = 10;
                f1 = (float)(ai[1] - 119) / 3F;
            }
            if(ai[1] == 119)
            {
                byte0 = 3;
                byte1 = 3;
            }
            if(ai[1] > 98 && ai[1] < 119)
            {
                byte0 = 5;
                byte1 = 3;
                f1 = (float)(ai[1] - 98) / 21F;
            }
            if(ai[1] == 98)
            {
                byte0 = 5;
                byte1 = 5;
            }
            if(ai[1] > 81 && ai[1] < 98)
            {
                byte0 = 0;
                byte1 = 5;
                f1 = (float)(ai[1] - 81) / 17F;
            }
            if(ai[1] == 81)
            {
                byte0 = 0;
                byte1 = 0;
            }
            if(ai[1] <= 80)
            {
                byte0 = 2;
                byte1 = 2;
            }
            if(ai[0] <= 88)
            {
                byte0 = 13;
                byte1 = 13;
            }
            acelf[l][0] = (acelf[byte1][0] - acelf[byte0][0]) * f1 + acelf[byte0][0];
            acelf[l][1] = (acelf[byte1][1] - acelf[byte0][1]) * f1 + acelf[byte0][1];
            acelf[l][2] = (acelf[byte1][2] - acelf[byte0][2]) * f1 + acelf[byte0][2];
            if(ai[1] <= 70 && ai[0] > 88)
            {
                acelf[l][0] = 9F;
                acelf[l][1] = 4F;
                acelf[l][2] = 3F;
            }
            f1 = (float)(ai[2] - 88) / 109F;
            if(f1 > 1.0F)
                f1 = 1.0F;
            if((double)f1 < -0.55000000000000004D)
                f1 = -0.55F;
            airs[l] = 0.55F + 0.45F * f1 + 0.4F * ((float)ai1[9] / 100F);
            if((double)airs[l] < 0.29999999999999999D)
                airs[l] = 0.3F;
            airc[l] = (int)(10F + 70F * f1 + 30F * ((float)ai1[10] / 100F));
            if(airc[l] < 0)
                airc[l] = 0;
            int i3 = (int)(670F - ((float)(ai1[9] + ai1[10]) / 200F) * 420F);
            if(ai[0] <= 88)
                i3 = (int)(1670F - ((float)(ai1[9] + ai1[10]) / 200F) * 1420F);
            if(ai[2] > 190 && i3 < 300)
                i3 = 300;
            powerloss[l] = i3 * 10000;
            moment[l] = 0.7F + ((float)(ai[3] - 16) / 184F) * 1.0F;
            if(ai[0] < 110)
                moment[l] = 0.75F + ((float)(ai[3] - 16) / 184F) * 1.25F;
            if(ai[3] == 200 && ai[4] == 200 && ai[0] <= 88)
                moment[l] = 3F;
            float f2 = 0.9F + (float)(ai[4] - 90) * 0.01F;
            if((double)f2 < 0.59999999999999998D)
                f2 = 0.6F;
            if(ai[4] == 200 && ai[0] <= 88)
                f2 = 3F;
            maxmag[l] = (int)(f * f2);
            outdam[l] = 0.35F + (f2 - 0.6F) * 0.5F;
            if((double)outdam[l] < 0.34999999999999998D)
                outdam[l] = 0.35F;
            if(outdam[l] > 1.0F)
                outdam[l] = 1.0F;
            clrad[l] = (int)((double)(ai2[0] * ai2[0]) * 1.5D);
            if(clrad[l] < 1000)
                clrad[l] = 1000;
            dammult[l] = 0.3F + (float)ai2[1] * 0.005F;
            msquash[l] = (int)(2D + (double)(float)ai2[2] / 7.5999999999999996D);
            flipy[l] = j;
            handb[l] = (int)(7F + ((float)ai1[0] / 100F) * 8F);
            turn[l] = (int)(4F + ((float)ai1[1] / 100F) * 6F);
            grip[l] = 16F + ((float)ai1[2] / 100F) * 14F;
            if(grip[l] < 21F)
            {
                swits[l][0] += 40F * ((21F - grip[l]) / 5F);
                if(swits[l][0] > 100)
                    swits[l][0] = 100;
            }
            bounce[l] = 0.8F + ((float)ai1[3] / 100F) * 0.6F;
            if(ai1[3] > 67)
            {
                airs[l] *= 0.76F + (1.0F - (float)ai1[3] / 100F) * 0.24F;
                airc[l] *= 0.76F + (1.0F - (float)ai1[3] / 100F) * 0.24F;
            }
            lift[l] = (int)((((float)ai1[5] * (float)ai1[5]) / 10000F) * 30F);
            revlift[l] = (int)(((float)ai1[6] / 100F) * 32F);
            push[l] = (int)(2.0F + ((float)ai1[7] / 100F) * 2.0F * (float)((30 - lift[l]) / 30));
            revpush[l] = (int)(1.0F + ((float)ai1[8] / 100F) * 2.0F);
            comprad[l] = (float)i / 400F + ((float)(ai[3] - 16) / 184F) * 0.2F;
            if((double)comprad[l] < 0.40000000000000002D)
                comprad[l] = 0.4F;
            simag[l] = (float)(k - 17) * 0.0167F + 0.85F;
        } else
        {
            names[l] = "";
        }
    }

    public int getvalue(String s, String s1, int i)
    {
        int k = 0;
        String s3 = "";
        for(int j = s.length() + 1; j < s1.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s1.charAt(j)).toString();
            if(s2.equals(",") || s2.equals(")"))
            {
                k++;
                j++;
            }
            if(k == i)
                s3 = (new StringBuilder()).append(s3).append(s1.charAt(j)).toString();
        }

        return Float.valueOf(s3).intValue();
    }

    public String getSvalue(String s, String s1, int i)
    {
        String s2 = "";
        int j = 0;
        for(int k = s.length() + 1; k < s1.length() && j <= i; k++)
        {
            String s3 = (new StringBuilder()).append("").append(s1.charAt(k)).toString();
            if(s3.equals(",") || s3.equals(")"))
            {
                j++;
                continue;
            }
            if(j == i)
                s2 = (new StringBuilder()).append(s2).append(s3).toString();
        }

        return s2;
    }

    public int servervalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals("|"))
                {
                    l++;
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String serverSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals("|"))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    public void loadready()
    {
        m.csky[0] = 170;
        m.csky[1] = 220;
        m.csky[2] = 255;
        m.cfade[0] = 255;
        m.cfade[1] = 220;
        m.cfade[2] = 220;
        m.snap[0] = 0;
        m.snap[1] = 0;
        m.snap[2] = 0;
        fails = "";
        for(int i = 0; i < 20; i++)
            loadnames[i] = "";

        nl = 0;
        action = 0;
    }

    public void sparkactionloader()
    {
        actionloader = new Thread(this);
        actionloader.start();
    }

    public void sparkcarloader()
    {
        if(!carlon)
        {
            carloader = new Thread(this);
            carloader.start();
            carlon = true;
        }
    }

    public void sparkstageaction()
    {
        stageaction = new Thread(this);
        stageaction.start();
    }

    public void stopallnow()
    {
        staction = 0;
        action = 0;
        if(carloader != null)
        {
            carloader.stop();
            carloader = null;
        }
        if(actionloader != null)
        {
            actionloader.stop();
            actionloader = null;
        }
        if(stageaction != null)
        {
            stageaction.stop();
            stageaction = null;
        }
    }

    public void run()
    {
        if(Thread.currentThread() == actionloader)
        {
            if(action == 10)
            {
                int i = -1;
                try
                {
                    Socket socket2 = new Socket("multiplayer.needformadness.com", 7061);
                    BufferedReader bufferedreader2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
                    PrintWriter printwriter2 = new PrintWriter(socket2.getOutputStream(), true);
                    printwriter2.println((new StringBuilder()).append("9|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(names[ac]).append("|").toString());
                    String s11 = bufferedreader2.readLine();
                    if(s11 != null)
                        i = servervalue(s11, 0);
                    socket2.close();
                    bufferedreader2.close();
                    printwriter2.close();
                }
                catch(Exception exception2)
                {
                    i = -1;
                }
                if(i == 0)
                    action = 3;
                else
                    action = -10;
                System.gc();
            }
            if(action == 1)
            {
                reco = -1;
                try
                {
                    Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                    BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                    printwriter.println((new StringBuilder()).append("1|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").toString());
                    String s8 = bufferedreader.readLine();
                    if(s8 != null)
                    {
                        reco = servervalue(s8, 0);
                        if(reco == 0 || reco == 3 || reco > 10)
                        {
                            tnickey = serverSvalue(s8, 1);
                            if(reco != -167)
                            {
                                tclan = serverSvalue(s8, 2);
                                tclankey = serverSvalue(s8, 3);
                            } else
                            {
                                tclan = "";
                                tclankey = "";
                            }
                        }
                    }
                    socket.close();
                    bufferedreader.close();
                    printwriter.close();
                }
                catch(Exception exception)
                {
                    reco = -1;
                }
                if(reco == 0 || reco == 3 || reco > 10)
                    action = 2;
                else
                    action = 0;
                System.gc();
            }
            while(action == 2) ;
            if(action == 3)
            {
                String as[] = new String[700];
                nl = 0;
                String s4 = "";
                try
                {
                    URL url1 = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                    DataInputStream datainputstream1 = new DataInputStream(url1.openStream());
                    do
                    {
                        String s5;
                        if((s5 = datainputstream1.readLine()) == null)
                            break;
                        s5 = (new StringBuilder()).append("").append(s5.trim()).toString();
                        if(s5.startsWith("mycars"))
                        {
                            boolean flag1 = true;
                            while(flag1 && nl < 700) 
                            {
                                as[nl] = getSvalue("mycars", s5, nl);
                                if(as[nl].equals(""))
                                    flag1 = false;
                                else
                                    nl++;
                            }
                        }
                    } while(true);
                    if(nl > 0)
                        action = 4;
                    else
                        action = -1;
                    datainputstream1.close();
                }
                catch(Exception exception9)
                {
                    String s9 = (new StringBuilder()).append("").append(exception9).toString();
                    if(s9.indexOf("FileNotFound") != -1)
                        action = -1;
                    else
                        action = -2;
                }
                if(action == 4)
                {
                    gs.mcars.hide();
                    gs.mcars.removeAll();
                    for(int l2 = 0; l2 < nl; l2++)
                        gs.mcars.add(gs.rd, as[l2]);

                    if(lastcar.equals(""))
                    {
                        gs.mcars.select(0);
                    } else
                    {
                        gs.mcars.select(lastcar);
                        lastcar = "";
                    }
                    for(int i3 = 0; i3 < 40; i3++)
                        include[i3] = false;

                    roundslot = 16;
                    nlocars = 16;
                }
            }
            if(action == 4)
            {
                m.csky[0] = 170;
                m.csky[1] = 220;
                m.csky[2] = 255;
                m.cfade[0] = 255;
                m.cfade[1] = 220;
                m.cfade[2] = 220;
                m.snap[0] = 0;
                m.snap[1] = 0;
                m.snap[2] = 0;
                if(loadonlinecar(gs.mcars.getSelectedItem(), roundslot) == roundslot)
                {
                    inslot = roundslot;
                    roundslot++;
                    if(roundslot == 36)
                        roundslot = 16;
                    if(nlocars < 36)
                        nlocars++;
                    lastload = 2;
                    action = 5;
                } else
                {
                    if(lastload == 2)
                        lastload = 0;
                    action = -1;
                }
                System.gc();
            }
            if(action == 6)
            {
                int j = -1;
                try
                {
                    if(ac != -1)
                        acname = names[ac];
                    Socket socket3 = new Socket("multiplayer.needformadness.com", 7061);
                    BufferedReader bufferedreader3 = new BufferedReader(new InputStreamReader(socket3.getInputStream()));
                    PrintWriter printwriter3 = new PrintWriter(socket3.getOutputStream(), true);
                    printwriter3.println((new StringBuilder()).append("8|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(acname).append("|").toString());
                    String s12 = bufferedreader3.readLine();
                    if(s12 != null)
                        j = servervalue(s12, 0);
                    socket3.close();
                    bufferedreader3.close();
                    printwriter3.close();
                }
                catch(Exception exception3)
                {
                    j = -1;
                }
                if(j == 0)
                {
                    if(lastload == 2)
                    {
                        lastload = -2;
                        lastcar = gs.mcars.getSelectedItem();
                    }
                    action = 7;
                }
                if(j == 3)
                    action = -7;
                if(j == 4)
                    action = -8;
                if(action == 6)
                    action = -9;
                System.gc();
            }
            if(action == 11)
            {
                nl = 0;
                String s = "";
                try
                {
                    String s6 = "all";
                    if(loadlist == 1)
                        s6 = "Wall";
                    if(loadlist == 2)
                        s6 = "WA";
                    if(loadlist == 3)
                        s6 = "WAB";
                    if(loadlist == 4)
                        s6 = "WB";
                    if(loadlist == 5)
                        s6 = "WBC";
                    if(loadlist == 6)
                        s6 = "WC";
                    if(loadlist == 7)
                        s6 = "Mall";
                    if(loadlist == 8)
                        s6 = "MA";
                    if(loadlist == 9)
                        s6 = "MAB";
                    if(loadlist == 10)
                        s6 = "MB";
                    if(loadlist == 11)
                        s6 = "MBC";
                    if(loadlist == 12)
                        s6 = "MC";
                    if(loadlist == 13)
                        s6 = "Sall";
                    if(loadlist == 14)
                        s6 = "SA";
                    if(loadlist == 15)
                        s6 = "SAB";
                    if(loadlist == 16)
                        s6 = "SB";
                    if(loadlist == 17)
                        s6 = "SBC";
                    if(loadlist == 18)
                        s6 = "SC";
                    if(loadlist == 19)
                        s6 = "Aall";
                    if(loadlist == 20)
                        s6 = "AA";
                    if(loadlist == 21)
                        s6 = "AAB";
                    if(loadlist == 22)
                        s6 = "AB";
                    if(loadlist == 23)
                        s6 = "ABC";
                    if(loadlist == 24)
                        s6 = "AC";
                    URL url2 = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/top20/").append(s6).append(".txt").toString());
                    DataInputStream datainputstream2 = new DataInputStream(url2.openStream());
                    do
                    {
                        String s1;
                        if((s1 = datainputstream2.readLine()) == null)
                            break;
                        s1 = (new StringBuilder()).append("").append(s1.trim()).toString();
                        if(s1.startsWith("cars"))
                        {
                            for(boolean flag2 = true; flag2 && nl < 20;)
                            {
                                loadnames[nl] = getSvalue("cars", s1, nl);
                                if(loadnames[nl].equals(""))
                                    flag2 = false;
                                else
                                    nl++;
                            }

                        }
                        if(s1.startsWith("adds"))
                        {
                            int l3 = 0;
                            while(l3 < nl) 
                            {
                                adds[l3] = getvalue("adds", s1, l3);
                                l3++;
                            }
                        }
                    } while(true);
                    if(nl > 0)
                        action = 12;
                    else
                        action = -1;
                    datainputstream2.close();
                }
                catch(Exception exception4)
                {
                    action = -1;
                }
                System.gc();
            }
            if(action == 12)
            {
                m.csky[0] = 170;
                m.csky[1] = 220;
                m.csky[2] = 255;
                m.cfade[0] = 255;
                m.cfade[1] = 220;
                m.cfade[2] = 220;
                m.snap[0] = 0;
                m.snap[1] = 0;
                m.snap[2] = 0;
                xnlocars = 36;
                int k = nl;
                for(nl = 0; nl < k; nl++)
                    if(xnlocars < 56 && loadonlinecar(loadnames[nl], xnlocars) == xnlocars)
                        xnlocars++;

                nl = 0;
                if(xnlocars > 36)
                    action = 13;
                else
                    action = -1;
                System.gc();
            }
            if(action == 101)
            {
                nl = 0;
                String s2 = "";
                try
                {
                    URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/lists/").append(viewname).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                    DataInputStream datainputstream = new DataInputStream(url.openStream());
                    do
                    {
                        String s3;
                        if((s3 = datainputstream.readLine()) == null)
                            break;
                        s3 = (new StringBuilder()).append("").append(s3.trim()).toString();
                        if(s3.startsWith("mycars"))
                        {
                            boolean flag = true;
                            while(flag && nl < 20) 
                            {
                                loadnames[nl] = getSvalue("mycars", s3, nl);
                                if(loadnames[nl].equals(""))
                                    flag = false;
                                else
                                    nl++;
                            }
                        }
                    } while(true);
                    if(nl > 0)
                        action = 102;
                    else
                        action = -2;
                    datainputstream.close();
                }
                catch(Exception exception5)
                {
                    String s7 = (new StringBuilder()).append("").append(exception5).toString();
                    if(s7.indexOf("FileNotFound") != -1)
                        action = -2;
                    else
                        action = -1;
                }
                System.gc();
            }
            if(action == 102)
            {
                m.csky[0] = 170;
                m.csky[1] = 220;
                m.csky[2] = 255;
                m.cfade[0] = 255;
                m.cfade[1] = 220;
                m.cfade[2] = 220;
                m.snap[0] = 0;
                m.snap[1] = 0;
                m.snap[2] = 0;
                for(int l = 0; l < 40; l++)
                    include[l] = false;

                xnlocars = 36;
                int i1 = nl;
                for(nl = 0; nl < i1; nl++)
                    if(xnlocars < 56 && loadonlinecar(loadnames[nl], xnlocars) == xnlocars)
                        xnlocars++;

                nl = 0;
                if(xnlocars > 36)
                    action = 103;
                else
                    action = -1;
                System.gc();
            }
            actionloader = null;
        }
        if(Thread.currentThread() != carloader)
            break MISSING_BLOCK_LABEL_3057;
_L2:
        int j1;
        if(nl <= 0)
            break; /* Loop/switch isn't completed */
        j1 = 0;
        for(int i2 = 16; i2 < 56; i2++)
            if(loadnames[nl - 1].equals(names[i2]))
                j1 = -1;

        if(fails.indexOf((new StringBuilder()).append("|").append(loadnames[nl - 1]).append("|").toString()) != -1)
            j1 = -1;
        if(j1 == -1)
            break MISSING_BLOCK_LABEL_3019;
        int j2 = lcardate[0];
        int j3 = 36;
        if(haltload > 0)
        {
            j3 = 36 + haltload;
            j2 = lcardate[haltload];
        }
        j1 = j3;
        for(int k3 = j3; k3 < 56; k3++)
            if(lcardate[k3 - 36] < j2)
            {
                j2 = lcardate[k3 - 36];
                j1 = k3;
            }

        onloadingcar = j1 - 35;
        if(loadonlinecar(loadnames[nl - 1], j1) != -1)
            break MISSING_BLOCK_LABEL_3001;
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        fails;
        append();
        "|";
        append();
        loadnames[nl - 1];
        append();
        "|";
        append();
        toString();
        fails;
        break MISSING_BLOCK_LABEL_3014;
        lcardate[j1 - 36]++;
        onloadingcar = 0;
        nl--;
        try
        {
            carloader;
            Thread.sleep(20L);
        }
        catch(InterruptedException interruptedexception) { }
        if(true) goto _L2; else goto _L1
_L1:
        carlon = false;
        carloader = null;
        if(Thread.currentThread() == stageaction)
        {
            if(staction == 1)
            {
                int k1 = -1;
                try
                {
                    Socket socket4 = new Socket("multiplayer.needformadness.com", 7061);
                    BufferedReader bufferedreader4 = new BufferedReader(new InputStreamReader(socket4.getInputStream()));
                    PrintWriter printwriter4 = new PrintWriter(socket4.getOutputStream(), true);
                    printwriter4.println((new StringBuilder()).append("19|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(onstage).append("|").toString());
                    String s13 = bufferedreader4.readLine();
                    if(s13 != null)
                        k1 = servervalue(s13, 0);
                    socket4.close();
                    bufferedreader4.close();
                    printwriter4.close();
                }
                catch(Exception exception6)
                {
                    k1 = -1;
                }
                if(k1 == 0)
                {
                    try
                    {
                        gs.mstgs.remove(onstage);
                    }
                    catch(Exception exception7) { }
                    gs.mstgs.select(0);
                    staction = 0;
                } else
                {
                    staction = -1;
                }
            }
            if(staction == 4)
            {
                reco = -1;
                try
                {
                    Socket socket1 = new Socket("multiplayer.needformadness.com", 7061);
                    BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
                    PrintWriter printwriter1 = new PrintWriter(socket1.getOutputStream(), true);
                    printwriter1.println((new StringBuilder()).append("1|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").toString());
                    String s10 = bufferedreader1.readLine();
                    if(s10 != null)
                    {
                        reco = servervalue(s10, 0);
                        if(reco == 0 || reco == 3 || reco > 10)
                        {
                            tnickey = serverSvalue(s10, 1);
                            if(reco != -167)
                            {
                                tclan = serverSvalue(s10, 2);
                                tclankey = serverSvalue(s10, 3);
                            } else
                            {
                                tclan = "";
                                tclankey = "";
                            }
                        }
                    }
                    socket1.close();
                    bufferedreader1.close();
                    printwriter1.close();
                }
                catch(Exception exception1)
                {
                    reco = -1;
                }
                if(reco == 0 || reco == 3 || reco > 10)
                    staction = 5;
                else
                    staction = 3;
                System.gc();
                while(staction == 5) ;
            }
            if(staction == 2)
            {
                int l1 = -1;
                if(msloaded == 1)
                {
                    for(int k2 = 1; k2 < gs.mstgs.getItemCount(); k2++)
                        if(gs.mstgs.getItem(k2).equals(onstage))
                            l1 = 3;

                }
                if(l1 == -1)
                    try
                    {
                        Socket socket5 = new Socket("multiplayer.needformadness.com", 7061);
                        BufferedReader bufferedreader5 = new BufferedReader(new InputStreamReader(socket5.getInputStream()));
                        PrintWriter printwriter5 = new PrintWriter(socket5.getOutputStream(), true);
                        printwriter5.println((new StringBuilder()).append("18|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(onstage).append("|").toString());
                        String s14 = bufferedreader5.readLine();
                        if(s14 != null)
                            l1 = servervalue(s14, 0);
                        socket5.close();
                        bufferedreader5.close();
                        printwriter5.close();
                    }
                    catch(Exception exception8)
                    {
                        l1 = -1;
                    }
                staction = -1;
                if(l1 == 0)
                {
                    staction = 0;
                    if(msloaded == 1)
                        gs.mstgs.addstg(onstage);
                }
                if(l1 == 3)
                    staction = -2;
                if(l1 == 4)
                    staction = -3;
            }
            stageaction = null;
        }
        return;
    }

    public int loadonlinecar(String s, int i)
    {
        try
        {
            String s1 = (new StringBuilder()).append("http://multiplayer.needformadness.com/cars/").append(s).append(".radq").toString();
            s1 = s1.replace(' ', '_');
            URL url = new URL(s1);
            int j = url.openConnection().getContentLength();
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            byte abyte0[] = new byte[j];
            datainputstream.readFully(abyte0);
            ZipInputStream zipinputstream;
            if(abyte0[0] == 80 && abyte0[1] == 75 && abyte0[2] == 3)
            {
                zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte0));
            } else
            {
                byte abyte1[] = new byte[j - 40];
                for(int k = 0; k < j - 40; k++)
                {
                    byte byte0 = 20;
                    if(k >= 500)
                        byte0 = 40;
                    abyte1[k] = abyte0[k + byte0];
                }

                zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte1));
            }
            ZipEntry zipentry = zipinputstream.getNextEntry();
            if(zipentry != null)
            {
                int l = Integer.valueOf(zipentry.getName()).intValue();
                byte abyte2[] = new byte[l];
                int i1 = 0;
                int j1;
                for(; l > 0; l -= j1)
                {
                    j1 = zipinputstream.read(abyte2, i1, l);
                    i1 += j1;
                }

                m.loadnew = true;
                bco[i] = new ContO(abyte2, m, t);
                if(bco[i].errd || bco[i].npl <= 60 || bco[i].maxR < 120)
                    i = -1;
                if(i != -1)
                {
                    bco[i].shadow = true;
                    bco[i].noline = false;
                    bco[i].decor = false;
                    bco[i].tnt = 0;
                    bco[i].disp = 0;
                    bco[i].disline = 7;
                    bco[i].grounded = 1.0F;
                    boolean flag = true;
                    if(bco[i].keyz[0] < 0 || bco[i].keyx[0] > 0)
                        flag = false;
                    if(bco[i].keyz[1] < 0 || bco[i].keyx[1] < 0)
                        flag = false;
                    if(bco[i].keyz[2] > 0 || bco[i].keyx[2] > 0)
                        flag = false;
                    if(bco[i].keyz[3] > 0 || bco[i].keyx[3] < 0)
                        flag = false;
                    if(!flag)
                        i = -1;
                }
                if(i != -1)
                {
                    loadstat(abyte2, s, bco[i].maxR, bco[i].roofat, bco[i].wh, i);
                    if(names[i].equals(""))
                        i = -1;
                }
                m.loadnew = false;
                datainputstream.close();
                zipinputstream.close();
            } else
            {
                i = -1;
            }
        }
        catch(Exception exception)
        {
            i = -1;
        }
        System.gc();
        return i;
    }

    public void loadmystages(CheckPoints checkpoints)
    {
        String as[] = new String[700];
        int i = 0;
        String s = "";
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            do
            {
                String s1;
                if((s1 = datainputstream.readLine()) == null)
                    break;
                s1 = (new StringBuilder()).append("").append(s1.trim()).toString();
                if(s1.startsWith("mystages"))
                {
                    boolean flag = true;
                    while(flag && i < 700) 
                    {
                        as[i] = getSvalue("mystages", s1, i);
                        if(as[i].equals(""))
                            flag = false;
                        else
                            i++;
                    }
                }
            } while(true);
            if(i > 0)
                msloaded = 1;
            else
                msloaded = -2;
            datainputstream.close();
        }
        catch(Exception exception)
        {
            String s2 = (new StringBuilder()).append("").append(exception).toString();
            if(s2.indexOf("FileNotFound") != -1)
                msloaded = -2;
            else
                msloaded = -1;
        }
        if(msloaded == 1)
        {
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "Select Stage");
            int j = 0;
            for(int k = 0; k < i; k++)
            {
                gs.mstgs.add(gs.rd, as[k]);
                if(checkpoints.name.equals(as[k]))
                {
                    j = k + 1;
                    checkpoints.top20 = 0;
                }
            }

            gs.mstgs.select(j);
            gs.mstgs.show();
        }
        if(msloaded == -2)
        {
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "You have not published or added any stages...");
            gs.mstgs.select(0);
            gs.mstgs.show();
        }
        if(msloaded == -1)
        {
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "Failed to load stages, please try again later.");
            gs.mstgs.select(0);
            gs.mstgs.show();
        }
        System.gc();
    }

    public void loadtop20(int i)
    {
        String as[] = new String[20];
        int j = 0;
        String s = "";
        try
        {
            String s2 = "A";
            if(i == 3)
                s2 = "W";
            if(i == 4)
                s2 = "M";
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/top20/").append(s2).append(".txt").toString());
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            do
            {
                String s1;
                if((s1 = datainputstream.readLine()) == null)
                    break;
                s1 = (new StringBuilder()).append("").append(s1.trim()).toString();
                if(s1.startsWith("stages"))
                {
                    for(boolean flag = true; flag && j < 20;)
                    {
                        as[j] = getSvalue("stages", s1, j);
                        if(as[j].equals(""))
                            flag = false;
                        else
                            j++;
                    }

                }
                if(s1.startsWith("adds"))
                {
                    int l = 0;
                    while(l < j) 
                    {
                        top20adds[l] = getvalue("adds", s1, l);
                        l++;
                    }
                }
            } while(true);
            if(j > 0)
                msloaded = i;
            else
                msloaded = -2;
            datainputstream.close();
        }
        catch(Exception exception)
        {
            String s3 = (new StringBuilder()).append("").append(exception).toString();
            if(s3.indexOf("FileNotFound") != -1)
                msloaded = -2;
            else
                msloaded = -1;
        }
        if(msloaded == i)
        {
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "Select Stage");
            for(int k = 0; k < j; k++)
                gs.mstgs.add(gs.rd, (new StringBuilder()).append("N#").append(k + 1).append(" ").append(as[k]).toString());

            gs.mstgs.select(0);
            gs.mstgs.show();
        }
        if(msloaded == -1 || msloaded == -2)
        {
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "Failed to load Top20 list, please try again later.");
            gs.mstgs.select(0);
            gs.mstgs.show();
        }
        System.gc();
    }

    public void loadclanstages(String s)
    {
        if(!s.equals(""))
        {
            String as[] = new String[700];
            int i = 0;
            String s1 = "";
            try
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(s).append("/stages.txt").toString());
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String s2;
                for(; (s2 = datainputstream.readLine()) != null && i < 700; i++)
                    as[i] = s2;

                if(i > 0)
                    msloaded = 7;
                else
                    msloaded = -2;
                datainputstream.close();
            }
            catch(Exception exception)
            {
                String s3 = (new StringBuilder()).append("").append(exception).toString();
                if(s3.indexOf("FileNotFound") != -1)
                    msloaded = -2;
                else
                    msloaded = -1;
            }
            if(msloaded == 7)
            {
                gs.mstgs.hide();
                gs.mstgs.removeAll();
                gs.mstgs.add(gs.rd, "Select Stage");
                for(int j = 0; j < i; j++)
                    gs.mstgs.add(gs.rd, as[j]);

                gs.mstgs.select(0);
                gs.mstgs.show();
            }
            if(msloaded == -1)
            {
                gs.mstgs.hide();
                gs.mstgs.removeAll();
                gs.mstgs.add(gs.rd, "Failed to load clan stages, please try again later.");
                gs.mstgs.select(0);
                gs.mstgs.show();
            }
            if(msloaded == -2)
            {
                gs.mstgs.hide();
                gs.mstgs.removeAll();
                gs.mstgs.add(gs.rd, "No stages have been added to your clan yet.");
                gs.mstgs.select(0);
                gs.mstgs.show();
            }
            System.gc();
        } else
        {
            msloaded = -2;
            gs.mstgs.hide();
            gs.mstgs.removeAll();
            gs.mstgs.add(gs.rd, "You are not a member of any clan yet.");
            gs.mstgs.select(0);
            gs.mstgs.show();
        }
    }

    public void loadstagemaker()
    {
        gs.mstgs.hide();
        gs.mstgs.removeAll();
        gs.mstgs.add(gs.rd, "Select Stage");
        int i = 0;
        File file = new File("mystages/");
        if(file.exists())
        {
            String as[] = (new File("mystages/")).list();
            for(int j = 0; j < as.length; j++)
                if(as[j].toLowerCase().endsWith(".txt") && i < 200)
                {
                    gs.mstgs.add(gs.rd, as[j].substring(0, as[j].length() - 4));
                    i++;
                }

        }
        if(i != 0)
        {
            msloaded = 2;
        } else
        {
            gs.mstgs.add(gs.rd, "No stages where found in your 'mystages' folder.");
            msloaded = -1;
        }
        gs.mstgs.select(0);
        gs.mstgs.show();
    }

    public void loadcarmaker()
    {
        m.csky[0] = 170;
        m.csky[1] = 220;
        m.csky[2] = 255;
        m.cfade[0] = 255;
        m.cfade[1] = 220;
        m.cfade[2] = 220;
        m.snap[0] = 0;
        m.snap[1] = 0;
        m.snap[2] = 0;
        for(int i = 0; i < 40; i++)
            include[i] = false;

        nlcars = 16;
        File file = new File("mycars/");
        if(file.exists())
        {
            String as[] = (new File("mycars/")).list();
            for(int j = 0; j < as.length; j++)
                if(as[j].toLowerCase().endsWith(".rad") && nlcars < 56 && loadcar(as[j].substring(0, as[j].length() - 4), nlcars) == nlcars)
                    nlcars++;

        }
        System.gc();
        if(nlcars > 16)
            lastload = 1;
    }

    public int loadcar(String s, int i)
    {
        try
        {
            File file = new File((new StringBuilder()).append("mycars/").append(s).append(".rad").toString());
            if(file.exists())
            {
                String s1 = "";
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                for(String s2 = null; (s2 = bufferedreader.readLine()) != null;)
                    s1 = (new StringBuilder()).append(s1).append("").append(s2).append("\n").toString();

                bufferedreader.close();
                bufferedreader = null;
                m.loadnew = true;
                bco[i] = new ContO(s1.getBytes(), m, t);
                if(bco[i].errd || bco[i].npl <= 60)
                    i = -1;
                if(i != -1)
                {
                    bco[i].shadow = true;
                    bco[i].noline = false;
                    bco[i].decor = false;
                    bco[i].tnt = 0;
                    bco[i].disp = 0;
                    bco[i].disline = 7;
                    bco[i].grounded = 1.0F;
                    boolean flag = true;
                    if(bco[i].keyz[0] < 0 || bco[i].keyx[0] > 0)
                        flag = false;
                    if(bco[i].keyz[1] < 0 || bco[i].keyx[1] < 0)
                        flag = false;
                    if(bco[i].keyz[2] > 0 || bco[i].keyx[2] > 0)
                        flag = false;
                    if(bco[i].keyz[3] > 0 || bco[i].keyx[3] < 0)
                        flag = false;
                    if(!flag)
                        i = -1;
                }
                if(i != -1)
                {
                    loadstat(s1.getBytes(), s, bco[i].maxR, bco[i].roofat, bco[i].wh, i);
                    if(names[i].equals(""))
                        i = -1;
                }
                m.loadnew = false;
            } else
            {
                i = -1;
            }
        }
        catch(Exception exception)
        {
            i = -1;
            System.out.println((new StringBuilder()).append("Error Loading Car: ").append(exception).toString());
        }
        System.gc();
        return i;
    }

    Trackers t;
    GameSparker gs;
    ContO bco[];
    Medium m;
    Thread carloader;
    Thread actionloader;
    Thread stageaction;
    int swits[][] = {
        {
            50, 185, 282
        }, {
            100, 200, 310
        }, {
            60, 180, 275
        }, {
            76, 195, 298
        }, {
            70, 170, 275
        }, {
            70, 202, 293
        }, {
            60, 170, 289
        }, {
            70, 206, 291
        }, {
            90, 210, 295
        }, {
            90, 190, 276
        }, {
            70, 200, 295
        }, {
            50, 160, 270
        }, {
            90, 200, 305
        }, {
            50, 130, 210
        }, {
            80, 200, 300
        }, {
            70, 210, 290
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }, {
            0, 0, 0
        }
    };
    float acelf[][] = {
        {
            11F, 5F, 3F
        }, {
            14F, 7F, 5F
        }, {
            10F, 5F, 3.5F
        }, {
            11F, 6F, 3.5F
        }, {
            10F, 5F, 3.5F
        }, {
            12F, 6F, 3F
        }, {
            7F, 9F, 4F
        }, {
            11F, 5F, 3F
        }, {
            12F, 7F, 4F
        }, {
            12F, 7F, 3.5F
        }, {
            11.5F, 6.5F, 3.5F
        }, {
            9F, 5F, 3F
        }, {
            13F, 7F, 4.5F
        }, {
            7.5F, 3.5F, 3F
        }, {
            11F, 7.5F, 4F
        }, {
            12F, 6F, 3.5F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }, {
            0.0F, 0.0F, 0.0F
        }
    };
    int handb[] = {
        7, 10, 7, 15, 12, 8, 9, 10, 5, 7, 
        8, 10, 8, 12, 7, 7, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    float airs[] = {
        1.0F, 1.2F, 0.95F, 1.0F, 2.2F, 1.0F, 0.9F, 0.8F, 1.0F, 0.9F, 
        1.15F, 0.8F, 1.0F, 0.3F, 1.3F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    int airc[] = {
        70, 30, 40, 40, 30, 50, 40, 90, 40, 50, 
        75, 10, 50, 0, 100, 60, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int turn[] = {
        6, 9, 5, 7, 8, 7, 5, 5, 9, 7, 
        7, 4, 6, 5, 7, 6, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    float grip[] = {
        20F, 27F, 18F, 22F, 19F, 20F, 25F, 20F, 19F, 24F, 
        22.5F, 25F, 30F, 27F, 25F, 27F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    float bounce[] = {
        1.2F, 1.05F, 1.3F, 1.15F, 1.3F, 1.2F, 1.15F, 1.1F, 1.2F, 1.1F, 
        1.15F, 0.8F, 1.05F, 0.8F, 1.1F, 1.15F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    float simag[] = {
        0.9F, 0.85F, 1.05F, 0.9F, 0.85F, 0.9F, 1.05F, 0.9F, 1.0F, 1.05F, 
        0.9F, 1.1F, 0.9F, 1.3F, 0.9F, 1.15F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    float moment[] = {
        1.3F, 0.75F, 1.4F, 1.2F, 1.1F, 1.38F, 1.43F, 1.48F, 1.35F, 1.7F, 
        1.42F, 2.0F, 1.26F, 3F, 1.5F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    float comprad[] = {
        0.5F, 0.4F, 0.8F, 0.5F, 0.4F, 0.5F, 0.5F, 0.5F, 0.5F, 0.8F, 
        0.5F, 1.5F, 0.5F, 0.8F, 0.5F, 0.8F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    int push[] = {
        2, 2, 3, 3, 2, 2, 2, 4, 2, 2, 
        2, 4, 2, 2, 2, 2, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int revpush[] = {
        2, 3, 2, 2, 2, 2, 2, 1, 2, 1, 
        2, 1, 2, 2, 2, 1, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int lift[] = {
        0, 30, 0, 20, 0, 30, 0, 0, 20, 0, 
        0, 0, 10, 0, 30, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int revlift[] = {
        0, 0, 15, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 32, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int powerloss[] = {
        0x2625a0, 0x2625a0, 0x3567e0, 0x2625a0, 0x3d0900, 0x2625a0, 0x30d400, 0x30d400, 0x29f630, 0x53ec60, 
        0x29f630, 0x44aa20, 0x3567e0, 0xfed260, 0x2dc6c0, 0x53ec60, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int flipy[] = {
        -50, -60, -92, -44, -60, -57, -54, -60, -77, -57, 
        -82, -85, -28, -100, -63, -127, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int msquash[] = {
        7, 4, 7, 2, 8, 4, 6, 4, 3, 8, 
        4, 10, 3, 20, 3, 8, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int clrad[] = {
        3300, 1700, 4700, 3000, 2000, 4500, 3500, 5000, 10000, 15000, 
        4000, 7000, 10000, 15000, 5500, 5000, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    float dammult[] = {
        0.75F, 0.8F, 0.45F, 0.8F, 0.42F, 0.7F, 0.72F, 0.6F, 0.58F, 0.41F, 
        0.67F, 0.45F, 0.61F, 0.25F, 0.38F, 0.52F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    int maxmag[] = {
        7600, 4200, 7200, 6000, 6000, 15000, 17200, 17000, 18000, 11000, 
        19000, 10700, 13000, 45000, 5800, 18000, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    float dishandle[] = {
        0.65F, 0.6F, 0.55F, 0.77F, 0.62F, 0.9F, 0.6F, 0.72F, 0.45F, 0.8F, 
        0.95F, 0.4F, 0.87F, 0.42F, 1.0F, 0.95F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    float outdam[] = {
        0.68F, 0.35F, 0.8F, 0.5F, 0.42F, 0.76F, 0.82F, 0.76F, 0.72F, 0.62F, 
        0.79F, 0.95F, 0.77F, 1.0F, 0.85F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    int cclass[] = {
        0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 
        3, 4, 4, 4, 4, 4, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    String names[] = {
        "Tornado Shark", "Formula 7", "Wow Caninaro", "La Vita Crab", "Nimi", "MAX Revenge", "Lead Oxide", "Kool Kat", "Drifter X", "Sword of Justice", 
        "High Rider", "EL KING", "Mighty Eight", "M A S H E E N", "Radical One", "DR Monstaa", "", "", "", "", 
        "", "", "", "", "", "", "", "", "", "", 
        "", "", "", "", "", "", "", "", "", "", 
        "", "", "", "", "", "", "", "", "", "", 
        "", "", "", "", "", ""
    };
    int enginsignature[] = {
        0, 1, 2, 1, 0, 3, 2, 2, 1, 0, 
        3, 4, 1, 4, 0, 3, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0
    };
    int lastload;
    int nlcars;
    int nlocars;
    int xnlocars;
    boolean include[];
    String createdby[];
    int publish[];
    String loadnames[];
    int nl;
    int action;
    boolean carlon;
    int reco;
    int lcardate[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    int haltload;
    int onloadingcar;
    int ac;
    String acname;
    String fails;
    String tnickey;
    String tclan;
    String tclankey;
    int loadlist;
    int adds[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    String viewname;
    int staction;
    String onstage;
    int inslot;
    int roundslot;
    String lastcar;
    int msloaded;
    int top20adds[];
}
