// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CheckPoints.java


public class CheckPoints
{

    public CheckPoints()
    {
        x = new int[140];
        z = new int[140];
        y = new int[140];
        typ = new int[140];
        pcs = 0;
        nsp = 0;
        n = 0;
        fx = new int[5];
        fz = new int[5];
        fy = new int[5];
        roted = new boolean[5];
        special = new boolean[5];
        fn = 0;
        stage = (int)(Math.random() * 27D) + 1;
        nlaps = 0;
        nfix = 0;
        notb = false;
        name = "hogan rewish";
        maker = "";
        pubt = 0;
        trackname = "";
        trackvol = 200;
        top20 = 0;
        nto = 0;
        wasted = 0;
        haltall = false;
        pcleared = 0;
        opx = new int[8];
        opz = new int[8];
        onscreen = new int[8];
        omxz = new int[8];
        catchfin = 0;
        postwo = 0;
        prox = 0.0F;
    }

    public void checkstat(Mad mads[], ContO contos[], Record record, int i, int i_0, int i_1)
    {
        if(!haltall)
        {
            pcleared = mads[i_0].pcleared;
            for(int i_2 = 0; i_2 < i; i_2++)
            {
                magperc[i_2] = (float)mads[i_2].hitmag / (float)mads[i_2].cd.maxmag[mads[i_2].cn];
                if(magperc[i_2] > 1.0F)
                    magperc[i_2] = 1.0F;
                pos[i_2] = 0;
                onscreen[i_2] = contos[i_2].dist;
                opx[i_2] = contos[i_2].x;
                opz[i_2] = contos[i_2].z;
                omxz[i_2] = mads[i_2].mxz;
                if(dested[i_2] == 0)
                    clear[i_2] = mads[i_2].clear;
                else
                    clear[i_2] = -1;
                mads[i_2].outshakedam = mads[i_2].shakedam;
                mads[i_2].shakedam = 0;
            }

            for(int i_3 = 0; i_3 < i; i_3++)
            {
                for(int i_4 = i_3 + 1; i_4 < i; i_4++)
                {
                    if(clear[i_3] != clear[i_4])
                    {
                        if(clear[i_3] < clear[i_4])
                            pos[i_3]++;
                        else
                            pos[i_4]++;
                        continue;
                    }
                    int i_5 = mads[i_3].pcleared + 1;
                    if(i_5 >= n)
                        i_5 = 0;
                    do
                    {
                        if(typ[i_5] > 0)
                            break;
                        if(++i_5 >= n)
                            i_5 = 0;
                    } while(true);
                    if(py(contos[i_3].x / 100, x[i_5] / 100, contos[i_3].z / 100, z[i_5] / 100) > py(contos[i_4].x / 100, x[i_5] / 100, contos[i_4].z / 100, z[i_5] / 100))
                        pos[i_3]++;
                    else
                        pos[i_4]++;
                }

            }

            if(stage > 2)
            {
                for(int i_6 = 0; i_6 < i; i_6++)
                {
                    if(clear[i_6] != nlaps * nsp || pos[i_6] != 0)
                        continue;
                    if(i_6 == i_0)
                    {
                        for(int i_7 = 0; i_7 < i; i_7++)
                            if(pos[i_7] == 1)
                                postwo = i_7;

                        if(py(opx[i_0] / 100, opx[postwo] / 100, opz[i_0] / 100, opz[postwo] / 100) < 14000 && clear[i_0] - clear[postwo] == 1)
                            catchfin = 30;
                        continue;
                    }
                    if(pos[i_0] == 1 && py(opx[i_0] / 100, opx[i_6] / 100, opz[i_0] / 100, opz[i_6] / 100) < 14000 && clear[i_6] - clear[i_0] == 1)
                    {
                        catchfin = 30;
                        postwo = i_6;
                    }
                }

            }
        }
        wasted = 0;
        for(int i_8 = 0; i_8 < i; i_8++)
            if((i_0 != i_8 || i_1 >= 2) && mads[i_8].dest)
                wasted++;

        if(catchfin != 0 && i_1 < 2)
        {
            catchfin--;
            if(catchfin == 0)
            {
                record.cotchinow(postwo);
                record.closefinish = pos[i_0] + 1;
            }
        }
    }

    public void calprox()
    {
        int i = 0;
        for(int i_9 = 0; i_9 < n - 1; i_9++)
        {
            for(int i_10 = i_9 + 1; i_10 < n; i_10++)
            {
                if(Math.abs(x[i_9] - x[i_10]) > i)
                    i = Math.abs(x[i_9] - x[i_10]);
                if(Math.abs(z[i_9] - z[i_10]) > i)
                    i = Math.abs(z[i_9] - z[i_10]);
            }

        }

        prox = (float)i / 90F;
    }

    public int py(int i, int i_11, int i_12, int i_13)
    {
        return (i - i_11) * (i - i_11) + (i_12 - i_13) * (i_12 - i_13);
    }

    int x[];
    int z[];
    int y[];
    int typ[];
    int pcs;
    int nsp;
    int n;
    int fx[];
    int fz[];
    int fy[];
    boolean roted[];
    boolean special[];
    int fn;
    int stage;
    int nlaps;
    int nfix;
    boolean notb;
    String name;
    String maker;
    int pubt;
    String trackname;
    int trackvol;
    int top20;
    int nto;
    int pos[] = {
        7, 7, 7, 7, 7, 7, 7, 7
    };
    int clear[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int dested[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    float magperc[] = {
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F
    };
    int wasted;
    boolean haltall;
    int pcleared;
    int opx[];
    int opz[];
    int onscreen[];
    int omxz[];
    int catchfin;
    int postwo;
    float prox;
}
