// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   StageMaker.java

import java.applet.Applet;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.zip.*;
import javax.swing.JOptionPane;

public class StageMaker extends Applet
    implements Runnable
{

    public StageMaker()
    {
        exwist = false;
        apx = 0;
        apy = 0;
        sstage = "";
        suser = "Horaks";
        tab = 0;
        tabed = -1;
        btgame = new Image[2];
        onbtgame = false;
        focuson = true;
        overcan = false;
        left = false;
        right = false;
        up = false;
        down = false;
        zoomi = false;
        zoomo = false;
        stagename = "";
        tstage = (new StringBuilder()).append("snap(0,0,0)\r\nsky(191,215,255)\r\nclouds(255,255,255,5,-1000)\r\nfog(195,207,230)\r\nground(192,194,202)\r\ntexture(0,0,0,50)\r\nfadefrom(5000)\r\ndensity(5)\n\rmountains(").append((int)(Math.random() * 100000D)).append(")\r\nnlaps(5)\r\n\r\n").toString();
        bstage = "set(47,0,0,0)\r\nmaxr(11,28500,-5600)\r\nmaxb(9,-8000,-12300)\r\nmaxl(11,-14700,-5600)\r\nmaxt(9,44800,-12300)\r\n";
        undos = new String[5000];
        nundo = 0;
        m = new Medium();
        cp = new CheckPoints();
        t = new Trackers();
        bco = new ContO[67];
        co = new ContO[601];
        nob = 0;
        xnob = 0;
        errd = 0;
        origfade = 5000;
        sfase = 0;
        slstage = new Smenu(2000);
        srch = new TextField("", 38);
        strtyp = new Smenu(40);
        ptyp = new Smenu(40);
        part = new Smenu(40);
        sptyp = 0;
        spart = 0;
        sp = 0;
        lsp = -1;
        seq = 0;
        setcur = false;
        epart = false;
        arrng = false;
        esp = -1;
        hi = -1;
        arrcnt = 0;
        chi = -1;
        seqn = false;
        rot = 0;
        adrot = 0;
        su = new Image[2];
        sl = new Image[2];
        sd = new Image[2];
        sr = new Image[2];
        zi = new Image[2];
        zo = new Image[2];
        pgen = false;
        pwd = 2L + Math.round(Math.random() * 4D);
        phd = 2L + Math.round(Math.random() * 4D);
        fgen = 0;
        sx = 0;
        sz = 1500;
        sy = -10000;
        fixh = new TextField("2000", 5);
        hf = 2000;
        onoff = false;
        onfly = false;
        flyh = 0;
        mgen = new TextField("", 10);
        vxz = 0;
        vx = 0;
        vz = 0;
        vy = 0;
        dtab = 0;
        dtabed = -1;
        mouseon = -1;
        pfog = new Checkbox("Linked Blend");
        nlaps = new Smenu(40);
        tracks = new Smenu(2000);
        trackname = "";
        ltrackname = "";
        trackvol = 200;
        tracksize = 111;
        track = new RadicalMod();
        avon = 0;
        witho = new Smenu(40);
        logged = 0;
        tnick = new TextField("", 15);
        tpass = new TextField("", 15);
        pubitem = new Smenu(707);
        pubtyp = new Smenu(40);
        nms = 0;
        roto = 0;
        mystages = new String[20];
        maker = new String[20];
        pubt = new int[20];
        addeda = new String[20][5000];
        nad = new int[20];
        justpubd = "";
        btn = 0;
        mouses = 0;
        xm = 0;
        ym = 0;
        lxm = 0;
        lym = 0;
        cntout = 0;
        preop = false;
        mousdr = false;
        ttstage = "";
    }

    public void run()
    {
        thredo.setPriority(10);
        btgame[0] = getImage("data/backtogame1.gif");
        btgame[1] = getImage("data/backtogame2.gif");
        logo = getImage("data/stagemakerlogo.gif");
        for(int i = 0; i < 2; i++)
        {
            su[i] = getImage((new StringBuilder()).append("data/su").append(i + 1).append(".gif").toString());
            sl[i] = getImage((new StringBuilder()).append("data/sl").append(i + 1).append(".gif").toString());
            sd[i] = getImage((new StringBuilder()).append("data/sd").append(i + 1).append(".gif").toString());
            sr[i] = getImage((new StringBuilder()).append("data/sr").append(i + 1).append(".gif").toString());
            zi[i] = getImage((new StringBuilder()).append("data/zi").append(i + 1).append(".gif").toString());
            zo[i] = getImage((new StringBuilder()).append("data/zo").append(i + 1).append(".gif").toString());
        }

        loadbase();
        loadsettings();
        if(Madness.testdrive != 0)
        {
            if(Madness.testcar.equals("Failx12"))
            {
                JOptionPane.showMessageDialog(null, "Failed to load stage! Please make sure stage is saved properly before Test Drive.", "Stage Maker", 1);
                thredo.stop();
            } else
            {
                stagename = Madness.testcar;
                errd = 0;
                readstage(3);
                if(errd == 0)
                {
                    tab = 2;
                    dtab = 6;
                    witho.select(Madness.testdrive - 3);
                }
            }
            Madness.testcar = "";
            Madness.testdrive = 0;
        }
        requestFocus();
        do
        {
            if(exwist)
                break;
            rd.setColor(new Color(225, 225, 225));
            rd.fillRect(0, 25, 800, 525);
            rd.setColor(new Color(0, 0, 0));
            if(tab != tabed)
                hidefields();
            if(tab == 0)
            {
                if(tabed != tab)
                {
                    slstage.removeAll();
                    slstage.maxl = 360;
                    slstage.add(rd, "Select a Stage                      ");
                    String as[] = (new File("mystages/")).list();
                    if(as != null)
                    {
                        for(int i2 = 0; i2 < as.length; i2++)
                            if(as[i2].toLowerCase().endsWith(".txt"))
                                slstage.add(rd, as[i2].substring(0, as[i2].length() - 4));

                    }
                    if(stagename.equals(""))
                    {
                        slstage.select(0);
                    } else
                    {
                        slstage.select(stagename);
                        if(stagename.equals(slstage.getSelectedItem()))
                        {
                            readstage(3);
                            sx = 0;
                            sz = 1500;
                            sy = -10000;
                        } else
                        {
                            stagename = "";
                            slstage.select(0);
                        }
                    }
                    mouseon = -1;
                    sfase = 0;
                }
                rd.drawImage(logo, 261, 35, null);
                if(xm > 261 && xm < 538 && ym > 35 && ym < 121)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 3;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 3)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if(mouseon == 3 && mouses == -1)
                    openhlink();
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(xm > 200 && xm < 550 && ym > 467 && ym < 504)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 2;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 2)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if(mouseon == 2)
                    rd.setColor(new Color(0, 64, 128));
                else
                    rd.setColor(new Color(0, 0, 0));
                rd.drawString("For the Stage Maker Homepage, Development Center and Forums :", 400 - ftm.stringWidth("For the Stage Maker Homepage, Development Center and Forums :") / 2, 480);
                rd.setColor(new Color(0, 128, 255));
                String s = "http://www.needformadness.com/developer/";
                rd.drawString(s, 400 - ftm.stringWidth(s) / 2, 500);
                if(mouseon == 2)
                    rd.setColor(new Color(0, 128, 255));
                else
                    rd.setColor(new Color(0, 64, 128));
                rd.drawLine(400 - ftm.stringWidth(s) / 2, 501, 400 + ftm.stringWidth(s) / 2, 501);
                if(mouseon == 2 && mouses == -1)
                    openhlink();
                byte byte0 = -110;
                if(xm > 150 && xm < 600 && ym > 467 + byte0 && ym < 504 + byte0)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 1;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 1)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if(mouseon == 1)
                    rd.setColor(new Color(0, 64, 128));
                else
                    rd.setColor(new Color(0, 0, 0));
                rd.drawString("For help and a detailed step by step description on how to use the Stage Maker :", 400 - ftm.stringWidth("For help and a detailed step by step description on how to use the Stage Maker :") / 2, 480 + byte0);
                rd.setColor(new Color(0, 128, 255));
                s = "http://www.needformadness.com/developer/help.html";
                rd.drawString(s, 400 - ftm.stringWidth(s) / 2, 500 + byte0);
                if(mouseon == 1)
                    rd.setColor(new Color(0, 128, 255));
                else
                    rd.setColor(new Color(0, 64, 128));
                rd.drawLine(400 - ftm.stringWidth(s) / 2, 501 + byte0, 400 + ftm.stringWidth(s) / 2, 501 + byte0);
                if(mouseon == 1 && mouses == -1)
                    openlink();
                byte byte1 = -60;
                byte byte2 = 70;
                rd.setColor(new Color(0, 0, 0));
                rd.drawRect(227 - byte2, 194 + byte1, 346 + byte2 * 2, 167 + byte2 / 5);
                if(sfase == 0)
                {
                    rd.drawString("Select Stage to Edit", 400 - ftm.stringWidth("Select Stage to Edit") / 2, 230 + byte1);
                    slstage.move(220, 240 + byte1);
                    if(slstage.getWidth() != 360)
                        slstage.setSize(360, 21);
                    if(!slstage.isShowing())
                        slstage.show();
                    if(button("    Make new Stage    ", 400, 296 + byte1, 0, true))
                    {
                        srch.setText("");
                        slstage.hide();
                        sfase = 1;
                    }
                    if(button("     Rename Stage     ", 325, 336 + byte1, 0, false))
                        if(!stagename.equals(""))
                        {
                            slstage.hide();
                            srch.setText(stagename);
                            sfase = 2;
                        } else
                        {
                            JOptionPane.showMessageDialog(null, "Please select a stage to rename first.", "Stage Maker", 1);
                        }
                    if(button("      Delete Stage      ", 475, 336 + byte1, 0, false))
                        if(!stagename.equals(""))
                        {
                            if(JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Are you sure you want to permanently delete this stage?\n\n").append(stagename).append("\n\n").toString(), "Stage Maker", 0) == 0)
                                delstage(stagename);
                        } else
                        {
                            JOptionPane.showMessageDialog(null, "Please select a stage to delete first.", "Stage Maker", 1);
                        }
                    if(slstage.getSelectedIndex() != 0)
                    {
                        if(!stagename.equals(slstage.getSelectedItem()))
                        {
                            stagename = slstage.getSelectedItem();
                            readstage(3);
                            sx = 0;
                            sz = 1500;
                            sy = -10000;
                            requestFocus();
                        }
                    } else
                    {
                        stagename = "";
                    }
                }
                if(sfase == 1)
                {
                    rd.drawString("Make a new Stage", 400 - ftm.stringWidth("Make a new Stage") / 2, 220 + byte1);
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.drawString("New stage name :", 200, 246 + byte1);
                    movefield(srch, 310, 231 + byte1, 290, 23);
                    if(!srch.isShowing())
                    {
                        srch.show();
                        srch.requestFocus();
                    }
                    fixtext(srch);
                    rd.drawString("Starting line type :", 293, 272 + byte1);
                    strtyp.move(408, 256 + byte1);
                    if(!strtyp.isShowing())
                        strtyp.show();
                    if(button("    Make Stage    ", 400, 311 + byte1, 0, true))
                        newstage();
                    if(button("  Cancel  ", 400, 351 + byte1, 0, false))
                    {
                        strtyp.hide();
                        srch.hide();
                        sfase = 0;
                    }
                }
                if(sfase == 2)
                {
                    rd.drawString((new StringBuilder()).append("Rename Stage :  ").append(stagename).append("").toString(), 400 - ftm.stringWidth((new StringBuilder()).append("Rename Stage :  ").append(stagename).append("").toString()) / 2, 230 + byte1);
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.drawString("New name :", 218, 266 + byte1);
                    if(!srch.isShowing())
                    {
                        srch.show();
                        srch.requestFocus();
                    }
                    movefield(srch, 292, 251 + byte1, 290, 23);
                    fixtext(srch);
                    if(button("    Rename Stage    ", 400, 306 + byte1, 0, true))
                        renstage(srch.getText());
                    if(button("  Cancel  ", 400, 346 + byte1, 0, false))
                    {
                        srch.hide();
                        sfase = 0;
                    }
                }
            }
            if(tab == 1)
            {
                if(tabed != tab)
                {
                    m.trk = 2;
                    readstage(0);
                    if(sptyp == 0)
                        partroads();
                    if(sptyp == 1)
                        partramps();
                    if(sptyp == 2)
                        partobst();
                    if(sptyp == 5)
                        partrees();
                    onoff = false;
                    setCursor(new Cursor(0));
                    setcur = false;
                    epart = false;
                    arrng = false;
                    if(nob == 1)
                    {
                        sptyp = 0;
                        if(co[0].colok == 38)
                            spart = 9;
                        else
                            spart = 0;
                    }
                    mouseon = -1;
                }
                if(sptyp == 0)
                {
                    if(spart == 0)
                        sp = 0;
                    if(spart == 1)
                        sp = 4;
                    if(spart == 2)
                        sp = 13;
                    if(spart == 3)
                        sp = 3;
                    if(spart == 4)
                        sp = 2;
                    if(spart == 5)
                        sp = 1;
                    if(spart == 6)
                        sp = 35;
                    if(spart == 7)
                        sp = 36;
                    if(spart == 8)
                        sp = 10;
                    if(spart == 9)
                        sp = 5;
                    if(spart == 10)
                        sp = 7;
                    if(spart == 11)
                        sp = 14;
                    if(spart == 12)
                        sp = 6;
                    if(spart == 13)
                        sp = 34;
                    if(spart == 14)
                        sp = 33;
                    if(spart == 15)
                        sp = 11;
                    if(spart == 16)
                        sp = 8;
                    if(spart == 17)
                        sp = 9;
                    if(spart == 18)
                        sp = 15;
                    if(spart == 19)
                        sp = 12;
                    if(spart == 20)
                        sp = 46;
                    if(spart == 21)
                        sp = 47;
                    if(spart == 22)
                        sp = 50;
                    if(spart == 23)
                        sp = 48;
                    if(spart == 24)
                        sp = 49;
                    if(spart == 25)
                        sp = 51;
                }
                if(sptyp == 1)
                {
                    if(spart == 0)
                        sp = 16;
                    if(spart == 1)
                        sp = 18;
                    if(spart == 2)
                        sp = 19;
                    if(spart == 3)
                        sp = 22;
                    if(spart == 4)
                        sp = 17;
                    if(spart == 5)
                        sp = 21;
                    if(spart == 6)
                        sp = 20;
                    if(spart == 7)
                        sp = 39;
                    if(spart == 8)
                        sp = 42;
                    if(spart == 9)
                        sp = 40;
                    if(spart == 10)
                        sp = 23;
                    if(spart == 11)
                        sp = 25;
                    if(spart == 12)
                        sp = 24;
                    if(spart == 13)
                        sp = 43;
                    if(spart == 14)
                        sp = 45;
                    if(spart == 15)
                        sp = 26;
                }
                if(sptyp == 2)
                {
                    if(spart == 0)
                        sp = 27;
                    if(spart == 1)
                        sp = 28;
                    if(spart == 2)
                        sp = 41;
                    if(spart == 3)
                        sp = 44;
                    if(spart == 4)
                        sp = 52;
                    if(spart == 5)
                        sp = 53;
                }
                if(sptyp == 3)
                    if(onfly)
                        sp = 54;
                    else
                    if(!onoff)
                        sp = 30;
                    else
                        sp = 32;
                if(sptyp == 4)
                    sp = 31;
                if(sptyp == 5)
                {
                    if(spart == 0)
                        sp = 55;
                    if(spart == 1)
                        sp = 56;
                    if(spart == 2)
                        sp = 57;
                    if(spart == 3)
                        sp = 58;
                    if(spart == 4)
                        sp = 59;
                    if(spart == 5)
                        sp = 60;
                    if(spart == 6)
                        sp = 61;
                    if(spart == 7)
                        sp = 62;
                    if(spart == 8)
                        sp = 63;
                    if(spart == 9)
                        sp = 64;
                    if(spart == 10)
                        sp = 65;
                }
                if(sptyp == 6)
                {
                    if(!pgen)
                    {
                        int j = (int)(10000D * Math.random());
                        if(fgen != 0)
                        {
                            j = fgen;
                            fgen = 0;
                        }
                        bco[66] = new ContO(j, (int)pwd, (int)phd, m, t, 0, 0, 0);
                        bco[66].srz = j;
                        bco[66].srx = (int)pwd;
                        bco[66].sry = (int)phd;
                        pgen = true;
                        seq = 3;
                    }
                    sp = 66;
                    rot = 0;
                } else
                if(pgen)
                {
                    pgen = false;
                    pwd = 2L + Math.round(Math.random() * 4D);
                    phd = 2L + Math.round(Math.random() * 4D);
                }
                if(sp == 30 || sp == 31 || sp == 32 || sp == 54)
                {
                    if(rot == -90)
                        rot = 90;
                    if(rot == 180)
                        rot = 0;
                }
                adrot = 0;
                if(sp == 2)
                    adrot = -30;
                if(sp == 3)
                    adrot = 30;
                if(sp == 15)
                    adrot = 90;
                if(sp == 20)
                    adrot = 180;
                if(sp == 26)
                    adrot = 90;
                rd.setColor(new Color(200, 200, 200));
                rd.fillRect(248, 63, 514, 454);
                m.trk = 2;
                m.zy = 90;
                m.xz = 0;
                m.iw = 248;
                m.w = 762;
                m.ih = 63;
                m.h = 517;
                m.cx = 505;
                m.cy = 290;
                m.x = sx - m.cx;
                m.z = sz - m.cz;
                m.y = sy;
                int k = 0;
                int ai[] = new int[200];
                for(int j3 = 0; j3 < nob; j3++)
                    if(co[j3].dist != 0)
                    {
                        ai[k] = j3;
                        k++;
                    } else
                    {
                        co[j3].d(rd);
                    }

                int ai3[] = new int[k];
                for(int i4 = 0; i4 < k; i4++)
                    ai3[i4] = 0;

                for(int j4 = 0; j4 < k; j4++)
                {
                    for(int j7 = j4 + 1; j7 < k; j7++)
                    {
                        if(co[ai[j4]].dist != co[ai[j7]].dist)
                        {
                            if(co[ai[j4]].dist < co[ai[j7]].dist)
                                ai3[j4]++;
                            else
                                ai3[j7]++;
                            continue;
                        }
                        if(j7 > j4)
                            ai3[j4]++;
                        else
                            ai3[j7]++;
                    }

                }

                for(int k4 = 0; k4 < k; k4++)
                {
                    for(int k7 = 0; k7 < k; k7++)
                    {
                        if(ai3[k7] != k4)
                            continue;
                        if(ai[k7] == hi)
                            m.trk = 3;
                        if(ai[k7] == chi && !co[ai[k7]].errd)
                        {
                            int i10 = m.cx + (int)((float)(co[ai[k7]].x - m.x - m.cx) * m.cos(m.xz) - (float)(co[ai[k7]].z - m.z - m.cz) * m.sin(m.xz));
                            int i12 = m.cz + (int)((float)(co[ai[k7]].x - m.x - m.cx) * m.sin(m.xz) + (float)(co[ai[k7]].z - m.z - m.cz) * m.cos(m.xz));
                            int k15 = m.cy + (int)((float)(co[ai[k7]].y - m.y - m.cy) * m.cos(m.zy) - (float)(i12 - m.cz) * m.sin(m.zy));
                            int j18 = m.cz + (int)((float)(co[ai[k7]].y - m.y - m.cy) * m.sin(m.zy) + (float)(i12 - m.cz) * m.cos(m.zy));
                            int k22 = 0xf4240 / Math.abs(sy);
                            Graphics2D graphics2d = rd;
                            graphics2d.setComposite(AlphaComposite.getInstance(3, 0.7F));
                            rd.setColor(new Color(0, 164, 255));
                            rd.fillOval(xs(i10, j18) - k22 / 2, ys(k15, j18) - k22 / 2, k22, k22);
                            graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("NO# ").append(arrcnt + 1).append("").toString(), xs(i10, j18) - ftm.stringWidth((new StringBuilder()).append("NO# ").append(arrcnt + 1).append("").toString()) / 2, ys(k15, j18) - k22 / 2);
                        }
                        if(arrng && (co[ai[k7]].colok == 30 || co[ai[k7]].colok == 32 || co[ai[k7]].colok == 54) && co[ai[k7]].errd)
                        {
                            int j10 = m.cx + (int)((float)(co[ai[k7]].x - m.x - m.cx) * m.cos(m.xz) - (float)(co[ai[k7]].z - m.z - m.cz) * m.sin(m.xz));
                            int j12 = m.cz + (int)((float)(co[ai[k7]].x - m.x - m.cx) * m.sin(m.xz) + (float)(co[ai[k7]].z - m.z - m.cz) * m.cos(m.xz));
                            int l15 = m.cy + (int)((float)(co[ai[k7]].y - m.y - m.cy) * m.cos(m.zy) - (float)(j12 - m.cz) * m.sin(m.zy));
                            int k18 = m.cz + (int)((float)(co[ai[k7]].y - m.y - m.cy) * m.sin(m.zy) + (float)(j12 - m.cz) * m.cos(m.zy));
                            int l22 = 0xf4240 / Math.abs(sy);
                            Graphics2D graphics2d1 = rd;
                            graphics2d1.setComposite(AlphaComposite.getInstance(3, 0.5F));
                            rd.setColor(new Color(255, 128, 0));
                            rd.fillOval(xs(j10, k18) - l22 / 2, ys(l15, k18) - l22 / 2, l22, l22);
                            graphics2d1.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("NO# ").append(co[ai[k7]].wh).append("").toString(), xs(j10, k18) - ftm.stringWidth((new StringBuilder()).append("NO# ").append(co[ai[k7]].wh).append("").toString()) / 2, ys(l15, k18) - l22 / 2);
                        }
                        co[ai[k7]].d(rd);
                        if(m.trk == 3)
                            m.trk = 2;
                    }

                }

                if(xm > 248 && xm < 762 && ym > 63 && ym < 517)
                {
                    if(!epart && !arrng)
                    {
                        bco[sp].x = (xm - 505) * (Math.abs(sy) / m.focus_point) + sx;
                        bco[sp].z = (290 - ym) * (Math.abs(sy) / m.focus_point) + sz;
                        bco[sp].y = m.ground - bco[sp].grat;
                        bco[sp].xz = rot + adrot;
                        int l4 = 200;
                        int l7 = 0;
                        int k10 = 0;
                        int ai8[] = {
                            bco[sp].x + atp[sp][0], bco[sp].x + atp[sp][2]
                        };
                        int ai9[] = {
                            bco[sp].z + atp[sp][1], bco[sp].z + atp[sp][3]
                        };
                        rot(ai8, ai9, bco[sp].x, bco[sp].z, rot, 2);
                        int l18 = 0;
                        onfly = false;
                        int i23 = 500;
label0:
                        for(int i24 = 0; i24 < nob; i24++)
                        {
                            int ai11[] = {
                                co[i24].x + atp[co[i24].colok][0], co[i24].x + atp[co[i24].colok][2]
                            };
                            int ai12[] = {
                                co[i24].z + atp[co[i24].colok][1], co[i24].z + atp[co[i24].colok][3]
                            };
                            int i28 = co[i24].roofat;
                            if(co[i24].colok == 2)
                                i28 += 30;
                            if(co[i24].colok == 3)
                                i28 -= 30;
                            if(co[i24].colok == 15)
                                i28 -= 90;
                            if(co[i24].colok == 20)
                                i28 -= 180;
                            if(co[i24].colok == 26)
                                i28 -= 90;
                            rot(ai11, ai12, co[i24].x, co[i24].z, i28, 2);
                            if(sp <= 54)
                            {
                                int k28 = py(ai11[0], ai8[0], ai12[0], ai9[0]);
                                if(k28 < l4 && k28 != 0)
                                {
                                    l4 = k28;
                                    l7 = ai11[0] - ai8[0];
                                    k10 = ai12[0] - ai9[0];
                                }
                                k28 = py(ai11[1], ai8[0], ai12[1], ai9[0]);
                                if(k28 < l4 && k28 != 0)
                                {
                                    l4 = k28;
                                    l7 = ai11[1] - ai8[0];
                                    k10 = ai12[1] - ai9[0];
                                }
                                k28 = py(ai11[1], ai8[1], ai12[1], ai9[1]);
                                if(k28 < l4 && k28 != 0)
                                {
                                    l4 = k28;
                                    l7 = ai11[1] - ai8[1];
                                    k10 = ai12[1] - ai9[1];
                                }
                                k28 = py(ai11[0], ai8[1], ai12[0], ai9[1]);
                                if(k28 < l4 && k28 != 0)
                                {
                                    l4 = k28;
                                    l7 = ai11[0] - ai8[1];
                                    k10 = ai12[0] - ai9[1];
                                }
                            }
                            if(sptyp == 3 && py(ai11[0], ai8[0], ai12[0], ai9[0]) != 0 && py(ai11[1], ai8[0], ai12[1], ai9[0]) != 0)
                            {
                                for(int l28 = 0; l28 < rcheckp.length; l28++)
                                {
                                    if(co[i24].colok != rcheckp[l28])
                                        continue;
                                    if(py(ai11[0], ai8[0], ai12[0], ai9[0]) <= l18 || l18 == 0)
                                    {
                                        l18 = py(ai11[0], ai8[0], ai12[0], ai9[0]);
                                        onoff = false;
                                    }
                                    if(py(ai11[1], ai8[0], ai12[1], ai9[0]) <= l18)
                                    {
                                        l18 = py(ai11[1], ai8[0], ai12[1], ai9[0]);
                                        onoff = false;
                                    }
                                }

                                for(int i29 = 0; i29 < ocheckp.length; i29++)
                                {
                                    if(co[i24].colok != ocheckp[i29])
                                        continue;
                                    if(py(ai11[0], ai8[0], ai12[0], ai9[0]) <= l18 || l18 == 0)
                                    {
                                        l18 = py(ai11[0], ai8[0], ai12[0], ai9[0]);
                                        onoff = true;
                                    }
                                    if(py(ai11[1], ai8[0], ai12[1], ai9[0]) <= l18)
                                    {
                                        l18 = py(ai11[1], ai8[0], ai12[1], ai9[0]);
                                        onoff = true;
                                    }
                                }

                            }
                            if(sp > 12 && sp < 33 || sp == 35 || sp == 36 || sp >= 39 && sp <= 54)
                            {
                                if((rot == 0 || rot == 180 || sp == 26 || sp == 15) && (i28 == 0 || i28 == 180 || sp == 26 || sp == 15))
                                {
                                    if(Math.abs(ai11[0] - ai8[0]) < 200)
                                        l7 = ai11[0] - ai8[0];
                                    if(Math.abs(ai11[0] - ai8[1]) < 200)
                                        l7 = ai11[0] - ai8[1];
                                    if(Math.abs(ai11[1] - ai8[1]) < 200)
                                        l7 = ai11[1] - ai8[1];
                                    if(Math.abs(ai11[1] - ai8[0]) < 200)
                                        l7 = ai11[1] - ai8[0];
                                }
                                if((rot == 90 || rot == -90 || sp == 26 || sp == 15) && (i28 == 90 || i28 == -90 || sp == 26 || sp == 15))
                                {
                                    if(Math.abs(ai12[0] - ai9[0]) < 200)
                                        k10 = ai12[0] - ai9[0];
                                    if(Math.abs(ai12[0] - ai9[1]) < 200)
                                        k10 = ai12[0] - ai9[1];
                                    if(Math.abs(ai12[1] - ai9[1]) < 200)
                                        k10 = ai12[1] - ai9[1];
                                    if(Math.abs(ai12[1] - ai9[0]) < 200)
                                        k10 = ai12[1] - ai9[0];
                                }
                            }
                            if(sptyp != 3 || co[i24].colok < 46 || co[i24].colok > 51)
                                continue;
                            int ai15[] = {
                                2, 3, 5, 2, 3, 3
                            };
                            if((Math.abs(co[i24].roofat) == 180 || co[i24].roofat == 0) && rot == 0 && Math.abs(bco[sp].x - co[i24].x) < 500 && Math.abs(bco[sp].z - co[i24].z) < 3000)
                            {
                                for(int i30 = 0; i30 < ai15[co[i24].colok - 46]; i30++)
                                {
                                    for(int i31 = 0; i31 < co[i24].p[i30].n; i31++)
                                        if(py(bco[sp].x, co[i24].x, bco[sp].z, co[i24].z + co[i24].p[i30].oz[i31]) < i23)
                                        {
                                            i23 = py(bco[sp].x, co[i24].x, bco[sp].z, co[i24].z + co[i24].p[i30].oz[i31]);
                                            flyh = (co[i24].p[i30].oy[i31] - 28) + m.ground;
                                            l7 = co[i24].x - bco[sp].x;
                                            k10 = (co[i24].z + co[i24].p[i30].oz[i31]) - bco[sp].z;
                                            onfly = true;
                                        }

                                }

                            }
                            if(Math.abs(co[i24].roofat) != 90 || rot != 90 || Math.abs(bco[sp].z - co[i24].z) >= 500 || Math.abs(bco[sp].x - co[i24].x) >= 3000)
                                continue;
                            int j30 = 0;
                            do
                            {
                                if(j30 >= ai15[co[i24].colok - 46])
                                    continue label0;
                                for(int j31 = 0; j31 < co[i24].p[j30].n; j31++)
                                    if(py(bco[sp].z, co[i24].z, bco[sp].x, co[i24].x + co[i24].p[j30].ox[j31]) < i23)
                                    {
                                        i23 = py(bco[sp].z, co[i24].z, bco[sp].x, co[i24].x + co[i24].p[j30].ox[j31]);
                                        flyh = (co[i24].p[j30].oy[j31] - 28) + m.ground;
                                        k10 = co[i24].z - bco[sp].z;
                                        l7 = (co[i24].x + co[i24].p[j30].ox[j31]) - bco[sp].x;
                                        onfly = true;
                                    }

                                j30++;
                            } while(true);
                        }

                        bco[sp].x += l7;
                        bco[sp].z += k10;
                        int j24 = bco[sp].xy;
                        int i26 = bco[sp].zy;
                        if(sp == 31)
                        {
                            bco[sp].y = -hf;
                            if(bco[sp].y > -500)
                                bco[sp].y = -500;
                        } else
                        {
                            bco[sp].xy = 0;
                        }
                        if(sp == 54)
                            bco[sp].y = flyh;
                        bco[sp].zy = 0;
                        if(cntout == 0)
                        {
                            if(mouseon == -1)
                            {
                                bco[sp].d(rd);
                                if(!setcur)
                                {
                                    setCursor(new Cursor(13));
                                    setcur = true;
                                }
                                if(mouses == -1)
                                {
                                    if(nundo < 5000)
                                    {
                                        undos[nundo] = bstage;
                                        nundo++;
                                    }
                                    if(bco[sp].xz == 270)
                                        bco[sp].xz = -90;
                                    if(bco[sp].xz == 360)
                                        bco[sp].xz = 0;
                                    errd = 0;
                                    boolean flag12 = false;
                                    if(xnob < 601)
                                    {
                                        if(sp != 31 && sp != 54 && sp != 66)
                                            try
                                            {
                                                co[nob] = new ContO(bco[sp], bco[sp].x, m.ground - bco[sp].grat, bco[sp].z, bco[sp].xz);
                                                co[nob].roofat = bco[sp].xz;
                                                co[nob].colok = sp;
                                                nob++;
                                            }
                                            catch(Exception exception11)
                                            {
                                                errd = 1;
                                            }
                                        if(sp == 31)
                                            if(cp.fn < 5)
                                            {
                                                co[nob] = new ContO(bco[sp], bco[sp].x, bco[sp].y, bco[sp].z, bco[sp].xz);
                                                co[nob].roofat = bco[sp].xz;
                                                co[nob].colok = sp;
                                                nob++;
                                                fixh.setText((new StringBuilder()).append("").append(Math.abs(bco[sp].y)).append("").toString());
                                            } else
                                            {
                                                errd = 5;
                                            }
                                        if(sp == 54)
                                            try
                                            {
                                                co[nob] = new ContO(bco[sp], bco[sp].x, bco[sp].y, bco[sp].z, bco[sp].xz);
                                                co[nob].roofat = bco[sp].xz;
                                                co[nob].colok = sp;
                                                nob++;
                                            }
                                            catch(Exception exception12)
                                            {
                                                errd = 1;
                                            }
                                        if(sp == 66)
                                        {
                                            co[nob] = new ContO(bco[66].srz, bco[66].srx, bco[66].sry, m, t, bco[66].x, bco[66].z, bco[sp].y);
                                            co[nob].srz = bco[66].srz;
                                            co[nob].srx = bco[66].srx;
                                            co[nob].sry = bco[66].sry;
                                            co[nob].colok = sp;
                                            nob++;
                                        }
                                    } else
                                    {
                                        errd = 4;
                                    }
                                    if(errd == 0)
                                    {
                                        sortstage();
                                        readstage(0);
                                        flag12 = true;
                                        if(sp == 66)
                                            pgen = false;
                                        if(sp == 52 || sp == 53 || sp >= 55 && sp <= 65)
                                        {
                                            seq = 3;
                                            bco[sp].xy = 0;
                                            bco[sp].zy = 0;
                                            boolean flag13 = false;
                                            if(rot == 0 && !flag13)
                                            {
                                                rot = 90;
                                                flag13 = true;
                                            }
                                            if(rot == 90 && !flag13)
                                            {
                                                rot = 180;
                                                flag13 = true;
                                            }
                                            if(rot == 180 && !flag13)
                                            {
                                                rot = -90;
                                                flag13 = true;
                                            }
                                            if(rot == -90 && !flag13)
                                            {
                                                rot = 0;
                                                boolean flag14 = true;
                                            }
                                        }
                                    }
                                    if(errd != 0)
                                    {
                                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error!  Unable to place part!\nReason:\n").append(errlo[errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                                        if(flag12)
                                        {
                                            nundo--;
                                            bstage = undos[nundo];
                                            readstage(0);
                                        }
                                    }
                                    lxm = bco[sp].x;
                                    lym = bco[sp].z;
                                    cntout = 10;
                                }
                            }
                        } else
                        {
                            if(lxm != bco[sp].x && lxm != bco[sp].z)
                                cntout--;
                            if(setcur)
                            {
                                setCursor(new Cursor(0));
                                setcur = false;
                            }
                        }
                        bco[sp].xy = j24;
                        bco[sp].zy = i26;
                    } else
                    {
                        if(epart)
                            if(esp == -1 && !overcan)
                            {
                                hi = -1;
                                int i5 = 0;
                                for(int i8 = 0; i8 < nob; i8++)
                                {
                                    int l10 = m.cx + (int)((float)(co[i8].x - m.x - m.cx) * m.cos(m.xz) - (float)(co[i8].z - m.z - m.cz) * m.sin(m.xz));
                                    int k12 = m.cz + (int)((float)(co[i8].x - m.x - m.cx) * m.sin(m.xz) + (float)(co[i8].z - m.z - m.cz) * m.cos(m.xz));
                                    int i16 = m.cy + (int)((float)(co[i8].y - m.y - m.cy) * m.cos(m.zy) - (float)(k12 - m.cz) * m.sin(m.zy));
                                    int i19 = m.cz + (int)((float)(co[i8].y - m.y - m.cy) * m.sin(m.zy) + (float)(k12 - m.cz) * m.cos(m.zy));
                                    if(xm <= xs(l10 - co[i8].maxR, i19) || xm >= xs(l10 + co[i8].maxR, i19) || ym <= ys(i16 - co[i8].maxR, i19) || ym >= ys(i16 + co[i8].maxR, i19) || co[i8].colok == 37 || co[i8].colok == 38)
                                        continue;
                                    if(hi == -1)
                                    {
                                        hi = i8;
                                        i5 = py(xm, xs(l10, i19), ym, ys(i16, i19));
                                        continue;
                                    }
                                    if(py(xm, xs(l10, i19), ym, ys(i16, i19)) <= i5)
                                    {
                                        hi = i8;
                                        i5 = py(xm, xs(l10, i19), ym, ys(i16, i19));
                                    }
                                }

                                if(hi != -1)
                                {
                                    if(!setcur)
                                    {
                                        setCursor(new Cursor(13));
                                        setcur = true;
                                    }
                                    if(mouses == -1)
                                    {
                                        esp = hi;
                                        mouses = 0;
                                    }
                                } else
                                if(setcur)
                                {
                                    setCursor(new Cursor(0));
                                    setcur = false;
                                }
                            } else
                            if(setcur)
                            {
                                setCursor(new Cursor(0));
                                setcur = false;
                            }
                        if(arrng)
                        {
                            chi = -1;
                            int j5 = 5000;
                            for(int j8 = 0; j8 < nob; j8++)
                            {
                                if(co[j8].colok != 30 && co[j8].colok != 32 && co[j8].colok != 54 || co[j8].errd)
                                    continue;
                                int i11 = m.cx + (int)((float)(co[j8].x - m.x - m.cx) * m.cos(m.xz) - (float)(co[j8].z - m.z - m.cz) * m.sin(m.xz));
                                int l12 = m.cz + (int)((float)(co[j8].x - m.x - m.cx) * m.sin(m.xz) + (float)(co[j8].z - m.z - m.cz) * m.cos(m.xz));
                                int j16 = m.cy + (int)((float)(co[j8].y - m.y - m.cy) * m.cos(m.zy) - (float)(l12 - m.cz) * m.sin(m.zy));
                                int j19 = m.cz + (int)((float)(co[j8].y - m.y - m.cy) * m.sin(m.zy) + (float)(l12 - m.cz) * m.cos(m.zy));
                                if(xm > xs(i11 - co[j8].maxR, j19) && xm < xs(i11 + co[j8].maxR, j19) && ym > ys(j16 - co[j8].maxR, j19) && ym < ys(j16 + co[j8].maxR, j19) && py(xm, xs(i11, j19), ym, ys(j16, j19)) <= j5)
                                {
                                    chi = j8;
                                    j5 = py(xm, xs(i11, j19), ym, ys(j16, j19));
                                }
                            }

                            if(chi != -1)
                            {
                                if(!setcur)
                                {
                                    setCursor(new Cursor(13));
                                    setcur = true;
                                }
                                if(mouses == -1)
                                {
                                    arrcnt++;
                                    co[chi].wh = arrcnt;
                                    co[chi].errd = true;
                                    mouses = 0;
                                }
                            } else
                            if(setcur)
                            {
                                setCursor(new Cursor(0));
                                setcur = false;
                            }
                        }
                    }
                } else
                if(setcur)
                {
                    setCursor(new Cursor(0));
                    setcur = false;
                }
                if(epart && esp != -1)
                    if(co[esp].dist != 0)
                    {
                        m.cx = 505;
                        m.cy = 290;
                        m.x = sx - m.cx;
                        m.z = sz - m.cz;
                        m.y = sy;
                        int k5 = m.cx + (int)((float)(co[esp].x - m.x - m.cx) * m.cos(m.xz) - (float)(co[esp].z - m.z - m.cz) * m.sin(m.xz));
                        int k8 = m.cz + (int)((float)(co[esp].x - m.x - m.cx) * m.sin(m.xz) + (float)(co[esp].z - m.z - m.cz) * m.cos(m.xz));
                        int j11 = m.cy + (int)((float)(co[esp].y - m.y - m.cy) * m.cos(m.zy) - (float)(k8 - m.cz) * m.sin(m.zy));
                        int i13 = m.cz + (int)((float)(co[esp].y - m.y - m.cy) * m.sin(m.zy) + (float)(k8 - m.cz) * m.cos(m.zy));
                        int k16 = xs(k5, i13);
                        int k19 = ys(j11, i13);
                        rd.setColor(new Color(225, 225, 225));
                        rd.fillRect(k16, k19, 90, 88);
                        rd.setColor(new Color(138, 147, 160));
                        rd.drawRect(k16, k19, 90, 88);
                        if(button("   Edit   ", k16 + 45, k19 + 22, 3, false))
                        {
                            copyesp(true);
                            removesp();
                            lxm = 0;
                            lym = 0;
                            cntout = 2;
                            epart = false;
                        }
                        if(button(" Remove ", k16 + 45, k19 + 49, 3, false))
                        {
                            removesp();
                            esp = -1;
                            mouses = 0;
                        }
                        if(button("  Copy  ", k16 + 45, k19 + 76, 3, false))
                        {
                            copyesp(false);
                            lxm = 0;
                            lym = 0;
                            cntout = 2;
                            epart = false;
                        }
                        rd.setColor(new Color(255, 0, 0));
                        rd.drawString("x", k16 + 82, k19 - 2);
                        if(xm > 248 && xm < 762 && ym > 63 && ym < 517 && mouses == 1 && (xm < k16 || xm > k16 + 90 || ym < k19 || ym > k19 + 88))
                        {
                            esp = -1;
                            mouses = 0;
                        }
                    } else
                    {
                        esp = -1;
                    }
                rd.setColor(new Color(225, 225, 225));
                rd.fillRect(248, 25, 514, 38);
                rd.fillRect(0, 25, 248, 530);
                rd.fillRect(248, 517, 514, 38);
                rd.fillRect(762, 25, 38, 530);
                if(sptyp == 6)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.drawString("Radius:", 11, 97);
                    rd.drawString("Height:", 14, 117);
                    boolean flag3 = false;
                    if(xm > 57 && xm < 204 && ym > 90 && ym < 99)
                        flag3 = true;
                    rd.setColor(new Color(136, 148, 170));
                    if(flag3 || mouseon == 1)
                    {
                        rd.drawRect(57, 90, 147, 8);
                        rd.setColor(new Color(0, 0, 0));
                    }
                    rd.drawLine(57, 94, 204, 94);
                    if(mouseon == 1)
                    {
                        pwd = (float)(xm - 57) / 36.75F + 2.0F;
                        if(pwd < 2.0F)
                            pwd = 2.0F;
                        if(pwd > 6F)
                            pwd = 6F;
                    }
                    rd.drawRect((int)(57F + (pwd - 2.0F) * 36.75F), 90, 2, 8);
                    boolean flag4 = false;
                    if(xm > 57 && xm < 204 && ym > 110 && ym < 119)
                        flag4 = true;
                    rd.setColor(new Color(136, 148, 170));
                    if(flag4 || mouseon == 2)
                    {
                        rd.drawRect(57, 110, 147, 8);
                        rd.setColor(new Color(0, 0, 0));
                    }
                    rd.drawLine(57, 114, 204, 114);
                    if(mouseon == 2)
                    {
                        phd = (float)(xm - 57) / 36.75F + 2.0F;
                        if(phd < 2.0F)
                            phd = 2.0F;
                        if(phd > 6F)
                            phd = 6F;
                    }
                    rd.drawRect((int)(57F + (phd - 2.0F) * 36.75F), 110, 2, 8);
                    if(mouses == 1)
                    {
                        if(flag3)
                            mouseon = 1;
                        if(flag4)
                            mouseon = 2;
                    } else
                    {
                        if(mouseon == 1 || mouseon == 2)
                            pgen = false;
                        mouseon = -1;
                    }
                }
                int l5 = 0;
                if(xm > 482 && xm < 529 && ym > 35 && ym < 61 || up)
                {
                    l5 = 1;
                    if(mouses == 1 || up)
                        sz += 500;
                }
                rd.drawImage(su[l5], 482, 35, null);
                l5 = 0;
                if(xm > 482 && xm < 529 && ym > 519 && ym < 545 || down)
                {
                    l5 = 1;
                    if(mouses == 1 || down)
                        sz -= 500;
                }
                rd.drawImage(sd[l5], 482, 519, null);
                l5 = 0;
                if(xm > 220 && xm < 246 && ym > 264 && ym < 311 || left)
                {
                    l5 = 1;
                    if(mouses == 1 || left)
                        sx -= 500;
                }
                rd.drawImage(sl[l5], 220, 264, null);
                l5 = 0;
                if(xm > 764 && xm < 790 && ym > 264 && ym < 311 || right)
                {
                    l5 = 1;
                    if(mouses == 1 || right)
                        sx += 500;
                }
                rd.drawImage(sr[l5], 764, 264, null);
                l5 = 0;
                if(xm > 616 && xm < 677 && ym > 30 && ym < 61 || zoomi)
                {
                    l5 = 1;
                    if(mouses == 1 || zoomi)
                    {
                        sy += 500;
                        if(sy > -2500)
                            sy = -2500;
                    }
                }
                rd.drawImage(zi[l5], 616, 30, null);
                l5 = 0;
                if(xm > 690 && xm < 751 && ym > 30 && ym < 61 || zoomo)
                {
                    l5 = 1;
                    if(mouses == 1 || zoomo)
                    {
                        sy -= 500;
                        if(sy < -55000)
                            sy = -55000;
                    }
                }
                rd.drawImage(zo[l5], 690, 30, null);
                if((epart || arrng) && sy < -36000)
                    sy = -36000;
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                rd.drawString("Part Selection", 11, 47);
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                ptyp.move(10, 50);
                if(!ptyp.isShowing())
                {
                    ptyp.show();
                    ptyp.select(sptyp);
                }
                if(sptyp != ptyp.getSelectedIndex())
                {
                    sptyp = ptyp.getSelectedIndex();
                    if(sptyp == 0)
                    {
                        partroads();
                        part.show();
                    }
                    if(sptyp == 1)
                    {
                        partramps();
                        part.show();
                    }
                    if(sptyp == 2)
                    {
                        partobst();
                        part.show();
                    }
                    if(sptyp == 5)
                    {
                        partrees();
                        part.show();
                    }
                    spart = 0;
                    part.select(spart);
                    requestFocus();
                    fixh.setText("2000");
                    focuson = false;
                }
                part.move(10, 80);
                part.setSize(200, 21);
                if(sptyp == 0 || sptyp == 1 || sptyp == 2 || sptyp == 5)
                {
                    if(!part.isShowing())
                    {
                        part.show();
                        part.select(spart);
                    }
                } else
                if(part.isShowing())
                    part.hide();
                if(spart != part.getSelectedIndex())
                {
                    spart = part.getSelectedIndex();
                    focuson = false;
                }
                if(sptyp == 3)
                    rd.drawString("Checkpoint", 110 - ftm.stringWidth("Checkpoint") / 2, 120);
                if(sptyp == 4)
                    rd.drawString("Fixing Hoop", 110 - ftm.stringWidth("Fixing Hoop") / 2, 120);
                if(lsp != sp)
                {
                    seq = 3;
                    bco[sp].xy = 0;
                    bco[sp].zy = 0;
                    lsp = sp;
                    epart = false;
                    arrng = false;
                }
                if(xm > 10 && xm < 210 && ym > 130 && ym < 334)
                {
                    if(seq >= 3)
                        if(seq == 20 || !seqn)
                        {
                            seq = 0;
                            bco[sp].xy = 0;
                            bco[sp].zy = 0;
                        } else
                        {
                            seq++;
                        }
                    seqn = true;
                    rd.setColor(new Color(210, 210, 210));
                } else
                {
                    rd.setColor(new Color(200, 200, 200));
                    seqn = false;
                }
                rd.fillRect(10, 130, 200, 200);
                if((sp == 30 || sp == 32 || sp == 54) && button("  Rearrange Checkpoints  >  ", 110, 315, 2, true))
                {
                    mouses = 0;
                    epart = false;
                    if(!arrng)
                    {
                        arrcnt = 0;
                        for(int l8 = 0; l8 < nob; l8++)
                            if(co[l8].colok == 30 || co[l8].colok == 32 || co[l8].colok == 54)
                                co[l8].errd = false;

                        arrng = true;
                    } else
                    {
                        arrng = false;
                    }
                }
                if(seqn && mouses == -1)
                    if(sp != 66)
                    {
                        boolean flag5 = false;
                        if(rot == 0 && !flag5)
                        {
                            rot = 90;
                            flag5 = true;
                        }
                        if(rot == 90 && !flag5)
                        {
                            rot = 180;
                            flag5 = true;
                        }
                        if(rot == 180 && !flag5)
                        {
                            rot = -90;
                            flag5 = true;
                        }
                        if(rot == -90 && !flag5)
                        {
                            rot = 0;
                            boolean flag6 = true;
                        }
                        if(sp == 30 || sp == 31 || sp == 32)
                        {
                            if(rot == -90)
                                rot = 90;
                            if(rot == 180)
                                rot = 0;
                        }
                        seq = 5;
                        bco[sp].xy = 0;
                        bco[sp].zy = 0;
                        epart = false;
                        arrng = false;
                    } else
                    {
                        pgen = false;
                        pwd = 2L + Math.round(Math.random() * 4D);
                        phd = 2L + Math.round(Math.random() * 4D);
                    }
                if(sp == 31)
                {
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Height:", 62, 280);
                    movefield(fixh, 107, 266, 50, 20);
                    if(fixh.hasFocus())
                        focuson = false;
                    if(!fixh.isShowing())
                        fixh.show();
                    rd.setFont(new Font("Arial", 0, 11));
                    ftm = rd.getFontMetrics();
                    rd.drawString("( Height off the ground... )", 110 - ftm.stringWidth("( Height off the ground... )") / 2, 300);
                    if(fixh.getText().equals(""))
                    {
                        fixh.setText("0");
                        fixh.select(0, 0);
                    }
                    try
                    {
                        hf = Integer.valueOf(fixh.getText()).intValue();
                        if(hf > 8000)
                        {
                            hf = 8000;
                            fixh.setText("8000");
                        }
                    }
                    catch(Exception exception6)
                    {
                        hf = 2000;
                        fixh.setText("2000");
                    }
                } else
                if(fixh.isShowing())
                    fixh.hide();
                m.trk = 2;
                m.zy = 90;
                m.xz = 0;
                m.iw = 10;
                m.w = 210;
                m.ih = 130;
                m.h = 330;
                m.cx = 110;
                m.cy = 230;
                m.x = -110;
                m.z = -230;
                m.y = -15000;
                if(sptyp == 1 && sp != 20 && sp != 21 && sp != 43 && sp != 45)
                    m.y = -10000;
                if(sptyp == 2 && sp != 41)
                    m.y = -7600;
                if(sptyp == 3 || sptyp == 4)
                    m.y = -5000;
                if(sptyp == 5)
                {
                    m.y = -3000;
                    m.z = 150;
                }
                if(sptyp == 6)
                    m.y = -7600;
                if(sp == 31)
                {
                    m.z = -500;
                    if(rot != 0)
                        bco[sp].roted = true;
                    else
                        bco[sp].roted = false;
                }
                bco[sp].x = 0;
                bco[sp].y = 0;
                bco[sp].z = 0;
                bco[sp].xz = rot + adrot;
                bco[sp].d(rd);
                byte byte4 = 1;
                if(sptyp == 0 || sptyp == 1)
                {
                    if(sp != 26 && sp != 20)
                    {
                        if(rot == -90 || rot == 0)
                            byte4 = -1;
                    } else
                    {
                        if(sp == 26 && (rot == -90 || rot == 180))
                            byte4 = -1;
                        if(sp == 20 && (rot == 90 || rot == 180))
                            byte4 = -1;
                    }
                    if(seq == 2)
                    {
                        bco[sp].xy -= 5 * byte4;
                        if(bco[sp].xy == 0)
                            seq = 3;
                    }
                    if(seq == 1)
                        seq = 2;
                    if(seq == 0)
                    {
                        bco[sp].xy += 5 * byte4;
                        if(bco[sp].xy == 85 * byte4)
                            seq = 1;
                    }
                }
                if(sptyp == 2 || sptyp == 3 || sptyp == 4 || sptyp == 6)
                {
                    if(rot == -90 || rot == 180)
                        byte4 = -1;
                    if(seq == 2)
                    {
                        bco[sp].zy += 5 * byte4;
                        if(bco[sp].zy == 0)
                            seq = 3;
                    }
                    if(seq == 1)
                        seq = 2;
                    if(seq == 0)
                    {
                        bco[sp].zy -= 5 * byte4;
                        if(bco[sp].zy == -(85 * byte4))
                            seq = 1;
                    }
                }
                if(sptyp == 5)
                {
                    if(rot == -90 || rot == 180)
                        byte4 = -1;
                    boolean flag9 = false;
                    if(rot == -90 || rot == 90)
                        flag9 = true;
                    if(!flag9)
                        bco[sp].xy = 0;
                    else
                        bco[sp].zy = 0;
                    if(seq == 2)
                        if(!flag9)
                        {
                            bco[sp].zy += 5 * byte4;
                            if(bco[sp].zy == 0)
                                seq = 3;
                        } else
                        {
                            bco[sp].xy -= 5 * byte4;
                            if(bco[sp].xy == 0)
                                seq = 3;
                        }
                    if(seq == 1)
                        seq = 2;
                    if(seq == 0)
                        if(!flag9)
                        {
                            bco[sp].zy -= 5 * byte4;
                            if(bco[sp].zy == -(85 * byte4))
                                seq = 1;
                        } else
                        {
                            bco[sp].xy += 5 * byte4;
                            if(bco[sp].xy == 85 * byte4)
                                seq = 1;
                        }
                }
                if(sp != 66)
                {
                    if(button("  Rotate  ", 110, 348, 3, true))
                    {
                        boolean flag10 = false;
                        if(rot == 0 && !flag10)
                        {
                            rot = 90;
                            flag10 = true;
                        }
                        if(rot == 90 && !flag10)
                        {
                            rot = 180;
                            flag10 = true;
                        }
                        if(rot == 180 && !flag10)
                        {
                            rot = -90;
                            flag10 = true;
                        }
                        if(rot == -90 && !flag10)
                        {
                            rot = 0;
                            boolean flag11 = true;
                        }
                        if(sp == 30 || sp == 31 || sp == 32)
                        {
                            if(rot == -90)
                                rot = 90;
                            if(rot == 180)
                                rot = 0;
                        }
                        seq = 3;
                        bco[sp].xy = 0;
                        bco[sp].zy = 0;
                        epart = false;
                        arrng = false;
                    }
                } else
                if(button("  Generate New  ", 110, 348, 3, true))
                {
                    pgen = false;
                    pwd = 2L + Math.round(Math.random() * 4D);
                    phd = 2L + Math.round(Math.random() * 4D);
                }
                if(button(">", 191, 348, 3, true) && (sptyp == 0 || sptyp == 1 || sptyp == 2 || sptyp == 5))
                {
                    spart++;
                    if(spart == part.getItemCount())
                        spart = 0;
                    part.select(spart);
                    epart = false;
                    arrng = false;
                }
                if(button("<", 28, 348, 3, true) && (sptyp == 0 || sptyp == 1 || sptyp == 2 || sptyp == 5))
                {
                    spart--;
                    if(spart == -1)
                        spart = part.getItemCount() - 1;
                    part.select(spart);
                    epart = false;
                    arrng = false;
                }
                if(button("   <  Undo   ", 204, 404, 0, true))
                {
                    epart = false;
                    arrng = false;
                    if(nundo > 0)
                    {
                        nundo--;
                        bstage = undos[nundo];
                        readstage(0);
                    }
                }
                if(button("   Remove / Edit  Part   ", 172, 454, 0, true))
                {
                    if(!epart)
                        epart = true;
                    else
                        epart = false;
                    arrng = false;
                    esp = -1;
                }
                if(button("   Go to >  Startline   ", 175, 504, 0, true))
                {
                    sx = 0;
                    sz = 1500;
                }
                if(button(" About Part ", 164, 66, 3, false))
                    JOptionPane.showMessageDialog(null, discp[sp], "Stage Maker", 1);
                if(button("  Keyboard Controls  ", 691, 536, 3, false))
                    JOptionPane.showMessageDialog(null, "Instead of clicking the triangular buttons around the Building Area to scroll, you can use:\n[ Keyboard Arrows ]\n\nYou can also zoom in and out using the following keys:\n[+] & [-]  or  [8] & [2]  or  [Enter] & [Backspace]\n\n", "Stage Maker", 1);
                if(button("  Save  ", 280, 50, 0, false))
                {
                    epart = false;
                    arrng = false;
                    savefile();
                }
                if(button("  Save & Preview  ", 380, 50, 0, false))
                {
                    epart = false;
                    arrng = false;
                    savefile();
                    hidefields();
                    tab = 2;
                }
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                int k11 = 0;
                byte byte5 = 0;
                int l16 = (int)(((float)xnob / 601F) * 200F);
                k11 = l16;
                int l19 = (int)(((float)t.nt / 6700F) * 200F);
                if(l19 > k11)
                {
                    k11 = l19;
                    byte5 = 1;
                }
                int j23 = (int)(((float)cp.n / 140F) * 200F);
                if(j23 > k11)
                {
                    k11 = j23;
                    byte5 = 2;
                }
                int k24 = (int)(((float)(m.nrw * m.ncl) / 16000F) * 200F);
                if(k24 > k11)
                {
                    k11 = k24;
                    byte5 = 3;
                }
                if(k11 > 200)
                    k11 = 200;
                if(k11 <= 100)
                    rd.setColor(new Color(100 + k11, 225, 30));
                else
                    rd.setColor(new Color(200, 325 - k11, 30));
                rd.fillRect(167, 531, k11, 9);
                if(button("Memory Consumption :", 85, 540, 3, false))
                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Memory Consumption Details\n\nNumber of Parts:  ").append(l16 / 2).append(" %\nPart's Details:  ").append(l19 / 2).append(" %\nRoad Points:  ").append(j23 / 2).append(" %\nStage Area:  ").append(k24 / 2).append(" %\n \n").toString(), "Stage Maker", 1);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRect(167, 531, 200, 9);
                String as7[] = {
                    "Number of Parts", "Part's Details", "Road Points", "Stage Area"
                };
                rd.drawString(as7[byte5], 267 - ftm.stringWidth(as7[byte5]) / 2, 540);
                rd.drawString((new StringBuilder()).append("").append(k11 / 2).append(" %  used").toString(), 375, 540);
                if(overcan)
                    overcan = false;
                if(epart)
                {
                    if(esp == -1)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Click on any part to Edit >", 257, 454);
                        if(button(" Cancel ", 323, 474, 4, false))
                            epart = false;
                    }
                } else
                {
                    if(hi != -1)
                        hi = -1;
                    if(esp != -1)
                        esp = -1;
                }
                if(arrng)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Click on Checkpoint NO# ").append(arrcnt + 1).append("  >").toString(), 257, 80);
                    if(button(" Cancel ", 330, 100, 4, false))
                        arrng = false;
                    if(arrcnt == cp.nsp)
                    {
                        sortstage();
                        JOptionPane.showMessageDialog(null, "Checkpoints Arranged!\nPress Save and Test Drive to check the new checkpoint order.\n", "Stage Maker", 1);
                        arrng = false;
                    }
                } else
                if(chi != -1)
                    chi = -1;
            }
            if(tab == 2)
            {
                if(tabed != tab)
                {
                    m.trk = 0;
                    readstage(1);
                    setCursor(new Cursor(0));
                    setcur = false;
                    vxz = 0;
                    vx = sx - 400;
                    vz = sz - m.cz - 8000;
                    vy = -1500;
                    dtabed = -1;
                }
                m.trk = 0;
                m.zy = 6;
                m.iw = 10;
                m.w = 790;
                m.ih = 35;
                m.h = 445;
                m.cx = 400;
                m.cy = 215;
                m.xz = vxz;
                m.x = vx;
                m.z = vz;
                m.y = vy;
                m.d(rd);
                int l = 0;
                int ai1[] = new int[200];
                for(int k3 = 0; k3 < nob; k3++)
                    if(co[k3].dist != 0)
                    {
                        ai1[l] = k3;
                        l++;
                    } else
                    {
                        co[k3].d(rd);
                    }

                int ai4[] = new int[l];
                for(int i6 = 0; i6 < l; i6++)
                    ai4[i6] = 0;

                for(int j6 = 0; j6 < l; j6++)
                {
                    for(int i9 = j6 + 1; i9 < l; i9++)
                    {
                        if(co[ai1[j6]].dist != co[ai1[i9]].dist)
                        {
                            if(co[ai1[j6]].dist < co[ai1[i9]].dist)
                                ai4[j6]++;
                            else
                                ai4[i9]++;
                            continue;
                        }
                        if(i9 > j6)
                            ai4[j6]++;
                        else
                            ai4[i9]++;
                    }

                }

                for(int k6 = 0; k6 < l; k6++)
                {
                    for(int j9 = 0; j9 < l; j9++)
                    {
                        if(ai4[j9] != k6)
                            continue;
                        if(ai1[j9] == hi)
                            m.trk = 3;
                        co[ai1[j9]].d(rd);
                        if(m.trk == 3)
                            m.trk = 2;
                    }

                }

                if(up)
                {
                    vz += 500F * m.cos(m.xz);
                    vx += 500F * m.sin(m.xz);
                }
                if(down)
                {
                    vz -= 500F * m.cos(m.xz);
                    vx -= 500F * m.sin(m.xz);
                }
                if(left)
                    vxz -= 5;
                if(right)
                    vxz += 5;
                if(zoomi)
                {
                    vy += 100;
                    if(vy > -500)
                        vy = -500;
                }
                if(zoomo)
                {
                    vy -= 100;
                    if(vy < -5000)
                        vy = -5000;
                }
                rd.setColor(new Color(225, 225, 225));
                rd.fillRect(0, 25, 10, 525);
                rd.fillRect(790, 25, 10, 525);
                rd.fillRect(10, 25, 780, 10);
                rd.fillRect(10, 445, 780, 105);
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                String as2[] = {
                    "Controls", "Atmosphere", "Colors", "Scenery", "Laps", "Sound Track", "Test Drive"
                };
                int ai6[] = {
                    10, 10, 121, 111
                };
                int ai7[] = {
                    425, 445, 445, 425
                };
                for(int j13 = 0; j13 < 7; j13++)
                {
                    rd.setColor(new Color(170, 170, 170));
                    if(xm > ai6[0] && xm < ai6[3] && ym > 425 && ym < 445)
                        rd.setColor(new Color(190, 190, 190));
                    if(dtab == j13)
                        rd.setColor(new Color(225, 225, 225));
                    rd.fillPolygon(ai6, ai7, 4);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString(as2[j13], (j13 * 111 + 62) - ftm.stringWidth(as2[j13]) / 2, 439);
                    if(xm > ai6[0] && xm < ai6[3] && ym > 425 && ym < 445 && mouses == -1 && mouseon == -1)
                        dtab = j13;
                    for(int i17 = 0; i17 < 4; i17++)
                        ai6[i17] += 111;

                }

                if(tabed == tab && dtab != dtabed)
                {
                    if(!ttstage.equals(""))
                    {
                        tstage = ttstage;
                        ttstage = "";
                    }
                    readstage(1);
                    hidefields();
                }
                if(dtab == 0)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Use the [ Keyboard Arrows ] to navigate through the stage.", 20, 470);
                    rd.drawString("[Left] & [Right] arrows are for rotating.  [Up] & [Down] arrows are for moving forwards and backwards.", 20, 490);
                    rd.drawString("For moving vertically down and up use the following keys:  [+] & [-]  or  [8] & [2]  or  [Enter] & [Backspace]", 20, 520);
                }
                if(dtab == 2)
                {
                    if(dtabed != dtab)
                    {
                        Color.RGBtoHSB(csky[0], csky[1], csky[2], hsb[0]);
                        Color.RGBtoHSB(cfade[0], cfade[1], cfade[2], hsb[1]);
                        Color.RGBtoHSB(cgrnd[0], cgrnd[1], cgrnd[2], hsb[2]);
                        for(int k13 = 0; k13 < 3; k13++)
                        {
                            float f1 = hsb[k13][1];
                            hsb[k13][1] = hsb[k13][2];
                            hsb[k13][2] = f1;
                        }

                        if(hsb[1][1] == (hsb[0][1] + hsb[2][1]) / 2.0F && hsb[1][0] == hsb[2][0] && hsb[1][2] == hsb[2][2])
                            pfog.setState(true);
                        else
                            pfog.setState(false);
                        ttstage = "";
                        mouseon = -1;
                    }
                    if(mouses != 1)
                    {
                        if((mouseon >= 6 || mouseon < 3) && mouseon != -1)
                        {
                            if(ttstage.equals(""))
                                ttstage = tstage;
                            sortop();
                            readstage(1);
                        }
                        mouseon = -1;
                    }
                    String as3[] = {
                        "Sky", "Dust / Fog", "Ground"
                    };
                    for(int j17 = 0; j17 < 3; j17++)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString(as3[j17], (107 + 195 * j17) - ftm.stringWidth(as3[j17]) / 2, 461);
                        for(int i20 = 0; i20 < 150; i20++)
                        {
                            rd.setColor(Color.getHSBColor((float)((double)(float)i20 * 0.0066670000000000002D), 1.0F, 1.0F));
                            rd.drawLine(32 + i20 + 195 * j17, 467, 32 + i20 + 195 * j17, 474);
                        }

                        for(int j20 = 0; j20 < 150; j20++)
                        {
                            rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.5F + (float)j20 * 0.00333F));
                            rd.drawLine(32 + j20 + 195 * j17, 483, 32 + j20 + 195 * j17, 490);
                        }

                        for(int k20 = 0; k20 < 150; k20++)
                        {
                            rd.setColor(Color.getHSBColor(hsb[j17][0], 0.0F + (float)((double)(float)k20 * 0.0016670000000000001D), hsb[j17][1]));
                            rd.drawLine(32 + k20 + 195 * j17, 499, 32 + k20 + 195 * j17, 506);
                        }

                        for(int l20 = 0; l20 < 3; l20++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            float f3 = hsb[j17][l20] * 150F;
                            if(l20 == 1)
                            {
                                float f4 = 0.75F;
                                if(j17 == 0)
                                    f4 = 0.85F;
                                if(j17 == 1)
                                    f4 = 0.8F;
                                f3 = (hsb[j17][l20] - f4) / 0.001F;
                            }
                            if(l20 == 2)
                                f3 = hsb[j17][l20] * 600F;
                            if(f3 < 0.0F)
                                f3 = 0.0F;
                            if(f3 > 150F)
                                f3 = 150F;
                            rd.drawLine((int)((float)(32 + 195 * j17) + f3), 467 + l20 * 16, (int)((float)(32 + 195 * j17) + f3), 474 + l20 * 16);
                            rd.drawLine((int)((float)(33 + 195 * j17) + f3), 467 + l20 * 16, (int)((float)(33 + 195 * j17) + f3), 474 + l20 * 16);
                            rd.fillRect((int)((float)(31 + 195 * j17) + f3), 475 + l20 * 16, 4, 2);
                            rd.drawLine((int)((float)(30 + 195 * j17) + f3), 477 + l20 * 16, (int)((float)(35 + 195 * j17) + f3), 477 + l20 * 16);
                            if(xm > 29 + 195 * j17 && xm < 185 + 195 * j17 && ym > 468 + l20 * 16 && ym < 477 + l20 * 16 && mouses == 1 && mouseon == -1)
                                mouseon = l20 + j17 * 3;
                            if(mouseon != l20 + j17 * 3)
                                continue;
                            if(l20 == 0)
                                hsb[j17][l20] = (float)(xm - (32 + 195 * j17)) / 150F;
                            if(l20 == 1)
                            {
                                float f5 = 0.75F;
                                if(j17 == 0)
                                    f5 = 0.85F;
                                if(j17 == 1)
                                    f5 = 0.8F;
                                hsb[j17][l20] = f5 + (float)(xm - (32 + 195 * j17)) * 0.001F;
                                if(hsb[j17][l20] < f5)
                                    hsb[j17][l20] = f5;
                                if(hsb[j17][l20] > f5 + 0.15F)
                                    hsb[j17][l20] = f5 + 0.15F;
                            }
                            if(l20 == 2)
                            {
                                hsb[j17][l20] = (float)(xm - (32 + 195 * j17)) / 600F;
                                if((double)hsb[j17][l20] > 0.25D)
                                    hsb[j17][l20] = 0.25F;
                            }
                            if(hsb[j17][l20] > 1.0F)
                                hsb[j17][l20] = 1.0F;
                            if(hsb[j17][l20] < 0.0F)
                                hsb[j17][l20] = 0.0F;
                        }

                    }

                    movefield(pfog, 258, 511, 200, 23);
                    if(!pfog.isShowing())
                        pfog.show();
                    if(pfog.getState())
                    {
                        rd.setComposite(AlphaComposite.getInstance(3, 0.25F));
                        rd.setColor(new Color(0, 0, 0));
                        rd.fillRect(215, 464, 175, 47);
                        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                        hsb[1][1] = (hsb[0][1] + hsb[2][1]) / 2.0F;
                        hsb[1][0] = hsb[2][0];
                        hsb[1][2] = hsb[2][2];
                    }
                    Color color = Color.getHSBColor(hsb[0][0], hsb[0][2], hsb[0][1]);
                    m.setsky(color.getRed(), color.getGreen(), color.getBlue());
                    csky[0] = color.getRed();
                    csky[1] = color.getGreen();
                    csky[2] = color.getBlue();
                    color = Color.getHSBColor(hsb[1][0], hsb[1][2], hsb[1][1]);
                    m.setfade(color.getRed(), color.getGreen(), color.getBlue());
                    cfade[0] = color.getRed();
                    cfade[1] = color.getGreen();
                    cfade[2] = color.getBlue();
                    color = Color.getHSBColor(hsb[2][0], hsb[2][2], hsb[2][1]);
                    m.setgrnd(color.getRed(), color.getGreen(), color.getBlue());
                    cgrnd[0] = color.getRed();
                    cgrnd[1] = color.getGreen();
                    cgrnd[2] = color.getBlue();
                    if(button(" Reset ", 650, 510, 0, true))
                    {
                        if(!ttstage.equals(""))
                        {
                            tstage = ttstage;
                            ttstage = "";
                        }
                        readstage(1);
                        dtabed = -2;
                    }
                    if(button("        Save        ", 737, 510, 0, true))
                    {
                        sortop();
                        ttstage = "";
                        savefile();
                    }
                }
                if(dtab == 3)
                {
                    if(dtabed != dtab)
                    {
                        Color.RGBtoHSB(cldd[0], cldd[1], cldd[2], hsb[0]);
                        Color.RGBtoHSB(texture[0], texture[1], texture[2], hsb[1]);
                        mgen.setText((new StringBuilder()).append("").append(m.mgen).append("").toString());
                        mouseon = -1;
                        ttstage = "";
                    }
                    if(mouses != 1)
                    {
                        if(mouseon == 0 || mouseon == 1 || mouseon == 2 || mouseon == 6)
                        {
                            if(ttstage.equals(""))
                                ttstage = tstage;
                            sortop();
                            readstage(1);
                        }
                        mouseon = -1;
                    }
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Clouds", 32, 461);
                    for(int l13 = 0; l13 < 150; l13++)
                    {
                        rd.setColor(Color.getHSBColor((float)l13 * 0.006667F, 1.0F, 1.0F));
                        rd.drawLine(32 + l13 + 0, 467, 32 + l13 + 0, 474);
                    }

                    for(int i14 = 0; i14 < 150; i14++)
                    {
                        rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.75F + (float)i14 * 0.001667F));
                        rd.drawLine(32 + i14 + 0, 483, 32 + i14 + 0, 490);
                    }

                    for(int j14 = 0; j14 < 150; j14++)
                    {
                        rd.setColor(Color.getHSBColor(hsb[0][0], (float)j14 * 0.003333F, hsb[0][2]));
                        rd.drawLine(32 + j14 + 0, 499, 32 + j14 + 0, 506);
                    }

                    rd.setFont(new Font("Arial", 0, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Blend:", 32, 529);
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(70, 522, 112, 2);
                    rd.fillRect(70, 528, 112, 2);
                    float f = 0.0F;
                    int k17 = 255;
                    for(int i21 = 0; i21 < 112; i21++)
                    {
                        k17 = (int)(255F / (f + 1.0F));
                        if(k17 > 255)
                            k17 = 255;
                        if(k17 < 0)
                            k17 = 0;
                        f += 0.02F;
                        rd.setColor(new Color(k17, k17, k17));
                        rd.drawLine(70 + i21, 524, 70 + i21, 527);
                    }

                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Height", 202 - ftm.stringWidth("Height") / 2, 461);
                    rd.drawLine(202, 467, 202, 530);
                    for(int j21 = 0; j21 < 8; j21++)
                        rd.drawLine(202, 466 + j21 * 8, 202 + (8 - j21), 466 + j21 * 8);

                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Ground Texture", 257, 471);
                    for(int k21 = 0; k21 < 150; k21++)
                    {
                        rd.setColor(Color.getHSBColor((float)k21 * 0.006667F, 1.0F, 1.0F));
                        rd.drawLine(32 + k21 + 225, 477, 32 + k21 + 225, 484);
                    }

                    for(int l21 = 0; l21 < 150; l21++)
                    {
                        rd.setColor(Color.getHSBColor(hsb[1][0], (float)l21 * 0.006667F, (float)l21 * 0.006667F));
                        rd.drawLine(32 + l21 + 225, 493, 32 + l21 + 225, 500);
                    }

                    rd.setFont(new Font("Arial", 0, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Blend:", 257, 523);
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(295, 516, 112, 2);
                    rd.fillRect(295, 522, 112, 2);
                    f = 0.0F;
                    k17 = 255;
                    for(int i22 = 0; i22 < 112; i22++)
                    {
                        int l17 = (int)(255F / (f + 1.0F));
                        if(l17 > 255)
                            l17 = 255;
                        if(l17 < 0)
                            l17 = 0;
                        f += 0.02F;
                        rd.setColor(new Color(l17, l17, l17));
                        rd.drawLine(70 + i22 + 225, 518, 70 + i22 + 225, 521);
                    }

                    for(int j22 = 0; j22 < 2; j22++)
                    {
                        byte byte7 = 3;
                        if(j22 == 1)
                            byte7 = 2;
                        for(int l24 = 0; l24 < byte7; l24++)
                        {
                            int j26 = l24;
                            if(l24 == 1)
                                j26 = 2;
                            if(l24 == 2)
                                j26 = 1;
                            rd.setColor(new Color(0, 0, 0));
                            float f7 = hsb[j22][j26] * 150F;
                            if(l24 == 1 && j22 == 0)
                            {
                                float f8 = 0.75F;
                                f7 = (hsb[j22][j26] - f8) / 0.001667F;
                            }
                            if(l24 == 2 && j22 == 0)
                                f7 = hsb[j22][j26] / 0.003333F;
                            if(f7 < 0.0F)
                                f7 = 0.0F;
                            if(f7 > 150F)
                                f7 = 150F;
                            rd.drawLine((int)((float)(32 + 225 * j22) + f7), 467 + l24 * 16 + 10 * j22, (int)((float)(32 + 225 * j22) + f7), 474 + l24 * 16 + 10 * j22);
                            rd.drawLine((int)((float)(33 + 225 * j22) + f7), 467 + l24 * 16 + 10 * j22, (int)((float)(33 + 225 * j22) + f7), 474 + l24 * 16 + 10 * j22);
                            rd.fillRect((int)((float)(31 + 225 * j22) + f7), 475 + l24 * 16 + 10 * j22, 4, 2);
                            rd.drawLine((int)((float)(30 + 225 * j22) + f7), 477 + l24 * 16 + 10 * j22, (int)((float)(35 + 225 * j22) + f7), 477 + l24 * 16 + 10 * j22);
                            if(xm > 29 + 225 * j22 && xm < 185 + 225 * j22 && ym > 468 + l24 * 16 + 10 * j22 && ym < 477 + l24 * 16 + 10 * j22 && mouses == 1 && mouseon == -1)
                                mouseon = l24 + j22 * 3;
                            if(mouseon != l24 + j22 * 3)
                                continue;
                            hsb[j22][j26] = (float)(xm - (32 + 225 * j22)) * 0.006667F;
                            if(l24 == 1 && j22 == 1)
                            {
                                hsb[j22][1] = (float)(xm - (32 + 225 * j22)) * 0.006667F;
                                if(hsb[j22][1] > 1.0F)
                                    hsb[j22][1] = 1.0F;
                                if(hsb[j22][1] < 0.0F)
                                    hsb[j22][1] = 0.0F;
                            }
                            if(l24 == 1 && j22 == 0)
                            {
                                float f9 = 0.75F;
                                hsb[j22][j26] = f9 + (float)(xm - (32 + 225 * j22)) * 0.001667F;
                                if(hsb[j22][j26] < f9)
                                    hsb[j22][j26] = f9;
                            }
                            if(l24 == 2 && j22 == 0)
                            {
                                hsb[j22][j26] = (float)(xm - (32 + 225 * j22)) * 0.003333F;
                                if((double)hsb[j22][j26] > 0.5D)
                                    hsb[j22][j26] = 0.5F;
                            }
                            if(hsb[j22][j26] > 1.0F)
                                hsb[j22][j26] = 1.0F;
                            if(hsb[j22][j26] < 0.0F)
                                hsb[j22][j26] = 0.0F;
                        }

                        rd.setColor(new Color(0, 0, 0));
                        float f6 = (float)(texture[3] - 20) * 2.8F;
                        if(j22 == 0)
                            f6 = (float)cldd[3] * 11.2F;
                        if(f6 < 0.0F)
                            f6 = 0.0F;
                        if(f6 > 112F)
                            f6 = 112F;
                        rd.drawLine((int)((float)(70 + 225 * j22) + f6), 522 - 6 * j22, (int)((float)(70 + 225 * j22) + f6), 529 - 6 * j22);
                        rd.drawLine((int)((float)(71 + 225 * j22) + f6), 522 - 6 * j22, (int)((float)(71 + 225 * j22) + f6), 529 - 6 * j22);
                        rd.fillRect((int)((float)(69 + 225 * j22) + f6), 530 - 6 * j22, 4, 2);
                        rd.drawLine((int)((float)(68 + 225 * j22) + f6), 532 - 6 * j22, (int)((float)(73 + 225 * j22) + f6), 532 - 6 * j22);
                        if(xm > 67 + 225 * j22 && xm < 185 + 225 * j22 && ym > 522 - 6 * j22 && ym < 532 - 6 * j22 && mouses == 1 && mouseon == -1)
                            mouseon = 6 + j22;
                    }

                    if(mouseon == 6)
                    {
                        cldd[3] = (int)((float)(xm - 70) / 11.2F);
                        if(cldd[3] < 0)
                            cldd[3] = 0;
                        if(cldd[3] > 10)
                            cldd[3] = 10;
                    }
                    if(mouseon == 7)
                    {
                        texture[3] = (int)((double)(xm - 70 - 225) / 2.7999999999999998D + 20D);
                        if(texture[3] < 20)
                            texture[3] = 20;
                        if(texture[3] > 60)
                            texture[3] = 60;
                    }
                    rd.setColor(new Color(0, 128, 255));
                    float f2 = (float)(1500 - Math.abs(cldd[4])) / 15.625F;
                    if(f2 > 64F)
                        f2 = 64F;
                    if(f2 < 0.0F)
                        f2 = 0.0F;
                    rd.drawRect(199, (int)(465F + f2), 12, 2);
                    if(xm > 197 && xm < 213 && ym > 463 && ym < 533 && mouses == 1 && mouseon == -1)
                        mouseon = 8;
                    if(mouseon == 8)
                    {
                        cldd[4] = -(int)((float)(530 - ym) * 15.625F + 500F);
                        if(cldd[4] > -500)
                            cldd[4] = -500;
                        if(cldd[4] < -1500)
                            cldd[4] = -1500;
                    }
                    Color color1 = Color.getHSBColor(hsb[0][0], hsb[0][1], hsb[0][2]);
                    m.setcloads(color1.getRed(), color1.getGreen(), color1.getBlue(), cldd[3], cldd[4]);
                    cldd[0] = color1.getRed();
                    cldd[1] = color1.getGreen();
                    cldd[2] = color1.getBlue();
                    color1 = Color.getHSBColor(hsb[1][0], hsb[1][1], hsb[1][2]);
                    m.setexture(color1.getRed(), color1.getGreen(), color1.getBlue(), texture[3]);
                    texture[0] = color1.getRed();
                    texture[1] = color1.getGreen();
                    texture[2] = color1.getBlue();
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Mountains", 452, 465);
                    rd.setFont(new Font("Arial", 0, 11));
                    rd.drawString("Mountain Generator Key:", 452, 480);
                    movefield(mgen, 452, 484, 120, 20);
                    if(mgen.hasFocus())
                        focuson = false;
                    if(!mgen.isShowing())
                        mgen.show();
                    if(button("  Generate New  ", 512, 525, 3, true))
                    {
                        m.mgen = (int)(Math.random() * 100000D);
                        mgen.setText((new StringBuilder()).append("").append(m.mgen).append("").toString());
                        if(ttstage.equals(""))
                            ttstage = tstage;
                        sortop();
                        readstage(1);
                    }
                    if(!mgen.getText().equals((new StringBuilder()).append("").append(m.mgen).append("").toString()))
                        try
                        {
                            int i25 = Integer.valueOf(mgen.getText()).intValue();
                            m.mgen = i25;
                            if(ttstage.equals(""))
                                ttstage = tstage;
                            sortop();
                            readstage(1);
                        }
                        catch(Exception exception10)
                        {
                            mgen.setText((new StringBuilder()).append("").append(m.mgen).append("").toString());
                        }
                    if(button(" Reset ", 650, 510, 0, true))
                    {
                        if(!ttstage.equals(""))
                        {
                            tstage = ttstage;
                            ttstage = "";
                        }
                        readstage(1);
                        dtabed = -2;
                    }
                    if(button("        Save        ", 737, 510, 0, true))
                    {
                        sortop();
                        ttstage = "";
                        savefile();
                    }
                }
                if(dtab == 1)
                {
                    if(dtabed != dtab)
                    {
                        for(int k14 = 0; k14 < 3; k14++)
                            snap[k14] = (int)((float)m.snap[k14] / 1.2F + 50F);

                        fogn[0] = (8 - ((m.fogd + 1) / 2 - 1)) * 20;
                        fogn[1] = (m.fade[0] - 5000) / 30;
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Atmosphere RGB Mask", 20, 461);
                    rd.setColor(new Color(128, 128, 128));
                    rd.drawLine(10, 457, 17, 457);
                    rd.drawLine(260, 457, 152, 457);
                    rd.drawLine(10, 457, 10, 546);
                    rd.drawLine(260, 457, 260, 527);
                    rd.drawLine(260, 527, 360, 527);
                    rd.drawLine(10, 546, 360, 546);
                    rd.drawLine(360, 527, 360, 546);
                    String as4[] = {
                        "Red", "Green", "Blue"
                    };
                    int ai10[] = {
                        32, 20, 29
                    };
                    byte byte6 = 38;
                    int k23 = -70;
                    for(int j25 = 0; j25 < 3; j25++)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString((new StringBuilder()).append("").append(as4[j25]).append(" :").toString(), ai10[j25], 447 + j25 * 24 + byte6);
                        rd.drawLine(140 + k23, 443 + (j25 * 24 + byte6), 230 + k23, 443 + j25 * 24 + byte6);
                        for(int k26 = 1; k26 < 10; k26++)
                            rd.drawLine(140 + 10 * k26 + k23, (443 - k26) + j25 * 24 + byte6, 140 + 10 * k26 + k23, 443 + k26 + j25 * 24 + byte6);

                        rd.setColor(new Color(255, 0, 0));
                        int l26 = (int)((float)snap[j25] / 1.1111F / 10F);
                        rd.fillRect(138 + (int)((float)snap[j25] / 1.1111F) + k23, (443 - l26) + j25 * 24 + byte6, 5, l26 * 2 + 1);
                        rd.setColor(new Color(255, 128, 0));
                        rd.drawRect(139 + (int)((float)snap[j25] / 1.1111F) + k23, 434 + j25 * 24 + byte6, 2, 18);
                        if(button(" - ", 260 + k23, 447 + j25 * 24 + byte6, 4, false))
                        {
                            snap[j25] -= 2;
                            if(snap[j25] < 0)
                                snap[j25] = 0;
                        }
                        if(!button(" + ", 300 + k23, 447 + j25 * 24 + byte6, 4, false))
                            continue;
                        if(snap[0] + snap[1] + snap[2] > 200)
                        {
                            for(int j27 = 0; j27 < 3; j27++)
                            {
                                if(j27 == j25)
                                    continue;
                                snap[j27]--;
                                if(snap[j27] < 0)
                                    snap[j27] = 0;
                            }

                        }
                        snap[j25] += 2;
                        if(snap[j25] > 100)
                            snap[j25] = 100;
                    }

                    if(m.snap[0] != (int)((float)snap[0] * 1.2F - 60F) || m.snap[1] != (int)((float)snap[1] * 1.2F - 60F) || m.snap[2] != (int)((float)snap[2] * 1.2F - 60F))
                    {
                        for(int k25 = 0; k25 < 3; k25++)
                            m.snap[k25] = (int)((float)snap[k25] * 1.2F - 60F);

                        readstage(2);
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Car Lights :", 265, 541);
                    if(snap[0] + snap[1] + snap[2] > 110)
                    {
                        rd.drawString("Off", 335, 541);
                        m.lightson = false;
                    } else
                    {
                        rd.setColor(new Color(0, 200, 0));
                        rd.drawString("On", 335, 541);
                        m.lightson = true;
                    }
                    byte byte8 = 33;
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Dust/Fog Properties", 280 + byte8, 461);
                    rd.setColor(new Color(128, 128, 128));
                    rd.drawLine(270 + byte8, 457, 277 + byte8, 457);
                    rd.drawLine(540 + byte8, 457, 393 + byte8, 457);
                    rd.drawLine(270 + byte8, 457, 270 + byte8, 522);
                    rd.drawLine(540 + byte8, 457, 540 + byte8, 522);
                    rd.drawLine(270 + byte8, 522, 540 + byte8, 522);
                    String as8[] = {
                        "Density", "Near / Far"
                    };
                    int ai13[] = {
                        292 + byte8, 280 + byte8
                    };
                    int ai14[] = {
                        20, 10
                    };
                    byte6 = 38;
                    k23 = 210 + byte8;
                    for(int j29 = 0; j29 < 2; j29++)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString((new StringBuilder()).append("").append(as8[j29]).append(" :").toString(), ai13[j29], 447 + j29 * 24 + byte6);
                        rd.drawLine(140 + k23, 443 + (j29 * 24 + byte6), 230 + k23, 443 + j29 * 24 + byte6);
                        for(int k30 = 1; k30 < 10; k30++)
                            rd.drawLine(140 + 10 * k30 + k23, (443 - k30) + j29 * 24 + byte6, 140 + 10 * k30 + k23, 443 + k30 + j29 * 24 + byte6);

                        rd.setColor(new Color(255, 0, 0));
                        int l30 = (int)((float)fogn[j29] / 1.1111F / 10F);
                        rd.fillRect(138 + (int)((float)fogn[j29] / 1.1111F) + k23, (443 - l30) + j29 * 24 + byte6, 5, l30 * 2 + 1);
                        rd.setColor(new Color(255, 128, 0));
                        rd.drawRect(139 + (int)((float)fogn[j29] / 1.1111F) + k23, 434 + j29 * 24 + byte6, 2, 18);
                        if(button(" - ", 260 + k23, 447 + j29 * 24 + byte6, 4, false))
                        {
                            fogn[j29] -= ai14[j29];
                            if(fogn[j29] < 0)
                                fogn[j29] = 0;
                        }
                        if(!button(" + ", 300 + k23, 447 + j29 * 24 + byte6, 4, false))
                            continue;
                        fogn[j29] += ai14[j29];
                        if(fogn[j29] > 100)
                            fogn[j29] = 100;
                    }

                    m.fogd = ((8 - fogn[0] / 20) + 1) * 2 - 1;
                    m.fadfrom(5000 + fogn[1] * 30);
                    origfade = m.fade[0];
                    if(button(" Reset ", 650, 510, 0, true))
                        dtabed = -2;
                    if(button("        Save        ", 737, 510, 0, true))
                    {
                        sortop();
                        savefile();
                    }
                }
                if(dtab == 4)
                {
                    if(dtabed != dtab && cp.nlaps - 1 >= 0 && cp.nlaps - 1 <= 14)
                        nlaps.select(cp.nlaps - 1);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Set the number of laps for this stage:", 130, 496);
                    nlaps.move(348, 480);
                    if(!nlaps.isShowing())
                        nlaps.show();
                    if(cp.nlaps != nlaps.getSelectedIndex() + 1)
                    {
                        cp.nlaps = nlaps.getSelectedIndex() + 1;
                        requestFocus();
                    }
                    if(button(" Reset ", 530, 496, 0, true))
                        dtabed = -2;
                    if(button("        Save        ", 617, 496, 0, true))
                    {
                        sortop();
                        savefile();
                    }
                }
                if(dtab == 5)
                {
                    if(dtabed != dtab)
                    {
                        tracks.removeAll();
                        tracks.maxl = 200;
                        tracks.add(rd, "The Play List  -  MOD Tracks");
                        String as5[] = (new File("mystages/mymusic/")).list();
                        if(as5 != null)
                        {
                            for(int i18 = 0; i18 < as5.length; i18++)
                                if(as5[i18].toLowerCase().endsWith(".zip"))
                                    tracks.add(rd, as5[i18].substring(0, as5[i18].length() - 4));

                        }
                        if(ltrackname.equals(""))
                        {
                            if(trackname.equals(""))
                                tracks.select(0);
                            else
                                tracks.select(trackname);
                        } else
                        {
                            tracks.select(ltrackname);
                        }
                        mouseon = -1;
                    }
                    tracks.move(10, 450);
                    if(tracks.getWidth() != 200)
                        tracks.setSize(200, 21);
                    if(!tracks.isShowing())
                        tracks.show();
                    if(track.playing && track.loaded == 2)
                    {
                        if(button("      Stop      ", 110, 495, 2, false))
                            track.stop();
                        if(!ltrackname.equals(tracks.getSelectedItem()))
                            track.stop();
                        if(xm > 10 && xm < 210 && ym > 516 && ym < 534)
                        {
                            if(mouses == 1)
                                mouseon = 1;
                            rd.setColor(new Color(0, 164, 242));
                        } else
                        {
                            rd.setColor(new Color(120, 210, 255));
                        }
                        rd.drawRect(10, 516, 200, 18);
                        rd.setColor(new Color(200, 200, 200));
                        rd.drawLine(10, 523, 210, 523);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawLine(10, 524, 210, 524);
                        rd.drawLine(10, 525, 210, 525);
                        rd.drawLine(10, 526, 210, 526);
                        rd.setColor(new Color(255, 255, 255));
                        rd.drawLine(10, 527, 210, 527);
                        int l14 = (int)((1.0F - (float)track.sClip.stream.available() / (float)avon) * 200F);
                        if(mouseon == 1)
                        {
                            l14 = xm - 10;
                            if(l14 < 0)
                                l14 = 0;
                            if(l14 > 200)
                                l14 = 200;
                            if(mouses != 1)
                            {
                                track.sClip.stream.reset();
                                track.sClip.stream.skip((long)(((float)l14 / 200F) * (float)avon));
                                mouseon = -1;
                            }
                        }
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawRect(8 + l14, 516, 4, 18);
                        rd.setColor(new Color(0, 164, 242));
                        rd.drawLine(10 + l14, 520, 10 + l14, 518);
                        rd.drawLine(10 + l14, 530, 10 + l14, 532);
                    } else
                    if(tracks.getSelectedIndex() != 0 && button("      Play  >      ", 110, 495, 2, false))
                    {
                        if(!ltrackname.equals(tracks.getSelectedItem()))
                        {
                            track.unload();
                            track = new RadicalMod((new StringBuilder()).append("mystages/mymusic/").append(tracks.getSelectedItem()).append(".zip").toString(), 300, 8000, 125, true, false);
                            if(track.loaded == 2)
                            {
                                avon = track.sClip.stream.available();
                                ltrackname = tracks.getSelectedItem();
                            } else
                            {
                                ltrackname = "";
                            }
                        }
                        if(!ltrackname.equals(""))
                            track.play();
                        else
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Failed to load '").append(tracks.getSelectedItem()).append("', please make sure it is a valid MOD Track!").toString(), "Stage Maker", 1);
                    }
                    if(tracks.getSelectedIndex() != 0)
                    {
                        if(button("   Set as the stage's Sound Track  >   ", 330, 466, 2, false))
                        {
                            if(!ltrackname.equals(tracks.getSelectedItem()))
                            {
                                track.unload();
                                track = new RadicalMod((new StringBuilder()).append("mystages/mymusic/").append(tracks.getSelectedItem()).append(".zip").toString(), 300, 8000, 125, true, false);
                                if(track.loaded == 2)
                                {
                                    avon = track.sClip.stream.available();
                                    ltrackname = tracks.getSelectedItem();
                                } else
                                {
                                    ltrackname = "";
                                }
                            }
                            if(!ltrackname.equals(""))
                            {
                                trackname = ltrackname;
                                trackvol = (int)(220F / ((float)track.rvol / 3750F));
                                try
                                {
                                    File file = new File((new StringBuilder()).append("mystages/mymusic/").append(trackname).append(".zip").toString());
                                    tracksize = (int)(file.length() / 1024L);
                                    if(tracksize > 700)
                                    {
                                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Cannot use '").append(tracks.getSelectedItem()).append("' as the sound track!\nIts file size is bigger then 700KB.\n\n").toString(), "Stage Maker", 1);
                                        trackname = "";
                                    }
                                }
                                catch(Exception exception7)
                                {
                                    tracksize = 111;
                                }
                            } else
                            {
                                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Failed to load '").append(tracks.getSelectedItem()).append("', please make sure it is a valid MOD Track!").toString(), "Stage Maker", 1);
                            }
                        }
                        if(button("   X Delete   ", 258, 495, 2, false) && JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Are you sure you want to permanently delete this MOD Track from your Play List?\n\n").append(tracks.getSelectedItem()).append("\n\n>  If you delete this Track from the Play List you will not be able to use it for other stages as well!     \n\n").toString(), "Stage Maker", 0) == 0)
                            deltrack();
                    }
                    if(button("      Add a new Track from a file . . .     ", 330, 530, 0, false) && JOptionPane.showConfirmDialog(null, "The game only accepts Module format music files for the game ('.mod', '.xm' and '.s3m' file extensions).\nA good place to find Module Tracks is the modarchive.com, all the current Module Tracks\nthat are distributed with the game are from the modarchive.com.\n\nTo find out more about Module Tracks and to learn how to compose & remix your own\nmusic, please read the section of the Stage Maker help about it.\n\nThe Stage Maker accepts only '.mod', '.xm' & '.s3m' files or a '.zip' file containing a Module file.\nThe file size of the Module must be less the 700KB (when compressed as a zip file).\n", "Stage Maker", 0) == 0)
                    {
                        File file1 = null;
                        FileDialog filedialog = new FileDialog(new Frame(), "Stage Maker - Add MOD Track file to stage sound track play list!");
                        filedialog.setFile("*.mod;*.xm;*.s3m;*.zip");
                        filedialog.setMode(0);
                        filedialog.setVisible(true);
                        try
                        {
                            if(filedialog.getFile() != null)
                                file1 = new File((new StringBuilder()).append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString());
                        }
                        catch(Exception exception8) { }
                        if(file1 != null)
                            try
                            {
                                if(filedialog.getFile().toLowerCase().endsWith(".mod") || filedialog.getFile().toLowerCase().endsWith(".xm") || filedialog.getFile().toLowerCase().endsWith(".s3m"))
                                {
                                    File file2 = new File("mystages/mymusic/");
                                    if(!file2.exists())
                                        file2.mkdirs();
                                    String s21 = (new StringBuilder()).append("mystages/mymusic/").append(file1.getName().substring(0, file1.getName().length() - 4)).append(".zip").toString();
                                    FileInputStream fileinputstream1 = new FileInputStream(file1);
                                    ZipOutputStream zipoutputstream = new ZipOutputStream(new FileOutputStream(s21));
                                    ZipEntry zipentry1 = new ZipEntry((new StringBuilder()).append("").append(file1.getName()).append("").toString());
                                    zipentry1.setSize(file1.length());
                                    zipoutputstream.putNextEntry(zipentry1);
                                    byte abyte5[] = new byte[1024];
                                    int k29;
                                    while((k29 = fileinputstream1.read(abyte5)) > 0) 
                                        zipoutputstream.write(abyte5, 0, k29);
                                    zipoutputstream.closeEntry();
                                    zipoutputstream.close();
                                    fileinputstream1.close();
                                    file2 = new File((new StringBuilder()).append("mystages/mymusic/").append(file1.getName()).append(".zip").toString());
                                    if(file2.length() / 1024L >= 700L)
                                    {
                                        JOptionPane.showMessageDialog(null, "The selected file is larger then 700KB in size when zipped and therefore cannot be added!", "Stage Maker", 1);
                                        file2.delete();
                                    }
                                } else
                                if(file1.length() / 1024L < 700L)
                                {
                                    File file3 = new File("mystages/mymusic/");
                                    if(!file3.exists())
                                        file3.mkdirs();
                                    file3 = new File((new StringBuilder()).append("mystages/mymusic/").append(file1.getName()).append("").toString());
                                    FileInputStream fileinputstream = new FileInputStream(file1);
                                    FileOutputStream fileoutputstream = new FileOutputStream(file3);
                                    byte abyte3[] = new byte[1024];
                                    int k27;
                                    while((k27 = fileinputstream.read(abyte3)) > 0) 
                                        fileoutputstream.write(abyte3, 0, k27);
                                    fileinputstream.close();
                                    fileoutputstream.close();
                                } else
                                {
                                    JOptionPane.showMessageDialog(null, "The selected file is larger then 700KB in size and therefore cannot be added!", "Stage Maker", 1);
                                }
                                tracks.removeAll();
                                tracks.add(rd, "Select MOD Track                      ");
                                String as6[] = (new File("mystages/mymusic/")).list();
                                if(as6 != null)
                                {
                                    for(int l23 = 0; l23 < as6.length; l23++)
                                        if(as6[l23].toLowerCase().endsWith(".zip"))
                                            tracks.add(rd, as6[l23].substring(0, as6[l23].length() - 4));

                                }
                                tracks.select(file1.getName().substring(0, file1.getName().length() - 4));
                            }
                            catch(Exception exception9)
                            {
                                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to copy file! Error Deatials:\n").append(exception9).toString(), "Stage Maker", 1);
                            }
                    }
                    char c = '\310';
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Sound Track", 280 + c, 461);
                    String s18 = trackname;
                    if(s18.equals(""))
                        s18 = "No Sound Track set.";
                    else
                    if(button("   <  Remove Track   ", 378, 495, 2, false))
                        trackname = "";
                    rd.drawString(s18, 629 - ftm.stringWidth(s18) / 2, 482);
                    rd.setColor(new Color(128, 128, 128));
                    rd.drawLine(270 + c, 457, 277 + c, 457);
                    rd.drawLine(589 + c, 457, 353 + c, 457);
                    rd.drawLine(270 + c, 457, 270 + c, 497);
                    rd.drawLine(589 + c, 457, 589 + c, 497);
                    rd.drawLine(270 + c, 497, 589 + c, 497);
                    if(button(" Reset ", 576, 530, 0, true))
                    {
                        ltrackname = "";
                        dtabed = -2;
                    }
                    if(button("        Save        ", 663, 530, 0, true))
                    {
                        sortop();
                        savefile();
                    }
                }
                if(dtab == 6)
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Test Drive the Stage", 400 - ftm.stringWidth("Test Drive the Stage") / 2, 470);
                    witho.move(342, 480);
                    if(!witho.isShowing())
                        witho.show();
                    if(button("     TEST DRIVE!     ", 400, 530, 0, true))
                    {
                        savefile();
                        errd = 0;
                        readstage(3);
                        if(cp.nsp < 2)
                            errd = 7;
                        if(errd == 0)
                        {
                            Madness.testcar = stagename;
                            Madness.testdrive = witho.getSelectedIndex() + 3;
                            Madness.game();
                        } else
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error!  This stage is not ready for a test drive!\nReason:\n").append(errlo[errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                        }
                    }
                }
                if(dtabed != dtab)
                    if(dtabed == -2)
                        dtabed = -1;
                    else
                        dtabed = dtab;
            }
            if(tab == 3)
            {
                rd.setFont(new Font("Arial", 1, 13));
                rd.setColor(new Color(0, 0, 0));
                rd.drawString((new StringBuilder()).append("Publish Stage :  [ ").append(stagename).append(" ]").toString(), 30, 50);
                rd.drawString("Publishing Type :", 30, 80);
                pubtyp.move(150, 63);
                if(!pubtyp.isShowing())
                {
                    pubtyp.show();
                    pubtyp.select(1);
                }
                pubitem.move(790 - pubitem.w, 96);
                if(!pubitem.isShowing())
                    pubitem.show();
                if(pubitem.sel != 0)
                {
                    boolean flag = false;
                    for(int j2 = 0; j2 < nms; j2++)
                        if(pubitem.getSelectedItem().equals(mystages[j2]))
                            flag = true;

                    if(!flag)
                        logged = 2;
                }
                rd.setColor(new Color(0, 0, 0));
                rd.setFont(new Font("Arial", 0, 12));
                if(pubtyp.getSelectedIndex() == 0)
                {
                    rd.drawString("Private :  This means only you can have your stage in your account and no one else can add", 268, 72);
                    rd.drawString("it to their account to play it!", 268, 88);
                }
                if(pubtyp.getSelectedIndex() == 1)
                {
                    rd.drawString("Public :  This means anyone can add this stage to their account to play it, but only you can", 268, 72);
                    rd.drawString("download it to your Stage Maker and edit it (no one else but you can edit it).", 268, 88);
                }
                if(pubtyp.getSelectedIndex() == 2)
                {
                    rd.drawString("Super Public :  This means anyone can add this stage to their account to play it and can also", 268, 72);
                    rd.drawString("download it to their stage Maker, edit it and publish it.", 268, 88);
                }
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                rd.drawString("Stage Name", 180 - ftm.stringWidth("Stage Name") / 2, 138);
                rd.drawString("Created By", 400 - ftm.stringWidth("Created By") / 2, 138);
                rd.drawString("Added By", 500 - ftm.stringWidth("Added By") / 2, 138);
                rd.drawString("Publish Type", 600 - ftm.stringWidth("Publish Type") / 2, 138);
                rd.drawString("Options", 720 - ftm.stringWidth("Options") / 2, 138);
                rd.drawLine(350, 129, 350, 140);
                rd.drawLine(450, 129, 450, 140);
                rd.drawLine(550, 129, 550, 140);
                rd.drawLine(650, 129, 650, 140);
                rd.drawRect(10, 140, 780, 402);
                if(button("       Publish  >       ", 102, 110, 0, true))
                {
                    if(logged == 0)
                        JOptionPane.showMessageDialog(null, "Please login to retrieve your account first before publishing!", "Stage Maker", 1);
                    if(logged == 3 || logged == -1)
                    {
                        savefile();
                        errd = 0;
                        readstage(3);
                        if(cp.nsp < 2)
                            errd = 7;
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        if(ftm.stringWidth(stagename) > 274)
                            errd = 8;
                        if(errd == 0)
                        {
                            int i1 = 0;
                            for(int k2 = 0; k2 < pubitem.no; k2++)
                                if(pubitem.opts[k2].equals(stagename))
                                    i1 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Replace your already online stage '").append(stagename).append("' with this one?").toString(), "Stage Maker", 0);

                            if(i1 == 0)
                            {
                                setCursor(new Cursor(3));
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.setColor(new Color(225, 225, 225));
                                rd.fillRect(11, 141, 779, 401);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString("Connecting to Server...", 400 - ftm.stringWidth("Connecting to Server...") / 2, 250);
                                repaint();
                                justpubd = stagename;
                                int l2 = -1;
                                try
                                {
                                    Socket socket1 = new Socket("multiplayer.needformadness.com", 7061);
                                    BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
                                    PrintWriter printwriter1 = new PrintWriter(socket1.getOutputStream(), true);
                                    Object obj = null;
                                    printwriter1.println((new StringBuilder()).append("20|").append(tnick.getText()).append("|").append(tpass.getText()).append("|").append(stagename).append("|").append(pubtyp.getSelectedIndex()).append("|").toString());
                                    String s13 = bufferedreader1.readLine();
                                    if(s13 != null)
                                        l2 = servervalue(s13, 0);
                                    if(l2 == 0)
                                    {
                                        String s19 = " Publishing Stage ";
                                        String s20 = (new StringBuilder()).append("").append(tstage).append("\r\n").append(bstage).append("").toString();
                                        DataInputStream datainputstream4 = new DataInputStream(new ByteArrayInputStream(s20.getBytes()));
                                        for(String s22 = null; (s22 = datainputstream4.readLine()) != null;)
                                        {
                                            s22 = s22.trim();
                                            printwriter1.println(s22);
                                            rd.setColor(new Color(225, 225, 225));
                                            rd.fillRect(11, 141, 779, 401);
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString(s19, 400 - ftm.stringWidth(s19) / 2, 250);
                                            s19 = (new StringBuilder()).append("| ").append(s19).append(" |").toString();
                                            if(s19.equals("| | | | | | | | | | | | | | | | | | | | | | | |  Publishing Stage  | | | | | | | | | | | | | | | | | | | | | | | |"))
                                                s19 = " Publishing Stage ";
                                            repaint();
                                            try
                                            {
                                                Thread _tmp = thredo;
                                                Thread.sleep(10L);
                                            }
                                            catch(InterruptedException interruptedexception1) { }
                                        }

                                        printwriter1.println("QUITX1111");
                                        rd.setColor(new Color(225, 225, 225));
                                        rd.fillRect(11, 141, 779, 401);
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.drawString("Creating the stage online...", 400 - ftm.stringWidth("Creating the stage online...") / 2, 250);
                                        rd.drawString("This may take a couple of minutes, please wait...", 400 - ftm.stringWidth("This may take a couple of minutes, please wait...") / 2, 280);
                                        repaint();
                                        String s14 = bufferedreader1.readLine();
                                        if(s14 != null)
                                            l2 = servervalue(s14, 0);
                                        else
                                            l2 = -1;
                                        if(l2 == 0)
                                        {
                                            rd.setColor(new Color(225, 225, 225));
                                            rd.fillRect(11, 141, 779, 401);
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString("Uploading stage's sound track...", 400 - ftm.stringWidth("Uploading Stage's Sound Track...") / 2, 250);
                                            rd.drawString("This may take a couple of minutes, please wait...", 400 - ftm.stringWidth("This may take a couple of minutes, please wait...") / 2, 280);
                                            repaint();
                                            File file4 = new File((new StringBuilder()).append("mystages/mymusic/").append(trackname).append(".zip").toString());
                                            if(!trackname.equals("") && file4.exists())
                                            {
                                                int l27 = (int)file4.length();
                                                printwriter1.println((new StringBuilder()).append("track|").append(trackname).append("|").append(l27).append("|").toString());
                                                String s15 = bufferedreader1.readLine();
                                                if(s15 != null)
                                                    l2 = servervalue(s15, 0);
                                                else
                                                    l2 = -2;
                                                if(l2 == 0)
                                                {
                                                    FileInputStream fileinputstream2 = new FileInputStream(file4);
                                                    byte abyte6[] = new byte[l27];
                                                    fileinputstream2.read(abyte6);
                                                    fileinputstream2.close();
                                                    DataOutputStream dataoutputstream = new DataOutputStream(socket1.getOutputStream());
                                                    dataoutputstream.write(abyte6, 0, l27);
                                                    String s16 = bufferedreader1.readLine();
                                                    if(s16 != null)
                                                        l2 = servervalue(s16, 0);
                                                    else
                                                        l2 = -2;
                                                }
                                                if(l2 == -67)
                                                    l2 = 0;
                                            } else
                                            {
                                                printwriter1.println("END");
                                                String s17 = bufferedreader1.readLine();
                                            }
                                        }
                                    }
                                    socket1.close();
                                }
                                catch(Exception exception2)
                                {
                                    l2 = -1;
                                }
                                setCursor(new Cursor(0));
                                boolean flag2 = false;
                                if(l2 == 0)
                                {
                                    logged = 1;
                                    flag2 = true;
                                }
                                if(l2 == 3)
                                {
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to publish stage.\nReason:\n").append(errlo[8]).append("\n\n").toString(), "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 == 4)
                                {
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to publish stage.\nReason:\nStage name used (").append(stagename).append(").\nThe name '").append(stagename).append("' is already used by another published stage.\nPlease rename your stage.\n\n").toString(), "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 == 5)
                                {
                                    JOptionPane.showMessageDialog(null, "Unable to create stage online!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 > 5)
                                {
                                    JOptionPane.showMessageDialog(null, "Unable to publish stage fully!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 == -4)
                                {
                                    logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!\nReason:\nAnother MOD Track is already uploaded with the same name, please rename your Track.\nOpen your 'mystages' folder then open 'mymusic' to find your MOD Track to rename it.\n\n", "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 == -3)
                                {
                                    logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!\nReason:\nYour MOD Track\u2019s file size is too large, Track file size must be less then 700KB to be accepted.\n\n", "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(l2 == -2)
                                {
                                    logged = 1;
                                    JOptionPane.showMessageDialog(null, "Unable to upload sound track!  Unknown Error.  Please try again later.", "Stage Maker", 1);
                                    flag2 = true;
                                }
                                if(!flag2)
                                    JOptionPane.showMessageDialog(null, "Unable to publish stage!  Unknown Error.", "Stage Maker", 1);
                            }
                        } else
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error!  This stage is not ready for publishing!\nReason:\n").append(errlo[errd - 1]).append("\n\n").toString(), "Stage Maker", 0);
                        }
                    }
                }
                if(logged == 3)
                {
                    for(int j1 = 0; j1 < nms; j1++)
                    {
                        rd.setColor(new Color(235, 235, 235));
                        if(xm > 11 && xm < 789 && ym > 142 + j1 * 20 && ym < 160 + j1 * 20)
                            rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(11, 142 + j1 * 20, 778, 18);
                        rd.setFont(new Font("Arial", 0, 12));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString(mystages[j1], 180 - ftm.stringWidth(mystages[j1]) / 2, 156 + j1 * 20);
                        rd.setColor(new Color(155, 155, 155));
                        rd.drawLine(350, 145 + j1 * 20, 350, 157 + j1 * 20);
                        if(pubt[j1] != -1)
                        {
                            rd.drawLine(450, 145 + j1 * 20, 450, 157 + j1 * 20);
                            rd.drawLine(550, 145 + j1 * 20, 550, 157 + j1 * 20);
                            rd.drawLine(650, 145 + j1 * 20, 650, 157 + j1 * 20);
                            boolean flag1 = false;
                            if(maker[j1].toLowerCase().equals(tnick.getText().toLowerCase()))
                            {
                                flag1 = true;
                                rd.setColor(new Color(0, 64, 0));
                                rd.drawString("You", 400 - ftm.stringWidth("You") / 2, 156 + j1 * 20);
                            } else
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString(maker[j1], 400 - ftm.stringWidth(maker[j1]) / 2, 156 + j1 * 20);
                            }
                            if(nad[j1] > 1)
                            {
                                if(ovbutton((new StringBuilder()).append("").append(nad[j1]).append(" Players").toString(), 500, 156 + j1 * 20))
                                {
                                    String s6 = (new StringBuilder()).append("[ ").append(mystages[j1]).append(" ]  has been added by the following players to their accounts:     \n\n").toString();
                                    int l6 = 0;
                                    for(int k9 = 0; k9 < nad[j1]; k9++)
                                    {
                                        if(++l6 == 17)
                                        {
                                            s6 = (new StringBuilder()).append(s6).append("\n").toString();
                                            l6 = 1;
                                        }
                                        s6 = (new StringBuilder()).append(s6).append(addeda[j1][k9]).toString();
                                        if(k9 == nad[j1] - 1)
                                            continue;
                                        if(k9 != nad[j1] - 2)
                                        {
                                            s6 = (new StringBuilder()).append(s6).append(", ").toString();
                                            continue;
                                        }
                                        if(l6 == 16)
                                        {
                                            s6 = (new StringBuilder()).append(s6).append("\nand ").toString();
                                            l6 = 0;
                                        } else
                                        {
                                            s6 = (new StringBuilder()).append(s6).append(" and ").toString();
                                        }
                                    }

                                    s6 = (new StringBuilder()).append(s6).append("\n \n \n").toString();
                                    JOptionPane.showMessageDialog(null, s6, "Stage Maker", 1);
                                }
                            } else
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("None", 500 - ftm.stringWidth("None") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 0)
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("Private", 600 - ftm.stringWidth("Private") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 1)
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("Public", 600 - ftm.stringWidth("Public") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 2)
                            {
                                rd.setColor(new Color(0, 64, 0));
                                rd.drawString("Super Public", 600 - ftm.stringWidth("Super Public") / 2, 156 + j1 * 20);
                            }
                            if((pubt[j1] == 2 || flag1) && ovbutton("Download", 700, 156 + j1 * 20))
                            {
                                int l3 = 0;
                                for(int i7 = 0; i7 < slstage.getItemCount(); i7++)
                                    if(mystages[j1].equals(slstage.getItem(i7)))
                                        l3 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Replace the local ").append(mystages[j1]).append(" in your 'mystages' folder with the published online copy?").toString(), "Stage Maker", 0);

                                if(l3 == 0)
                                {
                                    setCursor(new Cursor(3));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(225, 225, 225));
                                    rd.fillRect(11, 141, 779, 401);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("Downloading stage, please wait...", 400 - ftm.stringWidth("Downloading stage, please wait...") / 2, 250);
                                    repaint();
                                    try
                                    {
                                        String s7 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(mystages[j1]).append(".radq?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                                        s7 = s7.replace(' ', '_');
                                        URL url2 = new URL(s7);
                                        int i15 = url2.openConnection().getContentLength();
                                        DataInputStream datainputstream2 = new DataInputStream(url2.openStream());
                                        byte abyte0[] = new byte[i15];
                                        datainputstream2.readFully(abyte0);
                                        datainputstream2.close();
                                        ZipInputStream zipinputstream;
                                        if(abyte0[0] == 80 && abyte0[1] == 75 && abyte0[2] == 3)
                                        {
                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte0));
                                        } else
                                        {
                                            byte abyte2[] = new byte[i15 - 40];
                                            for(int l25 = 0; l25 < i15 - 40; l25++)
                                            {
                                                byte byte9 = 20;
                                                if(l25 >= 500)
                                                    byte9 = 40;
                                                abyte2[l25] = abyte0[l25 + byte9];
                                            }

                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte2));
                                        }
                                        ZipEntry zipentry = zipinputstream.getNextEntry();
                                        if(zipentry != null)
                                        {
                                            String s23 = "";
                                            int i27 = Integer.valueOf(zipentry.getName()).intValue();
                                            byte abyte4[] = new byte[i27];
                                            int j28 = 0;
                                            int l29;
                                            for(; i27 > 0; i27 -= l29)
                                            {
                                                l29 = zipinputstream.read(abyte4, j28, i27);
                                                j28 += l29;
                                            }

                                            String s24 = new String(abyte4);
                                            s24 = (new StringBuilder()).append(s24).append("\n").toString();
                                            String s25 = "";
                                            int k31 = 0;
                                            int l31 = s24.indexOf("\n", 0);
                                            do
                                            {
                                                if(l31 == -1 || k31 >= s24.length())
                                                    break;
                                                String s26 = s24.substring(k31, l31);
                                                s26 = s26.trim();
                                                k31 = l31 + 1;
                                                l31 = s24.indexOf("\n", k31);
                                                if(!s26.startsWith("stagemaker(") && !s26.startsWith("publish("))
                                                {
                                                    s25 = (new StringBuilder()).append(s25).append("").append(s26).append("\r\n").toString();
                                                } else
                                                {
                                                    s25 = s25.trim();
                                                    s25 = (new StringBuilder()).append(s25).append("\r\n").toString();
                                                }
                                                if(s26.startsWith("soundtrack"))
                                                    s23 = getstring("soundtrack", s26, 0);
                                            } while(true);
                                            s25 = s25.trim();
                                            s25 = (new StringBuilder()).append(s25).append("\r\n\r\n").toString();
                                            File file5 = new File("mystages/");
                                            if(!file5.exists())
                                                file5.mkdirs();
                                            file5 = new File((new StringBuilder()).append("mystages/").append(mystages[j1]).append(".txt").toString());
                                            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file5));
                                            bufferedwriter.write(s25);
                                            bufferedwriter.close();
                                            bufferedwriter = null;
                                            zipinputstream.close();
                                            if(!s23.equals(""))
                                                try
                                                {
                                                    rd.setColor(new Color(0, 0, 0));
                                                    rd.drawString("Downloading stage's sound track...", 400 - ftm.stringWidth("Downloading stage's sound track...") / 2, 280);
                                                    repaint();
                                                    String s8 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/music/").append(s23).append(".zip").toString();
                                                    s8 = s8.replace(' ', '_');
                                                    URL url3 = new URL(s8);
                                                    int j15 = url3.openConnection().getContentLength();
                                                    File file6 = new File((new StringBuilder()).append("mystages/mymusic/").append(s23).append(".zip").toString());
                                                    if(file6.exists())
                                                        if(file6.length() == (long)j15)
                                                            l3 = 1;
                                                        else
                                                            l3 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Another track named '").append(s23).append("' already exists in your Sound Tracks folder!\nReplace it with the one attached to this stage?").toString(), "Stage Maker", 0);
                                                    if(l3 == 0)
                                                    {
                                                        DataInputStream datainputstream3 = new DataInputStream(url3.openStream());
                                                        byte abyte1[] = new byte[j15];
                                                        datainputstream3.readFully(abyte1);
                                                        datainputstream3.close();
                                                        FileOutputStream fileoutputstream1 = new FileOutputStream(file6);
                                                        fileoutputstream1.write(abyte1);
                                                        fileoutputstream1.close();
                                                        fileoutputstream1 = null;
                                                    }
                                                }
                                                catch(Exception exception13) { }
                                            setCursor(new Cursor(0));
                                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("").append(mystages[j1]).append(" has been successfully downloaded!").toString(), "Stage Maker", 1);
                                        } else
                                        {
                                            JOptionPane.showMessageDialog(null, "Unable to download stage.  Unknown Error!     \nPlease try again later.", "Stage Maker", 1);
                                        }
                                    }
                                    catch(Exception exception5)
                                    {
                                        JOptionPane.showMessageDialog(null, "Unable to download stage.  Unknown Error!     \nPlease try again later.", "Stage Maker", 1);
                                    }
                                }
                            }
                        } else
                        {
                            rd.drawString("-    Error Loading this stage's info!    -", 550 - ftm.stringWidth("-    Error Loading this stage's info!    -") / 2, 156 + j1 * 20);
                        }
                        if(!ovbutton("X", 765, 156 + j1 * 20) || JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Remove ").append(mystages[j1]).append(" from your account?").toString(), "Stage Maker", 0) != 0)
                            continue;
                        setCursor(new Cursor(3));
                        int i3 = -1;
                        try
                        {
                            Socket socket2 = new Socket("multiplayer.needformadness.com", 7061);
                            BufferedReader bufferedreader2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
                            PrintWriter printwriter2 = new PrintWriter(socket2.getOutputStream(), true);
                            printwriter2.println((new StringBuilder()).append("19|").append(tnick.getText()).append("|").append(tpass.getText()).append("|").append(mystages[j1]).append("|").toString());
                            String s11 = bufferedreader2.readLine();
                            if(s11 != null)
                                i3 = servervalue(s11, 0);
                            socket2.close();
                        }
                        catch(Exception exception3)
                        {
                            i3 = -1;
                        }
                        if(i3 == 0)
                        {
                            logged = 1;
                        } else
                        {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Failed to remove ").append(mystages[j1]).append(" from your account.  Unknown Error!     \nPlease try again later.").toString(), "Stage Maker", 1);
                        }
                    }

                }
                if(logged == 2)
                {
                    mystages[roto] = pubitem.getSelectedItem();
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(225, 225, 225));
                    rd.fillRect(50, 150, 600, 150);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Loading ").append(mystages[roto]).append("\u2018s info...").toString(), 400 - ftm.stringWidth((new StringBuilder()).append("Loading ").append(mystages[roto]).append("\u2018s info...").toString()) / 2, 220);
                    repaint();
                    maker[roto] = "Unkown";
                    pubt[roto] = -1;
                    nad[roto] = 0;
                    String s1 = "";
                    try
                    {
                        String s3 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(mystages[roto]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                        s3 = s3.replace(' ', '_');
                        URL url = new URL(s3);
                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                        do
                        {
                            String s2;
                            if((s2 = datainputstream.readLine()) == null)
                                break;
                            s2 = (new StringBuilder()).append("").append(s2.trim()).toString();
                            if(s2.startsWith("details"))
                            {
                                maker[roto] = getSvalue("details", s2, 0);
                                pubt[roto] = getvalue("details", s2, 1);
                                boolean flag7 = false;
                                while(!flag7) 
                                {
                                    addeda[roto][nad[roto]] = getSvalue("details", s2, 2 + nad[roto]);
                                    if(addeda[roto][nad[roto]].equals(""))
                                        flag7 = true;
                                    else
                                        nad[roto]++;
                                }
                            }
                        } while(true);
                        nms++;
                        if(nms > 20)
                            nms = 20;
                        roto++;
                        if(roto >= 20)
                            roto = 0;
                    }
                    catch(Exception exception) { }
                    setCursor(new Cursor(0));
                    logged = 3;
                }
                if(logged == -1)
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Ready to publish...", 400 - ftm.stringWidth("Ready to publish...") / 2, 220);
                    rd.drawString((new StringBuilder()).append("Click \u2018Publish\u2019 above to add stage: '").append(stagename).append("'.").toString(), 400 - ftm.stringWidth((new StringBuilder()).append("Click \u2018Publish\u2019 above to add stage: '").append(stagename).append("'.").toString()) / 2, 280);
                }
                if(logged == 1)
                {
                    rd.setColor(new Color(225, 225, 225));
                    rd.fillRect(11, 141, 779, 401);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Loading your account's stage list...", 400 - ftm.stringWidth("Loading your account's stage list...") / 2, 220);
                    repaint();
                    pubitem.removeAll();
                    pubitem.add(rd, "Account Stage");
                    nms = 0;
                    roto = 0;
                    int k1 = 0;
                    String s4 = "";
                    try
                    {
                        URL url1 = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/lists/").append(tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                        DataInputStream datainputstream1 = new DataInputStream(url1.openStream());
                        do
                        {
                            String s5;
                            if((s5 = datainputstream1.readLine()) == null)
                                break;
                            s5 = (new StringBuilder()).append("").append(s5.trim()).toString();
                            if(s5.startsWith("mystages"))
                            {
                                boolean flag8 = true;
                                while(flag8 && k1 < 700) 
                                {
                                    String s12 = getSvalue("mystages", s5, k1);
                                    if(s12.equals(""))
                                    {
                                        flag8 = false;
                                    } else
                                    {
                                        pubitem.add(rd, s12);
                                        k1++;
                                    }
                                }
                            }
                        } while(true);
                        setCursor(new Cursor(0));
                        logged = -1;
                        datainputstream1.close();
                    }
                    catch(Exception exception4)
                    {
                        String s9 = (new StringBuilder()).append("").append(exception4).toString();
                        if(s9.indexOf("FileNotFound") != -1)
                        {
                            setCursor(new Cursor(0));
                            logged = -1;
                        } else
                        {
                            logged = 0;
                            JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Stage Maker", 1);
                        }
                    }
                    if(!justpubd.equals(""))
                    {
                        pubitem.select(justpubd);
                        justpubd = "";
                    }
                }
                if(logged == 0)
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Login to Retrieve your Account Stages", 400 - ftm.stringWidth("Login to Retrieve your Account Stages") / 2, 220);
                    rd.drawString("Nickname:", 376 - ftm.stringWidth("Nickname:") - 14, 266);
                    if(!tnick.isShowing())
                        tnick.show();
                    movefield(tnick, 376, 250, 129, 23);
                    rd.drawString("Password:", 376 - ftm.stringWidth("Password:") - 14, 296);
                    if(!tpass.isShowing())
                        tpass.show();
                    movefield(tpass, 376, 280, 129, 23);
                    if(button("       Login       ", 400, 340, 0, true))
                    {
                        setCursor(new Cursor(3));
                        int l1 = -1;
                        try
                        {
                            Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                            printwriter.println((new StringBuilder()).append("1|").append(tnick.getText().toLowerCase()).append("|").append(tpass.getText()).append("|").toString());
                            String s10 = bufferedreader.readLine();
                            if(s10 != null)
                                l1 = servervalue(s10, 0);
                            socket.close();
                        }
                        catch(Exception exception1)
                        {
                            l1 = -1;
                        }
                        if(l1 == 0 || l1 == 3 || l1 > 10)
                        {
                            tnick.hide();
                            tpass.hide();
                            logged = 1;
                            savesettings();
                        }
                        if(l1 == 1 || l1 == 2)
                        {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Sorry.  Incorrect Nickname or Password!", "Stage Maker", 0);
                        }
                        if(l1 == -167)
                        {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Sorry.  Your trial account cannot publish stages.  Please upgrade to a full account!   ", "Stage Maker", 0);
                        }
                        if(l1 == -1)
                        {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Stage Maker", 1);
                        }
                    }
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Register a full account or if you have a trial account upgrade it!", 400 - ftm.stringWidth("Register a full account or if you have a trial account upgrade it!") / 2, 450);
                    if(button("   Register!   ", 340, 480, 0, true))
                        Madness.openurl("http://multiplayer.needformadness.com/register.html");
                    if(button("   Upgrade!   ", 460, 480, 0, true))
                        Madness.openurl("http://multiplayer.needformadness.com/edit.pl?display=upgrade");
                    rd.setFont(new Font("Arial", 0, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("You need a full account to publish your stages to the multiplayer game!", 400 - ftm.stringWidth("You need a full account to publish your stages to the multiplayer game!") / 2, 505);
                }
            }
            if(tabed != tab)
                if(tabed == -2)
                    tabed = -1;
                else
                    tabed = tab;
            rd.setColor(new Color(0, 0, 0));
            rd.fillRect(0, 0, 800, 25);
            if(!onbtgame)
                rd.drawImage(btgame[0], 620, 0, null);
            else
                rd.drawImage(btgame[1], 620, 0, null);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            String as1[] = {
                "Stage", "Build", "View & Edit", "Publish"
            };
            int ai2[] = {
                0, 0, 100, 90
            };
            int ai5[] = {
                0, 25, 25, 0
            };
            byte byte3 = 4;
            if(stagename.equals("") || sfase != 0)
            {
                tab = 0;
                byte3 = 1;
            }
            for(int l9 = 0; l9 < byte3; l9++)
            {
                rd.setColor(new Color(170, 170, 170));
                if(xm > ai2[0] && xm < ai2[3] && ym > 0 && ym < 25)
                    rd.setColor(new Color(200, 200, 200));
                if(tab == l9)
                    rd.setColor(new Color(225, 225, 225));
                rd.fillPolygon(ai2, ai5, 4);
                rd.setColor(new Color(0, 0, 0));
                rd.drawString(as1[l9], (l9 * 100 + 45) - ftm.stringWidth(as1[l9]) / 2, 17);
                if(xm > ai2[0] && xm < ai2[3] && ym > 0 && ym < 25 && mouses == -1)
                    tab = l9;
                for(int l11 = 0; l11 < 4; l11++)
                    ai2[l11] += 100;

            }

            if(mouses == -1)
                mouses = 0;
            drawms();
            repaint();
            if(!exwist)
                try
                {
                    Thread _tmp1 = thredo;
                    Thread.sleep(40L);
                }
                catch(InterruptedException interruptedexception) { }
        } while(true);
        track.unload();
        track = null;
        rd.dispose();
        System.gc();
        if(Madness.endadv == 2)
            Madness.advopen();
    }

    public void removesp()
    {
        if(nundo < 5000)
        {
            undos[nundo] = bstage;
            nundo++;
        }
        String s = "";
        if(co[esp].colok != 30 && co[esp].colok != 31 && co[esp].colok != 32 && co[esp].colok != 66)
            s = (new StringBuilder()).append("set(").append(co[esp].colok + 10).append(",").append(co[esp].x).append(",").append(co[esp].z).append(",").append(co[esp].roofat).append(")").toString();
        if(co[esp].colok == 31)
            s = (new StringBuilder()).append("fix(").append(co[esp].colok + 10).append(",").append(co[esp].x).append(",").append(co[esp].z).append(",").append(co[esp].y).append(",").append(co[esp].roofat).append(")").toString();
        if(co[esp].colok == 30 || co[esp].colok == 32)
            s = (new StringBuilder()).append("chk(").append(co[esp].colok + 10).append(",").append(co[esp].x).append(",").append(co[esp].z).append(",").append(co[esp].roofat).append(")").toString();
        if(co[esp].colok == 54)
            s = (new StringBuilder()).append("chk(").append(co[esp].colok + 10).append(",").append(co[esp].x).append(",").append(co[esp].z).append(",").append(co[esp].roofat).append(",").append(co[esp].y).append(")").toString();
        if(co[esp].colok == 66)
            s = (new StringBuilder()).append("pile(").append(co[esp].srz).append(",").append(co[esp].srx).append(",").append(co[esp].sry).append(",").append(co[esp].x).append(",").append(co[esp].z).append(")").toString();
        int i = bstage.indexOf(s);
        int j = i + s.length();
        int k = -1;
        int l = bstage.indexOf("set", j);
        if(l != -1)
            k = l;
        l = bstage.indexOf("chk", j);
        if(l != -1 && l < k)
            k = l;
        l = bstage.indexOf("fix", j);
        if(l != -1 && l < k)
            k = l;
        if(k == -1)
        {
            k = bstage.indexOf("\r\n", j);
            if(k != -1)
                k++;
        }
        if(k != -1)
            j = k;
        if(i != -1)
            bstage = (new StringBuilder()).append("").append(bstage.substring(0, i)).append("").append(bstage.substring(j, bstage.length())).append("").toString();
        readstage(0);
    }

    public void copyesp(boolean flag)
    {
        sp = co[esp].colok;
        rot = co[esp].roofat;
        if(sp == 2)
            rot -= 30;
        if(sp == 3)
            rot += 30;
        if(sp == 15)
            rot += 90;
        if(sp == 20)
            rot += 180;
        if(sp == 26)
            rot -= 90;
        if(sp == 0)
        {
            sptyp = 0;
            spart = 0;
        }
        if(sp == 4)
        {
            sptyp = 0;
            spart = 1;
        }
        if(sp == 13)
        {
            sptyp = 0;
            spart = 2;
        }
        if(sp == 3)
        {
            sptyp = 0;
            spart = 3;
        }
        if(sp == 2)
        {
            sptyp = 0;
            spart = 4;
        }
        if(sp == 1)
        {
            sptyp = 0;
            spart = 5;
        }
        if(sp == 35)
        {
            sptyp = 0;
            spart = 6;
        }
        if(sp == 36)
        {
            sptyp = 0;
            spart = 7;
        }
        if(sp == 10)
        {
            sptyp = 0;
            spart = 8;
        }
        if(sp == 5)
        {
            sptyp = 0;
            spart = 9;
        }
        if(sp == 7)
        {
            sptyp = 0;
            spart = 10;
        }
        if(sp == 14)
        {
            sptyp = 0;
            spart = 11;
        }
        if(sp == 6)
        {
            sptyp = 0;
            spart = 12;
        }
        if(sp == 34)
        {
            sptyp = 0;
            spart = 13;
        }
        if(sp == 33)
        {
            sptyp = 0;
            spart = 14;
        }
        if(sp == 11)
        {
            sptyp = 0;
            spart = 15;
        }
        if(sp == 8)
        {
            sptyp = 0;
            spart = 16;
        }
        if(sp == 9)
        {
            sptyp = 0;
            spart = 17;
        }
        if(sp == 15)
        {
            sptyp = 0;
            spart = 18;
        }
        if(sp == 12)
        {
            sptyp = 0;
            spart = 19;
        }
        if(sp == 46)
        {
            sptyp = 0;
            spart = 20;
        }
        if(sp == 47)
        {
            sptyp = 0;
            spart = 21;
        }
        if(sp == 48)
        {
            sptyp = 0;
            spart = 23;
        }
        if(sp == 49)
        {
            sptyp = 0;
            spart = 24;
        }
        if(sp == 50)
        {
            sptyp = 0;
            spart = 22;
        }
        if(sp == 51)
        {
            sptyp = 0;
            spart = 25;
        }
        if(sp == 16)
        {
            sptyp = 1;
            spart = 0;
        }
        if(sp == 18)
        {
            sptyp = 1;
            spart = 1;
        }
        if(sp == 19)
        {
            sptyp = 1;
            spart = 2;
        }
        if(sp == 22)
        {
            sptyp = 1;
            spart = 3;
        }
        if(sp == 17)
        {
            sptyp = 1;
            spart = 4;
        }
        if(sp == 21)
        {
            sptyp = 1;
            spart = 5;
        }
        if(sp == 20)
        {
            sptyp = 1;
            spart = 6;
        }
        if(sp == 39)
        {
            sptyp = 1;
            spart = 7;
        }
        if(sp == 42)
        {
            sptyp = 1;
            spart = 8;
        }
        if(sp == 40)
        {
            sptyp = 1;
            spart = 9;
        }
        if(sp == 23)
        {
            sptyp = 1;
            spart = 10;
        }
        if(sp == 25)
        {
            sptyp = 1;
            spart = 11;
        }
        if(sp == 24)
        {
            sptyp = 1;
            spart = 12;
        }
        if(sp == 43)
        {
            sptyp = 1;
            spart = 13;
        }
        if(sp == 45)
        {
            sptyp = 1;
            spart = 14;
        }
        if(sp == 26)
        {
            sptyp = 1;
            spart = 15;
        }
        if(sp == 27)
        {
            sptyp = 2;
            spart = 0;
        }
        if(sp == 28)
        {
            sptyp = 2;
            spart = 1;
        }
        if(sp == 41)
        {
            sptyp = 2;
            spart = 2;
        }
        if(sp == 44)
        {
            sptyp = 2;
            spart = 3;
        }
        if(sp == 52)
        {
            sptyp = 2;
            spart = 4;
        }
        if(sp == 53)
        {
            sptyp = 2;
            spart = 5;
        }
        if(sp == 30 || sp == 32 || sp == 54)
        {
            sptyp = 3;
            spart = 0;
        }
        if(sp == 31)
        {
            sptyp = 4;
            spart = 0;
        }
        if(sp == 55)
        {
            sptyp = 5;
            spart = 0;
        }
        if(sp == 56)
        {
            sptyp = 5;
            spart = 1;
        }
        if(sp == 57)
        {
            sptyp = 5;
            spart = 2;
        }
        if(sp == 58)
        {
            sptyp = 5;
            spart = 3;
        }
        if(sp == 59)
        {
            sptyp = 5;
            spart = 4;
        }
        if(sp == 60)
        {
            sptyp = 5;
            spart = 5;
        }
        if(sp == 61)
        {
            sptyp = 5;
            spart = 6;
        }
        if(sp == 62)
        {
            sptyp = 5;
            spart = 7;
        }
        if(sp == 63)
        {
            sptyp = 5;
            spart = 8;
        }
        if(sp == 64)
        {
            sptyp = 5;
            spart = 9;
        }
        if(sp == 65)
        {
            sptyp = 5;
            spart = 10;
        }
        if(sp == 66)
        {
            if(flag)
                fgen = co[esp].srz;
            else
                fgen = 0;
            pwd = co[esp].srx;
            phd = co[esp].sry;
            pgen = false;
            sptyp = 6;
        }
        if(sptyp == 0)
        {
            partroads();
            part.show();
        }
        if(sptyp == 1)
        {
            partramps();
            part.show();
        }
        if(sptyp == 2)
        {
            partobst();
            part.show();
        }
        if(sptyp == 5)
        {
            partrees();
            part.show();
        }
        ptyp.select(sptyp);
        part.select(spart);
    }

    public void partrees()
    {
        part.removeAll();
        part.add(rd, "Tree 1");
        part.add(rd, "Tree 2");
        part.add(rd, "Tree 3");
        part.add(rd, "Tree 4");
        part.add(rd, "Tree 5");
        part.add(rd, "Palm Tree 1");
        part.add(rd, "Palm Tree 2");
        part.add(rd, "Palm Tree 3");
        part.add(rd, "Cactus 1");
        part.add(rd, "Cactus 2");
        part.add(rd, "Cactus 3");
    }

    public void partroads()
    {
        part.removeAll();
        part.add(rd, "NormalRoad");
        part.add(rd, "NormalRoad Turn");
        part.add(rd, "NormalRoad End");
        part.add(rd, "NormalRoad TwistedLeft");
        part.add(rd, "NormalRoad TwistedRight");
        part.add(rd, "NormalRoad Edged");
        part.add(rd, "NormalRoad-Raised Ramp");
        part.add(rd, "NormalRoad Raised");
        part.add(rd, "Normal-Off-Road Blend");
        part.add(rd, "OffRoad");
        part.add(rd, "OffRoad Turn");
        part.add(rd, "OffRoad End");
        part.add(rd, "OffRoad BumpyGreen");
        part.add(rd, "OffRoad-BumpySides Start");
        part.add(rd, "OffRoad BumpySides");
        part.add(rd, "Off-Halfpipe-Road Blend");
        part.add(rd, "HalfpipeRoad");
        part.add(rd, "HalfpipeRoad Turn");
        part.add(rd, "HalfpipeRoad-Ramp Filler");
        part.add(rd, "Halfpipe-Normal-Road Blend");
        part.add(rd, "Rollercoaster Start/End");
        part.add(rd, "Rollercoaster Road1");
        part.add(rd, "Rollercoaster Road2");
        part.add(rd, "Rollercoaster Road3");
        part.add(rd, "Rollercoaster Road4");
        part.add(rd, "Rollercoaster Road5");
    }

    public void partramps()
    {
        part.removeAll();
        part.add(rd, "Basic Ramp");
        part.add(rd, "Two-Way Ramp");
        part.add(rd, "Two-Way High-Low Ramp");
        part.add(rd, "Small Ramp");
        part.add(rd, "Crash Ramp");
        part.add(rd, "Big-Takeoff Ramp");
        part.add(rd, "Landing Ramp");
        part.add(rd, "Tunnel Side Ramp");
        part.add(rd, "Speed Ramp");
        part.add(rd, "Launch Pad Ramp");
        part.add(rd, "Offroad Bump Ramp");
        part.add(rd, "Offroad Ramp");
        part.add(rd, "Offroad Big Ramp");
        part.add(rd, "Offroad Hill Ramp");
        part.add(rd, "Offroad Big Hill Ramp");
        part.add(rd, "Halfpipe");
    }

    public void partobst()
    {
        part.removeAll();
        part.add(rd, "Spiky Pillars");
        part.add(rd, "Rail Doorway");
        part.add(rd, "The Net");
        part.add(rd, "Bump Slide");
        part.add(rd, "Offroad Dirt-Pile 1");
        part.add(rd, "Offroad Dirt-Pile 2");
    }

    public void init()
    {
        setBackground(new Color(0, 0, 0));
        offImage = createImage(800, 550);
        if(offImage != null)
            rd = (Graphics2D)offImage.getGraphics();
        rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        setLayout(null);
        slstage.setFont(new Font("Arial", 1, 13));
        slstage.add(rd, "Select a Stage...         ");
        slstage.setForeground(new Color(63, 80, 110));
        slstage.setBackground(new Color(209, 217, 230));
        srch.setFont(new Font("Arial", 1, 12));
        srch.setBackground(new Color(255, 255, 255));
        srch.setForeground(new Color(0, 0, 0));
        strtyp.setFont(new Font("Arial", 1, 12));
        strtyp.add(rd, "NormalRoad");
        strtyp.add(rd, "OffRoad");
        strtyp.setBackground(new Color(63, 80, 110));
        strtyp.setForeground(new Color(209, 217, 230));
        ptyp.setFont(new Font("Arial", 1, 12));
        ptyp.add(rd, "Roads");
        ptyp.add(rd, "Ramps");
        ptyp.add(rd, "Obstacles");
        ptyp.add(rd, "Checkpoint");
        ptyp.add(rd, "Fixing Hoop");
        ptyp.add(rd, "Trees");
        ptyp.add(rd, "Ground Pile");
        ptyp.setBackground(new Color(63, 80, 110));
        ptyp.setForeground(new Color(209, 217, 230));
        part.setFont(new Font("Arial", 1, 12));
        part.add(rd, "Halfpipe-Normal-Road Blend");
        part.setBackground(new Color(63, 80, 110));
        part.setForeground(new Color(209, 217, 230));
        fixh.setFont(new Font("Arial", 1, 12));
        fixh.setBackground(new Color(255, 255, 255));
        fixh.setForeground(new Color(0, 0, 0));
        mgen.setFont(new Font("Arial", 1, 12));
        mgen.setBackground(new Color(255, 255, 255));
        mgen.setForeground(new Color(0, 0, 0));
        pfog.setFont(new Font("Arial", 1, 12));
        pfog.setBackground(new Color(225, 225, 225));
        pfog.setForeground(new Color(0, 0, 0));
        nlaps.setFont(new Font("Arial", 1, 12));
        for(int i = 0; i < 15; i++)
            nlaps.add(rd, (new StringBuilder()).append(" ").append(i + 1).append(" ").toString());

        nlaps.setBackground(new Color(63, 80, 110));
        nlaps.setForeground(new Color(209, 217, 230));
        tracks.setFont(new Font("Arial", 1, 12));
        tracks.add(rd, "Select MOD Track");
        tracks.setForeground(new Color(63, 80, 110));
        tracks.setBackground(new Color(209, 217, 230));
        witho.setFont(new Font("Arial", 1, 12));
        witho.add(rd, "With other cars");
        witho.add(rd, "Alone");
        witho.setBackground(new Color(63, 80, 110));
        witho.setForeground(new Color(209, 217, 230));
        tnick.setFont(new Font("Arial", 1, 13));
        tnick.setBackground(new Color(255, 255, 255));
        tnick.setForeground(new Color(0, 0, 0));
        tpass.setFont(new Font("Arial", 1, 13));
        tpass.setEchoCharacter('*');
        tpass.setBackground(new Color(255, 255, 255));
        tpass.setForeground(new Color(0, 0, 0));
        pubtyp.setFont(new Font("Arial", 1, 13));
        pubtyp.add(rd, "Private");
        pubtyp.add(rd, "Public");
        pubtyp.add(rd, "Super Public");
        pubtyp.setBackground(new Color(63, 80, 110));
        pubtyp.setForeground(new Color(209, 217, 230));
        pubitem.setFont(new Font("Arial", 1, 13));
        pubitem.add(rd, "Account Stages");
        pubitem.setBackground(new Color(209, 217, 230));
        pubitem.setForeground(new Color(63, 80, 110));
        add(tnick);
        add(tpass);
        add(srch);
        add(fixh);
        add(mgen);
        add(pfog);
        hidefields();
    }

    public void hidefields()
    {
        pubtyp.hide();
        pubitem.hide();
        tpass.hide();
        tnick.hide();
        witho.hide();
        strtyp.hide();
        srch.hide();
        slstage.hide();
        tracks.hide();
        nlaps.hide();
        pfog.hide();
        fixh.hide();
        mgen.hide();
        ptyp.hide();
        part.hide();
    }

    public void movefield(Component component, int i, int j, int k, int l)
    {
        i += apx;
        j += apy;
        if(component.getX() != i || component.getY() != j || component.getWidth() != k || component.getHeight() != l)
            component.setBounds(i, j, k, l);
    }

    public void drawms()
    {
        boolean flag = false;
        if(pubtyp.draw(rd, xm, ym, mousdr, 550, false))
            flag = true;
        if(pubitem.draw(rd, xm, ym, mousdr, 550, false))
            flag = true;
        if(slstage.draw(rd, xm, ym, mousdr, 550, false))
            flag = true;
        if(strtyp.draw(rd, xm, ym, mousdr, 550, false))
            flag = true;
        char c = '\0';
        if(preop)
            c = '\uFC18';
        if(part.draw(rd, xm, ym + c, mousdr && !preop, 550, false))
            flag = true;
        if(ptyp.draw(rd, xm, ym, mousdr, 550, false))
        {
            flag = true;
            preop = true;
        } else
        {
            preop = false;
        }
        if(nlaps.draw(rd, xm, ym, mousdr, 550, true))
            flag = true;
        if(tracks.draw(rd, xm, ym, mousdr, 550, true))
            flag = true;
        if(witho.draw(rd, xm, ym, mousdr, 550, true))
            flag = true;
        if(flag)
            mouses = 0;
    }

    public void start()
    {
        if(thredo == null)
            thredo = new Thread(this);
        thredo.start();
    }

    public void stop()
    {
        exwist = true;
    }

    public void paint(Graphics g)
    {
        apx = getWidth() / 2 - 400;
        apy = getHeight() / 2 - 275;
        g.drawImage(offImage, apx, apy, this);
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public boolean mouseUp(Event event, int i, int j)
    {
        mousdr = false;
        xm = i - apx;
        ym = j - apy;
        if(mouses == 1)
            mouses = -1;
        if(onbtgame)
            Madness.game();
        return false;
    }

    public boolean mouseDown(Event event, int i, int j)
    {
        mousdr = true;
        xm = i - apx;
        ym = j - apy;
        mouses = 1;
        requestFocus();
        focuson = true;
        return false;
    }

    public boolean mouseMove(Event event, int i, int j)
    {
        xm = i - apx;
        ym = j - apy;
        if(xm > 620 && xm < 774 && ym > 0 && ym < 23)
        {
            if(!onbtgame)
            {
                onbtgame = true;
                setCursor(new Cursor(12));
            }
        } else
        if(onbtgame)
        {
            onbtgame = false;
            setCursor(new Cursor(0));
        }
        return false;
    }

    public boolean mouseDrag(Event event, int i, int j)
    {
        mousdr = true;
        xm = i - apx;
        ym = j - apy;
        return false;
    }

    public boolean keyDown(Event event, int i)
    {
        if(focuson)
        {
            if(i == 42 || i == 10 || i == 56 || i == 119 || i == 87 || i == 43 || i == 61)
                zoomi = true;
            if(i == 47 || i == 8 || i == 50 || i == 115 || i == 83 || i == 45)
                zoomo = true;
            if(i == 1006)
                left = true;
            if(i == 1007)
                right = true;
            if(i == 1005)
                down = true;
            if(i == 1004)
                up = true;
        }
        return false;
    }

    public boolean keyUp(Event event, int i)
    {
        if(i == 42 || i == 10 || i == 56 || i == 119 || i == 87 || i == 43 || i == 61)
            zoomi = false;
        if(i == 47 || i == 8 || i == 50 || i == 115 || i == 83 || i == 45)
            zoomo = false;
        if(i == 1006)
            left = false;
        if(i == 1007)
            right = false;
        if(i == 1005)
            down = false;
        if(i == 1004)
            up = false;
        return false;
    }

    public void loadbase()
    {
        String as[] = {
            "road", "froad", "twister2", "twister1", "turn", "offroad", "bumproad", "offturn", "nroad", "nturn", 
            "roblend", "noblend", "rnblend", "roadend", "offroadend", "hpground", "ramp30", "cramp35", "dramp15", "dhilo15", 
            "slide10", "takeoff", "sramp22", "offbump", "offramp", "sofframp", "halfpipe", "spikes", "rail", "thewall", 
            "checkpoint", "fixpoint", "offcheckpoint", "sideoff", "bsideoff", "uprise", "riseroad", "sroad", "soffroad", "tside", 
            "launchpad", "thenet", "speedramp", "offhill", "slider", "uphill", "roll1", "roll2", "roll3", "roll4", 
            "roll5", "roll6", "opile1", "opile2", "aircheckpoint", "tree1", "tree2", "tree3", "tree4", "tree5", 
            "tree6", "tree7", "tree8", "cac1", "cac2", "cac3"
        };
        try
        {
            File file = new File("data/models.zip");
            ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(file));
            ZipEntry zipentry = zipinputstream.getNextEntry();
            Object obj = null;
            for(; zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i = -1;
                for(int j = 0; j < 66; j++)
                    if(zipentry.getName().startsWith(as[j]))
                        i = j;

                if(i == -1)
                    continue;
                int k = (int)zipentry.getSize();
                byte abyte0[] = new byte[k];
                int l = 0;
                int i1;
                for(; k > 0; k -= i1)
                {
                    i1 = zipinputstream.read(abyte0, l, k);
                    l += i1;
                }

                bco[i] = new ContO(abyte0, m, t);
                for(int j1 = 0; j1 < bco[i].npl; j1++)
                    bco[i].p[j1].loadprojf();

                if(i == 31)
                    bco[i].elec = true;
            }

            zipinputstream.close();
            bco[66] = new ContO((int)(10000D * Math.random()), (int)pwd, (int)phd, m, t, 0, 0, 0);
        }
        catch(Exception exception)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to load file 'data/models.zip'!\nError:\n").append(exception).toString(), "Stage Maker", 1);
        }
        System.gc();
    }

    public void readstage(int i)
    {
        String s;
        int j;
        int k;
        int l;
        int i1;
        boolean flag;
        boolean flag1;
        String s2;
        errd = 0;
        trackname = "";
        t.nt = 0;
        nob = 0;
        xnob = 0;
        cp.n = 0;
        cp.nsp = 0;
        cp.fn = 0;
        cp.haltall = false;
        cp.wasted = 0;
        cp.catchfin = 0;
        m.ground = 250;
        m.lightson = false;
        if(i == 0)
        {
            m.snap[0] = 0;
            m.snap[1] = 0;
            m.snap[2] = 0;
        }
        if(i == 3)
        {
            tstage = "";
            bstage = "";
        }
        s = bstage;
        if(i == 1 || i == 2)
            s = (new StringBuilder()).append("").append(tstage).append("\r\n").append(bstage).append("").toString();
        j = 0;
        k = 100;
        l = 0;
        i1 = 100;
        flag = true;
        flag1 = true;
        s2 = "";
        DataInputStream datainputstream;
        datainputstream = null;
        if(i == 3)
        {
            File file = new File((new StringBuilder()).append("mystages/").append(stagename).append(".txt").toString());
            datainputstream = new DataInputStream(new FileInputStream(file));
            nundo = 0;
        } else
        {
            datainputstream = new DataInputStream(new ByteArrayInputStream(s.getBytes()));
        }
_L79:
        String s1;
        if((s1 = datainputstream.readLine()) == null) goto _L2; else goto _L1
_L1:
        s2 = (new StringBuilder()).append("").append(s1.trim()).toString();
        if(!s2.startsWith("sky")) goto _L4; else goto _L3
_L3:
        csky[0] = getint("sky", s2, 0);
        csky[1] = getint("sky", s2, 1);
        csky[2] = getint("sky", s2, 2);
        m.setsky(csky[0], csky[1], csky[2]);
        if(i != 3) goto _L4; else goto _L5
_L5:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L4:
        if(!s2.startsWith("ground")) goto _L7; else goto _L6
_L6:
        cgrnd[0] = getint("ground", s2, 0);
        cgrnd[1] = getint("ground", s2, 1);
        cgrnd[2] = getint("ground", s2, 2);
        m.setgrnd(cgrnd[0], cgrnd[1], cgrnd[2]);
        if(i != 3) goto _L7; else goto _L8
_L8:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L7:
        if(!s2.startsWith("polys")) goto _L10; else goto _L9
_L9:
        m.setpolys(getint("polys", s2, 0), getint("polys", s2, 1), getint("polys", s2, 2));
        if(i != 3) goto _L10; else goto _L11
_L11:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L10:
        if(!s2.startsWith("fog")) goto _L13; else goto _L12
_L12:
        cfade[0] = getint("fog", s2, 0);
        cfade[1] = getint("fog", s2, 1);
        cfade[2] = getint("fog", s2, 2);
        m.setfade(cfade[0], cfade[1], cfade[2]);
        if(i != 3) goto _L13; else goto _L14
_L14:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L13:
        if(!s2.startsWith("texture")) goto _L16; else goto _L15
_L15:
        texture[0] = getint("texture", s2, 0);
        texture[1] = getint("texture", s2, 1);
        texture[2] = getint("texture", s2, 2);
        texture[3] = getint("texture", s2, 3);
        m.setexture(texture[0], texture[1], texture[2], texture[3]);
        if(i != 3) goto _L16; else goto _L17
_L17:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L16:
        if(!s2.startsWith("clouds")) goto _L19; else goto _L18
_L18:
        cldd[0] = getint("clouds", s2, 0);
        cldd[1] = getint("clouds", s2, 1);
        cldd[2] = getint("clouds", s2, 2);
        cldd[3] = getint("clouds", s2, 3);
        cldd[4] = getint("clouds", s2, 4);
        m.setcloads(cldd[0], cldd[1], cldd[2], cldd[3], cldd[4]);
        if(i != 3) goto _L19; else goto _L20
_L20:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L19:
        if(i == 2 || !s2.startsWith("snap")) goto _L22; else goto _L21
_L21:
        m.setsnap(getint("snap", s2, 0), getint("snap", s2, 1), getint("snap", s2, 2));
        if(i != 3) goto _L22; else goto _L23
_L23:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L22:
        if(!s2.startsWith("density")) goto _L25; else goto _L24
_L24:
        m.fogd = (getint("density", s2, 0) + 1) * 2 - 1;
        if(m.fogd < 1)
            m.fogd = 1;
        if(m.fogd > 30)
            m.fogd = 30;
        if(i != 3) goto _L25; else goto _L26
_L26:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L25:
        if(!s2.startsWith("mountains")) goto _L28; else goto _L27
_L27:
        m.mgen = getint("mountains", s2, 0);
        if(i != 3) goto _L28; else goto _L29
_L29:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L28:
        if(!s2.startsWith("fadefrom")) goto _L31; else goto _L30
_L30:
        m.fadfrom(getint("fadefrom", s2, 0));
        origfade = m.fade[0];
        if(i != 3) goto _L31; else goto _L32
_L32:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L31:
        if(!s2.startsWith("lightson")) goto _L34; else goto _L33
_L33:
        m.lightson = true;
        if(i != 3) goto _L34; else goto _L35
_L35:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L34:
        if(!s2.startsWith("nlaps")) goto _L37; else goto _L36
_L36:
        cp.nlaps = getint("nlaps", s2, 0);
        if(cp.nlaps < 1)
            cp.nlaps = 1;
        if(cp.nlaps > 15)
            cp.nlaps = 15;
        if(i != 3) goto _L37; else goto _L38
_L38:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L37:
        if(!s2.startsWith("soundtrack")) goto _L40; else goto _L39
_L39:
        trackname = getstring("soundtrack", s2, 0);
        trackvol = getint("soundtrack", s2, 1);
        tracksize = getint("soundtrack", s2, 2);
        if(i != 3) goto _L40; else goto _L41
_L41:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        tstage;
_L40:
        if(!s2.startsWith("set")) goto _L43; else goto _L42
_L42:
        int j1 = getint("set", s2, 0);
        if(j1 >= 10 && j1 <= 25)
            m.loadnew = true;
        j1 -= 10;
        co[nob] = new ContO(bco[j1], getint("set", s2, 1), m.ground - bco[j1].grat, getint("set", s2, 2), getint("set", s2, 3));
        co[nob].roofat = getint("set", s2, 3);
        co[nob].colok = j1;
        if(s2.indexOf(")p") != -1)
        {
            cp.x[cp.n] = getint("chk", s2, 1);
            cp.z[cp.n] = getint("chk", s2, 2);
            cp.y[cp.n] = 0;
            cp.typ[cp.n] = 0;
            if(s2.indexOf(")pt") != -1)
                cp.typ[cp.n] = -1;
            if(s2.indexOf(")pr") != -1)
                cp.typ[cp.n] = -2;
            if(s2.indexOf(")po") != -1)
                cp.typ[cp.n] = -3;
            if(s2.indexOf(")ph") != -1)
                cp.typ[cp.n] = -4;
            cp.n++;
        }
        xnob++;
        nob++;
        if(i != 3) goto _L45; else goto _L44
_L44:
        if(!flag1) goto _L47; else goto _L46
_L46:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag1 = false;
_L47:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L45:
        if(m.loadnew)
            m.loadnew = false;
_L43:
        if(!s2.startsWith("chk")) goto _L49; else goto _L48
_L48:
        int k1 = getint("chk", s2, 0);
        k1 -= 10;
        int i3 = m.ground - bco[k1].grat;
        if(k1 == 54)
            i3 = getint("chk", s2, 4);
        co[nob] = new ContO(bco[k1], getint("chk", s2, 1), i3, getint("chk", s2, 2), getint("chk", s2, 3));
        co[nob].roofat = getint("chk", s2, 3);
        co[nob].colok = k1;
        cp.x[cp.n] = getint("chk", s2, 1);
        cp.z[cp.n] = getint("chk", s2, 2);
        cp.y[cp.n] = i3;
        if(getint("chk", s2, 3) == 0)
            cp.typ[cp.n] = 1;
        else
            cp.typ[cp.n] = 2;
        cp.pcs = cp.n;
        cp.n++;
        co[nob].checkpoint = cp.nsp + 1;
        if(s2.indexOf(")r") != -1)
            co[nob].wh = cp.nsp + 1;
        cp.nsp++;
        xnob++;
        nob++;
        if(i != 3) goto _L49; else goto _L50
_L50:
        if(!flag1) goto _L52; else goto _L51
_L51:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag1 = false;
_L52:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L49:
        if(!s2.startsWith("fix")) goto _L54; else goto _L53
_L53:
        int l1 = getint("fix", s2, 0);
        l1 -= 10;
        co[nob] = new ContO(bco[l1], getint("fix", s2, 1), getint("fix", s2, 3), getint("fix", s2, 2), getint("fix", s2, 4));
        co[nob].roofat = getint("fix", s2, 4);
        co[nob].colok = l1;
        cp.fx[cp.fn] = getint("fix", s2, 1);
        cp.fz[cp.fn] = getint("fix", s2, 2);
        cp.fy[cp.fn] = getint("fix", s2, 3);
        co[nob].elec = true;
        if(getint("fix", s2, 4) != 0)
        {
            cp.roted[cp.fn] = true;
            co[nob].roted = true;
        } else
        {
            cp.roted[cp.fn] = false;
        }
        if(s2.indexOf(")s") != -1)
            cp.special[cp.fn] = true;
        else
            cp.special[cp.fn] = false;
        cp.fn++;
        xnob++;
        nob++;
        if(i != 3) goto _L54; else goto _L55
_L55:
        if(!flag1) goto _L57; else goto _L56
_L56:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag1 = false;
_L57:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L54:
        if(!s2.startsWith("pile")) goto _L59; else goto _L58
_L58:
        co[nob] = new ContO(getint("pile", s2, 0), getint("pile", s2, 1), getint("pile", s2, 2), m, t, getint("pile", s2, 3), getint("pile", s2, 4), m.ground);
        co[nob].srz = getint("pile", s2, 0);
        co[nob].srx = getint("pile", s2, 1);
        co[nob].sry = getint("pile", s2, 2);
        co[nob].colok = 66;
        xnob++;
        nob++;
        if(i != 3) goto _L59; else goto _L60
_L60:
        if(!flag1) goto _L62; else goto _L61
_L61:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag1 = false;
_L62:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L59:
        if(!s2.startsWith("maxr")) goto _L64; else goto _L63
_L63:
        int i2 = getint("maxr", s2, 0);
        int j3 = getint("maxr", s2, 1);
        j = j3;
        int j4 = getint("maxr", s2, 2);
        for(int j5 = 0; j5 < i2; j5++)
        {
            co[nob] = new ContO(bco[29], j3, m.ground - bco[29].grat, j5 * 4800 + j4, 0);
            if(i == 0)
                xnob++;
            else
                nob++;
        }

        if(i != 3) goto _L64; else goto _L65
_L65:
        if(!flag) goto _L67; else goto _L66
_L66:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag = false;
_L67:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L64:
        if(!s2.startsWith("maxl")) goto _L69; else goto _L68
_L68:
        int j2 = getint("maxl", s2, 0);
        int k3 = getint("maxl", s2, 1);
        k = k3;
        int k4 = getint("maxl", s2, 2);
        for(int k5 = 0; k5 < j2; k5++)
        {
            co[nob] = new ContO(bco[29], k3, m.ground - bco[29].grat, k5 * 4800 + k4, 180);
            if(i == 0)
                xnob++;
            else
                nob++;
        }

        if(i != 3) goto _L69; else goto _L70
_L70:
        if(!flag) goto _L72; else goto _L71
_L71:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag = false;
_L72:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L69:
        if(!s2.startsWith("maxt")) goto _L74; else goto _L73
_L73:
        int k2 = getint("maxt", s2, 0);
        int l3 = getint("maxt", s2, 1);
        l = l3;
        int l4 = getint("maxt", s2, 2);
        for(int l5 = 0; l5 < k2; l5++)
        {
            co[nob] = new ContO(bco[29], l5 * 4800 + l4, m.ground - bco[29].grat, l3, 90);
            if(i == 0)
                xnob++;
            else
                nob++;
        }

        if(i != 3) goto _L74; else goto _L75
_L75:
        if(!flag) goto _L77; else goto _L76
_L76:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag = false;
_L77:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L74:
        if(!s2.startsWith("maxb")) goto _L79; else goto _L78
_L78:
        int l2 = getint("maxb", s2, 0);
        int i4 = getint("maxb", s2, 1);
        i1 = i4;
        int i5 = getint("maxb", s2, 2);
        for(int i6 = 0; i6 < l2; i6++)
        {
            co[nob] = new ContO(bco[29], i6 * 4800 + i5, m.ground - bco[29].grat, i4, -90);
            if(i == 0)
                xnob++;
            else
                nob++;
        }

        if(i != 3) goto _L79; else goto _L80
_L80:
        if(!flag) goto _L82; else goto _L81
_L81:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\n";
        append();
        toString();
        bstage;
        flag = false;
_L82:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "";
        append();
        s2;
        append();
        "\r\n";
        append();
        toString();
        bstage;
          goto _L79
_L2:
        datainputstream.close();
        m.newpolys(k, j - k, i1, l - i1, t, nob);
        m.newclouds(k, j, i1, l);
        m.newmountains(k, j, i1, l);
        m.newstars();
        break MISSING_BLOCK_LABEL_4553;
        Exception exception;
        exception;
        System.out.println((new StringBuilder()).append("Error in stage ").append(stagename).toString());
        System.out.println((new StringBuilder()).append("").append(exception).toString());
        System.out.println((new StringBuilder()).append("At line: ").append(s2).toString());
        errd = 6;
        if(cp.fn >= 5)
            errd = 5;
        if(t.nt >= 6700)
            errd = 1;
        if(cp.n >= 140)
            errd = 2;
        if(nob >= 601)
            errd = 4;
        if(m.nrw * m.ncl >= 16000)
            errd = 3;
        if(xnob >= 602)
            errd = 4;
        if(i != 3 || bstage.indexOf("set(47,0,0,0)") != -1 || bstage.indexOf("set(48,0,0,0)") != -1) goto _L84; else goto _L83
_L83:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "set(47,0,0,0)\r\n";
        append();
        toString();
        bstage;
_L84:
    }

    public void newstage()
    {
        if(srch.getText().equals(""))
            break MISSING_BLOCK_LABEL_209;
        File file = new File((new StringBuilder()).append("mystages/").append(srch.getText()).append(".txt").toString());
        if(file.exists())
            break MISSING_BLOCK_LABEL_196;
        stagename = srch.getText();
        tstage = (new StringBuilder()).append("snap(0,0,0)\r\nsky(191,215,255)\r\nclouds(255,255,255,5,-1000)\r\nfog(195,207,230)\r\nground(192,194,202)\r\ntexture(0,0,0,50)\r\nfadefrom(5000)\r\ndensity(5)\r\nmountains(").append((int)(Math.random() * 100000D)).append(")\r\nnlaps(5)\r\n\r\n").toString();
        if(strtyp.getSelectedIndex() == 1)
            bstage = "set(48,0,0,0)\r\n";
        else
            bstage = "set(47,0,0,0)\r\n";
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\nmaxl(3,-7200,-4800)\r\nmaxb(3,-7200,-4800)\r\nmaxr(3,7200,-4800)\r\nmaxt(3,7200,-4800)\r\n";
        append();
        toString();
        bstage;
        savefile();
        strtyp.hide();
        srch.hide();
        sfase = 0;
        tabed = -2;
        break MISSING_BLOCK_LABEL_219;
        JOptionPane.showMessageDialog(null, "A stage with that name already exists, please choose another name!", "Stage Maker", 1);
        break MISSING_BLOCK_LABEL_219;
        JOptionPane.showMessageDialog(null, "Please enter a stage name first!", "Stage Maker", 1);
    }

    public void sortop()
    {
        tstage = (new StringBuilder()).append("snap(").append(m.snap[0]).append(",").append(m.snap[1]).append(",").append(m.snap[2]).append(")\r\nsky(").append(csky[0]).append(",").append(csky[1]).append(",").append(csky[2]).append(")\r\nfog(").append(cfade[0]).append(",").append(cfade[1]).append(",").append(cfade[2]).append(")\r\nclouds(").append(cldd[0]).append(",").append(cldd[1]).append(",").append(cldd[2]).append(",").append(cldd[3]).append(",").append(cldd[4]).append(")\r\nground(").append(cgrnd[0]).append(",").append(cgrnd[1]).append(",").append(cgrnd[2]).append(")\r\ntexture(").append(texture[0]).append(",").append(texture[1]).append(",").append(texture[2]).append(",").append(texture[3]).append(")\r\nfadefrom(").append(origfade).append(")\r\ndensity(").append((m.fogd + 1) / 2 - 1).append(")\r\nmountains(").append(m.mgen).append(")\r\nnlaps(").append(cp.nlaps).append(")\r\n").toString();
        if(trackname.equals("")) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "soundtrack(";
        append();
        trackname;
        append();
        ",";
        append();
        trackvol;
        append();
        ",";
        append();
        tracksize;
        append();
        ")\r\n";
        append();
        toString();
        tstage;
_L2:
        for(int i = 0; i < 3; i++)
            snap[i] = (int)((float)m.snap[i] / 1.2F + 50F);

        if(snap[0] + snap[1] + snap[2] > 110) goto _L4; else goto _L3
_L3:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "lightson()\r\n";
        append();
        toString();
        tstage;
_L4:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        tstage;
        append();
        "\r\n";
        append();
        toString();
        tstage;
    }

    public void sortstage()
    {
        int ai[];
        int ai1[];
        int k;
        int l3;
        int j6;
        int i9;
        int i12;
        int i14;
        ai = new int[nob * 2];
        ai1 = new int[nob * 2];
        for(int i = 0; i < nob; i++)
            ai[i] = 0;

        int j = 0;
        k = 0;
        ai1[k] = 0;
        k++;
        boolean flag = false;
        int l = 0;
        while(!flag) 
        {
            int ai2[] = {
                co[j].x + atp[co[j].colok][0], co[j].x + atp[co[j].colok][2]
            };
            int ai3[] = {
                co[j].z + atp[co[j].colok][1], co[j].z + atp[co[j].colok][3]
            };
            int i4 = co[j].roofat;
            if(co[j].colok == 2)
                i4 += 30;
            if(co[j].colok == 3)
                i4 -= 30;
            if(co[j].colok == 15)
                i4 -= 90;
            if(co[j].colok == 20)
                i4 -= 180;
            if(co[j].colok == 26)
                i4 -= 90;
            rot(ai2, ai3, co[j].x, co[j].z, i4, 2);
            int k6 = -1;
            int j9 = -1;
            if(l != 0)
            {
                for(int j12 = 0; j12 < nob; j12++)
                {
                    boolean flag2 = false;
                    if(k == 2 && j12 == 0)
                        flag2 = true;
                    if(j == j12 || flag2 || ai[j12] != 0 || co[j12].colok > 14 && co[j12].colok < 33 || co[j12].colok >= 39 && co[j12].colok < 46 || co[j12].colok >= 52)
                        continue;
                    byte byte0 = 0;
                    if(co[j12].colok != 2 && co[j12].colok != 3 && co[j12].colok != 4 && co[j12].colok != 7 && co[j12].colok != 9)
                    {
                        if(l == 1 && co[j12].z > co[j].z && Math.abs(co[j12].x - co[j].x) < 1000 && (co[j12].roofat == 180 || co[j12].roofat == 0))
                            byte0 = 1;
                        if(l == 2 && co[j12].z < co[j].z && Math.abs(co[j12].x - co[j].x) < 1000 && (co[j12].roofat == 180 || co[j12].roofat == 0))
                            byte0 = 1;
                        if(l == 3 && co[j12].x > co[j].x && Math.abs(co[j12].z - co[j].z) < 1000 && (co[j12].roofat == 90 || co[j12].roofat == -90))
                            byte0 = 1;
                        if(l == 4 && co[j12].x < co[j].x && Math.abs(co[j12].z - co[j].z) < 1000 && (co[j12].roofat == 90 || co[j12].roofat == -90))
                            byte0 = 1;
                    } else
                    {
                        byte0 = 2;
                    }
                    if(byte0 == 0)
                        continue;
                    int ai5[] = {
                        co[j12].x + atp[co[j12].colok][0], co[j12].x + atp[co[j12].colok][2]
                    };
                    int ai7[] = {
                        co[j12].z + atp[co[j12].colok][1], co[j12].z + atp[co[j12].colok][3]
                    };
                    int j4 = co[j12].roofat;
                    if(co[j12].colok == 2)
                        j4 += 30;
                    if(co[j12].colok == 3)
                        j4 -= 30;
                    if(co[j12].colok == 15)
                        j4 -= 90;
                    if(co[j12].colok == 20)
                        j4 -= 180;
                    if(co[j12].colok == 26)
                        j4 -= 90;
                    rot(ai5, ai7, co[j12].x, co[j12].z, j4, 2);
                    int l15 = 0;
                    if(j12 != 0)
                    {
                        l15 = pyn(ai5[0], ai2[0], ai7[0], ai3[0]);
                        if(l15 >= 0 && (l15 < 100 || byte0 != 2) && (l15 < k6 || k6 == -1))
                        {
                            k6 = l15;
                            j9 = j12;
                        }
                    }
                    l15 = pyn(ai5[1], ai2[0], ai7[1], ai3[0]);
                    if(l15 >= 0 && (l15 < 100 || byte0 != 2) && (l15 < k6 || k6 == -1))
                    {
                        k6 = l15;
                        j9 = j12;
                    }
                    if(j == 0)
                        continue;
                    if(j12 != 0)
                    {
                        l15 = pyn(ai5[0], ai2[1], ai7[0], ai3[1]);
                        if(l15 >= 0 && (l15 < 100 || byte0 != 2) && l15 < k6)
                        {
                            k6 = l15;
                            j9 = j12;
                        }
                    }
                    l15 = pyn(ai5[1], ai2[1], ai7[1], ai3[1]);
                    if(l15 >= 0 && (l15 < 100 || byte0 != 2) && l15 < k6)
                    {
                        k6 = l15;
                        j9 = j12;
                    }
                }

            }
            if(j9 == -1)
            {
                for(int k12 = 0; k12 < nob; k12++)
                {
                    boolean flag3 = false;
                    if(k == 2 && k12 == 0)
                        flag3 = true;
                    if(j == k12 || flag3 || ai[k12] != 0 || co[k12].colok > 14 && co[k12].colok < 33 || co[k12].colok >= 39 && co[k12].colok < 46 || co[k12].colok >= 52)
                        continue;
                    int ai4[] = {
                        co[k12].x + atp[co[k12].colok][0], co[k12].x + atp[co[k12].colok][2]
                    };
                    int ai6[] = {
                        co[k12].z + atp[co[k12].colok][1], co[k12].z + atp[co[k12].colok][3]
                    };
                    int k4 = co[k12].roofat;
                    if(co[k12].colok == 2)
                        k4 += 30;
                    if(co[k12].colok == 3)
                        k4 -= 30;
                    if(co[k12].colok == 15)
                        k4 -= 90;
                    if(co[k12].colok == 20)
                        k4 -= 180;
                    if(co[k12].colok == 26)
                        k4 -= 90;
                    rot(ai4, ai6, co[k12].x, co[k12].z, k4, 2);
                    int j15 = 0;
                    if(k12 != 0)
                    {
                        j15 = pyn(ai4[0], ai2[0], ai6[0], ai3[0]);
                        if(j15 >= 0 && (j15 < k6 || k6 == -1))
                        {
                            k6 = j15;
                            j9 = k12;
                        }
                    }
                    j15 = pyn(ai4[1], ai2[0], ai6[1], ai3[0]);
                    if(j15 >= 0 && (j15 < k6 || k6 == -1))
                    {
                        k6 = j15;
                        j9 = k12;
                    }
                    if(j == 0)
                        continue;
                    if(k12 != 0)
                    {
                        j15 = pyn(ai4[0], ai2[1], ai6[0], ai3[1]);
                        if(j15 >= 0 && j15 < k6)
                        {
                            k6 = j15;
                            j9 = k12;
                        }
                    }
                    j15 = pyn(ai4[1], ai2[1], ai6[1], ai3[1]);
                    if(j15 >= 0 && j15 < k6)
                    {
                        k6 = j15;
                        j9 = k12;
                    }
                }

            }
            if(j9 != -1)
            {
                l = 0;
                if(co[j9].colok != 2 && co[j9].colok != 3 && co[j9].colok != 4 && co[j9].colok != 7 && co[j9].colok != 9)
                {
                    if((co[j9].roofat == 180 || co[j9].roofat == 0) && co[j9].z > co[j].z)
                        l = 1;
                    if((co[j9].roofat == 180 || co[j9].roofat == 0) && co[j9].z < co[j].z)
                        l = 2;
                    if((co[j9].roofat == 90 || co[j9].roofat == -90) && co[j9].x > co[j].x)
                        l = 3;
                    if((co[j9].roofat == 90 || co[j9].roofat == -90) && co[j9].x < co[j].x)
                        l = 4;
                }
                if(co[j9].colok == 4 || co[j9].colok == 7 || co[j9].colok == 9)
                    ai[j9] = 2;
                else
                    ai[j9] = 1;
                if(co[j9].colok >= 46 && co[j9].colok <= 51)
                    ai[j9] = 6;
                j = j9;
                if(j9 == 0)
                {
                    ai[0] = 1;
                    flag = true;
                } else
                {
                    ai1[k] = j9;
                    k++;
                }
            } else
            {
                ai[0] = 1;
                flag = true;
            }
        }
        for(int i1 = 0; i1 < nob; i1++)
            if(ai[i1] == 0 && (co[i1].colok <= 14 || co[i1].colok >= 33) && (co[i1].colok < 39 || co[i1].colok >= 46) && co[i1].colok < 52)
            {
                ai1[k] = i1;
                k++;
            }

        for(int j1 = 0; j1 < k; j1++)
        {
            if(co[ai1[j1]].colok < 46 || co[ai1[j1]].colok > 51)
                continue;
            for(int l1 = j1 + 1; l1 < k; l1++)
            {
                int l4 = pyn(co[ai1[j1]].x, co[ai1[l1]].x, co[ai1[j1]].z, co[ai1[l1]].z);
                if(l4 < 0 || co[ai1[l1]].colok >= 46 && co[ai1[j1]].colok <= 51 || l4 >= ((co[ai1[j1]].maxR + co[ai1[l1]].maxR) / 100) * ((co[ai1[j1]].maxR + co[ai1[l1]].maxR) / 100))
                    continue;
                int l6 = ai1[l1];
                for(int k9 = l1; k9 > j1; k9--)
                    ai1[k9] = ai1[k9 - 1];

                ai1[j1] = l6;
                ai[ai1[j1]] = 0;
                j1++;
            }

        }

        int k1 = 1;
        for(int i2 = 0; i2 < cp.nsp; i2++)
        {
            for(int i5 = 0; i5 < nob; i5++)
            {
                if(co[i5].wh != i2 + 1 || co[i5].colok != 30 && co[i5].colok != 32 && co[i5].colok != 54)
                    continue;
                int i7 = -1;
                int l9 = -1;
                for(int l12 = k1; l12 < k; l12++)
                {
                    if(co[ai1[l12]].colok == 30 || co[ai1[l12]].colok == 32 || co[ai1[l12]].colok == 54)
                        continue;
                    int j14 = pyn(co[i5].x, co[ai1[l12]].x, co[i5].z, co[ai1[l12]].z);
                    if(j14 >= 0 && (j14 < i7 || i7 == -1))
                    {
                        i7 = j14;
                        l9 = l12;
                    }
                }

                if(l9 != -1)
                {
                    ai[ai1[l9]] = 0;
                    for(int i13 = k; i13 > l9; i13--)
                        ai1[i13] = ai1[i13 - 1];

                    ai1[l9 + 1] = i5;
                    k1 = l9 + 1;
                    k++;
                } else
                {
                    ai1[k] = i5;
                    k1 = k;
                    k++;
                }
            }

        }

        for(int j2 = 0; j2 < nob; j2++)
        {
            if(co[j2].wh != 0 || co[j2].colok != 30 && co[j2].colok != 32 && co[j2].colok != 54)
                continue;
            int j5 = -1;
            int j7 = -1;
            for(int i10 = k1; i10 < k; i10++)
            {
                if(co[ai1[i10]].colok == 30 || co[ai1[i10]].colok == 32 || co[ai1[i10]].colok == 54)
                    continue;
                int j13 = pyn(co[j2].x, co[ai1[i10]].x, co[j2].z, co[ai1[i10]].z);
                if(j13 >= 0 && (j13 < j5 || j5 == -1))
                {
                    j5 = j13;
                    j7 = i10;
                }
            }

            if(j7 != -1)
            {
                ai[ai1[j7]] = 0;
                for(int j10 = k; j10 > j7; j10--)
                    ai1[j10] = ai1[j10 - 1];

                ai1[j7 + 1] = j2;
                k++;
            } else
            {
                ai1[k] = j2;
                k++;
            }
        }

        for(int k2 = 0; k2 < nob; k2++)
        {
            if(co[k2].colok != 31)
                continue;
            int k5 = -1;
            int k7 = -1;
            for(int k10 = 0; k10 < k; k10++)
            {
                int k13 = pyn(co[k2].x, co[ai1[k10]].x, co[k2].z, co[ai1[k10]].z);
                if(k13 >= 0 && (k13 < k5 || k5 == -1))
                {
                    k5 = k13;
                    k7 = k10;
                }
            }

            if(k7 != -1)
            {
                for(int l10 = k; l10 > k7; l10--)
                    ai1[l10] = ai1[l10 - 1];

                ai1[k7] = k2;
                k++;
            } else
            {
                ai1[k] = k2;
                k++;
            }
        }

        for(int l2 = 0; l2 < nob; l2++)
        {
            if(co[l2].colok != 15 && co[l2].colok != 27 && co[l2].colok != 28 && co[l2].colok != 41 && co[l2].colok != 44 && co[l2].colok != 52 && co[l2].colok != 53)
                continue;
            int l5 = -1;
            for(int l7 = 0; l7 < k; l7++)
            {
                if(co[ai1[l7]].colok > 14 && co[ai1[l7]].colok < 33 || co[ai1[l7]].colok >= 39)
                    continue;
                int i11 = pyn(co[l2].x, co[ai1[l7]].x, co[l2].z, co[ai1[l7]].z);
                if(i11 >= 0 && i11 < ((co[l2].maxR + co[ai1[l7]].maxR) / 100) * ((co[l2].maxR + co[ai1[l7]].maxR) / 100))
                    l5 = l7;
            }

            if(l5 != -1)
            {
                for(int i8 = k; i8 > l5; i8--)
                    ai1[i8] = ai1[i8 - 1];

                ai1[l5 + 1] = l2;
                k++;
            } else
            {
                ai1[k] = l2;
                k++;
            }
        }

        for(int i3 = 0; i3 < nob; i3++)
        {
            if((co[i3].colok < 16 || co[i3].colok > 25) && co[i3].colok != 40 && co[i3].colok != 42 && co[i3].colok != 43 && co[i3].colok != 45)
                continue;
            int i6 = -1;
            for(int j8 = 0; j8 < k; j8++)
            {
                if(co[ai1[j8]].colok > 14 && co[ai1[j8]].colok < 33 || co[ai1[j8]].colok >= 39)
                    continue;
                int j11 = pyn(co[i3].x, co[ai1[j8]].x, co[i3].z, co[ai1[j8]].z);
                if(j11 < 0 || j11 >= ((co[i3].maxR + co[ai1[j8]].maxR) / 100) * ((co[i3].maxR + co[ai1[j8]].maxR) / 100))
                    continue;
                if(ai[ai1[j8]] != 0)
                {
                    ai[ai1[j8]] = 0;
                    if(co[i3].colok != 20)
                        ai[i3] = 3;
                    else
                        ai[i3] = 5;
                }
                i6 = j8;
            }

            if(i6 != -1);
            if(i6 != -1)
            {
                for(int k8 = k; k8 > i6; k8--)
                    ai1[k8] = ai1[k8 - 1];

                ai1[i6 + 1] = i3;
                k++;
            } else
            {
                ai1[k] = i3;
                k++;
            }
        }

        for(int j3 = 0; j3 < nob; j3++)
        {
            if(co[j3].colok != 26 && co[j3].colok != 39)
                continue;
            boolean flag1 = false;
            if(Math.random() > Math.random())
            {
                flag1 = true;
                if(co[j3].colok == 39)
                    if(Math.random() > Math.random())
                        flag1 = false;
                    else
                    if(Math.random() > Math.random())
                        flag1 = false;
            }
            int l8 = -1;
            for(int k11 = 0; k11 < k; k11++)
            {
                if(co[ai1[k11]].colok > 14 && co[ai1[k11]].colok < 33 || co[ai1[k11]].colok >= 39)
                    continue;
                int l13 = pyn(co[j3].x, co[ai1[k11]].x, co[j3].z, co[ai1[k11]].z);
                if(l13 < 0 || l13 >= ((co[j3].maxR + co[ai1[k11]].maxR) / 100) * ((co[j3].maxR + co[ai1[k11]].maxR) / 100))
                    continue;
                boolean flag4 = false;
                if(co[j3].colok == 26)
                {
                    if(co[j3].roofat == 90 && co[ai1[k11]].x > co[j3].x)
                        flag4 = true;
                    if(co[j3].roofat == -90 && co[ai1[k11]].x < co[j3].x)
                        flag4 = true;
                    if(co[j3].roofat == 0 && co[ai1[k11]].z < co[j3].z)
                        flag4 = true;
                    if(co[j3].roofat == 180 && co[ai1[k11]].z > co[j3].z)
                        flag4 = true;
                }
                if(co[j3].colok == 39)
                {
                    if(co[j3].roofat == 90 && co[ai1[k11]].z > co[j3].z)
                        flag4 = true;
                    if(co[j3].roofat == -90 && co[ai1[k11]].z < co[j3].z)
                        flag4 = true;
                    if(co[j3].roofat == 0 && co[ai1[k11]].x > co[j3].x)
                        flag4 = true;
                    if(co[j3].roofat == 180 && co[ai1[k11]].x < co[j3].x)
                        flag4 = true;
                }
                if(!flag4)
                    continue;
                if(ai[ai1[k11]] == 1 && flag1)
                {
                    ai[ai1[k11]] = 0;
                    ai[j3] = 4;
                }
                l8 = k11;
            }

            if(l8 != -1)
            {
                for(int l11 = k; l11 > l8; l11--)
                    ai1[l11] = ai1[l11 - 1];

                ai1[l8 + 1] = j3;
                k++;
            } else
            {
                ai1[k] = j3;
                k++;
            }
        }

        for(int k3 = 0; k3 < nob; k3++)
            if(co[k3].colok >= 55 && co[k3].colok <= 65 || co[k3].colok == 66)
            {
                ai1[k] = k3;
                k++;
            }

        l3 = 0;
        j6 = 0;
        i9 = 0;
        i12 = 0;
        bstage = "";
        i14 = 0;
_L13:
        if(i14 >= k) goto _L2; else goto _L1
_L1:
        if(co[ai1[i14]].colok == 30 || co[ai1[i14]].colok == 31 || co[ai1[i14]].colok == 32 || co[ai1[i14]].colok == 54 || co[ai1[i14]].colok == 66) goto _L4; else goto _L3
_L3:
        String s;
        s = "";
        if(ai[ai1[i14]] == 1)
            s = "p";
        if(ai[ai1[i14]] == 2)
            s = "pt";
        if(ai[ai1[i14]] == 3)
            s = "pr";
        if(ai[ai1[i14]] == 4)
            s = "ph";
        if(ai[ai1[i14]] == 5)
            s = "pl";
        if(ai[ai1[i14]] == 6)
            s = "pr";
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "set(";
        append();
        co[ai1[i14]].colok + 10;
        append();
        ",";
        append();
        co[ai1[i14]].x;
        append();
        ",";
        append();
        co[ai1[i14]].z;
        append();
        ",";
        append();
        co[ai1[i14]].roofat;
        append();
        ")";
        append();
        s;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L4:
        if(co[ai1[i14]].colok != 30 && co[ai1[i14]].colok != 32) goto _L6; else goto _L5
_L5:
        if(co[ai1[i14]].roofat == 180)
            co[ai1[i14]].roofat = 0;
        s = "";
        if(co[ai1[i14]].wh != 0)
            s = "r";
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "chk(";
        append();
        co[ai1[i14]].colok + 10;
        append();
        ",";
        append();
        co[ai1[i14]].x;
        append();
        ",";
        append();
        co[ai1[i14]].z;
        append();
        ",";
        append();
        co[ai1[i14]].roofat;
        append();
        ")";
        append();
        s;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L6:
        if(co[ai1[i14]].colok != 54) goto _L8; else goto _L7
_L7:
        if(co[ai1[i14]].roofat == 180)
            co[ai1[i14]].roofat = 0;
        s = "";
        if(co[ai1[i14]].wh != 0)
            s = "r";
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "chk(";
        append();
        co[ai1[i14]].colok + 10;
        append();
        ",";
        append();
        co[ai1[i14]].x;
        append();
        ",";
        append();
        co[ai1[i14]].z;
        append();
        ",";
        append();
        co[ai1[i14]].roofat;
        append();
        ",";
        append();
        co[ai1[i14]].y;
        append();
        ")";
        append();
        s;
        append();
        "\r\n";
        append();
        toString();
        bstage;
_L8:
        if(co[ai1[i14]].colok != 31) goto _L10; else goto _L9
_L9:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "fix(";
        append();
        co[ai1[i14]].colok + 10;
        append();
        ",";
        append();
        co[ai1[i14]].x;
        append();
        ",";
        append();
        co[ai1[i14]].z;
        append();
        ",";
        append();
        co[ai1[i14]].y;
        append();
        ",";
        append();
        co[ai1[i14]].roofat;
        append();
        ")\r\n";
        append();
        toString();
        bstage;
_L10:
        if(co[ai1[i14]].colok != 66) goto _L12; else goto _L11
_L11:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "pile(";
        append();
        co[ai1[i14]].srz;
        append();
        ",";
        append();
        co[ai1[i14]].srx;
        append();
        ",";
        append();
        co[ai1[i14]].sry;
        append();
        ",";
        append();
        co[ai1[i14]].x;
        append();
        ",";
        append();
        co[ai1[i14]].z;
        append();
        ")\r\n";
        append();
        toString();
        bstage;
_L12:
        if(co[ai1[i14]].x + co[ai1[i14]].maxR > l3)
            l3 = co[ai1[i14]].x + co[ai1[i14]].maxR;
        if(co[ai1[i14]].x - co[ai1[i14]].maxR < i9)
            i9 = co[ai1[i14]].x - co[ai1[i14]].maxR;
        if(co[ai1[i14]].z + co[ai1[i14]].maxR > j6)
            j6 = co[ai1[i14]].z + co[ai1[i14]].maxR;
        if(co[ai1[i14]].z - co[ai1[i14]].maxR < i12)
            i12 = co[ai1[i14]].z - co[ai1[i14]].maxR;
        i14++;
          goto _L13
_L2:
        int k14;
        int l14;
        int k15;
        int i16;
        int j16;
        int k16;
        int l16;
        i14 = i9 - 0;
        k14 = l3 + 0;
        l14 = (int)((float)(k14 - i14) / 4800F) + 1;
        int i15 = (l14 * 4800 - (k14 - i14)) / 2;
        i14 -= i15;
        k14 += i15;
        k15 = i14 + 2400;
        i16 = i12 - 0;
        j16 = j6 + 0;
        k16 = (int)((float)(j16 - i16) / 4800F) + 1;
        i15 = (k16 * 4800 - (j16 - i16)) / 2;
        i16 -= i15;
        j16 += i15;
        l16 = i16 + 2400;
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        bstage;
        append();
        "\r\nmaxl(";
        append();
        k16;
        append();
        ",";
        append();
        i14;
        append();
        ",";
        append();
        l16;
        append();
        ")\r\nmaxb(";
        append();
        l14;
        append();
        ",";
        append();
        i16;
        append();
        ",";
        append();
        k15;
        append();
        ")\r\nmaxr(";
        append();
        k16;
        append();
        ",";
        append();
        k14;
        append();
        ",";
        append();
        l16;
        append();
        ")\r\nmaxt(";
        append();
        l14;
        append();
        ",";
        append();
        j16;
        append();
        ",";
        append();
        k15;
        append();
        ")\r\n";
        append();
        toString();
        bstage;
    }

    public void savefile()
    {
        try
        {
            File file = new File("mystages/");
            if(!file.exists())
                file.mkdirs();
            file = new File((new StringBuilder()).append("mystages/").append(stagename).append(".txt").toString());
            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
            bufferedwriter.write(tstage);
            bufferedwriter.write(bstage);
            bufferedwriter.close();
            bufferedwriter = null;
        }
        catch(Exception exception)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to save file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
        savesettings();
    }

    public void renstage(String s)
    {
        if(s.equals(""))
            JOptionPane.showMessageDialog(null, "Please Enter a New Stage Name!\n", "Stage Maker", 1);
        else
            try
            {
                File file = new File((new StringBuilder()).append("mystages/").append(stagename).append(".txt").toString());
                File file1 = new File((new StringBuilder()).append("mystages/").append(s).append(".txt").toString());
                if(file.renameTo(file1))
                {
                    stagename = s;
                    sfase = 0;
                    hidefields();
                    tabed = -2;
                } else
                {
                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to rename stage to: '").append(s).append("', possible reason: stage name already used!\n").toString(), "Stage Maker", 1);
                }
            }
            catch(Exception exception)
            {
                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to rename file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
            }
    }

    public void delstage(String s)
    {
        try
        {
            File file = new File((new StringBuilder()).append("mystages/").append(s).append(".txt").toString());
            file.delete();
            slstage.remove(s);
            slstage.select(0);
        }
        catch(Exception exception)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to delete file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
    }

    public void deltrack()
    {
        try
        {
            File file = new File((new StringBuilder()).append("mystages/mymusic/").append(tracks.getSelectedItem()).append(".zip").toString());
            file.delete();
            if(trackname.equals(tracks.getSelectedItem()))
            {
                trackname = "";
                sortop();
                savefile();
            }
            tracks.remove(tracks.getSelectedItem());
            tracks.select(0);
        }
        catch(Exception exception)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to delete file! Error Deatials:\n").append(exception).toString(), "Stage Maker", 1);
        }
    }

    public void loadsettings()
    {
        try
        {
            File file = new File("mystages/settings.data");
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String s = bufferedreader.readLine();
                if(s != null)
                {
                    sstage = s;
                    stagename = sstage;
                }
                s = bufferedreader.readLine();
                if(s != null)
                {
                    suser = s;
                    if(!suser.equals("Horaks"))
                        tnick.setText(suser);
                }
                bufferedreader.close();
                bufferedreader = null;
            }
        }
        catch(Exception exception) { }
    }

    public void savesettings()
    {
        if(!sstage.equals(stagename) || !suser.equals(tnick.getText()))
        {
            String s = (new StringBuilder()).append("").append(stagename).append("\n").append(tnick.getText()).append("\n\n").toString();
            sstage = stagename;
            suser = tnick.getText();
            try
            {
                File file = new File("mystages/");
                if(!file.exists())
                    file.mkdirs();
                file = new File("mystages/settings.data");
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                bufferedwriter.write(s);
                bufferedwriter.close();
                bufferedwriter = null;
            }
            catch(Exception exception) { }
        }
    }

    public void fixtext(TextField textfield)
    {
        String s = textfield.getText();
        s = s.replace('"', '#');
        String s1 = "\\";
        String s2 = "";
        int i = 0;
        int j = -1;
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        for(; i < s.length(); i++)
        {
            String s3 = (new StringBuilder()).append("").append(s.charAt(i)).toString();
            if(s3.equals("|") || s3.equals(",") || s3.equals("(") || s3.equals(")") || s3.equals("#") || s3.equals(s1) || s3.equals("!") || s3.equals("?") || s3.equals("~") || s3.equals(".") || s3.equals("@") || s3.equals("$") || s3.equals("%") || s3.equals("^") || s3.equals("&") || s3.equals("*") || s3.equals("+") || s3.equals("=") || s3.equals(">") || s3.equals("<") || s3.equals("/") || s3.equals(";") || s3.equals(":") || ftm.stringWidth(s2) > 274)
                j = i;
            else
                s2 = (new StringBuilder()).append(s2).append(s3).toString();
        }

        if(j != -1)
        {
            textfield.setText(s2);
            textfield.select(j, j);
        }
    }

    public void rot(int ai[], int ai1[], int i, int j, int k, int l)
    {
        if(k != 0)
        {
            for(int i1 = 0; i1 < l; i1++)
            {
                int j1 = ai[i1];
                int k1 = ai1[i1];
                ai[i1] = i + (int)((float)(j1 - i) * m.cos(k) - (float)(k1 - j) * m.sin(k));
                ai1[i1] = j + (int)((float)(j1 - i) * m.sin(k) + (float)(k1 - j) * m.cos(k));
            }

        }
    }

    public int xs(int i, int j)
    {
        if(j < m.cz)
            j = m.cz;
        return ((j - m.focus_point) * (m.cx - i)) / j + i;
    }

    public int ys(int i, int j)
    {
        if(j < m.cz)
            j = m.cz;
        return ((j - m.focus_point) * (m.cy - i)) / j + i;
    }

    public int py(int i, int j, int k, int l)
    {
        return (int)Math.sqrt((i - j) * (i - j) + (k - l) * (k - l));
    }

    public int pyn(int i, int j, int k, int l)
    {
        return ((i - j) / 100) * ((i - j) / 100) + ((k - l) / 100) * ((k - l) / 100);
    }

    public String getstring(String s, String s1, int i)
    {
        int k = 0;
        String s3 = "";
        for(int j = s.length() + 1; j < s1.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s1.charAt(j)).toString();
            if(s2.equals(",") || s2.equals(")"))
            {
                k++;
                j++;
            }
            if(k == i)
                s3 = (new StringBuilder()).append(s3).append(s1.charAt(j)).toString();
        }

        return s3;
    }

    public int getint(String s, String s1, int i)
    {
        int k = 0;
        String s3 = "";
        for(int j = s.length() + 1; j < s1.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s1.charAt(j)).toString();
            if(s2.equals(",") || s2.equals(")"))
            {
                k++;
                j++;
            }
            if(k == i)
                s3 = (new StringBuilder()).append(s3).append(s1.charAt(j)).toString();
        }

        return Integer.valueOf(s3).intValue();
    }

    public Image getImage(String s)
    {
        Image image = Toolkit.getDefaultToolkit().createImage(s);
        MediaTracker mediatracker = new MediaTracker(this);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        return image;
    }

    public int servervalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals("|"))
                {
                    l++;
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String serverSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals("|"))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    public int getvalue(String s, String s1, int i)
    {
        int k = 0;
        String s3 = "";
        for(int j = s.length() + 1; j < s1.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s1.charAt(j)).toString();
            if(s2.equals(",") || s2.equals(")"))
            {
                k++;
                j++;
            }
            if(k == i)
                s3 = (new StringBuilder()).append(s3).append(s1.charAt(j)).toString();
        }

        return Float.valueOf(s3).intValue();
    }

    public String getSvalue(String s, String s1, int i)
    {
        String s2 = "";
        int j = 0;
        for(int k = s.length() + 1; k < s1.length() && j <= i; k++)
        {
            String s3 = (new StringBuilder()).append("").append(s1.charAt(k)).toString();
            if(s3.equals(",") || s3.equals(")"))
            {
                j++;
                continue;
            }
            if(j == i)
                s2 = (new StringBuilder()).append(s2).append(s3).toString();
        }

        return s2;
    }

    public boolean button(String s, int i, int j, int k, boolean flag)
    {
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        int l = ftm.stringWidth(s);
        boolean flag1 = false;
        boolean flag2 = false;
        if(s.equals(" Cancel ") && epart && Math.abs(xm - i) < l / 2 + 12 && Math.abs((ym - j) + 5) < 10)
            overcan = true;
        if(Math.abs(xm - i) < l / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == 1)
            flag1 = true;
        else
            flag1 = false;
        if(Math.abs(xm - i) < l / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == -1)
        {
            mouses = 0;
            flag2 = true;
        }
        boolean flag3 = false;
        if(flag)
        {
            if(tab == 0)
                rd.setColor(new Color(207, 207, 207));
            if(tab == 1)
                rd.setColor(new Color(200, 200, 200));
            if(tab == 2)
                rd.setColor(new Color(170, 170, 170));
            if(tab != 3)
            {
                rd.drawRect(i - l / 2 - 15, j - (22 - k), l + 29, 34 - k * 2);
                if(k == 2 && tab == 1)
                {
                    rd.setColor(new Color(220, 220, 220));
                    rd.fillRect(i - l / 2 - 15, j - (22 - k), l + 29, 34 - k * 2);
                }
            } else
            {
                flag3 = true;
            }
        }
        if(!flag1)
        {
            rd.setColor(new Color(220, 220, 220));
            if(flag3)
                rd.setColor(new Color(230, 230, 230));
            rd.fillRect(i - l / 2 - 10, j - (17 - k), l + 20, 25 - k * 2);
            rd.setColor(new Color(240, 240, 240));
            if(flag3)
                rd.setColor(new Color(255, 255, 255));
            rd.drawLine(i - l / 2 - 10, j - (17 - k), i + l / 2 + 10, j - (17 - k));
            rd.drawLine(i - l / 2 - 10, j - (18 - k), i + l / 2 + 10, j - (18 - k));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - l / 2 - 9, j - (19 - k), i + l / 2 + 9, j - (19 - k));
            rd.setColor(new Color(200, 200, 200));
            if(flag3)
                rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i + l / 2 + 10, j - (17 - k), i + l / 2 + 10, j + (7 - k));
            rd.drawLine(i + l / 2 + 11, j - (17 - k), i + l / 2 + 11, j + (7 - k));
            rd.setColor(new Color(200, 200, 200));
            if(flag3)
                rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i + l / 2 + 12, j - (16 - k), i + l / 2 + 12, j + (6 - k));
            rd.drawLine(i - l / 2 - 10, j + (7 - k), i + l / 2 + 10, j + (7 - k));
            rd.drawLine(i - l / 2 - 10, j + (8 - k), i + l / 2 + 10, j + (8 - k));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i - l / 2 - 9, j + (9 - k), i + l / 2 + 9, j + (9 - k));
            rd.setColor(new Color(240, 240, 240));
            if(flag3)
                rd.setColor(new Color(255, 255, 255));
            rd.drawLine(i - l / 2 - 10, j - (17 - k), i - l / 2 - 10, j + (7 - k));
            rd.drawLine(i - l / 2 - 11, j - (17 - k), i - l / 2 - 11, j + (7 - k));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - l / 2 - 12, j - (16 - k), i - l / 2 - 12, j + (6 - k));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("  Keyboard Controls  "))
                rd.setColor(new Color(100, 100, 100));
            rd.drawString(s, i - l / 2, j);
        } else
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - l / 2 - 10, j - (17 - k), l + 20, 25 - k * 2);
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - l / 2 - 10, j - (17 - k), i + l / 2 + 10, j - (17 - k));
            rd.drawLine(i - l / 2 - 10, j - (18 - k), i + l / 2 + 10, j - (18 - k));
            rd.drawLine(i - l / 2 - 9, j - (19 - k), i + l / 2 + 9, j - (19 - k));
            rd.setColor(new Color(247, 247, 247));
            rd.drawLine(i + l / 2 + 10, j - (17 - k), i + l / 2 + 10, j + (7 - k));
            rd.drawLine(i + l / 2 + 11, j - (17 - k), i + l / 2 + 11, j + (7 - k));
            rd.drawLine(i + l / 2 + 12, j - (16 - k), i + l / 2 + 12, j + (6 - k));
            rd.drawLine(i - l / 2 - 10, j + (7 - k), i + l / 2 + 10, j + (7 - k));
            rd.drawLine(i - l / 2 - 10, j + (8 - k), i + l / 2 + 10, j + (8 - k));
            rd.drawLine(i - l / 2 - 9, j + (9 - k), i + l / 2 + 9, j + (9 - k));
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - l / 2 - 10, j - (17 - k), i - l / 2 - 10, j + (7 - k));
            rd.drawLine(i - l / 2 - 11, j - (17 - k), i - l / 2 - 11, j + (7 - k));
            rd.drawLine(i - l / 2 - 12, j - (16 - k), i - l / 2 - 12, j + (6 - k));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("  Keyboard Controls  "))
                rd.setColor(new Color(100, 100, 100));
            rd.drawString(s, (i - l / 2) + 1, j + 1);
        }
        return flag2;
    }

    public boolean ovbutton(String s, int i, int j)
    {
        rd.setFont(new Font("Arial", 0, 12));
        ftm = rd.getFontMetrics();
        if(s.equals("X") || s.equals("Download"))
        {
            rd.setFont(new Font("Arial", 1, 12));
            ftm = rd.getFontMetrics();
        }
        int k = ftm.stringWidth(s);
        byte byte0 = 4;
        boolean flag = false;
        boolean flag1 = false;
        if(Math.abs(xm - i) < k / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == 1)
            flag = true;
        else
            flag = false;
        if(Math.abs(xm - i) < k / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == -1)
        {
            mouses = 0;
            flag1 = true;
        }
        if(!flag)
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - k / 2 - 10, j - (17 - byte0), k + 20, 25 - byte0 * 2);
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i + k / 2 + 10, j - (17 - byte0));
            rd.drawLine(i - k / 2 - 10, j - (18 - byte0), i + k / 2 + 10, j - (18 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 9, j - (19 - byte0), i + k / 2 + 9, j - (19 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i + k / 2 + 10, j - (17 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 11, j - (17 - byte0), i + k / 2 + 11, j + (7 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i + k / 2 + 12, j - (16 - byte0), i + k / 2 + 12, j + (6 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (7 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (8 - byte0), i + k / 2 + 10, j + (8 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i - k / 2 - 9, j + (9 - byte0), i + k / 2 + 9, j + (9 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i - k / 2 - 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 11, j - (17 - byte0), i - k / 2 - 11, j + (7 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 12, j - (16 - byte0), i - k / 2 - 12, j + (6 - byte0));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("X"))
                rd.setColor(new Color(255, 0, 0));
            if(s.equals("Download"))
                rd.setColor(new Color(0, 64, 128));
            rd.drawString(s, i - k / 2, j);
        } else
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - k / 2 - 10, j - (17 - byte0), k + 20, 25 - byte0 * 2);
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i + k / 2 + 10, j - (17 - byte0));
            rd.drawLine(i - k / 2 - 10, j - (18 - byte0), i + k / 2 + 10, j - (18 - byte0));
            rd.drawLine(i - k / 2 - 9, j - (19 - byte0), i + k / 2 + 9, j - (19 - byte0));
            rd.setColor(new Color(247, 247, 247));
            rd.drawLine(i + k / 2 + 10, j - (17 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 11, j - (17 - byte0), i + k / 2 + 11, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 12, j - (16 - byte0), i + k / 2 + 12, j + (6 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (7 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (8 - byte0), i + k / 2 + 10, j + (8 - byte0));
            rd.drawLine(i - k / 2 - 9, j + (9 - byte0), i + k / 2 + 9, j + (9 - byte0));
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i - k / 2 - 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 11, j - (17 - byte0), i - k / 2 - 11, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 12, j - (16 - byte0), i - k / 2 - 12, j + (6 - byte0));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("X"))
                rd.setColor(new Color(255, 0, 0));
            if(s.equals("Download"))
                rd.setColor(new Color(0, 64, 128));
            rd.drawString(s, (i - k / 2) + 1, j + 1);
        }
        return flag1;
    }

    public void openlink()
    {
        Madness.openurl("http://www.needformadness.com/developer/help.html");
    }

    public void openhlink()
    {
        Madness.openurl("http://www.needformadness.com/developer/");
    }

    Graphics2D rd;
    Image offImage;
    Thread thredo;
    boolean exwist;
    FontMetrics ftm;
    int apx;
    int apy;
    String sstage;
    String suser;
    int tab;
    int tabed;
    Image btgame[];
    Image logo;
    boolean onbtgame;
    boolean focuson;
    boolean overcan;
    boolean left;
    boolean right;
    boolean up;
    boolean down;
    boolean zoomi;
    boolean zoomo;
    String stagename;
    String tstage;
    String bstage;
    String undos[];
    int nundo;
    Medium m;
    CheckPoints cp;
    Trackers t;
    ContO bco[];
    ContO co[];
    int nob;
    int xnob;
    int errd;
    int origfade;
    int sfase;
    Smenu slstage;
    TextField srch;
    Smenu strtyp;
    Smenu ptyp;
    Smenu part;
    int sptyp;
    int spart;
    int sp;
    int lsp;
    int seq;
    boolean setcur;
    boolean epart;
    boolean arrng;
    int esp;
    int hi;
    int arrcnt;
    int chi;
    boolean seqn;
    int rot;
    int adrot;
    Image su[];
    Image sl[];
    Image sd[];
    Image sr[];
    Image zi[];
    Image zo[];
    boolean pgen;
    float pwd;
    float phd;
    int fgen;
    int sx;
    int sz;
    int sy;
    TextField fixh;
    int hf;
    int atp[][] = {
        {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            1520, 2830, -1520, -2830
        }, {
            -1520, 2830, 1520, -2830
        }, {
            0, -1750, 1750, 0
        }, {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            0, -1750, 1750, 0
        }, {
            0, 2800, 0, -2800
        }, {
            0, -1750, 1750, 0
        }, {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            0, 560, 0, -560
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            385, 980, 385, -980
        }, {
            0, 0, 0, -600
        }, {
            0, 0, 0, 0
        }, {
            0, 2164, 0, -2164
        }, {
            0, 2164, 0, -2164
        }, {
            0, 3309, 0, -1680
        }, {
            0, 1680, 0, -3309
        }, {
            350, 0, -350, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            1810, 980, 1810, -980
        }, {
            0, 0, 0, 0
        }, {
            0, 500, 0, -500
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            0, 1680, 0, -3309
        }, {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            0, 2800, 0, -2800
        }, {
            700, 1400, 700, -1400
        }, {
            0, -1480, 0, -1480
        }, {
            0, 0, 0, 0
        }, {
            350, 0, -350, 0
        }, {
            0, 0, 0, 0
        }, {
            700, 0, -700, 0
        }, {
            0, 0, 0, 0
        }, {
            0, -2198, 0, 1482
        }, {
            0, -1319, 0, 1391
        }, {
            0, -1894, 0, 2271
        }, {
            0, -826, 0, 839
        }, {
            0, -1400, 0, 1400
        }, {
            0, -1400, 0, 1400
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }, {
            0, 0, 0, 0
        }
    };
    String discp[] = {
        "NormalRoad :  Basic asphalt road.\nAttaches correctly to the following other parts :\n\n'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',  'NormalRoad Edged',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad Edged :  Asphalt road with edged side blocks (a destructive road).\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad TwistedRight :  Asphalt road twisted towards the right.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad Twistedleft',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad TwistedLeft :  Asphalt road twisted towards the left.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "NormalRoad Turn :  Asphalt corner road turn.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp', 'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "OffRoad :  Basic sandy dirt-road.\nAttaches correctly to the following other parts :\n\n'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "OffRoad BumpyGreen :  Dirt-road with bumpy greenery in the middle.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "OffRoad Turn :  Dirt-road corner turn.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad End',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand 'Normal-Off-Road Blend'\n\n", "HalfpipeRoad :  Basic road for the half-pipe ramp.\nAttaches correctly to the following other parts :\n\n'Off-Halfpipe-Road Blend',  'HalfpipeRoad',  'HalfpipeRoad Turn',  'HalfpipeRoad-Ramp Filler'\nand  'Halfpipe-Normal-Road Blend'\n\n", "HalfpipeRoad Turn :  Half-pipe corner road turn.\nAttaches correctly to the following other parts :\n\n'HalfpipeRoad',  'Off-Halfpipe-Road Blend',  'HalfpipeRoad'  and  'Halfpipe-Normal-Road Blend'\n\n", 
        "Normal-Off-Road Blend :  Road blend between the normal asphalt road and the dirt-road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'NormalRoad-Raised Ramp', 'Halfpipe-Normal-Road Blend' 'OffRoad',  'OffRoad Turn',\n'OffRoad End',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start'  and  'Off-Halfpipe-Road Blend'\n\n", "Off-Halfpipe-Road Blend :  Road blend between the dirt-road and the half-pipe road.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start',\n'HalfpipeRoad',  'HalfpipeRoad Turn',  'Halfpipe-Normal-Road Blend'  and  'Normal-Off-Road Blend'\n\n", "Halfpipe-Normal-Road Blend :  Road blend between the normal asphalt road and the half-pipe road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'NormalRoad-Raised Ramp',  'HalfpipeRoad',  'Off-Halfpipe-Road Blend',  'HalfpipeRoad'\nand  'Off-Halfpipe-Road Blend'\n\n", "NormalRoad End :  The end part of the normal asphalt road.\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad Edged',  'NormalRoad TwistedLeft',  'NormalRoad TwistedRight',\n'NormalRoad-Raised Ramp',  'Normal-Off-Road Blend'  and  'Halfpipe-Normal-Road Blend'\n\n", "OffRoad End :  The end part of the dirt-road.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad BumpyGreen',  ' OffRoad-BumpySides Start',  'Off-Halfpipe-Road Blend'\nand  'Normal-Off-Road Blend'\n\n", "HalfpipeRoad-Ramp Filler :  A part that gets placed between the half-pipe road and the half-pipe ramp to extend the distance in between.\nAttaches correctly to the following other parts :\n\n'HalfpipeRoad'  and  'Halfpipe'\n\n", "Basic Ramp :  Basic 30 degree asphalt ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Crash Ramp :  A 35 degree ramp with big side blocks for crashing into.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Two-Way Ramp :  Two way 15 degree inclined ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Two-Way High-Low Ramp :  Two way 15 degree inclined ramp, with peeked side for an optional higher car jump.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", 
        "Landing Ramp :  A ramp that is both a landing inclination and an obstacle as well, it is usually placed just after another normal ramp.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Big-Takeoff Ramp:  A big takeoff ramp for getting huge heights with the cars.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Small Ramp :  A small ramp that can be placed on either side of the road.\nAttaches correctly over and to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand   'NormalRoad TwistedRight'\n\n", "Offroad Bump Ramp :  A small bump ramp that is to be placed over the off-road dirt tracks.\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Offroad Big Ramp :  The big off-road dirt mountain like ramp!\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Offroad Ramp :  Normal sized off-road dirt track ramp!\nAttaches correctly over and to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Halfpipe :  The Half-pipe ramp, two of these ramps opposite each other create a half-pipe for the cars!\nAttaches correctly over and to the following other parts :\n\n'HalfpipeRoad',  'HalfpipeRoad Turn'  and  'HalfpipeRoad-Ramp Filler'\n\n", "Spiky Pillars :  An obstacle that is usually placed after a ramp for the cars to crash onto if they did not jump high or far enough!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Rail Doorway :  A rail doorway that works as an obstacle for cars flying above it or cars driving through it!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "The Wall", 
        "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "Fixing Hoop :  The fixing hoop that fixes a car when it flies through it! You can add a max of 5 fixing hoops per stage.\nPlace it anywhere in the stage at an height your choose, the only important thing is that it needs to be reachable by the cars.", "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "OffRoad BumpySides :  Off-road dirt track with bumpy sandbar sides.\nAttaches correctly to the following other parts :\n\n'OffRoad-BumpySides Start'\n\n", "OffRoad-BumpySides Start: The start of the off-road dirt track with bumpy sandbar sides.\nAttaches correctly to the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides',\n'Off-Halfpipe-Road Blend'  and  'Normal-Off-Road Blend'\n\n", "NormalRoad-Raised Ramp:  The start of the raised above the ground road (NormalRoad Raised).\nAttaches correctly to the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight'  and  'NormalRoad Raised'\n\n", "NormalRoad Raised :  Normal road raised above the ground, cars must avoid falling off it when driving on it.\nAttaches correctly to the following other parts :\n\n'NormalRoad-Raised Ramp'\n\n", "The Start1", "The Start2", "Tunnel Side Ramp:  A ramp that can be used to create a tunnel like road with an open top or can be used as a wall ramp!\nAttaches correctly over only the 'NormalRoad' part.", 
        "Launch Pad Ramp:  A ramp that launches your car fully upwards like a rocket, it also has sides to lock any car climbing it!\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "The Net:  An obstacle part that is to be placed in the center of the road right after a ramp, the idea is that the\ncars jumping the ramp should try to go over it or through it without getting caught crashing (without getting\ncaught in it, getting caught in the net!).\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Speed Ramp:  A ramp that is designed to have the perfect angle to catapult your car the furthest when doing forward loops, it is half the roads width.\nAttaches correctly over following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Offroad Hill Ramp:  An offroad hill ramp that has two different inclines from the front and back to jump.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Bump Slide:  A small bump obstacle that is to be placed on the sides of the road or in the center.\nAttaches correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft'\nand  'NormalRoad TwistedRight'\n\n", "Offroad Big Hill Ramp:  An offroad big hill ramp that has two different inclines from the front and back to jump.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',  'OffRoad-BumpySides Start'\nand  'OffRoad-BumpySides'\n\n", "Rollercoaster Start/End:  The ramp that starts the Rollercoaster Road and ends it.\nAttaches correctly over and to following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n 'NormalRoad TwistedRight'  and  'Rollercoaster Start/End'\n\n", "Rollercoaster Road1\nAttaches correctly to only 'Rollercoaster Start/End', 'Rollercoaster Road2' and itself.\n\n", "Rollercoaster Road3\nAttaches correctly to only 'Rollercoaster Road2', 'Rollercoaster Road4' and itself.\n\n", "Rollercoaster Road4\nAttaches correctly to only 'Rollercoaster Road3', 'Rollercoaster Road5' and itself.\n\n", 
        "Rollercoaster Road2\nAttaches correctly to only 'Rollercoaster Road1', 'Rollercoaster Road3' and itself.\n\n", "Rollercoaster Road5\nAttaches correctly to only 'Rollercoaster Road4' and itself.\n\n", "Offroad Dirt-Pile:  A dirt pile obstacle that is to be placed anywhere in the middle of the road.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start'  and  'OffRoad-BumpySides'\n\n", "Offroad Dirt-Pile:  A dirt pile obstacle that is to be placed anywhere in the middle of the road.\nAttaches correctly over the following other parts :\n\n'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad-BumpySides Start'  and  'OffRoad-BumpySides'\n\n", "Checkpoint :  The checkpoint part that ultimately decides how you stage is raced, place carefully with thought.\n(Any stage must have at least two checkpoints to work).\nMounts correctly over the following other parts :\n\n'NormalRoad',  'NormalRoad Turn',  'NormalRoad End',  'NormalRoad Edged',  'NormalRoad TwistedLeft',\n'NormalRoad TwistedRight',  'OffRoad',  'OffRoad Turn',  'OffRoad End',  'OffRoad BumpyGreen',\n'OffRoad-BumpySides Start',  'OffRoad-BumpySides',  'Rollercoaster Start/End'  and  'Rollercoaster Road 2,3,4 and 5'\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", 
        "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Trees/Cactus are decorative stage parts that should be placed outside the race track on the ground and NEVER on any road part or ramp!\nTrees/Cactus are not to be used as obstacles of the race course!\nThey are to be used as out of path ground decoration only.\n\n", "Ground Piles are to be paced outside the race track on the ground and NEVER on any road part or ramp!\nThey are to be used as ground decoration and out of race course obstacles (ground obstacles)!\n\n"
    };
    String errlo[] = {
        "The maximum allocated memory for the stage's part's details has been exerted.\nPlease decrease the amount of parts in the stage that have more details then average.", "The maximum amount of road points allowed in the track has been exceeded.\nPlease remove some of the road parts that are in the circler path of the track (the parts that are between the checkpoints).\nOr try to remove some of the extra checkpoints in the track as well.", "The maximum allowed area for a track (the area in between its walls) has been exceeded.\nPlease try to place parts only inside the current allowed area, inside the area between the current maximum wall placements.", "The maximum number of parts allowed per stage has been exceeded.\nPlease remove some of the already extra parts placed in order to make space.", "The maximum number of Fixing Hoops allowed per stage is 5!\nPlease remove the extra Fixing Hoops from your stage to have only 5 main ones left.", "Unknown Error, please make sure the stage you are handling is saved correctly.\nPlease go to the 'Build' tab and press 'Save & Preview'.", "There needs to be at least 2 checkpoints in the Stage in order for the game to work.\nPlease go to the 'Build' tab and select 'Checkpoint' in the Part Selection menu to add more checkpoints.", "The name of the stage is too long!\nPlease go to the 'Stage' tab, click 'Rename Stage' and give your stage a shorter name."
    };
    int rcheckp[] = {
        0, 1, 2, 3, 4, 12, 13, 37
    };
    int ocheckp[] = {
        5, 6, 7, 11, 14, 33, 34, 38
    };
    boolean onoff;
    boolean onfly;
    int flyh;
    int csky[] = {
        170, 220, 255
    };
    int cgrnd[] = {
        205, 200, 200
    };
    int cfade[] = {
        255, 220, 220
    };
    int texture[] = {
        0, 0, 0, 10
    };
    int cldd[] = {
        210, 210, 210, 1, -1000
    };
    TextField mgen;
    int vxz;
    int vx;
    int vz;
    int vy;
    int dtab;
    int dtabed;
    int mouseon;
    float hsb[][] = {
        {
            0.5F, 0.875F, 0.5F
        }, {
            0.5F, 0.875F, 0.5F
        }, {
            0.5F, 0.875F, 0.5F
        }
    };
    Checkbox pfog;
    int snap[] = {
        50, 50, 50
    };
    int fogn[] = {
        60, 0
    };
    Smenu nlaps;
    Smenu tracks;
    String trackname;
    String ltrackname;
    int trackvol;
    int tracksize;
    RadicalMod track;
    int avon;
    Smenu witho;
    int logged;
    TextField tnick;
    TextField tpass;
    Smenu pubitem;
    Smenu pubtyp;
    int nms;
    int roto;
    String mystages[];
    String maker[];
    int pubt[];
    String addeda[][];
    int nad[];
    String justpubd;
    boolean pessd[] = {
        false, false, false, false, false, false, false, false, false, false, 
        false, false, false, false, false, false, false, false, false, false, 
        false, false, false, false
    };
    int bx[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int by[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int bw[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int btn;
    int mouses;
    int xm;
    int ym;
    int lxm;
    int lym;
    int cntout;
    boolean preop;
    boolean mousdr;
    String ttstage;
}
