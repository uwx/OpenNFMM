// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CarMaker.java

import java.applet.Applet;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.swing.JOptionPane;

public class CarMaker extends Applet
    implements Runnable, ActionListener
{

    public CarMaker()
    {
        exwist = false;
        apx = 0;
        apy = 0;
        focuson = true;
        btgame = new Image[2];
        onbtgame = false;
        tab = 0;
        tabed = -1;
        loadedfile = false;
        carname = "";
        scar = "";
        suser = "Horaks";
        sfont = "Monospaced";
        sthm = 0;
        sfase = 0;
        slcar = new Smenu(2000);
        tutok = false;
        flk = 0;
        changed = false;
        lastedo = "";
        prefs = false;
        mirror = false;
        editor = new TextArea(20, 20);
        srch = new TextField("", 15);
        rplc = new TextField("", 15);
        fontsel = new Smenu(40);
        cfont = "Monospaced";
        ctheme = new Smenu(40);
        cthm = 0;
        cntprf = 0;
        cntpls = 0;
        cntchk = 0;
        npolys = 0;
        tomany = false;
        ox = 335;
        oy = 40;
        oz = 800;
        oxz = -90;
        oxy = 0;
        ozy = 0;
        m = new Medium();
        t = new Trackers();
        compo = new ContO[16];
        right = false;
        left = false;
        up = false;
        down = false;
        rotl = false;
        rotr = false;
        plus = false;
        minus = false;
        in = false;
        out = false;
        pflk = false;
        breakbond = false;
        polynum = -1;
        prflk = 0;
        bfo = 0;
        dtab = 0;
        dtabed = -1;
        mouseon = -1;
        fcol = "";
        ofcol = "";
        scol = "";
        oscol = "";
        compcar = new Smenu(40);
        compsel = 0;
        changed2 = false;
        wv = new TextField[16];
        defnow = false;
        aply1 = "";
        aply2 = "";
        aplyd1 = false;
        aplyd2 = false;
        forwheels = false;
        cls = new Smenu(40);
        simcar = new Smenu(40);
        carsel = 0;
        clsel = 0;
        statdef = false;
        pfase = 0;
        hitmag = 0;
        actmag = 0;
        squash = 0;
        crashok = false;
        crashleft = false;
        crashs = new soundClip[3];
        lowcrashs = new soundClip[3];
        engine = new Smenu(40);
        engs = new soundClip[5][5];
        engsel = 0;
        engon = false;
        witho = new Smenu(40);
        tested = false;
        rateh = false;
        handling = 140;
        logged = 0;
        tnick = new TextField("", 15);
        tpass = new TextField("", 15);
        pubitem = new Smenu(707);
        pubtyp = new Smenu(40);
        nmc = 0;
        roto = 0;
        mycars = new String[20];
        maker = new String[20];
        pubt = new int[20];
        clas = new int[20];
        addeda = new String[20][5000];
        nad = new int[20];
        justpubd = "";
        btn = 0;
        mouses = 0;
        xm = 0;
        ym = 0;
        sls = -1;
        sle = -1;
        crshturn = 0;
        crashup = false;
        openm = false;
        mousdr = false;
        waso = false;
        objfacend = false;
        multf10 = false;
    }

    public void run()
    {
        thredo.setPriority(10);
        btgame[0] = getImage("data/backtogame1.gif");
        btgame[1] = getImage("data/backtogame2.gif");
        logo = getImage("data/carmakerlogo.gif");
        m.w = 700;
        m.cx = 350;
        m.y = -240;
        m.z = -400;
        m.zy = 4;
        m.focus_point = 800;
        m.fadfrom(8000);
        m.cfade[0] = 187;
        m.cfade[1] = 210;
        m.cfade[2] = 227;
        loadsounds();
        loadbase();
        m.loadnew = true;
        loadsettings();
        editor.setFont(new Font(cfont, 1, 14));
        srch.setFont(new Font(cfont, 1, 14));
        rplc.setFont(new Font(cfont, 1, 14));
        for(int i = 0; i < 16; i++)
            wv[i].setFont(new Font(cfont, 1, 14));

        setheme();
        if(Madness.testdrive != 0)
        {
            if(Madness.testcar.equals("Failx12"))
            {
                JOptionPane.showMessageDialog(null, "Failed to load car! Please make sure car is saved before Test Drive.", "Car Maker", 1);
                thredo.stop();
            } else
            {
                carname = Madness.testcar;
                loadfile();
                if(loadedfile)
                {
                    tested = true;
                    tab = 2;
                    dtab = 6;
                    witho.select(Madness.testdrive - 1);
                }
            }
            Madness.testcar = "";
            Madness.testdrive = 0;
        }
        boolean flag = false;
        if(!carname.equals(""))
        {
            tutok = true;
            flag = true;
        }
        do
        {
            if(exwist)
                break;
            if(tab != tabed)
            {
                hidefields();
                if(tab == 1)
                    editor.enable();
                else
                    editor.disable();
                if(tabed == 2)
                    if(!breakbond)
                    {
                        if(!editor.getText().equals(lastedo))
                            editor.setText(lastedo);
                    } else
                    {
                        breakbond = false;
                    }
                setCursor(new Cursor(0));
            }
            rd.setColor(new Color(225, 225, 225));
            rd.fillRect(0, 0, 700, 550);
            rd.setColor(new Color(0, 0, 0));
            btn = 0;
            int j = 50;
            if(tab == 0)
            {
                if(tabed != tab)
                {
                    slcar.removeAll();
                    slcar.maxl = 200;
                    slcar.add(rd, "Select a Car                      ");
                    String as[] = (new File("mycars/")).list();
                    if(as != null)
                    {
                        for(int k1 = 0; k1 < as.length; k1++)
                            if(as[k1].toLowerCase().endsWith(".rad"))
                                slcar.add(rd, as[k1].substring(0, as[k1].length() - 4));

                    }
                    if(carname.equals(""))
                    {
                        slcar.select(0);
                    } else
                    {
                        slcar.select(carname);
                        if(carname.equals(slcar.getSelectedItem()))
                            loadfile();
                    }
                    mouseon = -1;
                    srch.setText("");
                    sfase = 0;
                }
                rd.setFont(new Font("Arial", 1, 13));
                rd.setColor(new Color(0, 0, 0));
                rd.drawImage(logo, 214, 35, null);
                if(xm > 214 && xm < 485 && ym > 25 && ym < 104 && !openm)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 3;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 3)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                if(mouseon == 3 && mouses == -1)
                    openhlink();
                char c = '\036';
                byte byte0 = 0;
                if(tutok)
                {
                    c = '\372';
                    byte0 = -70;
                }
                if(xm > 76 && xm < 624 && ym > 84 + c && ym < 167 + c && !openm)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 1;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 1)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                byte byte1 = 0;
                if(!tutok && mouseon != 1 && !flag)
                    if(flk <= 0)
                    {
                        rd.setColor(new Color(255, 0, 0));
                        flk--;
                        if(flk == -2)
                            flk = 1;
                    } else
                    {
                        rd.setColor(new Color(0, 0, 255));
                        byte1 = 2;
                        flk++;
                        if(flk == 3)
                            flk = 0;
                    }
                rd.drawLine(76 + byte1, 84 + c, 76 + byte1, 167 + c);
                rd.drawLine(76 + byte1, 84 + c, 95 + byte1, 84 + c);
                rd.drawLine(76 + byte1, 167 + c, 95 + byte1, 167 + c);
                rd.drawLine(624 - byte1, 84 + c, 624 - byte1, 167 + c);
                rd.drawLine(624 - byte1, 84 + c, 605 - byte1, 84 + c);
                rd.drawLine(624 - byte1, 167 + c, 605 - byte1, 167 + c);
                if(mouseon == 1)
                    rd.setColor(new Color(0, 64, 128));
                else
                    rd.setColor(new Color(0, 0, 0));
                rd.drawString("If this is your first time creating a car please follow the tutorial found at:", 106, 110 + c);
                rd.setColor(new Color(0, 128, 255));
                rd.drawString("http://www.needformadness.com/developer/simplecar.html", 106, 130 + c);
                if(mouseon == 1)
                    rd.setColor(new Color(0, 128, 255));
                else
                    rd.setColor(new Color(0, 64, 128));
                rd.drawLine(106, 131 + c, 480, 131 + c);
                if(mouseon == 1)
                    rd.setColor(new Color(0, 64, 128));
                else
                    rd.setColor(new Color(0, 0, 0));
                rd.drawString("It is highly recommended that you follow this tutorial before trying anything!", 106, 150 + c);
                if(mouseon == 1 && mouses == -1)
                {
                    openlink();
                    flag = true;
                }
                if(xm > 200 && xm < 500 && ym > 467 && ym < 504 && !openm)
                {
                    if(mouseon == -1)
                    {
                        mouseon = 2;
                        setCursor(new Cursor(12));
                    }
                } else
                if(mouseon == 2)
                {
                    mouseon = -1;
                    setCursor(new Cursor(0));
                }
                ftm = rd.getFontMetrics();
                if(mouseon == 2)
                    rd.setColor(new Color(0, 64, 128));
                else
                    rd.setColor(new Color(0, 0, 0));
                rd.drawString("For the Car Maker Homepage, Development Center and Forums :", 350 - ftm.stringWidth("For the Car Maker Homepage, Development Center and Forums :") / 2, 480);
                rd.setColor(new Color(0, 128, 255));
                String s7 = "http://www.needformadness.com/developer/";
                rd.drawString(s7, 350 - ftm.stringWidth(s7) / 2, 500);
                if(mouseon == 2)
                    rd.setColor(new Color(0, 128, 255));
                else
                    rd.setColor(new Color(0, 64, 128));
                rd.drawLine(350 - ftm.stringWidth(s7) / 2, 501, 350 + ftm.stringWidth(s7) / 2, 501);
                if(mouseon == 2 && mouses == -1)
                    openhlink();
                byte byte3 = 0;
                if(sfase == 3)
                    byte3 = 100;
                rd.setColor(new Color(0, 0, 0));
                rd.drawRect(177 - byte3, 202 + byte0, 346 + byte3 * 2, 167 + byte3 / 5);
                if(sfase == 0)
                {
                    rd.drawString("Select Car to Edit", 350 - ftm.stringWidth("Select Car to Edit") / 2, 230 + byte0);
                    slcar.move(250, 240 + byte0);
                    if(slcar.getWidth() != 200)
                        slcar.setSize(200, 21);
                    if(!slcar.isShowing())
                        slcar.show();
                    stringbutton("    Make new Car    ", 430, 296 + byte0, 0, true);
                    stringbutton("     Rename Car     ", 270, 296 + byte0, 0, false);
                    stringbutton("      Delete Car      ", 270, 336 + byte0, 0, false);
                    stringbutton("     Import & Export     ", 430, 336 + byte0, 0, false);
                    if(slcar.getSelectedIndex() != 0)
                    {
                        if(!carname.equals(slcar.getSelectedItem()))
                        {
                            tomany = false;
                            carname = slcar.getSelectedItem();
                            loadfile();
                            editor.select(0, 0);
                            tested = false;
                            requestFocus();
                        }
                    } else
                    {
                        carname = "";
                    }
                }
                if(sfase == 1)
                {
                    rd.drawString("Make a new Car", 350 - ftm.stringWidth("Make a new Car") / 2, 230 + byte0);
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.drawString("New car name :", 228, 266 + byte0);
                    movefield(srch, 335, 250 + byte0, 129, 22);
                    if(!srch.isShowing())
                    {
                        srch.show();
                        srch.requestFocus();
                    }
                    fixtext(srch);
                    stringbutton("    Make Car    ", 350, 306 + byte0, 0, true);
                    stringbutton("  Cancel  ", 350, 346 + byte0, 0, false);
                }
                if(sfase == 2)
                {
                    rd.drawString((new StringBuilder()).append("Rename Car :  ").append(carname).append("").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Rename Car :  ").append(carname).append("").toString()) / 2, 230 + byte0);
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.drawString("New name :", 239, 266 + byte0);
                    movefield(srch, 316, 250 + byte0, 129, 22);
                    if(!srch.isShowing())
                    {
                        srch.show();
                        srch.requestFocus();
                    }
                    fixtext(srch);
                    stringbutton("   Rename Car   ", 350, 306 + byte0, 0, true);
                    stringbutton("  Cancel  ", 350, 346 + byte0, 0, false);
                }
                if(sfase == 3)
                {
                    rd.drawString("Import a Wavefront OBJ 3D Model", 350 - ftm.stringWidth("Import a Wavefront OBJ 3D Model") / 2, 230 + byte0);
                    if(xm > 116 && xm < 584 && ym > 246 + byte0 && ym < 290 + byte0)
                    {
                        if(mouseon == -1)
                        {
                            mouseon = 3;
                            setCursor(new Cursor(12));
                        }
                    } else
                    if(mouseon == 3)
                    {
                        mouseon = -1;
                        setCursor(new Cursor(0));
                    }
                    ftm = rd.getFontMetrics();
                    if(mouseon == 3)
                        rd.setColor(new Color(0, 64, 128));
                    else
                        rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Please read the important information about importing cars found at:", 350 - ftm.stringWidth("Please read the important information about importing cars, found here :") / 2, 260 + byte0);
                    rd.setColor(new Color(0, 128, 255));
                    String s8 = "http://www.needformadness.com/developer/extras.html";
                    rd.drawString(s8, 350 - ftm.stringWidth(s8) / 2, 280 + byte0);
                    if(mouseon == 3)
                        rd.setColor(new Color(0, 128, 255));
                    else
                        rd.setColor(new Color(0, 64, 128));
                    rd.drawLine(350 - ftm.stringWidth(s8) / 2, 281 + byte0, 350 + ftm.stringWidth(s8) / 2, 281 + byte0);
                    if(mouseon == 3 && mouses == -1)
                        openelink();
                    stringbutton("     Import Car     ", 350, 326 + byte0, 0, true);
                    stringbutton("  Export >  ", 550, 326 + byte0, 0, false);
                    stringbutton("  Cancel  ", 350, 366 + byte0, 0, false);
                }
                if(sfase == 4)
                {
                    rd.drawString("Select Car to Export", 350 - ftm.stringWidth("Select Car to Export") / 2, 230 + byte0);
                    slcar.move(250, 240 + byte0);
                    if(slcar.getWidth() != 200)
                        slcar.setSize(200, 21);
                    if(!slcar.isShowing())
                        slcar.show();
                    stringbutton("     Export Car     ", 350, 306 + byte0, 0, true);
                    stringbutton("  Cancel  ", 350, 346 + byte0, 0, false);
                    if(slcar.getSelectedIndex() != 0)
                    {
                        if(!carname.equals(slcar.getSelectedItem()))
                        {
                            tomany = false;
                            carname = slcar.getSelectedItem();
                            loadfile();
                            editor.select(0, 0);
                            tested = false;
                            requestFocus();
                        }
                    } else
                    {
                        carname = "";
                    }
                }
            }
            if(tab == 1)
            {
                if(tabed != tab)
                {
                    srch.setText("");
                    rplc.setText("");
                    cntchk = 1;
                    npolys = 0;
                    prefs = false;
                }
                movefield(editor, 5, 30, 690, 400);
                if(!openm)
                {
                    if(!editor.isShowing())
                    {
                        editor.show();
                        editor.requestFocus();
                    }
                } else
                if(editor.isShowing())
                    editor.hide();
                rd.setFont(new Font("Arial", 1, 12));
                if(prefs)
                {
                    rd.drawString("Code Font:", 10, 446);
                    fontsel.move(76, 430);
                    if(!fontsel.isShowing())
                    {
                        fontsel.show();
                        fontsel.select(cfont);
                    }
                    if(!cfont.equals(fontsel.getSelectedItem()))
                    {
                        cntprf = 0;
                        cfont = fontsel.getSelectedItem();
                        editor.setFont(new Font(cfont, 1, 14));
                        srch.setFont(new Font(cfont, 1, 14));
                        rplc.setFont(new Font(cfont, 1, 14));
                        for(int k = 0; k < 16; k++)
                            wv[k].setFont(new Font(cfont, 1, 14));

                        editor.requestFocus();
                    }
                    rd.drawString("Code Theme:", 190, 446);
                    ctheme.move(271, 430);
                    if(!ctheme.isShowing())
                    {
                        ctheme.show();
                        ctheme.select(cthm);
                    }
                    if(cthm != ctheme.getSelectedIndex())
                    {
                        cntprf = 0;
                        cthm = ctheme.getSelectedIndex();
                        setheme();
                        editor.requestFocus();
                    }
                    stringbutton("<", 400, 446, 3, false);
                    cntprf++;
                    if(cntprf == 200)
                        prefs = false;
                } else
                {
                    stringbutton("Preferences", 52, 446, 3, false);
                    if(ctheme.isShowing())
                        ctheme.hide();
                    if(fontsel.isShowing())
                        fontsel.hide();
                    if(cntprf != 0)
                        cntprf = 0;
                    if(cntchk == 0)
                    {
                        npolys = 0;
                        int l = 0;
                        boolean flag2 = false;
                        do
                        {
                            if(l == -1 || mouses == 1)
                                break;
                            if(!flag2)
                                l = editor.getText().indexOf("<p>", l);
                            else
                                l = editor.getText().indexOf("</p>", l);
                            if(l != -1)
                            {
                                if(!flag2)
                                {
                                    flag2 = true;
                                } else
                                {
                                    flag2 = false;
                                    npolys++;
                                }
                                l += 3;
                            }
                        } while(true);
                        if(mouses == 1)
                            npolys = 0;
                        cntchk = 30;
                    } else
                    {
                        cntchk--;
                    }
                    if(npolys > 210)
                        rd.setColor(new Color(255, 0, 0));
                    if(npolys != 0)
                        rd.drawString((new StringBuilder()).append("Number of Polygons :  ").append(npolys).append(" / 210").toString(), 200, 446);
                }
                if(!changed && !editor.getText().equals(lastedo))
                    changed = true;
                stringbutton("  Save  ", 490, 455, 0, changed);
                stringbutton("  Save & Preview  >  ", 600, 455, 0, changed);
                mirror = false;
                polynum = -1;
                cntpls = 0;
                String s = "";
                try
                {
                    s = editor.getSelectedText();
                }
                catch(Exception exception) { }
                if(!s.equals(""))
                {
                    int l1 = s.indexOf("<p>", 0);
                    do
                    {
                        if(l1 == -1 || l1 + 1 >= s.length())
                            break;
                        if(!mirror)
                        {
                            l1 = s.indexOf("</p>", l1 + 1);
                            if(l1 != -1)
                            {
                                mirror = true;
                                cntpls++;
                            }
                        }
                        if(mirror)
                        {
                            l1 = s.indexOf("<p>", l1 + 1);
                            if(l1 != -1)
                                mirror = false;
                        }
                    } while(true);
                }
                if(!mirror)
                {
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawRect(5, 474, 494, 70);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Text to find:", 18, 500);
                    movefield(srch, 91, 484, 129, 22);
                    if(!srch.isShowing())
                        srch.show();
                    boolean flag3 = false;
                    if(!srch.getText().equals(""))
                        flag3 = true;
                    stringbutton(" Find ", 117, 526, 2, flag3);
                    rd.drawString("Replace with:", 255, 500);
                    movefield(rplc, 338, 484, 129, 22);
                    if(!rplc.isShowing())
                        rplc.show();
                    flag3 = false;
                    if(!srch.getText().equals("") && !rplc.getText().equals(""))
                        flag3 = true;
                    stringbutton(" Replace ", 376, 526, 2, flag3);
                } else
                {
                    if(srch.isShowing())
                        srch.hide();
                    if(rplc.isShowing())
                        rplc.hide();
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawRect(5, 474, 450, 70);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Mirror [Selected] polygon(s) along:", 18, 490);
                    stringbutton(" Mirro Along X Axis ", 90, 525, 2, true);
                    stringbutton(" Mirro Along Y Axis ", 230, 525, 2, false);
                    stringbutton(" Mirro Along Z Axis ", 370, 525, 2, false);
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawRect(465, 474, 230, 70);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Show [Selected] polygon(s):", 478, 490);
                    stringbutton(" Show in 3D  > ", 580, 523, 0, true);
                }
                if(npolys > 210 && !tomany)
                {
                    repaint();
                    JOptionPane.showMessageDialog(null, "Maximum number of polygons (pieces) allowed has been exceeded!\nThe maximum allowed is 210 polygons, please decrease.\n", "Car Maker", 1);
                    tomany = true;
                }
            }
            if(tab == 2)
            {
                if(tabed != tab)
                {
                    setupo();
                    dtabed = -1;
                }
                m.d(rd);
                o.d(rd);
                if(dtab == 2)
                {
                    if(compsel > 0 && compsel <= 16)
                    {
                        compo[compsel - 1].x = o.x;
                        compo[compsel - 1].y = o.y;
                        compo[compsel - 1].z = o.z;
                        compo[compsel - 1].xz = o.xz;
                        compo[compsel - 1].xy = o.xy;
                        compo[compsel - 1].zy = o.zy;
                        rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                        compo[compsel - 1].d(rd);
                        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    }
                    if(xm > 420 && xm < 690 && ym > 425 && ym < 540)
                    {
                        int ai[] = {
                            50 + adna[0], -50 - adna[1], 0, 0, 0, 0
                        };
                        int ai1[] = {
                            0, 0, 50 + adna[2], -50 - adna[3], 0, 0
                        };
                        int ai4[] = {
                            0, 0, 0, 0, 50 + adna[4], -50 - adna[5]
                        };
                        for(int k2 = 0; k2 < 6; k2++)
                        {
                            ai[k2] += o.x - m.x;
                            ai1[k2] += o.y - m.y;
                            ai4[k2] += o.z - m.z;
                        }

                        rot(ai, ai1, o.x - m.x, o.y - m.y, o.xy, 6);
                        rot(ai1, ai4, o.y - m.y, o.z - m.z, o.zy, 6);
                        rot(ai, ai4, o.x - m.x, o.z - m.z, o.xz, 6);
                        rot(ai, ai4, m.cx, m.cz, m.xz, 6);
                        rot(ai1, ai4, m.cy, m.cz, m.zy, 6);
                        int ai7[] = new int[6];
                        int ai8[] = new int[6];
                        for(int k11 = 0; k11 < 6; k11++)
                        {
                            ai7[k11] = xs(ai[k11], ai4[k11]);
                            ai8[k11] = ys(ai1[k11], ai4[k11]);
                        }

                        rd.setColor(new Color(0, 150, 0));
                        rd.drawString("X+", ai7[0] - 7, ai8[0] + 4);
                        rd.drawString("-X", ai7[1] - 5, ai8[1] + 4);
                        rd.drawLine(ai7[0], ai8[0], ai7[1], ai8[1]);
                        rd.setColor(new Color(150, 0, 0));
                        rd.drawString("Y+", ai7[2] - 7, ai8[2] + 4);
                        rd.drawString("-Y", ai7[3] - 5, ai8[3] + 4);
                        rd.drawLine(ai7[2], ai8[2], ai7[3], ai8[3]);
                        rd.setColor(new Color(0, 0, 150));
                        rd.drawString("Z+", ai7[4] - 7, ai8[4] + 4);
                        rd.drawString("-Z", ai7[5] - 5, ai8[5] + 4);
                        rd.drawLine(ai7[4], ai8[4], ai7[5], ai8[5]);
                        for(int l11 = 0; l11 < 6; l11++)
                        {
                            if((float)Math.abs(ai8[l11] - 207) * 1.91F > (float)Math.abs(ai7[l11] - 350))
                            {
                                if(Math.abs(Math.abs(ai8[l11] - 207) - 170) > 10)
                                    if(Math.abs(ai8[l11] - 207) < 170)
                                        adna[l11] += 10;
                                    else
                                        adna[l11] -= 10;
                            } else
                            if(Math.abs(Math.abs(ai7[l11] - 350) - 338) > 10)
                                if(Math.abs(ai7[l11] - 350) < 338)
                                    adna[l11] += 10;
                                else
                                    adna[l11] -= 10;
                            if(adna[l11] > 276)
                                adna[l11] = 276;
                            if(adna[l11] < 0)
                                adna[l11] = 0;
                        }

                    }
                }
                rd.setColor(new Color(205, 200, 200));
                rd.fillRect(0, 390, 700, 20);
                rd.setColor(new Color(225, 225, 225));
                rd.fillRect(0, 410, 700, 140);
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                String as1[] = {
                    "3D Controls", "Color Edit", "Scale & Align", "Wheels", "Stats & Class", "Physics", "Test Drive"
                };
                int ai2[] = {
                    0, 0, 100, 90
                };
                int ai5[] = {
                    390, 410, 410, 390
                };
                for(int l2 = 0; l2 < 7; l2++)
                {
                    rd.setColor(new Color(170, 170, 170));
                    if(xm > ai2[0] && xm < ai2[3] && ym > 390 && ym < 410)
                        rd.setColor(new Color(190, 190, 190));
                    if(dtab == l2)
                        rd.setColor(new Color(225, 225, 225));
                    rd.fillPolygon(ai2, ai5, 4);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString(as1[l2], (l2 * 100 + 47) - ftm.stringWidth(as1[l2]) / 2, 404);
                    if(xm > ai2[0] && xm < ai2[3] && ym > 390 && ym < 410 && mouses == -1)
                        dtab = l2;
                    for(int j7 = 0; j7 < 4; j7++)
                        ai2[j7] += 100;

                }

                if(dtabed != dtab)
                {
                    if(dtabed != -1)
                    {
                        if(!editor.getText().equals(lastedo))
                            editor.setText(lastedo);
                        setupo();
                    }
                    setCursor(new Cursor(0));
                    hidefields();
                    requestFocus();
                }
                rd.setColor(new Color(0, 0, 0));
                if(dtab == 0)
                {
                    rd.drawString("Rotate Car around its X & Z Axis using:  [ Keyboard Arrows ] ", 20, 440);
                    rd.drawString("Rotate Car fully around the Y Axis using:    [ < ]  &  [ > ]    or    [ A ]  &  [ D ]    or    [ 4 ]  &  [ 6 ]    Keys", 20, 465);
                    rd.drawString("Move Car Up and Down using:    [ - ]  &  [ + ]    Keys", 20, 490);
                    rd.drawString("Move Car Forwards and Backwards using:    [ W ]  &  [ S ]    or    [ 8 ]  &  [ 2 ]    or    [ Enter ]  &  [ Backspace ]    Keys", 20, 515);
                }
                if(dtab == 1)
                    if(o.colok != 2)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("[  First & Second Color not defined yet  ]", 350 - ftm.stringWidth("[  First & Second Color not defined yet  ]") / 2, 450);
                        stringbutton(" Define 1st and 2nd Color ", 350, 490, 0, true);
                    } else
                    {
                        if(dtabed != dtab)
                        {
                            fcol = (new StringBuilder()).append("(").append(o.fcol[0]).append(",").append(o.fcol[1]).append(",").append(o.fcol[2]).append(")").toString();
                            srch.setText(fcol);
                            ofcol = fcol;
                            Color.RGBtoHSB(o.fcol[0], o.fcol[1], o.fcol[2], fhsb);
                            float f = fhsb[1];
                            fhsb[1] = fhsb[2];
                            fhsb[2] = f;
                            scol = (new StringBuilder()).append("(").append(o.scol[0]).append(",").append(o.scol[1]).append(",").append(o.scol[2]).append(")").toString();
                            rplc.setText(scol);
                            oscol = scol;
                            Color.RGBtoHSB(o.scol[0], o.scol[1], o.scol[2], shsb);
                            f = shsb[1];
                            shsb[1] = shsb[2];
                            shsb[2] = f;
                            bfo = 51;
                            mouseon = -1;
                        }
                        if(mouses != 1)
                            mouseon = -1;
                        rd.setColor(new Color(170, 170, 170));
                        rd.drawRect(20, 425, 320, 110);
                        rd.setColor(new Color(225, 225, 225));
                        rd.fillRect(141, 419, 77, 9);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("First Color", 151, 428);
                        rd.drawString("Hue:", 75, 450);
                        rd.drawString("Brightness:", 35, 470);
                        rd.drawString("Saturation:", 38, 490);
                        rd.drawString("RGB Value:", 38, 520);
                        movefield(srch, 106, 504, 129, 22);
                        if(srch.hasFocus())
                            focuson = false;
                        if(!srch.isShowing())
                            srch.show();
                        for(int i3 = 0; i3 < 200; i3++)
                        {
                            rd.setColor(Color.getHSBColor((float)((double)(float)i3 * 0.0050000000000000001D), 1.0F, 1.0F));
                            rd.drawLine(110 + i3, 442, 110 + i3, 449);
                        }

                        for(int j3 = 0; j3 < 200; j3++)
                        {
                            rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.2F + (float)((double)(float)j3 * 0.0040000000000000001D)));
                            rd.drawLine(110 + j3, 462, 110 + j3, 469);
                        }

                        for(int k3 = 0; k3 < 200; k3++)
                        {
                            rd.setColor(Color.getHSBColor(fhsb[0], (float)((double)(float)k3 * 0.0050000000000000001D), fhsb[1]));
                            rd.drawLine(110 + k3, 482, 110 + k3, 489);
                        }

                        for(int l3 = 0; l3 < 3; l3++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            float f1 = fhsb[l3] * 200F;
                            if(l3 == 1)
                                f1 = (fhsb[l3] - 0.2F) * 250F;
                            rd.drawLine((int)(110F + f1), 442 + l3 * 20, (int)(110F + f1), 449 + l3 * 20);
                            rd.drawLine((int)(111F + f1), 442 + l3 * 20, (int)(111F + f1), 449 + l3 * 20);
                            rd.fillRect((int)(109F + f1), 450 + l3 * 20, 4, 2);
                            rd.drawLine((int)(108F + f1), 452 + l3 * 20, (int)(113F + f1), 452 + l3 * 20);
                            if(xm > 107 && xm < 313 && ym > 439 + l3 * 20 && ym < 452 + l3 * 20 && mouses == 1 && mouseon == -1)
                                mouseon = l3;
                            if(mouseon != l3)
                                continue;
                            if(l3 == 1)
                            {
                                fhsb[l3] = 0.2F + (float)(xm - 110) / 250F;
                                if((double)fhsb[l3] < 0.20000000000000001D)
                                    fhsb[l3] = 0.2F;
                            } else
                            {
                                fhsb[l3] = (float)(xm - 110) / 200F;
                            }
                            if(fhsb[l3] > 1.0F)
                                fhsb[l3] = 1.0F;
                            if(fhsb[l3] < 0.0F)
                                fhsb[l3] = 0.0F;
                        }

                        stringbutton(" Save ", 300, 520, 0, !fcol.equals(ofcol));
                        rd.setColor(new Color(170, 170, 170));
                        rd.drawRect(360, 425, 320, 110);
                        rd.setColor(new Color(225, 225, 225));
                        rd.fillRect(472, 419, 95, 9);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Second Color", 482, 428);
                        rd.drawString("Hue:", 415, 450);
                        rd.drawString("Brightness:", 375, 470);
                        rd.drawString("Saturation:", 378, 490);
                        rd.drawString("RGB Value:", 378, 520);
                        movefield(rplc, 446, 504, 129, 22);
                        if(rplc.hasFocus())
                            focuson = false;
                        if(!rplc.isShowing())
                            rplc.show();
                        for(int i4 = 0; i4 < 200; i4++)
                        {
                            rd.setColor(Color.getHSBColor((float)((double)(float)i4 * 0.0050000000000000001D), 1.0F, 1.0F));
                            rd.drawLine(450 + i4, 442, 450 + i4, 449);
                        }

                        for(int j4 = 0; j4 < 200; j4++)
                        {
                            rd.setColor(Color.getHSBColor(0.0F, 0.0F, 0.2F + (float)((double)(float)j4 * 0.0040000000000000001D)));
                            rd.drawLine(450 + j4, 462, 450 + j4, 469);
                        }

                        for(int k4 = 0; k4 < 200; k4++)
                        {
                            rd.setColor(Color.getHSBColor(shsb[0], (float)((double)(float)k4 * 0.0050000000000000001D), shsb[2]));
                            rd.drawLine(450 + k4, 482, 450 + k4, 489);
                        }

                        for(int l4 = 0; l4 < 3; l4++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            float f2 = shsb[l4] * 200F;
                            if(l4 == 1)
                                f2 = (shsb[l4] - 0.2F) * 250F;
                            rd.drawLine((int)(450F + f2), 442 + l4 * 20, (int)(450F + f2), 449 + l4 * 20);
                            rd.drawLine((int)(451F + f2), 442 + l4 * 20, (int)(451F + f2), 449 + l4 * 20);
                            rd.fillRect((int)(449F + f2), 450 + l4 * 20, 4, 2);
                            rd.drawLine((int)(448F + f2), 452 + l4 * 20, (int)(453F + f2), 452 + l4 * 20);
                            if(xm > 447 && xm < 653 && ym > 439 + l4 * 20 && ym < 452 + l4 * 20 && mouses == 1 && mouseon == -1)
                                mouseon = l4 + 3;
                            if(mouseon != l4 + 3)
                                continue;
                            if(l4 == 1)
                            {
                                shsb[l4] = 0.2F + (float)(xm - 450) / 250F;
                                if((double)shsb[l4] < 0.20000000000000001D)
                                    shsb[l4] = 0.2F;
                            } else
                            {
                                shsb[l4] = (float)(xm - 450) / 200F;
                            }
                            if(shsb[l4] > 1.0F)
                                shsb[l4] = 1.0F;
                            if(shsb[l4] < 0.0F)
                                shsb[l4] = 0.0F;
                        }

                        stringbutton(" Save ", 640, 520, 0, !scol.equals(oscol));
                        if((double)fhsb[1] < 0.20000000000000001D)
                            fhsb[1] = 0.2F;
                        if((double)shsb[1] < 0.20000000000000001D)
                            shsb[1] = 0.2F;
                        for(int i5 = 0; i5 < o.npl; i5++)
                        {
                            if(o.p[i5].colnum == 1)
                            {
                                o.p[i5].hsb[0] = fhsb[0];
                                o.p[i5].hsb[1] = fhsb[2];
                                o.p[i5].hsb[2] = fhsb[1];
                            }
                            if(o.p[i5].colnum == 2)
                            {
                                o.p[i5].hsb[0] = shsb[0];
                                o.p[i5].hsb[1] = shsb[2];
                                o.p[i5].hsb[2] = shsb[1];
                            }
                        }

                        String s9 = (new StringBuilder()).append("(").append(Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getRed()).append(",").append(Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getGreen()).append(",").append(Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getBlue()).append(")").toString();
                        if(!fcol.equals(s9))
                        {
                            fcol = s9;
                            srch.setText(fcol);
                        }
                        s9 = (new StringBuilder()).append("(").append(Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getRed()).append(",").append(Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getGreen()).append(",").append(Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getBlue()).append(")").toString();
                        if(!scol.equals(s9))
                        {
                            scol = s9;
                            rplc.setText(scol);
                        }
                        if(srch.getText().equals(fcol) && rplc.getText().equals(scol))
                        {
                            if(bfo < 50)
                                bfo++;
                            else
                            if(bfo == 50)
                            {
                                requestFocus();
                                bfo = 51;
                            }
                        } else
                        {
                            bfo = 0;
                            if(!srch.getText().equals(fcol))
                            {
                                fcol = srch.getText();
                                int ai9[] = new int[3];
                                boolean flag8 = true;
                                try
                                {
                                    int l16 = fcol.indexOf(",", 0);
                                    int j18 = fcol.indexOf(",", l16 + 1);
                                    ai9[0] = Integer.valueOf(fcol.substring(1, l16)).intValue();
                                    if(ai9[0] < 0)
                                        ai9[0] = 0;
                                    if(ai9[0] > 255)
                                        ai9[0] = 255;
                                    ai9[1] = Integer.valueOf(fcol.substring(l16 + 1, j18)).intValue();
                                    if(ai9[1] < 0)
                                        ai9[1] = 0;
                                    if(ai9[1] > 255)
                                        ai9[1] = 255;
                                    ai9[2] = Integer.valueOf(fcol.substring(j18 + 1, fcol.length() - 1)).intValue();
                                    if(ai9[2] < 0)
                                        ai9[2] = 0;
                                    if(ai9[2] > 255)
                                        ai9[2] = 255;
                                }
                                catch(Exception exception8)
                                {
                                    flag8 = false;
                                }
                                if(flag8)
                                {
                                    Color.RGBtoHSB(ai9[0], ai9[1], ai9[2], fhsb);
                                    float f3 = fhsb[1];
                                    fhsb[1] = fhsb[2];
                                    fhsb[2] = f3;
                                }
                            }
                            if(!rplc.getText().equals(scol))
                            {
                                scol = rplc.getText();
                                int ai10[] = new int[3];
                                boolean flag9 = true;
                                try
                                {
                                    int i17 = scol.indexOf(",", 0);
                                    int k18 = scol.indexOf(",", i17 + 1);
                                    ai10[0] = Integer.valueOf(scol.substring(1, i17)).intValue();
                                    if(ai10[0] < 0)
                                        ai10[0] = 0;
                                    if(ai10[0] > 255)
                                        ai10[0] = 255;
                                    ai10[1] = Integer.valueOf(scol.substring(i17 + 1, k18)).intValue();
                                    if(ai10[1] < 0)
                                        ai10[1] = 0;
                                    if(ai10[1] > 255)
                                        ai10[1] = 255;
                                    ai10[2] = Integer.valueOf(scol.substring(k18 + 1, scol.length() - 1)).intValue();
                                    if(ai10[2] < 0)
                                        ai10[2] = 0;
                                    if(ai10[2] > 255)
                                        ai10[2] = 255;
                                }
                                catch(Exception exception9)
                                {
                                    flag9 = false;
                                }
                                if(flag9)
                                {
                                    Color.RGBtoHSB(ai10[0], ai10[1], ai10[2], shsb);
                                    float f4 = shsb[1];
                                    shsb[1] = shsb[2];
                                    shsb[2] = f4;
                                }
                            }
                        }
                    }
                if(dtab == 2)
                {
                    if(dtabed != dtab)
                    {
                        lastedo = editor.getText();
                        scale[0] = 100;
                        int j5 = editor.getText().indexOf("\nScaleX(", 0);
                        if(j5 != -1)
                        {
                            j5++;
                            try
                            {
                                scale[0] = Integer.valueOf(editor.getText().substring(j5 + 7, editor.getText().indexOf(")", j5))).intValue();
                            }
                            catch(Exception exception4)
                            {
                                scale[0] = 100;
                            }
                        }
                        oscale[0] = scale[0];
                        scale[1] = 100;
                        j5 = editor.getText().indexOf("\nScaleY(", 0);
                        if(j5 != -1)
                        {
                            j5++;
                            try
                            {
                                scale[1] = Integer.valueOf(editor.getText().substring(j5 + 7, editor.getText().indexOf(")", j5))).intValue();
                            }
                            catch(Exception exception5)
                            {
                                scale[1] = 100;
                            }
                        }
                        oscale[1] = scale[1];
                        scale[2] = 100;
                        j5 = editor.getText().indexOf("\nScaleZ(", 0);
                        if(j5 != -1)
                        {
                            j5++;
                            try
                            {
                                scale[2] = Integer.valueOf(editor.getText().substring(j5 + 7, editor.getText().indexOf(")", j5))).intValue();
                            }
                            catch(Exception exception6)
                            {
                                scale[2] = 100;
                            }
                        }
                        oscale[2] = scale[2];
                        bfo = 0;
                        compsel = 0;
                        compcar.select(compsel);
                        changed2 = false;
                    }
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawRect(9, 425, 270, 115);
                    rd.setColor(new Color(225, 225, 225));
                    rd.fillRect(119, 419, 51, 9);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Scale", 129, 428);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Scale X", 25, 450);
                    stringbutton(" - ", 92, 450, 4, false);
                    rd.drawString((new StringBuilder()).append("").append((float)scale[0] / 100F).append("").toString(), 126 - ftm.stringWidth((new StringBuilder()).append("").append((float)scale[0] / 100F).append("").toString()) / 2, 450);
                    stringbutton(" + ", 160, 450, 4, false);
                    rd.drawString("Scale Y", 25, 474);
                    stringbutton(" - ", 92, 474, 4, false);
                    rd.drawString((new StringBuilder()).append("").append((float)scale[1] / 100F).append("").toString(), 126 - ftm.stringWidth((new StringBuilder()).append("").append((float)scale[1] / 100F).append("").toString()) / 2, 474);
                    stringbutton(" + ", 160, 474, 4, false);
                    rd.drawString("Scale Z", 25, 498);
                    stringbutton(" - ", 92, 498, 4, false);
                    rd.drawString((new StringBuilder()).append("").append((float)scale[2] / 100F).append("").toString(), 126 - ftm.stringWidth((new StringBuilder()).append("").append((float)scale[2] / 100F).append("").toString()) / 2, 498);
                    stringbutton(" + ", 160, 498, 4, false);
                    rd.drawString("Scale ALL", 25, 527);
                    stringbutton(" - ", 106, 527, 2, true);
                    stringbutton(" + ", 146, 527, 2, true);
                    stringbutton("   Save   ", 230, 454, 0, oscale[0] != scale[0] || oscale[1] != scale[1] || oscale[2] != scale[2]);
                    stringbutton(" Reset ", 230, 493, 0, false);
                    rd.drawString("Compare scale and", 296, 440);
                    rd.drawString("alignment with:", 308, 455);
                    compcar.move(288, 462);
                    if(compcar.hasFocus())
                    {
                        focuson = false;
                        bfo++;
                        if(bfo == 100)
                            requestFocus();
                    } else
                    {
                        bfo = 0;
                    }
                    if(!compcar.isShowing())
                        compcar.show();
                    if(compsel != compcar.getSelectedIndex())
                    {
                        compsel = compcar.getSelectedIndex();
                        requestFocus();
                    }
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawRect(420, 425, 270, 115);
                    rd.setColor(new Color(225, 225, 225));
                    rd.fillRect(531, 419, 47, 9);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Align", 541, 428);
                    rd.drawString("Align in X", 433, 450);
                    stringbutton(" Rotate 90\260 ", 535, 450, 4, false);
                    stringbutton("+10", 607, 450, 4, false);
                    stringbutton("-10", 656, 450, 4, false);
                    rd.drawString("Align in Y", 433, 474);
                    stringbutton(" Rotate 90\260 ", 535, 474, 4, false);
                    stringbutton("+10", 607, 474, 4, false);
                    stringbutton("-10", 656, 474, 4, false);
                    rd.drawString("Align in Z", 433, 498);
                    stringbutton(" Rotate 90\260 ", 535, 498, 4, false);
                    stringbutton("+10", 607, 498, 4, false);
                    stringbutton("-10", 656, 498, 4, false);
                    stringbutton(" Reset ", 490, 527, 0, false);
                    stringbutton("      Save      ", 607, 527, 0, changed2);
                }
                if(dtab == 3)
                {
                    if(dtabed != dtab)
                    {
                        int k5 = 45;
                        int k7 = 45;
                        int i12 = 15;
                        int j17 = 15;
                        int l18 = 76;
                        int k21 = -76;
                        int i24 = 26;
                        int l25 = 26;
                        int k26 = 20;
                        int l27 = 20;
                        int j28 = 18;
                        int l28 = 18;
                        int j29 = 10;
                        int k29 = 10;
                        int l29 = 0;
                        int j30 = 0;
                        String s26 = "(140,140,140)";
                        String s28 = "(140,140,140)";
                        int l30 = 0;
                        String s29 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        int i31 = 0;
                        int j31 = s29.indexOf("\n", 0);
                        int k31 = 0;
                        int l31 = 15;
                        int i32 = 20;
                        String s30 = "(140,140,140)";
                        do
                        {
                            if(j31 == -1 || i31 >= s29.length())
                                break;
                            String s31 = s29.substring(i31, j31);
                            s31 = s31.trim();
                            i31 = j31 + 1;
                            j31 = s29.indexOf("\n", i31);
                            try
                            {
                                if(s31.startsWith("rims("))
                                {
                                    s30 = (new StringBuilder()).append("(").append(getvalue("rims", s31, 0)).append(",").append(getvalue("rims", s31, 1)).append(",").append(getvalue("rims", s31, 2)).append(")").toString();
                                    l31 = getvalue("rims", s31, 3);
                                    i32 = getvalue("rims", s31, 4);
                                }
                                if(s31.startsWith("gwgr("))
                                    k31 = getvalue("gwgr", s31, 0);
                                if(s31.startsWith("w("))
                                {
                                    int j32 = getvalue("w", s31, 2);
                                    if(j32 > 0)
                                    {
                                        k5 = Math.abs(getvalue("w", s31, 0));
                                        i12 = getvalue("w", s31, 1);
                                        l18 = j32;
                                        i24 = Math.abs(getvalue("w", s31, 4));
                                        k26 = Math.abs(getvalue("w", s31, 5));
                                        s26 = s30;
                                        j28 = l31;
                                        j29 = i32;
                                        l29 = k31;
                                    } else
                                    {
                                        k7 = Math.abs(getvalue("w", s31, 0));
                                        j17 = getvalue("w", s31, 1);
                                        k21 = j32;
                                        l25 = Math.abs(getvalue("w", s31, 4));
                                        l27 = Math.abs(getvalue("w", s31, 5));
                                        s28 = s30;
                                        l28 = l31;
                                        k29 = i32;
                                        j30 = k31;
                                    }
                                    l30++;
                                }
                            }
                            catch(Exception exception13) { }
                        } while(true);
                        if(l30 != 4)
                            defnow = true;
                        else
                            defnow = false;
                        wv[0].setText((new StringBuilder()).append("").append(k7).append("").toString());
                        wv[1].setText((new StringBuilder()).append("").append(j17).append("").toString());
                        wv[2].setText((new StringBuilder()).append("").append(k21).append("").toString());
                        wv[3].setText((new StringBuilder()).append("").append(l27).append("").toString());
                        wv[4].setText((new StringBuilder()).append("").append(l25).append("").toString());
                        srch.setText(s28);
                        wv[5].setText((new StringBuilder()).append("").append(l28).append("").toString());
                        wv[6].setText((new StringBuilder()).append("").append(k29).append("").toString());
                        wv[7].setText((new StringBuilder()).append("").append(j30).append("").toString());
                        wv[8].setText((new StringBuilder()).append("").append(k5).append("").toString());
                        wv[9].setText((new StringBuilder()).append("").append(i12).append("").toString());
                        wv[10].setText((new StringBuilder()).append("").append(l18).append("").toString());
                        wv[11].setText((new StringBuilder()).append("").append(k26).append("").toString());
                        wv[12].setText((new StringBuilder()).append("").append(i24).append("").toString());
                        rplc.setText(s26);
                        wv[13].setText((new StringBuilder()).append("").append(j28).append("").toString());
                        wv[14].setText((new StringBuilder()).append("").append(j29).append("").toString());
                        wv[15].setText((new StringBuilder()).append("").append(l29).append("").toString());
                        aply1 = (new StringBuilder()).append("").append(wv[0].getText()).append("").append(wv[1].getText()).append("").append(wv[2].getText()).append("").append(wv[3].getText()).append("").append(wv[4].getText()).append("").append(srch.getText()).append("").append(wv[5].getText()).append("").append(wv[6].getText()).append("").append(wv[7].getText()).append("").toString();
                        aply2 = (new StringBuilder()).append("").append(wv[8].getText()).append("").append(wv[9].getText()).append("").append(wv[10].getText()).append("").append(wv[11].getText()).append("").append(wv[12].getText()).append("").append(rplc.getText()).append("").append(wv[13].getText()).append("").append(wv[14].getText()).append("").append(wv[15].getText()).append("").toString();
                        aplyd1 = false;
                        aplyd2 = false;
                        changed2 = false;
                        mouseon = -1;
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("BACK Wheels :", 12, 424);
                    rd.drawString("\261X :", 12, 449);
                    movefield(wv[0], 35, 433, 40, 22);
                    rd.drawString("Y :", 86, 449);
                    movefield(wv[1], 101, 433, 40, 22);
                    rd.drawString("Z :", 151, 449);
                    movefield(wv[2], 166, 433, 40, 22);
                    rd.drawString("Height :", 12, 479);
                    movefield(wv[3], 56, 463, 40, 22);
                    rd.drawString("Width :", 107, 479);
                    movefield(wv[4], 148, 463, 40, 22);
                    rd.drawString("Rims RGB Color :", 12, 509);
                    movefield(srch, 109, 493, 129, 22);
                    rd.drawString("Rims Size :", 12, 539);
                    movefield(wv[5], 76, 523, 40, 22);
                    rd.drawString("Rims Depth :", 126, 539);
                    movefield(wv[6], 199, 523, 40, 22);
                    if(xm > 245 && xm < 336 && ym > 524 && ym < 541)
                    {
                        rd.setColor(new Color(255, 0, 0));
                        rd.drawLine(248, 540, 279, 540);
                        rd.drawLine(327, 540, 334, 540);
                        if(mouseon == -1)
                        {
                            mouseon = 1;
                            setCursor(new Cursor(12));
                        }
                    } else
                    if(mouseon == 1)
                    {
                        mouseon = -1;
                        setCursor(new Cursor(0));
                    }
                    rd.drawString("Hide :                ?", 249, 539);
                    movefield(wv[7], 282, 523, 40, 22);
                    stringbutton("   Apply   ", 300, 440, 0, aplyd1);
                    stringbutton("   Save   ", 300, 477, 0, changed2);
                    rd.drawString("FRONT Wheels :", 362, 424);
                    rd.drawString("\261X :", 362, 449);
                    movefield(wv[8], 385, 433, 40, 22);
                    rd.drawString("Y :", 436, 449);
                    movefield(wv[9], 451, 433, 40, 22);
                    rd.drawString("Z :", 501, 449);
                    movefield(wv[10], 516, 433, 40, 22);
                    rd.drawString("Height :", 362, 479);
                    movefield(wv[11], 406, 463, 40, 22);
                    rd.drawString("Width :", 457, 479);
                    movefield(wv[12], 498, 463, 40, 22);
                    rd.drawString("Rims RGB Color :", 362, 509);
                    movefield(rplc, 459, 493, 129, 22);
                    rd.drawString("Rims Size :", 362, 539);
                    movefield(wv[13], 426, 523, 40, 22);
                    rd.drawString("Rims Depth :", 476, 539);
                    movefield(wv[14], 549, 523, 40, 22);
                    if(xm > 595 && xm < 686 && ym > 524 && ym < 541)
                    {
                        rd.setColor(new Color(255, 0, 0));
                        rd.drawLine(598, 540, 629, 540);
                        rd.drawLine(677, 540, 684, 540);
                        if(mouseon == -1)
                        {
                            mouseon = 2;
                            setCursor(new Cursor(12));
                        }
                    } else
                    if(mouseon == 2)
                    {
                        mouseon = -1;
                        setCursor(new Cursor(0));
                    }
                    rd.drawString("Hide :                ?", 599, 539);
                    movefield(wv[15], 632, 523, 40, 22);
                    stringbutton("   Apply   ", 650, 440, 0, aplyd2);
                    stringbutton("   Save   ", 650, 477, 0, changed2);
                    if(mouses == -1 && (mouseon == 1 || mouseon == 2))
                        JOptionPane.showMessageDialog(null, "Use this variable to hide the car wheels inside the car if you need to (if they are getting drawn over the car when they\nshould be drawn behind it).\n\nIf you have created a car model with specific places for the wheels go inside them (inside the car), if when you place the\nwheels there they don\u2019t get drawn inside the car (they get drawn over it instead), use this variable to adjust that.\n\nYou can also use this variable to do the opposite, to make the wheels get drawn over the car if they are getting drawn\nbehind it when they shouldn\u2019t.\n\nThe Hide variable takes values from -40 to 40:\nA +ve value from 1 to 40 makes the wheels more hidden, where 40 is the maximum the car wheel can be hidden.\nA -ve value from -1 to -40 does exactly the opposite and makes the wheels more apparent (this if the car wheels appear\ninside the car when they should be outside).\nA 0 value means do nothing.\nMost of the time you will need to use this variable, it will be to enter +ve values from 1-40 for hiding the car wheels.\n\n", "Car Maker", 1);
                    for(int l5 = 0; l5 < 16; l5++)
                    {
                        if(wv[l5].hasFocus())
                            focuson = false;
                        if(!wv[l5].isShowing())
                            wv[l5].show();
                    }

                    if(srch.hasFocus())
                        focuson = false;
                    if(!srch.isShowing())
                        srch.show();
                    if(rplc.hasFocus())
                        focuson = false;
                    if(!rplc.isShowing())
                        rplc.show();
                    if(!focuson)
                    {
                        if(!aplyd1 && !aply1.equals((new StringBuilder()).append("").append(wv[0].getText()).append("").append(wv[1].getText()).append("").append(wv[2].getText()).append("").append(wv[3].getText()).append("").append(wv[4].getText()).append("").append(srch.getText()).append("").append(wv[5].getText()).append("").append(wv[6].getText()).append("").append(wv[7].getText()).append("").toString()))
                            aplyd1 = true;
                        if(!aplyd2 && !aply2.equals((new StringBuilder()).append("").append(wv[8].getText()).append("").append(wv[9].getText()).append("").append(wv[10].getText()).append("").append(wv[11].getText()).append("").append(wv[12].getText()).append("").append(rplc.getText()).append("").append(wv[13].getText()).append("").append(wv[14].getText()).append("").append(wv[15].getText()).append("").toString()))
                            aplyd2 = true;
                    }
                    rd.setColor(new Color(170, 170, 170));
                    rd.drawLine(350, 410, 350, 550);
                    rd.drawLine(300, 409, 400, 409);
                }
                if(dtab == 4)
                {
                    if(dtabed != dtab)
                    {
                        changed2 = false;
                        statdef = false;
                        String s10 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        int l7 = 0;
                        int j12 = s10.indexOf("\n", 0);
                        do
                        {
                            if(j12 == -1 || l7 >= s10.length())
                                break;
                            String s20 = s10.substring(l7, j12);
                            s20 = s20.trim();
                            l7 = j12 + 1;
                            j12 = s10.indexOf("\n", l7);
                            try
                            {
                                if(s20.startsWith("stat("))
                                {
                                    int i19 = 0;
                                    for(int l21 = 0; l21 < 5; l21++)
                                    {
                                        stat[l21] = getvalue("stat", s20, l21);
                                        if(stat[l21] > 200)
                                            stat[l21] = 200;
                                        if(stat[l21] < 16)
                                            stat[l21] = 16;
                                        i19 += stat[l21];
                                    }

                                    int i22 = 0;
                                    if(i19 > 680)
                                    {
                                        i22 = 680 - i19;
                                        changed2 = true;
                                    }
                                    if(i19 > 640 && i19 < 680)
                                    {
                                        i22 = 640 - i19;
                                        changed2 = true;
                                    }
                                    if(i19 > 600 && i19 < 640)
                                    {
                                        i22 = 600 - i19;
                                        changed2 = true;
                                    }
                                    if(i19 > 560 && i19 < 600)
                                    {
                                        i22 = 560 - i19;
                                        changed2 = true;
                                    }
                                    if(i19 > 520 && i19 < 560)
                                    {
                                        i22 = 520 - i19;
                                        changed2 = true;
                                    }
                                    if(i19 < 520)
                                    {
                                        i22 = 520 - i19;
                                        changed2 = true;
                                    }
                                    while(i22 != 0) 
                                    {
                                        int j24 = 0;
                                        while(j24 < 5) 
                                        {
                                            if(i22 > 0 && stat[j24] < 200)
                                            {
                                                stat[j24]++;
                                                i22--;
                                            }
                                            if(i22 < 0 && stat[j24] > 16)
                                            {
                                                stat[j24]--;
                                                i22++;
                                            }
                                            j24++;
                                        }
                                    }
                                    for(int k24 = 0; k24 < 5; k24++)
                                        rstat[k24] = stat[k24];

                                    statdef = true;
                                }
                            }
                            catch(Exception exception10)
                            {
                                statdef = false;
                            }
                        } while(true);
                        if(statdef)
                        {
                            if(simcar.getItemCount() == 16)
                                simcar.add(rd, "   ");
                        } else
                        if(simcar.getItemCount() == 17)
                            simcar.remove("   ");
                    }
                    rd.setColor(new Color(0, 0, 0));
                    if(!statdef)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("To start, please select the most similar NFM car to this car", 350 - ftm.stringWidth("To start, please select the most similar NFM car to this car") / 2, 450);
                        simcar.move(288, 460);
                        if(!simcar.isShowing())
                            simcar.show();
                        stringbutton("   OK   ", 350, 515, 0, true);
                    } else
                    {
                        rd.drawString("Car Class", 54, 435);
                        cls.move(34, 440);
                        if(!cls.isShowing())
                            cls.show();
                        boolean flag5 = false;
                        int i8 = 0;
                        for(int k12 = 0; k12 < 5; k12++)
                        {
                            i8 += stat[k12];
                            if(stat[k12] != rstat[k12])
                                flag5 = true;
                        }

                        if(clsel != cls.getSelectedIndex())
                        {
                            clsel = cls.getSelectedIndex();
                            for(int l12 = ((4 - clsel) * 40 + 520) - i8; l12 != 0;)
                            {
                                int k17 = 0;
                                while(k17 < 5) 
                                {
                                    if(l12 > 0 && stat[k17] < 200)
                                    {
                                        stat[k17]++;
                                        l12--;
                                    }
                                    if(l12 < 0 && stat[k17] > 16)
                                    {
                                        stat[k17]--;
                                        l12++;
                                    }
                                    k17++;
                                }
                            }

                        }
                        if(4 - (i8 - 520) / 40 != cls.getSelectedIndex())
                        {
                            clsel = 4 - (i8 - 520) / 40;
                            cls.select(clsel);
                        }
                        rd.drawString("Most Similar Car", 36, 490);
                        simcar.move(20, 495);
                        if(!simcar.isShowing())
                            simcar.show();
                        if(carsel != simcar.getSelectedIndex())
                        {
                            carsel = simcar.getSelectedIndex();
                            if(carsel != 16)
                            {
                                for(int i13 = 0; i13 < 5; i13++)
                                    stat[i13] = carstat[carsel][i13];

                            }
                            requestFocus();
                        }
                        int j13 = 60;
                        int l17 = 16;
                        for(int j19 = 0; j19 < 16; j19++)
                        {
                            int j22 = 0;
                            for(int l24 = 0; l24 < 5; l24++)
                                j22 += Math.abs(carstat[j19][l24] - stat[l24]);

                            if(j22 < j13)
                            {
                                l17 = j19;
                                j13 = j22;
                            }
                        }

                        if(l17 != carsel)
                        {
                            carsel = l17;
                            if(carsel < simcar.getItemCount())
                                simcar.select(carsel);
                        }
                        rd.drawString("Speed :", 196, 435);
                        rd.drawString("Acceleration :", 160, 459);
                        rd.drawString("Stunts :", 195, 483);
                        rd.drawString("Strength :", 183, 507);
                        rd.drawString("Endurance :", 171, 531);
                        for(int k19 = 0; k19 < 5; k19++)
                        {
                            for(int k22 = 0; k22 < stat[k19]; k22++)
                            {
                                rd.setColor(Color.getHSBColor((float)((double)(float)k22 * 0.00069999999999999999D), 1.0F, 1.0F));
                                rd.drawLine(250 + k22, 426 + k19 * 24, 250 + k22, 434 + k19 * 24);
                            }

                            rd.setColor(new Color(0, 0, 0));
                            rd.drawLine(249, 426 + k19 * 24, 249, 434 + k19 * 24);
                            rd.drawLine(450, 426 + k19 * 24, 450, 434 + k19 * 24);
                            rd.drawLine(249, 435 + k19 * 24, 450, 435 + k19 * 24);
                            for(int l22 = 0; l22 < 7; l22++)
                                rd.drawLine(275 + l22 * 25, 434 + k19 * 24, 275 + l22 * 25, 430 + k19 * 24);

                            stringbutton(" - ", 480, 435 + k19 * 24, 4, false);
                            stringbutton(" + ", 520, 435 + k19 * 24, 4, false);
                        }

                        if(carsel < 16 && j13 != 0)
                            stringbutton(" Reselect ", 80, 534, 4, true);
                        else
                            stringbutton(" Reselect ", 80, -1000, 4, true);
                        stringbutton("      Save      ", 620, 459, 0, flag5 || changed2);
                        stringbutton("   Reset   ", 620, 507, 0, false);
                    }
                }
                if(dtab == 5)
                {
                    if(dtabed != dtab)
                    {
                        mouseon = -1;
                        pfase = 0;
                        if(o.keyz[0] <= 0 || o.keyx[0] >= 0)
                            pfase = -1;
                        if(o.keyz[1] <= 0 || o.keyx[1] <= 0)
                            pfase = -1;
                        if(o.keyz[2] >= 0 || o.keyx[2] >= 0)
                            pfase = -1;
                        if(o.keyz[3] >= 0 || o.keyx[3] <= 0)
                            pfase = -1;
                        crashok = false;
                        if(Math.random() > Math.random())
                            crashleft = false;
                        else
                            crashleft = true;
                        engsel = 0;
                        if(pfase == 0)
                        {
                            String s11 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                            int j8 = 0;
                            int k13 = s11.indexOf("\n", 0);
                            do
                            {
                                if(k13 == -1 || j8 >= s11.length())
                                    break;
                                String s21 = s11.substring(j8, k13);
                                s21 = s21.trim();
                                j8 = k13 + 1;
                                k13 = s11.indexOf("\n", j8);
                                try
                                {
                                    if(s21.startsWith("physics("))
                                    {
                                        for(int l19 = 0; l19 < 11; l19++)
                                        {
                                            phys[l19] = getvalue("physics", s21, l19);
                                            if(phys[l19] > 100)
                                                phys[l19] = 100;
                                            if(phys[l19] < 0)
                                                phys[l19] = 0;
                                        }

                                        for(int i20 = 0; i20 < 11; i20++)
                                            rphys[i20] = phys[i20];

                                        for(int j20 = 0; j20 < 3; j20++)
                                        {
                                            crash[j20] = getvalue("physics", s21, j20 + 11);
                                            if(crash[j20] > 100)
                                                crash[j20] = 100;
                                            if(crash[j20] < 0)
                                                crash[j20] = 0;
                                        }

                                        for(int k20 = 0; k20 < 3; k20++)
                                            rcrash[k20] = crash[k20];

                                        engsel = getvalue("physics", s21, 14);
                                        if(engsel > 4)
                                            engsel = 0;
                                        if(engsel < 0)
                                            engsel = 0;
                                        crashok = true;
                                    }
                                }
                                catch(Exception exception11)
                                {
                                    crashok = false;
                                }
                            } while(true);
                        }
                        engon = false;
                    }
                    int i6 = -1;
                    if(pfase == 0)
                    {
                        for(int k8 = 0; k8 < 4; k8++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(xm > pnx[k8] && xm < 230 && ym > 433 + k8 * 24 && ym < 453 + k8 * 24)
                            {
                                i6 = k8;
                                rd.setColor(new Color(176, 64, 0));
                                rd.drawLine(pnx[k8], 448 + k8 * 24, 128, 448 + k8 * 24);
                            }
                            rd.drawString((new StringBuilder()).append("").append(pname[k8]).append(" :").toString(), pnx[k8], 447 + k8 * 24);
                            rd.drawLine(140, 443 + k8 * 24, 230, 443 + k8 * 24);
                            for(int l13 = 1; l13 < 10; l13++)
                                rd.drawLine(140 + 10 * l13, (443 - l13) + k8 * 24, 140 + 10 * l13, 443 + l13 + k8 * 24);

                            rd.setColor(new Color(255, 0, 0));
                            int i14 = (int)((float)phys[k8] / 1.1111F / 10F);
                            rd.fillRect(138 + (int)((float)phys[k8] / 1.1111F), (443 - i14) + k8 * 24, 5, i14 * 2 + 1);
                            rd.setColor(new Color(255, 128, 0));
                            rd.drawRect(139 + (int)((float)phys[k8] / 1.1111F), 434 + k8 * 24, 2, 18);
                            stringbutton(" - ", 260, 447 + k8 * 24, 4, false);
                            stringbutton(" + ", 300, 447 + k8 * 24, 4, false);
                        }

                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("<  Click on any variable name to learn about its function & use!", 333, 447);
                        stringbutton(" Random ", 380, 496, 0, false);
                        stringbutton(" Reset ", 455, 496, 0, false);
                        stringbutton("       Next  >       ", 570, 496, 0, true);
                    }
                    if(pfase == 1)
                    {
                        for(int l8 = 0; l8 < 4; l8++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(xm > pnx[l8 + 5] && xm < 211 && ym > 433 + l8 * 24 && ym < 453 + l8 * 24)
                            {
                                i6 = l8 + 5;
                                rd.setColor(new Color(176, 64, 0));
                                rd.drawLine(pnx[l8 + 5], 448 + l8 * 24, 109, 448 + l8 * 24);
                            }
                            rd.drawString((new StringBuilder()).append("").append(pname[l8 + 5]).append(" :").toString(), pnx[l8 + 5], 447 + l8 * 24);
                            rd.drawLine(121, 443 + l8 * 24, 211, 443 + l8 * 24);
                            for(int j14 = 1; j14 < 10; j14++)
                                rd.drawLine(121 + 10 * j14, (443 - j14) + l8 * 24, 121 + 10 * j14, 443 + j14 + l8 * 24);

                            rd.setColor(new Color(255, 0, 0));
                            int k14 = (int)((float)phys[l8 + 5] / 1.1111F / 10F);
                            rd.fillRect(119 + (int)((float)phys[l8 + 5] / 1.1111F), (443 - k14) + l8 * 24, 5, k14 * 2 + 1);
                            rd.setColor(new Color(255, 128, 0));
                            rd.drawRect(120 + (int)((float)phys[l8 + 5] / 1.1111F), 434 + l8 * 24, 2, 18);
                            stringbutton(" - ", 241, 447 + l8 * 24, 4, false);
                            stringbutton(" + ", 281, 447 + l8 * 24, 4, false);
                        }

                        for(int i9 = 0; i9 < 2; i9++)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(xm > pnx[i9 + 9] && xm < 548 && ym > 433 + i9 * 24 && ym < 453 + i9 * 24)
                            {
                                i6 = i9 + 9;
                                rd.setColor(new Color(176, 64, 0));
                                rd.drawLine(pnx[i9 + 9], 448 + i9 * 24, 446, 448 + i9 * 24);
                            }
                            rd.drawString((new StringBuilder()).append("").append(pname[i9 + 9]).append(" :").toString(), pnx[i9 + 9], 447 + i9 * 24);
                            rd.drawLine(458, 443 + i9 * 24, 548, 443 + i9 * 24);
                            for(int l14 = 1; l14 < 10; l14++)
                                rd.drawLine(458 + 10 * l14, (443 - l14) + i9 * 24, 458 + 10 * l14, 443 + l14 + i9 * 24);

                            rd.setColor(new Color(255, 0, 0));
                            int i15 = (int)((float)phys[i9 + 9] / 1.1111F / 10F);
                            rd.fillRect(456 + (int)((float)phys[i9 + 9] / 1.1111F), (443 - i15) + i9 * 24, 5, i15 * 2 + 1);
                            rd.setColor(new Color(255, 128, 0));
                            rd.drawRect(457 + (int)((float)phys[i9 + 9] / 1.1111F), 434 + i9 * 24, 2, 18);
                            stringbutton(" - ", 578, 447 + i9 * 24, 4, false);
                            stringbutton(" + ", 618, 447 + i9 * 24, 4, false);
                        }

                        stringbutton(" Random ", 361, 519, 0, false);
                        stringbutton(" Reset ", 436, 519, 0, false);
                        stringbutton(" <  Back ", 509, 519, 0, false);
                        stringbutton("       Next  >       ", 603, 519, 0, true);
                    }
                    if(pfase == 2)
                    {
                        if(xm > 40 && xm < 670 && ym > 416 && ym < 436)
                        {
                            i6 = 11;
                            rd.setColor(new Color(176, 64, 0));
                            rd.drawLine(596, 431, 669, 431);
                        }
                        rd.drawString("[   Crash Test,  Damage :                                       ]                                                     What is this?", 180, 430);
                        if(hitmag < 0)
                            hitmag = 0;
                        if(hitmag > 17000)
                        {
                            crashok = true;
                            hitmag = 17000;
                            for(int j9 = 0; j9 < o.npl; j9++)
                                if((o.p[j9].wz == 0 || o.p[j9].gr == -17 || o.p[j9].gr == -16) && o.p[j9].embos == 0)
                                    o.p[j9].embos = 1;

                        }
                        rd.setColor(new Color(255, (int)(250F - (float)hitmag / 68F), 0));
                        rd.fillRect(322, 423, (int)((float)hitmag / 170F), 7);
                        rd.setColor(new Color(255, 0, 0));
                        rd.drawRect(322, 423, 100, 7);
                        if(i6 != 11)
                            rd.setColor(new Color(170, 170, 170));
                        else
                            rd.setColor(new Color(176, 64, 0));
                        rd.drawString("Normal Crash", 39, 438);
                        rd.drawString("Roof Crash", 501, 438);
                        rd.drawLine(125, 426, 179, 426);
                        rd.drawLine(125, 426, 125, 440);
                        rd.drawLine(491, 426, 437, 426);
                        rd.drawLine(491, 426, 491, 440);
                        rd.drawRect(19, 440, 276, 91);
                        rd.drawRect(339, 440, 312, 67);
                        rd.setColor(new Color(0, 0, 0));
                        if(xm > 50 && xm < 195 && ym > 446 && ym < 466)
                        {
                            i6 = 12;
                            rd.setColor(new Color(176, 64, 0));
                            rd.drawLine(50, 461, 94, 461);
                        }
                        rd.drawString("Radius :", 50, 460);
                        rd.drawLine(105, 456, 195, 456);
                        for(int k9 = 1; k9 < 10; k9++)
                            rd.drawLine(105 + 10 * k9, 456 - k9, 105 + 10 * k9, 456 + k9);

                        rd.setColor(new Color(255, 0, 0));
                        int l9 = (int)((float)crash[0] / 1.1111F / 10F);
                        rd.fillRect(103 + (int)((float)crash[0] / 1.1111F), 456 - l9, 5, l9 * 2 + 1);
                        rd.setColor(new Color(255, 128, 0));
                        rd.drawRect(104 + (int)((float)crash[0] / 1.1111F), 447, 2, 18);
                        stringbutton(" - ", 225, 460, 4, false);
                        stringbutton(" + ", 265, 460, 4, false);
                        rd.setColor(new Color(0, 0, 0));
                        if(xm > 30 && xm < 195 && ym > 470 && ym < 490)
                        {
                            i6 = 13;
                            rd.setColor(new Color(176, 64, 0));
                            rd.drawLine(30, 485, 94, 485);
                        }
                        rd.drawString("Magnitude :", 30, 484);
                        rd.drawLine(105, 480, 195, 480);
                        for(int j15 = 1; j15 < 10; j15++)
                            rd.drawLine(105 + 10 * j15, 480 - j15, 105 + 10 * j15, 480 + j15);

                        rd.setColor(new Color(255, 0, 0));
                        l9 = (int)((float)crash[1] / 1.1111F / 10F);
                        rd.fillRect(103 + (int)((float)crash[1] / 1.1111F), 480 - l9, 5, l9 * 2 + 1);
                        rd.setColor(new Color(255, 128, 0));
                        rd.drawRect(104 + (int)((float)crash[1] / 1.1111F), 471, 2, 18);
                        stringbutton(" - ", 225, 484, 4, false);
                        stringbutton(" + ", 265, 484, 4, false);
                        rd.setColor(new Color(0, 0, 0));
                        if(xm > 350 && xm < 551 && ym > 446 && ym < 466)
                        {
                            i6 = 14;
                            rd.setColor(new Color(176, 64, 0));
                            rd.drawLine(350, 461, 450, 461);
                        }
                        rd.drawString("Roof Destruction :", 350, 460);
                        rd.drawLine(461, 456, 551, 456);
                        for(int k15 = 1; k15 < 10; k15++)
                            rd.drawLine(461 + 10 * k15, 456 - k15, 461 + 10 * k15, 456 + k15);

                        rd.setColor(new Color(255, 0, 0));
                        l9 = (int)((float)crash[2] / 1.1111F / 10F);
                        rd.fillRect(459 + (int)((float)crash[2] / 1.1111F), 456 - l9, 5, l9 * 2 + 1);
                        rd.setColor(new Color(255, 128, 0));
                        rd.drawRect(460 + (int)((float)crash[2] / 1.1111F), 447, 2, 18);
                        stringbutton(" - ", 581, 460, 4, false);
                        stringbutton(" + ", 621, 460, 4, false);
                        stringbutton("    CRASH!    ", 143, 516, 0, true);
                        stringbutton("  Fix  ", 235, 516, 0, false);
                        stringbutton("    CRASH Roof!    ", 484, 492, 0, true);
                        stringbutton("  Fix  ", 591, 492, 0, false);
                        stringbutton(" Reset ", 435, 535, 0, false);
                        stringbutton(" <  Back ", 508, 535, 0, false);
                        stringbutton("       Next  >       ", 602, 535, 0, true);
                    }
                    if(pfase == 3)
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Select the most suitable engine for your car :", 30, 440);
                        engine.move(293, 424);
                        if(!engine.isShowing())
                        {
                            engine.show();
                            engine.select(engsel);
                        }
                        if(engsel != engine.getSelectedIndex())
                        {
                            engsel = engine.getSelectedIndex();
                            for(int i10 = 0; i10 < 5; i10++)
                            {
                                for(int l15 = 0; l15 < 5; l15++)
                                {
                                    engs[l15][i10].stop();
                                    engs[l15][i10].checkopen();
                                }

                            }

                            engon = false;
                        }
                        if(engsel == 0)
                            rd.drawString("Normal Engine:  Like Tornado Shark, Sword of Justice or Radical One's engine.", 30, 470);
                        if(engsel == 1)
                            rd.drawString("V8 Engine:  High speed engine like Formula 7, Drifter X or Might Eight's engine.", 30, 470);
                        if(engsel == 2)
                            rd.drawString("Retro Engine:  Like Wow Caninaro, Lead Oxide or Kool Kat\u2019s engine.", 30, 470);
                        if(engsel == 3)
                            rd.drawString("Power Engine:  Turbo/super charged engine like Max Revenge, High Rider or Dr Monstaa\u2019s engine.", 30, 470);
                        if(engsel == 4)
                            rd.drawString("Diesel Engine:  Big diesel powered engine for big cars like EL King or  M A S H E E N .", 30, 470);
                        rd.drawString("LISTEN :", 30, 500);
                        stringbutton(" Idle ", 108, 500, 0, true);
                        stringbutton(" RPM 1 ", 170, 500, 0, true);
                        stringbutton(" RPM 2 ", 240, 500, 0, true);
                        stringbutton(" RPM 3 ", 310, 500, 0, true);
                        stringbutton(" RPM MAX ", 389, 500, 0, true);
                        if(engon)
                            stringbutton("          Stop Engine          ", 240, 535, 0, true);
                        else
                            stringbutton("          Stop Engine          ", 240, -2500, 0, true);
                        stringbutton(" <  Back ", 500, 525, 0, false);
                        stringbutton("     Save & Finish!     ", 610, 525, 0, true);
                    }
                    if(pfase == 4)
                    {
                        rd.drawString("Testing & Setting up Physics...", 265, 470);
                        repaint();
                        try
                        {
                            Thread _tmp = thredo;
                            Thread.sleep(100L);
                        }
                        catch(InterruptedException interruptedexception) { }
                        for(int j10 = 0; j10 < 4; j10++)
                        {
                            byte byte4 = 0;
                            byte byte5 = 4;
                            if(j10 == 1)
                                byte5 = 2;
                            if(j10 == 2)
                                byte4 = 2;
label0:
                            for(int l20 = 0; l20 < 10; l20++)
                            {
                                setupo();
                                o.xy = 0;
                                hitmag = 0;
                                int i23 = 0;
                                actmag = 0;
                                int i25 = byte4;
                                boolean flag10 = false;
                                do
                                {
                                    if(hitmag >= 17000)
                                        continue label0;
                                    if(flag10)
                                        regx(i25, (int)(150D + 600D * Math.random()), true);
                                    else
                                        regz(i25, (int)(150D + 600D * Math.random()), true);
                                    if(++i25 == byte5)
                                    {
                                        o.xz += 45;
                                        o.zy += 45;
                                        i25 = 0;
                                        if(flag10)
                                            flag10 = false;
                                        else
                                            flag10 = true;
                                        if(i23 == actmag)
                                            crash[0] += 10;
                                        i23 = actmag;
                                    }
                                } while(true);
                            }

                            float f5 = 0.0F;
                            for(int j23 = 0; j23 < 10; j23++)
                            {
                                setupo();
                                o.xy = 0;
                                actmag = 0;
                                hitmag = 0;
                                int j25 = byte4;
                                boolean flag11 = false;
                                do
                                {
                                    if(hitmag >= 17000)
                                        break;
                                    if(flag11)
                                        regx(j25, (int)(150D + 600D * Math.random()), true);
                                    else
                                        regz(j25, (int)(150D + 600D * Math.random()), true);
                                    if(++j25 == byte5)
                                    {
                                        o.xz += 45;
                                        o.zy += 45;
                                        j25 = 0;
                                        if(flag11)
                                            flag11 = false;
                                        else
                                            flag11 = true;
                                    }
                                } while(true);
                                f5 += (float)actmag / (float)hitmag;
                            }

                            f5 /= 10F;
                            actmag = (int)((float)hitmag * f5);
                            if(stat[4] > 200)
                                stat[4] = 200;
                            if(stat[4] < 16)
                                stat[4] = 16;
                            float f6 = 0.9F + (float)(stat[4] - 90) * 0.01F;
                            if((double)f6 < 0.59999999999999998D)
                                f6 = 0.6F;
                            if(stat[4] == 200 && stat[0] <= 88)
                                f6 = 3F;
                            int k25 = (int)((float)actmag * f6);
label1:
                            for(int i26 = 0; i26 < 12; i26++)
                            {
                                setupo();
                                o.xy = 0;
                                o.xz = 90 * i26;
                                if(o.xz >= 360)
                                    o.xz -= 360;
                                hitmag = 0;
                                int l26 = 0;
                                actmag = 0;
                                int i28 = byte4;
                                boolean flag13 = false;
                                do
                                {
                                    if(actmag >= k25)
                                        continue label1;
                                    if(flag13)
                                        regx(i28, (int)(150D + 600D * Math.random()), true);
                                    else
                                        regz(i28, (int)(150D + 600D * Math.random()), true);
                                    if(++i28 == byte5)
                                    {
                                        if(flag13)
                                            flag13 = false;
                                        else
                                            flag13 = true;
                                        i28 = 0;
                                        if(l26 == actmag)
                                            crash[0] += 10;
                                        l26 = actmag;
                                    }
                                } while(true);
                            }

                            if(j10 != 3)
                                continue;
                            f5 = 0.0F;
                            for(int j26 = 0; j26 < 10; j26++)
                            {
                                setupo();
                                o.xy = 0;
                                actmag = 0;
                                hitmag = 0;
                                int i27 = byte4;
                                boolean flag12 = false;
                                do
                                {
                                    if(hitmag >= 17000)
                                        break;
                                    if(flag12)
                                        regx(i27, (int)(150D + 600D * Math.random()), true);
                                    else
                                        regz(i27, (int)(150D + 600D * Math.random()), true);
                                    if(++i27 == byte5)
                                    {
                                        o.xz += 45;
                                        o.zy += 45;
                                        i27 = 0;
                                        if(flag12)
                                            flag12 = false;
                                        else
                                            flag12 = true;
                                    }
                                } while(true);
                                f5 += (float)actmag / (float)hitmag;
                            }

                            f5 /= 10F;
                            actmag = (int)((float)hitmag * f5);
                        }

                        setupo();
                        String s15 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        String s17 = "";
                        int i18 = 0;
                        for(int i21 = s15.indexOf("\n", 0); i21 != -1 && i18 < s15.length();)
                        {
                            String s23 = s15.substring(i18, i21);
                            s23 = s23.trim();
                            i18 = i21 + 1;
                            i21 = s15.indexOf("\n", i18);
                            if(!s23.startsWith("physics("))
                            {
                                s17 = (new StringBuilder()).append(s17).append("").append(s23).append("\n").toString();
                            } else
                            {
                                s17 = s17.trim();
                                s17 = (new StringBuilder()).append(s17).append("\n").toString();
                            }
                        }

                        s17 = s17.trim();
                        s17 = (new StringBuilder()).append(s17).append("\n\n\nphysics(").append(phys[0]).append(",").append(phys[1]).append(",").append(phys[2]).append(",").append(phys[3]).append(",").append(phys[4]).append(",").append(phys[5]).append(",").append(phys[6]).append(",").append(phys[7]).append(",").append(phys[8]).append(",").append(phys[9]).append(",").append(phys[10]).append(",").append(crash[0]).append(",").append(crash[1]).append(",").append(crash[2]).append(",").append(engsel).append(",").append(actmag).append(")\n\n\n\n").toString();
                        editor.setText(s17);
                        savefile();
                        for(int k23 = 0; k23 < 11; k23++)
                            rphys[k23] = phys[k23];

                        for(int l23 = 0; l23 < 3; l23++)
                            rcrash[l23] = crash[l23];

                        pfase = 5;
                    }
                    if(pfase == 5)
                    {
                        rd.drawString("Car physics has been successfully set up!", 231, 450);
                        rd.drawString("Test drive your car to see the results...", 242, 490);
                    }
                    if(i6 != -1)
                    {
                        if(mouseon == -1)
                        {
                            mouseon = i6;
                            setCursor(new Cursor(12));
                        }
                    } else
                    if(mouseon != -1)
                    {
                        mouseon = -1;
                        setCursor(new Cursor(0));
                    }
                    if(mouses == -1 && i6 != -1)
                        JOptionPane.showMessageDialog(null, usage[i6], "Car Maker", 1);
                }
                if(dtab == 6)
                {
                    if(dtab != dtabed)
                    {
                        String s12 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        int k10 = 0;
                        int i16 = s12.indexOf("\n", 0);
                        do
                        {
                            if(i16 == -1 || k10 >= s12.length())
                                break;
                            String s22 = s12.substring(k10, i16);
                            s22 = s22.trim();
                            k10 = i16 + 1;
                            i16 = s12.indexOf("\n", k10);
                            if(s22.startsWith("handling("))
                                try
                                {
                                    handling = getvalue("handling", s22, 0);
                                    if(handling > 200)
                                        handling = 200;
                                    if(handling < 50)
                                        handling = 50;
                                }
                                catch(Exception exception12) { }
                        } while(true);
                        rateh = false;
                    }
                    if(!rateh)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Test Drive the Car", 350 - ftm.stringWidth("Test Drive the Car") / 2, 445);
                        witho.move(292, 455);
                        if(!witho.isShowing())
                            witho.show();
                        stringbutton("     TEST DRIVE!     ", 350, 505, 0, true);
                        if(tested)
                        {
                            stringbutton("  Edit Stats & Class  ", 150, 471, 0, false);
                            stringbutton("  Edit Physics  ", 150, 505, 0, false);
                            stringbutton("     Rate Car Handling     ", 550, 471, 0, true);
                        }
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString((new StringBuilder()).append("Based on you test drive(s), how do your rate ").append(carname).append("'s handling?").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Based on your test drive(s), how do you rate ").append(carname).append("'s handling?").toString()) / 2, 445);
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.drawString("Handling :", 183, 483);
                        for(int j6 = 0; j6 < handling; j6++)
                        {
                            rd.setColor(Color.getHSBColor((float)((double)(float)j6 * 0.00069999999999999999D), 1.0F, 1.0F));
                            rd.drawLine(250 + j6, 474, 250 + j6, 482);
                        }

                        rd.setColor(new Color(0, 0, 0));
                        rd.drawLine(249, 474, 249, 482);
                        rd.drawLine(450, 474, 450, 482);
                        rd.drawLine(249, 483, 450, 483);
                        for(int k6 = 0; k6 < 7; k6++)
                            rd.drawLine(275 + k6 * 25, 482, 275 + k6 * 25, 478);

                        stringbutton(" - ", 480, 483, 4, false);
                        stringbutton(" + ", 520, 483, 4, false);
                        stringbutton("       Save       ", 388, 525, 0, true);
                        stringbutton(" Cancel ", 298, 525, 0, false);
                    }
                }
                if(polynum >= 0 && cntpls > 0)
                {
                    for(int l6 = 0; l6 < o.npl; l6++)
                    {
                        if(l6 >= polynum && l6 < polynum + cntpls)
                        {
                            if(pflk)
                            {
                                o.p[l6].hsb[2] = 1.0F;
                                continue;
                            }
                            o.p[l6].hsb[2] = 0.0F;
                            for(o.p[l6].hsb[0] = Math.abs(0.5F - o.p[l6].hsb[0]); o.p[l6].hsb[0] > 1.0F; o.p[l6].hsb[0]--);
                            continue;
                        }
                        if(prflk > 6 && prflk < 20)
                            o.p[l6].gr = -13;
                        else
                            o.p[l6].gr = 1;
                    }

                    if(pflk)
                        pflk = false;
                    else
                        pflk = true;
                    if(prflk < 40)
                        prflk++;
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("[ Showing ").append(cntpls).append(" Polygons Selected ]").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("[ Showing ").append(cntpls).append(" Polygons Selected ]").toString()) / 2, 45);
                    stringbutton("  Stop  ", 350, 67, 5, false);
                }
                j = 50;
                if(rotr)
                {
                    o.xz -= 5;
                    j = 15;
                }
                if(rotl)
                {
                    o.xz += 5;
                    j = 15;
                }
                if(left)
                {
                    o.xy -= 5;
                    j = 15;
                }
                if(right)
                {
                    o.xy += 5;
                    j = 15;
                }
                if(up)
                {
                    o.zy -= 5;
                    j = 15;
                }
                if(down)
                {
                    o.zy += 5;
                    j = 15;
                }
                if(plus)
                {
                    o.y += 5;
                    j = 15;
                }
                if(minus)
                {
                    o.y -= 5;
                    j = 15;
                }
                if(in)
                {
                    o.z += 10;
                    j = 15;
                }
                if(out)
                {
                    o.z -= 10;
                    j = 15;
                }
                ox = o.x;
                oy = o.y;
                oz = o.z;
                oxz = o.xz;
                oxy = o.xy;
                ozy = o.zy;
                if(dtabed != dtab)
                    dtabed = dtab;
                if(dtab == 5 && pfase == -1)
                {
                    repaint();
                    JOptionPane.showMessageDialog(null, "Car Wheels not defined or not defined correctly.\nBefore defining the car Physics car Wheels must be defined correctly!\nPlease go to the \u2018Wheels\u2019 tab and use  [ Apply ]  and  [ Save ]  to define correctly.\n", "Car Maker", 1);
                    dtab = 3;
                }
            }
            if(tab == 3)
            {
                rd.setFont(new Font("Arial", 1, 13));
                rd.setColor(new Color(0, 0, 0));
                rd.drawString((new StringBuilder()).append("Publish Car :  [ ").append(carname).append(" ]").toString(), 30, 50);
                rd.drawString("Publishing Type :", 30, 80);
                pubtyp.move(150, 63);
                if(!pubtyp.isShowing())
                {
                    pubtyp.show();
                    pubtyp.select(1);
                }
                stringbutton("       Publish  >       ", 102, 110, 0, true);
                pubitem.move(690 - pubitem.w, 96);
                if(!pubitem.isShowing())
                    pubitem.show();
                if(pubitem.sel != 0)
                {
                    boolean flag1 = false;
                    for(int i2 = 0; i2 < nmc; i2++)
                        if(pubitem.getSelectedItem().equals(mycars[i2]))
                            flag1 = true;

                    if(!flag1)
                        logged = 2;
                }
                rd.setColor(new Color(0, 0, 0));
                rd.setFont(new Font("Arial", 0, 12));
                if(pubtyp.getSelectedIndex() == 0)
                {
                    rd.drawString("Private :  This means only you can use your car and no one else can add", 268, 72);
                    rd.drawString("it to their account to play with it !", 268, 88);
                }
                if(pubtyp.getSelectedIndex() == 1)
                {
                    rd.drawString("Public :  This means anyone can add this car to their account to play with it,", 268, 72);
                    rd.drawString("but only you can download it to your Car Maker (no one else can get it\u2019s code).", 268, 88);
                }
                if(pubtyp.getSelectedIndex() == 2)
                {
                    rd.drawString("Super Public :  This means anyone can add this car to their account to play", 268, 72);
                    rd.drawString("with it and anyone can also download it to their Car Maker to get its code.", 268, 88);
                }
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                rd.drawString("Car Name", 80 - ftm.stringWidth("Car Name") / 2, 138);
                rd.drawString("Car Class", 200 - ftm.stringWidth("Car Class") / 2, 138);
                rd.drawString("Created By", 300 - ftm.stringWidth("Created By") / 2, 138);
                rd.drawString("Added By", 400 - ftm.stringWidth("Added By") / 2, 138);
                rd.drawString("Publish Type", 500 - ftm.stringWidth("Publish Type") / 2, 138);
                rd.drawString("Options", 620 - ftm.stringWidth("Options") / 2, 138);
                rd.drawLine(150, 129, 150, 140);
                rd.drawLine(250, 129, 250, 140);
                rd.drawLine(350, 129, 350, 140);
                rd.drawLine(450, 129, 450, 140);
                rd.drawLine(550, 129, 550, 140);
                rd.drawRect(10, 140, 680, 402);
                if(logged == 0)
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Login to Retrieve your Account Cars", 350 - ftm.stringWidth("Login to Retrieve your Account Cars") / 2, 220);
                    rd.drawString("Nickname:", 326 - ftm.stringWidth("Nickname:") - 14, 266);
                    movefield(tnick, 326, 250, 129, 22);
                    if(!tnick.isShowing())
                        tnick.show();
                    rd.drawString("Password:", 326 - ftm.stringWidth("Password:") - 14, 296);
                    movefield(tpass, 326, 280, 129, 22);
                    if(!tpass.isShowing())
                        tpass.show();
                    stringbutton("       Login       ", 350, 340, 0, true);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Register a full account or if you have a trial account upgrade it!", 350 - ftm.stringWidth("Register a full account or if you have a trial account upgrade it!") / 2, 450);
                    stringbutton("   Register!   ", 290, 480, 0, true);
                    stringbutton("   Upgrade!   ", 410, 480, 0, true);
                    rd.setFont(new Font("Arial", 0, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("You need a full account to publish your cars to the multiplayer game!", 350 - ftm.stringWidth("You need a full account to publish your cars to the multiplayer game!") / 2, 505);
                }
                if(logged == -1)
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Ready to publish...", 350 - ftm.stringWidth("Ready to publish...") / 2, 220);
                    rd.drawString((new StringBuilder()).append("Click \u2018Publish\u2019 above to add car: '").append(carname).append("'.").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Click \u2018Publish\u2019 above to add car: '").append(carname).append("'.").toString()) / 2, 280);
                }
                if(logged == 2)
                {
                    mycars[roto] = pubitem.getSelectedItem();
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(225, 225, 225));
                    rd.fillRect(50, 150, 600, 150);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString((new StringBuilder()).append("Loading ").append(mycars[roto]).append("\u2018s info...").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Loading ").append(mycars[roto]).append("\u2018s info...").toString()) / 2, 220);
                    repaint();
                    maker[roto] = "Unkown";
                    pubt[roto] = -1;
                    clas[roto] = 0;
                    nad[roto] = 0;
                    String s1 = "";
                    try
                    {
                        String s3 = (new StringBuilder()).append("http://multiplayer.needformadness.com/cars/").append(mycars[roto]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                        s3 = s3.replace(' ', '_');
                        URL url = new URL(s3);
                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                        do
                        {
                            String s2;
                            if((s2 = datainputstream.readLine()) == null)
                                break;
                            s2 = (new StringBuilder()).append("").append(s2.trim()).toString();
                            if(s2.startsWith("details"))
                            {
                                maker[roto] = getSvalue("details", s2, 0);
                                pubt[roto] = getvalue("details", s2, 1);
                                clas[roto] = getvalue("details", s2, 2);
                                boolean flag6 = false;
                                while(!flag6) 
                                {
                                    addeda[roto][nad[roto]] = getSvalue("details", s2, 3 + nad[roto]);
                                    if(addeda[roto][nad[roto]].equals(""))
                                        flag6 = true;
                                    else
                                        nad[roto]++;
                                }
                            }
                        } while(true);
                        nmc++;
                        if(nmc > 20)
                            nmc = 20;
                        roto++;
                        if(roto >= 20)
                            roto = 0;
                    }
                    catch(Exception exception1) { }
                    logged = 3;
                }
                if(logged == 1)
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Loading your account car list...", 350 - ftm.stringWidth("Loading your account car list...") / 2, 220);
                    repaint();
                    pubitem.removeAll();
                    pubitem.add(rd, "Account Cars");
                    nmc = 0;
                    roto = 0;
                    int i1 = 0;
                    String s4 = "";
                    try
                    {
                        URL url1 = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/lists/").append(tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                        DataInputStream datainputstream1 = new DataInputStream(url1.openStream());
                        do
                        {
                            String s5;
                            if((s5 = datainputstream1.readLine()) == null)
                                break;
                            s5 = (new StringBuilder()).append("").append(s5.trim()).toString();
                            if(s5.startsWith("mycars"))
                            {
                                boolean flag7 = true;
                                while(flag7 && i1 < 700) 
                                {
                                    String s18 = getSvalue("mycars", s5, i1);
                                    if(s18.equals(""))
                                    {
                                        flag7 = false;
                                    } else
                                    {
                                        pubitem.add(rd, s18);
                                        i1++;
                                    }
                                }
                            }
                        } while(true);
                        setCursor(new Cursor(0));
                        logged = -1;
                        datainputstream1.close();
                    }
                    catch(Exception exception2)
                    {
                        String s13 = (new StringBuilder()).append("").append(exception2).toString();
                        if(s13.indexOf("FileNotFound") != -1)
                        {
                            setCursor(new Cursor(0));
                            logged = -1;
                        } else
                        {
                            logged = 0;
                            JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Car Maker", 1);
                        }
                    }
                    if(!justpubd.equals(""))
                    {
                        pubitem.select(justpubd);
                        justpubd = "";
                    }
                }
                if(logged == 3)
                {
                    for(int j1 = 0; j1 < nmc; j1++)
                    {
                        rd.setColor(new Color(235, 235, 235));
                        if(xm > 11 && xm < 689 && ym > 142 + j1 * 20 && ym < 160 + j1 * 20)
                            rd.setColor(new Color(255, 255, 255));
                        rd.fillRect(11, 142 + j1 * 20, 678, 18);
                        rd.setFont(new Font("Arial", 0, 12));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString(mycars[j1], 80 - ftm.stringWidth(mycars[j1]) / 2, 156 + j1 * 20);
                        rd.setColor(new Color(155, 155, 155));
                        rd.drawLine(150, 145 + j1 * 20, 150, 157 + j1 * 20);
                        if(pubt[j1] != -1)
                        {
                            rd.drawLine(250, 145 + j1 * 20, 250, 157 + j1 * 20);
                            rd.drawLine(350, 145 + j1 * 20, 350, 157 + j1 * 20);
                            rd.drawLine(450, 145 + j1 * 20, 450, 157 + j1 * 20);
                            rd.drawLine(550, 145 + j1 * 20, 550, 157 + j1 * 20);
                            rd.setColor(new Color(0, 0, 64));
                            String s6 = "C";
                            if(clas[j1] == 1)
                                s6 = "B & C";
                            if(clas[j1] == 2)
                                s6 = "B";
                            if(clas[j1] == 3)
                                s6 = "A & B";
                            if(clas[j1] == 4)
                                s6 = "A";
                            rd.drawString((new StringBuilder()).append("Class ").append(s6).append("").toString(), 200 - ftm.stringWidth((new StringBuilder()).append("Class ").append(s6).append("").toString()) / 2, 156 + j1 * 20);
                            boolean flag4 = false;
                            if(maker[j1].toLowerCase().equals(tnick.getText().toLowerCase()))
                            {
                                flag4 = true;
                                rd.setColor(new Color(0, 64, 0));
                                rd.drawString("You", 300 - ftm.stringWidth("You") / 2, 156 + j1 * 20);
                            } else
                            {
                                rd.drawString(maker[j1], 300 - ftm.stringWidth(maker[j1]) / 2, 156 + j1 * 20);
                            }
                            if(nad[j1] > 1)
                            {
                                if(ovbutton((new StringBuilder()).append("").append(nad[j1]).append(" Players").toString(), 400, 156 + j1 * 20))
                                {
                                    String s14 = (new StringBuilder()).append("[ ").append(mycars[j1]).append(" ]  has been added by the following players to their accounts:     \n\n").toString();
                                    int l10 = 0;
                                    for(int j16 = 0; j16 < nad[j1]; j16++)
                                    {
                                        if(++l10 == 17)
                                        {
                                            s14 = (new StringBuilder()).append(s14).append("\n").toString();
                                            l10 = 1;
                                        }
                                        s14 = (new StringBuilder()).append(s14).append(addeda[j1][j16]).toString();
                                        if(j16 == nad[j1] - 1)
                                            continue;
                                        if(j16 != nad[j1] - 2)
                                        {
                                            s14 = (new StringBuilder()).append(s14).append(", ").toString();
                                            continue;
                                        }
                                        if(l10 == 16)
                                        {
                                            s14 = (new StringBuilder()).append(s14).append("\nand ").toString();
                                            l10 = 0;
                                        } else
                                        {
                                            s14 = (new StringBuilder()).append(s14).append(" and ").toString();
                                        }
                                    }

                                    s14 = (new StringBuilder()).append(s14).append("\n \n \n").toString();
                                    JOptionPane.showMessageDialog(null, s14, "Car Maker", 1);
                                }
                            } else
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("None", 400 - ftm.stringWidth("None") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 0)
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("Private", 500 - ftm.stringWidth("Private") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 1)
                            {
                                rd.setColor(new Color(0, 0, 64));
                                rd.drawString("Public", 500 - ftm.stringWidth("Public") / 2, 156 + j1 * 20);
                            }
                            if(pubt[j1] == 2)
                            {
                                rd.setColor(new Color(0, 64, 0));
                                rd.drawString("Super Public", 500 - ftm.stringWidth("Super Public") / 2, 156 + j1 * 20);
                            }
                            if((pubt[j1] == 2 || flag4) && ovbutton("Download", 600, 156 + j1 * 20))
                            {
                                int i7 = 0;
                                for(int i11 = 0; i11 < slcar.getItemCount(); i11++)
                                    if(mycars[j1].equals(slcar.getItem(i11)))
                                        i7 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Replace the local ").append(mycars[j1]).append(" in your 'mycars' folder with the published online copy?").toString(), "Car Maker", 0);

                                if(i7 == 0)
                                {
                                    setCursor(new Cursor(3));
                                    rd.setFont(new Font("Arial", 1, 13));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(225, 225, 225));
                                    rd.fillRect(11, 141, 679, 401);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("Downloading car, please wait...", 350 - ftm.stringWidth("Downloading car, please wait...") / 2, 250);
                                    repaint();
                                    try
                                    {
                                        String s16 = (new StringBuilder()).append("http://multiplayer.needformadness.com/cars/").append(mycars[j1]).append(".radq?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                                        s16 = s16.replace(' ', '_');
                                        URL url2 = new URL(s16);
                                        int j21 = url2.openConnection().getContentLength();
                                        DataInputStream datainputstream2 = new DataInputStream(url2.openStream());
                                        byte abyte0[] = new byte[j21];
                                        datainputstream2.readFully(abyte0);
                                        ZipInputStream zipinputstream;
                                        if(abyte0[0] == 80 && abyte0[1] == 75 && abyte0[2] == 3)
                                        {
                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte0));
                                        } else
                                        {
                                            byte abyte1[] = new byte[j21 - 40];
                                            for(int j27 = 0; j27 < j21 - 40; j27++)
                                            {
                                                byte byte6 = 20;
                                                if(j27 >= 500)
                                                    byte6 = 40;
                                                abyte1[j27] = abyte0[j27 + byte6];
                                            }

                                            zipinputstream = new ZipInputStream(new ByteArrayInputStream(abyte1));
                                        }
                                        ZipEntry zipentry = zipinputstream.getNextEntry();
                                        if(zipentry != null)
                                        {
                                            int k27 = Integer.valueOf(zipentry.getName()).intValue();
                                            byte abyte2[] = new byte[k27];
                                            int k28 = 0;
                                            int i29;
                                            for(; k27 > 0; k27 -= i29)
                                            {
                                                i29 = zipinputstream.read(abyte2, k28, k27);
                                                k28 += i29;
                                            }

                                            String s24 = new String(abyte2);
                                            s24 = (new StringBuilder()).append(s24).append("\n").toString();
                                            String s25 = "";
                                            int i30 = 0;
                                            for(int k30 = s24.indexOf("\n", 0); k30 != -1 && i30 < s24.length();)
                                            {
                                                String s27 = s24.substring(i30, k30);
                                                s27 = s27.trim();
                                                i30 = k30 + 1;
                                                k30 = s24.indexOf("\n", i30);
                                                if(!s27.startsWith("carmaker(") && !s27.startsWith("publish("))
                                                {
                                                    s25 = (new StringBuilder()).append(s25).append("").append(s27).append("\n").toString();
                                                } else
                                                {
                                                    s25 = s25.trim();
                                                    s25 = (new StringBuilder()).append(s25).append("\n").toString();
                                                }
                                            }

                                            s25 = s25.trim();
                                            s25 = (new StringBuilder()).append(s25).append("\n\n").toString();
                                            File file = new File("mycars/");
                                            if(!file.exists())
                                                file.mkdirs();
                                            file = new File((new StringBuilder()).append("mycars/").append(mycars[j1]).append(".rad").toString());
                                            BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                                            bufferedwriter.write(s25);
                                            bufferedwriter.close();
                                            bufferedwriter = null;
                                            zipinputstream.close();
                                            if(carname.equals(mycars[j1]))
                                            {
                                                editor.setText(s25);
                                                lastedo = s25;
                                            }
                                            setCursor(new Cursor(0));
                                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("").append(mycars[j1]).append(" has been successfully downloaded!").toString(), "Car Maker", 1);
                                        } else
                                        {
                                            JOptionPane.showMessageDialog(null, "Unable to download car.  Unknown Error!     \nPlease try again later.", "Car Maker", 1);
                                        }
                                    }
                                    catch(Exception exception7)
                                    {
                                        JOptionPane.showMessageDialog(null, "Unable to download car.  Unknown Error!     \nPlease try again later.", "Car Maker", 1);
                                    }
                                }
                            }
                        } else
                        {
                            rd.drawString("-    Error Loading this car's info!    -", 350 - ftm.stringWidth("-    Error Loading this car's info!    -") / 2, 156 + j1 * 20);
                        }
                        if(!ovbutton("X", 665, 156 + j1 * 20) || JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Remove ").append(mycars[j1]).append(" from your account?").toString(), "Car Maker", 0) != 0)
                            continue;
                        setCursor(new Cursor(3));
                        int j2 = -1;
                        try
                        {
                            Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                            printwriter.println((new StringBuilder()).append("9|").append(tnick.getText()).append("|").append(tpass.getText()).append("|").append(mycars[j1]).append("|").toString());
                            String s19 = bufferedreader.readLine();
                            if(s19 != null)
                                j2 = servervalue(s19, 0);
                            socket.close();
                        }
                        catch(Exception exception3)
                        {
                            j2 = -1;
                        }
                        if(j2 == 0)
                        {
                            logged = 1;
                        } else
                        {
                            setCursor(new Cursor(0));
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Failed to remove ").append(mycars[j1]).append(" from your account.  Unknown Error!     \nPlease try again later.").toString(), "Car Maker", 1);
                        }
                    }

                }
            }
            if(tabed != tab)
                tabed = tab;
            rd.setColor(new Color(0, 0, 0));
            rd.fillRect(0, 0, 700, 25);
            if(!onbtgame)
                rd.drawImage(btgame[0], 520, 0, null);
            else
                rd.drawImage(btgame[1], 520, 0, null);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            String as2[] = {
                "Car", "Code Edit", "3D Edit", "Publish"
            };
            int ai3[] = {
                0, 0, 100, 90
            };
            int ai6[] = {
                0, 25, 25, 0
            };
            byte byte2 = 4;
            if(carname.equals("") || !loadedfile || sfase != 0)
            {
                tab = 0;
                byte2 = 1;
            }
            for(int j11 = 0; j11 < byte2; j11++)
            {
                rd.setColor(new Color(170, 170, 170));
                if(xm > ai3[0] && xm < ai3[3] && ym > 0 && ym < 25)
                    rd.setColor(new Color(200, 200, 200));
                if(tab == j11)
                    rd.setColor(new Color(225, 225, 225));
                rd.fillPolygon(ai3, ai6, 4);
                rd.setColor(new Color(0, 0, 0));
                rd.drawString(as2[j11], (j11 * 100 + 45) - ftm.stringWidth(as2[j11]) / 2, 17);
                if(xm > ai3[0] && xm < ai3[3] && ym > 0 && ym < 25 && mouses == -1)
                {
                    if(tab != j11 && tab == 1)
                        savefile();
                    tab = j11;
                }
                for(int k16 = 0; k16 < 4; k16++)
                    ai3[k16] += 100;

            }

            drawms();
            ctachm();
            repaint();
            if(!exwist)
                try
                {
                    Thread _tmp1 = thredo;
                    Thread.sleep(j);
                }
                catch(InterruptedException interruptedexception1) { }
        } while(true);
        rd.dispose();
        System.gc();
        if(Madness.endadv == 2)
            Madness.advopen();
    }

    public void ctachm()
    {
        int i = -1;
        for(int j = 0; j < btn; j++)
        {
            if(Math.abs(xm - bx[j]) < bw[j] / 2 + 12 && Math.abs(ym - by[j]) < 14 && mouses == 1)
                pessd[j] = true;
            else
                pessd[j] = false;
            if(Math.abs(xm - bx[j]) < bw[j] / 2 + 12 && Math.abs(ym - by[j]) < 14 && mouses == -1)
                i = j;
        }

        if(mouses == -1)
            mouses = 0;
        if(tab == 0)
        {
            if(sfase == 0)
            {
                if(i == 0)
                {
                    sfase = 1;
                    i = -1;
                    hidefields();
                }
                if(i == 1)
                    if(!carname.equals(""))
                    {
                        srch.setText(carname);
                        sfase = 2;
                        i = -1;
                        hidefields();
                    } else
                    {
                        JOptionPane.showMessageDialog(null, "Please Select a Car to Rename!\n", "Car Maker", 1);
                    }
                if(i == 2)
                    delcar(carname);
                if(i == 3)
                {
                    sfase = 3;
                    i = -1;
                    hidefields();
                }
            }
            if(sfase == 1)
            {
                if(i == 0)
                {
                    newcar(srch.getText());
                    i = -1;
                }
                if(i == 1)
                {
                    srch.setText("");
                    sfase = 0;
                    i = -1;
                    hidefields();
                }
            }
            if(sfase == 2)
            {
                if(i == 0)
                {
                    rencar(srch.getText());
                    i = -1;
                }
                if(i == 1)
                {
                    srch.setText("");
                    sfase = 0;
                    i = -1;
                    hidefields();
                }
            }
            if(sfase == 3)
            {
                if(i == 0)
                {
                    File file = null;
                    FileDialog filedialog = new FileDialog(new Frame(), "Car Maker - Wavefront OBJ Import");
                    filedialog.setFile("*.obj");
                    filedialog.setMode(0);
                    filedialog.setVisible(true);
                    try
                    {
                        if(filedialog.getFile() != null)
                            file = new File((new StringBuilder()).append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString());
                    }
                    catch(Exception exception2) { }
                    if(file != null)
                    {
                        setCursor(new Cursor(3));
                        byte byte2 = 0;
                        if(tutok)
                            byte2 = -70;
                        rd.setColor(new Color(225, 225, 225));
                        rd.fillRect(116, 246 + byte2, 468, 50);
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.drawString((new StringBuilder()).append("Reading ").append(file.getName()).append(", please wait...").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Reading ").append(file.getName()).append(", please wait...").toString()) / 2, 276 + byte2);
                        repaint();
                        int ai[] = new int[6000];
                        int ai2[] = new int[6000];
                        int ai5[] = new int[6000];
                        int l18 = 0;
                        int ai7[][] = new int[600][100];
                        int ai8[] = new int[600];
                        int i21 = 0;
                        if(file.exists())
                        {
                            try
                            {
                                BufferedReader bufferedreader2 = new BufferedReader(new FileReader(file));
                                Object obj = null;
                                boolean flag6 = false;
                                boolean flag7 = false;
                                do
                                {
                                    String s28;
                                    if((s28 = bufferedreader2.readLine()) == null)
                                        break;
                                    if(s28.startsWith("v "))
                                        if(l18 < 6000)
                                        {
                                            multf10 = true;
                                            ai[l18] = objvalue(s28, 0);
                                            ai2[l18] = objvalue(s28, 1);
                                            ai5[l18] = objvalue(s28, 2);
                                            l18++;
                                        } else
                                        {
                                            flag6 = true;
                                        }
                                    if(s28.startsWith("f "))
                                        if(i21 < 600)
                                        {
                                            multf10 = false;
                                            objfacend = false;
                                            for(ai8[i21] = 0; !objfacend && ai8[i21] < 100; ai8[i21]++)
                                                ai7[i21][ai8[i21]] = objvalue(s28, ai8[i21]);

                                            i21++;
                                        } else
                                        {
                                            flag7 = true;
                                        }
                                } while(true);
                                if(flag6)
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Warning!\nThe number of Vertices in file ").append(file.getName()).append(" exceeded the maximum of 6000 that the Car Maker can read!     \n\nPlease choose a simpler model to import.\n \n").toString(), "Car Maker", 0);
                                if(flag7)
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Warning!\nThe number of Faces in file ").append(file.getName()).append(" exceeded the maximum of 600 that the Car Maker can read!     \n\nPlease choose a simpler model to import.\n \n").toString(), "Car Maker", 0);
                                bufferedreader2.close();
                                bufferedreader2 = null;
                            }
                            catch(Exception exception7)
                            {
                                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to load file! Error Deatials:\n").append(exception7).toString(), "Car Maker", 1);
                            }
                            rd.setColor(new Color(225, 225, 225));
                            rd.fillRect(116, 246 + byte2, 468, 50);
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("Importing ").append(file.getName()).append(", please wait...").toString(), 350 - ftm.stringWidth((new StringBuilder()).append("Importing ").append(file.getName()).append(", please wait...").toString()) / 2, 276 + byte2);
                            repaint();
                            carname = file.getName();
                            if(carname.endsWith(".obj"))
                                carname = carname.substring(0, carname.length() - 4);
                            String s27 = (new StringBuilder()).append("\n// imported car: ").append(carname).append("\n---------------------\n\n// Please read the helpful information about importing cars found at:\n// http://www.needformadness.com/developer/extras.html\n\n\n").toString();
                            for(int l22 = 0; l22 < i21; l22++)
                            {
                                s27 = (new StringBuilder()).append(s27).append("<p>\nc(200,200,220)\n\n").toString();
                                for(int l23 = 0; l23 < ai8[l22]; l23++)
                                    if(ai7[l22][l23] < 6000)
                                    {
                                        int l24 = ai7[l22][l23];
                                        s27 = (new StringBuilder()).append(s27).append("p(").append(ai[l24]).append(",").append(-ai2[l24]).append(",").append(ai5[l24]).append(")\n").toString();
                                    }

                                s27 = (new StringBuilder()).append(s27).append("</p>\n\n").toString();
                            }

                            s27 = (new StringBuilder()).append(s27).append("\n\n\n\n").toString();
                            file = new File("mycars/");
                            if(!file.exists())
                                file.mkdirs();
                            file = new File((new StringBuilder()).append("mycars/").append(carname).append(".rad").toString());
                            int i23 = 0;
                            if(file.exists())
                                i23 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Another car with the name '").append(carname).append("' already exists, replace it?      \n").toString(), "Car Maker", 0);
                            if(i23 == 0)
                                try
                                {
                                    BufferedWriter bufferedwriter1 = new BufferedWriter(new FileWriter(file));
                                    bufferedwriter1.write(s27);
                                    bufferedwriter1.close();
                                    bufferedwriter1 = null;
                                    if(file.exists())
                                    {
                                        sfase = 0;
                                        hidefields();
                                        tabed = -1;
                                    } else
                                    {
                                        carname = "";
                                        JOptionPane.showMessageDialog(null, "Failed to create car, unknown reason!\n", "Car Maker", 1);
                                    }
                                }
                                catch(Exception exception8)
                                {
                                    carname = "";
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to create file! Error Deatials:\n").append(exception8).toString(), "Car Maker", 1);
                                }
                        } else
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error, ").append(file.getName()).append(" was not found!").toString(), "Car Maker", 1);
                        }
                        setCursor(new Cursor(0));
                    }
                }
                if(i == 1)
                {
                    sfase = 4;
                    i = -1;
                }
                if(i == 2)
                {
                    sfase = 0;
                    i = -1;
                }
            }
            if(sfase == 4)
            {
                if(i == 0)
                {
                    File file1 = null;
                    FileDialog filedialog1 = new FileDialog(new Frame(), "Car Maker - Wavefront OBJ Import");
                    filedialog1.setFile((new StringBuilder()).append("").append(carname).append(".obj").toString());
                    filedialog1.setMode(1);
                    filedialog1.setVisible(true);
                    try
                    {
                        if(filedialog1.getFile() != null)
                            file1 = new File((new StringBuilder()).append("").append(filedialog1.getDirectory()).append("").append(filedialog1.getFile()).append("").toString());
                    }
                    catch(Exception exception3) { }
                    if(file1 != null)
                    {
                        int i7 = 0;
                        if(file1.exists())
                            i7 = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("File ").append(file1.getName()).append(" already exists, replace it?      \n").toString(), "Car Maker", 0);
                        if(i7 == 0)
                        {
                            setCursor(new Cursor(3));
                            setupo();
                            int ai1[] = new int[6000];
                            int ai3[] = new int[6000];
                            int ai6[] = new int[6000];
                            int i19 = 0;
                            String s22 = "";
                            for(int i20 = 0; i20 < o.npl; i20++)
                            {
                                for(int j21 = 0; j21 < o.p[i20].n; j21++)
                                {
                                    boolean flag5 = false;
                                    for(int j23 = 0; j23 < i19; j23++)
                                        if(ai1[j23] == o.p[i20].ox[j21] && ai3[j23] == o.p[i20].oy[j21] && ai6[j23] == o.p[i20].oz[j21])
                                            flag5 = true;

                                    if(!flag5 && i19 < 6000)
                                    {
                                        ai1[i19] = o.p[i20].ox[j21];
                                        ai3[i19] = o.p[i20].oy[j21];
                                        ai6[i19] = o.p[i20].oz[j21];
                                        i19++;
                                    }
                                }

                            }

                            for(int j20 = 0; j20 < i19; j20++)
                                s22 = (new StringBuilder()).append(s22).append("v ").append((float)ai1[j20] / 10F).append(" ").append((float)(-ai3[j20]) / 10F).append(" ").append((float)ai6[j20] / 10F).append("\n").toString();

                            for(int k20 = 0; k20 < o.npl; k20++)
                            {
                                if(o.p[k20].wz != 0)
                                    continue;
                                s22 = (new StringBuilder()).append(s22).append("f").toString();
                                for(int k21 = 0; k21 < o.p[k20].n; k21++)
                                {
                                    s22 = (new StringBuilder()).append(s22).append(" ").toString();
                                    for(int i22 = 0; i22 < i19; i22++)
                                        if(ai1[i22] == o.p[k20].ox[k21] && ai3[i22] == o.p[k20].oy[k21] && ai6[i22] == o.p[k20].oz[k21])
                                            s22 = (new StringBuilder()).append(s22).append("").append(i22 + 1).toString();

                                }

                                s22 = (new StringBuilder()).append(s22).append("\n").toString();
                            }

                            try
                            {
                                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file1));
                                bufferedwriter.write(s22);
                                bufferedwriter.close();
                                bufferedwriter = null;
                                if(file1.exists())
                                {
                                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car has been successfully exported to:\n").append(file1.getAbsolutePath()).append("          \n \n").toString(), "Car Maker", 1);
                                    sfase = 0;
                                    hidefields();
                                    tabed = -1;
                                } else
                                {
                                    JOptionPane.showMessageDialog(null, "Failed to export car, unknown reason!\n", "Car Maker", 1);
                                }
                            }
                            catch(Exception exception6)
                            {
                                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to create exported file! Error Deatials:\n").append(exception6).toString(), "Car Maker", 1);
                            }
                            setCursor(new Cursor(0));
                        }
                    }
                }
                if(i == 1)
                {
                    sfase = 0;
                    i = -1;
                }
            }
        }
        if(tab == 1)
        {
            if(i == 0)
                if(prefs)
                    prefs = false;
                else
                    prefs = true;
            if(i == 1 || i == 2)
            {
                savefile();
                if(i == 2)
                    tab = 2;
            }
            if(!mirror)
            {
                boolean flag = false;
                if(i == 4)
                {
                    if(sls != -1 && sle != -1 && editor.getSelectedText().equals(srch.getText()))
                    {
                        editor.replaceText(rplc.getText(), sls, sle);
                        sls = -1;
                        sle = -1;
                        flag = true;
                        try
                        {
                            Thread _tmp = thredo;
                            Thread.sleep(100L);
                        }
                        catch(InterruptedException interruptedexception) { }
                    }
                    i = 3;
                }
                if(i == 3 && !srch.getText().equals(""))
                {
                    editor.requestFocus();
                    sls = editor.getText().indexOf(srch.getText(), editor.getSelectionEnd());
                    if(sls != -1)
                    {
                        sle = sls + srch.getText().length();
                        editor.select(sls, sle);
                    } else
                    if(!flag)
                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Cannot find  '").append(srch.getText()).append("'  from Cursor position    ").toString(), "Car Maker", 1);
                }
            } else
            {
                if(i == 3 || i == 4 || i == 5)
                {
                    String s = (new StringBuilder()).append("").append(editor.getSelectedText()).append("\n").toString();
                    String s1 = "\n\n";
                    if(cntpls == 1)
                        s1 = (new StringBuilder()).append(s1).append("// Mirror of the polygon above along the ").toString();
                    else
                        s1 = (new StringBuilder()).append(s1).append("// Mirror of the ").append(cntpls).append(" polygons above along the ").toString();
                    if(i == 3)
                        s1 = (new StringBuilder()).append(s1).append("X axis:").toString();
                    if(i == 4)
                        s1 = (new StringBuilder()).append(s1).append("Y axis:").toString();
                    if(i == 5)
                        s1 = (new StringBuilder()).append(s1).append("Z axis:").toString();
                    s1 = (new StringBuilder()).append(s1).append("\n\n").toString();
                    int j7 = 0;
                    String s13;
                    for(int j11 = s.indexOf("\n", 0); j11 != -1 && j7 < s.length(); s1 = (new StringBuilder()).append(s1).append("").append(s13).append("\n").toString())
                    {
                        s13 = s.substring(j7, j11);
                        s13 = s13.trim();
                        j7 = j11 + 1;
                        j11 = s.indexOf("\n", j7);
                        if(s13.startsWith("fs(-"))
                            s13 = (new StringBuilder()).append("fs(").append(s13.substring(4, s13.length())).append("").toString();
                        else
                        if(s13.startsWith("fs("))
                            s13 = (new StringBuilder()).append("fs(-").append(s13.substring(3, s13.length())).append("").toString();
                        if(i == 3)
                            if(s13.startsWith("p(-"))
                                s13 = (new StringBuilder()).append("p(").append(s13.substring(3, s13.length())).append("").toString();
                            else
                            if(s13.startsWith("p("))
                                s13 = (new StringBuilder()).append("p(-").append(s13.substring(2, s13.length())).append("").toString();
                        if(i == 4 && s13.startsWith("p("))
                        {
                            int j17 = s13.indexOf(",", 0);
                            if(j17 >= 0)
                                if(s13.startsWith(",-", j17))
                                    s13 = (new StringBuilder()).append("").append(s13.substring(0, j17)).append(",").append(s13.substring(j17 + 2, s13.length())).append("").toString();
                                else
                                if(s13.startsWith(",", j17))
                                    s13 = (new StringBuilder()).append("").append(s13.substring(0, j17)).append(",-").append(s13.substring(j17 + 1, s13.length())).append("").toString();
                        }
                        if(i != 5 || !s13.startsWith("p("))
                            continue;
                        int k17 = s13.indexOf(",", 0);
                        k17 = s13.indexOf(",", k17 + 1);
                        if(k17 < 0)
                            continue;
                        if(s13.startsWith(",-", k17))
                        {
                            s13 = (new StringBuilder()).append("").append(s13.substring(0, k17)).append(",").append(s13.substring(k17 + 2, s13.length())).append("").toString();
                            continue;
                        }
                        if(s13.startsWith(",", k17))
                            s13 = (new StringBuilder()).append("").append(s13.substring(0, k17)).append(",-").append(s13.substring(k17 + 1, s13.length())).append("").toString();
                    }

                    s1 = (new StringBuilder()).append(s1).append("\n// End of mirror").toString();
                    editor.insertText(s1, editor.getSelectionEnd());
                }
                if(i == 6)
                {
                    polynum = 0;
                    int k = editor.getText().lastIndexOf("</p>", editor.getSelectionStart());
                    boolean flag1 = false;
                    for(; k >= 0; k--)
                    {
                        if(!flag1)
                        {
                            k = editor.getText().lastIndexOf("<p>", k);
                            if(k != -1)
                            {
                                flag1 = true;
                                polynum++;
                            }
                            continue;
                        }
                        k = editor.getText().lastIndexOf("</p>", k);
                        if(k != -1)
                            flag1 = false;
                    }

                    prflk = 0;
                    tab = 2;
                }
            }
            i = -1;
        }
        if(tab == 2)
        {
            byte byte0 = 0;
            if(dtab == 1)
                if(o.colok != 2)
                {
                    if(i == 0)
                    {
                        JOptionPane.showMessageDialog(null, "Car Maker will attempt now to find the first and second colors automatically.\nPlease make sure that they are the correct colors!\n\nPlease note that these are also the colors that will be editable in the multiplayer game.      ", "Car Maker", 1);
                        String s2 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        int k7 = 0;
                        int k11 = s2.indexOf("\n", 0);
                        int j15 = 0;
                        String s15 = "";
                        String s19 = "";
                        do
                        {
                            if(k11 == -1 || k7 >= s2.length() || j15 == 2)
                                break;
                            String s23 = s2.substring(k7, k11);
                            s23 = s23.trim();
                            k7 = k11 + 1;
                            k11 = s2.indexOf("\n", k7);
                            if(s23.startsWith("c("))
                            {
                                String s24 = s23.substring(1, s23.indexOf(")") + 1);
                                if(j15 == 1 && !s24.equals(s19))
                                {
                                    s15 = (new StringBuilder()).append(s15).append("2ndColor").append(s24).append("\n\n\n").toString();
                                    j15 = 2;
                                }
                                if(j15 == 0)
                                {
                                    s19 = s24;
                                    s15 = (new StringBuilder()).append("1stColor").append(s24).append("\n").toString();
                                    j15 = 1;
                                }
                            }
                        } while(true);
                        if(j15 == 0)
                        {
                            s15 = "1stColor(255,0,0)\n2ndColor(0,0,255)\n\n\n";
                            j15 = 2;
                        }
                        if(j15 == 1)
                        {
                            s15 = (new StringBuilder()).append(s15).append("2ndColor(0,0,255)\n\n\n").toString();
                            byte byte3 = 2;
                        }
                        int k19 = editor.getText().indexOf("<p>", 0);
                        editor.insertText(s15, k19);
                        editor.select(k19, (k19 + s15.length()) - 2);
                        breakbond = true;
                        tab = 1;
                    }
                    byte0 = 1;
                } else
                {
                    if(i == 0)
                    {
                        ofcol = (new StringBuilder()).append("(").append(o.fcol[0]).append(",").append(o.fcol[1]).append(",").append(o.fcol[2]).append(")").toString();
                        int j1 = editor.getText().indexOf(ofcol, 0);
                        int l7 = j1;
                        for(; j1 != -1; j1 = editor.getText().indexOf(ofcol, j1 + 1))
                            editor.replaceText(fcol, j1, j1 + ofcol.length());

                        ofcol = fcol;
                        editor.select(l7 - 8, l7 - 8);
                        savefile();
                        o.fcol[0] = Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getRed();
                        o.fcol[1] = Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getGreen();
                        o.fcol[2] = Color.getHSBColor(fhsb[0], fhsb[2], fhsb[1]).getBlue();
                    }
                    if(i == 1)
                    {
                        oscol = (new StringBuilder()).append("(").append(o.scol[0]).append(",").append(o.scol[1]).append(",").append(o.scol[2]).append(")").toString();
                        int k1 = editor.getText().indexOf(oscol, 0);
                        int i8 = k1;
                        for(; k1 != -1; k1 = editor.getText().indexOf(oscol, k1 + 1))
                            editor.replaceText(scol, k1, k1 + oscol.length());

                        oscol = scol;
                        editor.select(i8 - 8, i8 - 8);
                        savefile();
                        o.scol[0] = Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getRed();
                        o.scol[1] = Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getGreen();
                        o.scol[2] = Color.getHSBColor(shsb[0], shsb[2], shsb[1]).getBlue();
                    }
                    byte0 = 2;
                }
            if(dtab == 2)
            {
                if(i == 9)
                {
                    scale[0] = 100;
                    scale[1] = 100;
                    scale[2] = 100;
                }
                if(i == 0 || i == 1 || i == 6 || i == 7 || i == 9)
                {
                    if(i == 0 || i == 6)
                        scale[0] -= 5;
                    if(i == 1 || i == 7)
                        scale[0] += 5;
                    if(scale[0] < 0)
                        scale[0] = 0;
                    int l1 = editor.getText().indexOf("\nScaleX(", 0);
                    if(l1 != -1)
                    {
                        l1++;
                        int j8 = editor.getText().indexOf(")", l1);
                        int l11 = editor.getText().indexOf("\n", l1);
                        if(l11 > j8)
                            editor.replaceText((new StringBuilder()).append("ScaleX(").append(scale[0]).append(")").toString(), l1, j8 + 1);
                        else
                            editor.replaceText((new StringBuilder()).append("ScaleX(").append(scale[0]).append(")").toString(), l1, l11);
                    } else
                    {
                        int k8 = editor.getText().indexOf("<p>", 0);
                        int i12 = editor.getText().indexOf("\nScale", 0);
                        if(i12 < k8 && i12 != -1)
                            editor.insertText((new StringBuilder()).append("\nScaleX(").append(scale[0]).append(")").toString(), i12);
                        else
                            editor.insertText((new StringBuilder()).append("ScaleX(").append(scale[0]).append(")\n\n\n").toString(), k8);
                    }
                }
                if(i == 2 || i == 3 || i == 6 || i == 7 || i == 9)
                {
                    if(i == 2 || i == 6)
                        scale[1] -= 5;
                    if(i == 3 || i == 7)
                        scale[1] += 5;
                    if(scale[1] < 0)
                        scale[1] = 0;
                    int i2 = editor.getText().indexOf("\nScaleY(", 0);
                    if(i2 != -1)
                    {
                        i2++;
                        int l8 = editor.getText().indexOf(")", i2);
                        int j12 = editor.getText().indexOf("\n", i2);
                        if(j12 > l8)
                            editor.replaceText((new StringBuilder()).append("ScaleY(").append(scale[1]).append(")").toString(), i2, l8 + 1);
                        else
                            editor.replaceText((new StringBuilder()).append("ScaleY(").append(scale[1]).append(")").toString(), i2, j12);
                    } else
                    {
                        int i9 = editor.getText().indexOf("<p>", 0);
                        int k12 = editor.getText().indexOf("\nScale", 0);
                        if(k12 < i9 && k12 != -1)
                            editor.insertText((new StringBuilder()).append("\nScaleY(").append(scale[1]).append(")").toString(), k12);
                        else
                            editor.insertText((new StringBuilder()).append("ScaleY(").append(scale[1]).append(")\n\n\n").toString(), i9);
                    }
                }
                if(i == 4 || i == 5 || i == 6 || i == 7 || i == 9)
                {
                    if(i == 4 || i == 6)
                        scale[2] -= 5;
                    if(i == 5 || i == 7)
                        scale[2] += 5;
                    if(scale[2] < 0)
                        scale[2] = 0;
                    int j2 = editor.getText().indexOf("\nScaleZ(", 0);
                    if(j2 != -1)
                    {
                        j2++;
                        int j9 = editor.getText().indexOf(")", j2);
                        int l12 = editor.getText().indexOf("\n", j2);
                        if(l12 > j9)
                            editor.replaceText((new StringBuilder()).append("ScaleZ(").append(scale[2]).append(")").toString(), j2, j9 + 1);
                        else
                            editor.replaceText((new StringBuilder()).append("ScaleZ(").append(scale[2]).append(")").toString(), j2, l12);
                    } else
                    {
                        int k9 = editor.getText().indexOf("<p>", 0);
                        int i13 = editor.getText().indexOf("\nScale", 0);
                        if(i13 < k9 && i13 != -1)
                            editor.insertText((new StringBuilder()).append("\nScaleZ(").append(scale[2]).append(")").toString(), i13);
                        else
                            editor.insertText((new StringBuilder()).append("ScaleZ(").append(scale[2]).append(")\n\n\n").toString(), k9);
                    }
                }
                if(i == 0 || i == 1 || i == 2 || i == 3 || i == 4 || i == 5 || i == 6 || i == 7 || i == 9)
                    setupo();
                if(i == 8)
                {
                    savefile();
                    oscale[0] = scale[0];
                    oscale[1] = scale[1];
                    oscale[2] = scale[2];
                }
                if(i == 10 || i == 11 || i == 12 || i == 13 || i == 14 || i == 15 || i == 16 || i == 17 || i == 18)
                    try
                    {
                        String s3 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        String s6 = "";
                        int j13 = 0;
                        for(int k15 = s3.indexOf("\n", 0); k15 != -1 && j13 < s3.length();)
                        {
                            String s16 = s3.substring(j13, k15);
                            s16 = s16.trim();
                            j13 = k15 + 1;
                            k15 = s3.indexOf("\n", j13);
                            if(s16.startsWith("p("))
                            {
                                int j19 = s16.indexOf(",", 0);
                                int l19 = s16.indexOf(",", j19 + 1);
                                int l20 = s16.indexOf(")", l19 + 1);
                                if(j19 != -1 && l19 != -1 && l20 != -1)
                                {
                                    int l21 = Float.valueOf(s16.substring(2, j19)).intValue();
                                    int j22 = Float.valueOf(s16.substring(j19 + 1, l19)).intValue();
                                    int k23 = Float.valueOf(s16.substring(l19 + 1, l20)).intValue();
                                    if(i == 10)
                                    {
                                        int i24 = j22;
                                        j22 = k23;
                                        k23 = -i24;
                                    }
                                    if(i == 11)
                                        l21 += 10;
                                    if(i == 12)
                                        l21 -= 10;
                                    if(i == 13)
                                    {
                                        int j24 = l21;
                                        l21 = -k23;
                                        k23 = j24;
                                    }
                                    if(i == 14)
                                        j22 += 10;
                                    if(i == 15)
                                        j22 -= 10;
                                    if(i == 16)
                                    {
                                        int k24 = j22;
                                        j22 = -l21;
                                        l21 = k24;
                                    }
                                    if(i == 17)
                                        k23 += 10;
                                    if(i == 18)
                                        k23 -= 10;
                                    s6 = (new StringBuilder()).append(s6).append("p(").append(l21).append(",").append(j22).append(",").append(k23).append(")").append(s16.substring(l20 + 1, s16.length())).append("\n").toString();
                                } else
                                {
                                    s6 = (new StringBuilder()).append(s6).append("").append(s16).append("\n").toString();
                                }
                            } else
                            {
                                s6 = (new StringBuilder()).append(s6).append("").append(s16).append("\n").toString();
                            }
                        }

                        editor.setText(s6);
                        setupo();
                        changed2 = true;
                    }
                    catch(Exception exception) { }
                if(i == 19)
                {
                    editor.setText(lastedo);
                    setupo();
                    changed2 = false;
                }
                if(i == 20 && changed2)
                {
                    int k2 = JOptionPane.showConfirmDialog(null, "Saving now will permanently change the point locations & numbers entered in the code!      \n\nContinue?", "Car Maker", 0);
                    if(k2 == 0)
                    {
                        editor.setText((new StringBuilder()).append(editor.getText().trim()).append("\n\n\n\n").toString());
                        savefile();
                        changed2 = false;
                    }
                }
                byte0 = 21;
            }
            if(dtab == 3)
            {
                if(i == 0 || i == 2 || defnow)
                {
                    if(defnow)
                    {
                        defnow = false;
                        repaint();
                        JOptionPane.showMessageDialog(null, "Car Maker will setup default Front and Back Wheels positions and adjustments.\n\nEnter the desired positions and adjustments then press ' Apply ' to view!\nDon't forget to press ' Save ' when finished!", "Car Maker", 1);
                    }
                    byte byte1 = 0;
                    try
                    {
                        int l9 = Float.valueOf(wv[10].getText()).intValue();
                        if(l9 <= 0)
                            byte1 = 1;
                        l9 = Float.valueOf(wv[2].getText()).intValue();
                        if(l9 >= 0)
                            byte1 = 2;
                        l9 = Float.valueOf(wv[8].getText()).intValue();
                        if(l9 <= 0)
                            byte1 = 3;
                        l9 = Float.valueOf(wv[0].getText()).intValue();
                        if(l9 <= 0)
                            byte1 = 4;
                        l9 = Float.valueOf(wv[15].getText()).intValue();
                        if(l9 > 40)
                            wv[15].setText("40");
                        if(l9 < -40)
                            wv[15].setText("-40");
                        l9 = Float.valueOf(wv[7].getText()).intValue();
                        if(l9 > 40)
                            wv[7].setText("40");
                        if(l9 < -40)
                            wv[7].setText("-40");
                    }
                    catch(Exception exception4) { }
                    if(byte1 == 1)
                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("ERROR:\nThe Z location value of the FRONT Wheels must be greater then zero! (it should have a +ve value)\nZ :  '").append(wv[10].getText()).append("'  is less or equal to zero, where it should have +ve value!").toString(), "Car Maker", 1);
                    if(byte1 == 2)
                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("ERROR:\nThe Z location value of the BACK Wheels must be smaller then zero! (it should have a -ve value)\nZ :  '").append(wv[2].getText()).append("'  is bigger or equal to zero, where it should have -ve value!").toString(), "Car Maker", 1);
                    if(byte1 == 3)
                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("ERROR:\nThe \261X location value of the FRONT or BACK Wheels must be greater then zero! (it should have a +ve value)\n\261X :  '").append(wv[8].getText()).append("'  is less or equal to zero, where it should have +ve value!").toString(), "Car Maker", 1);
                    if(byte1 == 4)
                        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("ERROR:\nThe \261X location value of the FRONT or BACK Wheels must be greater then zero! (it should have a +ve value)\n\261X :  '").append(wv[0].getText()).append("'  is less or equal to zero, whenr it should have +ve value!").toString(), "Car Maker", 1);
                    if(byte1 == 0)
                    {
                        String s7 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        String s12 = "";
                        int l15 = 0;
                        for(int l17 = s7.indexOf("\n", 0); l17 != -1 && l15 < s7.length();)
                        {
                            String s20 = s7.substring(l15, l17);
                            s20 = s20.trim();
                            l15 = l17 + 1;
                            l17 = s7.indexOf("\n", l15);
                            if(!s20.startsWith("rims(") && !s20.startsWith("gwgr(") && !s20.startsWith("w("))
                            {
                                s12 = (new StringBuilder()).append(s12).append("").append(s20).append("\n").toString();
                            } else
                            {
                                s12 = s12.trim();
                                s12 = (new StringBuilder()).append(s12).append("\n").toString();
                            }
                        }

                        s12 = s12.trim();
                        s12 = (new StringBuilder()).append(s12).append("\n\n\ngwgr(").append(wv[15].getText()).append(")\n").toString();
                        String s21 = "140,140,140";
                        if(rplc.getText().startsWith("(") && rplc.getText().endsWith(")"))
                            s21 = rplc.getText().substring(1, rplc.getText().length() - 1);
                        s12 = (new StringBuilder()).append(s12).append("rims(").append(s21).append(",").append(wv[13].getText()).append(",").append(wv[14].getText()).append(")\n").toString();
                        s12 = (new StringBuilder()).append(s12).append("w(-").append(wv[8].getText()).append(",").append(wv[9].getText()).append(",").append(wv[10].getText()).append(",11,").append(wv[12].getText()).append(",").append(wv[11].getText()).append(")\n").toString();
                        s12 = (new StringBuilder()).append(s12).append("w(").append(wv[8].getText()).append(",").append(wv[9].getText()).append(",").append(wv[10].getText()).append(",11,-").append(wv[12].getText()).append(",").append(wv[11].getText()).append(")\n").toString();
                        s12 = (new StringBuilder()).append(s12).append("\ngwgr(").append(wv[7].getText()).append(")\n").toString();
                        s21 = "140,140,140";
                        if(srch.getText().startsWith("(") && srch.getText().endsWith(")"))
                            s21 = srch.getText().substring(1, srch.getText().length() - 1);
                        s12 = (new StringBuilder()).append(s12).append("rims(").append(s21).append(",").append(wv[5].getText()).append(",").append(wv[6].getText()).append(")\n").toString();
                        s12 = (new StringBuilder()).append(s12).append("w(-").append(wv[0].getText()).append(",").append(wv[1].getText()).append(",").append(wv[2].getText()).append(",0,").append(wv[4].getText()).append(",").append(wv[3].getText()).append(")\n").toString();
                        s12 = (new StringBuilder()).append(s12).append("w(").append(wv[0].getText()).append(",").append(wv[1].getText()).append(",").append(wv[2].getText()).append(",0,-").append(wv[4].getText()).append(",").append(wv[3].getText()).append(")\n\n\n\n").toString();
                        editor.setText(s12);
                        forwheels = true;
                        setupo();
                        forwheels = false;
                        aply1 = (new StringBuilder()).append("").append(wv[0].getText()).append("").append(wv[1].getText()).append("").append(wv[2].getText()).append("").append(wv[3].getText()).append("").append(wv[4].getText()).append("").append(srch.getText()).append("").append(wv[5].getText()).append("").append(wv[6].getText()).append("").append(wv[7].getText()).append("").toString();
                        aply2 = (new StringBuilder()).append("").append(wv[8].getText()).append("").append(wv[9].getText()).append("").append(wv[10].getText()).append("").append(wv[11].getText()).append("").append(wv[12].getText()).append("").append(rplc.getText()).append("").append(wv[13].getText()).append("").append(wv[14].getText()).append("").append(wv[15].getText()).append("").toString();
                        aplyd1 = false;
                        aplyd2 = false;
                        changed2 = true;
                    }
                }
                if(i == 1 || i == 3)
                    if(!o.errd)
                    {
                        savefile();
                        changed2 = false;
                    } else
                    {
                        JOptionPane.showMessageDialog(null, "Unable to Save, press  [ Apply ]  to find out why!", "Car Maker", 1);
                    }
                byte0 = 4;
            }
            if(dtab == 4)
                if(!statdef)
                {
                    if(i == 0)
                    {
                        carsel = simcar.getSelectedIndex();
                        int l2 = 0;
                        for(int i10 = 0; i10 < 5; i10++)
                        {
                            stat[i10] = carstat[carsel][i10];
                            rstat[i10] = stat[i10];
                            l2 += stat[i10];
                        }

                        clsel = 4 - (l2 - 520) / 40;
                        cls.select(clsel);
                        if(simcar.getItemCount() == 16)
                            simcar.add(rd, "   ");
                        statdef = true;
                        changed2 = true;
                    }
                    byte0 = 1;
                } else
                {
                    for(int i3 = 0; i3 < 5; i3++)
                    {
                        int j10 = 0;
                        if(i == 1 + i3 * 2 && stat[i3] < 200)
                        {
                            j10 = 200 - stat[i3];
                            if(j10 > 4)
                                j10 = 4;
                        }
                        if(i == i3 * 2 && stat[i3] > 16)
                        {
                            j10 = 16 - stat[i3];
                            if(j10 < -4)
                                j10 = -4;
                        }
                        for(int k13 = 0; j10 != 0 && k13 != 5;)
                        {
                            k13 = 0;
                            int i16 = 0;
                            while(i16 < 5) 
                            {
                                if(i3 != i16 && (stat[i16] <= 200 || j10 > 0) && (stat[i16] >= 16 || j10 < 0) && j10 != 0)
                                {
                                    if(j10 > 0)
                                    {
                                        stat[i3]++;
                                        stat[i16]--;
                                        j10--;
                                    } else
                                    {
                                        stat[i3]--;
                                        stat[i16]++;
                                        j10++;
                                    }
                                } else
                                {
                                    k13++;
                                }
                                i16++;
                            }
                        }

                    }

                    if(i == 10)
                    {
                        carsel = simcar.getSelectedIndex();
                        int j3 = 0;
                        for(int k10 = 0; k10 < 5; k10++)
                        {
                            stat[k10] = carstat[carsel][k10];
                            j3 += stat[k10];
                        }

                        clsel = 4 - (j3 - 520) / 40;
                        cls.select(clsel);
                    }
                    if(i == 11)
                    {
                        String s4 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        String s8 = "";
                        int l13 = 0;
                        for(int j16 = s4.indexOf("\n", 0); j16 != -1 && l13 < s4.length();)
                        {
                            String s17 = s4.substring(l13, j16);
                            s17 = s17.trim();
                            l13 = j16 + 1;
                            j16 = s4.indexOf("\n", l13);
                            if(!s17.startsWith("stat("))
                            {
                                s8 = (new StringBuilder()).append(s8).append("").append(s17).append("\n").toString();
                            } else
                            {
                                s8 = s8.trim();
                                s8 = (new StringBuilder()).append(s8).append("\n").toString();
                            }
                        }

                        s8 = s8.trim();
                        s8 = (new StringBuilder()).append(s8).append("\n\n\nstat(").append(stat[0]).append(",").append(stat[1]).append(",").append(stat[2]).append(",").append(stat[3]).append(",").append(stat[4]).append(")\n\n\n\n").toString();
                        editor.setText(s8);
                        savefile();
                        for(int i18 = 0; i18 < 5; i18++)
                            rstat[i18] = stat[i18];

                        changed2 = false;
                    }
                    if(i == 12)
                    {
                        for(int k3 = 0; k3 < 5; k3++)
                            stat[k3] = rstat[k3];

                    }
                    byte0 = 13;
                }
            if(dtab == 5)
            {
                if(pfase == 0)
                {
                    for(int l3 = 0; l3 < 4; l3++)
                    {
                        if(i == 1 + l3 * 2)
                        {
                            phys[l3] += 2;
                            if(phys[l3] > 100)
                                phys[l3] = 100;
                        }
                        if(i != l3 * 2)
                            continue;
                        phys[l3] -= 2;
                        if(phys[l3] < 0)
                            phys[l3] = 0;
                    }

                    if(i == 8)
                    {
                        for(int i4 = 0; i4 < 5; i4++)
                            phys[i4] = (int)(Math.random() * 100D);

                    }
                    if(i == 9)
                    {
                        for(int j4 = 0; j4 < 5; j4++)
                            phys[j4] = rphys[j4];

                    }
                    if(i == 10)
                    {
                        pfase = 1;
                        i = -1;
                    }
                    byte0 = 11;
                }
                if(pfase == 1)
                {
                    for(int k4 = 0; k4 < 6; k4++)
                    {
                        if(i == 1 + k4 * 2)
                        {
                            phys[k4 + 5] += 2;
                            if(phys[k4 + 5] > 100)
                                phys[k4 + 5] = 100;
                        }
                        if(i != k4 * 2)
                            continue;
                        phys[k4 + 5] -= 2;
                        if(phys[k4 + 5] < 0)
                            phys[k4 + 5] = 0;
                    }

                    if(i == 12)
                    {
                        for(int l4 = 0; l4 < 6; l4++)
                            phys[l4 + 5] = (int)(Math.random() * 100D);

                    }
                    if(i == 13)
                    {
                        for(int i5 = 0; i5 < 6; i5++)
                            phys[i5 + 5] = rphys[i5 + 5];

                    }
                    if(i == 14)
                    {
                        pfase = 0;
                        i = -1;
                    }
                    if(i == 15)
                    {
                        pfase = 2;
                        i = -1;
                    }
                    byte0 = 16;
                }
                if(pfase == 2)
                {
                    for(int j5 = 0; j5 < 3; j5++)
                    {
                        if(i == 1 + j5 * 2)
                        {
                            crash[j5] += 2;
                            if(crash[j5] > 100)
                                crash[j5] = 100;
                        }
                        if(i != j5 * 2)
                            continue;
                        crash[j5] -= 2;
                        if(crash[j5] < 0)
                            crash[j5] = 0;
                    }

                    if(i == 6)
                    {
                        int k5 = (int)(150D + 600D * Math.random());
                        boolean flag2 = false;
                        boolean flag3 = false;
                        if(Math.random() > Math.random())
                            flag2 = true;
                        if(Math.random() > Math.random())
                            flag3 = true;
                        int ai4[] = {
                            -101, -101, -101, -101
                        };
                        ai4[0] = (int)(Math.random() * 4D);
                        if(Math.random() > Math.random())
                        {
                            if(flag3)
                                ai4[1] = ai4[0] + 1;
                            else
                                ai4[1] = ai4[0] - 1;
                            if(Math.random() > Math.random())
                            {
                                if(flag3)
                                    ai4[2] = ai4[1] + 1;
                                else
                                    ai4[2] = ai4[1] - 1;
                                if(Math.random() > Math.random())
                                    if(flag3)
                                        ai4[3] = ai4[2] + 1;
                                    else
                                        ai4[3] = ai4[2] - 1;
                            }
                        }
                        if(Math.random() > Math.random())
                            crashup = false;
                        else
                            crashup = true;
                        for(int j18 = 0; j18 < 4; j18++)
                        {
                            if(ai4[j18] == -101)
                                continue;
                            if(ai4[j18] >= 4)
                                ai4[j18] -= 4;
                            if(ai4[j18] <= -1)
                                ai4[j18] += 4;
                            k5 -= 50 * j18;
                            if(k5 < 150)
                                k5 = 150;
                            if(flag2)
                                regx(ai4[j18], k5, false);
                            else
                                regz(ai4[j18], k5, false);
                        }

                        if(hitmag < 17000)
                            if(crashleft)
                                o.xz += 22;
                            else
                                o.xz -= 22;
                    }
                    if(i == 8)
                    {
                        if(Math.random() > Math.random())
                            crashup = false;
                        else
                            crashup = true;
                        roofsqsh((int)(230D + Math.random() * 80D));
                    }
                    if(i == 9 || i == 7)
                    {
                        setupo();
                        if(Math.random() > Math.random())
                            crashleft = false;
                        else
                            crashleft = true;
                    }
                    if(i == 10)
                    {
                        for(int l5 = 0; l5 < 3; l5++)
                            crash[l5] = rcrash[l5];

                    }
                    if(i == 11)
                    {
                        setupo();
                        pfase = 1;
                        i = -1;
                    }
                    if(i == 12)
                        if(crashok)
                        {
                            setupo();
                            pfase = 3;
                            i = -1;
                        } else
                        {
                            JOptionPane.showMessageDialog(null, usage[11], "Car Maker", 1);
                        }
                    byte0 = 13;
                }
                if(pfase == 3)
                {
                    for(int i6 = 0; i6 < 5; i6++)
                    {
                        if(i == i6)
                        {
                            for(int l10 = 0; l10 < 5; l10++)
                            {
                                for(int i14 = 0; i14 < 5; i14++)
                                    engs[i14][l10].stop();

                            }

                            engs[engsel][i6].loop();
                            engon = true;
                        }
                        if(i == 5)
                        {
                            for(int i11 = 0; i11 < 5; i11++)
                            {
                                for(int j14 = 0; j14 < 5; j14++)
                                    engs[j14][i11].stop();

                            }

                            engon = false;
                        }
                        if(i == 6)
                        {
                            pfase = 2;
                            i = -1;
                            engine.hide();
                        }
                        if(i == 7)
                        {
                            pfase = 4;
                            i = -1;
                            engine.hide();
                        }
                    }

                    byte0 = 8;
                }
            }
            if(dtab == 6)
                if(!rateh)
                {
                    if(i == 0 && checko("Test Drive"))
                    {
                        Madness.testcar = carname;
                        Madness.testdrive = witho.getSelectedIndex() + 1;
                        Madness.game();
                    }
                    byte0 = 1;
                    if(tested)
                    {
                        if(i == 1)
                        {
                            dtab = 4;
                            i = -1;
                        }
                        if(i == 2)
                        {
                            dtab = 5;
                            i = -1;
                        }
                        if(i == 3)
                        {
                            rateh = true;
                            hidefields();
                        }
                        byte0 = 4;
                    }
                } else
                {
                    if(i == 0)
                    {
                        handling -= 2;
                        if(handling < 50)
                            handling = 50;
                    }
                    if(i == 1)
                    {
                        handling += 2;
                        if(handling > 200)
                            handling = 200;
                    }
                    if(i == 2)
                    {
                        String s5 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        String s9 = "";
                        int k14 = 0;
                        for(int k16 = s5.indexOf("\n", 0); k16 != -1 && k14 < s5.length();)
                        {
                            String s18 = s5.substring(k14, k16);
                            s18 = s18.trim();
                            k14 = k16 + 1;
                            k16 = s5.indexOf("\n", k14);
                            if(!s18.startsWith("handling("))
                            {
                                s9 = (new StringBuilder()).append(s9).append("").append(s18).append("\n").toString();
                            } else
                            {
                                s9 = s9.trim();
                                s9 = (new StringBuilder()).append(s9).append("\n").toString();
                            }
                        }

                        s9 = s9.trim();
                        s9 = (new StringBuilder()).append(s9).append("\n\n\nhandling(").append(handling).append(")\n\n\n\n").toString();
                        editor.setText(s9);
                        savefile();
                        rateh = false;
                    }
                    if(i == 3)
                        rateh = false;
                    byte0 = 4;
                }
            if(i == byte0)
            {
                for(int j6 = 0; j6 < o.npl; j6++)
                {
                    Color.RGBtoHSB(o.p[j6].c[0], o.p[j6].c[1], o.p[j6].c[2], o.p[j6].hsb);
                    if(o.p[j6].gr == -13)
                        o.p[j6].gr = 1;
                }

                polynum = -1;
            }
            i = -1;
        }
        if(tab == 3)
        {
            if(i == 0)
            {
                if(logged == 0)
                    JOptionPane.showMessageDialog(null, "Please login to retrieve your account first before publishing!", "Car Maker", 1);
                if((logged == 3 || logged == -1) && checko("Publishing"))
                {
                    int l = 0;
                    for(int k6 = 0; k6 < pubitem.no; k6++)
                        if(pubitem.opts[k6].equals(carname))
                            l = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Replace your already online car '").append(carname).append("' with this one?").toString(), "Car Maker", 0);

                    if(l == 0)
                    {
                        setCursor(new Cursor(3));
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(225, 225, 225));
                        rd.fillRect(11, 141, 679, 401);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Connecting to Server...", 350 - ftm.stringWidth("Connecting to Server...") / 2, 250);
                        repaint();
                        int l6 = 0;
                        String s10 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                        int l14 = 0;
                        for(int l16 = s10.indexOf("\n", 0); l16 != -1 && l14 < s10.length();)
                        {
                            l14 = l16 + 1;
                            l16 = s10.indexOf("\n", l14);
                            l6++;
                        }

                        justpubd = carname;
                        int k18 = -1;
                        try
                        {
                            Socket socket1 = new Socket("multiplayer.needformadness.com", 7061);
                            BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
                            PrintWriter printwriter1 = new PrintWriter(socket1.getOutputStream(), true);
                            printwriter1.println((new StringBuilder()).append("10|").append(tnick.getText()).append("|").append(tpass.getText()).append("|").append(carname).append("|").append(pubtyp.getSelectedIndex()).append("|").toString());
                            String s25 = bufferedreader1.readLine();
                            if(s25 != null)
                                k18 = servervalue(s25, 0);
                            if(k18 == 0)
                            {
                                int k22 = 0;
                                String s11 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
                                int i15 = 0;
                                for(int i17 = s11.indexOf("\n", 0); i17 != -1 && i15 < s11.length();)
                                {
                                    String s29 = s11.substring(i15, i17);
                                    s29 = s29.trim();
                                    printwriter1.println(s29);
                                    i15 = i17 + 1;
                                    i17 = s11.indexOf("\n", i15);
                                    k22++;
                                    rd.setColor(new Color(225, 225, 225));
                                    rd.fillRect(11, 141, 679, 401);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("Publishing Car...", 350 - ftm.stringWidth("Publishing Car...") / 2, 250);
                                    rd.setColor(new Color(119, 147, 191));
                                    rd.fillRect(250, 270, (int)(((float)k22 / (float)l6) * 200F), 7);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawRect(250, 270, 200, 7);
                                    repaint();
                                    try
                                    {
                                        Thread _tmp1 = thredo;
                                        Thread.sleep(10L);
                                    }
                                    catch(InterruptedException interruptedexception1) { }
                                }

                                printwriter1.println("QUITX1111");
                                rd.setColor(new Color(225, 225, 225));
                                rd.fillRect(11, 141, 679, 401);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString("Creating the car online...", 350 - ftm.stringWidth("Creating the car online...") / 2, 250);
                                rd.drawString("This may take a couple of minutes, please wait...", 350 - ftm.stringWidth("This may take a couple of minutes, please wait...") / 2, 280);
                                repaint();
                                String s26 = bufferedreader1.readLine();
                                if(s26 != null)
                                    k18 = servervalue(s26, 0);
                            }
                            socket1.close();
                        }
                        catch(Exception exception5)
                        {
                            k18 = -1;
                        }
                        setCursor(new Cursor(0));
                        boolean flag4 = false;
                        if(k18 == 0)
                        {
                            logged = 1;
                            flag4 = true;
                        }
                        if(k18 == 3)
                        {
                            JOptionPane.showMessageDialog(null, "Unable to publish car.\nReason:\nCar name is too large.  Please rename your car.  Car name must be less then 15 characters.", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 4)
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to publish car.\nReason:  Car name used (").append(carname).append(").\nThe name '").append(carname).append("' is already used by another published car.  Please rename your car.").toString(), "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 6)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nError loading 3D model!  Format maybe incorrect!", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 7)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nFirst and Second colors not defined yet!\nPlease go to the 'Color Edit' tab to define the colors.", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 8)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nCar Wheels not defined or not defined correctly!\nPlease go to the \u2018Wheels\u2019 tab and use  [ Apply ]  and  [ Save ]  to define correctly.", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 9)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nNo car seems to be designed!\nYou have not built a car yet please go to the \u2018Car\u2019 tab to find the tutorial on how to build a car.", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 10)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nCar contains too many polygons (pieces).\nNumber of polygons used need to be less then 210.\nPlease use the counter in the \u2018Code Edit\u2019 to decrease the number of polygons (pieces).", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 11)
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error Creating Car!\nReason:\nCar scale size is too large!\nPlease use the \u2018Scale All\u2019 option in the \u2018Scale & Align\u2019 tab to resize your car to suitable size.       \nCompare it to other NFM cars using the \u2018Compare Car...\u2019 option.\nCurrently you car needs to be scaled down by ").append((int)(((float)o.maxR / 400F - 1.0F) * 100F)).append("%.\n").toString(), "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 12)
                        {
                            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Error Creating Car!\nReason:\nCar scale size is too small!\nPlease use the \u2018Scale All\u2019 option in the \u2018Scale & Align\u2019 tab to resize your car to suitable size.       \nCompare it to other NFM cars using the \u2018Compare Car...\u2019 option.\nCurrently you car needs to be scaled up by ").append((int)((120F / (float)o.maxR - 1.0F) * 100F)).append("%.\n").toString(), "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 13)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nCar Stats & Class not defined correctly!\nPlease go to the 'Stats & Class' tab to define stats and don't forget to press  [ Save ]  when finished.\n", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 14)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nCar Physics not defined correctly!\nPlease go to the 'Physics' tab and complete the car physics definition until it is saved.\n", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 == 15)
                        {
                            JOptionPane.showMessageDialog(null, "Error Creating Car!\nReason:\nCar Handling not rated.\nPlease Test Drive your car to rate its handling before publishing!\n", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(k18 > 15)
                        {
                            JOptionPane.showMessageDialog(null, "Unable to publish car fully!  Unknown Error.  Please try again later.\n", "Car Maker", 1);
                            flag4 = true;
                        }
                        if(!flag4)
                            JOptionPane.showMessageDialog(null, "Unable to publish car!  Unknown Error.\n", "Car Maker", 1);
                    }
                }
            }
            if(logged == 0)
            {
                if(i == 1)
                {
                    setCursor(new Cursor(3));
                    int i1 = -1;
                    try
                    {
                        Socket socket = new Socket("multiplayer.needformadness.com", 7061);
                        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        PrintWriter printwriter = new PrintWriter(socket.getOutputStream(), true);
                        printwriter.println((new StringBuilder()).append("1|").append(tnick.getText().toLowerCase()).append("|").append(tpass.getText()).append("|").toString());
                        String s14 = bufferedreader.readLine();
                        if(s14 != null)
                            i1 = servervalue(s14, 0);
                        socket.close();
                    }
                    catch(Exception exception1)
                    {
                        i1 = -1;
                    }
                    if(i1 == 0 || i1 == 3 || i1 > 10)
                    {
                        tnick.hide();
                        tpass.hide();
                        logged = 1;
                        savesettings();
                    }
                    if(i1 == 1 || i1 == 2)
                    {
                        setCursor(new Cursor(0));
                        JOptionPane.showMessageDialog(null, "Sorry.  Incorrect Nickname or Password!", "Car Maker", 0);
                    }
                    if(i1 == -167)
                    {
                        setCursor(new Cursor(0));
                        JOptionPane.showMessageDialog(null, "Sorry.  Your trial account cannot publish cars.  Please upgrade to a full account!   ", "Car Maker", 0);
                    }
                    if(i1 == -1)
                    {
                        setCursor(new Cursor(0));
                        JOptionPane.showMessageDialog(null, "Unable to connect to server at this moment, please try again later.", "Car Maker", 1);
                    }
                }
                if(i == 2)
                    Madness.openurl("http://multiplayer.needformadness.com/register.html");
                if(i == 3)
                    Madness.openurl("http://multiplayer.needformadness.com/edit.pl?display=upgrade");
            }
        }
    }

    public void setupo()
    {
        o = new ContO(editor.getText().getBytes(), m, t);
        o.x = ox;
        o.y = oy;
        o.z = oz;
        o.xz = oxz;
        o.xy = oxy;
        o.zy = ozy;
        o.shadow = true;
        o.tnt = 0;
        o.disp = 0;
        o.disline = 7;
        o.grounded = 1.0F;
        o.noline = false;
        o.decor = false;
        if(o.errd && (!o.err.startsWith("Wheels Error:") || forwheels))
            JOptionPane.showMessageDialog(null, o.err, "Car Maker", 0);
        if(o.maxR == 0)
            o.maxR = 100;
        squash = 0;
        hitmag = 0;
    }

    public void loadfile()
    {
        loadedfile = false;
        lastedo = "";
        BufferedReader bufferedreader;
        File file = new File((new StringBuilder()).append("mycars/").append(carname).append(".rad").toString());
        bufferedreader = new BufferedReader(new FileReader(file));
        Object obj = null;
_L3:
        String s;
        if((s = bufferedreader.readLine()) == null) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        lastedo;
        append();
        "";
        append();
        s;
        append();
        "\n";
        append();
        toString();
        lastedo;
          goto _L3
_L2:
        loadedfile = true;
        bufferedreader.close();
        bufferedreader = null;
        break MISSING_BLOCK_LABEL_165;
        Exception exception;
        exception;
        loadedfile = false;
        lastedo = "";
        JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to load file! Error Deatials:\n").append(exception).toString(), "Car Maker", 1);
        editor.setText(lastedo);
        return;
    }

    public void savefile()
    {
        if(!editor.getText().equals(""))
            try
            {
                File file = new File("mycars/");
                if(!file.exists())
                    file.mkdirs();
                file = new File((new StringBuilder()).append("mycars/").append(carname).append(".rad").toString());
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                bufferedwriter.write(editor.getText());
                bufferedwriter.close();
                bufferedwriter = null;
                changed = false;
                lastedo = editor.getText();
            }
            catch(Exception exception)
            {
                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to save file! Error Deatials:\n").append(exception).toString(), "Car Maker", 1);
            }
        savesettings();
    }

    public void newcar(String s)
    {
        if(s.equals(""))
        {
            JOptionPane.showMessageDialog(null, "Please Enter a Car Name!\n", "Car Maker", 1);
        } else
        {
            String s1 = (new StringBuilder()).append("\n// car: ").append(s).append("\n---------------------\n\n// To start making you car you must start by reading the tutorial at:\n// http://www.needformadness.com/developer/simplecar.html\n\n\n<p>\nc(100,200,100)\n\np(-40,-50,80)\np(-40,-50,-70)\np(40,-50,-70)\np(40,-50,80)\n</p>\n\n<p>\nc(100,150,200)\n\np(-40,-20,-100)\np(-40,-50,-70)\np(40,-50,-70)\np(40,-20,-100)\n</p>\n\n\n\n").toString();
            try
            {
                File file = new File("mycars/");
                if(!file.exists())
                    file.mkdirs();
                carname = s;
                file = new File((new StringBuilder()).append("mycars/").append(carname).append(".rad").toString());
                if(!file.exists())
                {
                    BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                    bufferedwriter.write(s1);
                    bufferedwriter.close();
                    bufferedwriter = null;
                    if(file.exists())
                    {
                        sfase = 0;
                        hidefields();
                        tabed = -1;
                    } else
                    {
                        JOptionPane.showMessageDialog(null, "Failed to create car, unknown reason!\n", "Car Maker", 1);
                    }
                } else
                {
                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("A car with the name '").append(carname).append("' already exists, please choose another name!\n").toString(), "Car Maker", 1);
                }
            }
            catch(Exception exception)
            {
                carname = "";
                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to create file! Error Deatials:\n").append(exception).toString(), "Car Maker", 1);
            }
        }
    }

    public void delcar(String s)
    {
        if(s.equals(""))
        {
            JOptionPane.showMessageDialog(null, "Please Select a Car to Delete!\n", "Car Maker", 1);
        } else
        {
            int i = JOptionPane.showConfirmDialog(null, (new StringBuilder()).append("Are you sure you want to delete car :  ").append(s).append(" ?  ").toString(), "Car Maker", 0);
            if(i == 0)
                try
                {
                    File file = new File((new StringBuilder()).append("mycars/").append(s).append(".rad").toString());
                    file.delete();
                    slcar.remove(s);
                    slcar.select(0);
                }
                catch(Exception exception)
                {
                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to delete file! Error Deatials:\n").append(exception).toString(), "Car Maker", 1);
                }
        }
    }

    public void rencar(String s)
    {
        if(s.equals(""))
            JOptionPane.showMessageDialog(null, "Please Enter a New Car Name!\n", "Car Maker", 1);
        else
            try
            {
                File file = new File((new StringBuilder()).append("mycars/").append(carname).append(".rad").toString());
                File file1 = new File((new StringBuilder()).append("mycars/").append(s).append(".rad").toString());
                if(file.renameTo(file1))
                {
                    carname = s;
                    sfase = 0;
                    hidefields();
                    tabed = -1;
                } else
                {
                    JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to rename car to: '").append(s).append("', possible reason: Car name already used!\n").toString(), "Car Maker", 1);
                }
            }
            catch(Exception exception)
            {
                JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Unable to rename file! Error Deatials:\n").append(exception).toString(), "Car Maker", 1);
            }
    }

    public void loadsettings()
    {
        try
        {
            File file = new File("mycars/settings.data");
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String s = bufferedreader.readLine();
                if(s != null)
                {
                    scar = s;
                    carname = scar;
                }
                s = bufferedreader.readLine();
                if(s != null)
                {
                    suser = s;
                    if(!suser.equals("Horaks"))
                        tnick.setText(suser);
                }
                s = bufferedreader.readLine();
                if(s != null)
                {
                    sfont = s;
                    cfont = sfont;
                }
                s = bufferedreader.readLine();
                if(s != null)
                {
                    sthm = Float.valueOf(s).intValue();
                    cthm = sthm;
                }
                bufferedreader.close();
                bufferedreader = null;
            }
        }
        catch(Exception exception) { }
    }

    public void savesettings()
    {
        if(!scar.equals(carname) || !suser.equals(tnick.getText()) || !sfont.equals(cfont) || cthm != sthm)
        {
            String s = (new StringBuilder()).append("").append(carname).append("\n").append(tnick.getText()).append("\n").append(cfont).append("\n").append(cthm).append("\n\n").toString();
            scar = carname;
            suser = tnick.getText();
            sfont = cfont;
            sthm = cthm;
            try
            {
                File file = new File("mycars/");
                if(!file.exists())
                    file.mkdirs();
                file = new File("mycars/settings.data");
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                bufferedwriter.write(s);
                bufferedwriter.close();
                bufferedwriter = null;
            }
            catch(Exception exception) { }
        }
    }

    public boolean checko(String s)
    {
        loadfile();
        setupo();
        if(o.colok < 2)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nFirst and Second colors not defined yet!\nPlease go to the 'Color Edit' tab to define the colors.\n").toString(), "Car Maker", 1);
            return false;
        }
        boolean flag = true;
        if(o.keyz[0] <= 0 || o.keyx[0] >= 0)
            flag = false;
        if(o.keyz[1] <= 0 || o.keyx[1] <= 0)
            flag = false;
        if(o.keyz[2] >= 0 || o.keyx[2] >= 0)
            flag = false;
        if(o.keyz[3] >= 0 || o.keyx[3] <= 0)
            flag = false;
        if(!flag)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar Wheels not defined or not defined correctly!\nPlease go to the \u2018Wheels\u2019 tab and use  [ Apply ]  and  [ Save ]  to define correctly.\n").toString(), "Car Maker", 1);
            return false;
        }
        if(o.npl <= 60)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nNo car seems to be designed!\nYou have not built a car yet please go to the \u2018Car\u2019 tab to find the tutorial on how to build a car.\n").toString(), "Car Maker", 1);
            return false;
        }
        if(o.npl > 286)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar contains too many polygons (pieces).\nNumber of polygons used need to be less then 210.\nPlease use the counter in the \u2018Code Edit\u2019 to decrease the number of polygons (pieces).\n").toString(), "Car Maker", 1);
            return false;
        }
        if(o.maxR > 400)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar scale size is too large!\nPlease use the \u2018Scale All\u2019 option in the \u2018Scale & Align\u2019 tab to resize your car to suitable size.       \nCompare it to other NFM cars using the \u2018Compare Car...\u2019 option.\nCurrently you car needs to be scaled down by ").append((int)(((float)o.maxR / 400F - 1.0F) * 100F)).append("%.\n").toString(), "Car Maker", 1);
            return false;
        }
        if(o.maxR < 120)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar scale size is too small!\nPlease use the \u2018Scale All\u2019 option in the \u2018Scale & Align\u2019 tab to resize your car to suitable size.       \nCompare it to other NFM cars using the \u2018Compare Car...\u2019 option.\nCurrently you car needs to be scaled up by ").append((int)((120F / (float)o.maxR - 1.0F) * 100F)).append("%.\n").toString(), "Car Maker", 1);
            return false;
        }
        String s1 = (new StringBuilder()).append("").append(editor.getText()).append("\n").toString();
        int i = 0;
        int j = s1.indexOf("\n", 0);
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        do
        {
            if(j == -1 || i >= s1.length())
                break;
            String s2 = s1.substring(i, j);
            s2 = s2.trim();
            i = j + 1;
            j = s1.indexOf("\n", i);
            if(s2.startsWith("stat("))
            {
                flag1 = true;
                try
                {
                    int k = 0;
                    for(int k1 = 0; k1 < 5; k1++)
                    {
                        stat[k1] = getvalue("stat", s2, k1);
                        if(stat[k1] > 200)
                            flag1 = false;
                        if(stat[k1] < 16)
                            flag1 = false;
                        k += stat[k1];
                    }

                    if(k != 680 && k != 640 && k != 600 && k != 560 && k != 520)
                        flag1 = false;
                }
                catch(Exception exception)
                {
                    flag1 = false;
                }
            }
            if(s2.startsWith("physics("))
            {
                flag2 = true;
                try
                {
                    for(int l = 0; l < 11; l++)
                    {
                        phys[l] = getvalue("physics", s2, l);
                        if(phys[l] > 100)
                            flag2 = false;
                        if(phys[l] < 0)
                            flag2 = false;
                    }

                    for(int i1 = 0; i1 < 3; i1++)
                    {
                        crash[i1] = getvalue("physics", s2, i1 + 11);
                        if(i1 != 0 && crash[i1] > 100)
                            flag2 = false;
                        if(crash[i1] < 0)
                            flag2 = false;
                    }

                    engsel = getvalue("physics", s2, 14);
                    if(engsel > 4)
                        flag2 = false;
                    if(engsel < 0)
                        flag2 = false;
                }
                catch(Exception exception1)
                {
                    flag2 = false;
                }
            }
            if(s2.startsWith("handling("))
            {
                flag3 = true;
                try
                {
                    int j1 = getvalue("handling", s2, 0);
                    if(j1 > 200)
                        flag3 = false;
                    if(j1 < 0)
                        flag3 = false;
                }
                catch(Exception exception2)
                {
                    flag3 = false;
                }
            }
        } while(true);
        if(!flag1)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar Stats & Class not defined correctly!\nPlease go to the 'Stats & Class' tab to define stats and don't forget to press  [ Save ]  when finished.\n").toString(), "Car Maker", 1);
            return false;
        }
        if(!flag2)
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar Physics not defined correctly!\nPlease go to the 'Physics' tab and complete the car physics definition until it is saved.\n").toString(), "Car Maker", 1);
            return false;
        }
        if(!flag3 && s.equals("Publishing"))
        {
            JOptionPane.showMessageDialog(null, (new StringBuilder()).append("Car is not ready for ").append(s).append("!\nReason:\nCar Handling not rated.\nPlease Test Drive your car to rate its handling before publishing!\n").toString(), "Car Maker", 1);
            return false;
        } else
        {
            return true;
        }
    }

    public void regx(int i, float f, boolean flag)
    {
        hitmag += f;
        if(!flag)
            crash(f);
        f *= 0.3F + (float)crash[1] * 0.005F;
        if(Math.abs(f) > 100F)
        {
            int j = (int)((double)(crash[0] * crash[0]) * 1.5D);
            if(j < 1000)
                j = 1000;
            if(f > 100F)
                f -= 100F;
            if(f < -100F)
                f += 100F;
            for(int k = 0; k < o.npl; k++)
            {
                float f1 = 0.0F;
                for(int l = 0; l < o.p[k].n; l++)
                {
                    if(o.p[k].wz != 0 || py(o.keyx[i], o.p[k].ox[l], o.keyz[i], o.p[k].oz[l]) >= j)
                        continue;
                    f1 = (f / 20F) * m.random();
                    o.p[k].oz[l] -= f1 * m.sin(o.xz) * m.cos(o.zy);
                    o.p[k].ox[l] += f1 * m.cos(o.xz) * m.cos(o.xy);
                    if(flag)
                        actmag += Math.abs(f1);
                }

                if(f1 == 0.0F)
                    continue;
                if(Math.abs(f1) >= 1.0F)
                {
                    o.p[k].chip = 1;
                    o.p[k].ctmag = f1;
                }
                if(!o.p[k].nocol && o.p[k].glass != 1)
                {
                    if(o.p[k].bfase > 20 && (double)o.p[k].hsb[1] > 0.25D)
                        o.p[k].hsb[1] = 0.25F;
                    if(o.p[k].bfase > 25 && (double)o.p[k].hsb[2] > 0.69999999999999996D)
                        o.p[k].hsb[2] = 0.7F;
                    if(o.p[k].bfase > 30 && (double)o.p[k].hsb[1] > 0.14999999999999999D)
                        o.p[k].hsb[1] = 0.15F;
                    if(o.p[k].bfase > 35 && (double)o.p[k].hsb[2] > 0.59999999999999998D)
                        o.p[k].hsb[2] = 0.6F;
                    if(o.p[k].bfase > 40)
                        o.p[k].hsb[0] = 0.075F;
                    if(o.p[k].bfase > 50 && (double)o.p[k].hsb[2] > 0.5D)
                        o.p[k].hsb[2] = 0.5F;
                    if(o.p[k].bfase > 60)
                        o.p[k].hsb[0] = 0.05F;
                    o.p[k].bfase += Math.abs(f1);
                    new Color(o.p[k].c[0], o.p[k].c[1], o.p[k].c[2]);
                    Color color = Color.getHSBColor(o.p[k].hsb[0], o.p[k].hsb[1], o.p[k].hsb[2]);
                    o.p[k].c[0] = color.getRed();
                    o.p[k].c[1] = color.getGreen();
                    o.p[k].c[2] = color.getBlue();
                }
                if(o.p[k].glass == 1)
                    o.p[k].gr += Math.abs((double)f1 * 1.5D);
            }

        }
    }

    public void regz(int i, float f, boolean flag)
    {
        hitmag += f;
        if(!flag)
            crash(f);
        f *= 0.3F + (float)crash[1] * 0.005F;
        if(Math.abs(f) > 100F)
        {
            int j = (int)((double)(crash[0] * crash[0]) * 1.5D);
            if(j < 1000)
                j = 1000;
            if(f > 100F)
                f -= 100F;
            if(f < -100F)
                f += 100F;
            for(int k = 0; k < o.npl; k++)
            {
                float f1 = 0.0F;
                for(int l = 0; l < o.p[k].n; l++)
                {
                    if(o.p[k].wz != 0 || py(o.keyx[i], o.p[k].ox[l], o.keyz[i], o.p[k].oz[l]) >= j)
                        continue;
                    f1 = (f / 20F) * m.random();
                    o.p[k].oz[l] += f1 * m.cos(o.xz) * m.cos(o.zy);
                    o.p[k].ox[l] += f1 * m.sin(o.xz) * m.cos(o.xy);
                    if(flag)
                        actmag += Math.abs(f1);
                }

                if(f1 == 0.0F)
                    continue;
                if(Math.abs(f1) >= 1.0F)
                {
                    o.p[k].chip = 1;
                    o.p[k].ctmag = f1;
                }
                if(!o.p[k].nocol && o.p[k].glass != 1)
                {
                    if(o.p[k].bfase > 20 && (double)o.p[k].hsb[1] > 0.25D)
                        o.p[k].hsb[1] = 0.25F;
                    if(o.p[k].bfase > 25 && (double)o.p[k].hsb[2] > 0.69999999999999996D)
                        o.p[k].hsb[2] = 0.7F;
                    if(o.p[k].bfase > 30 && (double)o.p[k].hsb[1] > 0.14999999999999999D)
                        o.p[k].hsb[1] = 0.15F;
                    if(o.p[k].bfase > 35 && (double)o.p[k].hsb[2] > 0.59999999999999998D)
                        o.p[k].hsb[2] = 0.6F;
                    if(o.p[k].bfase > 40)
                        o.p[k].hsb[0] = 0.075F;
                    if(o.p[k].bfase > 50 && (double)o.p[k].hsb[2] > 0.5D)
                        o.p[k].hsb[2] = 0.5F;
                    if(o.p[k].bfase > 60)
                        o.p[k].hsb[0] = 0.05F;
                    o.p[k].bfase += Math.abs(f1);
                    new Color(o.p[k].c[0], o.p[k].c[1], o.p[k].c[2]);
                    Color color = Color.getHSBColor(o.p[k].hsb[0], o.p[k].hsb[1], o.p[k].hsb[2]);
                    o.p[k].c[0] = color.getRed();
                    o.p[k].c[1] = color.getGreen();
                    o.p[k].c[2] = color.getBlue();
                }
                if(o.p[k].glass == 1)
                    o.p[k].gr += Math.abs((double)f1 * 1.5D);
            }

        }
    }

    public void roofsqsh(float f)
    {
        if(f > 100F)
        {
            crash(f);
            f -= 100F;
            int i = (int)(2D + (double)(float)crash[2] / 7.5999999999999996D);
            int j = 0;
            int k = 1;
            for(int l = 0; l < o.npl; l++)
            {
                float f1 = 0.0F;
                if(Math.random() > 0.90000000000000002D)
                    f1 = (f / 15F) * m.random();
                for(int i1 = 0; i1 < o.p[l].n; i1++)
                    if(o.p[l].wz == 0 && (Math.abs(o.p[l].oy[i1] - o.roofat - squash) < i * 3 || o.p[l].oy[i1] < o.roofat + squash) && squash < i)
                    {
                        f1 = (f / 15F) * m.random();
                        o.p[l].oy[i1] += f1;
                        j = (int)((float)j + f1);
                        k++;
                        hitmag += Math.abs(f1);
                    }

                if(!o.p[l].nocol && o.p[l].glass != 1)
                {
                    if(f1 != 0.0F)
                    {
                        if(o.p[l].bfase > 20 && (double)o.p[l].hsb[1] > 0.25D)
                            o.p[l].hsb[1] = 0.25F;
                        if(o.p[l].bfase > 25 && (double)o.p[l].hsb[2] > 0.69999999999999996D)
                            o.p[l].hsb[2] = 0.7F;
                        if(o.p[l].bfase > 30 && (double)o.p[l].hsb[1] > 0.14999999999999999D)
                            o.p[l].hsb[1] = 0.15F;
                        if(o.p[l].bfase > 35 && (double)o.p[l].hsb[2] > 0.59999999999999998D)
                            o.p[l].hsb[2] = 0.6F;
                        if(o.p[l].bfase > 40)
                            o.p[l].hsb[0] = 0.075F;
                        if(o.p[l].bfase > 50 && (double)o.p[l].hsb[2] > 0.5D)
                            o.p[l].hsb[2] = 0.5F;
                        if(o.p[l].bfase > 60)
                            o.p[l].hsb[0] = 0.05F;
                        o.p[l].bfase += f1;
                        new Color(o.p[l].c[0], o.p[l].c[1], o.p[l].c[2]);
                        Color color = Color.getHSBColor(o.p[l].hsb[0], o.p[l].hsb[1], o.p[l].hsb[2]);
                        o.p[l].c[0] = color.getRed();
                        o.p[l].c[1] = color.getGreen();
                        o.p[l].c[2] = color.getBlue();
                    }
                } else
                if(o.p[l].glass == 1)
                    o.p[l].gr += 5;
                if(Math.abs(f1) >= 1.0F)
                {
                    o.p[l].chip = 1;
                    o.p[l].ctmag = f1;
                }
            }

            squash += j / k;
        }
    }

    public void crash(float f)
    {
        if(f > 100F)
            f -= 100F;
        if(f < -100F)
            f += 100F;
        if(Math.abs(f) > 25F && Math.abs(f) < 170F)
            lowcrashs[crshturn].play();
        if(Math.abs(f) >= 170F)
            crashs[crshturn].play();
        if(Math.abs(f) > 25F)
        {
            if(crashup)
                crshturn--;
            else
                crshturn++;
            if(crshturn == -1)
                crshturn = 2;
            if(crshturn == 3)
                crshturn = 0;
        }
    }

    public void setheme()
    {
        if(cthm == 0)
        {
            editor.setForeground(deff);
            editor.setBackground(defb);
        }
        if(cthm == 1)
        {
            editor.setForeground(new Color(0, 0, 0));
            editor.setBackground(new Color(192, 192, 192));
        }
        if(cthm == 2)
        {
            editor.setForeground(new Color(192, 192, 192));
            editor.setBackground(new Color(0, 0, 0));
        }
        if(cthm == 3)
        {
            editor.setForeground(new Color(0, 0, 0));
            editor.setBackground(new Color(50, 200, 0));
        }
        if(cthm == 4)
        {
            editor.setForeground(new Color(67, 255, 77));
            editor.setBackground(new Color(0, 0, 0));
        }
        if(cthm == 5)
        {
            editor.setForeground(new Color(0, 172, 255));
            editor.setBackground(new Color(210, 234, 255));
        }
        if(cthm == 6)
        {
            editor.setForeground(new Color(255, 230, 0));
            editor.setBackground(new Color(255, 77, 67));
        }
        if(cthm == 7)
        {
            editor.setForeground(new Color(0, 159, 255));
            editor.setBackground(new Color(9, 47, 104));
        }
    }

    public int py(int i, int j, int k, int l)
    {
        return (i - j) * (i - j) + (k - l) * (k - l);
    }

    public void rot(int ai[], int ai1[], int i, int j, int k, int l)
    {
        if(k != 0)
        {
            for(int i1 = 0; i1 < l; i1++)
            {
                int j1 = ai[i1];
                int k1 = ai1[i1];
                ai[i1] = i + (int)((float)(j1 - i) * m.cos(k) - (float)(k1 - j) * m.sin(k));
                ai1[i1] = j + (int)((float)(j1 - i) * m.sin(k) + (float)(k1 - j) * m.cos(k));
            }

        }
    }

    public int xs(int i, int j)
    {
        if(j < m.cz)
            j = m.cz;
        return ((j - m.focus_point) * (m.cx - i)) / j + i;
    }

    public int ys(int i, int j)
    {
        if(j < m.cz)
            j = m.cz;
        return ((j - m.focus_point) * (m.cy - i)) / j + i;
    }

    public void init()
    {
        setBackground(new Color(0, 0, 0));
        offImage = createImage(700, 550);
        if(offImage != null)
            rd = (Graphics2D)offImage.getGraphics();
        rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        setLayout(null);
        slcar.setFont(new Font("Arial", 1, 13));
        slcar.add(rd, "Select a Car...         ");
        slcar.setForeground(new Color(63, 80, 110));
        slcar.setBackground(new Color(209, 217, 230));
        fontsel.setFont(new Font("Arial", 1, 12));
        fontsel.add(rd, "Arial");
        fontsel.add(rd, "Dialog");
        fontsel.add(rd, "DialogInput");
        fontsel.add(rd, "Monospaced");
        fontsel.add(rd, "Serif");
        fontsel.add(rd, "SansSerif");
        fontsel.add(rd, "Verdana");
        fontsel.setBackground(new Color(63, 80, 110));
        fontsel.setForeground(new Color(209, 217, 230));
        ctheme.setFont(new Font("Arial", 1, 12));
        ctheme.add(rd, "Default");
        ctheme.add(rd, "Author");
        ctheme.add(rd, "Dos");
        ctheme.add(rd, "Green");
        ctheme.add(rd, "The Matrix");
        ctheme.add(rd, "Ice Age");
        ctheme.add(rd, "Fire");
        ctheme.add(rd, "Ocean");
        ctheme.setBackground(new Color(63, 80, 110));
        ctheme.setForeground(new Color(209, 217, 230));
        compcar.setFont(new Font("Arial", 1, 12));
        compcar.add(rd, "Compare Car...");
        compcar.add(rd, "Tornado Shark");
        compcar.add(rd, "Formula 7");
        compcar.add(rd, "Wow Caninaro");
        compcar.add(rd, "La Vita Crab");
        compcar.add(rd, "Nimi");
        compcar.add(rd, "MAX Revenge");
        compcar.add(rd, "Lead Oxide");
        compcar.add(rd, "Kool Kat");
        compcar.add(rd, "Drifter X");
        compcar.add(rd, "Sword of Justice");
        compcar.add(rd, "High Rider");
        compcar.add(rd, "EL KING");
        compcar.add(rd, "Mighty Eight");
        compcar.add(rd, "M A S H E E N");
        compcar.add(rd, "Radical One");
        compcar.add(rd, "DR Monstaa");
        compcar.add(rd, " -  None  - ");
        compcar.setBackground(new Color(63, 80, 110));
        compcar.setForeground(new Color(209, 217, 230));
        cls.setFont(new Font("Arial", 1, 12));
        cls.add(rd, "Class A");
        cls.add(rd, "Class A & B");
        cls.add(rd, "Class B");
        cls.add(rd, "Class B & C");
        cls.add(rd, "Class C");
        cls.setBackground(new Color(63, 80, 110));
        cls.setForeground(new Color(209, 217, 230));
        simcar.setFont(new Font("Arial", 1, 12));
        simcar.add(rd, "Tornado Shark");
        simcar.add(rd, "Formula 7");
        simcar.add(rd, "Wow Caninaro");
        simcar.add(rd, "La Vita Crab");
        simcar.add(rd, "Nimi");
        simcar.add(rd, "MAX Revenge");
        simcar.add(rd, "Lead Oxide");
        simcar.add(rd, "Kool Kat");
        simcar.add(rd, "Drifter X");
        simcar.add(rd, "Sword of Justice");
        simcar.add(rd, "High Rider");
        simcar.add(rd, "EL KING");
        simcar.add(rd, "Mighty Eight");
        simcar.add(rd, "M A S H E E N");
        simcar.add(rd, "Radical One");
        simcar.add(rd, "DR Monstaa");
        simcar.setBackground(new Color(63, 80, 110));
        simcar.setForeground(new Color(209, 217, 230));
        witho.setFont(new Font("Arial", 1, 12));
        witho.add(rd, "With other cars");
        witho.add(rd, "Alone");
        witho.setBackground(new Color(63, 80, 110));
        witho.setForeground(new Color(209, 217, 230));
        engine.setFont(new Font("Arial", 1, 12));
        engine.add(rd, "Normal Engine");
        engine.add(rd, "V8 Engine");
        engine.add(rd, "Retro Engine");
        engine.add(rd, "Power Engine");
        engine.add(rd, "Diesel Engine");
        engine.setBackground(new Color(63, 80, 110));
        engine.setForeground(new Color(209, 217, 230));
        MenuItem menuitem = new MenuItem("Cut");
        MenuItem menuitem1 = new MenuItem("Copy");
        MenuItem menuitem2 = new MenuItem("Paste");
        MenuItem menuitem3 = new MenuItem("Select All");
        popupMenu = new PopupMenu();
        popupMenu.add(menuitem);
        popupMenu.add(menuitem1);
        popupMenu.add(menuitem2);
        popupMenu.add(menuitem3);
        menuitem.addActionListener(this);
        menuitem1.addActionListener(this);
        menuitem2.addActionListener(this);
        menuitem3.addActionListener(this);
        add(popupMenu);
        for(int i = 0; i < 16; i++)
        {
            wv[i] = new TextField("", 2);
            wv[i].setBackground(new Color(255, 255, 255));
            wv[i].setForeground(new Color(0, 0, 0));
            wv[i].setFont(new Font(cfont, 1, 14));
            wv[i].addMouseListener(new MouseHandler(popupMenu, i));
            add(wv[i]);
        }

        tnick.setFont(new Font("Arial", 1, 13));
        tnick.setBackground(new Color(255, 255, 255));
        tnick.setForeground(new Color(0, 0, 0));
        tpass.setFont(new Font("Arial", 1, 13));
        tpass.setEchoCharacter('*');
        tpass.setBackground(new Color(255, 255, 255));
        tpass.setForeground(new Color(0, 0, 0));
        pubtyp.setFont(new Font("Arial", 1, 13));
        pubtyp.add(rd, "Private");
        pubtyp.add(rd, "Public");
        pubtyp.add(rd, "Super Public");
        pubtyp.setBackground(new Color(63, 80, 110));
        pubtyp.setForeground(new Color(209, 217, 230));
        pubitem.setFont(new Font("Arial", 1, 13));
        pubitem.add(rd, "Account Cars");
        pubitem.setBackground(new Color(209, 217, 230));
        pubitem.setForeground(new Color(63, 80, 110));
        srch.setBackground(new Color(255, 255, 255));
        srch.setForeground(new Color(0, 0, 0));
        srch.addMouseListener(new MouseHandler(popupMenu, 16));
        rplc.setBackground(new Color(255, 255, 255));
        rplc.setForeground(new Color(0, 0, 0));
        rplc.addMouseListener(new MouseHandler(popupMenu, 17));
        editor.addMouseListener(new MouseHandler(popupMenu, 18));
        add(tnick);
        add(tpass);
        add(editor);
        add(srch);
        add(rplc);
        defb = new Color(255, 255, 255);
        deff = new Color(0, 0, 0);
        hidefields();
    }

    public void hidefields()
    {
        pubtyp.hide();
        pubitem.hide();
        tpass.hide();
        tnick.hide();
        slcar.hide();
        witho.hide();
        for(int i = 0; i < 16; i++)
            wv[i].hide();

        simcar.hide();
        engine.hide();
        cls.hide();
        compcar.hide();
        editor.hide();
        fontsel.hide();
        ctheme.hide();
        srch.hide();
        rplc.hide();
    }

    public void movefield(Component component, int i, int j, int k, int l)
    {
        i += apx;
        j += apy;
        if(component.getX() != i || component.getY() != j || component.getWidth() != k || component.getHeight() != l)
            component.setBounds(i, j, k, l);
    }

    public void drawms()
    {
        openm = false;
        if(pubtyp.draw(rd, xm, ym, mousdr, 550, false))
            openm = true;
        if(pubitem.draw(rd, xm, ym, mousdr, 550, false))
            openm = true;
        if(fontsel.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(ctheme.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(compcar.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(cls.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(simcar.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(engine.draw(rd, xm, ym, mousdr, 550, false))
            openm = true;
        if(witho.draw(rd, xm, ym, mousdr, 550, true))
            openm = true;
        if(slcar.draw(rd, xm, ym, mousdr, 550, false))
            openm = true;
        if(openm)
        {
            waso = true;
            mouses = 0;
        }
    }

    public void openlink()
    {
        Madness.openurl("http://www.needformadness.com/developer/simplecar.html");
    }

    public void openhlink()
    {
        Madness.openurl("http://www.needformadness.com/developer/");
    }

    public void openelink()
    {
        Madness.openurl("http://www.needformadness.com/developer/extras.html");
    }

    public void start()
    {
        if(thredo == null)
            thredo = new Thread(this);
        thredo.start();
    }

    public void stop()
    {
        exwist = true;
    }

    public void paint(Graphics g)
    {
        apx = getWidth() / 2 - 350;
        apy = getHeight() / 2 - 275;
        g.drawImage(offImage, apx, apy, this);
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public boolean mouseUp(Event event, int i, int j)
    {
        xm = i - apx;
        ym = j - apy;
        if(waso)
            waso = false;
        else
            mouses = -1;
        mousdr = false;
        if(onbtgame)
            Madness.game();
        return false;
    }

    public boolean mouseDown(Event event, int i, int j)
    {
        xm = i - apx;
        ym = j - apy;
        mouses = 1;
        mousdr = true;
        if(tab != 1)
            requestFocus();
        return false;
    }

    public boolean mouseMove(Event event, int i, int j)
    {
        xm = i - apx;
        ym = j - apy;
        if(xm > 520 && xm < 674 && ym > 0 && ym < 23)
        {
            if(!onbtgame)
            {
                onbtgame = true;
                setCursor(new Cursor(12));
            }
        } else
        if(onbtgame)
        {
            onbtgame = false;
            setCursor(new Cursor(0));
        }
        return false;
    }

    public boolean mouseDrag(Event event, int i, int j)
    {
        mousdr = true;
        xm = i - apx;
        ym = j - apy;
        return false;
    }

    public boolean lostFocus(Event event, Object obj)
    {
        focuson = false;
        return false;
    }

    public boolean gotFocus(Event event, Object obj)
    {
        focuson = true;
        return false;
    }

    public boolean keyDown(Event event, int i)
    {
        if(focuson)
        {
            if(i == 54 || i == 46 || i == 100 || i == 68)
                rotr = true;
            if(i == 52 || i == 44 || i == 97 || i == 65)
                rotl = true;
            if(i == 43 || i == 61)
                plus = true;
            if(i == 45)
                minus = true;
            if(i == 42 || i == 10 || i == 56 || i == 119 || i == 87)
                in = true;
            if(i == 47 || i == 8 || i == 50 || i == 115 || i == 83)
                out = true;
            if(i == 1006)
                left = true;
            if(i == 1007)
                right = true;
            if(i == 1005)
                down = true;
            if(i == 1004)
                up = true;
        }
        return false;
    }

    public boolean keyUp(Event event, int i)
    {
        if(i == 54 || i == 46 || i == 100 || i == 68)
            rotr = false;
        if(i == 52 || i == 44 || i == 97 || i == 65)
            rotl = false;
        if(i == 43 || i == 61)
            plus = false;
        if(i == 45)
            minus = false;
        if(i == 42 || i == 10 || i == 56 || i == 119 || i == 97)
            in = false;
        if(i == 47 || i == 8 || i == 50 || i == 115 || i == 83)
            out = false;
        if(i == 1006)
            left = false;
        if(i == 1007)
            right = false;
        if(i == 1005)
            down = false;
        if(i == 1004)
            up = false;
        return false;
    }

    public void loadsounds()
    {
        try
        {
            File file = new File("data/sounds.zip");
            FileInputStream fileinputstream = new FileInputStream(file);
            ZipInputStream zipinputstream = new ZipInputStream(fileinputstream);
            for(ZipEntry zipentry = zipinputstream.getNextEntry(); zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i = (int)zipentry.getSize();
                String s = zipentry.getName();
                byte abyte0[] = new byte[i];
                int j = 0;
                int k;
                for(; i > 0; i -= k)
                {
                    k = zipinputstream.read(abyte0, j, i);
                    j += k;
                }

                for(int l = 0; l < 5; l++)
                {
                    for(int k1 = 0; k1 < 5; k1++)
                        if(s.equals((new StringBuilder()).append("").append(k1).append("").append(l).append(".wav").toString()))
                            engs[k1][l] = new soundClip(abyte0);

                }

                for(int i1 = 0; i1 < 3; i1++)
                    if(s.equals((new StringBuilder()).append("crash").append(i1 + 1).append(".wav").toString()))
                        crashs[i1] = new soundClip(abyte0);

                for(int j1 = 0; j1 < 3; j1++)
                    if(s.equals((new StringBuilder()).append("lowcrash").append(j1 + 1).append(".wav").toString()))
                        lowcrashs[j1] = new soundClip(abyte0);

            }

            fileinputstream.close();
            zipinputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Loading Sounds: ").append(exception).toString());
        }
        System.gc();
    }

    public void loadbase()
    {
        String as[] = {
            "2000tornados", "formula7", "canyenaro", "lescrab", "nimi", "maxrevenge", "leadoxide", "koolkat", "drifter", "policecops", 
            "mustang", "king", "audir8", "masheen", "radicalone", "drmonster"
        };
        try
        {
            File file = new File("data/models.zip");
            ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(file));
            ZipEntry zipentry = zipinputstream.getNextEntry();
            Object obj = null;
            for(; zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i = -1;
                for(int j = 0; j < 16; j++)
                    if(zipentry.getName().startsWith(as[j]))
                        i = j;

                if(i == -1)
                    continue;
                int k = (int)zipentry.getSize();
                byte abyte0[] = new byte[k];
                int l = 0;
                int i1;
                for(; k > 0; k -= i1)
                {
                    i1 = zipinputstream.read(abyte0, l, k);
                    l += i1;
                }

                compo[i] = new ContO(abyte0, m, t);
                compo[i].shadow = false;
                compo[i].noline = true;
            }

            zipinputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Loading Models from Zip: ").append(exception).toString());
        }
        System.gc();
    }

    public void fixtext(TextField textfield)
    {
        String s = textfield.getText();
        s = s.replace('"', '#');
        String s1 = "\\";
        String s2 = "";
        int i = 0;
        int j = -1;
        for(; i < s.length(); i++)
        {
            String s3 = (new StringBuilder()).append("").append(s.charAt(i)).toString();
            if(s3.equals("|") || s3.equals(",") || s3.equals("(") || s3.equals(")") || s3.equals("#") || s3.equals(s1) || s3.equals("!") || s3.equals("?") || s3.equals("~") || s3.equals(".") || s3.equals("@") || s3.equals("$") || s3.equals("%") || s3.equals("^") || s3.equals("&") || s3.equals("*") || s3.equals("+") || s3.equals("=") || s3.equals(">") || s3.equals("<") || s3.equals("/") || s3.equals("'") || s3.equals(";") || s3.equals(":") || i > 15)
                j = i;
            else
                s2 = (new StringBuilder()).append(s2).append(s3).toString();
        }

        if(j != -1)
        {
            textfield.setText(s2);
            textfield.select(j, j);
        }
    }

    public int getvalue(String s, String s1, int i)
    {
        int k = 0;
        String s3 = "";
        for(int j = s.length() + 1; j < s1.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s1.charAt(j)).toString();
            if(s2.equals(",") || s2.equals(")"))
            {
                k++;
                j++;
            }
            if(k == i)
                s3 = (new StringBuilder()).append(s3).append(s1.charAt(j)).toString();
        }

        return Float.valueOf(s3).intValue();
    }

    public String getSvalue(String s, String s1, int i)
    {
        String s2 = "";
        int j = 0;
        for(int k = s.length() + 1; k < s1.length() && j <= i; k++)
        {
            String s3 = (new StringBuilder()).append("").append(s1.charAt(k)).toString();
            if(s3.equals(",") || s3.equals(")"))
            {
                j++;
                continue;
            }
            if(j == i)
                s2 = (new StringBuilder()).append(s2).append(s3).toString();
        }

        return s2;
    }

    public int servervalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals("|"))
                {
                    l++;
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String serverSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals("|"))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    public int objvalue(String s, int i)
    {
        int j = 0;
        try
        {
            int k = 2;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            boolean flag = false;
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals(" "))
                {
                    if(flag)
                    {
                        l++;
                        flag = false;
                    }
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
                flag = true;
            }

            if(k >= s.length())
                objfacend = true;
            if(s3.equals(""))
                s3 = "0";
            if(multf10)
            {
                j = (int)(Float.valueOf(s3).floatValue() * 10F);
            } else
            {
                int j1 = s3.indexOf("/", 0);
                if(j1 != -1)
                    s3 = s3.substring(0, j1);
                j = Float.valueOf(s3).intValue() - 1;
                if(j < 0)
                    j = 0;
            }
        }
        catch(Exception exception) { }
        return j;
    }

    public Image getImage(String s)
    {
        Image image = Toolkit.getDefaultToolkit().createImage(s);
        MediaTracker mediatracker = new MediaTracker(this);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        return image;
    }

    public void stringbutton(String s, int i, int j, int k, boolean flag)
    {
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        if(s.indexOf("Publish") != -1)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
        }
        bx[btn] = i;
        by[btn] = j - 5;
        bw[btn] = ftm.stringWidth(s);
        if(!pessd[btn])
        {
            rd.setColor(new Color(220, 220, 220));
            if(flag)
                rd.setColor(new Color(230, 230, 230));
            rd.fillRect(i - bw[btn] / 2 - 10, j - (17 - k), bw[btn] + 20, 25 - k * 2);
            rd.setColor(new Color(240, 240, 240));
            if(flag)
                rd.setColor(new Color(255, 255, 255));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (17 - k), i + bw[btn] / 2 + 10, j - (17 - k));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (18 - k), i + bw[btn] / 2 + 10, j - (18 - k));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 9, j - (19 - k), i + bw[btn] / 2 + 9, j - (19 - k));
            rd.setColor(new Color(200, 200, 200));
            if(flag)
                rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i + bw[btn] / 2 + 10, j - (17 - k), i + bw[btn] / 2 + 10, j + (7 - k));
            rd.drawLine(i + bw[btn] / 2 + 11, j - (17 - k), i + bw[btn] / 2 + 11, j + (7 - k));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i + bw[btn] / 2 + 12, j - (16 - k), i + bw[btn] / 2 + 12, j + (6 - k));
            if(flag)
                rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - bw[btn] / 2 - 10, j + (7 - k), i + bw[btn] / 2 + 10, j + (7 - k));
            rd.drawLine(i - bw[btn] / 2 - 10, j + (8 - k), i + bw[btn] / 2 + 10, j + (8 - k));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i - bw[btn] / 2 - 9, j + (9 - k), i + bw[btn] / 2 + 9, j + (9 - k));
            rd.setColor(new Color(240, 240, 240));
            if(flag)
                rd.setColor(new Color(255, 255, 255));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (17 - k), i - bw[btn] / 2 - 10, j + (7 - k));
            rd.drawLine(i - bw[btn] / 2 - 11, j - (17 - k), i - bw[btn] / 2 - 11, j + (7 - k));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - bw[btn] / 2 - 12, j - (16 - k), i - bw[btn] / 2 - 12, j + (6 - k));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(s, i - bw[btn] / 2, j);
        } else
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - bw[btn] / 2 - 10, j - (17 - k), bw[btn] + 20, 25 - k * 2);
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (17 - k), i + bw[btn] / 2 + 10, j - (17 - k));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (18 - k), i + bw[btn] / 2 + 10, j - (18 - k));
            rd.drawLine(i - bw[btn] / 2 - 9, j - (19 - k), i + bw[btn] / 2 + 9, j - (19 - k));
            rd.setColor(new Color(247, 247, 247));
            rd.drawLine(i + bw[btn] / 2 + 10, j - (17 - k), i + bw[btn] / 2 + 10, j + (7 - k));
            rd.drawLine(i + bw[btn] / 2 + 11, j - (17 - k), i + bw[btn] / 2 + 11, j + (7 - k));
            rd.drawLine(i + bw[btn] / 2 + 12, j - (16 - k), i + bw[btn] / 2 + 12, j + (6 - k));
            rd.drawLine(i - bw[btn] / 2 - 10, j + (7 - k), i + bw[btn] / 2 + 10, j + (7 - k));
            rd.drawLine(i - bw[btn] / 2 - 10, j + (8 - k), i + bw[btn] / 2 + 10, j + (8 - k));
            rd.drawLine(i - bw[btn] / 2 - 9, j + (9 - k), i + bw[btn] / 2 + 9, j + (9 - k));
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - bw[btn] / 2 - 10, j - (17 - k), i - bw[btn] / 2 - 10, j + (7 - k));
            rd.drawLine(i - bw[btn] / 2 - 11, j - (17 - k), i - bw[btn] / 2 - 11, j + (7 - k));
            rd.drawLine(i - bw[btn] / 2 - 12, j - (16 - k), i - bw[btn] / 2 - 12, j + (6 - k));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(s, (i - bw[btn] / 2) + 1, j + 1);
        }
        btn++;
    }

    public boolean ovbutton(String s, int i, int j)
    {
        rd.setFont(new Font("Arial", 0, 12));
        ftm = rd.getFontMetrics();
        if(s.equals("X") || s.equals("Download"))
        {
            rd.setFont(new Font("Arial", 1, 12));
            ftm = rd.getFontMetrics();
        }
        int k = ftm.stringWidth(s);
        byte byte0 = 4;
        boolean flag = false;
        boolean flag1 = false;
        if(Math.abs(xm - i) < k / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == 1)
            flag = true;
        else
            flag = false;
        if(Math.abs(xm - i) < k / 2 + 12 && Math.abs((ym - j) + 5) < 10 && mouses == -1)
        {
            mouses = 0;
            flag1 = true;
        }
        if(!flag)
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - k / 2 - 10, j - (17 - byte0), k + 20, 25 - byte0 * 2);
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i + k / 2 + 10, j - (17 - byte0));
            rd.drawLine(i - k / 2 - 10, j - (18 - byte0), i + k / 2 + 10, j - (18 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 9, j - (19 - byte0), i + k / 2 + 9, j - (19 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i + k / 2 + 10, j - (17 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 11, j - (17 - byte0), i + k / 2 + 11, j + (7 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i + k / 2 + 12, j - (16 - byte0), i + k / 2 + 12, j + (6 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (7 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (8 - byte0), i + k / 2 + 10, j + (8 - byte0));
            rd.setColor(new Color(200, 200, 200));
            rd.drawLine(i - k / 2 - 9, j + (9 - byte0), i + k / 2 + 9, j + (9 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i - k / 2 - 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 11, j - (17 - byte0), i - k / 2 - 11, j + (7 - byte0));
            rd.setColor(new Color(240, 240, 240));
            rd.drawLine(i - k / 2 - 12, j - (16 - byte0), i - k / 2 - 12, j + (6 - byte0));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("X"))
                rd.setColor(new Color(255, 0, 0));
            if(s.equals("Download"))
                rd.setColor(new Color(0, 64, 128));
            rd.drawString(s, i - k / 2, j);
        } else
        {
            rd.setColor(new Color(220, 220, 220));
            rd.fillRect(i - k / 2 - 10, j - (17 - byte0), k + 20, 25 - byte0 * 2);
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i + k / 2 + 10, j - (17 - byte0));
            rd.drawLine(i - k / 2 - 10, j - (18 - byte0), i + k / 2 + 10, j - (18 - byte0));
            rd.drawLine(i - k / 2 - 9, j - (19 - byte0), i + k / 2 + 9, j - (19 - byte0));
            rd.setColor(new Color(247, 247, 247));
            rd.drawLine(i + k / 2 + 10, j - (17 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 11, j - (17 - byte0), i + k / 2 + 11, j + (7 - byte0));
            rd.drawLine(i + k / 2 + 12, j - (16 - byte0), i + k / 2 + 12, j + (6 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (7 - byte0), i + k / 2 + 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 10, j + (8 - byte0), i + k / 2 + 10, j + (8 - byte0));
            rd.drawLine(i - k / 2 - 9, j + (9 - byte0), i + k / 2 + 9, j + (9 - byte0));
            rd.setColor(new Color(192, 192, 192));
            rd.drawLine(i - k / 2 - 10, j - (17 - byte0), i - k / 2 - 10, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 11, j - (17 - byte0), i - k / 2 - 11, j + (7 - byte0));
            rd.drawLine(i - k / 2 - 12, j - (16 - byte0), i - k / 2 - 12, j + (6 - byte0));
            rd.setColor(new Color(0, 0, 0));
            if(s.equals("X"))
                rd.setColor(new Color(255, 0, 0));
            if(s.equals("Download"))
                rd.setColor(new Color(0, 64, 128));
            rd.drawString(s, (i - k / 2) + 1, j + 1);
        }
        return flag1;
    }

    public void actionPerformed(ActionEvent actionevent)
    {
        Object obj = wv[0];
        if(Madness.textid >= 0 && Madness.textid <= 15)
            obj = wv[Madness.textid];
        if(Madness.textid == 16)
            obj = srch;
        if(Madness.textid == 17)
            obj = rplc;
        if(Madness.textid == 18)
            obj = editor;
        String s = actionevent.getActionCommand();
        if(s.equals("Cut"))
        {
            StringSelection stringselection = new StringSelection(((TextComponent) (obj)).getSelectedText());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection, null);
            if(Madness.textid == 18)
                editor.replaceText("", editor.getSelectionStart(), editor.getSelectionEnd());
            else
                ((TextComponent) (obj)).setText((new StringBuilder()).append(((TextComponent) (obj)).getText().substring(0, ((TextComponent) (obj)).getSelectionStart())).append(((TextComponent) (obj)).getText().substring(((TextComponent) (obj)).getSelectionEnd(), ((TextComponent) (obj)).getText().length())).toString());
        }
        if(s.equals("Copy"))
        {
            StringSelection stringselection1 = new StringSelection(((TextComponent) (obj)).getSelectedText());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection1, null);
        }
        if(s.equals("Paste"))
            try
            {
                String s1 = (String)Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                if(Madness.textid == 18)
                    editor.replaceText(s1, editor.getSelectionStart(), editor.getSelectionEnd());
                else
                    ((TextComponent) (obj)).setText((new StringBuilder()).append(((TextComponent) (obj)).getText().substring(0, ((TextComponent) (obj)).getSelectionStart())).append(s1).append(((TextComponent) (obj)).getText().substring(((TextComponent) (obj)).getSelectionEnd(), ((TextComponent) (obj)).getText().length())).toString());
            }
            catch(Exception exception) { }
        if(s.equals("Select All"))
            ((TextComponent) (obj)).selectAll();
    }

    Graphics2D rd;
    Image offImage;
    Thread thredo;
    boolean exwist;
    FontMetrics ftm;
    int apx;
    int apy;
    boolean focuson;
    Image btgame[];
    Image logo;
    boolean onbtgame;
    int tab;
    int tabed;
    boolean loadedfile;
    String carname;
    String scar;
    String suser;
    String sfont;
    int sthm;
    int sfase;
    Smenu slcar;
    boolean tutok;
    int flk;
    boolean changed;
    String lastedo;
    boolean prefs;
    boolean mirror;
    PopupMenu popupMenu;
    TextArea editor;
    TextField srch;
    TextField rplc;
    Smenu fontsel;
    String cfont;
    Smenu ctheme;
    Color defb;
    Color deff;
    int cthm;
    int cntprf;
    int cntpls;
    int cntchk;
    int npolys;
    boolean tomany;
    int ox;
    int oy;
    int oz;
    int oxz;
    int oxy;
    int ozy;
    Medium m;
    Trackers t;
    ContO o;
    ContO compo[];
    boolean right;
    boolean left;
    boolean up;
    boolean down;
    boolean rotl;
    boolean rotr;
    boolean plus;
    boolean minus;
    boolean in;
    boolean out;
    boolean pflk;
    boolean breakbond;
    int polynum;
    int prflk;
    int bfo;
    int dtab;
    int dtabed;
    int mouseon;
    String fcol;
    String ofcol;
    String scol;
    String oscol;
    float fhsb[] = {
        0.5F, 0.5F, 0.5F
    };
    float shsb[] = {
        0.5F, 0.5F, 0.5F
    };
    int scale[] = {
        100, 100, 100
    };
    int oscale[] = {
        100, 100, 100
    };
    Smenu compcar;
    int compsel;
    int adna[] = {
        276, 276, 276, 276, 276, 276
    };
    boolean changed2;
    TextField wv[];
    boolean defnow;
    String aply1;
    String aply2;
    boolean aplyd1;
    boolean aplyd2;
    boolean forwheels;
    Smenu cls;
    Smenu simcar;
    int stat[] = {
        100, 100, 100, 100, 100
    };
    int rstat[] = {
        0, 0, 0, 0, 0
    };
    int carstat[][] = {
        {
            110, 81, 131, 98, 100
        }, {
            200, 200, 88, 16, 16
        }, {
            108, 80, 93, 114, 125
        }, {
            146, 119, 100, 83, 72
        }, {
            109, 85, 141, 96, 93
        }, {
            128, 98, 102, 109, 123
        }, {
            115, 139, 96, 117, 133
        }, {
            120, 81, 145, 126, 128
        }, {
            140, 122, 101, 113, 124
        }, {
            110, 144, 100, 154, 92
        }, {
            133, 122, 144, 115, 126
        }, {
            107, 96, 96, 192, 189
        }, {
            192, 200, 106, 92, 90
        }, {
            88, 104, 88, 200, 200
        }, {
            148, 150, 197, 95, 90
        }, {
            112, 128, 120, 192, 128
        }
    };
    int carsel;
    int clsel;
    boolean statdef;
    int pfase;
    int phys[] = {
        50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 
        50
    };
    int rphys[] = {
        50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 
        50
    };
    int crash[] = {
        50, 50, 50
    };
    int rcrash[] = {
        50, 50, 50
    };
    String pname[] = {
        "Handbrake", "Turning Sensitivity", "Tire Grip", "Bouncing", "Empty", "Lifts Others", "Gets Lifted", "Pushes Others", "Gets Pushed", "Aerial Rotation Speed", 
        "Aerial Control/Gliding"
    };
    int pnx[] = {
        62, 20, 76, 71, 60, 38, 44, 20, 33, 320, 
        324
    };
    String usage[] = {
        "Handbrake:\nThis defines the hand braking power of the car.\nThe more handbrake the car has the faster it brakes when you press Spacebar while driving.\nBut also the lesser the Handbrake the more the car can drift when you press Spacebar.\n\n", "Turning Sensitivity:\nThis defines how fast the car turns (or how fast the wheels respond to turning).\nThe more turning sensitive the faster the car turns and responds.\n\nWhen designing a fast car that is more racing oriented high turning sensitivity is     \nrecommended for the car to be able to take sharp and quick turns.\nHowever too much turning sensitivity can make the car hard to drive!\n\nWhen designing a slower and bigger car (like El King) lower turning sensitivity is\nrecommended for a more realistic effect.\n\n", "Tires Grip:\nThis defines the griping power of the car\u2019s wheels on the ground.\n\nThe more griping the more the cars sticks to track.\nThe less gripping the more the car drifts in the turns.\n\nSome drifting can be helpful as it makes the car drive smoother while less drifting can\nmake the car more irritable, it depends on how you like to drive the car and how it\nfeels for you.\n\n", "Bouncing:\nThis defines how the car bounces back when it hits the ground or obstacles.\n\nBouncing can help when performing stunts as when you land up side down\nif the car bounces it can be filliped over before landing again to avoid a 'bad landing'.\n\nHowever bouncing is not helpful in controlling the car and in racing.\n\n", "If you can read this then you are decompiling the code! Please don\u2019t bother trying to allow the car maker to give you max stats, the stats get check on the server before the car can be accepted. Just to save you sometime.", "Lifts Others:\nThis defines if the car lifts up other cars when it collides with them from the front and\nhow high it can lift them.\n\nDoes the car have a pointy nose like MAX Revenge, Radical One or La Vita Crab, a\npointy nose/front part that can go under the wheels of other cars and lift them?\nIf so then give it some Lifts Others.\n\nIf it has a nose/front part that is a block like most cars then give it 0 Lifts Others.\n\n", "Gets Lifted:\nThis defines if the car can get lifted over other cars when it collides with them and how\nhigh it can get lifted.\n\nIs the car higher off the ground like Wow Caninaro or has big wheels like Dr Monstaa,\nshould its jump over cars when it collides with them?\nIf so then give it some Gets Lifted depending on how high it should go.\n\nIf the car is lower to the ground like most cars then it should have 0 Gets Lifted\n\n", "Pushes Others:\nThis defines if the car pushes other cars away when it collides with them and how far it\ncan push them.\n\nIs the car a heavy car with a strong body like MASHEEN or El King, where when it\ncollides with other cars it pushes them away?\nOr does the car have special bumpers or body parts for pushing cars away like Sword of\nJustice has?\nIf so then give it some Pushes Others depending how strong you think it can push cars.\n\nIf it is a car like any other car, with an average weight and body strength then you should\ngive it 0 Pushes Others.\n\n", "Gets Pushed:\nThis defines if the car gets pushed away when it collides with other cars and how far it\ngets pushed away.\n\nIf the car is lighter then most cars, then it should get pushed away when it collides with\nothers cars.\nGetting pushed can be helpful if the car is week because it gets it away from the danger\n(from the car that hit it) faster, making it take lesser hits and escape better.\nHowever getting pushed is not helpful when racing.\n\n", "Aerial Rotation Speed:\nThis adjusts how fast the car can rotate and flip in the air when its performing a stunt.\n\nThis variable also depends on how much the \u2018Stunts\u2019 stat of the car is, if the car has a\nhigh Stunts stat then this variable will have a much bigger effect, if it has low Stunts stat\nthe variable will have a lower effect.\n\nIf you think the car is rotating too fast or too slow in the air when performing a stunt use\nthis variable to adjust that.\n\nIf the aerial rotation is too fast it can make the car hard to control in the air as it flips and\nhard to land upright.\n\nIf the car is a big and heavy car like MASHHEN or El King then it should have low\naerial rotation for a realistic effect.\n\n", 
        "Aerial Control/Gliding:\nThis adjusts the cars ability to push itself in the air and glide when performing stunts!\n\nIf you don\u2019t know, in the game:\nBackward looping pushes the car upwards. \nForward looping pushes the car forwards. \nLeft and right rolling pushes the car left and right. \n\nThis variable adjust the power if this aerial push.\n\nThe variable also depends on how much the \u2018Stunts\u2019 stat of the car is, if the car has a\nhigh Stunts stat then this variable will have a much bigger effect, if it has low Stunts stat\nthe variable will have a lower effect.\n\nIf the car has some kind of wings or fins like Radical One or Kool Kat have then it should\nhave higher aerial control and gliding ability.\n\n", "Crash Look Test!\nThis defines how the car will look when it gets damaged.\nOr in other words what the car will look like as it gets damaged until it becomes wasted!\n\nIMPORTANT:\nYou need to perform a 'Normal Crash' test with a 'Roof Crash' test until the car gets totally destroyed (gets wasted and burns).\nYou need to also try a 'Normal Crash' test alone (without the roof crash) until the car gets wasted!\nA 'Roof Crash' happens significantly more when the car falls on its roof from a high jumps.\nA 'Normal Crash' is what happens as the car crashes normally with other cars and obstacles.\n\nClick any of adjustment variable names \u2018Radius\u2019, \u2018Magnitude\u2019 and \u2018Roof Destruction\u2019 to learn about their effect.\n\n>  You must perform the crash test more then once in order to make sure that this is how your want the car to look as it gets damaged\nuntil total destruction.", "Crash Radius:\nThe radius around the crash at which the polygons/pieces that lay inside it get\naffected.\n\nOr basically in other words the number of pieces that get affected on collision (the pieces\naround the crash location).\n\nIncreasing the radius will result in more pieces/polygons around the point of collision\ngetting crashed and distorted.\nDecreasing the radius means less pieces/polygons around the collision point getting\ndistorted and crashed.\n\n", "Crash Magnitude:\nThe magnitude of the distortion and indentation to occur on the effected pieces/polygons.\n\nOr basically in other words the amount of destruction that happens to each piece when\ncrashed.\n\nHigher magnitude means the piece gets more destructed from an amount of damage,\nlower magnitude means the piece gets less destructed from that same amount of damage.\n\n", "Roof Destruction:\nThe amount of destruction to occur on the car\u2019s top.\nThe length of indentation and destruction to happen from above.\n\nTo really see this variable's effect try crashing the roof alone (without a normal crash),\ntry more then once while fixing the car and changing the variable\u2019s value to see the\ndifference.\n\nThe roof crash normally happens in the game when the car lands upside down from a\njump or when a big car like Dr Monstaa steps on it.\n\n"
    };
    int hitmag;
    int actmag;
    int squash;
    boolean crashok;
    boolean crashleft;
    soundClip crashs[];
    soundClip lowcrashs[];
    Smenu engine;
    soundClip engs[][];
    int engsel;
    boolean engon;
    Smenu witho;
    boolean tested;
    boolean rateh;
    int handling;
    int logged;
    TextField tnick;
    TextField tpass;
    Smenu pubitem;
    Smenu pubtyp;
    int nmc;
    int roto;
    String mycars[];
    String maker[];
    int pubt[];
    int clas[];
    String addeda[][];
    int nad[];
    String justpubd;
    boolean pessd[] = {
        false, false, false, false, false, false, false, false, false, false, 
        false, false, false, false, false, false, false, false, false, false, 
        false, false, false, false
    };
    int bx[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int by[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int bw[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    int btn;
    int mouses;
    int xm;
    int ym;
    int sls;
    int sle;
    int crshturn;
    boolean crashup;
    boolean openm;
    boolean mousdr;
    boolean waso;
    boolean objfacend;
    boolean multf10;
}
