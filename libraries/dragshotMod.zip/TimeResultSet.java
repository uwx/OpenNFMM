// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TimeResultSet.java

import java.awt.EventQueue;
import java.awt.event.InvocationEvent;
import java.io.*;
import java.net.*;

public class TimeResultSet
{

    public TimeResultSet()
    {
        names = new String[4][2][5];
        times = new long[4][2][5];
        state = 0;
        queue = new EventQueue();
    }

    public void postResults(final int stage, final String nick, final long time, final long bestlap, final int sumid)
    {
        queue.postEvent(new InvocationEvent(this, new Runnable() {

            public void run()
            {
                try
                {
                    state = 0;
                    URL url = new URL("http://dscore.webcindario.com/ds-addons/scores2.php");
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);
                    OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
                    out.write((new StringBuilder()).append("&action=post&stage=").append(stage).append("&nick=").append(URLEncoder.encode(nick, "UTF-8")).append("&time=").append(time).append("&bestlap=").append(bestlap).append("&sumid=").append(sumid).toString());
                    out.flush();
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    names = (new String[][][] {
                        new String[][] {
                            new String[] {
                                "", "", "", "", ""
                            }, new String[] {
                                "", "", "", "", ""
                            }
                        }, new String[][] {
                            new String[] {
                                "", "", "", "", ""
                            }, new String[] {
                                "", "", "", "", ""
                            }
                        }, new String[][] {
                            new String[] {
                                "", "", "", "", ""
                            }, new String[] {
                                "", "", "", "", ""
                            }
                        }, new String[][] {
                            new String[] {
                                "", "", "", "", ""
                            }, new String[] {
                                "", "", "", "", ""
                            }
                        }
                    });
                    times = new long[4][2][5];
                    int ti[] = new int[4];
                    int li[] = new int[4];
                    int sc = 0;
                    if(conn.getContentType().equals("text/plain"))
                    {
                        do
                        {
                            String str;
                            if((str = in.readLine()) == null)
                                break;
                            if(str.startsWith("TRACK"))
                            {
                                sc = getValue(str, 1) - 1;
                                if(ti[sc] < 5)
                                {
                                    names[sc][0][ti[sc]] = getSvalue(str, 2);
                                    times[sc][0][ti[sc]] = getLvalue(str, 3);
                                    ti[sc]++;
                                }
                            }
                            if(str.startsWith("LAP"))
                            {
                                sc = getValue(str, 1) - 1;
                                if(li[sc] < 5)
                                {
                                    names[sc][1][li[sc]] = getSvalue(str, 2);
                                    times[sc][1][li[sc]] = getLvalue(str, 3);
                                    li[sc]++;
                                }
                            }
                            if(str.equals("ACTION_REQUIRED") || str.equals("INVALID_ACTION"))
                                state = -2;
                            if(str.equals("ERROR") || str.equals("DB_ERROR"))
                            {
                                state = -1;
                                exp = "[Server error]";
                            }
                        } while(true);
                        state = 1;
                    } else
                    {
                        state = -1;
                        exp = "The service is currently unavailable";
                    }
                }
                catch(Exception ex)
                {
                    if((ex instanceof UnknownHostException) || (ex instanceof ConnectException) || ex.getMessage().toLowerCase().contains("connection refused"))
                        exp = "Can't connect to the results server";
                    else
                        exp = ex.getClass().getName();
                    state = -1;
                }
            }

            final int val$stage;
            final String val$nick;
            final long val$time;
            final long val$bestlap;
            final int val$sumid;
            final TimeResultSet this$0;

            
            {
                this$0 = TimeResultSet.this;
                stage = i;
                nick = s;
                time = l;
                bestlap = l1;
                sumid = j;
                super();
            }
        }
));
    }

    public String getSvalue(String string, int i)
    {
        String string_658 = "";
        try
        {
            int i_659 = 0;
            int i_660 = 0;
            int i_661 = 0;
            String string_662 = "";
            String string_663 = "";
            for(; i_659 < string.length() && i_661 != 2; i_659++)
            {
                string_662 = (new StringBuilder()).append("").append(string.charAt(i_659)).toString();
                if(string_662.equals("|"))
                {
                    i_660++;
                    if(i_661 == 1 || i_660 > i)
                        i_661 = 2;
                    continue;
                }
                if(i_660 == i)
                {
                    string_663 = (new StringBuilder()).append(string_663).append(string_662).toString();
                    i_661 = 1;
                }
            }

            string_658 = string_663;
        }
        catch(Exception exception) { }
        return string_658;
    }

    public long getLvalue(String string, int i)
    {
        return Long.parseLong(getSvalue(string, i));
    }

    public int getValue(String string, int i)
    {
        return Integer.parseInt(getSvalue(string, i));
    }

    String names[][][];
    long times[][][];
    int state;
    EventQueue queue;
    String exp;
}
