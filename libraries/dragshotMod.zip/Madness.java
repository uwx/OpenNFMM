// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Madness.java

import java.applet.Applet;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java2s.image.PNGEncoder;
import javax.swing.JOptionPane;

public class Madness extends Panel
{

    public Madness()
    {
    }

    public static void detectProxy()
    {
        System.setProperty("java.net.useSystemProxies", "true");
        System.out.println("Detecting proxies...");
        java.util.List l = null;
        try
        {
            l = ProxySelector.getDefault().select(new URI("http://foo/bar"));
        }
        catch(URISyntaxException e)
        {
            e.printStackTrace();
        }
        if(l != null)
        {
            for(Iterator i$ = l.iterator(); i$.hasNext();)
            {
                Proxy proxy = (Proxy)i$.next();
                java.net.Proxy.Type type = proxy.type();
                if(type == java.net.Proxy.Type.DIRECT)
                {
                    System.out.println("No proxies were found");
                } else
                {
                    System.out.println((new StringBuilder()).append("\ntype : ").append(type).toString());
                    InetSocketAddress addr = (InetSocketAddress)proxy.address();
                    if(addr == null)
                    {
                        System.out.println("No Proxy");
                    } else
                    {
                        System.out.println((new StringBuilder()).append("proxy hostname : ").append(addr.getHostName()).toString());
                        System.setProperty("http.proxyHost", addr.getHostName());
                        System.out.println((new StringBuilder()).append("proxy port : ").append(addr.getPort()).toString());
                        System.setProperty("http.proxyPort", Integer.toString(addr.getPort()));
                    }
                    System.out.println();
                }
            }

        }
    }

    public static void main(String strings[])
    {
        System.runFinalizersOnExit(true);
        System.out.println("NfmM DS-addons pack - version 2.2.0 build #6, core version 35 (version 36 supported)");
        detectProxy();
        frame = new Frame("Need for Madness DS-addons pack");
        frame.setBackground(new Color(0, 0, 0));
        frame.setIgnoreRepaint(true);
        ArrayList icons = new ArrayList();
        int resols[] = {
            16, 24, 32, 48, 64, 96
        };
        int arr$[] = resols;
        int len$ = arr$.length;
        for(int i$ = 0; i$ < len$; i$++)
        {
            int res = arr$[i$];
            icons.add(Toolkit.getDefaultToolkit().createImage((new StringBuilder()).append("data/icon_").append(res).append("px.png").toString()));
        }

        frame.setIconImages(icons);
        applet = new GameSparker();
        GameSparker.loadPreferences();
        frame.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent windowevent)
            {
                Madness.exitsequance();
            }

        }
);
        initMenu();
        frame.add("Center", applet);
        frame.show();
        frame.setMinimumSize(new Dimension(930, 586));
        frame.setSize(930, 586);
        frame.setExtendedState(6);
        applet.init();
        applet.start();
        GraphicsEnvironment graphicsenvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        myDevice = graphicsenvironment.getDefaultScreenDevice();
        defdisp = myDevice.getDisplayMode();
        checknupdate(36);
    }

    private static void initMenu()
    {
        menu = new MenuBar();
        Menu men = new Menu("Gadgets settings");
        Menu menabout = new Menu("NfmM DS-addons pack 2.2 ~ DragShot Software / RadicalPlay.com");
        Menu mens = new Menu("Set Skin");
        MenuItem mit = new MenuItem("Default (add-ons off)");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 0;
                Madness.modon = 0;
                Madness.chronon = 0;
                Madness.poson = 0;
                Madness.arrowon = 0;
                Madness.staton = 0;
                GameSparker.postMessage("Now using Default skin");
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 1;
                Madness.modon = 1;
                Madness.chronon = 1;
                Madness.poson = 1;
                Madness.arrowon = 1;
                Madness.staton = 1;
                GameSparker.postMessage("Now using DSmod 2 skin");
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 2;
                Madness.modon = 2;
                Madness.chronon = 2;
                Madness.poson = 2;
                Madness.arrowon = 2;
                Madness.staton = 2;
                GameSparker.postMessage("Now using Black Fusion skin");
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 3;
                Madness.modon = 3;
                Madness.chronon = 3;
                Madness.poson = 3;
                Madness.arrowon = 3;
                Madness.staton = 3;
                GameSparker.postMessage("Now using Digital 7 skin");
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 4;
                Madness.modon = 4;
                Madness.chronon = 4;
                Madness.poson = 4;
                Madness.arrowon = 4;
                Madness.staton = 4;
                GameSparker.postMessage("Now using S7 skin");
            }

        }
);
        mens.add(mit);
        men.add(mens);
        mens = new Menu("Speedometer");
        mit = new MenuItem("Do not show speedometer");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.speedon = 4;
            }

        }
);
        mens.add(mit);
        MenuItem mitkph = new MenuItem(kph ? "Switch to MPH" : "Switch to KPH");
        mitkph.addActionListener(new ActionListener(mitkph) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.kph = !Madness.kph;
                if(Madness.kph)
                {
                    mitkph.setLabel("Switch to MPH");
                    if(Madness.speedon != 0)
                        GameSparker.postMessage("Showing KPH");
                } else
                {
                    mitkph.setLabel("Switch to KPH");
                    if(Madness.speedon != 0)
                        GameSparker.postMessage("Showing MPH");
                }
            }

            final MenuItem val$mitkph;

            
            {
                mitkph = menuitem;
                super();
            }
        }
);
        mens.add(mitkph);
        men.add(mens);
        mens = new Menu("Track visor");
        mit = new MenuItem("Do not show Track visor");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.modon = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.modon = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.modon = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.modon = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.modon = 4;
            }

        }
);
        mens.add(mit);
        MenuItem mitmod = new MenuItem(hidemod ? "Set to always visible" : "Set to hide automatically");
        mitmod.addActionListener(new ActionListener(mitmod) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.hidemod = !Madness.hidemod;
                if(Madness.hidemod)
                {
                    mitmod.setLabel("Set to always visible");
                } else
                {
                    mitmod.setLabel("Set to hide automatically");
                    GadgetPainter.modc = 150;
                }
            }

            final MenuItem val$mitmod;

            
            {
                mitmod = menuitem;
                super();
            }
        }
);
        mens.add(mitmod);
        men.add(mens);
        mens = new Menu("Chronometer");
        mit = new MenuItem("Do not show chronometer");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.chronon = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.chronon = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.chronon = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.chronon = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.chronon = 4;
            }

        }
);
        mens.add(mit);
        men.add(mens);
        mens = new Menu("Position");
        mit = new MenuItem("Classic skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.poson = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.poson = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.poson = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.poson = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.poson = 4;
            }

        }
);
        mens.add(mit);
        men.add(mens);
        mens = new Menu("Opponent status");
        mit = new MenuItem("Classic skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.arrowon = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.arrowon = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.arrowon = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.arrowon = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.arrowon = 4;
            }

        }
);
        mens.add(mit);
        men.add(mens);
        mens = new Menu("Damage/Power");
        mit = new MenuItem("Classic skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.staton = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("DSmod2 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.staton = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Black Fusion skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.staton = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Digtal 7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.staton = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("S7 skin");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.staton = 4;
            }

        }
);
        mens.add(mit);
        men.add(mens);
        mens = new Menu("Skin color");
        mit = new MenuItem("Turquoise (Default)");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 0;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Light Blue");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 1;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Green");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 2;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Yellow");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 3;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Orange");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 4;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Red");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 5;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Purple");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 6;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("Pink");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 7;
            }

        }
);
        mens.add(mit);
        mit = new MenuItem("White");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                GadgetPainter.ci = 8;
            }

        }
);
        mens.add(mit);
        men.add(mens);
        MenuItem mitlock = new MenuItem(keyon ? "Key shortcuts ON" : "Key shortcuts OFF");
        mitlock.addActionListener(new ActionListener(mitlock) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.keyon = !Madness.keyon;
                if(Madness.keyon)
                {
                    mitlock.setLabel("Key shortcuts ON");
                    GameSparker.postMessage("Key shortcuts activated");
                } else
                {
                    mitlock.setLabel("Key shortcuts OFF");
                    GameSparker.postMessage("Key shortcuts deactivated");
                }
            }

            final MenuItem val$mitlock;

            
            {
                mitlock = menuitem;
                super();
            }
        }
);
        men.add(mitlock);
        menu.add(men);
        mens = new Menu("Graphics");
        MenuItem mitglass = new MenuItem(glasson ? "Disable transparent glass" : "Enable transparent glass");
        mitglass.addActionListener(new ActionListener(mitglass) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.glasson = !Madness.glasson;
                if(Madness.glasson)
                {
                    mitglass.setLabel("Disable transparent glass");
                    GameSparker.postMessage("Transparent glass enabled");
                } else
                {
                    mitglass.setLabel("Enable transparent glass");
                    GameSparker.postMessage("Transparent glass disabled");
                }
            }

            final MenuItem val$mitglass;

            
            {
                mitglass = menuitem;
                super();
            }
        }
);
        mens.add(mitglass);
        MenuItem mitland = new MenuItem(landscp ? "Disable landscape" : "Enable landscape");
        mitland.addActionListener(new ActionListener(mitland) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.landscp = !Madness.landscp;
                if(Madness.landscp)
                {
                    mitland.setLabel("Disable landscape");
                    GameSparker.postMessage("Landscape enabled");
                } else
                {
                    mitland.setLabel("Enable landscape");
                    GameSparker.postMessage("Landscape disabled");
                }
            }

            final MenuItem val$mitland;

            
            {
                mitland = menuitem;
                super();
            }
        }
);
        mens.add(mitland);
        MenuItem mitblur = new MenuItem(landscp ? "Disable boost blur" : "Enable boost blur");
        mitblur.addActionListener(new ActionListener(mitblur) {

            public void actionPerformed(ActionEvent e)
            {
                Madness.bluron = !Madness.bluron;
                if(Madness.bluron)
                {
                    mitblur.setLabel("Disable boost blur");
                    GameSparker.postMessage("Boost blur enabled");
                } else
                {
                    mitblur.setLabel("Enable boost blur");
                    GameSparker.postMessage("Boost blur disabled");
                }
            }

            final MenuItem val$mitblur;

            
            {
                mitblur = menuitem;
                super();
            }
        }
);
        mens.add(mitblur);
        Menu mengrap = new Menu("Graphics quality");
        mit = new MenuItem("High (all enabled)");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.ographs = Madness.graphs = 0;
                GameSparker.postMessage("High Quality");
            }

        }
);
        mengrap.add(mit);
        mit = new MenuItem("Medium (close fade, special effects disabled)");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.ographs = Madness.graphs = 1;
                GameSparker.postMessage("Medium Quality");
            }

        }
);
        mengrap.add(mit);
        mit = new MenuItem("Low (Nfm2 graphics, closest fade, max FPS)");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.ographs = Madness.graphs = 2;
                GameSparker.postMessage("Low Quality");
            }

        }
);
        mengrap.add(mit);
        mens.add(mengrap);
        Menu mendist = new Menu("Rendering distance");
        mit = new MenuItem("Automatic");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.fade = 0;
                GameSparker.postMessage("Rendering distance set to Automatic");
            }

        }
);
        mendist.add(mit);
        mit = new MenuItem("Far");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.fade = 1;
                GameSparker.postMessage("Rendering distance set to Far");
            }

        }
);
        mendist.add(mit);
        mit = new MenuItem("Medium");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.fade = 2;
                GameSparker.postMessage("Rendering distance set to Medium");
            }

        }
);
        mendist.add(mit);
        mit = new MenuItem("Near");
        mit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                Madness.fade = 3;
                GameSparker.postMessage("Rendering distance set to Near");
            }

        }
);
        mendist.add(mit);
        mens.add(mendist);
        menu.add(mens);
        menu.add(menabout);
        frame.setMenuBar(menu);
    }

    public static void gofullscreen()
    {
        DisplayMode displaymodes[] = myDevice.getDisplayModes();
        String strings[] = new String[100];
        int is[] = new int[100];
        int i = 0;
        float f = (float)defdisp.getWidth() / (float)defdisp.getHeight();
        float f_0 = -1F;
        int i_1 = 0;
        for(int i_2 = 0; i_2 < displaymodes.length; i_2++)
        {
            if(displaymodes[i_2].getWidth() < 800 || displaymodes[i_2].getBitDepth() < 16 || i_1 >= 100)
                continue;
            if(displaymodes[i_2].getWidth() < 900)
            {
                float f_3 = (float)displaymodes[i_2].getWidth() / (float)displaymodes[i_2].getHeight();
                f_3 = Math.abs(f - f_3);
                if(f_3 <= f_0 || f_0 == -1F)
                {
                    i = i_1;
                    f_0 = f_3;
                }
            }
            strings[i_1] = (new StringBuilder()).append("").append(displaymodes[i_2].getWidth()).append(" x ").append(displaymodes[i_2].getHeight()).append(" Resolution   -   ").append(displaymodes[i_2].getBitDepth()).append(" Bits   -   ").append(displaymodes[i_2].getRefreshRate()).append(" Refresh Rate").toString();
            is[i_1] = i_2;
            i_1++;
        }

        if(f_0 != -1F)
        {
            StringBuilder stringbuilder = new StringBuilder();
            String strings_4[] = strings;
            int i_5 = i;
            strings_4[i_5] = stringbuilder.append(strings_4[i_5]).append("     <  Recommended").toString();
        }
        try
        {
            File file = new File("data/full_screen.data");
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String string;
                for(boolean bool = false; (string = bufferedreader.readLine()) != null && !bool; bool = true)
                {
                    string = string.trim();
                    int i_6 = i;
                    try
                    {
                        i_6 = Integer.valueOf(string).intValue();
                    }
                    catch(Exception exception)
                    {
                        i_6 = i;
                    }
                    i = i_6;
                    if(i < 0)
                        i = 0;
                    if(i > i_1 - 1)
                        i = i_1 - 1;
                }

                bufferedreader.close();
            }
        }
        catch(Exception exception) { }
        String strings_8[] = new String[i_1];
        for(int i_9 = 0; i_9 < i_1; i_9++)
            strings_8[i_9] = strings[i_9];

        String strings_10[] = strings_8;
        Object object = JOptionPane.showInputDialog(null, "Choose a screen resolution setting below and click OK to try it.\nExit Fullscreen by pressing [Esc].\n\nIMPORTANT: If the game does not display properly in Fullscreen press [Esc]      \nand try a different resolution setting below,", "Fullscreen Options", 1, null, strings_10, strings_10[i]);
        int i_11 = -1;
        if(object != null)
        {
            int i_12 = 0;
            do
            {
                if(i_12 >= i_1)
                    break;
                if(object.equals(strings_10[i_12]))
                {
                    i_11 = is[i_12];
                    i = i_12;
                    break;
                }
                i_12++;
            } while(true);
        }
        if(i_11 != -1)
        {
            try
            {
                File file = new File("data/full_screen.data");
                BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(file));
                bufferedwriter.write((new StringBuilder()).append("").append(i).append("").toString());
                bufferedwriter.newLine();
                bufferedwriter.close();
                Object object_13 = null;
            }
            catch(Exception exception) { }
            fullscreen = true;
            frame.dispose();
            frame = new Frame("Fullscreen Need for Madness");
            frame.setBackground(new Color(0, 0, 0));
            frame.setUndecorated(true);
            frame.setResizable(false);
            frame.setExtendedState(6);
            frame.setIgnoreRepaint(true);
            frame.add("Center", applet);
            frame.setMenuBar(menu);
            frame.show();
            if(myDevice.isFullScreenSupported())
            {
                try
                {
                    myDevice.setFullScreenWindow(frame);
                }
                catch(Exception exception) { }
                if(myDevice.isDisplayChangeSupported())
                    try
                    {
                        myDevice.setDisplayMode(displaymodes[i_11]);
                    }
                    catch(Exception exception) { }
            }
            applet.requestFocus();
        }
    }

    public static void exitfullscreen()
    {
        frame.dispose();
        frame = new Frame("Need for Madness DS-addons pack");
        frame.setBackground(new Color(0, 0, 0));
        frame.setIgnoreRepaint(true);
        frame.setIconImage(Toolkit.getDefaultToolkit().createImage("data/icon.gif"));
        frame.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent windowevent)
            {
                Madness.exitsequance();
            }

        }
);
        frame.add("Center", applet);
        frame.setMenuBar(menu);
        frame.show();
        if(myDevice.isFullScreenSupported())
        {
            try
            {
                myDevice.setDisplayMode(defdisp);
            }
            catch(Exception exception) { }
            if(myDevice.isDisplayChangeSupported())
                try
                {
                    myDevice.setFullScreenWindow(null);
                }
                catch(Exception exception) { }
        }
        frame.setMinimumSize(new Dimension(930, 586));
        frame.setSize(800, 586);
        frame.setExtendedState(6);
        applet.requestFocus();
        fullscreen = false;
    }

    public static void exitsequance()
    {
        if(updateon == 0 || updateon == 3)
        {
            if(endadv == 1)
                endadv = 2;
            if(updateon != 3)
                applet.stop();
            frame.removeAll();
            GameSparker.savePreferences();
            try
            {
                Thread.sleep(200L);
            }
            catch(Exception exception) { }
            applet.destroy();
            applet = null;
            System.exit(0);
        }
    }

    public static void checknupdate(int i)
    {
        String string = "";
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/update/").append(i).append(".txt").toString());
            url.openConnection().setConnectTimeout(5000);
            string = url.openConnection().getContentType();
            if(string.equals("text/plain"))
            {
                JOptionPane.showMessageDialog(frame, "The official build this add-ons pack was based on is outdated.\nYou won't be able to play online.", "Game core outdated", 1);
                updated = false;
            }
        }
        catch(Exception exception) { }
    }

    public static void carmaker()
    {
        applet.stop();
        frame.removeAll();
        frame.setMenuBar(null);
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        applet.destroy();
        applet = null;
        System.gc();
        System.runFinalization();
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        applet = new CarMaker();
        frame.add("Center", applet);
        frame.show();
        applet.init();
        applet.start();
    }

    public static void stagemaker()
    {
        applet.stop();
        frame.removeAll();
        frame.setMenuBar(null);
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        applet.destroy();
        applet = null;
        System.gc();
        System.runFinalization();
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        applet = new StageMaker();
        frame.add("Center", applet);
        frame.show();
        applet.init();
        applet.start();
    }

    public static void game()
    {
        applet.stop();
        frame.removeAll();
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        applet.destroy();
        applet = null;
        System.gc();
        System.runFinalization();
        try
        {
            Thread.sleep(400L);
        }
        catch(Exception exception) { }
        frame.setMenuBar(menu);
        applet = new GameSparker();
        frame.add("Center", applet);
        frame.show();
        applet.init();
        applet.start();
    }

    public static void switchMenuBar()
    {
        if(applet != null && (applet instanceof GameSparker))
            if(frame.getMenuBar() == menu)
            {
                frame.setMenuBar(null);
                GameSparker.postMessage("Menu bar is now hidden");
            } else
            {
                frame.setMenuBar(menu);
                GameSparker.postMessage("Menu bar is now visible");
            }
    }

    public static void advopen()
    {
        try
        {
            File file = new File("data/user.data");
            if(file.exists())
            {
                Date date = new Date();
                long l = date.getTime();
                if(advtime == 0L || l - advtime > 0x1d4c0L)
                {
                    openurl("http://www.needformadness.com/");
                    advtime = l;
                    endadv = 1;
                }
            }
        }
        catch(Exception exception) { }
    }

    public static String urlopen()
    {
        String string = "explorer";
        String string_25 = System.getProperty("os.name").toLowerCase();
        if(string_25.indexOf("linux") != -1 || string_25.indexOf("unix") != -1 || string_25.equals("aix"))
            string = "xdg-open";
        if(string_25.indexOf("mac") != -1)
            string = "open";
        return string;
    }

    public static void openurl(String string)
    {
        if(Desktop.isDesktopSupported())
            try
            {
                Desktop.getDesktop().browse(new URI(string));
            }
            catch(Exception exception) { }
        else
            try
            {
                Runtime.getRuntime().exec((new StringBuilder()).append("").append(urlopen()).append(" ").append(string).append("").toString());
            }
            catch(Exception exception) { }
    }

    public static String getfuncSvalue(String string, String string_26, int i)
    {
        String string_27 = "";
        int i_28 = 0;
        for(int i_29 = string.length() + 1; i_29 < string_26.length() && i_28 <= i; i_29++)
        {
            String string_30 = (new StringBuilder()).append("").append(string_26.charAt(i_29)).toString();
            if(string_30.equals(",") || string_30.equals(")"))
            {
                i_28++;
                continue;
            }
            if(i_28 == i)
                string_27 = (new StringBuilder()).append(string_27).append(string_30).toString();
        }

        return string_27;
    }

    public static boolean isURL(String str)
    {
        boolean flk = false;
        int barind = str.indexOf("//");
        if(barind <= -1)
        {
            int di = str.indexOf('.');
            if(di > 1 && str.indexOf('.', di + 1) != -1 && str.indexOf("..") == -1)
                flk = true;
        } else
        if(str.startsWith("http://") || str.startsWith("https://"))
        {
            String url = str.substring(barind + 1);
            int di = url.indexOf('.');
            if(di > 1 && url.indexOf('.', di + 1) != -1 && url.indexOf("..") == -1)
                flk = true;
        }
        if(str.indexOf(' ') != -1)
            flk = false;
        return flk;
    }

    public static void saveSnap(Image image)
    {
        File dir = new File("screenshots");
        if(!dir.exists())
            dir.mkdir();
        BufferedImage buff = new BufferedImage(800, 450, 1);
        buff.createGraphics().drawImage(image, 0, 0, frame);
        (new Thread("Snapshot maker", buff) {

            public void run()
            {
                try
                {
                    PNGEncoder encoder = new PNGEncoder(new FileOutputStream((new StringBuilder()).append("screenshots/snap").append(System.currentTimeMillis()).append(".png").toString()), (byte)2);
                    encoder.encode(buff);
                    GameSparker.postMessage("Snapshot taken", 60);
                }
                catch(Exception ex)
                {
                    GameSparker.postMessage((new StringBuilder()).append("Snapshot failed: ").append(ex.toString()).toString(), 60);
                    ex.printStackTrace();
                }
            }

            final BufferedImage val$buff;

            
            {
                buff = bufferedimage;
                super(x0);
            }
        }
).start();
        sshot = false;
    }

    static Frame frame;
    static Applet applet;
    static boolean fullscreen = false;
    static int anti = 1;
    static GraphicsDevice myDevice;
    static DisplayMode defdisp;
    static DisplayMode fulldisp;
    static int testdrive = 0;
    static String testcar = "";
    static int textid = 0;
    static int updateon = 0;
    static String upfile = "";
    static boolean inisetup = false;
    static int endadv = 0;
    static long advtime = 0L;
    static MenuBar menu;
    static boolean hidemod = true;
    static boolean glasson = true;
    static boolean landscp = true;
    static boolean bluron = true;
    static boolean kph = true;
    static boolean keyon = true;
    static boolean gui = true;
    static boolean sshot = false;
    static int speedon = 1;
    static int chronon = 1;
    static int modon = 1;
    static int poson = 1;
    static int arrowon = 0;
    static int staton = 0;
    static int graphs = 0;
    static int ographs = 0;
    static int fade = 0;
    static boolean updated = true;

}
