// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   UDPMistro.java

import java.io.*;
import java.net.Socket;
import java.util.Date;

public class UDPMistro
    implements Runnable
{

    public UDPMistro()
    {
        runon = 0;
        udpc = new udpOnline[20];
        porturn = 0;
        usrv = new udpServe[13];
        diledelay = 0;
        sendat = 0L;
        sendcheck = "";
        delay = 0;
        ldelays = new int[5];
        diled = 0;
        rate = 30;
        freg = 0.0F;
        go = false;
        im = 0;
        nplayers = 0;
        info = new String[14][3];
        frame = new int[14][3];
        lframe = new int[8];
        force = new int[8];
        lcframe = new int[8];
        isbot = new boolean[8];
        gocnt = new int[8];
        out = new int[8];
        xtserver = "";
        xtservport = 0;
        pgame = 0;
        wx = 0;
    }

    public void UDPConnectOnline(String s, int i, int j, int k)
    {
        diledelay = 0;
        delay = 0;
        for(int l = 0; l < 5; l++)
            ldelays[l] = 0;

        diled = 0;
        go = false;
        freg = 0.0F;
        im = k;
        nplayers = j;
        for(int i1 = 0; i1 < 8; i1++)
        {
            for(int k1 = 0; k1 < 3; k1++)
            {
                frame[i1][k1] = -1;
                info[i1][k1] = "";
            }

            isbot[i1] = false;
            lframe[i1] = 0;
            force[i1] = 0;
            lcframe[i1] = 0;
        }

        for(int j1 = 0; j1 < 20; j1++)
            udpc[j1] = new udpOnline(this, s, i + im, j1, porturn);

        if(porturn == 0)
            porturn = 20;
        else
            porturn = 0;
        if(im < nplayers)
            break MISSING_BLOCK_LABEL_316;
        frame[im][0] = 11111;
        info[im][0] = "watching";
_L3:
        if(info[im][0].length() >= 110) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        info[im];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "|";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L3
_L2:
        nplayers++;
        go = true;
        runon = 1;
        runner = new Thread(this);
        runner.start();
        return;
    }

    public void UDPConnectLan(String s, int i, int j)
    {
        diledelay = 0;
        delay = 0;
        for(int k = 0; k < 5; k++)
            ldelays[k] = 0;

        diled = 0;
        go = false;
        freg = 0.0F;
        im = j;
        nplayers = i;
        for(int l = 0; l < 8; l++)
        {
            for(int j1 = 0; j1 < 3; j1++)
            {
                frame[l][j1] = -1;
                info[l][j1] = "";
            }

            isbot[l] = false;
            lframe[l] = 0;
            force[l] = 0;
            lcframe[l] = 0;
        }

        if(im == 0)
            break MISSING_BLOCK_LABEL_332;
        for(int i1 = 0; i1 < 20; i1++)
            udpc[i1] = new udpOnline(this, s, 7060 + im, i1, porturn);

        if(porturn == 0)
            porturn = 20;
        else
            porturn = 0;
        if(im < nplayers)
            break MISSING_BLOCK_LABEL_324;
        frame[im][0] = 11111;
        info[im][0] = "watching";
_L3:
        if(info[im][0].length() >= 110) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        info[im];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "|";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L3
_L2:
        nplayers++;
        go = true;
        runon = 1;
        break MISSING_BLOCK_LABEL_405;
        try
        {
            socket = new Socket(xtserver, xtservport);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            dout = new PrintWriter(socket.getOutputStream(), true);
        }
        catch(Exception exception) { }
        runon = 4;
        runner = new Thread(this);
        runner.start();
        return;
    }

    public void UDPLanServer(int i, String s, int j, int k)
    {
        xtserver = s;
        xtservport = j;
        pgame = k;
        for(int l = 0; l < 8; l++)
        {
            gocnt[l] = 3;
            out[l] = 0;
            for(int j1 = 0; j1 < 3; j1++)
            {
                frame[l][j1] = -1;
                info[l][j1] = "";
            }

            lframe[l] = 0;
            force[l] = 0;
            lcframe[l] = 0;
        }

        for(int i1 = 0; i1 < nplayers + 5; i1++)
            usrv[i1] = new udpServe(this, i1 + 1);

    }

    public void UDPquit()
    {
        if(runon == 1)
            runon = 2;
        if(runon == 4)
            runon = 5;
    }

    public void run()
    {
        int i = 0;
        while(runon == 1) 
        {
            if(!udpc[0].started)
            {
                udpc[0].spark();
                i = 1;
            } else
            {
                Date date = new Date();
                if(i > delay / rate && date.getTime() - udpc[0].sendat > (long)(rate - 5))
                {
                    udpc[0].spark();
                    i = 1;
                }
            }
            if(delay > rate && i <= delay / rate && i >= 1 && i < 20)
            {
                Date date1 = new Date();
                long l = date1.getTime() - udpc[i - 1].sendat;
                if(l >= (long)(rate - 5) && l < (long)(rate * 2))
                {
                    udpc[i].spark();
                    i++;
                }
            }
            if(diled == 10)
            {
                for(int j = 0; j < 20; j++)
                {
                    if(!udpc[j].started)
                        continue;
                    Date date2 = new Date();
                    long l1 = date2.getTime() - udpc[j].sendat;
                    if((double)l1 > (double)delay * 1.5D && l1 > (long)rate)
                        udpc[j].stomp();
                }

            }
            if(diledelay > 0)
                diledelay--;
            try
            {
                Thread _tmp = runner;
                Thread.sleep(5L);
            }
            catch(InterruptedException interruptedexception) { }
        }
        byte byte0 = 0;
        int k = 0;
        while(runon == 4) 
        {
            for(int i1 = 0; i1 < nplayers; i1++)
            {
                boolean flag = false;
                if(info[i1][0].length() > 16)
                {
                    String s5 = (new StringBuilder()).append("").append(info[i1][0].charAt(15)).toString();
                    if(!s5.equals("0"))
                        flag = true;
                }
                if(!flag && out[i1] == 77)
                    out[i1] = 0;
                if(out[i1] >= 76)
                    continue;
                if(frame[i1][0] > 6)
                {
                    if(lcframe[i1] != frame[i1][0] && !flag)
                    {
                        lcframe[i1] = frame[i1][0];
                        out[i1] = 0;
                        continue;
                    }
                    if(out[i1] < 70)
                        out[i1] = 71;
                    out[i1]++;
                    if(flag)
                        out[i1] = 77;
                    if(out[i1] == 76)
                    {
                        info[i1][0] = "disco";
                        frame[i1][0] += 10;
                    }
                    continue;
                }
                out[i1]++;
                if(out[i1] == 30)
                    frame[i1][0] = 7;
            }

            if(k == 10)
            {
                String s = (new StringBuilder()).append("3|").append(pgame).append("|alive|").toString();
                String s1 = "";
                if(byte0 == 0)
                    try
                    {
                        dout.println(s);
                        String s2 = din.readLine();
                        if(s2 == null)
                            byte0 = 1;
                    }
                    catch(Exception exception)
                    {
                        byte0 = 1;
                    }
                if(byte0 == true)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                        din.close();
                        din = null;
                        dout.close();
                        dout = null;
                    }
                    catch(Exception exception1) { }
                    try
                    {
                        socket = new Socket(xtserver, xtservport);
                        din = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        dout = new PrintWriter(socket.getOutputStream(), true);
                        dout.println(s);
                        String s3 = din.readLine();
                        if(s3 != null)
                            byte0 = 0;
                    }
                    catch(Exception exception2) { }
                }
                if(byte0 == true)
                {
                    try
                    {
                        socket.close();
                        socket = null;
                    }
                    catch(Exception exception3) { }
                    byte0 = 2;
                }
                k = 0;
            } else
            {
                k++;
            }
            try
            {
                Thread _tmp1 = runner;
                Thread.sleep(1000L);
            }
            catch(InterruptedException interruptedexception1) { }
        }
        int j1 = 0;
        while(runon == 2) 
        {
            int k1 = 0;
            for(int j2 = 0; j2 < 20; j2++)
                if(!udpc[j2].started)
                    k1++;

            if(k1 != 20)
                j1++;
            if(j1 == 400 || k1 == 20)
            {
                for(int k2 = 0; k2 < 20; k2++)
                {
                    udpc[k2].closeSocket();
                    udpc[k2] = null;
                }

                runon = 3;
            }
            try
            {
                Thread _tmp2 = runner;
                Thread.sleep(5L);
            }
            catch(InterruptedException interruptedexception2) { }
        }
        if(runon == 3)
        {
            System.gc();
            System.runFinalization();
            runon = 0;
            runner = null;
        }
        if(runon == 5)
        {
            for(int i2 = 0; i2 < nplayers + 2; i2++)
                try
                {
                    usrv[i2].stopServe();
                    usrv[i2] = null;
                }
                catch(Exception exception4) { }

            String s4 = (new StringBuilder()).append("3|").append(pgame).append("|finish|").toString();
            try
            {
                dout.println(s4);
                String s6 = din.readLine();
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception5) { }
            System.gc();
            System.runFinalization();
            runon = 0;
            runner = null;
        }
    }

    public void readinfo(Mad mad, ContO conto, Control control, int i, int ai[])
    {
        if(go && force[i] != 7 && !isbot[i])
        {
            freg += 0.050000000000000003D;
            int j = -1;
            if(j == -1)
            {
                for(int k = 0; k < 3; k++)
                {
                    if(frame[i][k] != lframe[i] + 1)
                        continue;
                    j = k;
                    if(k == 1)
                        freg -= 0.10000000000000001D;
                    if(k == 2)
                        freg -= 0.14999999999999999D;
                }

            }
            if(j == -1)
            {
                int l = 0;
                for(int j1 = 0; j1 < 3; j1++)
                    if(frame[i][j1] > lframe[i] + 1)
                        l++;

                if(l == 3)
                    j = 2;
            }
            if(j == -1 && force[i] == 1)
            {
                for(int i1 = 0; i1 < 3; i1++)
                    if(frame[i][i1] >= lframe[i])
                        j = i1;

                if(j == -1)
                    freg += 0.20000000000000001D;
            }
            if(freg < -15F)
                freg = -15F;
            if(freg > 0.0F)
                freg = 0.0F;
            if(j != -1)
            {
                force[i] = 0;
                String s = info[i][j];
                String s1 = getSvalue(s, 0);
                if(s1.length() == 16)
                {
                    String s2 = "";
                    s2 = (new StringBuilder()).append("").append(s1.charAt(0)).toString();
                    if(s2.equals("0"))
                        control.left = false;
                    else
                        control.left = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(1)).toString();
                    if(s2.equals("0"))
                        control.right = false;
                    else
                        control.right = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(2)).toString();
                    if(s2.equals("0"))
                        control.up = false;
                    else
                        control.up = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(3)).toString();
                    if(s2.equals("0"))
                        control.down = false;
                    else
                        control.down = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(4)).toString();
                    if(s2.equals("0"))
                        control.handb = false;
                    else
                        control.handb = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(5)).toString();
                    if(s2.equals("0"))
                        mad.newcar = false;
                    else
                        mad.newcar = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(6)).toString();
                    if(s2.equals("0"))
                        mad.mtouch = false;
                    else
                        mad.mtouch = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(7)).toString();
                    if(s2.equals("0"))
                        mad.wtouch = false;
                    else
                        mad.wtouch = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(8)).toString();
                    if(s2.equals("0"))
                        mad.pushed = false;
                    else
                        mad.pushed = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(9)).toString();
                    if(s2.equals("0"))
                        mad.gtouch = false;
                    else
                        mad.gtouch = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(10)).toString();
                    if(s2.equals("0"))
                        mad.pl = false;
                    else
                        mad.pl = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(11)).toString();
                    if(s2.equals("0"))
                        mad.pr = false;
                    else
                        mad.pr = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(12)).toString();
                    if(s2.equals("0"))
                        mad.pd = false;
                    else
                        mad.pd = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(13)).toString();
                    if(s2.equals("0"))
                        mad.pu = false;
                    else
                        mad.pu = true;
                    s2 = (new StringBuilder()).append("").append(s1.charAt(14)).toString();
                    if(s2.equals("0"))
                        mad.dest = false;
                    else
                        mad.dest = true;
                } else
                if(s1.equals("disco"))
                {
                    ai[i] = 3;
                    mad.hitmag = mad.cd.maxmag[mad.cn] + 100;
                    force[i] = 7;
                }
                if(force[i] != 7)
                {
                    int k1 = getncoms(s);
                    wx = 0;
                    if(k1 > 1)
                        conto.x = getvalue(s, 1);
                    if(k1 > 2)
                        conto.y = getvalue(s, 0);
                    if(k1 > 3)
                        conto.z = getvalue(s, 0);
                    if(k1 > 4)
                        conto.xz = getvalue(s, 0);
                    if(k1 > 5)
                        conto.xy = getvalue(s, 0);
                    if(k1 > 6)
                        conto.zy = getvalue(s, 0);
                    if(k1 > 7)
                        mad.speed = (float)getvalue(s, 0) / 100F;
                    if(k1 > 8)
                        mad.power = (float)getvalue(s, 0) / 100F;
                    if(k1 > 9)
                        mad.mxz = getvalue(s, 0);
                    if(k1 > 10)
                        mad.pzy = getvalue(s, 0);
                    if(k1 > 11)
                        mad.pxy = getvalue(s, 0);
                    if(k1 > 12)
                        mad.txz = getvalue(s, 0);
                    if(k1 > 13)
                        mad.loop = getvalue(s, 0);
                    if(k1 > 14)
                        conto.wxz = getvalue(s, 0);
                    if(k1 > 15)
                        mad.pcleared = getvalue(s, 0);
                    if(k1 > 16)
                        mad.clear = getvalue(s, 0);
                    if(k1 > 17)
                        mad.nlaps = getvalue(s, 0);
                    if(k1 > 18)
                        mad.hitmag = (int)(((float)getvalue(s, 0) / 100F) * (float)mad.cd.maxmag[mad.cn]);
                }
                lframe[i] = frame[i][j];
            } else
            if(force[i] == 0)
            {
                lframe[i]++;
                force[i] = 1;
            }
        }
    }

    public void readContOinfo(ContO conto, int i)
    {
        if(go && force[i] == 1 && !isbot[i])
        {
            int j = -2;
            if(j == -2)
            {
                for(int k = 0; k < 3; k++)
                    if(frame[i][k] == lframe[i] + 1)
                        j = -1;

            }
            if(j == -1)
            {
                for(int l = 0; l < 3; l++)
                    if(frame[i][l] == lframe[i])
                        j = l;

            }
            if(j > 0)
            {
                String s = info[i][j];
                int i1 = getncoms(s);
                wx = 0;
                if(i1 > 1)
                    conto.x = getvalue(s, 1);
                if(i1 > 1)
                    conto.y = getvalue(s, 0);
                if(i1 > 1)
                    conto.z = getvalue(s, 0);
                if(i1 > 1)
                    conto.xz = getvalue(s, 0);
                if(i1 > 1)
                    conto.xy = getvalue(s, 0);
                if(i1 > 1)
                    conto.zy = getvalue(s, 0);
            }
        }
    }

    public void setinfo(Mad mad, ContO conto, Control control, int i, float f, boolean flag, int j)
    {
        info[j][0] = "";
        if(!control.left) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L3
_L2:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L3:
        if(!control.right) goto _L5; else goto _L4
_L4:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L6
_L5:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L6:
        if(!control.up) goto _L8; else goto _L7
_L7:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L9
_L8:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L9:
        if(!control.down) goto _L11; else goto _L10
_L10:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L12
_L11:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L12:
        if(!control.handb) goto _L14; else goto _L13
_L13:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L15
_L14:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L15:
        if(!mad.newcar) goto _L17; else goto _L16
_L16:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L18
_L17:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L18:
        if(!mad.mtouch) goto _L20; else goto _L19
_L19:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L21
_L20:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L21:
        if(!mad.wtouch) goto _L23; else goto _L22
_L22:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L24
_L23:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L24:
        if(!mad.pushed) goto _L26; else goto _L25
_L25:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L27
_L26:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L27:
        if(!mad.gtouch) goto _L29; else goto _L28
_L28:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L30
_L29:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L30:
        if(!mad.pl) goto _L32; else goto _L31
_L31:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L33
_L32:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L33:
        if(!mad.pr) goto _L35; else goto _L34
_L34:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L36
_L35:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L36:
        if(!mad.pd) goto _L38; else goto _L37
_L37:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L39
_L38:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L39:
        if(!mad.pu) goto _L41; else goto _L40
_L40:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L42
_L41:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L42:
        if(!mad.dest) goto _L44; else goto _L43
_L43:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L45
_L44:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L45:
        if(!flag) goto _L47; else goto _L46
_L46:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "1";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L48
_L47:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "0";
        append();
        toString();
        JVM INSTR aastore ;
_L48:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        ",";
        append();
        conto.x;
        append();
        ",";
        append();
        conto.y;
        append();
        ",";
        append();
        conto.z;
        append();
        ",";
        append();
        conto.xz;
        append();
        ",";
        append();
        conto.xy;
        append();
        ",";
        append();
        conto.zy;
        append();
        ",";
        append();
        (int)(mad.speed * 100F);
        append();
        ",";
        append();
        (int)(mad.power * 100F);
        append();
        ",";
        append();
        mad.mxz;
        append();
        ",";
        append();
        mad.pzy;
        append();
        ",";
        append();
        mad.pxy;
        append();
        ",";
        append();
        mad.txz;
        append();
        ",";
        append();
        mad.loop;
        append();
        ",";
        append();
        conto.wxz;
        append();
        ",";
        append();
        mad.pcleared;
        append();
        ",";
        append();
        mad.clear;
        append();
        ",";
        append();
        mad.nlaps;
        append();
        ",";
        append();
        (int)(f * 100F);
        append();
        ",";
        append();
        i;
        append();
        ",";
        append();
        toString();
        JVM INSTR aastore ;
_L51:
        if(info[j][0].length() >= 110) goto _L50; else goto _L49
_L49:
        new StringBuilder();
        info[j];
        0;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        "|";
        append();
        toString();
        JVM INSTR aastore ;
          goto _L51
_L50:
        if(runon == 2)
            mad.hitmag = mad.cd.maxmag[mad.cn] + 100;
        frame[j][0]++;
        return;
    }

    public int getvalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            String s1 = "";
            String s3 = "";
            for(; wx < s.length() && l != 2; wx++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(wx)).toString();
                if(s2.equals(","))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    l = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String getSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals(","))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    public int getncoms(String s)
    {
        int i = 0;
        int j = 0;
        String s1 = "";
        for(; j < s.length(); j++)
        {
            String s2 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
            if(s2.equals(","))
                i++;
        }

        return i;
    }

    Thread runner;
    int runon;
    udpOnline udpc[];
    int porturn;
    udpServe usrv[];
    int diledelay;
    long sendat;
    String sendcheck;
    int delay;
    int ldelays[];
    int diled;
    int rate;
    float freg;
    boolean go;
    int im;
    int nplayers;
    String info[][];
    int frame[][];
    int lframe[];
    int force[];
    int lcframe[];
    boolean isbot[];
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    int gocnt[];
    int out[];
    String xtserver;
    int xtservport;
    int pgame;
    int wx;
}
