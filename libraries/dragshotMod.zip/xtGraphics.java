// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   xtGraphics.java

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class xtGraphics extends Panel
    implements Runnable
{

    public xtGraphics(Medium medium, CarDefine cardefine, Graphics2D graphics2d, GameSparker gamesparker)
    {
        fase = 111;
        oldfase = 0;
        starcnt = 0;
        mtop = false;
        opselect = 1;
        dropf = 0;
        cfase = 0;
        firstime = true;
        shaded = false;
        flipo = 0;
        nextc = 0;
        multion = 0;
        gmode = 0;
        looped = 1;
        warning = 0;
        newparts = false;
        logged = false;
        gotlog = false;
        autolog = false;
        nofull = false;
        nfreeplays = 0;
        ndisco = 0;
        hours = 8;
        onviewpro = false;
        playingame = -1;
        onjoin = -1;
        ontyp = 0;
        lan = false;
        nickname = "";
        clan = "";
        nickey = "";
        clankey = "";
        backlog = "";
        server = "multiplayer.needformadness.com";
        localserver = "";
        servername = "Madness";
        servport = 7071;
        gameport = 7001;
        acexp = 0;
        discon = 0;
        cntptrys = 5;
        nplayers = 7;
        im = 0;
        osc = 10;
        minsl = 0;
        maxsl = 15;
        allrnp = new float[8][6];
        isbot = new boolean[8];
        clangame = 0;
        clanchat = false;
        gaclan = "";
        lcarx = 0;
        lcary = 0;
        lcarz = 0;
        beststunt = 0;
        laptime = 0;
        fastestlap = 0;
        sendstat = 0;
        testdrive = 0;
        holdit = false;
        holdcnt = 0;
        winner = true;
        flexpix = null;
        smokey = new int[0x16fb4];
        flatrstart = 0;
        runtyp = 0;
        forstart = 0;
        exitm = 0;
        bcl = new Image[2];
        bcr = new Image[2];
        bc = new Image[2];
        trackbg = new Image[2];
        dude = new Image[3];
        duds = 0;
        dudo = 0;
        next = new Image[2];
        back = new Image[2];
        contin = new Image[2];
        ostar = new Image[2];
        star = new Image[3];
        pcontin = 0;
        pnext = 0;
        pback = 0;
        pstar = 0;
        orank = new Image[8];
        rank = new Image[8];
        ocntdn = new Image[4];
        cntdn = new Image[4];
        gocnt = 0;
        engs = new soundClip[5][5];
        pengs = new boolean[5];
        air = new soundClip[6];
        aird = false;
        grrd = false;
        crash = new soundClip[3];
        lowcrash = new soundClip[3];
        pwastd = false;
        skid = new soundClip[3];
        dustskid = new soundClip[3];
        scrape = new soundClip[4];
        mutes = false;
        loadedt = false;
        mutem = false;
        macn = false;
        badmac = false;
        arrace = false;
        alocked = -1;
        lalocked = -1;
        cntflock = 0;
        onlock = false;
        ana = 0;
        cntan = 0;
        cntovn = 0;
        flk = false;
        tcnt = 30;
        tflk = false;
        say = "";
        wasay = false;
        clear = 0;
        posit = 0;
        wasted = 0;
        laps = 0;
        dmcnt = 0;
        dmflk = false;
        pwcnt = 0;
        pwflk = false;
        loop = "";
        spin = "";
        asay = "";
        auscnt = 45;
        aflk = false;
        kbload = 0;
        dnload = 0;
        shload = 0.0F;
        radpx = 212;
        pin = 60;
        trkl = 0;
        trklim = (int)(Math.random() * 40D);
        lmode = 0;
        bgf = 0.0F;
        bgup = false;
        removeds = 0;
        nfmtab = 0;
        justwon1 = false;
        justwon2 = false;
        lfrom = 0;
        lockcnt = 0;
        showtf = false;
        ransay = 0;
        flkat = 0;
        movly = 0;
        gxdu = 0;
        gydu = 0;
        muhi = 0;
        lsc = -1;
        mouson = -1;
        onmsc = -1;
        remi = false;
        basefase = 0;
        noclass = false;
        gatey = 300;
        waitlink = 0;
        lxm = -10;
        lym = -10;
        pwait = 7;
        stopcnt = 0;
        cntwis = 0;
        lcn = 0;
        crshturn = 0;
        bfcrash = 0;
        bfskid = 0;
        crashup = false;
        skidup = false;
        skflg = 0;
        dskflg = 0;
        bfscrape = 0;
        sturn0 = 0;
        sturn1 = 0;
        bfsc1 = 0;
        bfsc2 = 0;
        flatr = 0;
        flyr = 0;
        flyrdest = 0;
        flang = 0;
        notrees = false;
        treeflk = false;
        prevGmod = 0;
        rs = new TimeResultSet();
        sumid = new int[32];
        m = medium;
        cd = cardefine;
        app = gamesparker;
        rd = graphics2d;
        hello = getImage("data/hello.gif");
        sign = getImage("data/sign.gif");
        loadbar = getImage("data/loadbar.gif");
        for(int i = 0; i < 5; i++)
            pengs[i] = false;

        nofull = false;
        SecurityManager securitymanager = System.getSecurityManager();
        if(securitymanager != null)
            try
            {
                securitymanager.checkConnect("needformadness.com", -1);
            }
            catch(Exception exception)
            {
                String string = (new StringBuilder()).append("").append(exception).toString();
                if(string.indexOf("access denied") != -1)
                    nofull = true;
            }
        macn = false;
        badmac = false;
        if(System.getProperty("os.name").indexOf("Mac") != -1)
            macn = true;
        chrono = new Chronometer(this);
    }

    public void loaddata()
    {
        kbload = 637;
        runtyp = 176;
        runner = new Thread(this);
        runner.start();
        loadimages();
        intertrack = new RadicalMod("music/interface.zip");
        dnload += 44;
        loadsounds();
    }

    public void loadsounds()
    {
        dnload += 3;
        try
        {
            File file = new File("data/sounds.zip");
            FileInputStream fileinputstream = new FileInputStream(file);
            ZipInputStream zipinputstream = new ZipInputStream(fileinputstream);
            for(ZipEntry zipentry = zipinputstream.getNextEntry(); zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i = (int)zipentry.getSize();
                String string = zipentry.getName();
                byte is[] = new byte[i];
                int i_0 = 0;
                int i_1;
                for(; i > 0; i -= i_1)
                {
                    i_1 = zipinputstream.read(is, i_0, i);
                    i_0 += i_1;
                }

                for(int i_2 = 0; i_2 < 5; i_2++)
                {
                    for(int i_3 = 0; i_3 < 5; i_3++)
                        if(string.equals((new StringBuilder()).append("").append(i_3).append("").append(i_2).append(".wav").toString()))
                            engs[i_3][i_2] = new soundClip(is);

                }

                for(int i_4 = 0; i_4 < 6; i_4++)
                    if(string.equals((new StringBuilder()).append("air").append(i_4).append(".wav").toString()))
                        air[i_4] = new soundClip(is);

                for(int i_5 = 0; i_5 < 3; i_5++)
                    if(string.equals((new StringBuilder()).append("crash").append(i_5 + 1).append(".wav").toString()))
                        crash[i_5] = new soundClip(is);

                for(int i_6 = 0; i_6 < 3; i_6++)
                    if(string.equals((new StringBuilder()).append("lowcrash").append(i_6 + 1).append(".wav").toString()))
                        lowcrash[i_6] = new soundClip(is);

                for(int i_7 = 0; i_7 < 3; i_7++)
                    if(string.equals((new StringBuilder()).append("skid").append(i_7 + 1).append(".wav").toString()))
                        skid[i_7] = new soundClip(is);

                for(int i_8 = 0; i_8 < 3; i_8++)
                    if(string.equals((new StringBuilder()).append("dustskid").append(i_8 + 1).append(".wav").toString()))
                        dustskid[i_8] = new soundClip(is);

                for(int i_9 = 0; i_9 < 3; i_9++)
                {
                    if(!string.equals((new StringBuilder()).append("scrape").append(i_9 + 1).append(".wav").toString()))
                        continue;
                    scrape[i_9] = new soundClip(is);
                    if(i_9 == 2)
                        scrape[3] = new soundClip(is);
                }

                if(string.equals("powerup.wav"))
                    powerup = new soundClip(is);
                if(string.equals("tires.wav"))
                    tires = new soundClip(is);
                if(string.equals("checkpoint.wav"))
                    checkpoint = new soundClip(is);
                if(string.equals("carfixed.wav"))
                    carfixed = new soundClip(is);
                if(string.equals("three.wav"))
                    three = new soundClip(is);
                if(string.equals("two.wav"))
                    two = new soundClip(is);
                if(string.equals("one.wav"))
                    one = new soundClip(is);
                if(string.equals("go.wav"))
                    go = new soundClip(is);
                if(string.equals("wasted.wav"))
                    wastd = new soundClip(is);
                if(string.equals("firewasted.wav"))
                    firewasted = new soundClip(is);
                if(string.equals("notif.wav"))
                    Globe.notif = new soundClip(is);
                dnload += 5;
            }

            fileinputstream.close();
            zipinputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Loading Sounds: ").append(exception).toString());
        }
        System.gc();
    }

    public void loadimages()
    {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        MediaTracker mediatracker = new MediaTracker(app);
        Image image = null;
        Image image_10 = null;
        dnload += 8;
        try
        {
            File file = new File("data/images.zip");
            FileInputStream fileinputstream = new FileInputStream(file);
            ZipInputStream zipinputstream = new ZipInputStream(fileinputstream);
            for(ZipEntry zipentry = zipinputstream.getNextEntry(); zipentry != null; zipentry = zipinputstream.getNextEntry())
            {
                int i = (int)zipentry.getSize();
                String string = zipentry.getName();
                byte is[] = new byte[i];
                int i_11 = 0;
                int i_12;
                for(; i > 0; i -= i_12)
                {
                    i_12 = zipinputstream.read(is, i_11, i);
                    i_11 += i_12;
                }

                if(string.equals("cars.gif"))
                    carsbg = loadBimage(is, mediatracker, toolkit, 1);
                if(string.equals("color.gif"))
                    image = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("class.gif"))
                    image_10 = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("smokey.gif"))
                    smokeypix(is, mediatracker, toolkit);
                if(string.equals("1.gif"))
                    orank[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("gameh.gif"))
                    ogameh = loadimage(is, mediatracker, toolkit);
                if(string.equals("wgame.gif"))
                    owgame = loadimage(is, mediatracker, toolkit);
                if(string.equals("gameov.gif"))
                    gameov = loadimage(is, mediatracker, toolkit);
                if(string.equals("lap.gif"))
                    olap = loadimage(is, mediatracker, toolkit);
                if(string.equals("paused.gif"))
                    paused = loadimage(is, mediatracker, toolkit);
                if(string.equals("select.gif"))
                    select = loadimage(is, mediatracker, toolkit);
                if(string.equals("yourwasted.gif"))
                    oyourwasted = loadimage(is, mediatracker, toolkit);
                if(string.equals("disco.gif"))
                    odisco = loadimage(is, mediatracker, toolkit);
                if(string.equals("youwastedem.gif"))
                    oyouwastedem = loadimage(is, mediatracker, toolkit);
                if(string.equals("gamefinished.gif"))
                    ogamefinished = loadimage(is, mediatracker, toolkit);
                if(string.equals("exitgame.gif"))
                    oexitgame = loadimage(is, mediatracker, toolkit);
                if(string.equals("pgate.gif"))
                    pgate = loadimage(is, mediatracker, toolkit);
                if(string.equals("d1.png"))
                    dude[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("d2.png"))
                    dude[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("d3.png"))
                    dude[2] = loadimage(is, mediatracker, toolkit);
                if(string.equals("float.gif"))
                    oflaot = loadimage(is, mediatracker, toolkit);
                if(string.equals("1c.gif"))
                    ocntdn[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("2c.gif"))
                    ocntdn[2] = loadimage(is, mediatracker, toolkit);
                if(string.equals("3c.gif"))
                    ocntdn[3] = loadimage(is, mediatracker, toolkit);
                if(string.equals("2.gif"))
                    orank[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("3.gif"))
                    orank[2] = loadimage(is, mediatracker, toolkit);
                if(string.equals("4.gif"))
                    orank[3] = loadimage(is, mediatracker, toolkit);
                if(string.equals("5.gif"))
                    orank[4] = loadimage(is, mediatracker, toolkit);
                if(string.equals("6.gif"))
                    orank[5] = loadimage(is, mediatracker, toolkit);
                if(string.equals("7.gif"))
                    orank[6] = loadimage(is, mediatracker, toolkit);
                if(string.equals("8.gif"))
                    orank[7] = loadimage(is, mediatracker, toolkit);
                if(string.equals("bgmain.jpg"))
                    bgmain = loadBimage(is, mediatracker, toolkit, 2);
                if(string.equals("br.gif"))
                    br = loadimage(is, mediatracker, toolkit);
                if(string.equals("loadingmusic.gif"))
                    oloadingmusic = loadimage(is, mediatracker, toolkit);
                if(string.equals("radicalplay.gif"))
                    radicalplay = loadimage(is, mediatracker, toolkit);
                if(string.equals("back.gif"))
                {
                    back[0] = loadimage(is, mediatracker, toolkit);
                    back[1] = bressed(back[0]);
                }
                if(string.equals("continue.gif"))
                {
                    contin[0] = loadimage(is, mediatracker, toolkit);
                    contin[1] = bressed(contin[0]);
                }
                if(string.equals("next.gif"))
                {
                    next[0] = loadimage(is, mediatracker, toolkit);
                    next[1] = bressed(next[0]);
                }
                if(string.equals("rpro.gif"))
                    rpro = loadimage(is, mediatracker, toolkit);
                if(string.equals("selectcar.gif"))
                    selectcar = loadimage(is, mediatracker, toolkit);
                if(string.equals("track.jpg"))
                {
                    trackbg[0] = loadBimage(is, mediatracker, toolkit, 3);
                    trackbg[1] = dodgen(trackbg[0]);
                }
                if(string.equals("youlost.gif"))
                    oyoulost = loadimage(is, mediatracker, toolkit);
                if(string.equals("youwon.gif"))
                    oyouwon = loadimage(is, mediatracker, toolkit);
                if(string.equals("0c.gif"))
                    ocntdn[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("damage.gif"))
                    odmg = loadimage(is, mediatracker, toolkit);
                if(string.equals("power.gif"))
                    opwr = loadimage(is, mediatracker, toolkit);
                if(string.equals("position.gif"))
                    opos = loadimage(is, mediatracker, toolkit);
                if(string.equals("speed.gif"))
                    osped = loadimage(is, mediatracker, toolkit);
                if(string.equals("wasted.gif"))
                    owas = loadimage(is, mediatracker, toolkit);
                if(string.equals("start1.gif"))
                    ostar[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("start2.gif"))
                {
                    ostar[1] = loadimage(is, mediatracker, toolkit);
                    star[2] = pressed(ostar[1]);
                }
                if(string.equals("congrad.gif"))
                    congrd = loadimage(is, mediatracker, toolkit);
                if(string.equals("statb.gif"))
                    statb = loadimage(is, mediatracker, toolkit);
                if(string.equals("statbo.gif"))
                    statbo = loadimage(is, mediatracker, toolkit);
                if(string.equals("madness.gif"))
                    mdness = loadude(is, mediatracker, toolkit);
                if(string.equals("fixhoop.png"))
                    fixhoop = loadimage(is, mediatracker, toolkit);
                if(string.equals("arrow.gif"))
                    sarrow = loadimage(is, mediatracker, toolkit);
                if(string.equals("stunts.png"))
                    stunts = loadimage(is, mediatracker, toolkit);
                if(string.equals("racing.gif"))
                    racing = loadimage(is, mediatracker, toolkit);
                if(string.equals("wasting.gif"))
                    wasting = loadimage(is, mediatracker, toolkit);
                if(string.equals("plus.gif"))
                    plus = loadimage(is, mediatracker, toolkit);
                if(string.equals("space.gif"))
                    space = loadimage(is, mediatracker, toolkit);
                if(string.equals("arrows.gif"))
                    arrows = loadimage(is, mediatracker, toolkit);
                if(string.equals("chil.gif"))
                    chil = loadimage(is, mediatracker, toolkit);
                if(string.equals("ory.gif"))
                    ory = loadimage(is, mediatracker, toolkit);
                if(string.equals("kz.gif"))
                    kz = loadimage(is, mediatracker, toolkit);
                if(string.equals("kx.gif"))
                    kx = loadimage(is, mediatracker, toolkit);
                if(string.equals("kv.gif"))
                    kv = loadimage(is, mediatracker, toolkit);
                if(string.equals("km.gif"))
                    km = loadimage(is, mediatracker, toolkit);
                if(string.equals("kn.gif"))
                    kn = loadimage(is, mediatracker, toolkit);
                if(string.equals("ks.gif"))
                    ks = loadimage(is, mediatracker, toolkit);
                if(string.equals("kenter.gif"))
                    kenter = loadimage(is, mediatracker, toolkit);
                if(string.equals("nfm.gif"))
                    nfm = loadimage(is, mediatracker, toolkit);
                if(string.equals("options.png"))
                    opti = loadimage(is, mediatracker, toolkit);
                if(string.equals("options2.png"))
                    opti2 = loadimage(is, mediatracker, toolkit);
                if(string.equals("opback.png"))
                    opback = loadimage(is, mediatracker, toolkit);
                if(string.equals("logocars.png"))
                    logocars = loadimage(is, mediatracker, toolkit);
                if(string.equals("logomad.png"))
                    logomadnes = loadimage(is, mediatracker, toolkit);
                if(string.equals("logomadbg.jpg"))
                    logomadbg = loadimage(is, mediatracker, toolkit);
                if(string.equals("byrd.png"))
                    byrd = loadimage(is, mediatracker, toolkit);
                if(string.equals("bggo.jpg"))
                    bggo = loadimage(is, mediatracker, toolkit);
                if(string.equals("nfmcoms.png"))
                    nfmcoms = loadimage(is, mediatracker, toolkit);
                if(string.equals("nfmcom.gif"))
                    nfmcom = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("brit.gif"))
                    brt = loadimage(is, mediatracker, toolkit);
                if(string.equals("arn.gif"))
                    arn = loadimage(is, mediatracker, toolkit);
                if(string.equals("mload.gif"))
                    mload = loadimage(is, mediatracker, toolkit);
                if(string.equals("login.gif"))
                    login = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("play.gif"))
                    play = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("cancel.gif"))
                    cancel = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("dome.gif"))
                    dome = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("register.gif"))
                    register = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("upgrade.gif"))
                    upgrade = loadimage(is, mediatracker, toolkit);
                if(string.equals("sdets.gif"))
                    sdets = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bob.gif"))
                    bob = loadBimage(is, mediatracker, toolkit, 1);
                if(string.equals("bot.gif"))
                    bot = loadBimage(is, mediatracker, toolkit, 1);
                if(string.equals("bol.gif"))
                    bol = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bolp.gif"))
                    bolp = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bor.gif"))
                    bor = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("borp.gif"))
                    borp = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("logout.gif"))
                    logout = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("change.gif"))
                    change = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("pln.gif"))
                    pln = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("pon.gif"))
                    pon = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bols.gif"))
                    bols = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bolps.gif"))
                    bolps = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bors.gif"))
                    bors = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("borps.gif"))
                    borps = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("games.gif"))
                    games = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("exit.gif"))
                    exit = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("chat.gif"))
                    chat = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("players.gif"))
                    players = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("roomp.gif"))
                    roomp = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("myfr.gif"))
                    myfr = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("mycl.gif"))
                    mycl = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("cnmc.gif"))
                    cnmc = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("ready.gif"))
                    redy = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("notreg.gif"))
                    ntrg = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("cgame.gif"))
                    cgame = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("ccar.gif"))
                    ccar = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("lanm.gif"))
                    lanm = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("asu.gif"))
                    asu = loadimage(is, mediatracker, toolkit);
                if(string.equals("asd.gif"))
                    asd = loadimage(is, mediatracker, toolkit);
                if(string.equals("pls.gif"))
                    pls = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("sts.gif"))
                    sts = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("gmc.gif"))
                    gmc = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("stg.gif"))
                    stg = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("crd.gif"))
                    crd = loadBimage(is, mediatracker, toolkit, 0);
                if(string.equals("bcl.gif"))
                    bcl[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("bcr.gif"))
                    bcr[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("bc.gif"))
                    bc[0] = loadimage(is, mediatracker, toolkit);
                if(string.equals("pbcl.gif"))
                    bcl[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("pbcr.gif"))
                    bcr[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("pbc.gif"))
                    bc[1] = loadimage(is, mediatracker, toolkit);
                if(string.equals("cmc.gif"))
                    cmc = loadimage(is, mediatracker, toolkit);
                if(string.equals("myc.gif"))
                    myc = loadimage(is, mediatracker, toolkit);
                if(string.equals("gac.gif"))
                    gac = loadimage(is, mediatracker, toolkit);
                if(string.equals("yac.gif"))
                    yac = loadimage(is, mediatracker, toolkit);
                if(string.equals("ycmc.gif"))
                    ycmc = loadimage(is, mediatracker, toolkit);
                if(string.equals("top20s.gif"))
                    top20s = loadimage(is, mediatracker, toolkit);
                dnload += 2;
            }

            fileinputstream.close();
            zipinputstream.close();
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error Loading Images: ").append(exception).toString());
        }
        makecarsbgc(image, image_10);
        System.gc();
    }

    public void run()
    {
        boolean bool = false;
        while(runtyp > 0) 
        {
            if(runtyp >= 1 && runtyp <= 140)
                hipnoload(runtyp, false);
            if(runtyp == 176)
            {
                loading();
                bool = true;
            }
            app.repaint();
            try
            {
                if(runner == null);
                Thread.sleep(20L);
            }
            catch(InterruptedException interruptedexception) { }
        }
        if(bool)
        {
            pingstat();
            bool = false;
        }
        boolean bools[] = {
            true, true
        };
        while((runtyp == -101 || sendstat == 1) && !lan) 
        {
            String string = (new StringBuilder()).append("3|").append(playingame).append("|").append(updatec[0]).append("|").toString();
            if(clanchat)
                string = (new StringBuilder()).append(string).append("").append(updatec[1]).append("|").append(clan).append("|").append(clankey).append("|").toString();
            else
                string = (new StringBuilder()).append(string).append("0|||").toString();
            if(updatec[0] <= -11)
            {
                for(int i = 0; i < -updatec[0] - 10; i++)
                    string = (new StringBuilder()).append(string).append("").append(cnames[0][6 - i]).append("|").append(sentn[0][6 - i]).append("|").toString();

                updatec[0] = -2;
            }
            if(clanchat && updatec[1] <= -11)
            {
                for(int i = 0; i < -updatec[1] - 10; i++)
                    string = (new StringBuilder()).append(string).append("").append(cnames[1][6 - i]).append("|").append(sentn[1][6 - i]).append("|").toString();

                updatec[1] = -2;
            }
            if(sendstat == 1)
            {
                string = (new StringBuilder()).append("5|").append(playingame).append("|").append(im).append("|").append(beststunt).append("|").append(fastestlap).append("|").toString();
                for(int i = 0; i < nplayers; i++)
                    string = (new StringBuilder()).append(string).append("").append(dcrashes[i]).append("|").toString();

                sendstat = 2;
            }
            boolean bool_13 = false;
            String string_14 = "";
            try
            {
                dout.println(string);
                string_14 = din.readLine();
                if(string_14 == null)
                    bool_13 = true;
            }
            catch(Exception exception)
            {
                bool_13 = true;
            }
            if(bool_13)
            {
                try
                {
                    socket.close();
                    socket = null;
                    din.close();
                    din = null;
                    dout.close();
                    dout = null;
                }
                catch(Exception exception) { }
                try
                {
                    socket = new Socket(server, servport);
                    din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                    dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                    dout.println(string);
                    string_14 = din.readLine();
                    if(string_14 != null)
                        bool_13 = false;
                }
                catch(Exception exception) { }
            }
            if(bool_13)
            {
                try
                {
                    socket.close();
                    socket = null;
                }
                catch(Exception exception) { }
                runtyp = 0;
                if(app.cmsg.isShowing())
                {
                    app.cmsg.hide();
                    app.requestFocus();
                }
                runner.stop();
            }
            if(sendstat != 2)
            {
                int i = 2;
                int i_15 = 1;
                if(clanchat)
                    i_15 = 2;
                for(int i_16 = 0; i_16 < i_15; i_16++)
                {
                    int i_17 = getvalue(string_14, i_16);
                    if(updatec[i_16] != i_17 && updatec[i_16] >= -2 && pointc[i_16] == 6)
                    {
                        for(int i_18 = 0; i_18 < 7; i_18++)
                        {
                            cnames[i_16][i_18] = getSvalue(string_14, i);
                            i++;
                            sentn[i_16][i_18] = getSvalue(string_14, i);
                            i++;
                        }

                        if(cnames[i_16][6].equals(""))
                            if(i_16 == 0)
                                cnames[i_16][6] = "Game Chat  ";
                            else
                                cnames[i_16][6] = (new StringBuilder()).append("").append(clan).append("'s Chat  ").toString();
                        if(updatec[i_16] != -2)
                        {
                            floater[i_16] = 1;
                            if(bools[i_16])
                            {
                                msgflk[i_16] = 67;
                                bools[i_16] = false;
                            } else
                            {
                                msgflk[i_16] = 110;
                            }
                        }
                        updatec[i_16] = i_17;
                    }
                }

            } else
            {
                sendstat = 3;
            }
            try
            {
                if(runner == null);
                Thread.sleep(1000L);
            }
            catch(InterruptedException interruptedexception) { }
        }
        if(runtyp == -167 || runtyp == -168)
        {
            try
            {
                socket = new Socket("multiplayer.needformadness.com", 7061);
                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                dout.println((new StringBuilder()).append("101|").append(runtyp + 174).append("|").append(app.tnick.getText()).append("|").append(app.tpass.getText()).append("|").toString());
                String string = din.readLine();
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception) { }
            runtyp = 0;
        }
        if(runtyp == -166 || runtyp == -167 || runtyp == -168)
            pingstat();
    }

    public void stopchat()
    {
        clanchat = false;
        clangame = 0;
        if(runtyp == -101)
        {
            runtyp = 0;
            try
            {
                socket.close();
                socket = null;
                din.close();
                din = null;
                dout.close();
                dout = null;
            }
            catch(Exception exception) { }
        }
    }

    public void sendwin(CheckPoints checkpoints)
    {
        if(logged && multion == 1 && winner)
        {
            if(checkpoints.wasted == nplayers - 1)
                runtyp = -167;
            else
                runtyp = -168;
        } else
        {
            runtyp = -166;
        }
        runner = new Thread(this);
        runner.start();
    }

    public void loading()
    {
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 800, 450);
        rd.drawImage(sign, 362, 35, this);
        rd.drawImage(hello, 125, 105, this);
        rd.setColor(new Color(198, 214, 255));
        rd.fillRoundRect(250, 340, 300, 80, 30, 70);
        rd.setColor(new Color(128, 167, 255));
        rd.drawRoundRect(250, 340, 300, 80, 30, 70);
        rd.drawImage(loadbar, 281, 365, this);
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        drawcs(358, "Loading game, please wait.", 0, 0, 0, 3);
        rd.setColor(new Color(255, 255, 255));
        rd.fillRect(295, 398, 210, 17);
        shload += (((float)dnload + 10F) - shload) / 100F;
        if(shload > (float)kbload)
            shload = kbload;
        if(dnload == kbload)
            shload = kbload;
        drawcs(410, (new StringBuilder()).append("").append((int)(((26F + (shload / (float)kbload) * 200F) / 226F) * 100F)).append(" % loaded    |    ").append(kbload - (int)shload).append(" KB remaining").toString(), 32, 64, 128, 3);
        rd.setColor(new Color(32, 64, 128));
        rd.fillRect(287, 371, 26 + (int)((shload / (float)kbload) * 200F), 10);
    }

    public void stoploading()
    {
        loading();
        app.repaint();
        runtyp = 0;
    }

    public void clicknow()
    {
        rd.setColor(new Color(198, 214, 255));
        rd.fillRoundRect(250, 340, 300, 80, 30, 70);
        rd.setColor(new Color(128, 167, 255));
        rd.drawRoundRect(250, 340, 300, 80, 30, 70);
        if(aflk)
        {
            drawcs(380, "Click here to Start", 0, 0, 0, 3);
            aflk = false;
        } else
        {
            drawcs(380, "Click here to Start", 0, 67, 200, 3);
            aflk = true;
        }
    }

    public void stopallnow()
    {
        if(runner != null)
        {
            runner.stop();
            runner = null;
        }
        runtyp = 0;
        if(loadedt)
        {
            strack.unload();
            strack = null;
            loadedt = false;
        }
        for(int i = 0; i < 5; i++)
        {
            for(int i_19 = 0; i_19 < 5; i_19++)
            {
                engs[i][i_19].stop();
                engs[i][i_19] = null;
            }

        }

        for(int i = 0; i < 6; i++)
        {
            air[i].stop();
            air[i] = null;
        }

        wastd.stop();
        intertrack.unload();
        intertrack = null;
    }

    public void resetstat(int i)
    {
        arrace = false;
        alocked = -1;
        lalocked = -1;
        cntflock = 90;
        onlock = false;
        ana = 0;
        cntan = 0;
        cntovn = 0;
        tcnt = 30;
        wasay = false;
        clear = 0;
        dmcnt = 0;
        pwcnt = 0;
        auscnt = 45;
        pnext = 0;
        pback = 0;
        starcnt = 130;
        gocnt = 3;
        grrd = true;
        aird = true;
        bfcrash = 0;
        bfscrape = 0;
        cntwis = 0;
        bfskid = 0;
        pwait = 7;
        forstart = 200;
        exitm = 0;
        holdcnt = 0;
        holdit = false;
        winner = false;
        wasted = 0;
        for(int i_20 = 0; i_20 < 8; i_20++)
        {
            dested[i_20] = 0;
            isbot[i_20] = false;
            dcrashes[i_20] = 0;
        }

        runtyp = 0;
        discon = 0;
        dnload = 0;
        beststunt = 0;
        laptime = 0;
        fastestlap = 0;
        sendstat = 0;
        if(fase == 2 || fase == -22)
            sortcars(i);
        if(fase == 22)
        {
            for(int i_21 = 0; i_21 < 2; i_21++)
            {
                for(int i_22 = 0; i_22 < 7; i_22++)
                {
                    cnames[i_21][i_22] = "";
                    sentn[i_21][i_22] = "";
                }

                if(i_21 == 0)
                    cnames[i_21][6] = "Game Chat  ";
                else
                    cnames[i_21][6] = (new StringBuilder()).append("").append(clan).append("'s Chat  ").toString();
                updatec[i_21] = -1;
                movepos[i_21] = 0;
                pointc[i_21] = 6;
                floater[i_21] = 0;
                cntchatp[i_21] = 0;
                msgflk[i_21] = 0;
                lcmsg[i_21] = "";
            }

            if(multion == 3)
                ransay = 6;
            else
            if(ransay == 0)
            {
                ransay = 1 + (int)(Math.random() * 5D);
            } else
            {
                ransay++;
                if(ransay > 5)
                    ransay = 1;
            }
        }
    }

    public void setbots(boolean bools[], int is[][])
    {
        for(int i = 0; i < nplayers; i++)
            if(plnames[i].indexOf("MadBot") != -1)
            {
                bools[i] = true;
                isbot[i] = true;
            }

    }

    public void rad(int i)
    {
        if(i == 0)
        {
            powerup.play();
            radpx = 212;
            pin = 0;
        }
        trackbg(false);
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(65, 135, 670, 59);
        if(pin != 0)
            rd.drawImage(radicalplay, radpx + (int)(8D * Math.random() - 4D), 135, null);
        else
            rd.drawImage(radicalplay, 212, 135, null);
        if(radpx != 212)
        {
            radpx += 40;
            if(radpx > 735)
                radpx = -388;
        } else
        if(pin != 0)
            pin--;
        if(i == 40)
        {
            radpx = 213;
            pin = 7;
        }
        if(radpx == 212)
        {
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            drawcs(185 + (int)(5F * m.random()), "Radicalplay.com", 112, 120, 143, 3);
        }
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        if(aflk)
        {
            drawcs(215, "And we are never going to find the new unless we get a little crazy...", 112, 120, 143, 3);
            aflk = false;
        } else
        {
            drawcs(217, "And we are never going to find the new unless we get a little crazy...", 150, 150, 150, 3);
            aflk = true;
        }
        rd.drawImage(rpro, 275, 265, null);
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        rd.fillRect(65, 0, 670, 25);
        rd.fillRect(65, 425, 670, 25);
    }

    public void credits(Control control, int i, int i_23, int i_24)
    {
        if(flipo == 0)
        {
            powerup.play();
            flipo = 1;
        }
        if(flipo >= 1 && flipo <= 100)
        {
            rad(flipo);
            flipo++;
            if(flipo == 100)
                flipo = 1;
        }
        if(flipo == 101)
        {
            mainbg(-1);
            rd.drawImage(mdness, 283, 32, null);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(90, "At Radicalplay.com", 0, 0, 0, 3);
            drawcs(145, "Cartoon 3D Engine, Game Programming, 3D Models, Graphics and Sound Effects", 0, 0, 0, 3);
            drawcs(165, "By Omar Waly", 40, 60, 0, 3);
            drawcs(185, "- Soundtracks engine, screen gadgets and other addons by Dany Fern\341ndez (DragShot) -", 40, 60, 0, 3);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(225, "Special Thanks!", 0, 0, 0, 3);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            drawcs(245, "Thanks to Dany Fern\341ndez D\355az (DragShot) for improving the game\u2019s music player to play more mod formats & effects!", 66, 98, 0, 3);
            drawcs(260, "Thanks to Badie El Zaman (Kingofspeed) for helping make the trees & cactus 3D models.", 66, 98, 0, 3);
            drawcs(275, "Thanks to Timothy Audrain Hardin (Legnak) for making hazard designs on stage parts & the new fence 3D model.", 66, 98, 0, 3);
            drawcs(290, "Thanks to Alex Miles (A-Mile) & Jaroslav Beleren (Phyrexian) for making trailer videos for the game.", 66, 98, 0, 3);
            drawcs(305, "A big thank you to everyone playing the game for sending their feedback, supporting the game and helping it improve!", 66, 98, 0, 3);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(345, "Music from ModArchive.org", 0, 0, 0, 3);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            drawcs(365, "Most of the tracks where remixed by Omar Waly to match the game.", 66, 98, 0, 3);
            drawcs(380, "More details about the tracks and their original composers at:", 66, 98, 0, 3);
            drawcs(395, "http://multiplayer.needformadness.com/music.html", 33, 49, 0, 3);
            rd.drawLine(400 - ftm.stringWidth("http://multiplayer.needformadness.com/music.html") / 2, 396, ftm.stringWidth("http://multiplayer.needformadness.com/music.html") / 2 + 400, 396);
            if(i > 258 && i < 542 && i_23 > 385 && i_23 < 399)
            {
                app.setCursor(new Cursor(12));
                if(i_24 == 2)
                    app.musiclink();
            } else
            {
                app.setCursor(new Cursor(0));
            }
        }
        if(flipo == 102)
        {
            mainbg(0);
            rd.drawImage(nfmcom, 190, 195, null);
            if(i > 190 && i < 609 && i_23 > 195 && i_23 < 216)
            {
                app.setCursor(new Cursor(12));
                if(i_24 == 2)
                    app.madlink();
            } else
            {
                app.setCursor(new Cursor(0));
            }
        }
        rd.drawImage(next[pnext], 665, 395, null);
        if(control.enter || control.handb || control.right)
        {
            if(flipo >= 1 && flipo <= 100)
            {
                flipo = 101;
                app.setCursor(new Cursor(0));
            } else
            {
                flipo++;
            }
            if(flipo == 103)
            {
                flipo = 0;
                fase = 10;
            }
            control.enter = false;
            control.handb = false;
            control.right = false;
        }
    }

    public void trackbg(boolean bool)
    {
        int i = 0;
        trkl++;
        if(trkl > trklim)
        {
            i = 1;
            trklim = (int)(Math.random() * 40D);
            trkl = 0;
        }
        if(bool)
            i = 0;
        for(int i_25 = 0; i_25 < 2; i_25++)
        {
            rd.drawImage(trackbg[i], trkx[i_25], 25, null);
            trkx[i_25] -= 10;
            if(trkx[i_25] <= -605)
                trkx[i_25] = 735;
        }

        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        rd.fillRect(65, 0, 670, 25);
        rd.fillRect(65, 425, 670, 25);
    }

    public void mainbg(int i)
    {
        int i_26 = 2;
        rd.setColor(new Color(191, 184, 124));
        if(i == -1)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = -400;
                bgup = false;
                bgf = 0.0F;
                lmode = i;
            }
            rd.setColor(new Color(144, 222, 9));
            i_26 = 8;
        }
        if(i == 0)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = -400;
                bgup = false;
                bgf = 0.0F;
                lmode = i;
            }
            int i_27 = (int)(255F * bgf + 191F * (1.0F - bgf));
            int i_28 = (int)(176F * bgf + 184F * (1.0F - bgf));
            int i_29 = (int)(67F * bgf + 124F * (1.0F - bgf));
            if(!bgup)
            {
                bgf += 0.02F;
                if(bgf > 0.9F)
                {
                    bgf = 0.9F;
                    bgup = true;
                }
            } else
            {
                bgf -= 0.02F;
                if(bgf < 0.2F)
                {
                    bgf = 0.2F;
                    bgup = false;
                }
            }
            rd.setColor(new Color(i_27, i_28, i_29));
            i_26 = 4;
        }
        if(i == 1)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = -400;
                lmode = i;
            }
            rd.setColor(new Color(255, 176, 67));
            i_26 = 8;
        }
        if(i == 2)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = -400;
                lmode = i;
                bgf = 0.2F;
            }
            rd.setColor(new Color(188, 170, 122));
            if(flipo == 17)
            {
                int i_30 = (int)(176F * bgf + 191F * (1.0F - bgf));
                int i_31 = (int)(202F * bgf + 184F * (1.0F - bgf));
                int i_32 = (int)(255F * bgf + 124F * (1.0F - bgf));
                rd.setColor(new Color(i_30, i_31, i_32));
                bgf += 0.025F;
                if(bgf > 0.85F)
                    bgf = 0.85F;
            } else
            {
                bgf = 0.2F;
            }
            i_26 = 2;
        }
        if(i == 3)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = -400;
                bgup = false;
                bgf = 0.0F;
                lmode = i;
            }
            int i_33 = (int)(255F * bgf + 191F * (1.0F - bgf));
            int i_34 = (int)(176F * bgf + 184F * (1.0F - bgf));
            int i_35 = (int)(67F * bgf + 124F * (1.0F - bgf));
            if(!bgup)
            {
                bgf += 0.02F;
                if(bgf > 0.9F)
                {
                    bgf = 0.9F;
                    bgup = true;
                }
            } else
            {
                bgf -= 0.02F;
                if(bgf < 0.2F)
                {
                    bgf = 0.2F;
                    bgup = false;
                }
            }
            rd.setColor(new Color(i_33, i_34, i_35));
            i_26 = 2;
        }
        if(i != -101)
            if(i == 4)
            {
                rd.setColor(new Color(216, 177, 100));
                rd.fillRect(65, 0, 670, 425);
            } else
            {
                rd.fillRect(65, 25, 670, 400);
            }
        if(i == 4)
        {
            if(i != lmode)
            {
                bgmy[0] = 0;
                bgmy[1] = 400;
                for(int i_36 = 0; i_36 < 4; i_36++)
                {
                    ovw[i_36] = (int)(50D + 150D * Math.random());
                    ovh[i_36] = (int)(50D + 150D * Math.random());
                    ovy[i_36] = (int)(400D * Math.random());
                    ovx[i_36] = (int)(Math.random() * 670D);
                    ovsx[i_36] = (int)(5D + Math.random() * 10D);
                }

                lmode = i;
            }
            for(int i_37 = 0; i_37 < 4; i_37++)
            {
                rd.setColor(new Color(235, 176, 84));
                rd.fillOval((int)((double)(65 + ovx[i_37]) - ((double)ovw[i_37] * 1.5D) / 2D), (int)((double)(25 + ovy[i_37]) - ((double)ovh[i_37] * 1.5D) / 2D), (int)((double)ovw[i_37] * 1.5D), (int)((double)ovh[i_37] * 1.5D));
                rd.setColor(new Color(255, 176, 67));
                rd.fillOval((65 + ovx[i_37]) - ovh[i_37] / 2, (25 + ovy[i_37]) - ovh[i_37] / 2, ovw[i_37], ovh[i_37]);
                ovx[i_37] -= ovsx[i_37];
                if((double)ovx[i_37] + ((double)ovw[i_37] * 1.5D) / 2D < 0.0D)
                {
                    ovw[i_37] = (int)(50D + 150D * Math.random());
                    ovh[i_37] = (int)(50D + 150D * Math.random());
                    ovy[i_37] = (int)(400D * Math.random());
                    ovx[i_37] = (int)(670D + ((double)ovw[i_37] * 1.5D) / 2D);
                    ovsx[i_37] = (int)(5D + Math.random() * 10D);
                }
            }

        }
        if(i != -101 && i != 4)
        {
            for(int i_38 = 0; i_38 < 2; i_38++)
            {
                if(i != 2 || flipo != 17)
                    rd.drawImage(bgmain, 65, 25 + bgmy[i_38], null);
                bgmy[i_38] += i_26;
                if(bgmy[i_38] >= 400)
                    bgmy[i_38] = -400;
            }

        }
        if(i == 2 && flipo == 17)
        {
            rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
            rd.drawImage(dude[0], 650, 285, null);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        if(i != 4)
            rd.fillRect(65, 0, 670, 25);
        rd.fillRect(65, 425, 670, 25);
    }

    public void inishstageselect(CheckPoints checkpoints)
    {
        if(checkpoints.stage == -2 && (cd.msloaded != 1 || !logged))
        {
            checkpoints.stage = (int)(Math.random() * 32D) + 1;
            checkpoints.top20 = 0;
        }
        if(checkpoints.stage > 32)
            checkpoints.stage = (int)(Math.random() * 32D) + 1;
        if(checkpoints.stage == -2)
        {
            boolean bool = false;
            for(int i = 1; i < app.mstgs.getItemCount(); i++)
                if(app.mstgs.getItem(i).equals(checkpoints.name))
                    bool = true;

            if(!bool)
                checkpoints.stage = (int)(Math.random() * 32D) + 1;
        }
        if(gmode == 1)
        {
            if(unlocked[0] != 11 || justwon1)
                checkpoints.stage = unlocked[0];
            else
            if(winner || checkpoints.stage > 11)
                checkpoints.stage = (int)(Math.random() * 11D) + 1;
            if(checkpoints.stage == 11)
                checkpoints.stage = 27;
        }
        if(gmode == 2)
            if(unlocked[0] != 17 || justwon2)
                checkpoints.stage = unlocked[1] + 10;
            else
            if(winner || checkpoints.stage < 11)
                checkpoints.stage = (int)(Math.random() * 17D) + 11;
        app.sgame.setBackground(new Color(0, 0, 0));
        app.sgame.setForeground(new Color(47, 179, 255));
        app.snfm1.setBackground(new Color(0, 0, 0));
        app.snfm1.setForeground(new Color(47, 179, 255));
        app.snfm2.setBackground(new Color(0, 0, 0));
        app.snfm2.setForeground(new Color(47, 179, 255));
        app.snfmm.setBackground(new Color(0, 0, 0));
        app.snfmm.setForeground(new Color(47, 179, 255));
        app.mstgs.setBackground(new Color(0, 0, 0));
        app.mstgs.setForeground(new Color(47, 179, 255));
        app.gmode.setBackground(new Color(49, 49, 0));
        app.gmode.setForeground(new Color(148, 167, 0));
        nplayers = prevGmod != 0 ? 1 : 7;
        app.sgame.removeAll();
        app.sgame.add(rd, " NFM 1     ");
        app.sgame.add(rd, " NFM 2     ");
        app.sgame.add(rd, " My Stages ");
        app.sgame.add(rd, " Weekly Top20 ");
        app.sgame.add(rd, " Monthly Top20 ");
        app.sgame.add(rd, " All-Times Top20 ");
        app.sgame.add(rd, " Stage Maker ");
        app.sgame.add(rd, " NFM Multiplayer");
        if(checkpoints.stage > 0 && checkpoints.stage <= 10)
        {
            app.sgame.select(0);
            nfmtab = 0;
        }
        if(checkpoints.stage > 10 && checkpoints.stage <= 27)
        {
            app.sgame.select(1);
            nfmtab = 1;
        }
        if(checkpoints.stage > 27)
        {
            app.sgame.select(7);
            nfmtab = 7;
        }
        if(checkpoints.stage == -2)
        {
            app.sgame.select(2);
            nfmtab = 2;
        }
        if(checkpoints.stage == -1)
        {
            app.sgame.select(6);
            nfmtab = 6;
        }
        removeds = 0;
        lfrom = 0;
        cd.staction = 0;
        fase = 2;
    }

    public void loadingstage(int i, boolean bool)
    {
        trackbg(true);
        rd.drawImage(br, 65, 25, null);
        rd.setColor(new Color(212, 214, 138));
        rd.fillRoundRect(265, 201, 270, 26, 20, 40);
        rd.setColor(new Color(57, 64, 8));
        rd.drawRoundRect(265, 201, 270, 26, 20, 40);
        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        drawcs(219, "Loading, please wait...", 58, 61, 17, 3);
        if(bool)
            rd.drawImage(select, 338, 35, null);
        app.repaint();
        if(cd.staction != 0)
        {
            app.tnick.hide();
            app.tpass.hide();
            cd.staction = 0;
        }
        removeds = 0;
    }

    public void cantgo(Control control)
    {
        pnext = 0;
        trackbg(false);
        rd.drawImage(br, 65, 25, null);
        rd.drawImage(select, 338, 35, null);
        rd.setFont(new Font("Arial", 1, 13));
        ftm = rd.getFontMetrics();
        drawcs(130, (new StringBuilder()).append("This stage will be unlocked when stage ").append(unlocked[gmode - 1]).append(" is complete!").toString(), 177, 177, 177, 3);
        for(int i = 0; i < 9; i++)
            rd.drawImage(pgate, 277 + i * 30, 215, null);

        rd.setFont(new Font("Arial", 1, 12));
        ftm = rd.getFontMetrics();
        if(aflk)
        {
            drawcs(185, (new StringBuilder()).append("[ Stage ").append(unlocked[gmode - 1] + 1).append(" Locked ]").toString(), 255, 128, 0, 3);
            aflk = false;
        } else
        {
            drawcs(185, (new StringBuilder()).append("[ Stage ").append(unlocked[gmode - 1] + 1).append(" Locked ]").toString(), 255, 0, 0, 3);
            aflk = true;
        }
        rd.drawImage(back[pback], 370, 345, null);
        lockcnt--;
        if(lockcnt == 0 || control.enter || control.handb || control.left)
        {
            control.left = false;
            control.handb = false;
            control.enter = false;
            fase = 1;
        }
    }

    public void stageselect(CheckPoints checkpoints, Control control, int i, int i_39, boolean bool)
    {
        rd.drawImage(br, 65, 25, null);
        rd.drawImage(select, 338, 35, null);
        if(testdrive != 3 && testdrive != 4)
        {
            if(checkpoints.stage > 0 && cd.staction == 0)
            {
                if(checkpoints.stage != 1 && (checkpoints.stage != 11 || gmode != 2))
                    rd.drawImage(back[pback], 115, 135, null);
                if((gmode == 1 || gmode == 2) && checkpoints.stage != 27)
                    rd.drawImage(next[pnext], 625, 135, null);
                else
                if(gmode == 0 && checkpoints.stage != 32)
                    rd.drawImage(next[pnext], 625, 135, null);
            }
            if(gmode == 0)
            {
                boolean bool_40 = false;
                int i_41 = 0;
                if(nfmtab != app.sgame.getSelectedIndex())
                {
                    nfmtab = app.sgame.getSelectedIndex();
                    app.snfm1.select(0);
                    app.snfm2.select(0);
                    app.snfmm.select(0);
                    app.mstgs.select(0);
                    app.requestFocus();
                    bool_40 = true;
                }
                if(cd.staction == 5)
                {
                    if(lfrom == 0)
                    {
                        cd.staction = 0;
                        removeds = 1;
                        bool_40 = true;
                    } else
                    {
                        cd.onstage = checkpoints.name;
                        cd.staction = 2;
                        dnload = 2;
                    }
                    nickname = app.tnick.getText();
                    backlog = nickname;
                    nickey = cd.tnickey;
                    clan = cd.tclan;
                    clankey = cd.tclankey;
                    app.setloggedcookie();
                    logged = true;
                    gotlog = true;
                    if(cd.reco == 0)
                        acexp = 0;
                    if(cd.reco > 10)
                        acexp = cd.reco - 10;
                    if(cd.reco == 3)
                        acexp = -1;
                    if(cd.reco == 111)
                        if(!backlog.toLowerCase().equals(nickname.toLowerCase()))
                            acexp = -3;
                        else
                            acexp = 0;
                }
                if(nfmtab == 2 && cd.staction == 0 && removeds == 1)
                    checkpoints.stage = -3;
                if(app.openm && cd.staction == 3)
                {
                    app.tnick.hide();
                    app.tpass.hide();
                    cd.staction = 0;
                }
                int i_42 = 0;
                app.sgame.setSize(131, 22);
                if(app.sgame.getSelectedIndex() == 0)
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.snfm1.getWidth()) / 2;
                if(app.sgame.getSelectedIndex() == 1)
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.snfm2.getWidth()) / 2;
                if(app.sgame.getSelectedIndex() == 7)
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.snfmm.getWidth()) / 2;
                if(app.sgame.getSelectedIndex() == 2)
                {
                    app.mstgs.setSize(338, 22);
                    if(bool_40)
                        if(logged)
                        {
                            if(cd.msloaded != 1)
                            {
                                app.mstgs.removeAll();
                                app.mstgs.add(rd, "Loading your stages now, please wait...");
                                app.mstgs.select(0);
                                i_41 = 1;
                            }
                        } else
                        {
                            app.mstgs.removeAll();
                            app.mstgs.add(rd, "Please login first to load your stages...");
                            app.mstgs.select(0);
                            cd.msloaded = 0;
                            lfrom = 0;
                            cd.staction = 3;
                            showtf = false;
                            tcnt = 0;
                            cntflock = 0;
                            cd.reco = -2;
                        }
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.mstgs.getWidth()) / 2;
                }
                if(app.sgame.getSelectedIndex() == 3)
                {
                    app.mstgs.setSize(338, 22);
                    if(bool_40 && cd.msloaded != 3)
                    {
                        app.mstgs.removeAll();
                        app.mstgs.add(rd, "Loading Top20 list, please wait...");
                        app.mstgs.select(0);
                        i_41 = 3;
                    }
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.mstgs.getWidth()) / 2;
                }
                if(app.sgame.getSelectedIndex() == 4)
                {
                    app.mstgs.setSize(338, 22);
                    if(bool_40 && cd.msloaded != 4)
                    {
                        app.mstgs.removeAll();
                        app.mstgs.add(rd, "Loading Top20 list, please wait...");
                        app.mstgs.select(0);
                        i_41 = 4;
                    }
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.mstgs.getWidth()) / 2;
                }
                if(app.sgame.getSelectedIndex() == 5)
                {
                    app.mstgs.setSize(338, 22);
                    if(bool_40 && cd.msloaded != 5)
                    {
                        app.mstgs.removeAll();
                        app.mstgs.add(rd, "Loading Top20 list, please wait...");
                        app.mstgs.select(0);
                        i_41 = 5;
                    }
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.mstgs.getWidth()) / 2;
                }
                if(app.sgame.getSelectedIndex() == 6)
                {
                    if(cd.staction != 0)
                    {
                        app.tnick.hide();
                        app.tpass.hide();
                        cd.staction = 0;
                    }
                    app.mstgs.setSize(338, 22);
                    if(bool_40 && cd.msloaded != 2)
                    {
                        app.mstgs.removeAll();
                        app.mstgs.add(rd, "Loading Stage Maker stages, please wait...");
                        app.mstgs.select(0);
                        i_41 = 2;
                    }
                    i_42 = 400 - (app.sgame.getWidth() + 6 + app.mstgs.getWidth()) / 2;
                }
                if(!app.sgame.isShowing())
                    app.sgame.show();
                app.sgame.move(i_42, 62);
                i_42 += app.sgame.getWidth() + 6;
                if(nfmtab == 0)
                {
                    if(!app.snfm1.isShowing())
                    {
                        app.snfm1.show();
                        if(!bool_40 && checkpoints.stage > 0)
                            app.snfm1.select(checkpoints.stage);
                    }
                    app.snfm1.move(i_42, 62);
                    if(app.snfm2.isShowing())
                        app.snfm2.hide();
                    if(app.snfmm.isShowing())
                        app.snfmm.hide();
                    if(app.mstgs.isShowing())
                        app.mstgs.hide();
                }
                if(nfmtab == 1)
                {
                    if(!app.snfm2.isShowing())
                    {
                        app.snfm2.show();
                        if(!bool_40 && checkpoints.stage > 10)
                            app.snfm2.select(checkpoints.stage - 10);
                    }
                    app.snfm2.move(i_42, 62);
                    if(app.snfm1.isShowing())
                        app.snfm1.hide();
                    if(app.snfmm.isShowing())
                        app.snfmm.hide();
                    if(app.mstgs.isShowing())
                        app.mstgs.hide();
                }
                if(nfmtab == 2 || nfmtab == 3 || nfmtab == 4 || nfmtab == 5 || nfmtab == 6)
                {
                    if(!app.mstgs.isShowing())
                    {
                        app.mstgs.show();
                        if(!bool_40)
                            app.mstgs.select(checkpoints.name);
                    }
                    app.mstgs.move(i_42, 62);
                    if(app.snfm1.isShowing())
                        app.snfm1.hide();
                    if(app.snfm2.isShowing())
                        app.snfm2.hide();
                    if(app.snfmm.isShowing())
                        app.snfmm.hide();
                }
                if(nfmtab == 7)
                {
                    if(!app.snfmm.isShowing())
                    {
                        app.snfmm.show();
                        if(!bool_40 && checkpoints.stage > 27)
                            app.snfmm.select(checkpoints.stage - 27);
                    }
                    app.snfmm.move(i_42, 62);
                    if(app.snfm1.isShowing())
                        app.snfm1.hide();
                    if(app.snfm2.isShowing())
                        app.snfm2.hide();
                    if(app.mstgs.isShowing())
                        app.mstgs.hide();
                }
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(cd.staction == 0 || cd.staction == 6)
                    if(checkpoints.stage != -3)
                    {
                        String string = "";
                        if(checkpoints.top20 >= 3)
                            string = (new StringBuilder()).append("N#").append(checkpoints.nto).append("  ").toString();
                        if(aflk)
                        {
                            drawcs(132, (new StringBuilder()).append(string).append(checkpoints.name).toString(), 240, 240, 240, 3);
                            aflk = false;
                        } else
                        {
                            drawcs(132, (new StringBuilder()).append(string).append(checkpoints.name).toString(), 176, 176, 176, 3);
                            aflk = true;
                        }
                        if(checkpoints.stage == -2 && cd.staction == 0)
                        {
                            rd.setFont(new Font("Arial", 1, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(255, 176, 85));
                            if(checkpoints.maker.equals(nickname))
                                rd.drawString("Created by You", 70, 115);
                            else
                                rd.drawString((new StringBuilder()).append("Created by :  ").append(checkpoints.maker).append("").toString(), 70, 115);
                            if(checkpoints.top20 >= 3)
                                rd.drawString((new StringBuilder()).append("Added by :  ").append(cd.top20adds[checkpoints.nto - 1]).append(" Players").toString(), 70, 135);
                        }
                    } else
                    if(removeds != 1)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        drawcs(132, "Failed to load stage...", 255, 138, 0, 3);
                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        if(nfmtab == 6)
                            drawcs(155, "Please Test Drive this stage in the Stage Maker to make sure it can be loaded!", 255, 138, 0, 3);
                        if(nfmtab == 2 || nfmtab == 3 || nfmtab == 4 || nfmtab == 5)
                            drawcs(155, "It could be a connection error, please try again later.", 255, 138, 0, 3);
                        if(nfmtab == 1 || nfmtab == 0 || nfmtab == 7)
                        {
                            drawcs(155, "Will try to load another stage...", 255, 138, 0, 3);
                            app.repaint();
                            try
                            {
                                Thread.sleep(5000L);
                            }
                            catch(InterruptedException interruptedexception) { }
                            if(nfmtab == 0)
                                app.snfm1.select(1 + (int)(Math.random() * 10D));
                            if(nfmtab == 1)
                                app.snfm2.select(1 + (int)(Math.random() * 17D));
                            if(nfmtab == 7)
                                app.snfmm.select(1 + (int)(Math.random() * 5D));
                        }
                    }
                if(cd.staction == 3)
                {
                    drawdprom(145, 170);
                    if(cd.reco == -2)
                        if(lfrom == 0)
                            drawcs(171, "Login to Retrieve your Account Stages", 0, 0, 0, 3);
                        else
                            drawcs(171, "Login to add this stage to your account.", 0, 0, 0, 3);
                    if(cd.reco == -1)
                        drawcs(171, "Unable to connect to server, try again later!", 0, 8, 0, 3);
                    if(cd.reco == 1)
                        drawcs(171, "Sorry.  The Nickname you have entered is incorrect.", 0, 0, 0, 3);
                    if(cd.reco == 2)
                        drawcs(171, "Sorry.  The Password you have entered is incorrect.", 0, 0, 0, 3);
                    if(cd.reco == -167 || cd.reco == -177)
                    {
                        if(cd.reco == -167)
                        {
                            nickname = app.tnick.getText();
                            backlog = nickname;
                            cd.reco = -177;
                        }
                        drawcs(171, "You are currently using a trial account.", 0, 0, 0, 3);
                    }
                    if(cd.reco == -3 && (tcnt % 3 != 0 || tcnt > 20))
                        drawcs(171, "Please enter your Nickname!", 0, 0, 0, 3);
                    if(cd.reco == -4 && (tcnt % 3 != 0 || tcnt > 20))
                        drawcs(171, "Please enter your Password!", 0, 0, 0, 3);
                    if(!showtf)
                    {
                        app.tnick.setBackground(new Color(206, 237, 255));
                        if(cd.reco != 1)
                        {
                            if(cd.reco != 2)
                                app.tnick.setText(nickname);
                            app.tnick.setForeground(new Color(0, 0, 0));
                        } else
                        {
                            app.tnick.setForeground(new Color(255, 0, 0));
                        }
                        app.tnick.requestFocus();
                        app.tpass.setBackground(new Color(206, 237, 255));
                        if(cd.reco != 2)
                        {
                            if(!autolog)
                                app.tpass.setText("");
                            app.tpass.setForeground(new Color(0, 0, 0));
                        } else
                        {
                            app.tpass.setForeground(new Color(255, 0, 0));
                        }
                        if(!app.tnick.getText().equals("") && cd.reco != 1)
                            app.tpass.requestFocus();
                        showtf = true;
                    }
                    rd.drawString("Nickname:", 376 - ftm.stringWidth("Nickname:") - 14, 201);
                    rd.drawString("Password:", 376 - ftm.stringWidth("Password:") - 14, 231);
                    app.movefieldd(app.tnick, 376, 185, 129, 23, true);
                    app.movefieldd(app.tpass, 376, 215, 129, 23, true);
                    if(tcnt < 30)
                    {
                        tcnt++;
                        if(tcnt == 30)
                        {
                            if(cd.reco == 2)
                                app.tpass.setText("");
                            app.tnick.setForeground(new Color(0, 0, 0));
                            app.tpass.setForeground(new Color(0, 0, 0));
                        }
                    }
                    if(cd.reco != -177)
                    {
                        if((drawcarb(true, null, "       Login       ", 347, 247, i, i_39, bool) || control.handb || control.enter) && tcnt > 5)
                        {
                            tcnt = 0;
                            if(!app.tnick.getText().equals("") && !app.tpass.getText().equals(""))
                            {
                                autolog = false;
                                app.tnick.hide();
                                app.tpass.hide();
                                app.requestFocus();
                                cd.staction = 4;
                                cd.sparkstageaction();
                            } else
                            {
                                if(app.tpass.getText().equals(""))
                                    cd.reco = -4;
                                if(app.tnick.getText().equals(""))
                                    cd.reco = -3;
                            }
                        }
                    } else
                    if(drawcarb(true, null, "  Upgrade to have your own stages!  ", 277, 247, i, i_39, bool) && cntflock == 0)
                    {
                        app.editlink(nickname, true);
                        cntflock = 100;
                    }
                    if(drawcarb(true, null, "  Cancel  ", 409, 282, i, i_39, bool))
                    {
                        app.tnick.hide();
                        app.tpass.hide();
                        app.requestFocus();
                        cd.staction = 0;
                    }
                    if(drawcarb(true, null, "  Register!  ", 316, 282, i, i_39, bool))
                    {
                        if(cntflock == 0)
                        {
                            app.reglink();
                            cntflock = 100;
                        }
                    } else
                    if(cntflock != 0)
                        cntflock--;
                }
                if(cd.staction == 4)
                {
                    drawdprom(145, 170);
                    drawcs(195, "Logging in to your account...", 0, 0, 0, 3);
                }
                if(checkpoints.stage == -2 && cd.msloaded == 1 && checkpoints.top20 < 3 && !app.openm && drawcarb(true, null, "X", 609, 113, i, i_39, bool))
                    cd.staction = 6;
                if(cd.staction == -1 && checkpoints.top20 < 3)
                {
                    removeds = 0;
                    drawdprom(145, 95);
                    drawcs(175, "Failed to remove stage from your account, try again later.", 0, 0, 0, 3);
                    if(drawcarb(true, null, " OK ", 379, 195, i, i_39, bool))
                        cd.staction = 0;
                }
                if(cd.staction == 1)
                {
                    drawdprom(145, 95);
                    drawcs(195, "Removing stage from your account...", 0, 0, 0, 3);
                    removeds = 1;
                }
                if(cd.staction == 6)
                {
                    drawdprom(145, 95);
                    drawcs(175, "Remove this stage from your account?", 0, 0, 0, 3);
                    if(drawcarb(true, null, " Yes ", 354, 195, i, i_39, bool))
                    {
                        cd.onstage = app.mstgs.getSelectedItem();
                        cd.staction = 1;
                        cd.sparkstageaction();
                    }
                    if(drawcarb(true, null, " No ", 408, 195, i, i_39, bool))
                        cd.staction = 0;
                }
                if(i_41 == 1)
                {
                    app.drawms();
                    app.repaint();
                    cd.loadmystages(checkpoints);
                }
                if(i_41 >= 3)
                {
                    app.drawms();
                    app.repaint();
                    cd.loadtop20(i_41);
                }
                if(i_41 == 2)
                {
                    app.drawms();
                    app.repaint();
                    cd.loadstagemaker();
                }
                if(checkpoints.stage != -3 && cd.staction == 0 && checkpoints.top20 < 3)
                    rd.drawImage(contin[pcontin], 355, 360, null);
                else
                    pcontin = 0;
                if(checkpoints.top20 >= 3 && cd.staction != 3 && cd.staction != 4)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    if(dnload == 0 && drawcarb(true, null, " Add to My Stages ", 334, 355, i, i_39, bool))
                        if(logged)
                        {
                            cd.onstage = checkpoints.name;
                            cd.staction = 2;
                            cd.sparkstageaction();
                            dnload = 2;
                        } else
                        {
                            lfrom = 1;
                            cd.staction = 3;
                            showtf = false;
                            tcnt = 0;
                            cntflock = 0;
                            cd.reco = -2;
                        }
                    if(dnload == 2)
                    {
                        drawcs(370, "Adding stage please wait...", 193, 106, 0, 3);
                        if(cd.staction == 0)
                            dnload = 3;
                        if(cd.staction == -2)
                            dnload = 4;
                        if(cd.staction == -3)
                            dnload = 5;
                        if(cd.staction == -1)
                            dnload = 6;
                        if(dnload != 2)
                            cd.staction = 0;
                    }
                    if(dnload == 3)
                        drawcs(370, "Stage has been successfully added to your stages!", 193, 106, 0, 3);
                    if(dnload == 4)
                        drawcs(370, "You already have this stage!", 193, 106, 0, 3);
                    if(dnload == 5)
                        drawcs(370, "Cannot add more then 20 stages to your account!", 193, 106, 0, 3);
                    if(dnload == 6)
                        drawcs(370, "Failed to add stage, unknown error, please try again later.", 193, 106, 0, 3);
                }
                if(testdrive == 0 && checkpoints.top20 < 3)
                {
                    if(!app.gmode.isShowing())
                    {
                        app.gmode.select(prevGmod);
                        app.gmode.show();
                    }
                    app.gmode.move(400 - app.gmode.getWidth() / 2, 395);
                    if(control.up)
                    {
                        app.gmode.select(1);
                        control.up = false;
                    }
                    if(control.down)
                    {
                        app.gmode.select(0);
                        control.down = false;
                    }
                    if(app.gmode.getSelectedIndex() == 0 && nplayers != 7)
                    {
                        nplayers = 7;
                        prevGmod = 0;
                        fase = 2;
                        app.requestFocus();
                    }
                    if(app.gmode.getSelectedIndex() == 1 && nplayers != 1)
                    {
                        nplayers = 1;
                        prevGmod = 1;
                        fase = 2;
                        app.requestFocus();
                    }
                } else
                if(app.gmode.isShowing())
                    app.gmode.hide();
                if(nfmtab == 0 && app.snfm1.getSelectedIndex() != checkpoints.stage && app.snfm1.getSelectedIndex() != 0)
                {
                    checkpoints.stage = app.snfm1.getSelectedIndex();
                    checkpoints.top20 = 0;
                    checkpoints.nto = 0;
                    hidos();
                    fase = 2;
                    app.requestFocus();
                }
                if(nfmtab == 1 && app.snfm2.getSelectedIndex() != checkpoints.stage - 10 && app.snfm2.getSelectedIndex() != 0)
                {
                    checkpoints.stage = app.snfm2.getSelectedIndex() + 10;
                    checkpoints.top20 = 0;
                    checkpoints.nto = 0;
                    hidos();
                    fase = 2;
                    app.requestFocus();
                }
                if(nfmtab == 7 && app.snfmm.getSelectedIndex() != checkpoints.stage - 27 && app.snfmm.getSelectedIndex() != 0)
                {
                    checkpoints.stage = app.snfmm.getSelectedIndex() + 27;
                    checkpoints.top20 = 0;
                    checkpoints.nto = 0;
                    hidos();
                    fase = 2;
                    app.requestFocus();
                }
                if((nfmtab == 2 || nfmtab == 6) && !app.mstgs.getSelectedItem().equals(checkpoints.name) && app.mstgs.getSelectedIndex() != 0)
                {
                    if(nfmtab == 2)
                        checkpoints.stage = -2;
                    else
                        checkpoints.stage = -1;
                    checkpoints.name = app.mstgs.getSelectedItem();
                    checkpoints.top20 = 0;
                    checkpoints.nto = 0;
                    hidos();
                    fase = 2;
                    app.requestFocus();
                }
                if(nfmtab == 3 || nfmtab == 4 || nfmtab == 5)
                {
                    String string = "";
                    int i_43 = app.mstgs.getSelectedItem().indexOf(" ") + 1;
                    if(i_43 > 0)
                        string = app.mstgs.getSelectedItem().substring(i_43);
                    if(!string.equals("") && !string.equals(checkpoints.name) && app.mstgs.getSelectedIndex() != 0)
                    {
                        checkpoints.stage = -2;
                        checkpoints.name = string;
                        checkpoints.top20 = -cd.msloaded;
                        checkpoints.nto = app.mstgs.getSelectedIndex();
                        hidos();
                        fase = 2;
                        app.requestFocus();
                    }
                }
            } else
            {
                rd.setFont(new Font("SansSerif", 1, 13));
                ftm = rd.getFontMetrics();
                if(checkpoints.stage < 27)
                {
                    int i_40_ = checkpoints.stage;
                    if(i_40_ > 10)
                        i_40_ -= 10;
                    drawcs(80, (new StringBuilder()).append("Stage ").append(i_40_).append("  >").toString(), 255, 128, 0, 3);
                } else
                if(checkpoints.stage > 27)
                {
                    int i_40_ = checkpoints.stage - 27;
                    drawcs(80, (new StringBuilder()).append("Multiplayer Stage ").append(i_40_).append("  >").toString(), 255, 128, 0, 3);
                } else
                {
                    drawcs(80, "Final Party Stage  >", 255, 128, 0, 3);
                }
                if(aflk)
                {
                    drawcs(100, (new StringBuilder()).append("| ").append(checkpoints.name).append(" |").toString(), 240, 240, 240, 3);
                    aflk = false;
                } else
                {
                    drawcs(100, (new StringBuilder()).append("| ").append(checkpoints.name).append(" |").toString(), 176, 176, 176, 3);
                    aflk = true;
                }
                if(checkpoints.stage != -3)
                    rd.drawImage(contin[pcontin], 355, 360, null);
                else
                    pcontin = 0;
            }
            if(cd.staction == 0)
            {
                if((control.handb || control.enter) && checkpoints.stage != -3 && checkpoints.top20 < 3)
                {
                    app.gmode.hide();
                    hidos();
                    dudo = 150;
                    fase = 5;
                    control.handb = false;
                    control.enter = false;
                    intertrack.stop();
                    intertrack.unloadimod();
                    if(nplayers == 1)
                    {
                        chrono.reset();
                        chrono.setLaps(checkpoints.nlaps);
                        plnames[0] = nickname.trim().isEmpty() ? "You" : nickname;
                    } else
                    {
                        botnames();
                        if(checkpoints.stage == 22 && sc[0] != 13)
                            plnames[6] = "S A N T A";
                    }
                }
                if(checkpoints.stage > 0)
                {
                    if(control.right)
                    {
                        if(gmode == 0 || gmode == 1 && checkpoints.stage != unlocked[0] || gmode == 2 && checkpoints.stage != unlocked[1] + 10 || checkpoints.stage == 27)
                        {
                            boolean flk = false;
                            if((gmode == 1 || gmode == 2) && checkpoints.stage != 27)
                                flk = true;
                            else
                            if(gmode == 0 && checkpoints.stage != 32)
                                flk = true;
                            if(flk)
                            {
                                hidos();
                                checkpoints.stage++;
                                if(gmode == 1 && checkpoints.stage == 11)
                                    checkpoints.stage = 27;
                                if(checkpoints.stage > 27)
                                {
                                    app.sgame.select(7);
                                    nfmtab = 7;
                                } else
                                if(checkpoints.stage > 10)
                                {
                                    app.sgame.select(1);
                                    nfmtab = 1;
                                } else
                                {
                                    app.sgame.select(0);
                                    nfmtab = 0;
                                }
                                fase = 2;
                            }
                        } else
                        {
                            fase = 4;
                            lockcnt = 100;
                        }
                        control.right = false;
                    }
                    if(control.left && checkpoints.stage != 1 && (checkpoints.stage != 11 || gmode != 2))
                    {
                        hidos();
                        checkpoints.stage--;
                        if(gmode == 1 && checkpoints.stage == 26)
                            checkpoints.stage = 10;
                        if(checkpoints.stage > 27)
                        {
                            app.sgame.select(7);
                            nfmtab = 7;
                            app.snfmm.select(checkpoints.stage - 27);
                        } else
                        if(checkpoints.stage > 10)
                        {
                            app.sgame.select(1);
                            nfmtab = 1;
                        } else
                        {
                            app.sgame.select(0);
                            nfmtab = 0;
                        }
                        fase = 2;
                        control.left = false;
                    }
                }
            }
        } else
        {
            if(aflk)
            {
                drawcs(132, checkpoints.name, 240, 240, 240, 3);
                aflk = false;
            } else
            {
                drawcs(132, checkpoints.name, 176, 176, 176, 3);
                aflk = true;
            }
            rd.drawImage(contin[pcontin], 355, 360, null);
            if(control.handb || control.enter)
            {
                dudo = 150;
                fase = 5;
                control.handb = false;
                control.enter = false;
                intertrack.stop();
                intertrack.unloadimod();
                if(nplayers == 1)
                {
                    chrono.reset();
                    chrono.setLaps(checkpoints.nlaps);
                    plnames[0] = nickname.trim().isEmpty() ? "You" : nickname;
                } else
                {
                    botnames();
                }
            }
        }
        if(drawcarb(true, null, " Exit X ", 670, 30, i, i_39, bool))
        {
            fase = 102;
            if(gmode == 0)
                opselect = 3;
            if(gmode == 1)
                opselect = 0;
            if(gmode == 2)
                opselect = 1;
            app.gmode.hide();
            hidos();
            app.tnick.hide();
            app.tpass.hide();
            intertrack.stop();
        }
        if(gmode == 0)
        {
            rd.setColor(new Color(0, 0, 0, 100));
            rd.fillRoundRect(306, 335, 185, 16, 5, 5);
            rd.setColor(new Color(0x626c00));
            rd.fillRect(308, 337, 12, 12);
            rd.setColor(new Color(0xc9d37f));
            rd.fillRect(309, 338, 10, 10);
            rd.setColor(new Color(0x313100));
            rd.fillRect(310, 339, 8, 8);
            rd.setColor(new Color(0x94a700));
            if(notrees)
            {
                rd.drawLine(311, 343, 311, 344);
                for(int k = 0; k < 5; k++)
                    rd.drawLine(312 + k, 344 - k, 312 + k, 345 - k);

            }
            rd.drawString("Do not include piles/trees", 324, 348);
            boolean flk = bool && !treeflk;
            if(!bool && treeflk)
                treeflk = false;
            if(i > 306 && i < 491 && i_39 > 335 && i_39 < 351 && flk)
            {
                notrees = !notrees;
                treeflk = true;
                fase = 2;
            }
            rd.drawLine(398, 394, 402, 394);
            rd.drawLine(399, 393, 401, 393);
            rd.drawLine(400, 392, 400, 393);
            rd.drawLine(398, 419, 402, 419);
            rd.drawLine(399, 420, 401, 420);
            rd.drawLine(400, 421, 400, 420);
        }
    }

    public void botnames()
    {
        String botnames[] = {
            "Nobody", "BotsFTW", "TestSubject", "Clockwork", "Kaboom!", "Skipper", "Demopan", "MadBot", "Not-a-Bot", "Cratus", 
            "Trollgineer", "Ambassador", "Undertaker", "QuakerTeam", "ChaosBringer", "Savior", "Warlock", "Nova", "DarkenBoy", "Wanderer", 
            "AbyssKnight", "LaGeas", "OilDancer", "AerialBooster", "GunRunner", "Ghostrider", "Kompacter"
        };
        boolean flks[] = new boolean[botnames.length];
        plnames[0] = nickname.trim().isEmpty() ? "You" : nickname;
        int i = 1;
        do
        {
            if(i >= nplayers)
                break;
            int id = (int)(Math.random() * (double)botnames.length);
            id = id != botnames.length ? id : botnames.length - 1;
            if(!flks[id])
            {
                plnames[i] = botnames[id];
                flks[id] = true;
                i++;
            }
        } while(true);
    }

    public void hidos()
    {
        app.sgame.hide();
        app.snfm1.hide();
        app.snfm2.hide();
        app.snfmm.hide();
        app.mstgs.hide();
    }

    public void hipnoload(int i, boolean bool)
    {
        int is[];
        for(is = (new int[] {
    m.snap[0], m.snap[1], m.snap[2]
}); is[0] + is[1] + is[2] < -30;)
        {
            int i_45 = 0;
            while(i_45 < 3) 
            {
                if(is[i_45] < 50)
                    is[i_45]++;
                i_45++;
            }
        }

        int i_46 = (int)(230F - 230F * ((float)is[0] / 100F));
        if(i_46 > 255)
            i_46 = 255;
        if(i_46 < 0)
            i_46 = 0;
        int i_47 = (int)(230F - 230F * ((float)is[1] / 100F));
        if(i_47 > 255)
            i_47 = 255;
        if(i_47 < 0)
            i_47 = 0;
        int i_48 = (int)(230F - 230F * ((float)is[2] / 100F));
        if(i_48 > 255)
            i_48 = 255;
        if(i_48 < 0)
            i_48 = 0;
        rd.setColor(new Color(i_46, i_47, i_48));
        rd.fillRect(65, 25, 670, 400);
        rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
        rd.drawImage(bggo, 0, -25, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        rd.fillRect(65, 0, 670, 25);
        rd.fillRect(65, 425, 670, 25);
        rd.setFont(new Font("Arial", 1, 13));
        ftm = rd.getFontMetrics();
        drawcs(50, asay, 0, 0, 0, 3);
        int i_49 = -90;
        if(multion == 0)
        {
            if(i == 1 || i == 2 || i == 3 || i == 4 || i == 5 || i == 10)
                i_49 = 0;
            if(i == 11 || i == 12 || i == 13 || i == 14 || i == 17 || i == 18 || i == 19 || i == 20 || i == 22 || i == 23 || i == 26)
                i_49 = 0;
            if(i < 0 && nplayers != 1 && newparts)
                i_49 = 0;
        } else
        if(ransay >= 1 && ransay <= 6 || i == 10)
            i_49 = 0;
        if(i_49 == 0)
        {
            if(dudo > 0)
            {
                if(aflk)
                {
                    if(Math.random() > Math.random())
                        duds = (int)(Math.random() * 3D);
                    else
                        duds = (int)(Math.random() * 2D);
                    aflk = false;
                } else
                {
                    aflk = true;
                }
                dudo--;
            } else
            {
                duds = 0;
            }
            rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
            rd.drawImage(dude[duds], 95, 35, null);
            rd.setComposite(AlphaComposite.getInstance(3, 0.7F));
            rd.drawImage(flaot, 192, 67, null);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            i_46 = (int)(80F - 80F * ((float)is[0] / 100F));
            if(i_46 > 255)
                i_46 = 255;
            if(i_46 < 0)
                i_46 = 0;
            i_47 = (int)(80F - 80F * ((float)is[1] / 100F));
            if(i_47 > 255)
                i_47 = 255;
            if(i_47 < 0)
                i_47 = 0;
            i_48 = (int)(80F - 80F * ((float)is[2] / 100F));
            if(i_48 > 255)
                i_48 = 255;
            if(i_48 < 0)
                i_48 = 0;
            rd.setColor(new Color(i_46, i_47, i_48));
            rd.setFont(new Font("Arial", 1, 13));
            if(multion != 0)
            {
                if(ransay == 1 && i != 10)
                    rd.drawString("Multiplayer Tip:  Press [ C ] to access chat quickly during the game!", 262, 92);
                if(ransay == 2 && i != 10)
                {
                    rd.drawString("Multiplayer Tip:  Press [ A ] to make Guidance Arrow point to cars and", 262, 92);
                    rd.drawString("click any of the players listed on the right to lock the Arrow on!", 262, 112);
                }
                if(ransay == 3 && i != 10)
                {
                    rd.drawString("Multiplayer Tip:  When wasting in multiplayer it's better to aim slightly", 262, 92);
                    rd.drawString("ahead of the other player's car to compensate for internet delay.", 262, 112);
                }
                if(ransay == 4 && i != 10)
                {
                    rd.drawString("DS-addons Tip:  If you're constantly experiencing problems with your", 262, 92);
                    rd.drawString("framerate, you can use the menu to reduce the graphics quality in", 262, 112);
                    rd.drawString("stages with a lot of track pieces nearby.", 262, 132);
                }
                if(ransay == 5 && i != 10)
                {
                    rd.drawString("DS-addons Tip:  You can customize your in-game interface using", 262, 92);
                    rd.drawString("some keys and/or the top menu. There are 4 different skins available", 262, 112);
                    rd.drawString("to choose from.", 262, 132);
                }
                if(ransay == 6)
                {
                    rd.drawString("When watching a game, click any player listed on the right of the", 262, 92);
                    rd.drawString("screen to follow and watch.", 262, 112);
                    rd.drawString("Press [ V ] to change the viewing mode!", 262, 132);
                }
                if(i == 10 && ransay != 6)
                {
                    if(tflk)
                    {
                        rd.setColor(new Color(200, i_47, i_48));
                        tflk = false;
                    } else
                    {
                        tflk = true;
                    }
                    rd.drawString("NOTE: Guidance Arrow and opponent status is disabled in this stage!", 262, 92);
                }
            } else
            {
                if(i < 0 && nplayers != 1 && newparts)
                {
                    rd.drawString("Please note, the computer car's AI has not yet been trained to handle", 262, 92);
                    rd.drawString("some of the new stage parts such as the 'Rollercoaster Road' and the", 262, 112);
                    rd.drawString("'Tunnel Side Ramp'.", 262, 132);
                    rd.drawString("(Those new parts where mostly designed for the multiplayer game.)", 262, 152);
                    rd.drawString("The AI will be trained and ready in the future releases of the game!", 262, 172);
                }
                if(i == 1 || i == 11)
                {
                    rd.drawString("Hey!  Don't forget, to complete a lap you must pass through", 262, 92);
                    rd.drawString("all checkpoints in the track!", 262, 112);
                }
                if(i == 2 || i == 12)
                    rd.drawString("Remember, the more power you have the faster your car will be!", 262, 92);
                if(i == 3)
                {
                    rd.drawString("> Hint: its easier to waste the other cars then to race in this stage!", 262, 92);
                    rd.drawString("Press [ A ] to make the guidance arrow point to cars instead of to", 262, 112);
                    rd.drawString("the track.", 262, 132);
                }
                if(i == 4)
                    rd.drawString("Remember, the better the stunt you perform the more power you get!", 262, 92);
                if(i == 5)
                    rd.drawString("Remember, the more power you have the stronger your car is!", 262, 92);
                if(i == 10)
                {
                    if(tflk)
                    {
                        rd.setColor(new Color(200, i_47, i_48));
                        tflk = false;
                    } else
                    {
                        tflk = true;
                    }
                    rd.drawString("NOTE: Guidance Arrow is disabled in this stage!", 262, 92);
                }
                if(i == 13)
                {
                    rd.drawString("Watch out!  Look out!  The policeman might be out to get you!", 262, 92);
                    rd.drawString("Don't upset him or you'll be arrested!", 262, 112);
                    rd.drawString("Better run, run, run.", 262, 152);
                }
                if(i == 14)
                {
                    rd.drawString("Don't waste your time.  Waste them instead!", 262, 92);
                    rd.drawString("Try a taste of sweet revenge here (if you can)!", 262, 112);
                    rd.drawString("Press [ A ] to make the guidance arrow point to cars instead of to", 262, 152);
                    rd.drawString("the track.", 262, 172);
                }
                if(i == 17)
                {
                    rd.drawString("Welcome to the realm of the king...", 262, 92);
                    rd.drawString("The key word here is 'POWER'.  The more you have of it the faster", 262, 132);
                    rd.drawString("and STRONGER you car will be!", 262, 152);
                }
                if(i == 18)
                {
                    rd.drawString("Watch out, EL KING is out to get you now!", 262, 92);
                    rd.drawString("He seems to be seeking revenge?", 262, 112);
                    rd.drawString("(To fly longer distances in the air try drifting your car on the ramp", 262, 152);
                    rd.drawString("before take off).", 262, 172);
                }
                if(i == 19)
                    rd.drawString("It\u2019s good to be the king!", 262, 92);
                if(i == 20)
                {
                    rd.drawString("Remember, forward loops give your car a push forwards in the air", 262, 92);
                    rd.drawString("and help in racing.", 262, 112);
                    rd.drawString("(You may need to do more forward loops here.  Also try keeping", 262, 152);
                    rd.drawString("your power at maximum at all times.  Try not to miss a ramp).", 262, 172);
                }
                if(i == 22)
                {
                    rd.drawString("Watch out!  Beware!  Take care!", 262, 92);
                    rd.drawString("MASHEEN is hiding out there some where, don't get mashed now!", 262, 112);
                }
                if(i == 23)
                {
                    rd.drawString("Anyone for a game of Digger?!", 262, 92);
                    rd.drawString("You can have fun using MASHEEN here!", 262, 112);
                }
                if(i == 26)
                {
                    rd.drawString("This is it!  This is the toughest stage in the game!", 262, 92);
                    rd.drawString("This track is actually a 4D object projected onto the 3D world.", 262, 132);
                    rd.drawString("It's been broken down, separated and, in many ways, it is also a", 262, 152);
                    rd.drawString("maze!  GOOD LUCK!", 262, 172);
                }
            }
        }
        rd.setComposite(AlphaComposite.getInstance(3, 0.8F));
        rd.drawImage(loadingmusic, 289, 205 + i_49, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        int i_50 = i - 1;
        if(i_50 < 0)
            i_50 = 32;
        if(!bool)
        {
            drawcs(340 + i_49, (new StringBuilder()).append("").append(sndsize[i_50]).append(" KB").toString(), 0, 0, 0, 3);
            drawcs(375 + i_49, " Please Wait...", 0, 0, 0, 3);
        } else
        {
            drawcs(365 + i_49, "Loading complete!  Press Start to begin...", 0, 0, 0, 3);
            rd.setComposite(AlphaComposite.getInstance(3, 0.5F));
            rd.drawImage(star[pstar], 359, 385 + i_49, null);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            if(pstar != 2)
                if(pstar == 0)
                    pstar = 1;
                else
                    pstar = 0;
            if(multion != 0)
                drawcs(380 + i_49, (new StringBuilder()).append("").append(forstart / 20).toString(), 0, 0, 0, 3);
        }
        GadgetPainter.reset();
    }

    public void loadmusic(int i, String string, int i_51)
    {
        hipnoload(i, false);
        app.setCursor(new Cursor(3));
        app.repaint();
        boolean bool = false;
        if(multion == 0)
        {
            if(i == 1 || i == 2 || i == 3 || i == 4 || i == 5 || i == 10)
                bool = true;
            if(i == 11 || i == 12 || i == 13 || i == 14 || i == 17 || i == 18 || i == 19 || i == 20 || i == 22 || i == 23 || i == 26)
                bool = true;
            if(i < 0 && nplayers != 1 && newparts)
                bool = true;
        } else
        if(ransay >= 1 && ransay <= 6 || i == 10)
            bool = true;
        if(bool)
        {
            runtyp = i;
            runner = new Thread(this);
            runner.start();
        }
        if(i == 1)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 240, 8400, 135, false, false);
        if(i == 2)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 190, 9000, 145, false, false);
        if(i == 3)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 170, 8500, 145, false, false);
        if(i == 4)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 205, 7500, 125, false, false);
        if(i == 5)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 170, 7900, 125, false, false);
        if(i == 6)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 370, 7900, 125, false, false);
        if(i == 7)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 205, 7500, 125, false, false);
        if(i == 8)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 230, 7900, 125, false, false);
        if(i == 9)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 180, 7900, 125, false, false);
        if(i == 10)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 280, 8100, 145, false, false);
        if(i == 11)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 120, 8000, 125, false, false);
        if(i == 12)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 260, 7200, 125, false, false);
        if(i == 13)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 270, 8000, 125, false, false);
        if(i == 14)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 190, 8000, 125, false, false);
        if(i == 15)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 162, 7800, 125, false, false);
        if(i == 16)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 220, 7600, 125, false, false);
        if(i == 17)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 300, 7500, 125, false, false);
        if(i == 18)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 200, 7900, 125, false, false);
        if(i == 19)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 200, 7900, 125, false, false);
        if(i == 20)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 232, 7300, 125, false, false);
        if(i == 21)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 370, 7900, 125, false, false);
        if(i == 22)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 290, 7900, 125, false, false);
        if(i == 23)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 222, 7600, 125, false, false);
        if(i == 24)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 230, 8000, 125, false, false);
        if(i == 25)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 220, 8000, 125, false, false);
        if(i == 26)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 261, 8000, 125, false, false);
        if(i == 27)
            if(gmode == 2)
                strack = new RadicalMod("music/party.zip", 400, 7600, 125, false, false);
            else
                strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 276, 8800, 145, false, false);
        if(i == 28)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 182, 8000, 125, false, false);
        if(i == 29)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 220, 8000, 125, false, false);
        if(i == 30)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 200, 8000, 125, false, false);
        if(i == 31)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 350, 7900, 125, false, false);
        if(i == 32)
            strack = new RadicalMod((new StringBuilder()).append("music/stage").append(i).append(".zip").toString(), 310, 8000, 125, false, false);
        if(i < 0)
            if(!string.equals(""))
            {
                if(i != -2)
                    strack = new RadicalMod((new StringBuilder()).append("mystages/mymusic/").append(string).append(".zip").toString(), i_51, 8000, 125, false, false);
                else
                    strack = new RadicalMod(string, i_51, 8000, 125, false, true);
            } else
            {
                strack = new RadicalMod();
            }
        loadedt = true;
        if(bool)
        {
            runner.stop();
            runner = null;
            runtyp = 0;
        }
        System.gc();
        if(multion == 0 && macn)
            try
            {
                Thread.sleep(1000L);
            }
            catch(InterruptedException interruptedexception) { }
        if(!lan)
            strack.play();
        else
        if(im != 0)
            try
            {
                Thread.sleep(1000L);
            }
            catch(InterruptedException interruptedexception) { }
        app.setCursor(new Cursor(0));
        pcontin = 0;
        mutem = false;
        mutes = false;
        fase = 6;
    }

    public void musicomp(int i, Control control)
    {
        hipnoload(i, true);
        if(multion != 0)
        {
            forstart--;
            if(lan && im == 0)
                forstart = 0;
        }
        if(control.handb || control.enter || forstart == 0)
        {
            System.gc();
            m.trk = 0;
            m.crs = false;
            m.ih = 0;
            m.iw = 0;
            m.h = 450;
            m.w = 800;
            m.focus_point = 400;
            m.cx = 400;
            m.cy = 225;
            m.cz = 50;
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            if(multion == 0)
            {
                fase = 0;
            } else
            {
                fase = 7001;
                forstart = 0;
                if(!lan)
                    try
                    {
                        socket = new Socket(server, servport);
                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                        runtyp = -101;
                        runner = new Thread(this);
                        runner.start();
                    }
                    catch(Exception exception) { }
            }
            if(Math.random() > Math.random())
                dudo = 250;
            else
                dudo = 428;
            control.handb = false;
            control.enter = false;
        }
    }

    public void waitenter()
    {
        if(forstart < 690)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(70, "Waiting for all players to finish loading!", 0, 0, 0, 0);
            if(forstart <= 640)
                drawcs(90, (new StringBuilder()).append("").append((640 - forstart) / 32).append("").toString(), 0, 0, 0, 0);
            else
                drawcs(90, "Your connection to game may have been lost...", 0, 0, 0, 0);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            if(tflk)
            {
                drawcs(125, "Get Ready!", 0, 0, 0, 0);
                tflk = false;
            } else
            {
                drawcs(125, "Get Ready!", 0, 128, 255, 0);
                tflk = true;
            }
        }
        forstart++;
        if(forstart == 700)
        {
            fase = -2;
            winner = false;
        }
    }

    public void multistat(Control control, CheckPoints checkpoints, int i, int i_52, boolean bool, UDPMistro udpmistro)
    {
        bool &= Madness.gui;
        if(!Madness.gui)
            rd.setClip(new Rectangle(1, 1));
        int i_53 = -1;
        if(fase != -2)
        {
            if(exitm != 0 && !holdit)
            {
                if(!lan || im != 0)
                {
                    if(bool)
                        if(i > 357 && i < 396 && i_52 > 162 && i_52 < 179)
                        {
                            exitm = 2;
                            if(multion == 1 && !lan && sendstat == 0)
                            {
                                sendstat = 1;
                                if(runtyp != -101)
                                {
                                    if(runner != null)
                                        runner.stop();
                                    runner = new Thread(this);
                                    runner.start();
                                }
                            }
                        } else
                        {
                            exitm = 0;
                        }
                    float fs[] = new float[3];
                    Color.RGBtoHSB(m.cgrnd[0], m.cgrnd[1], m.cgrnd[2], fs);
                    fs[1] -= 0.14999999999999999D;
                    if(fs[1] < 0.0F)
                        fs[1] = 0.0F;
                    fs[2] += 0.14999999999999999D;
                    if(fs[2] > 1.0F)
                        fs[2] = 1.0F;
                    rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                    rd.fillRect(357, 169, 39, 10);
                    rd.fillRect(403, 169, 39, 10);
                    fs[1] -= 0.070000000000000007D;
                    if(fs[1] < 0.0F)
                        fs[1] = 0.0F;
                    fs[2] += 0.070000000000000007D;
                    if(fs[2] > 1.0F)
                        fs[2] = 1.0F;
                    rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                    rd.fillRect(357, 162, 39, 7);
                    rd.fillRect(403, 162, 39, 7);
                    drawhi(exitgame, 116);
                    if(i > 357 && i < 396 && i_52 > 162 && i_52 < 179)
                    {
                        rd.setColor(new Color(m.csky[0], m.csky[1], m.csky[2]));
                        rd.fillRect(357, 162, 39, 17);
                    }
                    if(i > 403 && i < 442 && i_52 > 162 && i_52 < 179)
                    {
                        rd.setColor(new Color(m.csky[0], m.csky[1], m.csky[2]));
                        rd.fillRect(403, 162, 39, 17);
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Yes", 366, 175);
                    rd.drawString("No", 416, 175);
                    rd.setColor(new Color(m.csky[0] / 2, m.csky[1] / 2, m.csky[2] / 2));
                    rd.drawRect(403, 162, 39, 17);
                    rd.drawRect(357, 162, 39, 17);
                } else
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    drawcs(125, "You cannot exit game.  Your computer is the LAN server!", 0, 0, 0, 0);
                    msgflk[0]++;
                    if(msgflk[0] == 67 || bool)
                    {
                        msgflk[0] = 0;
                        exitm = 0;
                    }
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                }
            } else
            if(exitm == 4)
            {
                if(bool)
                {
                    if(i > 357 && i < 396 && i_52 > 362 && i_52 < 379)
                    {
                        alocked = -1;
                        lalocked = -1;
                        multion = 2;
                        control.multion = multion;
                        holdit = false;
                        exitm = 0;
                        control.chatup = 0;
                    }
                    if((!lan || im != 0) && i > 403 && i < 442 && i_52 > 362 && i_52 < 379)
                    {
                        holdcnt = 600;
                        exitm = 0;
                        control.chatup = 0;
                    }
                }
                float fs[] = new float[3];
                Color.RGBtoHSB(m.cgrnd[0], m.cgrnd[1], m.cgrnd[2], fs);
                fs[1] -= 0.14999999999999999D;
                if(fs[1] < 0.0F)
                    fs[1] = 0.0F;
                fs[2] += 0.14999999999999999D;
                if(fs[2] > 1.0F)
                    fs[2] = 1.0F;
                rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                rd.fillRect(357, 369, 39, 10);
                if(!lan || im != 0)
                    rd.fillRect(403, 369, 39, 10);
                fs[1] -= 0.070000000000000007D;
                if(fs[1] < 0.0F)
                    fs[1] = 0.0F;
                fs[2] += 0.070000000000000007D;
                if(fs[2] > 1.0F)
                    fs[2] = 1.0F;
                rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                rd.fillRect(357, 362, 39, 7);
                if(!lan || im != 0)
                    rd.fillRect(403, 362, 39, 7);
                rd.setColor(new Color(0, 0, 0));
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(lan && im == 0)
                    drawcs(140, "( You cannot exit game.  Your computer is the LAN server... )", 0, 0, 0, 0);
                rd.drawString("Continue watching this game?", 155, 375);
                if(i > 357 && i < 396 && i_52 > 362 && i_52 < 379)
                {
                    rd.setColor(new Color(m.csky[0], m.csky[1], m.csky[2]));
                    rd.fillRect(357, 362, 39, 17);
                }
                if((!lan || im != 0) && i > 403 && i < 442 && i_52 > 362 && i_52 < 379)
                {
                    rd.setColor(new Color(m.csky[0], m.csky[1], m.csky[2]));
                    rd.fillRect(403, 362, 39, 17);
                }
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                rd.drawString("Yes", 366, 375);
                if(!lan || im != 0)
                    rd.drawString("No", 416, 375);
                rd.setColor(new Color(m.csky[0] / 2, m.csky[1] / 2, m.csky[2] / 2));
                if(!lan || im != 0)
                    rd.drawRoundRect(147, 357, 301, 27, 7, 20);
                else
                    rd.drawRoundRect(147, 357, 262, 27, 7, 20);
                rd.drawRect(357, 362, 39, 17);
                if(!lan || im != 0)
                    rd.drawRect(403, 362, 39, 17);
            }
            if(runtyp == -101 && !lan)
            {
                if(warning == 210)
                    warning = 0;
                int i_54 = 0;
                int i_55 = 0;
                if(clanchat)
                {
                    i_54 = 1;
                    i_55 = -23;
                } else
                if(control.chatup == 2)
                    control.chatup = 1;
                for(int i_56 = i_54; i_56 >= 0; i_56--)
                {
                    boolean bool_57 = false;
                    if(i > 5 && i < 33 && i_52 > 423 + i_55 && i_52 < 446 + i_55)
                    {
                        bool_57 = true;
                        if(control.chatup != 0)
                            control.chatup = 0;
                    } else
                    if(pointc[i_56] != 6)
                    {
                        pointc[i_56] = 6;
                        floater[i_56] = 1;
                    }
                    if(i > 33 && i < 666 && i_52 > 423 + i_55 && i_52 < 446 + i_55 && lxm != i && i_52 != lym && lxm != -100)
                    {
                        control.chatup = i_56 + 1;
                        cntchatp[i_56] = 0;
                    }
                    if(i_56 == 0)
                    {
                        lxm = i;
                        lym = i_52;
                    }
                    if(exitm != 0 && exitm != 4)
                        control.chatup = 0;
                    boolean bool_58 = false;
                    if(control.enter && control.chatup == i_56 + 1)
                    {
                        bool_58 = true;
                        control.chatup = 0;
                        control.enter = false;
                        lxm = -100;
                    }
                    if(bool)
                    {
                        if(mouson == 0)
                        {
                            if(i > 676 && i < 785 && i_52 > 426 + i_55 && i_52 < 443 + i_55 && control.chatup == i_56 + 1)
                            {
                                bool_58 = true;
                                control.chatup = 0;
                            }
                            if(bool_57 && pointc[i_56] > 0)
                            {
                                pointc[i_56]--;
                                floater[i_56] = 1;
                            }
                            if(i_56 == 0)
                                mouson = 1;
                        }
                        if(i_56 == 0)
                            control.chatup = 0;
                    } else
                    if(i_56 == 0 && mouson != 0)
                        mouson = 0;
                    if(bool_58)
                    {
                        String string = "";
                        int i_59 = 0;
                        int i_60 = 1;
                        for(; i_59 < lcmsg[i_56].length(); i_59++)
                        {
                            String string_61 = (new StringBuilder()).append("").append(lcmsg[i_56].charAt(i_59)).toString();
                            if(string_61.equals(" "))
                                i_60++;
                            else
                                i_60 = 0;
                            if(i_60 < 2)
                                string = (new StringBuilder()).append(string).append(string_61).toString();
                        }

                        if(!string.equals(""))
                        {
                            string = passRem(string.replace('|', ':'));
                            if(!msgcheck(string) && updatec[i_56] > -12)
                            {
                                if(cnames[i_56][6].equals("Game Chat  ") || cnames[i_56][6].equals((new StringBuilder()).append("").append(clan).append("'s Chat  ").toString()))
                                    cnames[i_56][6] = "";
                                for(int i_62 = 0; i_62 < 6; i_62++)
                                {
                                    sentn[i_56][i_62] = sentn[i_56][i_62 + 1];
                                    cnames[i_56][i_62] = cnames[i_56][i_62 + 1];
                                }

                                sentn[i_56][6] = string;
                                cnames[i_56][6] = nickname;
                                if(pointc[i_56] != 6)
                                {
                                    pointc[i_56] = 6;
                                    floater[i_56] = 1;
                                }
                                msgflk[i_56] = 110;
                                if(updatec[i_56] > -11)
                                    updatec[i_56] = -11;
                                else
                                    updatec[i_56]--;
                            } else
                            {
                                warning++;
                            }
                        }
                    }
                    if(bool_57 || floater[i_56] != 0 || control.chatup == i_56 + 1 || msgflk[i_56] != 0)
                    {
                        float fs[] = new float[3];
                        Color.RGBtoHSB(m.cgrnd[0], m.cgrnd[1], m.cgrnd[2], fs);
                        fs[1] -= 0.14999999999999999D;
                        if(fs[1] < 0.0F)
                            fs[1] = 0.0F;
                        fs[2] += 0.14999999999999999D;
                        if(fs[2] > 1.0F)
                            fs[2] = 1.0F;
                        rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                        rd.fillRect(33, 423 + i_55, 761, 23);
                    }
                    if(control.chatup == 0 && app.cmsg.isShowing())
                    {
                        app.cmsg.hide();
                        app.requestFocus();
                    }
                    if(control.chatup != i_56 + 1)
                    {
                        int i_63 = 0;
                        int i_64 = (int)(48F + 48F * ((float)m.snap[1] / 100F));
                        if(i_64 > 255)
                            i_64 = 255;
                        if(i_64 < 0)
                            i_64 = 0;
                        int i_65 = (int)(96F + 96F * ((float)m.snap[2] / 100F));
                        if(i_65 > 255)
                            i_65 = 255;
                        if(i_65 < 0)
                            i_65 = 0;
                        if(floater[i_56] != 0)
                        {
                            for(int i_66 = 6; i_66 >= 0; i_66--)
                            {
                                if(pointc[i_56] == i_66)
                                    if(Math.abs(i_63 + movepos[i_56]) > 10)
                                    {
                                        floater[i_56] = (movepos[i_56] + i_63) / 4;
                                        if(floater[i_56] > -5 && floater[i_56] < 0)
                                            floater[i_56] = -5;
                                        if(floater[i_56] < 10 && floater[i_56] > 0)
                                            floater[i_56] = 10;
                                        movepos[i_56] -= floater[i_56];
                                    } else
                                    {
                                        movepos[i_56] = -i_63;
                                        floater[i_56] = 0;
                                    }
                                if(pointc[i_56] >= i_66)
                                {
                                    rd.setColor(new Color(0, i_64, i_65));
                                    rd.setFont(new Font("Tahoma", 1, 11));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString((new StringBuilder()).append(cnames[i_56][i_66]).append(": ").toString(), 39 + i_63 + movepos[i_56], 439 + i_55);
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(cnames[i_56][i_66]).append(": ").toString());
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Tahoma", 0, 11));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString((new StringBuilder()).append(sentn[i_56][i_66]).append("   ").toString(), 39 + i_63 + movepos[i_56], 439 + i_55);
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(sentn[i_56][i_66]).append("   ").toString());
                                } else
                                {
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(cnames[i_56][i_66]).append(": ").toString());
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(sentn[i_56][i_66]).append("   ").toString());
                                }
                            }

                            rd.setColor(new Color(0, 0, 0));
                            rd.fillRect(0, 423 + i_55, 5, 24);
                            rd.fillRect(794, 423 + i_55, 6, 24);
                        } else
                        {
                            int i_67 = pointc[i_56];
                            do
                            {
                                if(i_67 < 0)
                                    break;
                                if(i_67 == 6 && msgflk[i_56] != 0)
                                    msgflk[i_56]--;
                                rd.setColor(new Color(0, i_64, i_65));
                                rd.setFont(new Font("Tahoma", 1, 11));
                                ftm = rd.getFontMetrics();
                                if(ftm.stringWidth((new StringBuilder()).append(cnames[i_56][i_67]).append(": ").toString()) + 39 + i_63 < 775)
                                {
                                    if(i_67 != 6 || msgflk[i_56] < 67 || msgflk[i_56] % 3 != 0)
                                        rd.drawString((new StringBuilder()).append(cnames[i_56][i_67]).append(": ").toString(), 39 + i_63, 439 + i_55);
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(cnames[i_56][i_67]).append(": ").toString());
                                } else
                                {
                                    String string = "";
                                    for(int i_68 = 0; ftm.stringWidth(string) + 39 + i_63 < 775 && i_68 < cnames[i_56][i_67].length(); i_68++)
                                        string = (new StringBuilder()).append(string).append(cnames[i_56][i_67].charAt(i_68)).toString();

                                    string = (new StringBuilder()).append(string).append("...").toString();
                                    if(i_67 != 6 || msgflk[i_56] < 67 || msgflk[i_56] % 3 != 0)
                                        rd.drawString(string, 39 + i_63, 439 + i_55);
                                    break;
                                }
                                rd.setColor(new Color(0, 0, 0));
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                if(ftm.stringWidth(sentn[i_56][i_67]) + 39 + i_63 < 775)
                                {
                                    if(i_67 != 6 || msgflk[i_56] < 67 || msgflk[i_56] % 3 != 0)
                                        rd.drawString((new StringBuilder()).append(sentn[i_56][i_67]).append("   ").toString(), 39 + i_63, 439 + i_55);
                                    i_63 += ftm.stringWidth((new StringBuilder()).append(sentn[i_56][i_67]).append("   ").toString());
                                } else
                                {
                                    String string = "";
                                    for(int i_69 = 0; ftm.stringWidth(string) + 39 + i_63 < 775 && i_69 < sentn[i_56][i_67].length(); i_69++)
                                        string = (new StringBuilder()).append(string).append(sentn[i_56][i_67].charAt(i_69)).toString();

                                    string = (new StringBuilder()).append(string).append("...").toString();
                                    if(i_67 != 6 || msgflk[i_56] < 67 || msgflk[i_56] % 3 != 0)
                                        rd.drawString(string, 39 + i_63, 439 + i_55);
                                    break;
                                }
                                i_67--;
                            } while(true);
                        }
                    } else
                    {
                        msgflk[i_56] = 0;
                        i_53 = i_56;
                    }
                    if(bool_57 || floater[i_56] != 0)
                    {
                        float fs[] = new float[3];
                        Color.RGBtoHSB(m.cgrnd[0], m.cgrnd[1], m.cgrnd[2], fs);
                        fs[1] -= 0.075999999999999998D;
                        if(fs[1] < 0.0F)
                            fs[1] = 0.0F;
                        fs[2] += 0.075999999999999998D;
                        if(fs[2] > 1.0F)
                            fs[2] = 1.0F;
                        rd.setColor(Color.getHSBColor(fs[0], fs[1], fs[2]));
                        rd.fillRect(5, 423 + i_55, 28, 23);
                    }
                    if(bool_57)
                        rd.setColor(new Color(0, 0, 0));
                    else
                        rd.setColor(new Color((int)((float)m.cgrnd[0] / 2.0F), (int)((float)m.cgrnd[1] / 2.0F), (int)((float)m.cgrnd[2] / 2.0F)));
                    rd.setFont(new Font("Tahoma", 1, 11));
                    rd.drawString("<<", 10, 439 + i_55);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRect(5, 423 + i_55, 789, 23);
                    rd.drawLine(33, 423 + i_55, 33, 446 + i_55);
                    i_55 += 23;
                }

                if(i > 775 && i < 794 && i_52 > 409 - i_54 * 23 && i_52 < 423 - i_54 * 23 || control.chatquit)
                {
                    rd.drawRect(775, 409 - i_54 * 23, 19, 14);
                    rd.setColor(new Color(200, 0, 0));
                    if(bool || control.chatquit)
                    {
                        control.chatup = 0;
                        if(app.cmsg.isShowing())
                        {
                            app.cmsg.hide();
                            app.requestFocus();
                        }
                        runtyp = 0;
                        try
                        {
                            socket.close();
                            socket = null;
                            din.close();
                            din = null;
                            dout.close();
                            dout = null;
                        }
                        catch(Exception exception) { }
                        GameSparker.postMessage("Chat closed");
                    }
                }
                rd.setFont(new Font("Arial", 1, 12));
                rd.drawString("x", 782, 420 - i_54 * 23);
                if(warning != 0)
                {
                    drawWarning();
                    if(app.cmsg.isShowing())
                    {
                        app.cmsg.hide();
                        app.requestFocus();
                    }
                    warning++;
                }
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
            } else
            if(control.chatup != 0)
            {
                control.chatup = 0;
                if(!lan)
                {
                    runtyp = -101;
                    if(runner != null)
                        runner.stop();
                    runner = new Thread(this);
                    runner.start();
                }
            }
            if(holdit && multion == 1 && !lan && sendstat == 0)
            {
                sendstat = 1;
                if(runtyp != -101)
                {
                    if(runner != null)
                        runner.stop();
                    runner = new Thread(this);
                    runner.start();
                }
            }
            if(control.arrace && starcnt < 38 && !holdit && checkpoints.stage != 10 || multion >= 2)
            {
                if(alocked != -1 && checkpoints.dested[alocked] != 0)
                {
                    alocked = -1;
                    lalocked = -1;
                }
                if(multion >= 2)
                {
                    if(alocked == -1 || holdit)
                    {
                        if(cntflock == 100)
                        {
                            for(int i_70 = 0; i_70 < nplayers; i_70++)
                            {
                                if(holdit)
                                {
                                    if(checkpoints.pos[i_70] == 0)
                                    {
                                        alocked = i_70;
                                        im = i_70;
                                    }
                                    continue;
                                }
                                if(checkpoints.dested[i_70] == 0)
                                {
                                    alocked = i_70;
                                    im = i_70;
                                }
                            }

                        }
                        cntflock++;
                    } else
                    {
                        cntflock = 0;
                    }
                    if(lan)
                    {
                        boolean bool_71 = true;
                        for(int i_72 = 0; i_72 < nplayers; i_72++)
                            if(dested[i_72] == 0 && plnames[i_72].indexOf("MadBot") == -1)
                                bool_71 = false;

                        if(bool_71)
                            exitm = 2;
                    }
                }
                GadgetPainter.opponentStatus(this, rd, checkpoints, m, i, i_52, bool);
            }
            if(udpmistro.go && udpmistro.runon == 1 && !holdit)
            {
                int i_87 = 0;
                int i_88 = 0;
                for(int i_89 = 0; i_89 < nplayers; i_89++)
                {
                    if(i_89 == udpmistro.im)
                        continue;
                    i_88++;
                    if(udpmistro.lframe[i_89] == udpmistro.lcframe[i_89] || udpmistro.force[i_89] == 7)
                        i_87++;
                    else
                        udpmistro.lcframe[i_89] = udpmistro.lframe[i_89];
                }

                if(i_87 == i_88)
                    discon++;
                else
                if(discon != 0)
                    discon = 0;
                if(discon == 240)
                    udpmistro.runon = 2;
            }
        }
        if(i_53 != -1)
        {
            float fs[] = new float[3];
            Color.RGBtoHSB(m.cgrnd[0], m.cgrnd[1], m.cgrnd[2], fs);
            fs[1] -= 0.22D;
            if(fs[1] < 0.0F)
                fs[1] = 0.0F;
            fs[2] += 0.22D;
            if(fs[2] > 1.0F)
                fs[2] = 1.0F;
            Color color = Color.getHSBColor(fs[0], fs[1], fs[2]);
            rd.setColor(color);
            rd.fillRect(676, 426 - i_53 * 23, 109, 7);
            rd.setColor(new Color(0, 0, 0));
            rd.setFont(new Font("Tahoma", 1, 11));
            rd.drawString("Send Message  >", 684, 439 - i_53 * 23);
            rd.setColor(new Color((int)((float)m.cgrnd[0] / 1.2F), (int)((float)m.cgrnd[1] / 1.2F), (int)((float)m.cgrnd[2] / 1.2F)));
            rd.drawRect(676, 426 - i_53 * 23, 109, 17);
            if(!app.cmsg.isShowing() && warning == 0)
            {
                app.cmsg.show();
                app.cmsg.requestFocus();
                lcmsg[i_53] = "";
                app.cmsg.setText("");
                app.cmsg.setBackground(color);
            }
            app.movefield(app.cmsg, 34, 424 - i_53 * 23, 633, 22);
            if(app.cmsg.getText().equals(lcmsg[i_53]))
                cntchatp[i_53]++;
            else
                cntchatp[i_53] = -200;
            lcmsg[i_53] = (new StringBuilder()).append("").append(app.cmsg.getText()).toString();
            if(cntchatp[i_53] == 67)
                control.chatup = 0;
            if(app.cmsg.getText().length() > 100)
            {
                app.cmsg.setText(app.cmsg.getText().substring(0, 100));
                app.cmsg.select(100, 100);
            }
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
        }
        if(rd.getClip() != null)
            rd.setClip(null);
    }

    public void levelhigh(int i, int i_90, int i_91, int i_92, int i_93)
    {
        rd.drawImage(gameh, 301, 20, null);
        int i_94 = 16;
        int i_95 = 48;
        int i_96 = 96;
        if(i_92 < 50)
            if(aflk)
            {
                i_94 = 106;
                i_95 = 176;
                i_96 = 255;
                aflk = false;
            } else
            {
                aflk = true;
            }
        if(i != im)
        {
            if(i_91 == 0)
                drawcs(60, "You Wasted 'em!", i_94, i_95, i_96, 0);
            else
            if(i_91 == 1)
                drawcs(60, "Close Finish!", i_94, i_95, i_96, 0);
            else
                drawcs(60, "Close Finish!  Almost got it!", i_94, i_95, i_96, 0);
        } else
        if(i_90 == 229)
        {
            if(discon != 240)
                drawcs(60, "Wasted!", i_94, i_95, i_96, 0);
            else
                drawcs(60, "Disconnected!", i_94, i_95, i_96, 0);
        } else
        if(i_93 > 2 || i_93 < 0)
            drawcs(60, "Stunts!", i_94, i_95, i_96, 0);
        else
            drawcs(60, "Best Stunt!", i_94, i_95, i_96, 0);
        drawcs(380, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
    }

    public void inst(Control control)
    {
        if(flipo == 0)
            flipo = 1;
        if(flipo == 2)
        {
            flipo = 3;
            dudo = 200;
        }
        if(flipo == 4)
        {
            flipo = 5;
            dudo = 250;
        }
        if(flipo == 6)
        {
            flipo = 7;
            dudo = 200;
        }
        if(flipo == 8)
        {
            flipo = 9;
            dudo = 250;
        }
        if(flipo == 10)
        {
            flipo = 11;
            dudo = 200;
        }
        if(flipo == 12)
        {
            flipo = 13;
            dudo = 200;
        }
        if(flipo == 14)
        {
            flipo = 15;
            dudo = 100;
        }
        mainbg(2);
        rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
        rd.drawImage(bggo, 65, 25, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(735, 0, 65, 450);
        rd.fillRect(65, 425, 670, 25);
        if(aflk)
            aflk = false;
        else
            aflk = true;
        if(flipo != 1 && flipo != 17)
        {
            if(dudo > 0)
            {
                if(aflk)
                    if(Math.random() > Math.random())
                        duds = (int)(Math.random() * 3D);
                    else
                        duds = (int)(Math.random() * 2D);
                dudo--;
            } else
            {
                duds = 0;
            }
            rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
            rd.drawImage(dude[duds], 95, 15, null);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.drawImage(oflaot, 192, 42, null);
        }
        rd.setColor(new Color(0, 64, 128));
        rd.setFont(new Font("Arial", 1, 13));
        if(flipo == 3 || flipo == 5)
        {
            if(flipo == 3)
            {
                rd.drawString("Hello!  Welcome to the world of", 262, 67);
                rd.drawString("!", 657, 67);
                rd.drawImage(nfm, 469, 55, null);
                rd.drawString("In this game there are two ways to complete a stage.", 262, 107);
                rd.drawString("One is by racing and finishing in first place, the other is by", 262, 127);
                rd.drawString("wasting and crashing all the other cars in the stage!", 262, 147);
            } else
            {
                rd.setColor(new Color(0, 128, 255));
                rd.drawString("While racing, you will need to focus on going fast and passing", 262, 67);
                rd.drawString("through all the checkpoints in the track. To complete a lap, you", 262, 87);
                rd.drawString("must not miss a checkpoint.", 262, 107);
                rd.drawString("While wasting, you will just need to chase the other cars and", 262, 127);
                rd.drawString("crash into them (without worrying about track and checkpoints).", 262, 147);
            }
            rd.setColor(new Color(0, 0, 0));
            rd.drawImage(racing, 165, 185, null);
            rd.drawImage(ory, 429, 235, null);
            rd.drawImage(wasting, 492, 185, null);
            rd.setFont(new Font("Arial", 1, 11));
            rd.drawString("Checkpoint", 392, 189);
            rd.setFont(new Font("Arial", 1, 13));
            rd.drawString("Drive your car using the Arrow Keys and Spacebar", 125, 320);
            rd.drawImage(space, 171, 355, null);
            rd.drawImage(arrows, 505, 323, null);
            rd.setFont(new Font("Arial", 1, 11));
            rd.drawString("(When your car is on the ground Spacebar is for Handbrake)", 125, 341);
            rd.drawString("Accelerate", 515, 319);
            rd.drawString("Brake/Reverse", 506, 397);
            rd.drawString("Turn left", 454, 375);
            rd.drawString("Turn right", 590, 375);
            rd.drawString("Handbrake", 247, 374);
        }
        if(flipo == 7 || flipo == 9)
        {
            if(flipo == 7)
            {
                rd.drawString("Whether you are racing or wasting the other cars you will need", 262, 67);
                rd.drawString("to power up your car.", 262, 87);
                rd.drawString("=> More 'Power' makes your car become faster and stronger!", 262, 107);
                rd.drawString("To power up your car (and keep it powered up) you will need to", 262, 127);
                rd.drawString("perform stunts!", 262, 147);
                rd.drawImage(chil, 167, 295, null);
            } else
            {
                rd.drawString("The better the stunt the more power you get!", 262, 67);
                rd.setColor(new Color(0, 128, 255));
                rd.drawString("Forward looping pushes your car forwards in the air and helps", 262, 87);
                rd.drawString("when racing. Backward looping pushes your car upwards giving it", 262, 107);
                rd.drawString("more hang time in the air making it easier to control its landing.", 262, 127);
                rd.drawString("Left and right rolls shift your car in the air left and right slightly.", 262, 147);
                if(aflk || dudo < 150)
                    rd.drawImage(chil, 167, 295, null);
            }
            rd.setColor(new Color(0, 0, 0));
            rd.drawImage(stunts, 105, 175, null);
            rd.drawImage(opwr, 540, 253, null);
            rd.setFont(new Font("Arial", 1, 13));
            rd.drawString("To perform stunts. When your car is in the AIR:", 125, 310);
            rd.drawString("Press combo Spacebar + Arrow Keys", 125, 330);
            rd.drawImage(space, 185, 355, null);
            rd.drawImage(plus, 405, 358, null);
            rd.drawImage(arrows, 491, 323, null);
            rd.setFont(new Font("Arial", 1, 11));
            rd.setColor(new Color(0, 0, 0));
            rd.drawString("Forward Loop", 492, 319);
            rd.drawString("Backward Loop", 490, 397);
            rd.drawString("Left Roll", 443, 375);
            rd.drawString("Right Roll", 576, 375);
            rd.drawString("Spacebar", 266, 374);
            rd.setColor(new Color(140, 243, 244));
            rd.fillRect(602, 257, 76, 9);
        }
        if(flipo == 11 || flipo == 13)
        {
            if(flipo == 11)
            {
                rd.drawString("When wasting cars, to help you find the other cars in the stage,", 262, 67);
                rd.drawString("press [ A ] to toggle the guidance arrow from pointing to the track", 262, 87);
                rd.drawString("to pointing to the cars.", 262, 107);
                rd.drawString("When your car is damaged. You fix it (and reset its 'Damage') by", 262, 127);
                rd.drawString("jumping through the electrified hoop.", 262, 147);
            } else
            {
                rd.setColor(new Color(0, 128, 255));
                rd.drawString("You will find that in some stages it's easier to waste the other cars", 262, 67);
                rd.drawString("and in some others it's easier to race and finish in first place.", 262, 87);
                rd.drawString("It is up to you to decide when to waste and when to race.", 262, 107);
                rd.drawString("And remember, 'Power' is an important factor in the game. You", 262, 127);
                rd.drawString("will need it whether you are racing or wasting!", 262, 147);
            }
            rd.setColor(new Color(0, 0, 0));
            rd.drawImage(fixhoop, 185, 218, null);
            rd.drawImage(sarrow, 385, 228, null);
            rd.setFont(new Font("Arial", 1, 11));
            rd.drawString("The Electrified Hoop", 192, 216);
            rd.drawString("Jumping through it fixes your car.", 158, 338);
            rd.drawString("Make guidance arrow point to cars.", 385, 216);
        }
        if(flipo == 15 || flipo == 16)
        {
            rd.drawString("And if you don\u2019t know who I am,", 262, 67);
            rd.drawString("I am Coach Insano, I am the coach and narrator of this game!", 262, 87);
            rd.drawString("I recommend starting with NFM 1 if it\u2019s your first time to play.", 262, 127);
            rd.drawString("Good Luck & Have Fun!", 262, 147);
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(flipo != 15 ? "DS-addons Controls :" : "Other Controls :", 155, 205);
            rd.setFont(new Font("Arial", 1, 11));
            if(flipo == 15)
            {
                rd.drawImage(kz, 169, 229, null);
                rd.drawString("OR", 206, 251);
                rd.drawImage(kx, 229, 229, null);
                rd.drawString("To look behind you while driving.", 267, 251);
                rd.drawImage(kv, 169, 279, null);
                rd.drawString("Change Views", 207, 301);
                rd.drawImage(kenter, 169, 329, null);
                rd.drawString("Navigate & Pause Game", 275, 351);
                rd.drawImage(km, 489, 229, null);
                rd.drawString("Mute Music", 527, 251);
                rd.drawImage(kn, 489, 279, null);
                rd.drawString("Mute Sound Effects", 527, 301);
                rd.drawImage(ks, 489, 329, null);
                rd.drawString("Toggle radar / map", 527, 351);
                rd.setFont(new Font("Arial", 1, 13));
                rd.setColor(new Color(235, 235, 235));
                rd.fillRect(495, 335, 10, 10);
                rd.setColor(new Color(50, 50, 50));
                rd.drawString("Q", 495, 345);
            } else
            {
                String cntrls[][] = {
                    {
                        "S", "Switch the speedometer skin"
                    }, {
                        "W", "Switch the position area skin"
                    }, {
                        "D", "Switch the module name visor skin"
                    }, {
                        "E", "Switch the arrow/op-status area skin"
                    }, {
                        "F", "Switch the chronometer skin"
                    }, {
                        "R", "Switch the damage/power area skin"
                    }, {
                        "F2", "Show/hide the menu bar"
                    }, {
                        "F8", "Close the chat bar during a game"
                    }, {
                        "F11", "Show/hide in-game interface"
                    }, {
                        "F12", "Take a snapshot"
                    }
                };
                for(int i = 0; i < 5; i++)
                {
                    for(int j = 0; j < 2 && i * 2 + j < cntrls.length; j++)
                    {
                        rd.setClip(new java.awt.geom.RoundRectangle2D.Float(165 + j * 260, 240 + i * 30, 21 + (i >= 4 ? 6 : 0), 20F, 10F, 10F));
                        rd.setColor(new Color(200, 200, 200));
                        rd.fillRect(165 + j * 260, 240 + i * 30, 21 + (i >= 4 ? 6 : 0), 20);
                        rd.setColor(new Color(100, 100, 100));
                        rd.fillPolygon(new int[] {
                            165 + j * 260, 186 + j * 260 + (i >= 4 ? 6 : 0), 186 + j * 260 + (i >= 4 ? 6 : 0)
                        }, new int[] {
                            240 + i * 30, 240 + i * 30, 260 + i * 30
                        }, 3);
                        rd.setColor(new Color(245, 245, 245));
                        rd.fillRoundRect(168 + j * 260, 243 + i * 30, 15 + (i >= 4 ? 6 : 0), 14, 8, 8);
                        rd.setClip(null);
                        rd.setColor(new Color(50, 50, 50));
                        rd.drawRoundRect(165 + j * 260, 240 + i * 30, 21 + (i >= 4 ? 6 : 0), 20, 10, 10);
                        rd.drawString(cntrls[j + 2 * i][0], 170 + j * 260, 254 + i * 30);
                        rd.setColor(Color.BLACK);
                        rd.drawString(cntrls[j + 2 * i][1], 195 + j * 260 + (i >= 4 ? 6 : 0), 254 + i * 30);
                    }

                }

            }
        }
        if(flipo == 1 || flipo == 17)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            rd.setColor(new Color(0, 0, 0));
            if(flipo == 17)
                rd.drawString("M A I N    C O N T R O L S   -   once again!", 400 - ftm.stringWidth("M A I N    C O N T R O L S   -   once again!") / 2, 49);
            else
                rd.drawString("M A I N    C O N T R O L S", 400 - ftm.stringWidth("M A I N    C O N T R O L S") / 2, 49);
            rd.drawString("Drive your car using the Arrow Keys:", 125, 80);
            rd.drawString("On the GROUND Spacebar is for Handbrake", 125, 101);
            rd.drawImage(space, 171, 115, null);
            rd.drawImage(arrows, 505, 83, null);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            rd.drawString("Accelerate", 515, 79);
            rd.drawString("Brake/Reverse", 506, 157);
            rd.drawString("Turn left", 454, 135);
            rd.drawString("Turn right", 590, 135);
            rd.drawString("Handbrake", 247, 134);
            drawcs(175, "----------------------------------------------------------------------------------------------------------------------------------------------------", 0, 64, 128, 3);
            rd.setColor(new Color(0, 0, 0));
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            rd.drawString("To perform STUNTS:", 125, 200);
            rd.drawString("In the AIR press combo Spacebar + Arrow Keys", 125, 220);
            rd.drawImage(space, 185, 245, null);
            rd.drawImage(plus, 405, 248, null);
            rd.drawImage(arrows, 491, 213, null);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            rd.setColor(new Color(0, 0, 0));
            rd.drawString("Forward Loop", 492, 209);
            rd.drawString("Backward Loop", 490, 287);
            rd.drawString("Left Roll", 443, 265);
            rd.drawString("Right Roll", 576, 265);
            rd.drawString("Spacebar", 266, 264);
            rd.drawImage(stunts, 125, 285, null);
        }
        if(flipo >= 1 && flipo <= 16)
            rd.drawImage(next[pnext], 665, 395, null);
        if(flipo >= 3 && flipo <= 17)
            rd.drawImage(back[pback], 75, 395, null);
        if(flipo == 17)
            rd.drawImage(contin[pcontin], 565, 395, null);
        if(control.enter || control.right)
        {
            if(control.enter && flipo == 17)
            {
                flipo = 0;
                fase = oldfase;
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
            }
            control.enter = false;
            control.right = false;
            if(flipo >= 1 && flipo <= 16)
                flipo++;
        }
        if(control.left)
        {
            if(flipo >= 3 && flipo <= 15)
                flipo -= 3;
            if(flipo >= 16)
                flipo--;
            control.left = false;
        }
    }

    public void maini(Control control)
    {
        if(flipo == 0)
        {
            app.setCursor(new Cursor(0));
            flipo++;
        }
        mainbg(1);
        rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
        rd.drawImage(logomadbg, 65, 25, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.drawImage(logomadnes, 233, 186, null);
        float f = (float)flkat / 800F;
        if((double)f > 0.20000000000000001D)
            f = 0.2F;
        if(flkat > 200)
        {
            f = (float)(400 - flkat) / 1000F;
            if(f < 0.0F)
                f = 0.0F;
        }
        flkat++;
        if(flkat == 400)
            flkat = 0;
        rd.setComposite(AlphaComposite.getInstance(3, f));
        rd.drawImage(dude[0], 351 + gxdu, 28 + gydu, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        if(movly == 0)
        {
            gxdu = (int)(5D - 11D * Math.random());
            gydu = (int)(5D - 11D * Math.random());
        }
        movly++;
        if(movly == 2)
            movly = 0;
        rd.drawImage(logocars, 66, 33, null);
        rd.drawImage(opback, 247, 237, null);
        if(muhi < 0)
        {
            rd.setColor(new Color(140, 70, 0));
            rd.fillRoundRect(335, 293, 114, 19, 7, 20);
        }
        muhi--;
        if(muhi < -5)
            muhi = 50;
        if(control.up)
        {
            opselect--;
            if(opselect == -1)
                opselect = 3;
            control.up = false;
        }
        if(control.down)
        {
            opselect++;
            if(opselect == 4)
                opselect = 0;
            control.down = false;
        }
        if(opselect == 0)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(343, 261, 110, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 200, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 128, 0));
                aflk = true;
            }
            rd.drawRoundRect(343, 261, 110, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(343, 261, 110, 22, 7, 20);
        }
        if(opselect == 1)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(288, 291, 221, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 191, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 95, 0));
                aflk = true;
            }
            rd.drawRoundRect(288, 291, 221, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(288, 291, 221, 22, 7, 20);
        }
        if(opselect == 2)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(301, 321, 196, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 128, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 128, 0));
                aflk = true;
            }
            rd.drawRoundRect(301, 321, 196, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(301, 321, 196, 22, 7, 20);
        }
        if(opselect == 3)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(357, 351, 85, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 0, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 128, 0));
                aflk = true;
            }
            rd.drawRoundRect(357, 351, 85, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(357, 351, 85, 22, 7, 20);
        }
        rd.drawImage(opti, 294, 265, null);
        if(control.enter || control.handb)
        {
            if(opselect == 1)
                if(Madness.updated)
                {
                    mtop = true;
                    multion = 1;
                    gmode = 0;
                    if(firstime)
                    {
                        oldfase = -9;
                        fase = 11;
                        firstime = false;
                    } else
                    {
                        fase = -9;
                    }
                } else
                {
                    GameSparker.postMessage("The game core is outdated, you can't play online");
                    GameSparker.msgc = 100;
                }
            if(opselect == 2)
            {
                oldfase = 10;
                fase = 11;
                firstime = false;
            }
            if(opselect == 3)
                fase = 8;
            if(opselect == 0)
            {
                if(unlocked[0] == 11)
                    if(unlocked[1] != 17)
                        opselect = 1;
                    else
                        opselect = 2;
                if(firstime)
                {
                    oldfase = 102;
                    fase = 11;
                    firstime = false;
                } else
                {
                    fase = 102;
                }
            }
            flipo = 0;
            control.enter = false;
            control.handb = false;
        }
        rd.drawImage(byrd, 72, 410, null);
        rd.drawImage(nfmcoms, 567, 410, null);
        if(shaded)
        {
            app.repaint();
            try
            {
                Thread.sleep(200L);
            }
            catch(InterruptedException interruptedexception) { }
        }
    }

    public void maini2(Control control, int i, int i_97, int i_98)
    {
        mainbg(1);
        rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
        rd.drawImage(logomadbg, 65, 25, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.drawImage(logomadnes, 233, 186, null);
        float f = (float)flkat / 800F;
        if((double)f > 0.20000000000000001D)
            f = 0.2F;
        if(flkat > 200)
        {
            f = (float)(400 - flkat) / 1000F;
            if(f < 0.0F)
                f = 0.0F;
        }
        flkat++;
        if(flkat == 400)
            flkat = 0;
        rd.setComposite(AlphaComposite.getInstance(3, f));
        rd.drawImage(dude[0], 351 + gxdu, 28 + gydu, null);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        if(movly == 0)
        {
            gxdu = (int)(5D - 11D * Math.random());
            gydu = (int)(5D - 11D * Math.random());
        }
        movly++;
        if(movly == 2)
            movly = 0;
        rd.drawImage(logocars, 66, 33, null);
        rd.drawImage(opback, 247, 237, null);
        if(control.up)
        {
            opselect--;
            if(opselect == -1)
                opselect = 3 - dropf / 15;
            control.up = false;
        }
        if(control.down)
        {
            opselect++;
            if(opselect == 4 - dropf / 15)
                opselect = 0;
            control.down = false;
        }
        if(opselect == 0)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(358, 262 + dropf, 82, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 64, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 128, 0));
                aflk = true;
            }
            rd.drawRoundRect(358, 262 + dropf, 82, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(358, 262 + dropf, 82, 22, 7, 20);
        }
        if(opselect == 1)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(358, 290 + dropf, 82, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 64, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 95, 0));
                aflk = true;
            }
            rd.drawRoundRect(358, 290 + dropf, 82, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(358, 290 + dropf, 82, 22, 7, 20);
        }
        if(opselect == 2)
        {
            if(shaded)
            {
                rd.setColor(new Color(140, 70, 0));
                rd.fillRect(333, 318 + dropf, 132, 22);
                aflk = false;
            }
            if(aflk)
            {
                rd.setColor(new Color(200, 255, 0));
                aflk = false;
            } else
            {
                rd.setColor(new Color(255, 128, 0));
                aflk = true;
            }
            rd.drawRoundRect(333, 318 + dropf, 132, 22, 7, 20);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(333, 318 + dropf, 132, 22, 7, 20);
        }
        if(dropf == 0)
            if(opselect == 3)
            {
                if(shaded)
                {
                    rd.setColor(new Color(140, 70, 0));
                    rd.fillRect(348, 346, 102, 22);
                    aflk = false;
                }
                if(aflk)
                {
                    rd.setColor(new Color(200, 64, 0));
                    aflk = false;
                } else
                {
                    rd.setColor(new Color(255, 128, 0));
                    aflk = true;
                }
                rd.drawRoundRect(348, 346, 102, 22, 7, 20);
            } else
            {
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(348, 346, 102, 22, 7, 20);
            }
        rd.drawImage(opti2, 346, 265 + dropf, null);
        if(dropf != 0)
        {
            rd.setColor(new Color(58, 30, 8));
            rd.fillRect(357, 365, 87, 15);
        }
        if(control.enter || control.handb)
        {
            mtop = false;
            if(opselect == 0)
            {
                multion = 0;
                clangame = 0;
                gmode = 1;
                fase = -9;
            }
            if(opselect == 1)
            {
                multion = 0;
                clangame = 0;
                gmode = 2;
                fase = -9;
                opselect = 0;
            }
            if(dropf == 0 && opselect == 3)
            {
                multion = 0;
                clangame = 0;
                gmode = 0;
                fase = -9;
                opselect = 0;
            }
            if(opselect == 2)
                if(Madness.updated)
                {
                    multion = 1;
                    gmode = 0;
                    if(firstime)
                    {
                        oldfase = -9;
                        fase = 11;
                        firstime = false;
                    } else
                    {
                        fase = -9;
                    }
                } else
                {
                    GameSparker.postMessage("The game core is outdated, you can't play online");
                    GameSparker.msgc = 100;
                }
            flipo = 0;
            control.enter = false;
            control.handb = false;
        }
        rd.drawImage(byrd, 72, 410, null);
        rd.drawImage(nfmcoms, 567, 410, null);
        boolean bool = false;
        if(i_98 == 2)
            bool = true;
        if(drawcarb(true, null, "   < Back   ", 161, 313, i, i_97, bool))
        {
            opselect = 0;
            fase = 10;
        }
        if(shaded)
        {
            app.repaint();
            try
            {
                Thread.sleep(200L);
            }
            catch(InterruptedException interruptedexception) { }
        }
    }

    public void pausedgame(int i, Control control, Record record)
    {
        blowEffect = 0.0F;
        if(nplayers == 1 && chrono.running && !chrono.paused)
            chrono.pause();
        if(!badmac)
        {
            rd.drawImage(fleximg, 0, 0, null);
        } else
        {
            rd.setColor(new Color(30, 67, 110));
            rd.fillRect(281, 8, 237, 188);
        }
        if(control.up)
        {
            opselect--;
            if(opselect == -1)
                opselect = 3;
            control.up = false;
        }
        if(control.down)
        {
            opselect++;
            if(opselect == 4)
                opselect = 0;
            control.down = false;
        }
        if(opselect == 0)
        {
            rd.setColor(new Color(64, 143, 223));
            rd.fillRoundRect(329, 45, 137, 22, 7, 20);
            if(shaded)
                rd.setColor(new Color(225, 200, 255));
            else
                rd.setColor(new Color(0, 89, 223));
            rd.drawRoundRect(329, 45, 137, 22, 7, 20);
        }
        if(opselect == 1)
        {
            rd.setColor(new Color(64, 143, 223));
            rd.fillRoundRect(320, 73, 155, 22, 7, 20);
            if(shaded)
                rd.setColor(new Color(225, 200, 255));
            else
                rd.setColor(new Color(0, 89, 223));
            rd.drawRoundRect(320, 73, 155, 22, 7, 20);
        }
        if(opselect == 2)
        {
            rd.setColor(new Color(64, 143, 223));
            rd.fillRoundRect(303, 99, 190, 22, 7, 20);
            if(shaded)
                rd.setColor(new Color(225, 200, 255));
            else
                rd.setColor(new Color(0, 89, 223));
            rd.drawRoundRect(303, 99, 190, 22, 7, 20);
        }
        if(opselect == 3)
        {
            rd.setColor(new Color(64, 143, 223));
            rd.fillRoundRect(341, 125, 109, 22, 7, 20);
            if(shaded)
                rd.setColor(new Color(225, 200, 255));
            else
                rd.setColor(new Color(0, 89, 223));
            rd.drawRoundRect(341, 125, 109, 22, 7, 20);
        }
        rd.drawImage(paused, 281, 8, null);
        if(control.enter || control.handb)
        {
            if(opselect == 0)
            {
                if(loadedt && !mutem)
                    strack.resume();
                if(nplayers == 1 && chrono.running && chrono.paused)
                    chrono.resume();
                fase = 0;
            }
            if(opselect == 1)
                if(record.caught >= 300)
                {
                    if(loadedt && !mutem)
                        strack.resume();
                    fase = -1;
                } else
                {
                    fase = -8;
                }
            if(opselect == 2)
            {
                if(loadedt)
                    strack.stop();
                oldfase = -7;
                fase = 11;
            }
            if(opselect == 3)
            {
                if(loadedt)
                    strack.unload();
                if(nplayers == 1 && chrono.running)
                    chrono.stop();
                fase = 102;
                if(gmode == 0)
                    opselect = 3;
                if(gmode == 1)
                    opselect = 0;
                if(gmode == 2)
                    opselect = 1;
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            control.enter = false;
            control.handb = false;
        }
    }

    public void replyn()
    {
        if(aflk)
        {
            drawcs(30, "Replay  > ", 0, 0, 0, 0);
            aflk = false;
        } else
        {
            drawcs(30, "Replay  >>", 0, 128, 255, 0);
            aflk = true;
        }
    }

    public void cantreply()
    {
        rd.setColor(new Color(64, 143, 223));
        rd.fillRoundRect(200, 73, 400, 23, 7, 20);
        rd.setColor(new Color(0, 89, 223));
        rd.drawRoundRect(200, 73, 400, 23, 7, 20);
        drawcs(89, "Sorry not enough replay data to play available, please try again later.", 255, 255, 255, 1);
    }

    public void nofocus()
    {
        rd.setColor(new Color(255, 255, 255));
        rd.fillRect(0, 0, 800, 20);
        rd.fillRect(0, 0, 20, 450);
        rd.fillRect(0, 430, 800, 20);
        rd.fillRect(780, 0, 20, 450);
        rd.setColor(new Color(192, 192, 192));
        rd.drawRect(20, 20, 760, 410);
        rd.setColor(new Color(0, 0, 0));
        rd.drawRect(22, 22, 756, 406);
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        drawcs(14, "Game lost its focus.   Click screen with mouse to continue.", 100, 100, 100, 3);
        drawcs(445, "Game lost its focus.   Click screen with mouse to continue.", 100, 100, 100, 3);
    }

    public void inishcarselect(ContO contos[])
    {
        nplayers = 7;
        im = 0;
        xstart[0] = 0;
        xstart[1] = -350;
        xstart[2] = 350;
        xstart[3] = 0;
        xstart[4] = -350;
        xstart[5] = 350;
        xstart[6] = 0;
        zstart[0] = -760;
        zstart[1] = -380;
        zstart[2] = -380;
        zstart[3] = 0;
        zstart[4] = 380;
        zstart[5] = 380;
        zstart[6] = 760;
        onmsc = -1;
        remi = false;
        basefase = 0;
        noclass = false;
        if(testdrive != 1 && testdrive != 2)
        {
            if(gmode != 0)
            {
                cfase = 0;
                sc[0] = scm[gmode - 1];
            }
            if(gmode == 0)
                sc[0] = osc;
            if(cd.lastload != 1 || cfase != 3)
                onmsc = sc[0];
            if(cfase == 0 && sc[0] > 15)
            {
                sc[0] = 15;
                if(multion != 0)
                    cfase = -1;
            }
            if(onjoin != -1 && multion != 0)
            {
                if(ontyp <= -2)
                    cfase = 0;
                if(ontyp >= 20)
                {
                    ontyp -= 20;
                    cfase = 0;
                }
                if(ontyp >= 10)
                {
                    ontyp -= 10;
                    if(cd.lastload != 2)
                    {
                        cfase = -1;
                        onjoin = -1;
                    } else
                    {
                        cfase = 3;
                    }
                }
            }
            if(cfase == 11 || cfase == 101)
                if(sc[0] >= 16 && cd.lastload == 2 && sc[0] < 36)
                    cfase = 3;
                else
                    cfase = 0;
            if(cfase == 3)
            {
                if(multion != 0 && cd.lastload == 1)
                {
                    sc[0] = 15;
                    minsl = 0;
                    maxsl = 15;
                    cfase = 0;
                }
                if(cd.lastload == 0)
                {
                    sc[0] = 15;
                    minsl = 0;
                    maxsl = 15;
                    cfase = 0;
                }
                if(cd.lastload == 2)
                {
                    minsl = 16;
                    maxsl = cd.nlocars - 1;
                    if(sc[0] < minsl)
                        sc[0] = minsl;
                    if(sc[0] > maxsl)
                        sc[0] = maxsl;
                    if(onjoin != -1 && multion != 0 && ontyp > 0 && ontyp <= 5)
                    {
                        boolean bool = false;
                        for(int i = 16; i < cd.nlocars; i++)
                        {
                            if(Math.abs(cd.cclass[i] - (ontyp - 1)) > 1)
                                continue;
                            if(!bool)
                            {
                                minsl = i;
                                bool = true;
                            }
                            if(bool)
                                maxsl = i;
                        }

                        if(!bool)
                        {
                            onjoin = -1;
                            noclass = true;
                        } else
                        {
                            if(sc[0] < minsl)
                                sc[0] = minsl;
                            if(sc[0] > maxsl)
                                sc[0] = maxsl;
                            if(Math.abs(cd.cclass[sc[0]] - (ontyp - 1)) > 1)
                                sc[0] = minsl;
                        }
                    }
                }
                if(cd.lastload == -2 && logged)
                {
                    cfase = 5;
                    showtf = false;
                    cd.action = 3;
                    cd.sparkactionloader();
                }
            }
            if(cfase == 0)
            {
                minsl = 0;
                maxsl = 15;
                if(onjoin != -1 && multion != 0)
                {
                    if(ontyp == 1)
                    {
                        minsl = 0;
                        maxsl = 5;
                    }
                    if(ontyp == 2)
                    {
                        minsl = 0;
                        maxsl = 9;
                    }
                    if(ontyp == 3)
                    {
                        minsl = 5;
                        maxsl = 10;
                    }
                    if(ontyp == 4)
                    {
                        minsl = 6;
                        maxsl = 15;
                    }
                    if(ontyp == 5)
                    {
                        minsl = 10;
                        maxsl = 15;
                    }
                    if(ontyp <= -2)
                    {
                        minsl = Math.abs(ontyp + 2);
                        maxsl = Math.abs(ontyp + 2);
                    }
                }
                if(sc[0] < minsl)
                    sc[0] = minsl;
                if(sc[0] > maxsl)
                    sc[0] = maxsl;
            }
        } else
        {
            minsl = sc[0];
            maxsl = sc[0];
        }
        app.mcars.setBackground(new Color(0, 0, 0));
        app.mcars.setForeground(new Color(47, 179, 255));
        app.mcars.alphad = true;
        app.mcars.carsel = true;
        app.mgmcars.setBackground(new Color(0, 0, 0));
        app.mgmcars.setForeground(new Color(47, 179, 255));
        app.mgmcars.alphad = true;
        app.mgmcars.carsel = true;
        app.mgmcars.select(sc[0]);
        carsbginflex();
        flatrstart = 0;
        m.lightson = false;
        pnext = 0;
        pback = 0;
        lsc = -1;
        mouson = -1;
        if(multion == 0)
        {
            app.mycar.setLabel(" Include in this game.");
            app.mycar.setBackground(new Color(198, 179, 129));
            app.mycar.setForeground(new Color(0, 0, 0));
            int i = 16;
            if(cd.lastload == 2)
                i = cd.nlocars;
            for(int i_99 = 0; i_99 < i; i_99++)
            {
                float fs[] = new float[3];
                Color.RGBtoHSB(contos[i_99].fcol[0], contos[i_99].fcol[1], contos[i_99].fcol[2], fs);
                for(int i_100 = 0; i_100 < contos[i_99].npl; i_100++)
                    if(contos[i_99].p[i_100].colnum == 1)
                    {
                        contos[i_99].p[i_100].hsb[0] = fs[0];
                        contos[i_99].p[i_100].hsb[1] = fs[1];
                        contos[i_99].p[i_100].hsb[2] = fs[2];
                        contos[i_99].p[i_100].oc[0] = contos[i_99].fcol[0];
                        contos[i_99].p[i_100].oc[1] = contos[i_99].fcol[1];
                        contos[i_99].p[i_100].oc[2] = contos[i_99].fcol[2];
                    }

                Color.RGBtoHSB(contos[i_99].scol[0], contos[i_99].scol[1], contos[i_99].scol[2], fs);
                for(int i_101 = 0; i_101 < contos[i_99].npl; i_101++)
                    if(contos[i_99].p[i_101].colnum == 2)
                    {
                        contos[i_99].p[i_101].hsb[0] = fs[0];
                        contos[i_99].p[i_101].hsb[1] = fs[1];
                        contos[i_99].p[i_101].hsb[2] = fs[2];
                        contos[i_99].p[i_101].oc[0] = contos[i_99].scol[0];
                        contos[i_99].p[i_101].oc[1] = contos[i_99].scol[1];
                        contos[i_99].p[i_101].oc[2] = contos[i_99].scol[2];
                    }

                contos[i_99].xy = 0;
            }

            for(int i_102 = 0; i_102 < 6; i_102++)
                arnp[i_102] = -1F;

        }
        m.trk = 0;
        m.crs = true;
        m.x = -400;
        m.y = -525;
        m.z = -50;
        m.xz = 0;
        m.zy = 10;
        m.ground = 495;
        m.ih = 0;
        m.iw = 0;
        m.h = 450;
        m.w = 800;
        m.focus_point = 400;
        m.cx = 400;
        m.cy = 225;
        m.cz = 50;
        if(multion == 0)
        {
            intertrack.loadimod(false);
            intertrack.play();
        }
    }

    public void carselect(Control control, ContO contos[], Mad mad, int i, int i_103, boolean bool)
    {
        rd.setColor(new Color(0, 0, 0));
        rd.fillRect(0, 0, 65, 450);
        rd.fillRect(735, 0, 65, 450);
        rd.fillRect(65, 0, 670, 25);
        rd.fillRect(65, 425, 670, 25);
        if(flatrstart == 6)
        {
            if(multion != 0 || testdrive == 1 || testdrive == 2)
                rd.drawImage(carsbgc, 65, 25, null);
            else
                rd.drawImage(carsbg, 65, 25, null);
        } else
        if(flatrstart <= 1)
        {
            drawSmokeCarsbg();
        } else
        {
            rd.setColor(new Color(255, 255, 255));
            rd.fillRect(65, 25, 670, 400);
            carsbginflex();
            flatrstart = 6;
        }
        rd.drawImage(selectcar, 321, 37, null);
        if(cfase == 3 || cfase == 7 || remi)
        {
            if(cd.lastload == 1)
                rd.drawImage(ycmc, 337, 58, null);
            if(cd.lastload == 2)
                rd.drawImage(yac, 323, 58, null);
        }
        if(cfase == 11)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            String string = "Top 20 Cars";
            int i_104 = cd.loadlist;
            String string_105 = "Weekly";
            do
            {
                if(i_104 <= 6)
                    break;
                i_104 -= 6;
                if(string_105.equals("Semi-Annual"))
                    string_105 = "Annual";
                if(string_105.equals("Monthly"))
                    string_105 = "Semi-Annual";
                if(string_105.equals("Weekly"))
                    string_105 = "Monthly";
            } while(true);
            if(i_104 == 1)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Cars").toString();
            if(i_104 == 2)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Class A Cars").toString();
            if(i_104 == 3)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Class A & B Cars").toString();
            if(i_104 == 4)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Class B Cars").toString();
            if(i_104 == 5)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Class B & C Cars").toString();
            if(i_104 == 6)
                string = (new StringBuilder()).append("").append(string_105).append(" Top 20 Class C Cars").toString();
            drawcs(69, string, 120, 176, 255, 3);
        }
        if(cfase == 101)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(69, (new StringBuilder()).append("").append(cd.viewname).append("'s account cars!").toString(), 220, 112, 33, 3);
        }
        if(!remi)
        {
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            contos[sc[0]].d(rd);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        if(cfase == 8)
        {
            drawprom(150, 85);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            drawcs(195, "Removing Car...", 0, 0, 0, 3);
            if(cd.action != 10)
                if(cd.action != -10)
                {
                    cfase = 5;
                    showtf = false;
                } else
                {
                    cfase = 9;
                }
        }
        if((multion != 0 || testdrive == 1 || testdrive == 2) && lsc != sc[0])
        {
            if(contos[sc[0]].xy != 0)
                contos[sc[0]].xy = 0;
            boolean bool_106 = false;
            for(int i_107 = 0; i_107 < contos[sc[0]].npl && !bool_106; i_107++)
                if(contos[sc[0]].p[i_107].colnum == 1)
                {
                    float fs[] = new float[3];
                    Color.RGBtoHSB(contos[sc[0]].p[i_107].c[0], contos[sc[0]].p[i_107].c[1], contos[sc[0]].p[i_107].c[2], fs);
                    arnp[0] = fs[0];
                    arnp[1] = fs[1];
                    arnp[2] = 1.0F - fs[2];
                    bool_106 = true;
                }

            bool_106 = false;
            for(int i_108 = 0; i_108 < contos[sc[0]].npl && !bool_106; i_108++)
                if(contos[sc[0]].p[i_108].colnum == 2)
                {
                    float fs[] = new float[3];
                    Color.RGBtoHSB(contos[sc[0]].p[i_108].c[0], contos[sc[0]].p[i_108].c[1], contos[sc[0]].p[i_108].c[2], fs);
                    arnp[3] = fs[0];
                    arnp[4] = fs[1];
                    arnp[5] = 1.0F - fs[2];
                    bool_106 = true;
                }

            Color color = Color.getHSBColor(arnp[0], arnp[1], 1.0F - arnp[2]);
            Color color_109 = Color.getHSBColor(arnp[3], arnp[4], 1.0F - arnp[5]);
            for(int i_110 = 0; i_110 < contos[sc[0]].npl; i_110++)
            {
                if(contos[sc[0]].p[i_110].colnum == 1)
                {
                    contos[sc[0]].p[i_110].hsb[0] = arnp[0];
                    contos[sc[0]].p[i_110].hsb[1] = arnp[1];
                    contos[sc[0]].p[i_110].hsb[2] = 1.0F - arnp[2];
                    contos[sc[0]].p[i_110].c[0] = color.getRed();
                    contos[sc[0]].p[i_110].c[1] = color.getGreen();
                    contos[sc[0]].p[i_110].c[2] = color.getBlue();
                    contos[sc[0]].p[i_110].oc[0] = color.getRed();
                    contos[sc[0]].p[i_110].oc[1] = color.getGreen();
                    contos[sc[0]].p[i_110].oc[2] = color.getBlue();
                }
                if(contos[sc[0]].p[i_110].colnum == 2)
                {
                    contos[sc[0]].p[i_110].hsb[0] = arnp[3];
                    contos[sc[0]].p[i_110].hsb[1] = arnp[4];
                    contos[sc[0]].p[i_110].hsb[2] = 1.0F - arnp[5];
                    contos[sc[0]].p[i_110].c[0] = color_109.getRed();
                    contos[sc[0]].p[i_110].c[1] = color_109.getGreen();
                    contos[sc[0]].p[i_110].c[2] = color_109.getBlue();
                    contos[sc[0]].p[i_110].oc[0] = color_109.getRed();
                    contos[sc[0]].p[i_110].oc[1] = color_109.getGreen();
                    contos[sc[0]].p[i_110].oc[2] = color_109.getBlue();
                }
            }

            lsc = sc[0];
        }
        int i_111 = -1;
        int i_112 = 0;
        boolean bool_113 = false;
        if(flipo == 0)
        {
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            int i_114 = 0;
            if(flatrstart < 6)
                i_114 = 2;
            if(!remi && (cfase != 10 || cd.action != 0 && cd.action < 14))
            {
                if(cfase == 3 && cd.lastload == 2)
                {
                    app.mcars.move(400 - app.mcars.w / 2, 78);
                    app.mcars.show = true;
                    if(!app.mcars.getSelectedItem().equals(cd.names[sc[0]]))
                    {
                        for(int i_115 = 16; i_115 < cd.nlocars; i_115++)
                            if(cd.names[i_115].equals(app.mcars.getSelectedItem()))
                                i_111 = i_115;

                        if(i_111 == -1)
                        {
                            cfase = 5;
                            cd.action = 4;
                            cd.sparkactionloader();
                        }
                    }
                } else
                {
                    app.mcars.show = false;
                    if(remi || cfase != 0 || gmode != 0 || multion != 1 && multion != 3)
                    {
                        String string = "";
                        if(cfase == 11)
                            string = (new StringBuilder()).append("N#").append(sc[0] - 35).append("  ").toString();
                        if(aflk)
                        {
                            drawcs(95 + i_114, (new StringBuilder()).append(string).append(cd.names[sc[0]]).toString(), 240, 240, 240, 3);
                            aflk = false;
                        } else
                        {
                            drawcs(95, (new StringBuilder()).append(string).append(cd.names[sc[0]]).toString(), 176, 176, 176, 3);
                            aflk = true;
                        }
                    }
                }
            } else
            {
                app.mcars.show = false;
            }
            if(!remi && cfase == 0 && gmode == 0 && (multion == 1 || multion == 3))
            {
                app.mgmcars.move(400 - app.mcars.w / 2, 78);
                app.mgmcars.show();
                if(sc[0] != app.mgmcars.getSelectedIndex())
                {
                    if(flatrstart > 1)
                        flatrstart = 0;
                    nextc = app.mgmcars.getSelectedIndex() + 20;
                    flipo = 20;
                }
            } else
            if(app.mgmcars.isShowing())
                app.mgmcars.hide();
            contos[sc[0]].z = 950;
            if(sc[0] == 13)
                contos[sc[0]].z = 1000;
            contos[sc[0]].y = -34 - contos[sc[0]].grat;
            contos[sc[0]].x = 0;
            if(mouson >= 0 && mouson <= 3)
                contos[sc[0]].xz += 2;
            else
                contos[sc[0]].xz += 5;
            if(contos[sc[0]].xz > 360)
                contos[sc[0]].xz -= 360;
            contos[sc[0]].zy = 0;
            contos[sc[0]].wzy -= 10;
            if(contos[sc[0]].wzy < -30)
                contos[sc[0]].wzy += 30;
            if(!remi)
            {
                if(sc[0] != minsl)
                    rd.drawImage(back[pback], 95, 275, null);
                if(sc[0] != maxsl)
                    rd.drawImage(next[pnext], 645, 275, null);
            }
            if(gmode == 1)
            {
                if(sc[0] == 5 && unlocked[0] <= 2)
                    i_112 = 2;
                if(sc[0] == 6 && unlocked[0] <= 4)
                    i_112 = 4;
                if(sc[0] == 11 && unlocked[0] <= 6)
                    i_112 = 6;
                if(sc[0] == 14 && unlocked[0] <= 8)
                    i_112 = 8;
                if(sc[0] == 15 && unlocked[0] <= 10)
                    i_112 = 10;
            }
            if(gmode == 2 && sc[0] >= 8 && unlocked[1] <= (sc[0] - 7) * 2)
                i_112 = (sc[0] - 7) * 2;
            if(i_112 != 0)
            {
                if(gatey == 300)
                {
                    for(int i_116 = 0; i_116 < 9; i_116++)
                    {
                        pgas[i_116] = false;
                        pgady[i_116] = 0;
                    }

                    pgas[0] = true;
                }
                for(int i_117 = 0; i_117 < 9; i_117++)
                {
                    rd.drawImage(pgate, pgatx[i_117], (pgaty[i_117] + pgady[i_117]) - gatey, null);
                    if(flatrstart != 6)
                        continue;
                    if(pgas[i_117])
                    {
                        pgady[i_117] -= ((80 + 100 / (i_117 + 1)) - Math.abs(pgady[i_117])) / 3;
                        if(pgady[i_117] >= -(70 + 100 / (i_117 + 1)))
                            continue;
                        pgas[i_117] = false;
                        if(i_117 != 8)
                            pgas[i_117 + 1] = true;
                        continue;
                    }
                    pgady[i_117] += ((80 + 100 / (i_117 + 1)) - Math.abs(pgady[i_117])) / 3;
                    if(pgady[i_117] > 0)
                        pgady[i_117] = 0;
                }

                if(gatey != 0)
                    gatey -= 100;
                if(flatrstart == 6)
                {
                    drawcs(355, "[ Car Locked ]", 210, 210, 210, 3);
                    drawcs(375, (new StringBuilder()).append("This car unlocks when stage ").append(i_112).append(" is completed...").toString(), 255, 96, 0, 3);
                }
            } else
            {
                if(flatrstart == 6)
                {
                    if(cfase == 10)
                    {
                        if(cd.action == 13)
                        {
                            minsl = 36;
                            maxsl = cd.xnlocars - 1;
                            i_111 = 36;
                            cd.action = 0;
                            cfase = 11;
                        }
                        if(cd.action == 12)
                        {
                            int i_118 = cd.loadlist;
                            String string = "Top 20 Cars";
                            String string_119 = "Weekly";
                            do
                            {
                                if(i_118 <= 6)
                                    break;
                                i_118 -= 6;
                                if(string_119.equals("Semi-Annual"))
                                    string_119 = "Annual";
                                if(string_119.equals("Monthly"))
                                    string_119 = "Semi-Annual";
                                if(string_119.equals("Weekly"))
                                    string_119 = "Monthly";
                            } while(true);
                            if(i_118 == 1)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Cars").toString();
                            if(i_118 == 2)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Class A Cars").toString();
                            if(i_118 == 3)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Class A & B Cars").toString();
                            if(i_118 == 4)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Class B Cars").toString();
                            if(i_118 == 5)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Class B & C Cars").toString();
                            if(i_118 == 6)
                                string = (new StringBuilder()).append("").append(string_119).append(" Top 20 Class C Cars").toString();
                            drawprom(145, 170);
                            drawcs(195, (new StringBuilder()).append("[  Loading ").append(string).append("  ]").toString(), 0, 0, 0, 3);
                            if(cd.nl > 0 && cd.nl <= 20)
                                drawcs(235, (new StringBuilder()).append("Loading :  ").append(cd.loadnames[cd.nl - 1]).append("").toString(), 0, 0, 0, 3);
                        }
                        if(cd.action == 11)
                        {
                            drawprom(145, 170);
                            drawcs(195, "Loading List, Please Wait...", 0, 0, 0, 3);
                        }
                        if(cd.action == -1)
                        {
                            drawprom(145, 170);
                            drawcs(195, "Failed to Load List.", 0, 0, 0, 3);
                            drawcs(225, "Unknown Error.  Please try again later.", 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                            {
                                cd.action = 0;
                                cfase = basefase;
                            }
                        }
                        if(cd.action == 0 || cd.action == 14 || cd.action == 15 || cd.action == 16 || cd.action == 17)
                        {
                            drawprom(65, 250);
                            if(drawcarb(true, null, " X ", 557, 70, i, i_103, bool))
                            {
                                cd.action = 0;
                                cfase = basefase;
                            }
                            drawcs(305, "The lists get updated every 24 hours!", 0, 0, 0, 3);
                            if(cd.action == 14 || cd.action == 15 || cd.action == 16 || cd.action == 17)
                            {
                                if(!bool && cntflock == 20)
                                    cntflock = 0;
                                if(cd.action == 14)
                                    drawcs(91, "Weekly Top 20 Cars", 0, 0, 0, 3);
                                if(cd.action == 15)
                                    drawcs(91, "Monthly Top 20 Cars", 0, 0, 0, 3);
                                if(cd.action == 16)
                                    drawcs(91, "Semi-Annual Top 20 Cars", 0, 0, 0, 3);
                                if(cd.action == 17)
                                    drawcs(91, "Annual Top 20 Cars", 0, 0, 0, 3);
                                if(drawcarb(true, null, "   All Cars, All Classes   ", 318, 105, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 1 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                                if(drawcarb(true, null, "Class A Cars", 337, 135, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 2 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                                if(drawcarb(true, null, "Class A & B Cars", 337, 165, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 3 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                                if(drawcarb(true, null, "Class B Cars", 337, 195, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 4 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                                if(drawcarb(true, null, "Class B & C Cars", 337, 225, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 5 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                                if(drawcarb(true, null, "Class C Cars", 337, 255, i, i_103, bool) && cntflock == 0)
                                {
                                    cd.loadlist = 6 + (cd.action - 14) * 6;
                                    cd.action = 11;
                                    cd.sparkactionloader();
                                }
                            }
                            if(cd.action == 0)
                            {
                                drawcs(91, "Top 20 Most Added Public Custom Cars", 0, 0, 0, 3);
                                if(drawcarb(true, null, "  Weekly Top 20  ", 338, 125, i, i_103, bool))
                                    cd.action = 14;
                                if(drawcarb(true, null, "  Monthly Top 20  ", 337, 165, i, i_103, bool))
                                    cd.action = 15;
                                if(drawcarb(true, null, "  Semi-Annual Top 20  ", 321, 205, i, i_103, bool))
                                    cd.action = 16;
                                if(drawcarb(true, null, "  Annual Top 20  ", 339, 245, i, i_103, bool))
                                    cd.action = 17;
                                if(cntflock != 20)
                                    cntflock = 20;
                            }
                        }
                    }
                    if(cfase == 100)
                    {
                        if(cd.action == -1)
                        {
                            drawprom(145, 170);
                            drawcs(195, "Failed to Load List.", 0, 0, 0, 3);
                            drawcs(225, "Unknown Error.  Please try again later.", 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                                if(sc[0] >= 16 && cd.lastload == 2 && sc[0] < 36)
                                    cfase = 3;
                                else
                                    cfase = 0;
                        }
                        if(cd.action == -2)
                        {
                            drawprom(145, 170);
                            drawcs(195, "No account cars found.", 0, 0, 0, 3);
                            drawcs(225, (new StringBuilder()).append("").append(cd.viewname).append(" does not have any published or added cars.").toString(), 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                                if(sc[0] >= 16 && cd.lastload == 2 && sc[0] < 36)
                                    cfase = 3;
                                else
                                    cfase = 0;
                        }
                        if(cd.action == 100)
                        {
                            cd.action = 101;
                            cd.sparkactionloader();
                        }
                        if(cd.action == 101)
                        {
                            drawprom(145, 170);
                            drawcs(195, (new StringBuilder()).append("Loading ").append(cd.viewname).append("'s account cars, please wait...").toString(), 0, 0, 0, 3);
                        }
                        if(cd.action == 102)
                        {
                            drawprom(145, 170);
                            drawcs(195, (new StringBuilder()).append("Loading ").append(cd.viewname).append("'s account cars, please wait...").toString(), 0, 0, 0, 3);
                            if(cd.nl > 0 && cd.nl <= 20)
                                drawcs(235, (new StringBuilder()).append("Loading :  ").append(cd.loadnames[cd.nl - 1]).append("").toString(), 0, 0, 0, 3);
                        }
                        if(cd.action == 103)
                        {
                            minsl = 36;
                            maxsl = cd.xnlocars - 1;
                            i_111 = 36;
                            cd.action = 0;
                            cfase = 101;
                        }
                    }
                    if(cfase == 0 && testdrive != 1 && testdrive != 2 && gmode == 0)
                    {
                        int i_120 = 95;
                        int i_121 = 5;
                        if(multion != 0)
                        {
                            i_120 = 185;
                            i_121 = 0;
                        }
                        if(multion == 0 && drawcarb(false, cmc, "", 95, 70, i, i_103, bool))
                            if(cd.lastload != 1)
                            {
                                cfase = 1;
                            } else
                            {
                                minsl = 16;
                                maxsl = cd.nlcars - 1;
                                i_111 = 16;
                                cfase = 3;
                            }
                        if(drawcarb(false, myc, "", i_120, 105 + i_121, i, i_103, bool))
                            if(cd.lastload != 2)
                            {
                                cfase = 5;
                                showtf = false;
                                if(!logged)
                                {
                                    cd.action = 0;
                                    cd.reco = -2;
                                    tcnt = 5;
                                    cntflock = 0;
                                } else
                                {
                                    cd.action = 3;
                                    cd.sparkactionloader();
                                }
                            } else
                            {
                                minsl = 16;
                                maxsl = cd.nlocars - 1;
                                if(onmsc >= minsl && onmsc <= maxsl)
                                    i_111 = onmsc;
                                else
                                    i_111 = 16;
                                cfase = 3;
                            }
                        if((multion == 0 || onjoin == -1) && drawcarb(false, top20s, "", i_120, (i_120 - 95) / 7 + 25 + i_121, i, i_103, bool))
                        {
                            cd.action = 0;
                            cfase = 10;
                        }
                        if(remi)
                            remi = false;
                    }
                    if(cfase == -1)
                        if(autolog)
                        {
                            autolog = false;
                            cfase = 5;
                            cd.action = 1;
                            cd.sparkactionloader();
                        } else
                        if(cd.lastload != 2)
                        {
                            cfase = 5;
                            showtf = false;
                            if(!logged)
                            {
                                cd.action = 0;
                                cd.reco = -2;
                                tcnt = 5;
                                cntflock = 0;
                            } else
                            {
                                cd.action = 3;
                                cd.sparkactionloader();
                            }
                        } else
                        {
                            minsl = 16;
                            maxsl = cd.nlocars - 1;
                            if(onmsc >= minsl && onmsc <= maxsl)
                                i_111 = onmsc;
                            else
                                i_111 = 16;
                            cfase = 3;
                        }
                    if(cfase == 9)
                    {
                        drawprom(145, 95);
                        drawcs(175, "Failed to remove car.  Unkown Error.  Try again laster.", 0, 0, 0, 3);
                        if(drawcarb(true, null, "   OK   ", 371, 195, i, i_103, bool))
                        {
                            minsl = 16;
                            maxsl = cd.nlocars - 1;
                            if(onmsc >= minsl && onmsc <= maxsl)
                                i_111 = onmsc;
                            else
                                i_111 = 16;
                            cfase = 3;
                        }
                    }
                    if(cfase == 7)
                    {
                        if(app.mycar.isShowing())
                            app.mycar.hide();
                        drawprom(145, 95);
                        drawcs(175, "Remove this car from your account?", 0, 0, 0, 3);
                        if(drawcarb(true, null, " Yes ", 354, 195, i, i_103, bool))
                        {
                            remi = true;
                            minsl = 0;
                            maxsl = 15;
                            i_111 = 15;
                            cfase = 8;
                            onmsc = sc[0];
                            cd.ac = sc[0];
                            cd.action = 10;
                            cd.sparkactionloader();
                        }
                        if(drawcarb(true, null, " No ", 408, 195, i, i_103, bool))
                            cfase = 3;
                    }
                    if(cfase == 3 && i_111 == -1)
                    {
                        int i_122 = 95;
                        int i_123 = 5;
                        if(multion != 0)
                        {
                            i_122 = 185;
                            i_123 = 0;
                        }
                        if(drawcarb(false, gac, "", i_122, 105 + i_123, i, i_103, bool))
                        {
                            minsl = 0;
                            maxsl = 15;
                            if(onmsc >= minsl && onmsc <= maxsl)
                                i_111 = onmsc;
                            else
                                i_111 = 15;
                            cfase = 0;
                        }
                        if(multion == 0)
                        {
                            if(!app.openm)
                            {
                                if(!app.mycar.isShowing())
                                {
                                    app.mycar.show();
                                    app.mycar.setState(cd.include[sc[0] - 16]);
                                }
                            } else
                            {
                                app.mycar.hide();
                            }
                            rd.setColor(new Color(198, 179, 129));
                            rd.fillRoundRect(305, 302, 190, 24, 7, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(305, 302, 190, 24, 7, 20);
                            app.movefield(app.mycar, 334, 306, 150, 17);
                            if(app.mycar.getState() != cd.include[sc[0] - 16])
                            {
                                cd.include[sc[0] - 16] = app.mycar.getState();
                                app.requestFocus();
                            }
                        }
                        if((multion == 0 || onjoin == -1) && drawcarb(false, top20s, "", i_122, (i_122 - 95) / 7 + 25 + i_123, i, i_103, bool))
                        {
                            cd.action = 0;
                            cfase = 10;
                            if(app.mycar.isShowing())
                                app.mycar.hide();
                        }
                        if(cd.lastload == 2)
                        {
                            if(drawcarb(true, null, "X", 567, 135, i, i_103, bool))
                                cfase = 7;
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            if(!cd.createdby[sc[0] - 16].equals(nickname))
                                bool_113 = clink(cd.createdby[sc[0] - 16], i, i_103, bool);
                            else
                                rd.drawString("Created by You", 241, 160);
                        }
                        if(remi)
                            remi = false;
                        if(noclass)
                        {
                            drawprom(200, 95);
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            String string = "Class C";
                            if(ontyp == 2)
                                string = "Class B or C";
                            if(ontyp == 3)
                                string = "Class B";
                            if(ontyp == 4)
                                string = "Class A or B";
                            if(ontyp == 5)
                                string = "Class A";
                            drawcs(230, (new StringBuilder()).append("You do not have a ").append(string).append(" car in your account cars.").toString(), 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 250, i, i_103, bool))
                                noclass = false;
                        }
                    }
                    if((cfase == 11 || cfase == 101) && i_111 == -1)
                    {
                        if(cd.action == -9)
                        {
                            drawprom(145, 95);
                            drawcs(175, "Unknown error!  Failed to add car.  Try again later.", 0, 0, 0, 3);
                            if(drawcarb(true, null, " OK ", 379, 195, i, i_103, bool))
                                cd.action = 0;
                        }
                        if(cd.action == -8)
                        {
                            drawprom(145, 95);
                            drawcs(175, "Failed.  You already have 20 cars in your account!", 0, 0, 0, 3);
                            if(drawcarb(true, null, " OK ", 379, 195, i, i_103, bool))
                                cd.action = 0;
                        }
                        if(cd.action == -7)
                        {
                            drawprom(145, 95);
                            drawcs(175, "You already have this car!", 0, 0, 0, 3);
                            if(drawcarb(true, null, " OK ", 379, 195, i, i_103, bool))
                                cd.action = 0;
                        }
                        if(cd.action == 7)
                        {
                            drawprom(145, 95);
                            drawcs(175, (new StringBuilder()).append("").append(cd.names[cd.ac]).append(" has been successfully added to your cars!").toString(), 0, 0, 0, 3);
                            if(drawcarb(true, null, " OK ", 379, 195, i, i_103, bool))
                                cd.action = 0;
                        }
                        if(cd.action == 6)
                        {
                            drawprom(145, 95);
                            drawcs(195, (new StringBuilder()).append("Adding ").append(cd.names[cd.ac]).append(" to your cars...").toString(), 0, 0, 0, 3);
                        }
                        int i_124 = 95;
                        int i_125 = 5;
                        if(multion != 0)
                        {
                            i_124 = 185;
                            i_125 = 0;
                        }
                        if(onmsc >= 16 && (cd.lastload == 2 || cd.lastload == -2))
                        {
                            if(drawcarb(false, myc, "", i_124, 105 + i_125, i, i_103, bool))
                            {
                                if(cd.lastload != 2)
                                {
                                    cfase = 5;
                                    showtf = false;
                                    if(!logged)
                                    {
                                        cd.action = 0;
                                        cd.reco = -2;
                                        tcnt = 5;
                                        cntflock = 0;
                                    } else
                                    {
                                        cd.action = 3;
                                        cd.sparkactionloader();
                                    }
                                } else
                                {
                                    cd.action = 0;
                                    minsl = 16;
                                    maxsl = cd.nlocars - 1;
                                    if(onmsc >= minsl && onmsc <= maxsl)
                                        i_111 = onmsc;
                                    else
                                        i_111 = 16;
                                    cfase = 3;
                                }
                                app.moused = false;
                            }
                        } else
                        if(drawcarb(false, gac, "", i_124, 105 + i_125, i, i_103, bool))
                        {
                            cd.action = 0;
                            minsl = 0;
                            maxsl = 15;
                            if(onmsc >= minsl && onmsc <= maxsl)
                                i_111 = onmsc;
                            else
                                i_111 = 15;
                            cfase = 0;
                            app.moused = false;
                        }
                        if(drawcarb(false, top20s, "", i_124, (i_124 - 95) / 7 + 25 + i_125, i, i_103, bool))
                        {
                            cd.action = 0;
                            cfase = 10;
                        }
                        if(cd.action == 0)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            if(!cd.createdby[sc[0] - 16].equals(nickname))
                                bool_113 = clink(cd.createdby[sc[0] - 16], i, i_103, bool);
                            else
                                rd.drawString("Created by You", 241, 160);
                            if(cfase != 101)
                            {
                                rd.setFont(new Font("Arial", 1, 11));
                                rd.drawString((new StringBuilder()).append("Added by :  ").append(cd.adds[sc[0] - 36]).append(" Players").toString(), 241, 180);
                            }
                        }
                    }
                    if(cfase == 5)
                    {
                        drawprom(145, 170);
                        if(cd.action == 5)
                        {
                            minsl = 16;
                            maxsl = cd.nlocars - 1;
                            if(cd.inslot != -1)
                            {
                                onmsc = cd.inslot;
                                cd.inslot = -1;
                            }
                            if(onmsc >= minsl && onmsc <= maxsl)
                                i_111 = onmsc;
                            else
                                i_111 = 16;
                            cfase = 3;
                        }
                        if(cd.action == 4)
                        {
                            drawcs(195, "[  Loading Car  ]", 0, 0, 0, 3);
                            drawcs(235, (new StringBuilder()).append("Loading :  ").append(app.mcars.getSelectedItem()).append("").toString(), 0, 0, 0, 3);
                        }
                        if(cd.action == -2)
                        {
                            drawcs(195, "Unknown Connection Error", 0, 0, 0, 3);
                            drawcs(225, "Failed to connect to server, try again later!", 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                                cfase = 0;
                        }
                        if(cd.action == -1)
                        {
                            drawcs(195, "No published cars found...", 0, 0, 0, 3);
                            drawcs(225, "You have no added cars to your account yet!", 0, 0, 0, 3);
                            if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                                cfase = 0;
                        }
                        if(cd.action == 2 || cd.action == 3)
                        {
                            drawcs(195, "Loading your Account Cars list...", 0, 0, 0, 3);
                            if(cd.action == 2)
                            {
                                nickname = app.tnick.getText();
                                backlog = nickname;
                                nickey = cd.tnickey;
                                clan = cd.tclan;
                                clankey = cd.tclankey;
                                app.setloggedcookie();
                                logged = true;
                                gotlog = true;
                                if(cd.reco == 0)
                                    acexp = 0;
                                if(cd.reco > 10)
                                    acexp = cd.reco - 10;
                                if(cd.reco == 3)
                                    acexp = -1;
                                if(cd.reco == 111)
                                    if(!backlog.toLowerCase().equals(nickname.toLowerCase()))
                                        acexp = -3;
                                    else
                                        acexp = 0;
                                if(basefase == 0)
                                    cd.action = 3;
                                if(basefase == 11)
                                {
                                    cd.action = 6;
                                    cfase = 11;
                                }
                                if(basefase == 101)
                                {
                                    cd.action = 6;
                                    cfase = 101;
                                }
                            }
                        }
                        if(cd.action == 1)
                            drawcs(195, "Logging in to your account...", 0, 0, 0, 3);
                        if(cd.action == 0)
                        {
                            if(cd.reco == -5)
                                drawcs(171, "Login to Add this Car to your Account", 0, 0, 0, 3);
                            if(cd.reco == -2)
                                drawcs(171, "Login to Retrieve your Account Cars", 0, 0, 0, 3);
                            if(cd.reco == -1)
                                drawcs(171, "Unable to connect to server, try again later!", 0, 8, 0, 3);
                            if(cd.reco == 1)
                                drawcs(171, "Sorry.  The Nickname you have entered is incorrect.", 0, 0, 0, 3);
                            if(cd.reco == 2)
                                drawcs(171, "Sorry.  The Password you have entered is incorrect.", 0, 0, 0, 3);
                            if(cd.reco == -167 || cd.reco == -177)
                            {
                                if(cd.reco == -167)
                                {
                                    nickname = app.tnick.getText();
                                    backlog = nickname;
                                    cd.reco = -177;
                                }
                                drawcs(171, "You are currently using a trial account.", 0, 0, 0, 3);
                            }
                            if(cd.reco == -3 && (tcnt % 3 != 0 || tcnt > 20))
                                drawcs(171, "Please enter your Nickname!", 0, 0, 0, 3);
                            if(cd.reco == -4 && (tcnt % 3 != 0 || tcnt > 20))
                                drawcs(171, "Please enter your Password!", 0, 0, 0, 3);
                            if(!showtf)
                            {
                                app.tnick.show();
                                app.tnick.setBackground(new Color(206, 237, 255));
                                if(cd.reco != 1)
                                {
                                    if(cd.reco != 2)
                                        app.tnick.setText(nickname);
                                    app.tnick.setForeground(new Color(0, 0, 0));
                                } else
                                {
                                    app.tnick.setForeground(new Color(255, 0, 0));
                                }
                                app.tnick.requestFocus();
                                app.tpass.show();
                                app.tpass.setBackground(new Color(206, 237, 255));
                                if(cd.reco != 2)
                                {
                                    if(!autolog)
                                        app.tpass.setText("");
                                    app.tpass.setForeground(new Color(0, 0, 0));
                                } else
                                {
                                    app.tpass.setForeground(new Color(255, 0, 0));
                                }
                                if(!app.tnick.getText().equals("") && cd.reco != 1)
                                    app.tpass.requestFocus();
                                showtf = true;
                            }
                            rd.drawString("Nickname:", 376 - ftm.stringWidth("Nickname:") - 14, 201);
                            rd.drawString("Password:", 376 - ftm.stringWidth("Password:") - 14, 231);
                            app.movefieldd(app.tnick, 376, 185, 129, 23, true);
                            app.movefieldd(app.tpass, 376, 215, 129, 23, true);
                            if(tcnt < 30)
                            {
                                tcnt++;
                                if(tcnt == 30)
                                {
                                    if(cd.reco == 2)
                                        app.tpass.setText("");
                                    app.tnick.setForeground(new Color(0, 0, 0));
                                    app.tpass.setForeground(new Color(0, 0, 0));
                                }
                            }
                            if(cd.reco != -177)
                            {
                                if(drawcarb(true, null, "       Login       ", 347, 247, i, i_103, bool) && tcnt > 5)
                                {
                                    tcnt = 0;
                                    if(!app.tnick.getText().equals("") && !app.tpass.getText().equals(""))
                                    {
                                        autolog = false;
                                        app.tnick.hide();
                                        app.tpass.hide();
                                        app.requestFocus();
                                        cd.action = 1;
                                        cd.sparkactionloader();
                                    } else
                                    {
                                        if(app.tpass.getText().equals(""))
                                            cd.reco = -4;
                                        if(app.tnick.getText().equals(""))
                                            cd.reco = -3;
                                    }
                                }
                            } else
                            if(drawcarb(true, null, "  Upgrade to have your own cars!  ", 284, 247, i, i_103, bool) && cntflock == 0)
                            {
                                app.editlink(nickname, true);
                                cntflock = 100;
                            }
                            if(drawcarb(true, null, "  Cancel  ", 409, 282, i, i_103, bool))
                            {
                                app.tnick.hide();
                                app.tpass.hide();
                                app.requestFocus();
                                cfase = basefase;
                            }
                            if(drawcarb(true, null, "  Register!  ", 316, 282, i, i_103, bool))
                            {
                                if(cntflock == 0)
                                {
                                    app.reglink();
                                    cntflock = 100;
                                }
                            } else
                            if(cntflock != 0)
                                cntflock--;
                        }
                    }
                    if(cfase == 4)
                    {
                        drawprom(145, 150);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Failed to find any ready car in your \u2018mycars\u2019 folder!", 215, 175);
                        rd.drawString("Please \u2018Test Drive\u2019 your cars in the Car Maker to make", 215, 215);
                        rd.drawString("sure they are ready.", 215, 235);
                        if(drawcarb(true, null, "   OK   ", 371, 255, i, i_103, bool))
                            cfase = 0;
                    }
                    if(cfase == 2)
                    {
                        drawprom(165, 70);
                        drawcs(205, "Loading Car Maker Cars...", 0, 0, 0, 3);
                        app.repaint();
                        cd.loadcarmaker();
                        if(cd.nlcars > 16)
                        {
                            minsl = 16;
                            maxsl = cd.nlcars - 1;
                            i_111 = 16;
                            cfase = 3;
                        } else
                        {
                            cfase = 4;
                        }
                    }
                    if(cfase == 1)
                    {
                        drawprom(145, 170);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("The game will now load all the cars that can be loaded", 215, 170);
                        rd.drawString("from your \u2018mycars\u2019 folder.", 215, 190);
                        rd.drawString("If a car is not loaded, then it is not ready (not finished).", 215, 210);
                        rd.drawString("Perform a \u2018Test Drive\u2019 on any car to see if it is ready or not.", 215, 230);
                        rd.drawString("The maximum number of cars that can be loaded is  40 !", 215, 260);
                        if(drawcarb(true, null, "   OK   ", 371, 275, i, i_103, bool))
                            cfase = 2;
                    }
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(181, 120, 40));
                    rd.drawString("Top Speed:", 98, 343);
                    rd.drawImage(statb, 162, 337, null);
                    rd.drawString("Acceleration:", 88, 358);
                    rd.drawImage(statb, 162, 352, null);
                    rd.drawString("Handling:", 110, 373);
                    rd.drawImage(statb, 162, 367, null);
                    rd.drawString("Stunts:", 495, 343);
                    rd.drawImage(statb, 536, 337, null);
                    rd.drawString("Strength:", 483, 358);
                    rd.drawImage(statb, 536, 352, null);
                    rd.drawString("Endurance:", 473, 373);
                    rd.drawImage(statb, 536, 367, null);
                    rd.setColor(new Color(0, 0, 0));
                    float f = (float)(cd.swits[sc[0]][2] - 220) / 90F;
                    if((double)f < 0.20000000000000001D)
                        f = 0.2F;
                    rd.fillRect((int)(162F + 156F * f), 337, (int)(156F * (1.0F - f) + 1.0F), 7);
                    f = (cd.acelf[sc[0]][1] * cd.acelf[sc[0]][0] * cd.acelf[sc[0]][2] * cd.grip[sc[0]]) / 7700F;
                    if(f > 1.0F)
                        f = 1.0F;
                    rd.fillRect((int)(162F + 156F * f), 352, (int)(156F * (1.0F - f) + 1.0F), 7);
                    f = cd.dishandle[sc[0]];
                    rd.fillRect((int)(162F + 156F * f), 367, (int)(156F * (1.0F - f) + 1.0F), 7);
                    f = ((float)cd.airc[sc[0]] * cd.airs[sc[0]] * cd.bounce[sc[0]] + 28F) / 139F;
                    if(f > 1.0F)
                        f = 1.0F;
                    rd.fillRect((int)(536F + 156F * f), 337, (int)(156F * (1.0F - f) + 1.0F), 7);
                    float f_126 = 0.5F;
                    f = (cd.moment[sc[0]] + f_126) / 2.6F;
                    if(f > 1.0F)
                        f = 1.0F;
                    rd.fillRect((int)(536F + 156F * f), 352, (int)(156F * (1.0F - f) + 1.0F), 7);
                    f = cd.outdam[sc[0]];
                    rd.fillRect((int)(536F + 156F * f), 367, (int)(156F * (1.0F - f) + 1.0F), 7);
                    rd.drawImage(statbo, 162, 337, null);
                    rd.drawImage(statbo, 162, 352, null);
                    rd.drawImage(statbo, 162, 367, null);
                    rd.drawImage(statbo, 536, 337, null);
                    rd.drawImage(statbo, 536, 352, null);
                    rd.drawImage(statbo, 536, 367, null);
                    if(multion != 0 || testdrive == 1 || testdrive == 2)
                    {
                        rd.setFont(new Font("Arial", 1, 13));
                        ftm = rd.getFontMetrics();
                        String string = "Class C";
                        if(cd.cclass[sc[0]] == 1)
                            string = "Class B & C";
                        if(cd.cclass[sc[0]] == 2)
                            string = "Class B";
                        if(cd.cclass[sc[0]] == 3)
                            string = "Class A & B";
                        if(cd.cclass[sc[0]] == 4)
                            string = "Class A";
                        if(kbload < 7)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            kbload++;
                        } else
                        {
                            rd.setColor(new Color(176, 41, 0));
                            kbload = 0;
                        }
                        if(cfase != 10 || cd.action != 0 && cd.action < 14)
                            rd.drawString(string, 549 - ftm.stringWidth(string) / 2, 95);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("1st Color", 100, 55);
                        rd.drawString("2nd Color", 649, 55);
                        rd.setFont(new Font("Arial", 1, 10));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Hue  | ", 97, 70);
                        rd.drawImage(brt, 137, 63, null);
                        rd.drawString("Hue  | ", 647, 70);
                        rd.drawImage(brt, 687, 63, null);
                        rd.drawString("Intensity", 121, 219);
                        rd.drawString("Intensity", 671, 219);
                        rd.drawString("Reset", 110, 257);
                        rd.drawString("Reset", 660, 257);
                        for(int i_127 = 0; i_127 < 161; i_127++)
                        {
                            rd.setColor(Color.getHSBColor((float)((double)(float)i_127 * 0.0062500000000000003D), 1.0F, 1.0F));
                            rd.drawLine(102, 75 + i_127, 110, 75 + i_127);
                            if(i_127 <= 128)
                            {
                                rd.setColor(Color.getHSBColor(1.0F, 0.0F, (float)(1.0D - (double)(float)i_127 * 0.0062500000000000003D)));
                                rd.drawLine(137, 75 + i_127, 145, 75 + i_127);
                            }
                            rd.setColor(Color.getHSBColor((float)((double)(float)i_127 * 0.0062500000000000003D), 1.0F, 1.0F));
                            rd.drawLine(652, 75 + i_127, 660, 75 + i_127);
                            if(i_127 <= 128)
                            {
                                rd.setColor(Color.getHSBColor(1.0F, 0.0F, (float)(1.0D - (double)(float)i_127 * 0.0062500000000000003D)));
                                rd.drawLine(687, 75 + i_127, 695, 75 + i_127);
                            }
                        }

                        for(int i_128 = 0; i_128 < 40; i_128++)
                        {
                            rd.setColor(Color.getHSBColor(arnp[0], (float)((double)(float)i_128 * 0.025000000000000001D), 1.0F - arnp[2]));
                            rd.drawLine(121 + i_128, 224, 121 + i_128, 230);
                            rd.setColor(Color.getHSBColor(arnp[3], (float)((double)(float)i_128 * 0.025000000000000001D), 1.0F - arnp[5]));
                            rd.drawLine(671 + i_128, 224, 671 + i_128, 230);
                        }

                        rd.drawImage(arn, 110, 71 + (int)(arnp[0] * 160F), null);
                        rd.drawImage(arn, 145, 71 + (int)(arnp[2] * 160F), null);
                        rd.drawImage(arn, 660, 71 + (int)(arnp[3] * 160F), null);
                        rd.drawImage(arn, 695, 71 + (int)(arnp[5] * 160F), null);
                        rd.setColor(new Color(0, 0, 0));
                        rd.fillRect(120 + (int)(arnp[1] * 40F), 222, 3, 3);
                        rd.drawLine(121 + (int)(arnp[1] * 40F), 224, 121 + (int)(arnp[1] * 40F), 230);
                        rd.fillRect(120 + (int)(arnp[1] * 40F), 230, 3, 3);
                        rd.fillRect(670 + (int)(arnp[4] * 40F), 222, 3, 3);
                        rd.drawLine(671 + (int)(arnp[4] * 40F), 224, 671 + (int)(arnp[4] * 40F), 230);
                        rd.fillRect(670 + (int)(arnp[4] * 40F), 230, 3, 3);
                        if(bool)
                        {
                            if(mouson == -1)
                            {
                                if(i > 96 && i < 152 && i_103 > 248 && i_103 < 258)
                                {
                                    float fs[] = new float[3];
                                    Color.RGBtoHSB(contos[sc[0]].fcol[0], contos[sc[0]].fcol[1], contos[sc[0]].fcol[2], fs);
                                    arnp[0] = fs[0];
                                    arnp[1] = fs[1];
                                    arnp[2] = 1.0F - fs[2];
                                }
                                if(i > 646 && i < 702 && i_103 > 248 && i_103 < 258)
                                {
                                    float fs[] = new float[3];
                                    Color.RGBtoHSB(contos[sc[0]].scol[0], contos[sc[0]].scol[1], contos[sc[0]].scol[2], fs);
                                    arnp[3] = fs[0];
                                    arnp[4] = fs[1];
                                    arnp[5] = 1.0F - fs[2];
                                }
                                mouson = -2;
                                if(i > 119 && i < 163 && i_103 > 222 && i_103 < 232)
                                    mouson = 1;
                                if(i > 669 && i < 713 && i_103 > 222 && i_103 < 232)
                                    mouson = 4;
                                if(i > 98 && i < 122 && i_103 > 69 && i_103 < 241 && mouson == -2)
                                    mouson = 0;
                                if(i > 133 && i < 157 && i_103 > 69 && i_103 < 209 && mouson == -2)
                                    mouson = 2;
                                if(i > 648 && i < 672 && i_103 > 69 && i_103 < 241 && mouson == -2)
                                    mouson = 3;
                                if(i > 683 && i < 707 && i_103 > 69 && i_103 < 209 && mouson == -2)
                                    mouson = 5;
                            }
                        } else
                        if(mouson != -1)
                            mouson = -1;
                        if(mouson == 0 || mouson == 2 || mouson == 3 || mouson == 5)
                        {
                            arnp[mouson] = (float)((double)((float)i_103 - 75F) * 0.0062500000000000003D);
                            if(mouson == 2 || mouson == 5)
                            {
                                if((double)arnp[mouson] > 0.80000000000000004D)
                                    arnp[mouson] = 0.8F;
                            } else
                            if(arnp[mouson] > 1.0F)
                                arnp[mouson] = 1.0F;
                            if(arnp[mouson] < 0.0F)
                                arnp[mouson] = 0.0F;
                        }
                        if(mouson == 1)
                        {
                            arnp[mouson] = (float)((double)((float)i - 121F) * 0.025000000000000001D);
                            if(arnp[mouson] > 1.0F)
                                arnp[mouson] = 1.0F;
                            if(arnp[mouson] < 0.0F)
                                arnp[mouson] = 0.0F;
                        }
                        if(mouson == 4)
                        {
                            arnp[mouson] = (float)((double)((float)i - 671F) * 0.025000000000000001D);
                            if(arnp[mouson] > 1.0F)
                                arnp[mouson] = 1.0F;
                            if(arnp[mouson] < 0.0F)
                                arnp[mouson] = 0.0F;
                        }
                        if(cfase != 10 && cfase != 5 && i_111 == -1)
                        {
                            Color color = Color.getHSBColor(arnp[0], arnp[1], 1.0F - arnp[2]);
                            Color color_129 = Color.getHSBColor(arnp[3], arnp[4], 1.0F - arnp[5]);
                            for(int i_130 = 0; i_130 < contos[sc[0]].npl; i_130++)
                            {
                                if(contos[sc[0]].p[i_130].colnum == 1)
                                {
                                    contos[sc[0]].p[i_130].hsb[0] = arnp[0];
                                    contos[sc[0]].p[i_130].hsb[1] = arnp[1];
                                    contos[sc[0]].p[i_130].hsb[2] = 1.0F - arnp[2];
                                    contos[sc[0]].p[i_130].c[0] = color.getRed();
                                    contos[sc[0]].p[i_130].c[1] = color.getGreen();
                                    contos[sc[0]].p[i_130].c[2] = color.getBlue();
                                    contos[sc[0]].p[i_130].oc[0] = color.getRed();
                                    contos[sc[0]].p[i_130].oc[1] = color.getGreen();
                                    contos[sc[0]].p[i_130].oc[2] = color.getBlue();
                                }
                                if(contos[sc[0]].p[i_130].colnum == 2)
                                {
                                    contos[sc[0]].p[i_130].hsb[0] = arnp[3];
                                    contos[sc[0]].p[i_130].hsb[1] = arnp[4];
                                    contos[sc[0]].p[i_130].hsb[2] = 1.0F - arnp[5];
                                    contos[sc[0]].p[i_130].c[0] = color_129.getRed();
                                    contos[sc[0]].p[i_130].c[1] = color_129.getGreen();
                                    contos[sc[0]].p[i_130].c[2] = color_129.getBlue();
                                    contos[sc[0]].p[i_130].oc[0] = color_129.getRed();
                                    contos[sc[0]].p[i_130].oc[1] = color_129.getGreen();
                                    contos[sc[0]].p[i_130].oc[2] = color_129.getBlue();
                                }
                            }

                        }
                    }
                }
                if(!remi && cfase != 10 && cfase != 11 && cfase != 100 && cfase != 101)
                {
                    rd.drawImage(contin[pcontin], 355, 385, null);
                } else
                {
                    if(cfase == 11 && drawcarb(true, null, "Add to My Cars", 345, 385, i, i_103, bool) && cd.action == 0)
                    {
                        cd.ac = sc[0];
                        if(logged)
                        {
                            cd.action = 6;
                            cd.sparkactionloader();
                        } else
                        {
                            cd.reco = -5;
                            cfase = 5;
                            showtf = false;
                        }
                    }
                    if(cfase == 101 && i_111 == -1)
                        if(cd.publish[sc[0] - 16] == 1 || cd.publish[sc[0] - 16] == 2)
                        {
                            if(drawcarb(true, null, "Add to My Cars", 345, 385, i, i_103, bool) && cd.action == 0)
                            {
                                cd.ac = sc[0];
                                if(logged)
                                {
                                    cd.action = 6;
                                    cd.sparkactionloader();
                                } else
                                {
                                    cd.reco = -5;
                                    cfase = 5;
                                    showtf = false;
                                }
                            }
                        } else
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            drawcs(405, "Private Car", 193, 106, 0, 3);
                        }
                }
            }
        } else
        {
            if(cfase == 11 || cfase == 101)
                cd.action = 0;
            if(app.mycar.isShowing())
                app.mycar.hide();
            pback = 0;
            pnext = 0;
            gatey = 300;
            if(flipo > 10)
            {
                contos[sc[0]].y -= 100;
                if(nextc == 1)
                    contos[sc[0]].zy += 20;
                if(nextc == -1)
                    contos[sc[0]].zy -= 20;
            } else
            {
                if(flipo == 10)
                {
                    if(nextc >= 20)
                    {
                        sc[0] = nextc - 20;
                        lsc = -1;
                    }
                    if(nextc == 1)
                    {
                        sc[0]++;
                        if(gmode == 1)
                        {
                            if(sc[0] == 7)
                                sc[0] = 11;
                            if(sc[0] == 12)
                                sc[0] = 14;
                        }
                        if(multion != 0 && onjoin != -1 && ontyp > 0 && ontyp <= 5)
                            for(; sc[0] < maxsl && Math.abs(cd.cclass[sc[0]] - (ontyp - 1)) > 1; sc[0]++);
                    }
                    if(nextc == -1)
                    {
                        sc[0]--;
                        if(gmode == 1)
                        {
                            if(sc[0] == 13)
                                sc[0] = 11;
                            if(sc[0] == 10)
                                sc[0] = 6;
                        }
                        if(multion != 0 && onjoin != -1 && ontyp > 0 && ontyp <= 5)
                            for(; sc[0] > minsl && Math.abs(cd.cclass[sc[0]] - (ontyp - 1)) > 1; sc[0]--);
                    }
                    if(cfase == 3 && cd.lastload == 2)
                        app.mcars.select(cd.names[sc[0]]);
                    contos[sc[0]].z = 950;
                    contos[sc[0]].y = -34 - contos[sc[0]].grat - 1100;
                    contos[sc[0]].x = 0;
                    contos[sc[0]].zy = 0;
                }
                contos[sc[0]].y += 100;
            }
            flipo--;
        }
        if(cfase == 0 || cfase == 3 || cfase == 11 || cfase == 101)
        {
            basefase = cfase;
            if(i_111 != -1)
            {
                if(flatrstart > 1)
                    flatrstart = 0;
                nextc = i_111 + 20;
                flipo = 20;
            }
            if(control.right)
            {
                control.right = false;
                if(sc[0] != maxsl && flipo == 0)
                {
                    if(flatrstart > 1)
                        flatrstart = 0;
                    nextc = 1;
                    flipo = 20;
                    if(cfase == 0 && (multion == 1 || multion == 3))
                        app.mgmcars.select(sc[0] + 1);
                }
            }
            if(control.left)
            {
                control.left = false;
                if(sc[0] != minsl && flipo == 0)
                {
                    if(flatrstart > 1)
                        flatrstart = 0;
                    nextc = -1;
                    flipo = 20;
                    if(cfase == 0 && (multion == 1 || multion == 3))
                        app.mgmcars.select(sc[0] - 1);
                }
            }
            if(cfase != 11 && cfase != 101 && i_112 == 0 && flipo < 10 && (control.handb || control.enter))
            {
                m.crs = false;
                app.mcars.show = false;
                app.mgmcars.hide();
                if(multion != 0)
                {
                    fase = 1177;
                    intertrack.stop();
                } else
                if(testdrive != 3 && testdrive != 4)
                    fase = 3;
                else
                    fase = -22;
                if(sc[0] < 16 || cd.lastload == 2)
                    app.setcarcookie(sc[0], cd.names[sc[0]], arnp, gmode, unlocked, mtop);
                if(cd.haltload != 0)
                {
                    if(cd.haltload == 2)
                        cd.lcardate[1] = 0;
                    cd.lcardate[0] = 0;
                    cd.haltload = 0;
                }
                if(gmode == 0)
                    osc = sc[0];
                if(gmode == 1)
                    scm[0] = sc[0];
                if(gmode == 2)
                    scm[1] = sc[0];
                if(app.mycar.isShowing())
                    app.mycar.hide();
                flexpix = null;
                control.handb = false;
                control.enter = false;
            }
        } else
        {
            pback = 0;
            pnext = 0;
            pcontin = 0;
            if(cfase == 8 && i_111 != -1)
            {
                if(flatrstart > 1)
                    flatrstart = 0;
                nextc = i_111 + 20;
                flipo = 20;
            }
            if(cfase == 5 && cd.action == 0 && control.enter)
            {
                tcnt = 0;
                if(!app.tnick.getText().equals("") && !app.tpass.getText().equals(""))
                {
                    app.tnick.hide();
                    app.tpass.hide();
                    app.requestFocus();
                    cd.action = 1;
                    cd.sparkactionloader();
                } else
                {
                    if(app.tpass.getText().equals(""))
                        cd.reco = -4;
                    if(app.tnick.getText().equals(""))
                        cd.reco = -3;
                }
                control.enter = false;
            }
        }
        if(control.handb || control.enter)
        {
            control.handb = false;
            control.enter = false;
        }
        if(bool_113)
        {
            app.mouses = 0;
            onviewpro = true;
            cd.viewname = cd.createdby[sc[0] - 16];
            m.crs = false;
            fase = 1177;
            intertrack.stop();
            sc[0] = onmsc;
            if(sc[0] >= 16 && cd.lastload != 2 || sc[0] >= 36)
                sc[0] = 15;
            osc = sc[0];
            multion = 1;
            gmode = 0;
            if(app.mycar.isShowing())
                app.mycar.hide();
            flexpix = null;
            control.handb = false;
            control.enter = false;
        }
    }

    public void colorCar(ContO conto, int i)
    {
        if(plnames[i].indexOf("MadBot") == -1)
        {
            for(int i_131 = 0; i_131 < conto.npl; i_131++)
            {
                if(conto.p[i_131].colnum == 1)
                {
                    Color color = Color.getHSBColor(allrnp[i][0], allrnp[i][1], 1.0F - allrnp[i][2]);
                    conto.p[i_131].oc[0] = color.getRed();
                    conto.p[i_131].oc[1] = color.getGreen();
                    conto.p[i_131].oc[2] = color.getBlue();
                }
                if(conto.p[i_131].colnum == 2)
                {
                    Color color = Color.getHSBColor(allrnp[i][3], allrnp[i][4], 1.0F - allrnp[i][5]);
                    conto.p[i_131].oc[0] = color.getRed();
                    conto.p[i_131].oc[1] = color.getGreen();
                    conto.p[i_131].oc[2] = color.getBlue();
                }
            }

        } else
        {
            for(int i_132 = 0; i_132 < conto.npl; i_132++)
            {
                if(conto.p[i_132].colnum == 1)
                {
                    conto.p[i_132].oc[0] = conto.fcol[0];
                    conto.p[i_132].oc[1] = conto.fcol[1];
                    conto.p[i_132].oc[2] = conto.fcol[2];
                }
                if(conto.p[i_132].colnum == 2)
                {
                    conto.p[i_132].oc[0] = conto.scol[0];
                    conto.p[i_132].oc[1] = conto.scol[1];
                    conto.p[i_132].oc[2] = conto.scol[2];
                }
            }

        }
    }

    public boolean clink(String string, int i, int i_133, boolean bool)
    {
        boolean bool_134 = false;
        rd.drawString((new StringBuilder()).append("Created by :  ").append(string).append("").toString(), 241, 160);
        int i_135 = ftm.stringWidth(string);
        int i_136 = (241 + ftm.stringWidth((new StringBuilder()).append("Created by :  ").append(string).append("").toString())) - i_135;
        rd.drawLine(i_136, 162, (i_136 + i_135) - 2, 162);
        if(i > i_136 - 2 && i < i_136 + i_135 && i_133 > 147 && i_133 < 164)
        {
            if(bool)
                bool_134 = true;
            if(waitlink != 1)
            {
                app.setCursor(new Cursor(12));
                waitlink = 1;
            }
        } else
        if(waitlink != 0)
        {
            app.setCursor(new Cursor(0));
            waitlink = 0;
        }
        return bool_134;
    }

    public void drawprom(int i, int i_137)
    {
        rd.setComposite(AlphaComposite.getInstance(3, 0.76F));
        rd.setColor(new Color(129, 203, 237));
        rd.fillRoundRect(205, i, 390, i_137, 30, 30);
        rd.setColor(new Color(0, 0, 0));
        rd.drawRoundRect(205, i, 390, i_137, 30, 30);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
    }

    public void drawdprom(int i, int i_138)
    {
        rd.setComposite(AlphaComposite.getInstance(3, 0.9F));
        rd.setColor(new Color(129, 203, 237));
        rd.fillRoundRect(205, i, 390, i_138, 30, 30);
        rd.setColor(new Color(0, 0, 0));
        rd.drawRoundRect(205, i, 390, i_138, 30, 30);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
    }

    public void drawlprom(int i, int i_139)
    {
        rd.setComposite(AlphaComposite.getInstance(3, 0.5F));
        rd.setColor(new Color(129, 203, 237));
        rd.fillRoundRect(277, i, 390, i_139, 30, 30);
        rd.setColor(new Color(0, 0, 0));
        rd.drawRoundRect(277, i, 390, i_139, 30, 30);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
    }

    public void finish(CheckPoints checkpoints, ContO contos[], Control control, int i, int i_140, boolean bool)
    {
        if(!badmac)
        {
            rd.drawImage(fleximg, 0, 0, null);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
            rd.fillRect(0, 0, 800, 450);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        int i_141 = 0;
        String string = ":";
        if(checkpoints.stage > 0)
        {
            int i_142 = checkpoints.stage;
            if(i_141 > 27)
                i_141 -= 27;
            if(i_142 > 10)
                i_142 -= 10;
            string = (new StringBuilder()).append(" ").append(i_142).append("!").toString();
        }
        if(multion < 3)
        {
            if(winner)
            {
                rd.drawImage(congrd, 265, 87, null);
                drawcs(137, (new StringBuilder()).append("You Won!  At Stage").append(string).append("").toString(), 255, 161, 85, 3);
                drawcs(154, (new StringBuilder()).append("").append(checkpoints.name).append("").toString(), 255, 115, 0, 3);
                i_141 = 154;
            } else
            {
                rd.drawImage(gameov, 315, 117, null);
                if(multion != 0 && (forstart == 700 || discon == 240))
                {
                    drawcs(167, "Sorry, You where Disconnected from Game!", 255, 161, 85, 3);
                    drawcs(184, "Please check your connection!", 255, 115, 0, 3);
                } else
                {
                    drawcs(167, (new StringBuilder()).append("You Lost!  At Stage").append(string).append("").toString(), 255, 161, 85, 3);
                    drawcs(184, (new StringBuilder()).append("").append(checkpoints.name).append("").toString(), 255, 115, 0, 3);
                    i_141 = 184;
                }
            }
        } else
        {
            rd.drawImage(gameov, 315, 117, null);
            drawcs(167, (new StringBuilder()).append("Finished Watching Game!  At Stage").append(string).append("").toString(), 255, 161, 85, 3);
            drawcs(184, (new StringBuilder()).append("").append(checkpoints.name).append("").toString(), 255, 115, 0, 3);
            i_141 = 184;
        }
        if(winner && multion == 0 && gmode != 0 && (checkpoints.stage == unlocked[gmode - 1] + (gmode - 1) * 10 || checkpoints.stage == 27))
        {
            int i_143 = 0;
            int i_144 = 0;
            pin = 60;
            if(gmode == 1)
            {
                if(checkpoints.stage == 2)
                {
                    i_143 = 5;
                    i_144 = 365;
                    pin = -20;
                    scm[0] = 5;
                }
                if(checkpoints.stage == 4)
                {
                    i_143 = 6;
                    i_144 = 320;
                    pin = -20;
                    scm[0] = 6;
                }
                if(checkpoints.stage == 6)
                {
                    i_143 = 11;
                    i_144 = 326;
                    pin = -20;
                    scm[0] = 11;
                }
                if(checkpoints.stage == 8)
                {
                    i_143 = 14;
                    i_144 = 350;
                    pin = -20;
                    scm[0] = 14;
                }
                if(checkpoints.stage == 10)
                {
                    i_143 = 15;
                    i_144 = 370;
                    pin = -20;
                    scm[0] = 15;
                }
            }
            if(gmode == 2)
            {
                if(checkpoints.stage == 12)
                {
                    i_143 = 8;
                    i_144 = 365;
                    pin = -20;
                    scm[1] = 8;
                }
                if(checkpoints.stage == 14)
                {
                    i_143 = 9;
                    i_144 = 320;
                    pin = -20;
                    scm[1] = 9;
                }
                if(checkpoints.stage == 16)
                {
                    i_143 = 10;
                    i_144 = 370;
                    pin = -20;
                    scm[1] = 10;
                }
                if(checkpoints.stage == 18)
                {
                    i_143 = 11;
                    i_144 = 326;
                    pin = -20;
                    scm[1] = 11;
                }
                if(checkpoints.stage == 20)
                {
                    i_143 = 12;
                    i_144 = 310;
                    pin = -20;
                    scm[1] = 12;
                }
                if(checkpoints.stage == 22)
                {
                    i_143 = 13;
                    i_144 = 310;
                    pin = -20;
                    scm[1] = 13;
                }
                if(checkpoints.stage == 24)
                {
                    i_143 = 14;
                    i_144 = 350;
                    pin = -20;
                    scm[1] = 14;
                }
                if(checkpoints.stage == 26)
                {
                    i_143 = 15;
                    i_144 = 370;
                    pin = -20;
                    scm[1] = 15;
                }
            }
            if(checkpoints.stage != 27)
            {
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(aflk)
                    drawcs(200 + pin, (new StringBuilder()).append("Stage ").append((checkpoints.stage + 1) - (gmode - 1) * 10).append(" is now unlocked!").toString(), 196, 176, 0, 3);
                else
                    drawcs(200 + pin, (new StringBuilder()).append("Stage ").append((checkpoints.stage + 1) - (gmode - 1) * 10).append(" is now unlocked!").toString(), 255, 247, 165, 3);
                if(i_143 != 0)
                {
                    if(aflk)
                        drawcs(200, "And:", 196, 176, 0, 3);
                    else
                        drawcs(200, "And:", 255, 247, 165, 3);
                    rd.setColor(new Color(236, 226, 202));
                    if(Math.random() > 0.5D)
                    {
                        rd.setComposite(AlphaComposite.getInstance(3, 0.5F));
                        rd.fillRect(226, 211, 344, 125);
                        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.fillRect(226, 211, 348, 4);
                    rd.fillRect(226, 211, 4, 125);
                    rd.fillRect(226, 332, 348, 4);
                    rd.fillRect(570, 211, 4, 125);
                    contos[i_143].y = i_144;
                    m.crs = true;
                    m.x = -400;
                    m.y = 0;
                    m.z = -50;
                    m.xz = 0;
                    m.zy = 0;
                    m.ground = 2470;
                    contos[i_143].z = 1000;
                    contos[i_143].x = 0;
                    contos[i_143].xz += 5;
                    contos[i_143].zy = 0;
                    contos[i_143].wzy -= 10;
                    rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                    contos[i_143].d(rd);
                    rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    if(Math.random() < 0.5D)
                    {
                        rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                        rd.setColor(new Color(236, 226, 202));
                        for(int i_145 = 0; i_145 < 30; i_145++)
                            rd.drawLine(230, 215 + 4 * i_145, 569, 215 + 4 * i_145);

                        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    }
                    String string_146 = "";
                    if(i_143 == 13)
                        string_146 = " ";
                    if(aflk)
                        drawcs(320, (new StringBuilder()).append("").append(cd.names[i_143]).append("").append(string_146).append(" has been unlocked!").toString(), 196, 176, 0, 3);
                    else
                        drawcs(320, (new StringBuilder()).append("").append(cd.names[i_143]).append("").append(string_146).append(" has been unlocked!").toString(), 255, 247, 165, 3);
                    pin = 140;
                }
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
                drawcs(220 + pin, "GAME SAVED", 230, 167, 0, 3);
                if(pin == 60)
                    pin = 30;
                else
                    pin = 0;
            } else
            {
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                if(aflk)
                    drawcs(180, (new StringBuilder()).append("Woohoooo you finished NFM").append(gmode).append(" !!!").toString(), 144, 167, 255, 3);
                else
                    drawcs(180, (new StringBuilder()).append("Woohoooo you finished NFM").append(gmode).append(" !!!").toString(), 228, 240, 255, 3);
                if(aflk)
                    drawcs(210, "You're Awesome!", 144, 167, 255, 3);
                else
                    drawcs(212, "You're Awesome!", 228, 240, 255, 3);
                if(aflk)
                    drawcs(240, "You're truly a RADICAL GAMER!", 144, 167, 255, 3);
                else
                    drawcs(240, "You're truly a RADICAL GAMER!", 255, 100, 100, 3);
                rd.setColor(new Color(0, 0, 0));
                rd.fillRect(0, 255, 800, 62);
                rd.drawImage(radicalplay, radpx + (int)(8D * Math.random() - 4D), 255, null);
                if(radpx != 212)
                {
                    radpx += 40;
                    if(radpx > 800)
                        radpx = -468;
                }
                if(flipo == 40)
                    radpx = 213;
                flipo++;
                if(flipo == 70)
                    flipo = 0;
                if(radpx == 212)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    if(aflk)
                        drawcs(309, "A Game by Radicalplay.com", 144, 167, 255, 3);
                    else
                        drawcs(309, "A Game by Radicalplay.com", 228, 240, 255, 3);
                }
                if(aflk)
                    drawcs(350, "Now get up and dance!", 144, 167, 255, 3);
                else
                    drawcs(350, "Now get up and dance!", 228, 240, 255, 3);
                pin = 0;
            }
            if(aflk)
                aflk = false;
            else
                aflk = true;
        }
        if(multion != 0 && checkpoints.stage == -2 && i_141 != 0)
        {
            drawcs(i_141 + 17, (new StringBuilder()).append("Created by: ").append(checkpoints.maker).append("").toString(), 255, 161, 85, 3);
            if(checkpoints.pubt > 0)
            {
                if(checkpoints.pubt == 2)
                    drawcs(310, "Super Public Stage", 41, 177, 255, 3);
                else
                    drawcs(310, "Public Stage", 41, 177, 255, 3);
                if(dnload == 0 && drawcarb(true, null, " Add to My Stages ", 334, 317, i, i_140, bool))
                    if(logged)
                    {
                        cd.onstage = checkpoints.name;
                        cd.staction = 2;
                        cd.sparkstageaction();
                        dnload = 2;
                    } else
                    {
                        dnload = 1;
                        waitlink = 20;
                    }
                if(dnload == 1)
                {
                    rd.setColor(new Color(193, 106, 0));
                    String string_147 = "Upgrade to a full account to add custom stages!";
                    int i_148 = 400 - ftm.stringWidth(string_147) / 2;
                    int i_149 = i_148 + ftm.stringWidth(string_147);
                    rd.drawString(string_147, i_148, 332);
                    if(waitlink != -1)
                        rd.drawLine(i_148, 334, i_149, 334);
                    if(i > i_148 && i < i_149 && i_140 > 321 && i_140 < 334)
                    {
                        if(waitlink != -1)
                            app.setCursor(new Cursor(12));
                        if(bool && waitlink == 0)
                        {
                            app.editlink(nickname, true);
                            waitlink = -1;
                        }
                    } else
                    {
                        app.setCursor(new Cursor(0));
                    }
                    if(waitlink > 0)
                        waitlink--;
                }
                if(dnload == 2)
                {
                    drawcs(332, "Adding stage please wait...", 193, 106, 0, 3);
                    if(cd.staction == 0)
                        dnload = 3;
                    if(cd.staction == -2)
                        dnload = 4;
                    if(cd.staction == -3)
                        dnload = 5;
                    if(cd.staction == -1)
                        dnload = 6;
                }
                if(dnload == 3)
                    drawcs(332, "Stage has been successfully added to your stages!", 193, 106, 0, 3);
                if(dnload == 4)
                    drawcs(332, "You already have this stage!", 193, 106, 0, 3);
                if(dnload == 5)
                    drawcs(332, "Cannot add more then 20 stages to your account!", 193, 106, 0, 3);
                if(dnload == 6)
                    drawcs(332, "Failed to add stage, unknown error, please try again later.", 193, 106, 0, 3);
            } else
            {
                drawcs(342, "Private Stage", 193, 106, 0, 3);
            }
        }
        if(nplayers == 1)
        {
            rd.setFont(new Font("Arial", 1, 14));
            ftm = rd.getFontMetrics();
            if(checkpoints.stage > 0 && testdrive == 0 && sc[im] < 16)
            {
                rd.setColor(new Color(193, 106, 0));
                rd.drawString((new StringBuilder()).append("Your time: ").append(chrono.getTotalTime()).toString(), 380 - ftm.stringWidth((new StringBuilder()).append("Your time: ").append(chrono.getTotalTime()).toString()), 183);
                rd.drawString((new StringBuilder()).append("Best lap: ").append(chrono.getBestLapTime()).toString(), 420, 183);
                rd.drawRect(200, 200, 399, 20);
                rd.drawRect(200, 220, 399, 100);
                rd.drawLine(400, 200, 400, rs.state != 1 ? 220 : 320);
                rd.setColor(new Color(255, 161, 85));
                rd.drawString("Best track times", 300 - ftm.stringWidth("Best track times") / 2, 215);
                rd.drawString("Best lap times", 500 - ftm.stringWidth("Best lap times") / 2, 215);
                if(rs.state == 1)
                {
                    int sel = app.mscores.getSelectedIndex();
                    for(int j = 0; j < 2; j++)
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.setColor(new Color(255, 161, 85));
                        for(int k = 0; k < rs.names[sel][j].length; k++)
                        {
                            bool = rs.names[sel][j][k].equalsIgnoreCase(nickname);
                            if(bool)
                            {
                                rd.setColor(new Color(253, 166, 0));
                                rd.fillRect(201 + j * 200, 221 + k * 20, 198, 19);
                                rd.setColor(Color.BLACK);
                            }
                            rd.drawString(rs.names[sel][j][k], 205 + j * 200, 235 + k * 20);
                            if(bool)
                                rd.setColor(new Color(255, 161, 85));
                        }

                        rd.setFont(fontDigital.deriveFont(1, 12F));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(255, 196, 0));
                        Object hint = rd.getRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING);
                        rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
                        for(int k = 0; k < rs.times[sel][j].length; k++)
                        {
                            bool = rs.names[sel][j][k].equalsIgnoreCase(nickname);
                            if(bool)
                                rd.setColor(Color.BLACK);
                            if(rs.times[sel][j][k] > 0L)
                                rd.drawString(chrono.getTime(rs.times[sel][j][k]), (395 + j * 200) - ftm.stringWidth(chrono.getTime(rs.times[sel][j][k])), 235 + k * 20);
                            if(bool)
                                rd.setColor(new Color(255, 196, 0));
                        }

                        rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, hint);
                    }

                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    drawcs(346, "", 193, 106, 0, 3);
                    rd.drawString("Filter results:", 295, 356);
                    app.mscores.show();
                } else
                {
                    if(rs.state == 0)
                        drawcs(250, "Loading best time scores...", 193, 106, 0, 3);
                    if(rs.state == -1)
                    {
                        drawcs(250, "Error loading scores", 193, 106, 0, 3);
                        drawcs(270, rs.exp, 193, 106, 0, 3);
                    }
                    if(rs.state == -2)
                    {
                        drawcs(250, "Error loading scores", 193, 106, 0, 3);
                        drawcs(270, "One of the sent parameters might be invalid", 193, 106, 0, 3);
                        drawcs(290, "Where you trying to cheat or something?", 193, 106, 0, 3);
                    }
                }
            } else
            {
                drawcs(332, (new StringBuilder()).append("Your time: ").append(chrono.getTotalTime()).toString(), 193, 106, 0, 3);
                drawcs(352, (new StringBuilder()).append("Best lap: ").append(chrono.getBestLapTime()).toString(), 193, 106, 0, 3);
            }
        }
        rd.drawImage(contin[pcontin], 355, 380, null);
        if(control.enter || control.handb)
        {
            if(loadedt)
                strack.unload();
            if(multion == 0)
            {
                opselect = 3;
                if(gmode == 1)
                {
                    opselect = 0;
                    if(winner && checkpoints.stage == unlocked[gmode - 1] + (gmode - 1) * 10 && checkpoints.stage != 27)
                    {
                        unlocked[gmode - 1]++;
                        justwon1 = true;
                    } else
                    {
                        justwon1 = false;
                    }
                }
                if(gmode == 2)
                {
                    opselect = 1;
                    if(winner && checkpoints.stage == unlocked[gmode - 1] + (gmode - 1) * 10 && checkpoints.stage != 27)
                    {
                        unlocked[gmode - 1]++;
                        justwon2 = true;
                    } else
                    {
                        justwon2 = false;
                    }
                }
                if(checkpoints.stage == 32 && gmode == 0)
                    checkpoints.stage = (int)(Math.random() * 32D) + 1;
                fase = 102;
            } else
            if(cd.haltload == 1)
            {
                sc[0] = 36;
                fase = 1177;
            } else
            if(!mtop || nfreeplays >= 5 && !logged)
            {
                opselect = 2;
                fase = 102;
            } else
            {
                fase = -9;
            }
            if(multion == 0 && winner && checkpoints.stage != 32 && checkpoints.stage > 0)
                checkpoints.stage++;
            if(!winner && multion != 0 && (forstart == 700 || discon == 240) && ndisco < 5)
                ndisco++;
            flipo = 0;
            app.mscores.hide();
            control.enter = false;
            control.handb = false;
        }
    }

    public void sortcars(int i)
    {
        if(i != 0)
        {
            for(int i_150 = 1; i_150 < 7; i_150++)
                sc[i_150] = -1;

            boolean bools[] = new boolean[7];
            if(i < 0)
                i = 27;
            int i_151 = 7;
            if(gmode == 1)
                i_151 = 5;
            boolean bool = false;
            if(i <= 10)
            {
                int i_152 = 6;
                if(gmode == 1)
                    i_152 = 4;
                if((i == 1 || i == 2) && sc[0] != 5)
                {
                    sc[i_152] = 5;
                    i_151 = i_152;
                }
                if((i == 3 || i == 4) && sc[0] != 6)
                {
                    sc[i_152] = 6;
                    i_151 = i_152;
                }
                if((i == 5 || i == 6) && sc[0] != 11)
                {
                    sc[i_152] = 11;
                    i_151 = i_152;
                }
                if((i == 7 || i == 8) && sc[0] != 14)
                {
                    sc[i_152] = 14;
                    i_151 = i_152;
                }
                if((i == 9 || i == 10) && sc[0] != 15)
                {
                    sc[i_152] = 15;
                    i_151 = i_152;
                }
            } else
            if(i <= 27)
            {
                i -= 10;
                bool = true;
                if(sc[0] != 7 + (i + 1) / 2 && i != 17)
                {
                    sc[6] = 7 + (i + 1) / 2;
                    i_151 = 6;
                }
            } else
            {
                i -= 27;
                bool = true;
                if(sc[0] != 7 + (i + 1) / 2 && i != 17)
                {
                    sc[6] = 7 + (i + 1) / 2;
                    i_151 = 6;
                }
            }
            int i_153 = 16;
            int i_154 = 1;
            int i_155 = 2;
            for(int i_156 = 1; i_156 < i_151; i_156++)
            {
                bools[i_156] = false;
                do
                {
                    if(bools[i_156])
                        break;
                    float f = 10F;
                    if(bool)
                        f = 17F;
                    sc[i_156] = (int)(Math.random() * (double)(24F + 8F * ((float)i / f)));
                    if(sc[i_156] >= 16)
                        sc[i_156] -= 16;
                    bools[i_156] = true;
                    for(int i_157 = 0; i_157 < 7; i_157++)
                        if(i_156 != i_157 && sc[i_156] == sc[i_157])
                            bools[i_156] = false;

                    if(bool)
                        f = 16F;
                    float f_158 = ((float)(15 - sc[i_156]) / 15F) * ((float)i / f);
                    if((double)f_158 > 0.80000000000000004D)
                        f_158 = 0.8F;
                    if(i == 17 && (double)f_158 > 0.5D)
                        f_158 = 0.5F;
                    if((double)f_158 > Math.random())
                        bools[i_156] = false;
                    if(gmode == 1)
                    {
                        if(sc[i_156] >= 7 && sc[i_156] <= 10)
                            bools[i_156] = false;
                        if(sc[i_156] == 12 || sc[i_156] == 13)
                            bools[i_156] = false;
                        if(sc[i_156] > 5 && unlocked[0] <= 2)
                            bools[i_156] = false;
                        if(sc[i_156] > 6 && unlocked[0] <= 4)
                            bools[i_156] = false;
                        if(sc[i_156] > 11 && unlocked[0] <= 6)
                            bools[i_156] = false;
                        if(sc[i_156] > 14 && unlocked[0] <= 8)
                            bools[i_156] = false;
                    }
                    if(gmode == 2)
                    {
                        if((sc[i_156] - 7) * 2 > unlocked[1])
                            bools[i_156] = false;
                        if(i == 16 && unlocked[1] == 16 && sc[i_156] < 9)
                            bools[i_156] = false;
                    }
                } while(true);
                if(sc[i_156] >= i_153)
                    continue;
                i_153 = sc[i_156];
                if(i_154 != i_156)
                {
                    i_155 = i_154;
                    i_154 = i_156;
                }
            }

            if(!bool && i == 10)
            {
                boolean bool_159 = false;
                for(int i_160 = 0; i_160 < 7; i_160++)
                    if(sc[i_160] == 11)
                        bool_159 = true;

                if(!bool_159 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_154] = 11;
                bool_159 = false;
                for(int i_161 = 0; i_161 < 7; i_161++)
                    if(sc[i_161] == 14)
                        bool_159 = true;

                if(!bool_159 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_155] = 14;
            }
            if(i == 12)
            {
                boolean bool_162 = false;
                for(int i_163 = 0; i_163 < 7; i_163++)
                    if(sc[i_163] == 11)
                        bool_162 = true;

                if(!bool_162)
                    sc[i_154] = 11;
            }
            if(i == 14)
            {
                boolean bool_164 = false;
                for(int i_165 = 0; i_165 < 7; i_165++)
                    if(sc[i_165] == 12)
                        bool_164 = true;

                if(!bool_164 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_154] = 12;
                bool_164 = false;
                for(int i_166 = 0; i_166 < 7; i_166++)
                    if(sc[i_166] == 10)
                        bool_164 = true;

                if(!bool_164 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_155] = 10;
            }
            if(i == 15)
            {
                boolean bool_167 = false;
                for(int i_168 = 0; i_168 < 7; i_168++)
                    if(sc[i_168] == 11)
                        bool_167 = true;

                if(!bool_167 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_154] = 11;
                bool_167 = false;
                for(int i_169 = 0; i_169 < 7; i_169++)
                    if(sc[i_169] == 13)
                        bool_167 = true;

                if(!bool_167 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_155] = 13;
            }
            if(i == 16)
            {
                boolean bool_170 = false;
                for(int i_171 = 0; i_171 < 7; i_171++)
                    if(sc[i_171] == 13)
                        bool_170 = true;

                if(!bool_170 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_154] = 13;
                bool_170 = false;
                for(int i_172 = 0; i_172 < 7; i_172++)
                    if(sc[i_172] == 12)
                        bool_170 = true;

                if(!bool_170 && (Math.random() > Math.random() || gmode != 0))
                    sc[i_155] = 12;
            }
            if(cd.lastload == 1)
            {
                int i_173 = 0;
                for(int i_174 = 0; i_174 < cd.nlcars - 16; i_174++)
                {
                    if(i_173 == 0)
                    {
                        for(int i_175 = 1; i_175 < i_151; i_175++)
                            bools[i_175] = false;

                    }
                    if(!cd.include[i_174] || sc[0] == i_174 + 16)
                        continue;
                    int i_176;
                    for(i_176 = (int)(1.0D + Math.random() * (double)(i_151 - 1)); bools[i_176]; i_176 = (int)(1.0D + Math.random() * (double)(i_151 - 1)));
                    bools[i_176] = true;
                    sc[i_176] = i_174 + 16;
                    if(++i_173 == i_151 - 1)
                        i_173 = 0;
                }

            }
            if(cd.lastload == 2)
            {
                int i_177 = 0;
                for(int i_178 = 0; i_178 < cd.nlocars - 16; i_178++)
                {
                    if(i_177 == 0)
                    {
                        for(int i_179 = 1; i_179 < i_151; i_179++)
                            bools[i_179] = false;

                    }
                    if(!cd.include[i_178] || sc[0] == i_178 + 16)
                        continue;
                    int i_180;
                    for(i_180 = (int)(1.0D + Math.random() * (double)(i_151 - 1)); bools[i_180]; i_180 = (int)(1.0D + Math.random() * (double)(i_151 - 1)));
                    bools[i_180] = true;
                    sc[i_180] = i_178 + 16;
                    if(++i_177 == i_151 - 1)
                        i_177 = 0;
                }

            }
        }
    }

    public void ctachm(int i, int i_181, int i_182, Control control)
    {
        if(fase == 1)
        {
            if(i_182 == 1)
            {
                if(over(next[0], i, i_181, 625, 135))
                    pnext = 1;
                if(over(back[0], i, i_181, 115, 135))
                    pback = 1;
                if(over(contin[0], i, i_181, 355, 360))
                    pcontin = 1;
            }
            if(i_182 == 2)
            {
                if(pnext == 1)
                    control.right = true;
                if(pback == 1)
                    control.left = true;
                if(pcontin == 1)
                    control.enter = true;
            }
        }
        if(fase == 3)
        {
            if(i_182 == 1 && over(contin[0], i, i_181, 355, 350))
                pcontin = 1;
            if(i_182 == 2 && pcontin == 1)
            {
                control.enter = true;
                pcontin = 0;
            }
        }
        if(fase == 4)
        {
            if(i_182 == 1 && over(back[0], i, i_181, 370, 345))
                pback = 1;
            if(i_182 == 2 && pback == 1)
            {
                control.enter = true;
                pback = 0;
            }
        }
        if(fase == 6)
        {
            if(i_182 == 1 && (over(star[0], i, i_181, 359, 385) || over(star[0], i, i_181, 359, 295)))
                pstar = 2;
            if(i_182 == 2 && pstar == 2)
            {
                control.enter = true;
                pstar = 1;
            }
        }
        if(fase == 7)
        {
            if(i_182 == 1)
            {
                if(over(next[0], i, i_181, 645, 275))
                    pnext = 1;
                if(over(back[0], i, i_181, 95, 275))
                    pback = 1;
                if(over(contin[0], i, i_181, 355, 385) && !app.openm)
                    pcontin = 1;
            }
            if(i_182 == 2)
            {
                if(pnext == 1)
                    control.right = true;
                if(pback == 1)
                    control.left = true;
                if(pcontin == 1)
                {
                    control.enter = true;
                    pcontin = 0;
                }
            }
        }
        if(fase == -5)
        {
            lxm = i;
            lym = i_181;
            if(i_182 == 1 && over(contin[0], i, i_181, 355, 380))
                pcontin = 1;
            if(i_182 == 2 && pcontin == 1)
            {
                control.enter = true;
                pcontin = 0;
            }
        }
        if(fase == -7)
        {
            if(i_182 == 1)
            {
                if(overon(329, 45, 137, 22, i, i_181))
                {
                    opselect = 0;
                    shaded = true;
                }
                if(overon(320, 73, 155, 22, i, i_181))
                {
                    opselect = 1;
                    shaded = true;
                }
                if(overon(303, 99, 190, 22, i, i_181))
                {
                    opselect = 2;
                    shaded = true;
                }
                if(overon(341, 125, 109, 22, i, i_181))
                {
                    opselect = 3;
                    shaded = true;
                }
            }
            if(i_182 == 2 && shaded)
            {
                control.enter = true;
                shaded = false;
            }
            if(i_182 == 0 && (i != lxm || i_181 != lym))
            {
                if(overon(329, 45, 137, 22, i, i_181))
                    opselect = 0;
                if(overon(320, 73, 155, 22, i, i_181))
                    opselect = 1;
                if(overon(303, 99, 190, 22, i, i_181))
                    opselect = 2;
                if(overon(341, 125, 109, 22, i, i_181))
                    opselect = 3;
                lxm = i;
                lym = i_181;
            }
        }
        if(fase == 10)
        {
            if(i_182 == 1)
            {
                if(overon(343, 261, 110, 22, i, i_181))
                {
                    opselect = 0;
                    shaded = true;
                }
                if(overon(288, 291, 221, 22, i, i_181))
                {
                    opselect = 1;
                    shaded = true;
                }
                if(overon(301, 321, 196, 22, i, i_181))
                {
                    opselect = 2;
                    shaded = true;
                }
                if(overon(357, 351, 85, 22, i, i_181))
                {
                    opselect = 3;
                    shaded = true;
                }
            }
            if(i_182 == 2 && shaded)
            {
                control.enter = true;
                shaded = false;
            }
            if(i_182 == 0 && (i != lxm || i_181 != lym))
            {
                if(overon(343, 261, 110, 22, i, i_181))
                    opselect = 0;
                if(overon(288, 291, 221, 22, i, i_181))
                    opselect = 1;
                if(overon(301, 321, 196, 22, i, i_181))
                    opselect = 2;
                if(overon(357, 351, 85, 22, i, i_181))
                    opselect = 3;
                lxm = i;
                lym = i_181;
            }
        }
        if(fase == 102)
        {
            if(i_182 == 1)
            {
                if(overon(358, 262 + dropf, 82, 22, i, i_181))
                {
                    opselect = 0;
                    shaded = true;
                }
                if(overon(358, 290 + dropf, 82, 22, i, i_181))
                {
                    opselect = 1;
                    shaded = true;
                }
                if(overon(333, 318 + dropf, 132, 22, i, i_181))
                {
                    opselect = 2;
                    shaded = true;
                }
                if(dropf == 0 && overon(348, 346, 102, 22, i, i_181))
                {
                    opselect = 3;
                    shaded = true;
                }
            }
            if(i_182 == 2 && shaded)
            {
                control.enter = true;
                shaded = false;
            }
            if(i_182 == 0 && (i != lxm || i_181 != lym))
            {
                if(overon(358, 262 + dropf, 82, 22, i, i_181))
                    opselect = 0;
                if(overon(358, 290 + dropf, 82, 22, i, i_181))
                    opselect = 1;
                if(overon(333, 318 + dropf, 132, 22, i, i_181))
                    opselect = 2;
                if(dropf == 0 && overon(348, 346, 102, 22, i, i_181))
                    opselect = 3;
                lxm = i;
                lym = i_181;
            }
        }
        if(fase == 11)
        {
            if(flipo >= 1 && flipo <= 16)
            {
                if(i_182 == 1 && over(next[0], i, i_181, 665, 395))
                    pnext = 1;
                if(i_182 == 2 && pnext == 1)
                {
                    control.right = true;
                    pnext = 0;
                }
            }
            if(flipo >= 3 && flipo <= 17)
            {
                if(i_182 == 1 && over(back[0], i, i_181, 75, 395))
                    pback = 1;
                if(i_182 == 2 && pback == 1)
                {
                    control.left = true;
                    pback = 0;
                }
            }
            if(flipo == 17)
            {
                if(i_182 == 1 && over(contin[0], i, i_181, 565, 395))
                    pcontin = 1;
                if(i_182 == 2 && pcontin == 1)
                {
                    control.enter = true;
                    pcontin = 0;
                }
            }
        }
        if(fase == 8)
        {
            if(i_182 == 1 && over(next[0], i, i_181, 665, 395))
                pnext = 1;
            if(i_182 == 2 && pnext == 1)
            {
                control.enter = true;
                pnext = 0;
            }
        }
    }

    protected Color colorSnap(int r, int g, int b)
    {
        return colorSnap(r, g, b, 255);
    }

    protected Color colorSnap(int r, int g, int b, int a)
    {
        int nr = r;
        int ng = g;
        int nb = b;
        nr = (int)((float)nr + (float)nr * ((float)m.snap[0] / 100F));
        if(nr > 255)
            nr = 255;
        if(nr < 0)
            nr = 0;
        ng = (int)((float)ng + (float)ng * ((float)m.snap[1] / 100F));
        if(ng > 255)
            ng = 255;
        if(ng < 0)
            ng = 0;
        nb = (int)((float)nb + (float)nb * ((float)m.snap[2] / 100F));
        if(nb > 255)
            nb = 255;
        if(nb < 0)
            nb = 0;
        if(a > 255)
            a = 255;
        if(a < 0)
            a = 0;
        Color c = new Color(nr, ng, nb, a);
        rd.setColor(c);
        return c;
    }

    public void stat(Mad mad, ContO conto, CheckPoints checkpoints, Control control, boolean bool, int xm, int ym)
    {
        bool &= Madness.gui;
        if(!Madness.gui)
            rd.setClip(new Rectangle(1, 1));
        int i_247 = conto.x - lcarx;
        lcarx = conto.x;
        int i_248 = conto.y - lcary;
        lcary = conto.y;
        int i_249 = conto.z - lcarz;
        lcarz = conto.z;
        modlMove = (float)Math.sqrt(i_247 * i_247 + i_249 * i_249);
        float sp = (modlMove * 1.32F * 21F * 60F * 60F) / 100000F;
        blowEffect = holdit ? 0.0F : (Math.round(sp) - cd.swits[sc[mad.im]][2]) + 50;
        if(blowEffect < 0.0F)
            blowEffect = 0.0F;
        if(blowEffect > 450F)
            blowEffect = 450F;
        blowEffect = (blowEffect / 450F) * 0.4F;
        if(holdit)
        {
            int i = 250;
            if(fase == 7001)
                if(exitm != 4)
                {
                    exitm = 0;
                    i = 600;
                } else
                {
                    i = 1200;
                }
            if(exitm != 4 || !lan || im != 0)
            {
                holdcnt++;
                if((control.enter || holdcnt > i) && (control.chatup == 0 || fase != 7001))
                {
                    fase = -2;
                    control.enter = false;
                }
            } else
            if(control.enter)
                control.enter = false;
        } else
        {
            if(holdcnt != 0)
                holdcnt = 0;
            if(control.enter || control.exit)
            {
                if(fase == 0)
                {
                    if(loadedt)
                        strack.stop();
                    fase = -6;
                } else
                if(starcnt == 0 && control.chatup == 0 && (multion < 2 || !lan))
                    if(exitm == 0)
                        exitm = 1;
                    else
                        exitm = 0;
                if(control.chatup == 0 || fase != 7001)
                    control.enter = false;
                control.exit = false;
            }
        }
        if(exitm == 2)
        {
            fase = -2;
            winner = false;
        }
        if(fase == -2)
            break MISSING_BLOCK_LABEL_7459;
        holdit = false;
        if(checkpoints.haltall)
            checkpoints.haltall = false;
        boolean bool_183 = false;
        String string = "";
        String string_184 = "";
        if(clangame != 0 && (!mad.dest || multion >= 2))
        {
            bool_183 = true;
            for(int i = 0; i < nplayers; i++)
            {
                if(checkpoints.dested[i] != 0)
                    continue;
                if(string.equals(""))
                {
                    string = pclan[i];
                    continue;
                }
                if(string.toLowerCase().equals(pclan[i].toLowerCase()))
                    continue;
                bool_183 = false;
                break;
            }

        }
        if(clangame > 1)
        {
            boolean bool_185 = false;
            String string_186 = "";
            if(bool_183)
            {
                int i = 0;
                do
                {
                    if(i >= nplayers)
                        break;
                    if(!string.toLowerCase().equals(pclan[i].toLowerCase()))
                    {
                        string_184 = pclan[i];
                        break;
                    }
                    i++;
                } while(true);
                if(clangame == 2)
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("Clan ").append(string_184).append(" wasted, nobody won becuase this is a racing only game!").toString();
                }
                if(clangame == 4 && !string.toLowerCase().equals(gaclan.toLowerCase()))
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("Clan ").append(string_184).append(" wasted, nobody won becuase ").append(string).append(" should have raced in this racing vs wasting game!").toString();
                }
                if(clangame == 5 && string.toLowerCase().equals(gaclan.toLowerCase()))
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("Clan ").append(string_184).append(" wasted, nobody won becuase ").append(string).append(" should have raced in this racing vs wasting game!").toString();
                }
            }
            for(int i = 0; i < nplayers; i++)
            {
                if(checkpoints.clear[i] != checkpoints.nlaps * checkpoints.nsp || checkpoints.pos[i] != 0)
                    continue;
                if(clangame == 3)
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("").append(plnames[i]).append(" of clan ").append(pclan[i]).append(" finished first, nobody won becuase this is a wasting only game!").toString();
                }
                if(clangame == 4 && pclan[i].toLowerCase().equals(gaclan.toLowerCase()))
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("").append(plnames[i]).append(" of clan ").append(pclan[i]).append(" finished first, nobody won becuase ").append(pclan[i]).append(" should have wasted in this racing vs wasting game!").toString();
                }
                if(clangame == 5 && !pclan[i].toLowerCase().equals(gaclan.toLowerCase()))
                {
                    bool_185 = true;
                    string_186 = (new StringBuilder()).append("").append(plnames[i]).append(" of clan ").append(pclan[i]).append(" finished first, nobody won becuase ").append(pclan[i]).append(" should have wasted in this racing vs wasting game!").toString();
                }
            }

            if(bool_185)
            {
                drawhi(gamefinished, 70);
                if(aflk)
                {
                    drawcs(120, string_186, 0, 0, 0, 0);
                    aflk = false;
                } else
                {
                    drawcs(120, string_186, 0, 128, 255, 0);
                    aflk = true;
                }
                drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                checkpoints.haltall = true;
                holdit = true;
                winner = false;
            }
        }
        if(multion < 2)
        {
            if(!holdit && (checkpoints.wasted == nplayers - 1 && nplayers != 1 || bool_183))
            {
                drawhi(youwastedem, 70);
                if(!bool_183)
                {
                    if(aflk)
                    {
                        drawcs(120, "You Won, all cars have been wasted!", 0, 0, 0, 0);
                        aflk = false;
                    } else
                    {
                        drawcs(120, "You Won, all cars have been wasted!", 0, 128, 255, 0);
                        aflk = true;
                    }
                } else
                if(aflk)
                {
                    drawcs(120, (new StringBuilder()).append("Your clan ").append(string).append(" has wasted all the cars!").toString(), 0, 0, 0, 0);
                    aflk = false;
                } else
                {
                    drawcs(120, (new StringBuilder()).append("Your clan ").append(string).append(" has wasted all the cars!").toString(), 0, 128, 255, 0);
                    aflk = true;
                }
                drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                checkpoints.haltall = true;
                holdit = true;
                winner = true;
                if(nplayers == 1 && chrono.running)
                    chrono.stop();
            }
            if(!holdit && mad.dest && cntwis == 8)
            {
                if(discon != 240)
                {
                    drawhi(yourwasted, 70);
                } else
                {
                    drawhi(disco, 70);
                    stopchat();
                }
                boolean bool_187 = false;
                if(lan)
                {
                    bool_187 = true;
                    for(int i = 0; i < nplayers; i++)
                        if(i != im && dested[i] == 0 && plnames[i].indexOf("MadBot") == -1)
                            bool_187 = false;

                }
                if(fase == 7001 && nplayers - (checkpoints.wasted + 1) >= 2 && discon != 240 && !bool_187)
                {
                    exitm = 4;
                } else
                {
                    if(exitm == 4)
                        exitm = 0;
                    drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                }
                holdit = true;
                winner = false;
                if(nplayers == 1 && chrono.running)
                    chrono.stop();
            }
            if(!holdit)
            {
                for(int i = 0; i < nplayers; i++)
                    if(checkpoints.clear[i] == checkpoints.nlaps * checkpoints.nsp && checkpoints.pos[i] == 0)
                    {
                        if(nplayers == 1 && chrono.running)
                        {
                            chrono.stop();
                            if(checkpoints.stage > 0 && testdrive == 0 && sc[im] < 16)
                                rs.postResults(checkpoints.stage, nickname, chrono.totalTimeMillis(), chrono.bestLapTimeMillis(), sumid[checkpoints.stage - 1]);
                        }
                        if(clangame == 0)
                        {
                            if(i == im)
                            {
                                drawhi(youwon, 70);
                                if(aflk)
                                {
                                    drawcs(120, "You finished first, nice job!", 0, 0, 0, 0);
                                    aflk = false;
                                } else
                                {
                                    drawcs(120, "You finished first, nice job!", 0, 128, 255, 0);
                                    aflk = true;
                                }
                                winner = true;
                            } else
                            {
                                drawhi(youlost, 70);
                                if(fase != 7001)
                                {
                                    if(aflk)
                                    {
                                        drawcs(120, (new StringBuilder()).append("").append(cd.names[sc[i]]).append(" finished first, race over!").toString(), 0, 0, 0, 0);
                                        aflk = false;
                                    } else
                                    {
                                        drawcs(120, (new StringBuilder()).append("").append(cd.names[sc[i]]).append(" finished first, race over!").toString(), 0, 128, 255, 0);
                                        aflk = true;
                                    }
                                } else
                                if(aflk)
                                {
                                    drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" finished first, race over!").toString(), 0, 0, 0, 0);
                                    aflk = false;
                                } else
                                {
                                    drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" finished first, race over!").toString(), 0, 128, 255, 0);
                                    aflk = true;
                                }
                                winner = false;
                            }
                        } else
                        if(pclan[i].toLowerCase().equals(pclan[im].toLowerCase()))
                        {
                            drawhi(youwon, 70);
                            if(aflk)
                            {
                                drawcs(120, (new StringBuilder()).append("Your clan ").append(pclan[im]).append(" finished first, nice job!").toString(), 0, 0, 0, 0);
                                aflk = false;
                            } else
                            {
                                drawcs(120, (new StringBuilder()).append("Your clan ").append(pclan[im]).append(" finished first, nice job!").toString(), 0, 128, 255, 0);
                                aflk = true;
                            }
                            winner = true;
                        } else
                        {
                            drawhi(youlost, 70);
                            if(aflk)
                            {
                                drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" of clan ").append(pclan[i]).append(" finished first, race over!").toString(), 0, 0, 0, 0);
                                aflk = false;
                            } else
                            {
                                drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" of clan ").append(pclan[i]).append(" finished first, race over!").toString(), 0, 128, 255, 0);
                                aflk = true;
                            }
                            winner = false;
                        }
                        drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                        checkpoints.haltall = true;
                        holdit = true;
                    }

            }
        } else
        {
            if(!holdit && (checkpoints.wasted >= nplayers - 1 || bool_183))
            {
                String string_188 = "Someone";
                if(!bool_183)
                {
                    for(int i = 0; i < nplayers; i++)
                        if(checkpoints.dested[i] == 0)
                            string_188 = plnames[i];

                } else
                {
                    string_188 = (new StringBuilder()).append("Clan ").append(string).append("").toString();
                }
                drawhi(gamefinished, 70);
                if(aflk)
                {
                    drawcs(120, (new StringBuilder()).append("").append(string_188).append(" has wasted all the cars!").toString(), 0, 0, 0, 0);
                    aflk = false;
                } else
                {
                    drawcs(120, (new StringBuilder()).append("").append(string_188).append(" has wasted all the cars!").toString(), 0, 128, 255, 0);
                    aflk = true;
                }
                drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                checkpoints.haltall = true;
                holdit = true;
                winner = false;
            }
            if(!holdit)
            {
                for(int i = 0; i < nplayers; i++)
                {
                    if(checkpoints.clear[i] != checkpoints.nlaps * checkpoints.nsp || checkpoints.pos[i] != 0)
                        continue;
                    drawhi(gamefinished, 70);
                    if(clangame == 0)
                    {
                        if(aflk)
                        {
                            drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" finished first, race over!").toString(), 0, 0, 0, 0);
                            aflk = false;
                        } else
                        {
                            drawcs(120, (new StringBuilder()).append("").append(plnames[i]).append(" finished first, race over!").toString(), 0, 128, 255, 0);
                            aflk = true;
                        }
                    } else
                    if(aflk)
                    {
                        drawcs(120, (new StringBuilder()).append("Clan ").append(pclan[i]).append(" finished first, race over!").toString(), 0, 0, 0, 0);
                        aflk = false;
                    } else
                    {
                        drawcs(120, (new StringBuilder()).append("Clan ").append(pclan[i]).append(" finished first, race over!").toString(), 0, 128, 255, 0);
                        aflk = true;
                    }
                    drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                    checkpoints.haltall = true;
                    holdit = true;
                    winner = false;
                }

            }
            if(!holdit && discon == 240)
            {
                drawhi(gamefinished, 70);
                if(aflk)
                {
                    drawcs(120, "Game got disconnected!", 0, 0, 0, 0);
                    aflk = false;
                } else
                {
                    drawcs(120, "Game got disconnected!", 0, 128, 255, 0);
                    aflk = true;
                }
                drawcs(350, "Press  [ Enter ]  to continue", 0, 0, 0, 0);
                checkpoints.haltall = true;
                holdit = true;
                winner = false;
            }
            if(!holdit)
            {
                rd.drawImage(wgame, 311, 20, null);
                if(!clanchat)
                {
                    drawcs(397, "Click any player on the right to follow!", 0, 0, 0, 0);
                    if(!lan)
                        drawcs(412, "Press [V] to change view.  Press [Enter] to exit.", 0, 0, 0, 0);
                    else
                        drawcs(412, "Press [V] to change view.", 0, 0, 0, 0);
                }
            }
        }
        if(!bool)
            break MISSING_BLOCK_LABEL_4272;
        if(checkpoints.stage == 10 || multion >= 2 || nplayers == 1 || arrace == control.arrace)
            break MISSING_BLOCK_LABEL_3566;
        arrace = control.arrace;
        if(!arrace)
            break MISSING_BLOCK_LABEL_3490;
        wasay = true;
        say = " Arrow now pointing at >  CARS";
        if(multion != 1) goto _L2; else goto _L1
_L1:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        say;
        append();
        "    Press [Q] to toggle Radar!";
        append();
        toString();
        say;
_L2:
        tcnt = -5;
        if(arrace)
            break MISSING_BLOCK_LABEL_3566;
        wasay = false;
        say = " Arrow now pointing at >  TRACK";
        if(multion != 1) goto _L4; else goto _L3
_L3:
        new StringBuilder();
        this;
        JVM INSTR dup_x1 ;
        say;
        append();
        "    Press [Q] to toggle Radar!";
        append();
        toString();
        say;
_L4:
        tcnt = -5;
        cntan = 20;
        alocked = -1;
        alocked = -1;
        if(!holdit && fase != -6 && starcnt == 0 && multion < 2 && checkpoints.stage != 10)
        {
            GadgetPainter.arrow(this, rd, mad.point, mad.missedcp, checkpoints, arrace);
            if(!arrace)
            {
                if(auscnt == 45 && mad.capcnt == 0 && exitm == 0)
                    if(mad.missedcp > 0)
                    {
                        if(mad.missedcp > 15 && mad.missedcp < 50)
                            if(flk)
                                drawcs(70, "Checkpoint Missed!", 255, 0, 0, 0);
                            else
                                drawcs(70, "Checkpoint Missed!", 255, 150, 0, 2);
                        mad.missedcp++;
                        if(mad.missedcp == 70)
                            mad.missedcp = -2;
                    } else
                    if(mad.mtouch && cntovn < 70)
                    {
                        if(Math.abs(ana) > 100)
                            cntan++;
                        else
                        if(cntan != 0)
                            cntan--;
                        if(cntan > 40)
                        {
                            cntovn++;
                            cntan = 40;
                            if(flk)
                            {
                                drawcs(70, "Wrong Way!", 255, 150, 0, 0);
                                flk = false;
                            } else
                            {
                                drawcs(70, "Wrong Way!", 255, 0, 0, 2);
                                flk = true;
                            }
                        }
                    }
            } else
            if(alocked != lalocked)
            {
                if(alocked != -1)
                {
                    wasay = true;
                    say = (new StringBuilder()).append(" Arrow Locked on >  ").append(plnames[alocked]).append("").toString();
                    tcnt = -5;
                } else
                {
                    wasay = true;
                    say = "Arrow Unlocked!";
                    tcnt = 10;
                }
                lalocked = alocked;
            }
        }
        RenderingHints renderingHints = rd.getRenderingHints();
        GadgetPainter.position(rd, m, checkpoints, mad, this);
        GadgetPainter.status(rd, m, cd, mad, this);
        if(!holdit && Madness.speedon > 0)
            GadgetPainter.speedometer(rd, m, cd, mad, this);
        if(!holdit && RadicalMod.nonempty && !mutem && Madness.modon > 0)
            GadgetPainter.modTrackVisor(rd, m, this, xm, ym);
        if(nplayers == 1 && Madness.chronon > 0)
            chrono.paint(602, 65, !m.darksky && !m.lightson || Madness.chronon != 1 ? Madness.chronon : 2);
        rd.setRenderingHints(renderingHints);
        if(control.radar && checkpoints.stage != 10)
        {
            int ty[] = {
                0, 40, 10, 40, 10
            };
            boolean boolk = Madness.poson > 0;
            if(boolk)
                rd.translate(0, ty[Madness.poson]);
            radarstat(mad, conto, checkpoints);
            if(boolk)
                rd.translate(0, -ty[Madness.poson]);
        }
        if(!holdit)
        {
            if(starcnt != 0 && starcnt <= 35)
            {
                if(starcnt == 35 && !mutes)
                    three.play();
                if(starcnt == 24)
                {
                    gocnt = 2;
                    if(!mutes)
                        two.play();
                }
                if(starcnt == 13)
                {
                    gocnt = 1;
                    if(!mutes)
                        one.play();
                }
                if(starcnt == 2)
                {
                    gocnt = 0;
                    if(!mutes)
                        go.play();
                }
                duds = 0;
                if(starcnt <= 37 && starcnt > 32)
                    duds = 1;
                if(starcnt <= 26 && starcnt > 21)
                    duds = 1;
                if(starcnt <= 15 && starcnt > 10)
                    duds = 1;
                if(starcnt <= 4)
                    duds = 2;
                if(dudo != -1)
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.3F));
                    rd.drawImage(dude[duds], dudo, 0, null);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                }
                if(gocnt != 0)
                    rd.drawImage(cntdn[gocnt], 385, 50, null);
                else
                    rd.drawImage(cntdn[gocnt], 363, 50, null);
            }
            if(looped != 0 && mad.loop == 2)
                looped = 0;
            if(mad.power < 45F)
            {
                if(tcnt == 30 && auscnt == 45 && mad.mtouch && mad.capcnt == 0 && exitm == 0)
                {
                    if(looped != 2)
                    {
                        if(pwcnt < 70 || pwcnt < 100 && looped != 0)
                            if(pwflk)
                            {
                                drawcs(110, "Power low, perform stunt!", 0, 0, 200, 0);
                                pwflk = false;
                            } else
                            {
                                drawcs(110, "Power low, perform stunt!", 255, 100, 0, 0);
                                pwflk = true;
                            }
                    } else
                    if(pwcnt < 100)
                    {
                        String string_191 = "";
                        if(multion == 0)
                            string_191 = "  (Press Enter)";
                        if(pwflk)
                        {
                            drawcs(110, (new StringBuilder()).append("Please read the Game Instructions!").append(string_191).append("").toString(), 0, 0, 200, 0);
                            pwflk = false;
                        } else
                        {
                            drawcs(110, (new StringBuilder()).append("Please read the Game Instructions!").append(string_191).append("").toString(), 255, 100, 0, 0);
                            pwflk = true;
                        }
                    }
                    pwcnt++;
                    if(pwcnt == 300)
                    {
                        pwcnt = 0;
                        if(looped != 0)
                        {
                            looped++;
                            if(looped == 4)
                                looped = 2;
                        }
                    }
                }
            } else
            if(pwcnt != 0)
                pwcnt = 0;
            if(mad.capcnt == 0)
            {
                if(tcnt < 30)
                {
                    if(exitm == 0)
                        if(tflk)
                        {
                            if(!wasay)
                                drawcs(105, say, 0, 0, 0, 0);
                            else
                                drawcs(105, say, 0, 0, 0, 0);
                            tflk = false;
                        } else
                        {
                            if(!wasay)
                                drawcs(105, say, 0, 128, 255, 0);
                            else
                                drawcs(105, say, 255, 128, 0, 0);
                            tflk = true;
                        }
                    tcnt++;
                } else
                if(wasay)
                    wasay = false;
                if(auscnt < 45)
                {
                    if(exitm == 0)
                        if(aflk)
                        {
                            drawcs(85, asay, 98, 176, 255, 0);
                            aflk = false;
                        } else
                        {
                            drawcs(85, asay, 0, 128, 255, 0);
                            aflk = true;
                        }
                    auscnt++;
                }
            } else
            if(exitm == 0)
                if(tflk)
                {
                    drawcs(110, "Bad Landing!", 0, 0, 200, 0);
                    tflk = false;
                } else
                {
                    drawcs(110, "Bad Landing!", 255, 100, 0, 0);
                    tflk = true;
                }
            if(mad.trcnt == 10)
            {
                loop = "";
                spin = "";
                asay = "";
                int i;
                for(i = 0; mad.travzy > 225; i++)
                    mad.travzy -= 360;

                while(mad.travzy < -225) 
                {
                    mad.travzy += 360;
                    i--;
                }
                if(i == 1)
                    loop = "Forward loop";
                if(i == 2)
                    loop = "double Forward";
                if(i == 3)
                    loop = "triple Forward";
                if(i >= 4)
                    loop = "massive Forward looping";
                if(i == -1)
                    loop = "Backloop";
                if(i == -2)
                    loop = "double Back";
                if(i == -3)
                    loop = "triple Back";
                if(i <= -4)
                    loop = "massive Back looping";
                if(i == 0)
                    if(mad.ftab && mad.btab)
                        loop = "Tabletop and reversed Tabletop";
                    else
                    if(mad.ftab || mad.btab)
                        loop = "Tabletop";
                if(i > 0 && mad.btab)
                    loop = (new StringBuilder()).append("Hanged ").append(loop).toString();
                if(i < 0 && mad.ftab)
                    loop = (new StringBuilder()).append("Hanged ").append(loop).toString();
                if(loop != "")
                {
                    StringBuilder stringbuilder = new StringBuilder();
                    xtGraphics var_xtGraphics_192 = this;
                    var_xtGraphics_192.asay = stringbuilder.append(var_xtGraphics_192.asay).append(" ").append(loop).toString();
                }
                i = 0;
                for(mad.travxy = Math.abs(mad.travxy); mad.travxy > 270;)
                {
                    mad.travxy -= 360;
                    i++;
                }

                if(i == 0 && mad.rtab)
                    if(loop == "")
                        spin = "Tabletop";
                    else
                        spin = "Flipside";
                if(i == 1)
                    spin = "Rollspin";
                if(i == 2)
                    spin = "double Rollspin";
                if(i == 3)
                    spin = "triple Rollspin";
                if(i >= 4)
                    spin = "massive Roll spinning";
                i = 0;
                boolean bool_193 = false;
                mad.travxz = Math.abs(mad.travxz);
                do
                {
                    if(mad.travxz <= 90)
                        break;
                    mad.travxz -= 180;
                    if((i += 180) > 900)
                    {
                        i = 900;
                        bool_193 = true;
                    }
                } while(true);
                if(i != 0)
                {
                    if(loop == "" && spin == "")
                    {
                        StringBuilder stringbuilder = new StringBuilder();
                        xtGraphics var_xtGraphics_194 = this;
                        var_xtGraphics_194.asay = stringbuilder.append(var_xtGraphics_194.asay).append(" ").append(i).toString();
                        if(bool_193)
                        {
                            StringBuilder stringbuilder_195 = new StringBuilder();
                            xtGraphics var_xtGraphics_196 = this;
                            var_xtGraphics_196.asay = stringbuilder_195.append(var_xtGraphics_196.asay).append(" and beyond").toString();
                        }
                    } else
                    {
                        StringBuilder stringbuilder;
                        if(spin != "")
                            if(loop == "")
                            {
                                stringbuilder = new StringBuilder();
                                xtGraphics var_xtGraphics_197 = this;
                                var_xtGraphics_197.asay = stringbuilder.append(var_xtGraphics_197.asay).append(" ").append(spin).toString();
                            } else
                            {
                                stringbuilder = new StringBuilder();
                                xtGraphics var_xtGraphics_198 = this;
                                var_xtGraphics_198.asay = stringbuilder.append(var_xtGraphics_198.asay).append(" with ").append(spin).toString();
                            }
                        stringbuilder = new StringBuilder();
                        xtGraphics var_xtGraphics_199 = this;
                        var_xtGraphics_199.asay = stringbuilder.append(var_xtGraphics_199.asay).append(" by ").append(i).toString();
                        if(bool_193)
                        {
                            StringBuilder stringbuilder_200 = new StringBuilder();
                            xtGraphics var_xtGraphics_201 = this;
                            var_xtGraphics_201.asay = stringbuilder_200.append(var_xtGraphics_201.asay).append(" and beyond").toString();
                        }
                    }
                } else
                if(spin != "")
                    if(loop == "")
                    {
                        StringBuilder stringbuilder = new StringBuilder();
                        xtGraphics var_xtGraphics_202 = this;
                        var_xtGraphics_202.asay = stringbuilder.append(var_xtGraphics_202.asay).append(" ").append(spin).toString();
                    } else
                    {
                        StringBuilder stringbuilder = new StringBuilder();
                        xtGraphics var_xtGraphics_203 = this;
                        var_xtGraphics_203.asay = stringbuilder.append(var_xtGraphics_203.asay).append(" by ").append(spin).toString();
                    }
                if(asay != "")
                    auscnt -= 15;
                if(loop != "")
                    auscnt -= 25;
                if(spin != "")
                    auscnt -= 25;
                if(i != 0)
                    auscnt -= 25;
                if(auscnt < 45)
                {
                    if(!mutes)
                        powerup.play();
                    if(auscnt < -20)
                        auscnt = -20;
                    int i_204 = 0;
                    if(mad.powerup > 20F)
                        i_204 = 1;
                    if(mad.powerup > 40F)
                        i_204 = 2;
                    if(mad.powerup > 150F)
                        i_204 = 3;
                    if(mad.surfer)
                        asay = (new StringBuilder()).append(" ").append(adj[4][(int)(m.random() * 3F)]).append(asay).toString();
                    if(i_204 != 3)
                        asay = (new StringBuilder()).append(adj[i_204][(int)(m.random() * 3F)]).append(asay).append(exlm[i_204]).toString();
                    else
                        asay = adj[i_204][(int)(m.random() * 3F)];
                    if(!wasay)
                    {
                        tcnt = auscnt;
                        if(mad.power != 98F)
                            say = (new StringBuilder()).append("Power Up ").append((int)((100F * mad.powerup) / 98F)).append("%").toString();
                        else
                            say = "Power To The MAX";
                        if(skidup)
                            skidup = false;
                        else
                            skidup = true;
                    }
                }
            }
            if(mad.newcar)
            {
                if(!wasay)
                {
                    if(mad.fixes == -1)
                        say = "Car Fixed";
                    else
                    if(mad.fixes <= 0)
                        say = "Last fix used! No more fixes available!";
                    else
                    if(mad.fixes == 1)
                        say = "Only 1 more fix available, use it wisely!";
                    else
                        say = (new StringBuilder()).append("Car Fixed, ").append(mad.fixes).append(" more fixes available").toString();
                    tcnt = 0;
                }
                crashup = !crashup;
            }
            for(int i = 0; i < nplayers; i++)
            {
                if(dested[i] == checkpoints.dested[i] || i == im)
                    continue;
                dested[i] = checkpoints.dested[i];
                if(fase != 7001)
                {
                    if(dested[i] == 1)
                    {
                        wasay = true;
                        say = (new StringBuilder()).append("").append(cd.names[sc[i]]).append(" has been wasted!").toString();
                        tcnt = -15;
                    }
                    if(dested[i] == 2)
                    {
                        wasay = true;
                        say = (new StringBuilder()).append("You wasted ").append(cd.names[sc[i]]).append("!").toString();
                        tcnt = -15;
                    }
                    continue;
                }
                if(dested[i] == 1)
                {
                    wasay = true;
                    say = (new StringBuilder()).append("").append(plnames[i]).append(" has been wasted!").toString();
                    tcnt = -15;
                }
                if(dested[i] == 2)
                {
                    wasay = true;
                    if(multion < 2)
                        say = (new StringBuilder()).append("You wasted ").append(plnames[i]).append("!").toString();
                    else
                        say = (new StringBuilder()).append("").append(plnames[im]).append(" wasted ").append(plnames[i]).append("!").toString();
                    tcnt = -15;
                }
                if(dested[i] == 3)
                {
                    wasay = true;
                    say = (new StringBuilder()).append("").append(plnames[i]).append(" has left the game").toString();
                    tcnt = -15;
                }
            }

            if(multion >= 2 && alocked != lalocked)
            {
                if(alocked != -1)
                {
                    wasay = false;
                    say = (new StringBuilder()).append("Now following ").append(plnames[alocked]).append("!").toString();
                    tcnt = -15;
                }
                lalocked = alocked;
                clear = mad.clear;
            }
            if(clear != mad.clear && mad.clear != 0)
            {
                if(!wasay)
                {
                    if(mad.clear % checkpoints.nsp == 0)
                    {
                        if(mad.clear == (checkpoints.nlaps - 1) * checkpoints.nsp)
                            say = "Final lap!!!";
                        else
                            say = (new StringBuilder()).append(checkpoints.nlaps - mad.clear / checkpoints.nsp).append(" laps to go!").toString();
                    } else
                    {
                        say = "Checkpoint!";
                    }
                    tcnt = 15;
                }
                clear = mad.clear;
                if(checkpoints.nlaps > 0 && nplayers == 1 && clear % checkpoints.nsp == 0)
                    chrono.performLap();
                if(!mutes)
                    checkpoint.play();
                cntovn = 0;
                if(cntan != 0)
                    cntan = 0;
            }
        }
        if(m.lightn != -1)
        {
            int i = strack.sClip.stream.available();
            m.lton = false;
            if(i <= 0x6159e1 && i > 0x51e8c1)
                m.lton = true;
            if(i <= 0x2da781 && i > 0x142441)
                m.lton = true;
        }
        if(rd.getClip() != null)
            rd.setClip(null);
        return;
    }

    public void drawstat(int i, int i_205, boolean bool, float f)
    {
        int is[] = new int[4];
        int is_206[] = new int[4];
        if(i_205 > i)
            i_205 = i;
        int i_207 = (int)(98F * ((float)i_205 / (float)i));
        is[0] = 662;
        is_206[0] = 11;
        is[1] = 662;
        is_206[1] = 20;
        is[2] = 662 + i_207;
        is_206[2] = 20;
        is[3] = 662 + i_207;
        is_206[3] = 11;
        int i_208 = 244;
        int i_209 = 244;
        int i_210 = 11;
        if(i_207 > 33)
            i_209 = (int)(244F - 233F * ((float)(i_207 - 33) / 65F));
        if(i_207 > 70)
        {
            if(dmcnt < 10)
                if(dmflk)
                {
                    i_209 = 170;
                    dmflk = false;
                } else
                {
                    dmflk = true;
                }
            dmcnt++;
            if((double)dmcnt > 167D - (double)i_207 * 1.5D)
                dmcnt = 0;
        }
        i_208 = (int)((float)i_208 + (float)i_208 * ((float)m.snap[0] / 100F));
        if(i_208 > 255)
            i_208 = 255;
        if(i_208 < 0)
            i_208 = 0;
        i_209 = (int)((float)i_209 + (float)i_209 * ((float)m.snap[1] / 100F));
        if(i_209 > 255)
            i_209 = 255;
        if(i_209 < 0)
            i_209 = 0;
        i_210 = (int)((float)i_210 + (float)i_210 * ((float)m.snap[2] / 100F));
        if(i_210 > 255)
            i_210 = 255;
        if(i_210 < 0)
            i_210 = 0;
        rd.setColor(new Color(i_208, i_209, i_210));
        rd.fillPolygon(is, is_206, 4);
        is[0] = 662;
        is_206[0] = 31;
        is[1] = 662;
        is_206[1] = 40;
        is[2] = (int)(662F + f);
        is_206[2] = 40;
        is[3] = (int)(662F + f);
        is_206[3] = 31;
        i_208 = 128;
        if(f == 98F)
            i_208 = 64;
        i_209 = (int)(190D + (double)f * 0.37D);
        i_210 = 244;
        if(auscnt < 45 && aflk)
        {
            i_208 = 128;
            i_209 = 244;
            i_210 = 244;
        }
        i_208 = (int)((float)i_208 + (float)i_208 * ((float)m.snap[0] / 100F));
        if(i_208 > 255)
            i_208 = 255;
        if(i_208 < 0)
            i_208 = 0;
        i_209 = (int)((float)i_209 + (float)i_209 * ((float)m.snap[1] / 100F));
        if(i_209 > 255)
            i_209 = 255;
        if(i_209 < 0)
            i_209 = 0;
        i_210 = (int)((float)i_210 + (float)i_210 * ((float)m.snap[2] / 100F));
        if(i_210 > 255)
            i_210 = 255;
        if(i_210 < 0)
            i_210 = 0;
        rd.setColor(new Color(i_208, i_209, i_210));
        rd.fillPolygon(is, is_206, 4);
    }

    public void drawhi(Image image, int i)
    {
        if(m.darksky)
        {
            Color color = new Color(m.csky[0], m.csky[1], m.csky[2]);
            float fs[] = new float[3];
            Color.RGBtoHSB(m.csky[0], m.csky[1], m.csky[2], fs);
            fs[2] = 0.6F;
            color = Color.getHSBColor(fs[0], fs[1], fs[2]);
            rd.setColor(color);
            rd.fillRoundRect(390 - image.getWidth(ob) / 2, i - 2, image.getWidth(ob) + 20, image.getHeight(ob) + 2, 7, 20);
            rd.setColor(new Color((int)((double)color.getRed() / 1.1000000000000001D), (int)((double)color.getGreen() / 1.1000000000000001D), (int)((double)color.getBlue() / 1.1000000000000001D)));
            rd.drawRoundRect(390 - image.getWidth(ob) / 2, i - 2, image.getWidth(ob) + 20, image.getHeight(ob) + 2, 7, 20);
        }
        rd.drawImage(image, 400 - image.getWidth(ob) / 2, i, null);
    }

    public void drawcs(int i, String string, int i_211, int i_212, int i_213, int i_214)
    {
        if(i_214 != 3 && i_214 != 4)
        {
            i_211 = (int)((float)i_211 + (float)i_211 * ((float)m.snap[0] / 100F));
            if(i_211 > 255)
                i_211 = 255;
            if(i_211 < 0)
                i_211 = 0;
            i_212 = (int)((float)i_212 + (float)i_212 * ((float)m.snap[1] / 100F));
            if(i_212 > 255)
                i_212 = 255;
            if(i_212 < 0)
                i_212 = 0;
            i_213 = (int)((float)i_213 + (float)i_213 * ((float)m.snap[2] / 100F));
            if(i_213 > 255)
                i_213 = 255;
            if(i_213 < 0)
                i_213 = 0;
        }
        if(i_214 == 4)
        {
            i_211 = (int)((float)i_211 - (float)i_211 * ((float)m.snap[0] / 100F));
            if(i_211 > 255)
                i_211 = 255;
            if(i_211 < 0)
                i_211 = 0;
            i_212 = (int)((float)i_212 - (float)i_212 * ((float)m.snap[1] / 100F));
            if(i_212 > 255)
                i_212 = 255;
            if(i_212 < 0)
                i_212 = 0;
            i_213 = (int)((float)i_213 - (float)i_213 * ((float)m.snap[2] / 100F));
            if(i_213 > 255)
                i_213 = 255;
            if(i_213 < 0)
                i_213 = 0;
        }
        if(i_214 == 1)
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawString(string, (400 - ftm.stringWidth(string) / 2) + 1, i + 1);
        }
        if(i_214 == 2)
        {
            i_211 = (i_211 * 2 + m.csky[0] * 1) / 3;
            if(i_211 > 255)
                i_211 = 255;
            if(i_211 < 0)
                i_211 = 0;
            i_212 = (i_212 * 2 + m.csky[1] * 1) / 3;
            if(i_212 > 255)
                i_212 = 255;
            if(i_212 < 0)
                i_212 = 0;
            i_213 = (i_213 * 2 + m.csky[2] * 1) / 3;
            if(i_213 > 255)
                i_213 = 255;
            if(i_213 < 0)
                i_213 = 0;
        }
        rd.setColor(new Color(i_211, i_212, i_213));
        rd.drawString(string, 400 - ftm.stringWidth(string) / 2, i);
    }

    public void arrow(int i, int i_215, CheckPoints checkpoints, boolean bool)
    {
        int is[] = new int[7];
        int is_216[] = new int[7];
        int is_217[] = new int[7];
        int i_218 = 400;
        int i_219 = -90;
        int i_220 = 700;
        for(int i_221 = 0; i_221 < 7; i_221++)
            is_216[i_221] = i_219;

        is[0] = i_218;
        is_217[0] = i_220 + 110;
        is[1] = i_218 - 35;
        is_217[1] = i_220 + 50;
        is[2] = i_218 - 15;
        is_217[2] = i_220 + 50;
        is[3] = i_218 - 15;
        is_217[3] = i_220 - 50;
        is[4] = i_218 + 15;
        is_217[4] = i_220 - 50;
        is[5] = i_218 + 15;
        is_217[5] = i_220 + 50;
        is[6] = i_218 + 35;
        is_217[6] = i_220 + 50;
        boolean bool_222 = false;
        int i_223;
        if(!bool)
        {
            int i_224 = 0;
            if(checkpoints.x[i] - checkpoints.opx[im] >= 0)
                i_224 = 180;
            i_223 = (int)((double)(90 + i_224) + Math.atan((double)(checkpoints.z[i] - checkpoints.opz[im]) / (double)(checkpoints.x[i] - checkpoints.opx[im])) / 0.017453292519943295D);
        } else
        {
            int i_225 = 0;
            if(multion == 0 || alocked == -1)
            {
                int i_226 = -1;
                boolean bool_227 = false;
                for(int i_228 = 0; i_228 < nplayers; i_228++)
                    if(i_228 != im && (py(checkpoints.opx[im] / 100, checkpoints.opx[i_228] / 100, checkpoints.opz[im] / 100, checkpoints.opz[i_228] / 100) < i_226 || i_226 == -1) && (!bool_227 || checkpoints.onscreen[i_228] != 0) && checkpoints.dested[i_228] == 0)
                    {
                        i_225 = i_228;
                        i_226 = py(checkpoints.opx[im] / 100, checkpoints.opx[i_228] / 100, checkpoints.opz[im] / 100, checkpoints.opz[i_228] / 100);
                        if(checkpoints.onscreen[i_228] != 0)
                            bool_227 = true;
                    }

            } else
            {
                i_225 = alocked;
            }
            int i_229 = 0;
            if(checkpoints.opx[i_225] - checkpoints.opx[im] >= 0)
                i_229 = 180;
            i_223 = (int)((double)(90 + i_229) + Math.atan((double)(checkpoints.opz[i_225] - checkpoints.opz[im]) / (double)(checkpoints.opx[i_225] - checkpoints.opx[im])) / 0.017453292519943295D);
            if(multion == 0)
            {
                drawcs(13, "[                                ]", 76, 67, 240, 0);
                drawcs(13, cd.names[sc[i_225]], 0, 0, 0, 0);
            } else
            {
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                drawcs(17, "[                                ]", 76, 67, 240, 0);
                drawcs(12, plnames[i_225], 0, 0, 0, 0);
                rd.setFont(new Font("Arial", 0, 10));
                ftm = rd.getFontMetrics();
                drawcs(24, cd.names[sc[i_225]], 0, 0, 0, 0);
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
            }
        }
        for(i_223 += m.xz; i_223 < 0; i_223 += 360);
        for(; i_223 > 180; i_223 -= 360);
        if(!bool)
        {
            if(i_223 > 130)
                i_223 = 130;
            if(i_223 < -130)
                i_223 = -130;
        } else
        {
            if(i_223 > 100)
                i_223 = 100;
            if(i_223 < -100)
                i_223 = -100;
        }
        if(Math.abs(ana - i_223) < 180)
        {
            if(Math.abs(ana - i_223) < 10)
                ana = i_223;
            else
            if(ana < i_223)
                ana += 10;
            else
                ana -= 10;
        } else
        {
            if(i_223 < 0)
            {
                ana += 15;
                if(ana > 180)
                    ana -= 360;
            }
            if(i_223 > 0)
            {
                ana -= 15;
                if(ana < -180)
                    ana += 360;
            }
        }
        rot(is, is_217, i_218, i_220, ana, 7);
        i_223 = Math.abs(ana);
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if(!bool)
        {
            if(i_223 > 7 || i_215 > 0 || i_215 == -2 || cntan != 0)
            {
                for(int i_230 = 0; i_230 < 7; i_230++)
                {
                    is[i_230] = xs(is[i_230], is_217[i_230]);
                    is_216[i_230] = ys(is_216[i_230], is_217[i_230]);
                }

                int i_231 = (int)(190F + 190F * ((float)m.snap[0] / 100F));
                if(i_231 > 255)
                    i_231 = 255;
                if(i_231 < 0)
                    i_231 = 0;
                int i_232 = (int)(255F + 255F * ((float)m.snap[1] / 100F));
                if(i_232 > 255)
                    i_232 = 255;
                if(i_232 < 0)
                    i_232 = 0;
                int i_233 = 0;
                if(i_215 <= 0)
                {
                    if(i_223 <= 45 && i_215 != -2 && cntan == 0)
                    {
                        i_231 = (i_231 * i_223 + m.csky[0] * (45 - i_223)) / 45;
                        i_232 = (i_232 * i_223 + m.csky[1] * (45 - i_223)) / 45;
                        i_233 = (i_233 * i_223 + m.csky[2] * (45 - i_223)) / 45;
                    }
                    if(i_223 >= 90)
                    {
                        int i_234 = (int)(255F + 255F * ((float)m.snap[0] / 100F));
                        if(i_234 > 255)
                            i_234 = 255;
                        if(i_234 < 0)
                            i_234 = 0;
                        i_231 = (i_231 * (140 - i_223) + i_234 * (i_223 - 90)) / 50;
                        if(i_231 > 255)
                            i_231 = 255;
                    }
                } else
                if(flk)
                {
                    i_231 = (int)(255F + 255F * ((float)m.snap[0] / 100F));
                    if(i_231 > 255)
                        i_231 = 255;
                    if(i_231 < 0)
                        i_231 = 0;
                    flk = false;
                } else
                {
                    i_231 = (int)(255F + 255F * ((float)m.snap[0] / 100F));
                    if(i_231 > 255)
                        i_231 = 255;
                    if(i_231 < 0)
                        i_231 = 0;
                    i_232 = (int)(220F + 220F * ((float)m.snap[1] / 100F));
                    if(i_232 > 255)
                        i_232 = 255;
                    if(i_232 < 0)
                        i_232 = 0;
                    flk = true;
                }
                rd.setColor(new Color(i_231, i_232, i_233));
                rd.fillPolygon(is, is_216, 7);
                i_231 = (int)(115F + 115F * ((float)m.snap[0] / 100F));
                if(i_231 > 255)
                    i_231 = 255;
                if(i_231 < 0)
                    i_231 = 0;
                i_232 = (int)(170F + 170F * ((float)m.snap[1] / 100F));
                if(i_232 > 255)
                    i_232 = 255;
                if(i_232 < 0)
                    i_232 = 0;
                i_233 = 0;
                if(i_215 <= 0)
                {
                    if(i_223 <= 45 && i_215 != -2 && cntan == 0)
                    {
                        i_231 = (i_231 * i_223 + m.csky[0] * (45 - i_223)) / 45;
                        i_232 = (i_232 * i_223 + m.csky[1] * (45 - i_223)) / 45;
                        i_233 = (i_233 * i_223 + m.csky[2] * (45 - i_223)) / 45;
                    }
                } else
                if(flk)
                {
                    i_231 = (int)(255F + 255F * ((float)m.snap[0] / 100F));
                    if(i_231 > 255)
                        i_231 = 255;
                    if(i_231 < 0)
                        i_231 = 0;
                    i_232 = 0;
                }
                rd.setColor(new Color(i_231, i_232, i_233));
                rd.drawPolygon(is, is_216, 7);
            }
        } else
        {
            int i_235 = 0;
            if(multion != 0)
                i_235 = 8;
            for(int i_236 = 0; i_236 < 7; i_236++)
            {
                is[i_236] = xs(is[i_236], is_217[i_236]);
                is_216[i_236] = ys(is_216[i_236], is_217[i_236]) + i_235;
            }

            int i_237 = (int)(159F + 159F * ((float)m.snap[0] / 100F));
            if(i_237 > 255)
                i_237 = 255;
            if(i_237 < 0)
                i_237 = 0;
            int i_238 = (int)(207F + 207F * ((float)m.snap[1] / 100F));
            if(i_238 > 255)
                i_238 = 255;
            if(i_238 < 0)
                i_238 = 0;
            int i_239 = (int)(255F + 255F * ((float)m.snap[2] / 100F));
            if(i_239 > 255)
                i_239 = 255;
            if(i_239 < 0)
                i_239 = 0;
            rd.setColor(new Color(i_237, i_238, i_239));
            rd.fillPolygon(is, is_216, 7);
            i_237 = (int)(120F + 120F * ((float)m.snap[0] / 100F));
            if(i_237 > 255)
                i_237 = 255;
            if(i_237 < 0)
                i_237 = 0;
            i_238 = (int)(114F + 114F * ((float)m.snap[1] / 100F));
            if(i_238 > 255)
                i_238 = 255;
            if(i_238 < 0)
                i_238 = 0;
            i_239 = (int)(255F + 255F * ((float)m.snap[2] / 100F));
            if(i_239 > 255)
                i_239 = 255;
            if(i_239 < 0)
                i_239 = 0;
            rd.setColor(new Color(i_237, i_238, i_239));
            rd.drawPolygon(is, is_216, 7);
        }
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    }

    public void radarstat(Mad mad, ContO conto, CheckPoints checkpoints)
    {
        rd.setComposite(AlphaComposite.getInstance(3, 0.5F));
        rd.setColor(new Color(m.csky[0], m.csky[1], m.csky[2]));
        rd.fillRoundRect(10, 55, 172, 172, 30, 30);
        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        rd.setClip(new java.awt.geom.RoundRectangle2D.Float(10F, 55F, 172F, 172F, 30F, 30F));
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        rd.setColor(new Color(m.csky[0] / 2, m.csky[1] / 2, m.csky[2] / 2));
        int i = 0;
        do
        {
            if(i >= checkpoints.n)
                break;
            int i_240 = i + 1;
            if(i == checkpoints.n - 1)
                i_240 = 0;
            boolean bool = false;
            if(checkpoints.typ[i_240] == -3)
            {
                i_240 = 0;
                bool = true;
            }
            int is[] = {
                (int)(96F - (float)(checkpoints.opx[im] - checkpoints.x[i]) / checkpoints.prox), (int)(96F - (float)(checkpoints.opx[im] - checkpoints.x[i_240]) / checkpoints.prox)
            };
            int is_241[] = {
                (int)(141F - (float)(checkpoints.z[i] - checkpoints.opz[im]) / checkpoints.prox), (int)(141F - (float)(checkpoints.z[i_240] - checkpoints.opz[im]) / checkpoints.prox)
            };
            rot(is, is_241, 96, 141, mad.cxz, 2);
            rd.drawLine(is[0], is_241[0], is[1], is_241[1]);
            if(bool)
                break;
            i++;
        } while(true);
        if(arrace || multion > 1)
        {
            int is[] = new int[nplayers];
            int is_244[] = new int[nplayers];
            int i;
            for(i = 0; i < nplayers; i++)
            {
                is[i] = (int)(96F - (float)(checkpoints.opx[im] - checkpoints.opx[i]) / checkpoints.prox);
                is_244[i] = (int)(141F - (float)(checkpoints.opz[i] - checkpoints.opz[im]) / checkpoints.prox);
            }

            rot(is, is_244, 96, 141, mad.cxz, nplayers);
            i = 0;
            int i_245 = (int)(80F + 80F * ((float)m.snap[1] / 100F));
            if(i_245 > 255)
                i_245 = 255;
            if(i_245 < 0)
                i_245 = 0;
            int i_246 = (int)(159F + 159F * ((float)m.snap[2] / 100F));
            if(i_246 > 255)
                i_246 = 255;
            if(i_246 < 0)
                i_246 = 0;
            for(int i_247 = 0; i_247 < nplayers; i_247++)
            {
                if(i_247 == im || checkpoints.dested[i_247] != 0)
                    continue;
                if(clangame != 0)
                {
                    if(pclan[i_247].toLowerCase().equals(gaclan.toLowerCase()))
                    {
                        i = 159;
                        i_245 = 80;
                        i_246 = 0;
                    } else
                    {
                        i = 0;
                        i_245 = 80;
                        i_246 = 159;
                    }
                    i = (int)((float)i + (float)i * ((float)m.snap[0] / 100F));
                    if(i > 255)
                        i = 255;
                    if(i < 0)
                        i = 0;
                    i_245 = (int)((float)i_245 + (float)i_245 * ((float)m.snap[1] / 100F));
                    if(i_245 > 255)
                        i_245 = 255;
                    if(i_245 < 0)
                        i_245 = 0;
                    i_246 = (int)((float)i_246 + (float)i_246 * ((float)m.snap[2] / 100F));
                    if(i_246 > 255)
                        i_246 = 255;
                    if(i_246 < 0)
                        i_246 = 0;
                }
                int i_248 = 2;
                if(alocked == i_247)
                {
                    i_248 = 3;
                    rd.setColor(new Color(i, i_245, i_246));
                } else
                {
                    rd.setColor(new Color((i + m.csky[0]) / 2, (m.csky[1] + i_245) / 2, (i_246 + m.csky[2]) / 2));
                }
                rd.drawLine(is[i_247] - i_248, is_244[i_247], is[i_247] + i_248, is_244[i_247]);
                rd.drawLine(is[i_247], is_244[i_247] + i_248, is[i_247], is_244[i_247] - i_248);
                rd.setColor(new Color(i, i_245, i_246));
                rd.fillRect(is[i_247] - 1, is_244[i_247] - 1, 3, 3);
            }

        }
        rd.setColor(new Color(0, 0, 0, 160));
        rd.fillRect(95, 140, 3, 3);
        is = (int)(159F + 159F * ((float)m.snap[0] / 100F));
        if(is > 255)
            is = 255;
        if(is < 0)
            is = 0;
        int i_249 = 0;
        int i_250 = 0;
        if(clangame != 0)
        {
            if(pclan[im].toLowerCase().equals(gaclan.toLowerCase()))
            {
                is = 159;
                i_249 = 80;
                i_250 = 0;
            } else
            {
                is = 0;
                i_249 = 80;
                i_250 = 159;
            }
            is = (int)((float)is + (float)is * ((float)m.snap[0] / 100F));
            if(is > 255)
                is = 255;
            if(is < 0)
                is = 0;
            i_249 = (int)((float)i_249 + (float)i_249 * ((float)m.snap[1] / 100F));
            if(i_249 > 255)
                i_249 = 255;
            if(i_249 < 0)
                i_249 = 0;
            i_250 = (int)((float)i_250 + (float)i_250 * ((float)m.snap[2] / 100F));
            if(i_250 > 255)
                i_250 = 255;
            if(i_250 < 0)
                i_250 = 0;
        }
        rd.setClip(null);
        if(Madness.speedon == 0)
        {
            rd.setColor(new Color((is + m.csky[0]) / 2, (m.csky[1] + i_249) / 2, (i_250 + m.csky[2]) / 2));
            rd.drawLine(96, 139, 96, 143);
            rd.drawLine(94, 141, 98, 141);
            rd.setColor(new Color(is, i_249, i_250));
            rd.fillRect(95, 140, 3, 3);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            if(m.darksky)
            {
                Color color = new Color(m.csky[0], m.csky[1], m.csky[2]);
                float fs[] = new float[3];
                Color.RGBtoHSB(m.csky[0], m.csky[1], m.csky[2], fs);
                fs[2] = 0.6F;
                color = Color.getHSBColor(fs[0], fs[1], fs[2]);
                rd.setColor(color);
                rd.fillRect(5, 232, 181, 17);
                rd.drawLine(4, 233, 4, 247);
                rd.drawLine(3, 235, 3, 245);
                rd.drawLine(186, 233, 186, 247);
                rd.drawLine(187, 235, 187, 245);
            }
            rd.drawImage(sped, 7, 234, null);
            float f_254 = (modlMove * 1.32F * 21F * 60F * 60F) / 100000F;
            float f_255 = f_254 * 0.621371F;
            rd.setColor(new Color(0, 0, 100));
            rd.drawString((new StringBuilder()).append("").append((int)f_254).toString(), 62, 245);
            rd.drawString((new StringBuilder()).append("").append((int)f_255).toString(), 132, 245);
        } else
        {
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        }
    }

    public void playsounds(Mad mad, Control control, int i)
    {
        if((fase == 0 || fase == 7001) && starcnt < 35 && cntwis != 8 && !mutes)
        {
            boolean bool = control.up && mad.speed > 0.0F || control.down && mad.speed < 10F;
            boolean bool_256 = mad.skid == 1 && control.handb || Math.abs(mad.scz[0] - (mad.scz[1] + mad.scz[0] + mad.scz[2] + mad.scz[3]) / 4F) > 1.0F || Math.abs(mad.scx[0] - (mad.scx[1] + mad.scx[0] + mad.scx[2] + mad.scx[3]) / 4F) > 1.0F;
            boolean bool_257 = false;
            if(control.up && mad.speed < 10F)
            {
                bool_256 = true;
                bool = true;
                bool_257 = true;
            }
            if(bool && mad.mtouch)
            {
                if(!mad.capsized)
                {
                    if(!bool_256)
                    {
                        if(mad.power != 98F)
                        {
                            if(Math.abs(mad.speed) > 0.0F && Math.abs(mad.speed) <= (float)cd.swits[mad.cn][0])
                            {
                                int i_258 = (int)((3F * Math.abs(mad.speed)) / (float)cd.swits[mad.cn][0]);
                                if(i_258 == 2)
                                {
                                    if(pwait == 0)
                                        i_258 = 0;
                                    else
                                        pwait--;
                                } else
                                {
                                    pwait = 7;
                                }
                                sparkeng(i_258, mad.cn);
                            }
                            if(Math.abs(mad.speed) > (float)cd.swits[mad.cn][0] && Math.abs(mad.speed) <= (float)cd.swits[mad.cn][1])
                            {
                                int i_259 = (int)((3F * (Math.abs(mad.speed) - (float)cd.swits[mad.cn][0])) / (float)(cd.swits[mad.cn][1] - cd.swits[mad.cn][0]));
                                if(i_259 == 2)
                                {
                                    if(pwait == 0)
                                        i_259 = 0;
                                    else
                                        pwait--;
                                } else
                                {
                                    pwait = 7;
                                }
                                sparkeng(i_259, mad.cn);
                            }
                            if(Math.abs(mad.speed) > (float)cd.swits[mad.cn][1] && Math.abs(mad.speed) <= (float)cd.swits[mad.cn][2])
                            {
                                int i_260 = (int)((3F * (Math.abs(mad.speed) - (float)cd.swits[mad.cn][1])) / (float)(cd.swits[mad.cn][2] - cd.swits[mad.cn][1]));
                                sparkeng(i_260, mad.cn);
                            }
                        } else
                        {
                            int i_261 = 2;
                            if(pwait == 0)
                            {
                                if(Math.abs(mad.speed) > (float)cd.swits[mad.cn][1])
                                    i_261 = 3;
                            } else
                            {
                                pwait--;
                            }
                            sparkeng(i_261, mad.cn);
                        }
                    } else
                    {
                        sparkeng(-1, mad.cn);
                        if(bool_257)
                        {
                            if(stopcnt <= 0)
                            {
                                air[5].loop();
                                stopcnt = 10;
                            }
                        } else
                        if(stopcnt <= -2)
                        {
                            air[2 + (int)(m.random() * 3F)].loop();
                            stopcnt = 7;
                        }
                    }
                } else
                {
                    sparkeng(3, mad.cn);
                }
                grrd = false;
                aird = false;
            } else
            {
                pwait = 15;
                if(!mad.mtouch && !grrd && (double)m.random() > 0.40000000000000002D)
                {
                    air[(int)(m.random() * 4F)].loop();
                    stopcnt = 5;
                    grrd = true;
                }
                if(!mad.wtouch && !aird)
                {
                    stopairs();
                    air[(int)(m.random() * 4F)].loop();
                    stopcnt = 10;
                    aird = true;
                }
                sparkeng(-1, mad.cn);
            }
            if(mad.cntdest != 0 && cntwis < 7)
            {
                if(!pwastd)
                {
                    wastd.loop();
                    pwastd = true;
                }
            } else
            {
                if(pwastd)
                {
                    wastd.stop();
                    pwastd = false;
                }
                if(cntwis == 7 && !mutes)
                    firewasted.play();
            }
        } else
        {
            sparkeng(-2, mad.cn);
            if(pwastd)
            {
                wastd.stop();
                pwastd = false;
            }
        }
        if(stopcnt != -20)
        {
            if(stopcnt == 1)
                stopairs();
            stopcnt--;
        }
        if(bfcrash != 0)
            bfcrash--;
        if(bfscrape != 0)
            bfscrape--;
        if(bfsc1 != 0)
            bfsc1--;
        if(bfsc2 != 0)
            bfsc2--;
        if(bfskid != 0)
            bfskid--;
        if(mad.newcar)
            cntwis = 0;
        if(fase == 0 || fase == 7001 || fase == 6 || fase == -1 || fase == -2 || fase == -3 || fase == -4 || fase == -5)
        {
            if(mutes != control.mutes)
                mutes = control.mutes;
            if(control.mutem != mutem)
            {
                mutem = control.mutem;
                if(mutem)
                {
                    if(loadedt)
                        strack.stop();
                } else
                if(loadedt)
                    strack.resume();
            }
        }
        if(mad.cntdest != 0 && cntwis < 7)
        {
            if(mad.dest)
                cntwis++;
        } else
        {
            if(mad.cntdest == 0)
                cntwis = 0;
            if(cntwis == 7)
                cntwis = 8;
        }
        if(macn)
            closesounds();
    }

    public void stopairs()
    {
        for(int i = 0; i < 6; i++)
            air[i].stop();

    }

    public void sparkeng(int i, int i_262)
    {
        if(lcn != i_262)
        {
            for(int i_263 = 0; i_263 < 5; i_263++)
                if(pengs[i_263])
                {
                    engs[cd.enginsignature[lcn]][i_263].stop();
                    pengs[i_263] = false;
                }

            lcn = i_262;
        }
        i++;
        for(int i_264 = 0; i_264 < 5; i_264++)
        {
            if(i == i_264)
            {
                if(!pengs[i_264])
                {
                    engs[cd.enginsignature[i_262]][i_264].loop();
                    pengs[i_264] = true;
                }
                continue;
            }
            if(pengs[i_264])
            {
                engs[cd.enginsignature[i_262]][i_264].stop();
                pengs[i_264] = false;
            }
        }

    }

    public void crash(float f, int i)
    {
        if(bfcrash == 0)
        {
            if(i == 0)
            {
                if(Math.abs(f) > 25F && Math.abs(f) < 170F)
                {
                    if(!mutes)
                        lowcrash[crshturn].play();
                    bfcrash = 2;
                }
                if(Math.abs(f) >= 170F)
                {
                    if(!mutes)
                        crash[crshturn].play();
                    bfcrash = 2;
                }
                if(Math.abs(f) > 25F)
                {
                    if(crashup)
                        crshturn--;
                    else
                        crshturn++;
                    if(crshturn == -1)
                        crshturn = 2;
                    if(crshturn == 3)
                        crshturn = 0;
                }
            }
            if(i == -1)
            {
                if(Math.abs(f) > 25F && Math.abs(f) < 170F)
                {
                    if(!mutes)
                        lowcrash[2].play();
                    bfcrash = 2;
                }
                if(Math.abs(f) > 170F)
                {
                    if(!mutes)
                        crash[2].play();
                    bfcrash = 2;
                }
            }
            if(i == 1)
            {
                if(!mutes)
                    tires.play();
                bfcrash = 3;
            }
        }
    }

    public void skid(int i, float f)
    {
        if(bfcrash == 0 && bfskid == 0 && f > 150F)
        {
            if(i == 0)
            {
                if(!mutes)
                    skid[skflg].play();
                if(skidup)
                    skflg++;
                else
                    skflg--;
                if(skflg == 3)
                    skflg = 0;
                if(skflg == -1)
                    skflg = 2;
            } else
            {
                if(!mutes)
                    dustskid[dskflg].play();
                if(skidup)
                    dskflg++;
                else
                    dskflg--;
                if(dskflg == 3)
                    dskflg = 0;
                if(dskflg == -1)
                    dskflg = 2;
            }
            bfskid = 35;
        }
    }

    public void scrape(int i, int i_265, int i_266)
    {
        if(bfscrape == 0 && Math.sqrt(i * i + i_265 * i_265 + i_266 * i_266) / 10D > 10D)
        {
            int i_267 = 0;
            if(m.random() > m.random())
                i_267 = 1;
            if(i_267 == 0)
            {
                sturn1 = 0;
                sturn0++;
                if(sturn0 == 3)
                {
                    i_267 = 1;
                    sturn1 = 1;
                    sturn0 = 0;
                }
            } else
            {
                sturn0 = 0;
                sturn1++;
                if(sturn1 == 3)
                {
                    i_267 = 0;
                    sturn0 = 1;
                    sturn1 = 0;
                }
            }
            if(!mutes)
                scrape[i_267].play();
            bfscrape = 5;
        }
    }

    public void gscrape(int i, int i_268, int i_269)
    {
        if((bfsc1 == 0 || bfsc2 == 0) && Math.sqrt(i * i + i_268 * i_268 + i_269 * i_269) / 10D > 15D)
            if(bfsc1 == 0)
            {
                if(!mutes)
                {
                    scrape[2].stop();
                    scrape[2].play();
                }
                bfsc1 = 12;
                bfsc2 = 6;
            } else
            {
                if(!mutes)
                {
                    scrape[3].stop();
                    scrape[3].play();
                }
                bfsc2 = 12;
                bfsc1 = 6;
            }
    }

    public void closesounds()
    {
        for(int i = 0; i < 5; i++)
        {
            for(int i_270 = 0; i_270 < 5; i_270++)
                engs[i][i_270].checkopen();

        }

        for(int i = 0; i < 6; i++)
            air[i].checkopen();

        tires.checkopen();
        checkpoint.checkopen();
        carfixed.checkopen();
        powerup.checkopen();
        three.checkopen();
        two.checkopen();
        one.checkopen();
        go.checkopen();
        wastd.checkopen();
        firewasted.checkopen();
        for(int i = 0; i < 3; i++)
        {
            skid[i].checkopen();
            dustskid[i].checkopen();
            crash[i].checkopen();
            lowcrash[i].checkopen();
            scrape[i].checkopen();
        }

    }

    public void rot(int is[], int is_271[], int i, int i_272, int i_273, int i_274)
    {
        if(i_273 != 0)
        {
            for(int i_275 = 0; i_275 < i_274; i_275++)
            {
                int i_276 = is[i_275];
                int i_277 = is_271[i_275];
                is[i_275] = i + (int)((float)(i_276 - i) * m.cos(i_273) - (float)(i_277 - i_272) * m.sin(i_273));
                is_271[i_275] = i_272 + (int)((float)(i_276 - i) * m.sin(i_273) + (float)(i_277 - i_272) * m.cos(i_273));
            }

        }
    }

    public int xs(int i, int i_278)
    {
        if(i_278 < 50)
            i_278 = 50;
        return ((i_278 - m.focus_point) * (m.cx - i)) / i_278 + i;
    }

    public int ys(int i, int i_279)
    {
        if(i_279 < 50)
            i_279 = 50;
        return ((i_279 - m.focus_point) * (m.cy - i)) / i_279 + i;
    }

    public int py(int i, int i_280, int i_281, int i_282)
    {
        return (i - i_280) * (i - i_280) + (i_281 - i_282) * (i_281 - i_282);
    }

    public float pys(int i, int i_283, int i_284, int i_285)
    {
        return (float)Math.sqrt((i - i_283) * (i - i_283) + (i_284 - i_285) * (i_284 - i_285));
    }

    public void snap(int i)
    {
        dmg = loadsnap(odmg);
        pwr = loadsnap(opwr);
        was = loadsnap(owas);
        lap = loadsnap(olap);
        pos = loadsnap(opos);
        sped = loadsnap(osped);
        for(int i_286 = 0; i_286 < 8; i_286++)
            rank[i_286] = loadsnap(orank[i_286]);

        for(int i_287 = 0; i_287 < 4; i_287++)
            cntdn[i_287] = loadsnap(ocntdn[i_287]);

        if(multion != 0)
        {
            wgame = loadsnap(owgame);
            exitgame = loadsnap(oexitgame);
            gamefinished = loadsnap(ogamefinished);
            disco = loadsnap(odisco);
        }
        yourwasted = loadsnap(oyourwasted);
        youlost = loadsnap(oyoulost);
        youwon = loadsnap(oyouwon);
        youwastedem = loadsnap(oyouwastedem);
        gameh = loadsnap(ogameh);
        loadingmusic = loadopsnap(oloadingmusic, i, 76);
        star[0] = loadopsnap(ostar[0], i, 0);
        star[1] = loadopsnap(ostar[1], i, 0);
        flaot = loadopsnap(oflaot, i, 1);
    }

    public boolean overon(int i, int i_288, int i_289, int i_290, int i_291, int i_292)
    {
        return i_291 > i && i_291 < i + i_289 && i_292 > i_288 && i_292 < i_288 + i_290;
    }

    public boolean over(Image image, int i, int i_293, int i_294, int i_295)
    {
        int i_296 = image.getHeight(ob);
        int i_297 = image.getWidth(ob);
        return i > i_294 - 5 && i < i_294 + i_297 + 5 && i_293 > i_295 - 5 && i_293 < i_295 + i_296 + 5;
    }

    public void fleximage(Image image, int i, int i_298)
    {
        if(!badmac)
        {
            if(i == 0)
            {
                flexpix = new int[0x57e40];
                PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, 800, 450, flexpix, 0, 800);
                try
                {
                    pixelgrabber.grabPixels();
                }
                catch(InterruptedException interruptedexception) { }
            }
            int i_299 = 0;
            int i_300 = 0;
            int i_301 = 0;
            int i_302 = 0;
            int i_303 = (int)(Math.random() * 128D);
            int i_304 = (int)(5D + Math.random() * 15D);
            for(int i_305 = 0; i_305 < 0x57e40; i_305++)
            {
                Color color = new Color(flexpix[i_305]);
                boolean bool = false;
                boolean bool_306 = false;
                boolean bool_307 = false;
                int i_308;
                int i_309;
                int i_310;
                if(i_299 == 0)
                {
                    i_308 = color.getRed();
                    i_300 = i_308;
                    i_309 = color.getGreen();
                    i_301 = i_309;
                    i_310 = color.getBlue();
                    i_302 = i_310;
                } else
                {
                    i_308 = (int)(((float)color.getRed() + (float)i_300 * 0.38F * (float)i) / (1.0F + 0.38F * (float)i));
                    i_300 = i_308;
                    i_309 = (int)(((float)color.getGreen() + (float)i_301 * 0.38F * (float)i) / (1.0F + 0.38F * (float)i));
                    i_301 = i_309;
                    i_310 = (int)(((float)color.getBlue() + (float)i_302 * 0.38F * (float)i) / (1.0F + 0.38F * (float)i));
                    i_302 = i_310;
                }
                if(++i_299 == 800)
                    i_299 = 0;
                int i_311 = (int)((float)(i_308 * 17 + i_309 + i_310 + i_303) / 21F);
                int i_312 = (int)((float)(i_309 * 17 + i_308 + i_310 + i_303) / 22F);
                int i_313 = (int)((float)(i_310 * 17 + i_308 + i_309 + i_303) / 24F);
                if(--i_304 == 0)
                {
                    i_303 = (int)(Math.random() * 128D);
                    i_304 = (int)(5D + Math.random() * 15D);
                }
                Color color_314 = new Color(i_311, i_312, i_313);
                flexpix[i_305] = color_314.getRGB();
            }

            fleximg = createImage(new MemoryImageSource(800, 450, flexpix, 0, 800));
            rd.drawImage(fleximg, 0, 0, null);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
            rd.fillRect(0, 0, 800, 450);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
    }

    private Image loadsnap(Image image)
    {
        int i = image.getHeight(ob);
        int i_315 = image.getWidth(ob);
        int is[] = new int[i_315 * i];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_315, i, is, 0, i_315);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i_316 = 0; i_316 < i_315 * i; i_316++)
        {
            Color color = new Color(is[i_315 * i - 1]);
            Color color_317 = new Color(is[i_316]);
            if(color_317.getRed() != color_317.getGreen() && color_317.getGreen() != color_317.getBlue())
            {
                int i_318 = (int)((float)color_317.getRed() + (float)color_317.getRed() * ((float)m.snap[0] / 100F));
                if(i_318 > 255)
                    i_318 = 255;
                if(i_318 < 0)
                    i_318 = 0;
                int i_319 = (int)((float)color_317.getGreen() + (float)color_317.getGreen() * ((float)m.snap[1] / 100F));
                if(i_319 > 255)
                    i_319 = 255;
                if(i_319 < 0)
                    i_319 = 0;
                int i_320 = (int)((float)color_317.getBlue() + (float)color_317.getBlue() * ((float)m.snap[2] / 100F));
                if(i_320 > 255)
                    i_320 = 255;
                if(i_320 < 0)
                    i_320 = 0;
                is[i_316] = 0xff000000 | i_318 << 16 | i_319 << 8 | i_320;
                continue;
            }
            int i_321 = (int)(((float)(color.getRed() - color_317.getRed()) / (float)color.getRed()) * 255F);
            if(i_321 > 255)
                i_321 = 255;
            if(i_321 < 0)
                i_321 = 0;
            is[i_316] = i_321 << 24 | 0 | 0 | 0;
        }

        BufferedImage bufferedimage = new BufferedImage(i_315, i, 2);
        bufferedimage.setRGB(0, 0, i_315, i, is, 0, i_315);
        return bufferedimage;
    }

    private Image loadopsnap(Image image, int i, int i_322)
    {
        int i_323 = image.getHeight(ob);
        int i_324 = image.getWidth(ob);
        int is[] = new int[i_324 * i_323];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_324, i_323, is, 0, i_324);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        if(i < 0)
            i = 33;
        int i_325 = 0;
        if(i_322 == 1)
            i_325 = is[61993];
        int is_326[];
        for(is_326 = (new int[] {
    m.snap[0], m.snap[1], m.snap[2]
}); is_326[0] + is_326[1] + is_326[2] < -30;)
        {
            int i_327 = 0;
            while(i_327 < 3) 
            {
                if(is_326[i_327] < 50)
                    is_326[i_327]++;
                i_327++;
            }
        }

        for(int i_328 = 0; i_328 < i_324 * i_323; i_328++)
        {
            if(is[i_328] == is[i_322])
                continue;
            Color color = new Color(is[i_328]);
            boolean bool = false;
            boolean bool_329 = false;
            boolean bool_330 = false;
            int i_331;
            int i_332;
            int i_333;
            if(i_322 == 1 && is[i_328] == i_325)
            {
                i_331 = (int)(237F - 237F * ((float)is_326[0] / 150F));
                if(i_331 > 255)
                    i_331 = 255;
                if(i_331 < 0)
                    i_331 = 0;
                i_332 = (int)(237F - 237F * ((float)is_326[1] / 150F));
                if(i_332 > 255)
                    i_332 = 255;
                if(i_332 < 0)
                    i_332 = 0;
                i_333 = (int)(237F - 237F * ((float)is_326[2] / 150F));
                if(i_333 > 255)
                    i_333 = 255;
                if(i_333 < 0)
                    i_333 = 0;
                if(i == 11)
                {
                    i_331 = 250;
                    i_332 = 250;
                    i_333 = 250;
                }
            } else
            {
                i_331 = (int)((float)color.getRed() - (float)color.getRed() * ((float)is_326[0] / 100F));
                if(i_331 > 255)
                    i_331 = 255;
                if(i_331 < 0)
                    i_331 = 0;
                i_332 = (int)((float)color.getGreen() - (float)color.getGreen() * ((float)is_326[1] / 100F));
                if(i_332 > 255)
                    i_332 = 255;
                if(i_332 < 0)
                    i_332 = 0;
                i_333 = (int)((float)color.getBlue() - (float)color.getBlue() * ((float)is_326[2] / 100F));
                if(i_333 > 255)
                    i_333 = 255;
                if(i_333 < 0)
                    i_333 = 0;
            }
            Color color_334 = new Color(i_331, i_332, i_333);
            is[i_328] = color_334.getRGB();
        }

        Image image_335 = createImage(new MemoryImageSource(i_324, i_323, is, 0, i_324));
        return image_335;
    }

    private Image pressed(Image image)
    {
        int i = image.getHeight(ob);
        int i_336 = image.getWidth(ob);
        int is[] = new int[i_336 * i];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_336, i, is, 0, i_336);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i_337 = 0; i_337 < i_336 * i; i_337++)
            if(is[i_337] != is[i_336 * i - 1])
                is[i_337] = 0xff000000;

        Image image_338 = createImage(new MemoryImageSource(i_336, i, is, 0, i_336));
        return image_338;
    }

    private Image bressed(Image image)
    {
        int i = image.getHeight(ob);
        int i_339 = image.getWidth(ob);
        int is[] = new int[i_339 * i];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_339, i, is, 0, i_339);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        Color color = new Color(247, 255, 165);
        for(int i_340 = 0; i_340 < i_339 * i; i_340++)
            if(is[i_340] != is[i_339 * i - 1])
                is[i_340] = color.getRGB();

        Image image_341 = createImage(new MemoryImageSource(i_339, i, is, 0, i_339));
        return image_341;
    }

    public void pauseimage(Image image)
    {
        if(!badmac)
        {
            int is[] = new int[0x57e40];
            PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, 800, 450, is, 0, 800);
            try
            {
                pixelgrabber.grabPixels();
            }
            catch(InterruptedException interruptedexception) { }
            int i = 0;
            int i_342 = 0;
            int i_343 = 0;
            int i_344 = 0;
            for(int i_345 = 0; i_345 < 0x57e40; i_345++)
            {
                Color color = new Color(is[i_345]);
                boolean bool = false;
                int i_346;
                if(i_344 == 0)
                {
                    i_346 = (color.getRed() + color.getGreen() + color.getBlue()) / 3;
                    i_343 = i_346;
                } else
                {
                    i_346 = (color.getRed() + color.getGreen() + color.getBlue() + i_343 * 30) / 33;
                    i_343 = i_346;
                }
                if(++i_344 == 800)
                    i_344 = 0;
                if(i_345 > 800 * (8 + i_342) + 281 && i_342 < 188)
                {
                    int i_347 = (i_346 + 60) / 3;
                    int i_348 = (i_346 + 135) / 3;
                    int i_349 = (i_346 + 220) / 3;
                    if(++i == 237)
                    {
                        i_342++;
                        i = 0;
                    }
                    Color color_350 = new Color(i_347, i_348, i_349);
                    is[i_345] = color_350.getRGB();
                } else
                {
                    Color color_351 = new Color(i_346, i_346, i_346);
                    is[i_345] = color_351.getRGB();
                }
            }

            fleximg = createImage(new MemoryImageSource(800, 450, is, 0, 800));
            rd.drawImage(fleximg, 0, 0, null);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.setComposite(AlphaComposite.getInstance(3, 0.5F));
            rd.fillRect(0, 0, 800, 450);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
    }

    public void jflexo()
    {
        if(!badmac)
        {
            int is[] = new int[0x57e40];
            PixelGrabber pixelgrabber = new PixelGrabber(app.offImage, 0, 0, 800, 450, is, 0, 800);
            try
            {
                pixelgrabber.grabPixels();
            }
            catch(InterruptedException interruptedexception) { }
            int i = 0;
            int i_352 = 0;
            int i_353 = 0;
            int i_354 = 0;
            for(int i_355 = 0; i_355 < 0x57e40; i_355++)
            {
                Color color = new Color(is[i_355]);
                boolean bool = false;
                boolean bool_356 = false;
                boolean bool_357 = false;
                int i_358;
                int i_359;
                int i_360;
                if(i_354 == 0)
                {
                    i_358 = color.getRed();
                    i = i_358;
                    i_359 = color.getGreen();
                    i_353 = i_359;
                    i_360 = color.getBlue();
                    i_352 = i_360;
                } else
                {
                    i_358 = (color.getRed() + i * 10) / 11;
                    i = i_358;
                    i_359 = (color.getGreen() + i_353 * 10) / 11;
                    i_353 = i_359;
                    i_360 = (color.getBlue() + i_352 * 10) / 11;
                    i_352 = i_360;
                }
                if(++i_354 == 800)
                    i_354 = 0;
                Color color_361 = new Color(i_358, i_359, i_360);
                is[i_355] = color_361.getRGB();
            }

            Image image = createImage(new MemoryImageSource(800, 450, is, 0, 800));
            rd.drawImage(image, 0, 0, null);
        } else
        {
            rd.setColor(new Color(0, 0, 0));
            rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
            rd.fillRect(0, 0, 800, 450);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
    }

    public void pingstat()
    {
        int i = (int)(100D * Math.random());
        try
        {
            URL url = new URL((new StringBuilder()).append("http://c.statcounter.com/9994681/0/14bb645e/1/?reco=").append(i).append("").toString());
            url.openConnection().setConnectTimeout(5000);
            Image image = Toolkit.getDefaultToolkit().createImage(url);
            MediaTracker mediatracker = new MediaTracker(app);
            mediatracker.addImage(image, 0);
            mediatracker.waitForID(0);
            mediatracker.removeImage(image, 0);
            Object object = null;
            Object object_362 = null;
        }
        catch(Exception exception) { }
    }

    public Image getImage(String string)
    {
        Image image = Toolkit.getDefaultToolkit().createImage(string);
        MediaTracker mediatracker = new MediaTracker(app);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        return image;
    }

    private Image loadimage(byte is[], MediaTracker mediatracker, Toolkit toolkit)
    {
        Image image = toolkit.createImage(is);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        return image;
    }

    private Image loadude(byte is[], MediaTracker mediatracker, Toolkit toolkit)
    {
        Image image = toolkit.createImage(is);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        int i = image.getHeight(ob);
        int i_363 = image.getWidth(ob);
        int is_364[] = new int[i_363 * i];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_363, i, is_364, 0, i_363);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i_365 = 0; i_365 < i_363 * i; i_365++)
        {
            Color color = new Color(is_364[i_365]);
            if(color.getGreen() <= color.getRed() + 5 || color.getGreen() <= color.getBlue() + 5)
                continue;
            int i_366 = (int)(255F - (float)(color.getGreen() - (color.getRed() + color.getBlue()) / 2) * 1.5F);
            if(i_366 > 255)
                i_366 = 255;
            if(i_366 < 0)
                i_366 = 0;
            is_364[i_365] = i_366 << 24 | 0 | 0 | 0;
        }

        BufferedImage bufferedimage = new BufferedImage(i_363, i, 2);
        bufferedimage.setRGB(0, 0, i_363, i, is_364, 0, i_363);
        Object object = null;
        return bufferedimage;
    }

    private Image loadBimage(byte is[], MediaTracker mediatracker, Toolkit toolkit, int i)
    {
        Image image = toolkit.createImage(is);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        int i_367 = image.getHeight(ob);
        int i_368 = image.getWidth(ob);
        int is_369[] = new int[i_368 * i_367];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_368, i_367, is_369, 0, i_368);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i_370 = 0; i_370 < i_368 * i_367; i_370++)
        {
            if(is_369[i_370] == is_369[0] && i == 0)
                continue;
            Color color = new Color(is_369[i_370]);
            float fs[] = new float[3];
            Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
            fs[0] = 0.12F;
            fs[1] = 0.45F;
            if(i == 3)
            {
                fs[0] = 0.13F;
                fs[1] = 0.45F;
            }
            Color color_371 = Color.getHSBColor(fs[0], fs[1], fs[2]);
            is_369[i_370] = color_371.getRGB();
        }

        if(i == 2)
        {
            Color color = new Color(is_369[0]);
            int i_372 = 0x40000000 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
            color = new Color(is_369[1]);
            int i_373 = 0x80000000 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
            for(int i_374 = 2; i_374 < i_368 * i_367; i_374++)
            {
                if(is_369[i_374] == is_369[0])
                    is_369[i_374] = i_372;
                if(is_369[i_374] == is_369[1])
                    is_369[i_374] = i_373;
            }

            is_369[0] = i_372;
            is_369[1] = i_373;
        }
        Object object = null;
        Image image_375;
        if(i == 2)
        {
            BufferedImage bufferedimage = new BufferedImage(i_368, i_367, 2);
            bufferedimage.setRGB(0, 0, i_368, i_367, is_369, 0, i_368);
            image_375 = bufferedimage;
        } else
        {
            image_375 = createImage(new MemoryImageSource(i_368, i_367, is_369, 0, i_368));
        }
        Object object_376 = null;
        return image_375;
    }

    private Image dodgen(Image image)
    {
        int i = image.getHeight(ob);
        int i_377 = image.getWidth(ob);
        int is[] = new int[i_377 * i];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i_377, i, is, 0, i_377);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i_378 = 0; i_378 < i_377 * i; i_378++)
        {
            Color color = new Color(is[i_378]);
            int i_379 = color.getRed() * 4 + 90;
            if(i_379 > 255)
                i_379 = 255;
            if(i_379 < 0)
                i_379 = 0;
            int i_380 = color.getGreen() * 4 + 90;
            if(i_380 > 255)
                i_380 = 255;
            if(i_380 < 0)
                i_380 = 0;
            int i_381 = color.getBlue() * 4 + 90;
            if(i_381 > 255)
                i_381 = 255;
            if(i_381 < 0)
                i_381 = 0;
            Color color_382 = new Color(i_379, i_380, i_381);
            is[i_378] = color_382.getRGB();
        }

        Image image_383 = createImage(new MemoryImageSource(i_377, i, is, 0, i_377));
        return image_383;
    }

    private void smokeypix(byte is[], MediaTracker mediatracker, Toolkit toolkit)
    {
        Image image = toolkit.createImage(is);
        mediatracker.addImage(image, 0);
        try
        {
            mediatracker.waitForID(0);
        }
        catch(Exception exception) { }
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, 466, 202, smokey, 0, 466);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i = 0; i < 0x16fb4; i++)
            if(smokey[i] != smokey[0])
            {
                Color color = new Color(smokey[i]);
                float fs[] = new float[3];
                Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
                fs[0] = 0.11F;
                fs[1] = 0.45F;
                Color color_384 = Color.getHSBColor(fs[0], fs[1], fs[2]);
                smokey[i] = color_384.getRGB();
            }

    }

    private void makecarsbgc(Image image, Image image_385)
    {
        int is[] = new int[0x416e0];
        PixelGrabber pixelgrabber = new PixelGrabber(carsbg, 0, 0, 670, 400, is, 0, 670);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        int is_386[] = new int[20700];
        PixelGrabber pixelgrabber_387 = new PixelGrabber(image, 0, 0, 92, 225, is_386, 0, 92);
        try
        {
            pixelgrabber_387.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        int is_388[] = new int[2112];
        PixelGrabber pixelgrabber_389 = new PixelGrabber(image_385, 0, 0, 88, 24, is_388, 0, 88);
        try
        {
            pixelgrabber_389.grabPixels();
        }
        catch(InterruptedException interruptedexception) { }
        for(int i = 0; i < 670; i++)
        {
            for(int i_390 = 0; i_390 < 400; i_390++)
            {
                Color color;
                if(i > 14 && i < 106 && i_390 > 11 && i_390 < 236 && is_386[(i - 14) + (i_390 - 11) * 92] != is_386[0])
                {
                    color = new Color(is[i + i_390 * 670]);
                    Color color_391 = new Color(is_386[(i - 14) + (i_390 - 11) * 92]);
                    int i_392 = (int)((double)color.getRed() * 0.33000000000000002D + (double)color_391.getRed() * 0.67000000000000004D);
                    if(i_392 > 255)
                        i_392 = 255;
                    if(i_392 < 0)
                        i_392 = 0;
                    int i_393 = (int)((double)color.getGreen() * 0.33000000000000002D + (double)color_391.getGreen() * 0.67000000000000004D);
                    if(i_393 > 255)
                        i_393 = 255;
                    if(i_393 < 0)
                        i_393 = 0;
                    int i_394 = (int)((double)color.getBlue() * 0.33000000000000002D + (double)color_391.getBlue() * 0.67000000000000004D);
                    if(i_394 > 255)
                        i_394 = 255;
                    if(i_394 < 0)
                        i_394 = 0;
                    Color color_395 = new Color(i_392, i_393, i_394);
                    is[i + i_390 * 670] = color_395.getRGB();
                }
                if(i > 564 && i < 656 && i_390 > 11 && i_390 < 236 && is_386[(i - 564) + (i_390 - 11) * 92] != is_386[0])
                {
                    color = new Color(is[i + i_390 * 670]);
                    Color color_396 = new Color(is_386[(i - 564) + (i_390 - 11) * 92]);
                    int i_397 = (int)((double)color.getRed() * 0.33000000000000002D + (double)color_396.getRed() * 0.67000000000000004D);
                    if(i_397 > 255)
                        i_397 = 255;
                    if(i_397 < 0)
                        i_397 = 0;
                    int i_398 = (int)((double)color.getGreen() * 0.33000000000000002D + (double)color_396.getGreen() * 0.67000000000000004D);
                    if(i_398 > 255)
                        i_398 = 255;
                    if(i_398 < 0)
                        i_398 = 0;
                    int i_399 = (int)((double)color.getBlue() * 0.33000000000000002D + (double)color_396.getBlue() * 0.67000000000000004D);
                    if(i_399 > 255)
                        i_399 = 255;
                    if(i_399 < 0)
                        i_399 = 0;
                    Color color_400 = new Color(i_397, i_398, i_399);
                    is[i + i_390 * 670] = color_400.getRGB();
                }
                if(i <= 440 || i >= 528 || i_390 <= 53 || i_390 >= 77 || is_388[(i - 440) + (i_390 - 53) * 88] == is_388[0])
                    continue;
                color = new Color(is[i + i_390 * 670]);
                Color color_401 = new Color(is_388[(i - 440) + (i_390 - 53) * 88]);
                int i_402 = (int)((double)color.getRed() * 0.33000000000000002D + (double)color_401.getRed() * 0.67000000000000004D);
                if(i_402 > 255)
                    i_402 = 255;
                if(i_402 < 0)
                    i_402 = 0;
                int i_403 = (int)((double)color.getGreen() * 0.33000000000000002D + (double)color_401.getGreen() * 0.67000000000000004D);
                if(i_403 > 255)
                    i_403 = 255;
                if(i_403 < 0)
                    i_403 = 0;
                int i_404 = (int)((double)color.getBlue() * 0.33000000000000002D + (double)color_401.getBlue() * 0.67000000000000004D);
                if(i_404 > 255)
                    i_404 = 255;
                if(i_404 < 0)
                    i_404 = 0;
                Color color_405 = new Color(i_402, i_403, i_404);
                is[i + i_390 * 670] = color_405.getRGB();
            }

        }

        carsbgc = createImage(new MemoryImageSource(670, 400, is, 0, 670));
    }

    public void carsbginflex()
    {
        if(!badmac)
        {
            flatr = 0;
            flyr = (int)(m.random() * 160F - 80F);
            flyrdest = (int)(((float)flyr + m.random() * 160F) - 80F);
            flang = 1;
            flexpix = new int[0x416e0];
            PixelGrabber pixelgrabber = new PixelGrabber(carsbg, 0, 0, 670, 400, flexpix, 0, 670);
            try
            {
                pixelgrabber.grabPixels();
            }
            catch(InterruptedException interruptedexception) { }
        }
    }

    public void drawSmokeCarsbg()
    {
        if(!badmac)
        {
            if(Math.abs(flyr - flyrdest) > 20)
            {
                if(flyr > flyrdest)
                    flyr -= 20;
                else
                    flyr += 20;
            } else
            {
                flyr = flyrdest;
                flyrdest = (int)(((float)flyr + m.random() * 160F) - 80F);
            }
            if(flyr > 160)
                flyr = 160;
            if(flatr > 170)
            {
                flatrstart++;
                flatr = flatrstart * 3;
                flyr = (int)(m.random() * 160F - 80F);
                flyrdest = (int)(((float)flyr + m.random() * 160F) - 80F);
                flang = 1;
            }
            for(int i = 0; i < 466; i++)
            {
                for(int i_406 = 0; i_406 < 202; i_406++)
                {
                    if(smokey[i + i_406 * 466] == smokey[0])
                        continue;
                    float f = pys(i, 233, i_406, flyr);
                    int i_407 = (int)(((float)(i - 233) / f) * (float)flatr);
                    int i_408 = (int)(((float)(i_406 - flyr) / f) * (float)flatr);
                    int i_409 = i + i_407 + 100 + (i_406 + i_408 + 110) * 670;
                    if(i + i_407 + 100 >= 670 || i + i_407 + 100 <= 0 || i_406 + i_408 + 110 >= 400 || i_406 + i_408 + 110 <= 0 || i_409 >= 0x416e0 || i_409 < 0)
                        continue;
                    Color color = new Color(flexpix[i_409]);
                    Color color_410 = new Color(smokey[i + i_406 * 466]);
                    float f_411 = (255F - (float)color_410.getRed()) / 255F;
                    float f_412 = (255F - (float)color_410.getGreen()) / 255F;
                    float f_413 = (255F - (float)color_410.getBlue()) / 255F;
                    int i_414 = (int)(((float)color.getRed() * ((float)flang * f_411) + (float)color_410.getRed() * (1.0F - f_411)) / ((float)flang * f_411 + (1.0F - f_411)));
                    int i_415 = (int)(((float)color.getGreen() * ((float)flang * f_412) + (float)color_410.getGreen() * (1.0F - f_412)) / ((float)flang * f_412 + (1.0F - f_412)));
                    int i_416 = (int)(((float)color.getBlue() * ((float)flang * f_413) + (float)color_410.getBlue() * (1.0F - f_413)) / ((float)flang * f_413 + (1.0F - f_413)));
                    if(i_414 > 255)
                        i_414 = 255;
                    if(i_414 < 0)
                        i_414 = 0;
                    if(i_415 > 255)
                        i_415 = 255;
                    if(i_415 < 0)
                        i_415 = 0;
                    if(i_416 > 255)
                        i_416 = 255;
                    if(i_416 < 0)
                        i_416 = 0;
                    Color color_417 = new Color(i_414, i_415, i_416);
                    flexpix[i_409] = color_417.getRGB();
                }

            }

            flang += 2;
            flatr += 10 + flatrstart * 2;
            Image image = createImage(new MemoryImageSource(670, 400, flexpix, 0, 670));
            rd.drawImage(image, 65, 25, null);
        } else
        {
            rd.drawImage(carsbg, 65, 25, null);
            flatrstart++;
        }
    }

    public boolean msgcheck(String string)
    {
        boolean bool = false;
        string = string.toLowerCase();
        String strings[] = {
            "fu ", " rape", "slut ", "screw ", "redtube", "fuck", "fuk", "f*ck", "fu*k", "f**k", 
            "ass hole", "asshole", "dick", "dik", "cock", "cok ", "shit", "damn", "sex", "anal", 
            "whore", "bitch", "biatch", "bich", " ass", "bastard", "cunt", "dildo", "fag", "homo", 
            "mothaf", "motherf", "negro", "nigga", "nigger", "pussy", "gay", "homo", "you punk", "i will kill you"
        };
        for(int i = 0; i < strings.length; i++)
            if(string.indexOf(strings[i]) != -1)
                bool = true;

        if(string.startsWith("ass "))
            bool = true;
        if(string.equals("ass"))
            bool = true;
        if(string.equals("rape"))
            bool = true;
        if(string.equals("fu"))
            bool = true;
        String string_418 = "";
        String string_419 = "";
        int i = 0;
        boolean bool_420 = false;
        boolean bool_421;
        for(bool_421 = false; i < string.length() && !bool_421; i++)
        {
            if(!bool_420)
            {
                string_418 = (new StringBuilder()).append(string_418).append("").append(string.charAt(i)).toString();
                bool_420 = true;
                continue;
            }
            bool_420 = false;
            if(!string_419.equals("") && !string_419.equals((new StringBuilder()).append("").append(string.charAt(i)).toString()))
                bool_421 = true;
            string_419 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
        }

        if(!bool_421)
        {
            for(int i_422 = 0; i_422 < strings.length; i_422++)
                if(string_418.indexOf(strings[i_422]) != -1)
                    bool = true;

        }
        string_418 = "";
        string_419 = "";
        i = 0;
        bool_420 = true;
        for(bool_421 = false; i < string.length() && !bool_421; i++)
        {
            if(!bool_420)
            {
                string_418 = (new StringBuilder()).append(string_418).append("").append(string.charAt(i)).toString();
                bool_420 = true;
                continue;
            }
            bool_420 = false;
            if(!string_419.equals("") && !string_419.equals((new StringBuilder()).append("").append(string.charAt(i)).toString()))
                bool_421 = true;
            string_419 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
        }

        if(!bool_421)
        {
            for(int i_423 = 0; i_423 < strings.length; i_423++)
                if(string_418.indexOf(strings[i_423]) != -1)
                    bool = true;

        }
        string_418 = "";
        string_419 = "";
        i = 0;
        int i_424 = 0;
        for(bool_421 = false; i < string.length() && !bool_421; i++)
        {
            if(i_424 == 0)
            {
                string_418 = (new StringBuilder()).append(string_418).append("").append(string.charAt(i)).toString();
                i_424 = 2;
                continue;
            }
            i_424--;
            if(!string_419.equals("") && !string_419.equals((new StringBuilder()).append("").append(string.charAt(i)).toString()))
                bool_421 = true;
            string_419 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
        }

        if(!bool_421)
        {
            for(int i_425 = 0; i_425 < strings.length; i_425++)
                if(string_418.indexOf(strings[i_425]) != -1)
                    bool = true;

        }
        string_418 = "";
        string_419 = "";
        i = 0;
        i_424 = 1;
        for(bool_421 = false; i < string.length() && !bool_421; i++)
        {
            if(i_424 == 0)
            {
                string_418 = (new StringBuilder()).append(string_418).append("").append(string.charAt(i)).toString();
                i_424 = 2;
                continue;
            }
            i_424--;
            if(!string_419.equals("") && !string_419.equals((new StringBuilder()).append("").append(string.charAt(i)).toString()))
                bool_421 = true;
            string_419 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
        }

        if(!bool_421)
        {
            for(int i_426 = 0; i_426 < strings.length; i_426++)
                if(string_418.indexOf(strings[i_426]) != -1)
                    bool = true;

        }
        string_418 = "";
        string_419 = "";
        i = 0;
        i_424 = 2;
        for(bool_421 = false; i < string.length() && !bool_421; i++)
        {
            if(i_424 == 0)
            {
                string_418 = (new StringBuilder()).append(string_418).append("").append(string.charAt(i)).toString();
                i_424 = 2;
                continue;
            }
            i_424--;
            if(!string_419.equals("") && !string_419.equals((new StringBuilder()).append("").append(string.charAt(i)).toString()))
                bool_421 = true;
            string_419 = (new StringBuilder()).append("").append(string.charAt(i)).toString();
        }

        if(!bool_421)
        {
            for(int i_427 = 0; i_427 < strings.length; i_427++)
                if(string_418.indexOf(strings[i_427]) != -1)
                    bool = true;

        }
        return bool;
    }

    public boolean drawcarb(boolean bool, Image image, String string, int i, int i_428, int i_429, int i_430, 
            boolean bool_431)
    {
        boolean bool_432 = false;
        boolean bool_433 = false;
        rd.setFont(new Font("Arial", 1, 13));
        ftm = rd.getFontMetrics();
        int i_434;
        if(bool)
        {
            i_434 = ftm.stringWidth(string);
            if(string.startsWith("Class"))
                i_434 = 112;
        } else
        {
            i_434 = image.getWidth(ob);
        }
        int i_435 = 0;
        if(i_429 > i && i_429 < i + i_434 + 14 && i_430 > i_428 && i_430 < i_428 + 28)
        {
            i_435 = 1;
            if(bool_431)
                bool_432 = true;
        }
        rd.drawImage(bcl[i_435], i, i_428, null);
        rd.drawImage(bc[i_435], i + 4, i_428, i_434 + 6, 28, null);
        rd.drawImage(bcr[i_435], i + i_434 + 10, i_428, null);
        if(!bool && i_434 == 73)
            i_428--;
        if(bool)
        {
            if(string.equals("X") && i_435 == 1)
                rd.setColor(new Color(255, 0, 0));
            else
                rd.setColor(new Color(0, 0, 0));
            if(string.startsWith("Class"))
                rd.drawString(string, 400 - ftm.stringWidth(string) / 2, i_428 + 19);
            else
                rd.drawString(string, i + 7, i_428 + 19);
        } else
        {
            rd.drawImage(image, i + 7, i_428 + 7, null);
        }
        return bool_432;
    }

    public void drawWarning()
    {
        if(warning < 2)
            GameSparker.postMessage("Show education and express yourself properly", 209);
    }

    public void showMessage(String msg)
    {
        Font tmp = rd.getFont();
        FontMetrics tmpm = ftm;
        rd.setColor(new Color(30, 30, 30, 100));
        rd.setFont(new Font("Arial", 1, 16));
        ftm = rd.getFontMetrics();
        rd.fillRoundRect(400 - (ftm.stringWidth(msg) + 30) / 2, 360, ftm.stringWidth(msg) + 30, 30, 10, 10);
        drawcs(380, msg, 255, 255, 255, 3);
        rd.setFont(tmp);
        ftm = tmpm;
    }

    public int getvalue(String string, int i)
    {
        int i_436 = -1;
        try
        {
            int i_437 = 0;
            int i_438 = 0;
            int i_439 = 0;
            String string_440 = "";
            String string_441 = "";
            for(; i_437 < string.length() && i_439 != 2; i_437++)
            {
                string_440 = (new StringBuilder()).append("").append(string.charAt(i_437)).toString();
                if(string_440.equals("|"))
                {
                    i_438++;
                    if(i_439 == 1 || i_438 > i)
                        i_439 = 2;
                    continue;
                }
                if(i_438 == i)
                {
                    string_441 = (new StringBuilder()).append(string_441).append(string_440).toString();
                    i_439 = 1;
                }
            }

            if(string_441.equals(""))
                string_441 = "-1";
            i_436 = Integer.valueOf(string_441).intValue();
        }
        catch(Exception exception) { }
        return i_436;
    }

    public String getSvalue(String string, int i)
    {
        String string_442 = "";
        try
        {
            int i_443 = 0;
            int i_444 = 0;
            int i_445 = 0;
            String string_446 = "";
            String string_447 = "";
            for(; i_443 < string.length() && i_445 != 2; i_443++)
            {
                string_446 = (new StringBuilder()).append("").append(string.charAt(i_443)).toString();
                if(string_446.equals("|"))
                {
                    i_444++;
                    if(i_445 == 1 || i_444 > i)
                        i_445 = 2;
                    continue;
                }
                if(i_444 == i)
                {
                    string_447 = (new StringBuilder()).append(string_447).append(string_446).toString();
                    i_445 = 1;
                }
            }

            string_442 = string_447;
        }
        catch(Exception exception) { }
        return string_442;
    }

    protected String passRem(String str)
    {
        String out = str;
        String pass = app.tpass.getText();
        if(pass.isEmpty())
            pass = "%NaN%";
        int index = str.indexOf(pass.toLowerCase());
        if(index != -1)
        {
            String s1 = str.substring(0, index);
            String s2 = str.substring(index + pass.length());
            out = (new StringBuilder()).append(s1).append("****").append(s2).toString();
        }
        return out;
    }

    Graphics2D rd;
    Medium m;
    CarDefine cd;
    FontMetrics ftm;
    ImageObserver ob;
    GameSparker app;
    int fase;
    int oldfase;
    int starcnt;
    boolean mtop;
    int opselect;
    int dropf;
    int cfase;
    boolean firstime;
    boolean shaded;
    int flipo;
    int nextc;
    int multion;
    int gmode;
    int unlocked[] = {
        1, 1
    };
    int scm[] = {
        0, 0
    };
    int looped;
    int warning;
    boolean newparts;
    boolean logged;
    boolean gotlog;
    boolean autolog;
    boolean nofull;
    int nfreeplays;
    int ndisco;
    int hours;
    boolean onviewpro;
    int playingame;
    int onjoin;
    int ontyp;
    boolean lan;
    float arnp[] = {
        0.5F, 0.0F, 0.0F, 1.0F, 0.5F, 0.0F
    };
    String nickname;
    String clan;
    String nickey;
    String clankey;
    String backlog;
    String server;
    String localserver;
    String servername;
    int servport;
    int gameport;
    int acexp;
    int discon;
    int cntptrys;
    int delays[] = {
        600, 600, 600
    };
    int nplayers;
    int im;
    String plnames[] = {
        "", "", "", "", "", "", "", ""
    };
    int osc;
    int minsl;
    int maxsl;
    int sc[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int xstart[] = {
        0, -350, 350, 0, -350, 350, 0, 0
    };
    int zstart[] = {
        -760, -380, -380, 0, 380, 380, 760, 0
    };
    float allrnp[][];
    boolean isbot[];
    int clangame;
    boolean clanchat;
    String pclan[] = {
        "", "", "", "", "", "", "", ""
    };
    String gaclan;
    int lcarx;
    int lcary;
    int lcarz;
    int dcrashes[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int beststunt;
    int laptime;
    int fastestlap;
    int sendstat;
    int testdrive;
    boolean holdit;
    int holdcnt;
    boolean winner;
    int flexpix[];
    int smokey[];
    Image fleximg;
    int flatrstart;
    Thread runner;
    int runtyp;
    int forstart;
    int exitm;
    Image odmg;
    Image opwr;
    Image opos;
    Image osped;
    Image owas;
    Image olap;
    Image oyourwasted;
    Image odisco;
    Image ogamefinished;
    Image oyoulost;
    Image oyouwon;
    Image oyouwastedem;
    Image ogameh;
    Image owgame;
    Image oloadingmusic;
    Image oflaot;
    Image oexitgame;
    Image mload;
    Image dmg;
    Image pwr;
    Image pos;
    Image sped;
    Image was;
    Image lap;
    Image br;
    Image select;
    Image loadingmusic;
    Image yourwasted;
    Image disco;
    Image gamefinished;
    Image youlost;
    Image youwon;
    Image youwastedem;
    Image gameh;
    Image wgame;
    Image congrd;
    Image gameov;
    Image carsbg;
    Image carsbgc;
    Image selectcar;
    Image statb;
    Image statbo;
    Image mdness;
    Image paused;
    Image radicalplay;
    Image logocars;
    Image logomadnes;
    Image logomadbg;
    Image byrd;
    Image bggo;
    Image opback;
    Image nfmcoms;
    Image opti;
    Image opti2;
    Image bgmain;
    Image rpro;
    Image nfmcom;
    Image flaot;
    Image brt;
    Image arn;
    Image exitgame;
    Image pgate;
    Image fixhoop;
    Image sarrow;
    Image stunts;
    Image racing;
    Image wasting;
    Image plus;
    Image space;
    Image arrows;
    Image chil;
    Image ory;
    Image kz;
    Image kx;
    Image kv;
    Image km;
    Image kn;
    Image ks;
    Image kenter;
    Image nfm;
    Image login;
    Image register;
    Image play;
    Image sdets;
    Image cancel;
    Image bob;
    Image bot;
    Image bol;
    Image bolp;
    Image bor;
    Image borp;
    Image logout;
    Image change;
    Image pln;
    Image pon;
    Image dome;
    Image upgrade;
    Image bols;
    Image bolps;
    Image bors;
    Image borps;
    Image games;
    Image exit;
    Image chat;
    Image players;
    Image cgame;
    Image ccar;
    Image lanm;
    Image asu;
    Image asd;
    Image pls;
    Image sts;
    Image gmc;
    Image stg;
    Image crd;
    Image roomp;
    Image myfr;
    Image mycl;
    Image cnmc;
    Image redy;
    Image ntrg;
    Image bcl[];
    Image bcr[];
    Image bc[];
    Image cmc;
    Image myc;
    Image gac;
    Image yac;
    Image ycmc;
    Image top20s;
    Image trackbg[];
    Image dude[];
    int duds;
    int dudo;
    Image next[];
    Image back[];
    Image contin[];
    Image ostar[];
    Image star[];
    int pcontin;
    int pnext;
    int pback;
    int pstar;
    Image orank[];
    Image rank[];
    Image ocntdn[];
    Image cntdn[];
    int gocnt;
    soundClip engs[][];
    boolean pengs[];
    soundClip air[];
    boolean aird;
    boolean grrd;
    soundClip crash[];
    soundClip lowcrash[];
    soundClip tires;
    soundClip checkpoint;
    soundClip carfixed;
    soundClip powerup;
    soundClip three;
    soundClip two;
    soundClip one;
    soundClip go;
    soundClip wastd;
    soundClip firewasted;
    boolean pwastd;
    soundClip skid[];
    soundClip dustskid[];
    soundClip scrape[];
    boolean mutes;
    RadicalMod intertrack;
    RadicalMod strack;
    boolean loadedt;
    boolean mutem;
    boolean macn;
    boolean badmac;
    boolean arrace;
    int alocked;
    int lalocked;
    int cntflock;
    boolean onlock;
    int ana;
    int cntan;
    int cntovn;
    boolean flk;
    int tcnt;
    boolean tflk;
    String say;
    boolean wasay;
    int clear;
    int posit;
    int wasted;
    int laps;
    int dested[] = {
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int dmcnt;
    boolean dmflk;
    int pwcnt;
    boolean pwflk;
    String adj[][] = {
        {
            "Cool", "Alright", "Nice"
        }, {
            "Wicked", "Amazing", "Super"
        }, {
            "Awesome", "Ripping", "Radical"
        }, {
            "What the...?", "You're a super star!!!!", "Who are you again...?"
        }, {
            "surf style", "off the lip", "bounce back"
        }
    };
    String exlm[] = {
        "!", "!!", "!!!"
    };
    String loop;
    String spin;
    String asay;
    int auscnt;
    boolean aflk;
    int sndsize[] = {
        39, 128, 23, 58, 106, 140, 81, 135, 38, 141, 
        106, 76, 56, 116, 92, 208, 70, 80, 152, 102, 
        27, 65, 52, 30, 151, 129, 80, 44, 57, 123, 
        202, 210, 111
    };
    Image hello;
    Image sign;
    Image loadbar;
    int kbload;
    int dnload;
    float shload;
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    int radpx;
    int pin;
    int trkx[] = {
        65, 735
    };
    int trkl;
    int trklim;
    int lmode;
    int bgmy[] = {
        0, -400
    };
    float bgf;
    boolean bgup;
    int ovx[] = {
        0, 0, 0, 0
    };
    int ovy[] = {
        0, 0, 0, 0
    };
    int ovw[] = {
        0, 0, 0, 0
    };
    int ovh[] = {
        0, 0, 0, 0
    };
    int ovsx[] = {
        0, 0, 0, 0
    };
    int removeds;
    int nfmtab;
    boolean justwon1;
    boolean justwon2;
    int lfrom;
    int lockcnt;
    boolean showtf;
    int ransay;
    String cnames[][] = {
        {
            "", "", "", "", "", "", "Game Chat  "
        }, {
            "", "", "", "", "", "", "Your Clan's Chat  "
        }
    };
    String sentn[][] = {
        {
            "", "", "", "", "", "", ""
        }, {
            "", "", "", "", "", "", ""
        }
    };
    int updatec[] = {
        -1, -1
    };
    int movepos[] = {
        0, 0
    };
    int pointc[] = {
        6, 6
    };
    int floater[] = {
        0, 0
    };
    int cntchatp[] = {
        0, 0
    };
    int msgflk[] = {
        0, 0
    };
    String lcmsg[] = {
        "", ""
    };
    int flkat;
    int movly;
    int gxdu;
    int gydu;
    int muhi;
    int lsc;
    int mouson;
    int onmsc;
    boolean remi;
    int basefase;
    boolean noclass;
    int gatey;
    int pgatx[] = {
        211, 240, 280, 332, 399, 466, 517, 558, 586
    };
    int pgaty[] = {
        193, 213, 226, 237, 244, 239, 228, 214, 196
    };
    int pgady[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    boolean pgas[] = {
        false, false, false, false, false, false, false, false, false
    };
    int waitlink;
    int lxm;
    int lym;
    int pwait;
    int stopcnt;
    int cntwis;
    int lcn;
    int crshturn;
    int bfcrash;
    int bfskid;
    boolean crashup;
    boolean skidup;
    int skflg;
    int dskflg;
    int bfscrape;
    int sturn0;
    int sturn1;
    int bfsc1;
    int bfsc2;
    int flatr;
    int flyr;
    int flyrdest;
    int flang;
    boolean notrees;
    boolean treeflk;
    int prevGmod;
    Chronometer chrono;
    TimeResultSet rs;
    int sumid[];
    static Font fontAdventure;
    static Font fontDigital;
    static Font fontYukari;
    static float blowEffect = 0.0F;
    static float modlMove = 0.0F;

    static 
    {
        try
        {
            fontAdventure = Font.createFont(0, xtGraphics.getResourceAsStream("adventure.ttf"));
            fontDigital = Font.createFont(0, xtGraphics.getResourceAsStream("digital-7.ttf"));
            fontYukari = Font.createFont(0, xtGraphics.getResourceAsStream("yukari.ttf"));
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
