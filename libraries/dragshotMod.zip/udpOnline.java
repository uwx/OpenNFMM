// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   udpOnline.java

import java.io.PrintStream;
import java.net.*;
import java.util.Date;

public class udpOnline
    implements Runnable
{

    public udpOnline(UDPMistro udpmistro, String s, int i, int j, int k)
    {
        gameport = 7001;
        sendat = 0L;
        started = false;
        errd = false;
        nu = 0;
        um = udpmistro;
        gameport = i;
        nu = j;
        try
        {
            dSocket = new DatagramSocket(7010 + k + nu);
            errd = false;
            IPAddress = InetAddress.getByName(s);
        }
        catch(Exception exception)
        {
            System.out.println((new StringBuilder()).append("Error preparing for UDP Connection: ").append(exception).toString());
        }
    }

    public void spark()
    {
        if(errd)
            try
            {
                dSocket = new DatagramSocket(7020 + nu);
                errd = false;
            }
            catch(Exception exception) { }
        try
        {
            con = new Thread(this);
            con.start();
        }
        catch(Exception exception1) { }
    }

    public void closeSocket()
    {
        try
        {
            dSocket.close();
        }
        catch(Exception exception) { }
        dSocket = null;
        errd = true;
        if(con != null)
        {
            con.stop();
            con = null;
        }
        started = false;
    }

    public void stomp()
    {
        if(con != null)
        {
            con.stop();
            con = null;
        }
        started = false;
    }

    public void run()
    {
        started = true;
        Date date = new Date();
        sendat = date.getTime();
        String s = "";
        if(!um.go)
            s = "MAGNITUDE";
        if(nu == 0 && um.diledelay == 0)
        {
            um.sendat = sendat;
            s = (new StringBuilder()).append("").append(sendat).toString();
            s = s.substring(s.length() - 3, s.length());
            um.sendcheck = s;
            um.diledelay = 100;
        }
        try
        {
            byte abyte0[] = new byte[4];
            DatagramPacket datagrampacket = new DatagramPacket(abyte0, abyte0.length, IPAddress, gameport);
            String s1 = (new StringBuilder()).append("").append(s).append("|").append(um.im).append("|").append(um.frame[um.im][0]).append("|").append(um.info[um.im][0]).append("|").toString();
            byte abyte1[] = s1.getBytes();
            datagrampacket.setData(abyte1);
            dSocket.send(datagrampacket);
            for(int i = 0; i < um.nplayers - 1; i++)
            {
                dSocket.receive(datagrampacket);
                String s2 = new String(datagrampacket.getData());
                if((nu == 0 || !um.go) && i == 0)
                {
                    s = getSvalue(s2, 0);
                    if(!um.go && s.equals("1111111"))
                        um.go = true;
                }
                int l = getvalue(s2, 1);
                if(l < 0 || l >= um.nplayers)
                    continue;
                int i1 = getvalue(s2, 2);
                int j1 = 0;
                for(int k1 = 0; k1 < 3; k1++)
                    if(i1 != um.frame[l][k1])
                        j1++;

                if(j1 != 3)
                    continue;
                for(int l1 = 0; l1 < 3; l1++)
                {
                    if(i1 <= um.frame[l][l1])
                        continue;
                    for(int i2 = 2; i2 >= l1 + 1; i2--)
                    {
                        um.frame[l][i2] = um.frame[l][i2 - 1];
                        um.info[l][i2] = um.info[l][i2 - 1];
                    }

                    um.frame[l][l1] = i1;
                    um.info[l][l1] = getSvalue(s2, 3);
                    l1 = 3;
                }

            }

            if(nu == 0 && um.diledelay != 0 && um.sendcheck.equals(s))
            {
                Date date1 = new Date();
                for(int j = 4; j > 0; j--)
                    um.ldelays[j] = um.ldelays[j - 1];

                um.ldelays[0] = (int)(date1.getTime() - um.sendat);
                um.delay = 0;
                for(int k = 0; k < 5; k++)
                    if(um.ldelays[k] != 0 && (um.delay == 0 || um.ldelays[k] < um.delay))
                        um.delay = um.ldelays[k];

                um.diledelay = 0;
                if(um.diled != 10)
                    um.diled++;
            }
        }
        catch(Exception exception)
        {
            try
            {
                dSocket.close();
            }
            catch(Exception exception1) { }
            dSocket = null;
            errd = true;
        }
        started = false;
        con = null;
    }

    public int getvalue(String s, int i)
    {
        int j = -1;
        try
        {
            int k = 0;
            int l = 0;
            int i1 = 0;
            String s1 = "";
            String s3 = "";
            for(; k < s.length() && i1 != 2; k++)
            {
                String s2 = (new StringBuilder()).append("").append(s.charAt(k)).toString();
                if(s2.equals("|"))
                {
                    l++;
                    if(i1 == 1 || l > i)
                        i1 = 2;
                    continue;
                }
                if(l == i)
                {
                    s3 = (new StringBuilder()).append(s3).append(s2).toString();
                    i1 = 1;
                }
            }

            if(s3.equals(""))
                s3 = "-1";
            j = Integer.valueOf(s3).intValue();
        }
        catch(Exception exception) { }
        return j;
    }

    public String getSvalue(String s, int i)
    {
        String s1 = "";
        try
        {
            int j = 0;
            int k = 0;
            int l = 0;
            String s2 = "";
            String s4 = "";
            for(; j < s.length() && l != 2; j++)
            {
                String s3 = (new StringBuilder()).append("").append(s.charAt(j)).toString();
                if(s3.equals("|"))
                {
                    k++;
                    if(l == 1 || k > i)
                        l = 2;
                    continue;
                }
                if(k == i)
                {
                    s4 = (new StringBuilder()).append(s4).append(s3).toString();
                    l = 1;
                }
            }

            s1 = s4;
        }
        catch(Exception exception) { }
        return s1;
    }

    Thread con;
    UDPMistro um;
    int gameport;
    InetAddress IPAddress;
    DatagramSocket dSocket;
    long sendat;
    boolean started;
    boolean errd;
    int nu;
}
