// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GadgetPainter.java

import java.awt.*;
import java.awt.geom.*;
import java.text.DecimalFormat;

public class GadgetPainter
{

    public GadgetPainter()
    {
    }

    public static void speedometer(Graphics2D rd, Medium m, CarDefine cd, Mad madness, xtGraphics xt)
    {
        if(m.resdown == 0)
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        boolean clanchat = xt.clanchat;
        int swit = cd.swits[xt.sc[madness.im]][2];
        boolean goingfast = Math.abs(madness.speed) - (float)swit > 50F;
        if(clanchat)
            rd.translate(0, -25);
        if(Madness.speedon == 1)
        {
            boolean lights = m.darksky || m.lightson;
            Polygon pol;
            if(lights || goingfast)
            {
                if(goingfast)
                    rd.setColor(new Color(180, 0, 0));
                else
                    rd.setColor(new Color(0, 0, 0, 100));
                rd.fillArc(671, 320, 150, 150, 61, 115);
                pol = new Polygon();
                pol.addPoint(782, 330);
                pol.addPoint(782, 410);
                pol.addPoint(618, 410);
                pol.addPoint(623, 390);
                pol.addPoint(670, 390);
                pol.addPoint(746, 395);
                rd.fillPolygon(pol);
            }
            rd.setColor(lights ? new Color(co[ci][0], co[ci][1], co[ci][2]) : xt.colorSnap(30, 70, 150));
            rd.drawArc(671, 320, 150, 150, 61, 115);
            rd.drawLine(782, 330, 782, 410);
            rd.drawLine(782, 410, 618, 410);
            rd.drawLine(618, 410, 623, 390);
            rd.drawLine(623, 390, 670, 390);
            int px = 750;
            int py = 400;
            int degrees = 90 - (int)((double)(Math.abs(madness.speed) / (float)swit) * 110D);
            if(degrees < -20)
                degrees = -20;
            int pox;
            int poy;
            for(int i = 0; i <= 90; i += 30)
            {
                pox = px - (int)(m.sin(i) * 60F);
                poy = py - (int)(m.cos(i) * 60F);
                int ppx = px - (int)(m.sin(i) * 80F);
                int ppy = py - (int)(m.cos(i) * 80F);
                rd.drawLine(pox, poy, ppx, ppy);
            }

            for(int i = -15; i <= 90; i += 30)
            {
                pox = px - (int)(m.sin(i) * 80F);
                poy = py - (int)(m.cos(i) * 80F);
                int ppx = px - (int)(m.sin(i) * 70F);
                int ppy = py - (int)(m.cos(i) * 70F);
                rd.drawLine(pox, poy, ppx, ppy);
            }

            rd.drawString("Speed:", 628, 405);
            rd.setColor(lights ? new Color(250, 0, 0) : new Color(100, 0, 0));
            pol = new Polygon();
            pox = px - (int)(m.sin(degrees + 180) * 5F);
            poy = py - (int)(m.cos(degrees + 180) * 5F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees + 90) * 4F);
            poy = py - (int)(m.cos(degrees + 90) * 4F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees) * 70F);
            poy = py - (int)(m.cos(degrees) * 70F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees - 90) * 4F);
            poy = py - (int)(m.cos(degrees - 90) * 4F);
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
            rd.setFont(new Font("Arial", 1, 14));
            if(goingfast)
                rd.setColor(new Color(250, 0, 0));
            else
                rd.setColor(lights ? new Color(250, 250, 250) : new Color(0, 0, 0));
            String str;
            if(Madness.kph)
                str = (new StringBuilder()).append(dc.format(Math.abs(madness.speed))).append(" Km/h").toString().replace(",", ".");
            else
                str = (new StringBuilder()).append(dc.format(Math.abs((double)madness.speed / 1.6093440000000001D))).append(" Ml/h").toString().replace(",", ".");
            rd.drawString(str, 778 - rd.getFontMetrics().stringWidth(str), 406);
            rd.setFont(new Font("Arial", 1, 11));
            if(goingfast)
            {
                rd.setColor(new Color(255, 140, 10));
                rd.drawString("[Boost]", 625, 383);
            } else
            if(madness.speed < 0.0F)
            {
                rd.setColor(new Color(100, 140, 10));
                rd.drawString("[Rev]", 632, 383);
            }
        } else
        if(Madness.speedon == 2)
        {
            int px = 730;
            int py = 379;
            int degrees = 110 - (int)((double)(Math.abs(madness.speed) / (float)swit) * 220D);
            if(degrees < -115)
                degrees = -115;
            xt.colorSnap(50, 50, 50, 220);
            rd.fillArc(667, 316, 125, 125, -30, 240);
            Polygon pol = new Polygon();
            int pox = (px + 1) - (int)(m.sin(-120) * 62F);
            int poy = (py + 2) - (int)(m.cos(-120) * 62F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(-120) * 62F);
            poy = py - 1 - (int)(m.cos(-120) * 62F);
            pol.addPoint(pox, poy);
            pol.addPoint(px + 1, py);
            pol.addPoint(px - 2, py);
            pox = px - 1 - (int)(m.sin(120) * 62F);
            poy = py - 1 - (int)(m.cos(120) * 62F);
            pol.addPoint(pox, poy);
            pox--;
            poy += 3;
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
            rd.setStroke(new BasicStroke(6F));
            xt.colorSnap(40, 40, 40);
            rd.drawArc(667, 316, 125, 125, -30, 240);
            rd.setStroke(new BasicStroke(2.0F));
            if(!goingfast)
            {
                if(m.darksky || m.lightson)
                    rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
                else
                    xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            } else
            if(m.darksky || m.lightson)
                rd.setColor(new Color(250, 20, 20, 220));
            else
                xt.colorSnap(250, 20, 20, 220);
            rd.drawArc(667, 316, 125, 125, -30, 240);
            rd.setStroke(new BasicStroke(5F));
            for(int i = 11; i >= 0; i--)
            {
                if(!goingfast)
                {
                    if(i == 3)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(50, 204, 120, 220));
                        else
                            xt.colorSnap(50, 204, 120, 220);
                    if(i == 2)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 250, 20, 220));
                        else
                            xt.colorSnap(250, 250, 20, 220);
                    if(i == 1)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 150, 20, 220));
                        else
                            xt.colorSnap(250, 200, 20, 220);
                    if(i == 0)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 20, 20, 220));
                        else
                            xt.colorSnap(250, 20, 20, 220);
                }
                rd.drawArc(675, 324, 109, 109, -30 + (int)(20.800000000000001D * (double)i), 10);
            }

            rd.setStroke(new BasicStroke(1.0F));
            xt.colorSnap(40, 40, 40);
            rd.fillOval(px - 8, py - 8, 16, 16);
            pol = new Polygon();
            pox = px - (int)(m.sin(degrees + 68) * 8F);
            poy = py - (int)(m.cos(degrees + 68) * 8F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees) * 25F);
            poy = py - (int)(m.cos(degrees) * 25F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees - 68) * 8F);
            poy = py - (int)(m.cos(degrees - 68) * 8F);
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
            if(goingfast)
            {
                rd.setColor(new Color(255, 140, 10));
                rd.drawString("[Boost]", 711, 348);
            } else
            if(madness.speed < 0.0F)
            {
                rd.setColor(new Color(100, 140, 10));
                rd.drawString("[Rev]", 717, 348);
            }
            rd.setColor(new Color(250, 0, 0));
            pol = new Polygon();
            pox = px - (int)(m.sin(degrees + 180) * 5F);
            poy = py - (int)(m.cos(degrees + 180) * 5F);
            pol.addPoint(pox, poy);
            pox = px - (int)((double)m.sin(degrees + 90) * 3.2000000000000002D);
            poy = py - (int)((double)m.cos(degrees + 90) * 3.2000000000000002D);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees) * 60F);
            poy = py - (int)(m.cos(degrees) * 60F);
            pol.addPoint(pox, poy);
            pox = px - (int)((double)m.sin(degrees - 90) * 3.2000000000000002D);
            poy = py - (int)((double)m.cos(degrees - 90) * 3.2000000000000002D);
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
            rd.setFont(new Font("Arial", 1, 14));
            if(goingfast)
                rd.setColor(new Color(250, 0, 0));
            else
                rd.setColor(new Color(250, 250, 250));
            String str;
            if(Madness.kph)
                str = (new StringBuilder()).append(dc.format(Math.abs(madness.speed))).append(" Km/h").toString().replace(",", ".");
            else
                str = (new StringBuilder()).append(dc.format(Math.abs((double)madness.speed / 1.6093440000000001D))).append(" Ml/h").toString().replace(",", ".");
            rd.drawString(str, 730 - rd.getFontMetrics().stringWidth(str) / 2, 406);
            rd.setFont(new Font("Arial", 1, 11));
        } else
        if(Madness.speedon == 3)
        {
            if(m.resdown < 2)
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int pow = (int)((Math.abs(madness.speed) / (float)swit) * 94F);
            xt.colorSnap(0, 0, 0, 100);
            rd.fillRoundRect(677, 330, 121, 80, 10, 10);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawString("SPEED", 685, 382);
            for(int i = 0; i < pow && i <= 94; i += 4)
            {
                int h;
                if(i > 38 && i <= 72)
                    h = 17 + (int)(((float)(i - 36) / 32F) * 12F);
                else
                    h = i <= 70 ? 17 : 30;
                rd.fillRect(685 + i, 402 - h, 2, h);
            }

            rd.fillRect(685, 403, 94, 2);
            if(goingfast)
            {
                if(m.darksky || m.lightson)
                    rd.setColor(new Color(250, 20, 20, 220));
                else
                    xt.colorSnap(250, 20, 20, 220);
                for(int i = 0; i < 2; i++)
                {
                    for(int j = 0; j < 5; j++)
                        rd.drawLine(784 + j, (376 + i * 6) - j, 784 + j, (380 + i * 6) - j);

                    for(int j = 4; j > 0; j--)
                        rd.drawLine(793 - j, (377 + i * 6) - j, 793 - j, (381 + i * 6) - j);

                }

            }
            if(madness.speed >= 0.0F)
            {
                for(int i = 0; i < 5; i++)
                    rd.drawLine(784 + (4 - i), 390 + i, 793 - (5 - i), 390 + i);

            } else
            {
                for(int i = 0; i < 5; i++)
                    rd.drawLine(784 + (4 - i), 400 - i, 793 - (5 - i), 400 - i);

            }
            if(Madness.kph)
            {
                rd.drawString("KPH", 771, 344);
                String str = dt.format(Math.abs((int)madness.speed));
                rd.setFont(xtGraphics.fontDigital.deriveFont(2, Math.abs((int)madness.speed) >= 2000 ? 40F : 47F));
                FontMetrics ftm = rd.getFontMetrics();
                rd.drawString(str, 762 - ftm.stringWidth(str), 368);
                rd.setFont(xtGraphics.fontDigital.deriveFont(2, 25F));
                rd.drawString(dp.format((int)Math.abs(madness.speed * 100F) % 100), 767, 368);
            } else
            {
                rd.drawString("MPH", 771, 344);
                String str = dt.format(Math.abs((double)(int)madness.speed / 1.6093440000000001D));
                rd.setFont(xtGraphics.fontDigital.deriveFont(2, Math.abs((double)(int)madness.speed / 1.6093440000000001D) >= 2000D ? 40F : 47F));
                FontMetrics ftm = rd.getFontMetrics();
                rd.drawString(str, 762 - ftm.stringWidth(str), 368);
                rd.setFont(xtGraphics.fontDigital.deriveFont(2, 25F));
                rd.drawString(dp.format((int)Math.abs(((double)madness.speed / 1.6093440000000001D) * 100D) % 100), 767, 368);
            }
            rd.fillRect(763, 365, 3, 3);
            rd.setFont(new Font("Arial", 1, 11));
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        } else
        if(Madness.speedon == 4)
        {
            int px = 730;
            int py = 365;
            int mins = -120;
            int maxs = 120;
            float scale = 0.8F;
            float sensitivity = 3.55F;
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            xt.colorSnap(50, 50, 50, 220);
            rd.fillArc(px - (int)(80F * scale), py - (int)(80F * scale), (int)(160F * scale), (int)(160F * scale), -30, 240);
            Polygon pol = new Polygon();
            pol.addPoint(px, py);
            pol.addPoint(px - (int)(m.sin(-120) * 80F * scale) - 1, py - (int)(m.cos(-120) * 80F * scale) - 1);
            pol.addPoint((px - (int)(m.sin(120) * 80F * scale)) + 1, py - (int)(m.cos(120) * 80F * scale) - 1);
            rd.fillPolygon(pol);
            pol = new Polygon();
            byte byte0 = 3;
            pol.addPoint((px - (int)(m.sin(-120) * 80F * scale)) + byte0, py - (int)(m.cos(-120) * 80F * scale));
            pol.addPoint((px - (int)(m.sin(-120) * 80F * scale)) + byte0, (py - (int)(m.cos(-120) * 80F * scale)) + 14);
            pol.addPoint(((px - (int)(m.sin(-120) * 80F * scale)) + byte0) - 3, (py - (int)(m.cos(-120) * 80F * scale)) + 17);
            pol.addPoint((px - (int)(m.sin(120) * 80F * scale) - byte0) + 3, (py - (int)(m.cos(120) * 80F * scale)) + 17);
            pol.addPoint(px - (int)(m.sin(120) * 80F * scale) - byte0, (py - (int)(m.cos(120) * 80F * scale)) + 14);
            pol.addPoint(px - (int)(m.sin(120) * 80F * scale) - byte0, py - (int)(m.cos(120) * 80F * scale));
            rd.fillPolygon(pol);
            if(m.resdown < 2)
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawPolygon(pol);
            rd.drawArc(px - (int)(81F * scale), py - (int)(81F * scale), (int)(161F * scale), (int)(161F * scale), -15, 210);
            int degrees = 120 - (int)((Math.abs(madness.speed) * 2.0F) / 3F);
            if(madness.speed < 0.0F)
            {
                rd.setColor(new Color(100, 140, 10));
                rd.drawString("[Rev]", 717, 386);
            }
            if(speedocnt != 0)
                speedocnt--;
            if(madness.speed >= (float)swit)
                speedocnt = 10;
            else
            if(madness.speed < (float)(swit - 10))
                speedocnt = 0;
            if(speedocnt != 0)
            {
                rd.setColor(new Color(255, 0, 0));
                rd.drawString("[Max]", 717, 386);
            }
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            if(degrees > maxs)
                degrees = maxs;
            if(degrees < mins)
                degrees = mins;
            degreecnt = (int)((float)degreecnt + (float)(degrees - degreecnt) / sensitivity);
            if((float)Math.abs(degrees - degreecnt) < 1.5F)
                degreecnt = degrees;
            int pox;
            int poy;
            for(int n = mins; n <= maxs; n += 30)
            {
                pox = px - (int)(m.sin(n) * 70F * scale);
                poy = py - (int)(m.cos(n) * 70F * scale);
                int ppx = px - (int)(m.sin(n) * 80F * scale);
                int ppy = py - (int)(m.cos(n) * 80F * scale);
                rd.drawLine(pox, poy, ppx, ppy);
            }

            for(int n = mins + 10; n <= maxs; n += 30)
            {
                pox = px - (int)(m.sin(n) * 80F * scale);
                poy = py - (int)(m.cos(n) * 80F * scale);
                int ppx = px - (int)(m.sin(n) * 75F * scale);
                int ppy = py - (int)(m.cos(n) * 75F * scale);
                rd.drawLine(pox, poy, ppx, ppy);
            }

            for(int n = mins + 20; n <= maxs; n += 30)
            {
                pox = px - (int)(m.sin(n) * 80F * scale);
                poy = py - (int)(m.cos(n) * 80F * scale);
                int ppx = px - (int)(m.sin(n) * 75F * scale);
                int ppy = py - (int)(m.cos(n) * 75F * scale);
                rd.drawLine(pox, poy, ppx, ppy);
            }

            String str[] = {
                "0", "45", "90", "135", "180", "225", "270", "315", "360"
            };
            Font tmp = rd.getFont();
            Color color = rd.getColor();
            int r1 = 0;
            int g1 = 0;
            int b1 = 0;
            FontMetrics ftm;
            for(int n = mins; n <= maxs; n += 30)
            {
                rd.setFont(new Font("Arial", 1, 11));
                ftm = rd.getFontMetrics();
                pox = px - (int)(m.sin(n) * 55F * scale);
                poy = py - (int)(m.cos(n) * 55F * scale);
                if(n == mins)
                    if(degreecnt >= n + 5)
                    {
                        r1 = 70;
                        g1 = 0;
                        b1 = 0;
                    } else
                    {
                        r1 = 170;
                        g1 = 30;
                        b1 = 30;
                    }
                if(n == mins + 30)
                    if(degreecnt >= n)
                    {
                        r1 = 150;
                        g1 = 0;
                        b1 = 0;
                    } else
                    {
                        r1 = 230;
                        g1 = 30;
                        b1 = 30;
                    }
                if(n == mins + 60)
                    if(degreecnt >= n)
                    {
                        r1 = 150;
                        g1 = 30;
                        b1 = 0;
                    } else
                    {
                        r1 = 230;
                        g1 = 60;
                        b1 = 30;
                    }
                if(n == mins + 90)
                    if(degreecnt >= n)
                    {
                        r1 = 150;
                        g1 = 70;
                        b1 = 0;
                    } else
                    {
                        r1 = 230;
                        g1 = 100;
                        b1 = 30;
                    }
                if(n == mins + 120)
                    if(degreecnt >= n)
                    {
                        r1 = 150;
                        g1 = 150;
                        b1 = 30;
                    } else
                    {
                        r1 = 230;
                        g1 = 230;
                        b1 = 60;
                    }
                if(n == mins + 150)
                    if(degreecnt >= n)
                    {
                        r1 = 130;
                        g1 = 150;
                        b1 = 45;
                    } else
                    {
                        r1 = 190;
                        g1 = 230;
                        b1 = 80;
                    }
                if(n == mins + 180)
                    if(degreecnt >= n)
                    {
                        r1 = 100;
                        g1 = 150;
                        b1 = 45;
                    } else
                    {
                        r1 = 150;
                        g1 = 230;
                        b1 = 80;
                    }
                if(n == mins + 210)
                    if(degreecnt >= n)
                    {
                        r1 = 50;
                        g1 = 150;
                        b1 = 20;
                    } else
                    {
                        r1 = 80;
                        g1 = 230;
                        b1 = 30;
                    }
                if(n == mins + 240)
                    if(degreecnt >= n)
                    {
                        r1 = 0;
                        g1 = 80;
                        b1 = 0;
                    } else
                    {
                        r1 = 30;
                        g1 = 150;
                        b1 = 30;
                    }
                rd.setColor(new Color(r1, g1, b1));
                rd.drawString(str[8 - (n / 30 + 4)], pox - ftm.stringWidth(str[8 - (n / 30 + 4)]) / 2, poy + 5);
            }

            rd.setFont(tmp);
            rd.setColor(color);
            ftm = rd.getFontMetrics();
            int coorx[] = new int[720];
            int coory[] = new int[720];
            color = rd.getColor();
            for(int lol = 0; lol < 482; lol++)
                if(lol < 241)
                {
                    coorx[lol] = px - (int)(m.sin(lol - 120) * 80F * scale);
                    coory[lol] = py - (int)(m.cos(lol - 120) * 80F * scale);
                } else
                {
                    coorx[lol] = px - (int)(m.sin(481 - lol - 120) * 82F * scale);
                    coory[lol] = py - (int)(m.cos(481 - lol - 120) * 82F * scale);
                }

            rd.fillPolygon(coorx, coory, 482);
            rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 150));
            for(int lol = 0; lol < 482; lol++)
                if(lol < 241)
                {
                    coorx[lol] = px - (int)(m.sin(lol - 120) * 82F * scale);
                    coory[lol] = py - (int)(m.cos(lol - 120) * 82F * scale);
                } else
                {
                    coorx[lol] = px - (int)(m.sin(481 - lol - 120) * 83F * scale);
                    coory[lol] = py - (int)(m.cos(481 - lol - 120) * 83F * scale);
                }

            rd.fillPolygon(coorx, coory, 482);
            rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 230));
            for(int lol = 0; lol < 482; lol++)
                if(lol < 241)
                {
                    coorx[lol] = px - (int)(m.sin(lol - 120) * 83F * scale);
                    coory[lol] = py - (int)(m.cos(lol - 120) * 83F * scale);
                } else
                {
                    coorx[lol] = px - (int)(m.sin(481 - lol - 120) * 83F * scale);
                    coory[lol] = py - (int)(m.cos(481 - lol - 120) * 83F * scale);
                }

            rd.setColor(color);
            rd.fillPolygon(coorx, coory, 482);
            pol = new Polygon();
            pol.addPoint(px - (int)(m.sin(-120) * 80F * scale), py - (int)(m.cos(-120) * 80F * scale) - 1);
            pol.addPoint(px - (int)(m.sin(-120) * 80F * scale), (py - (int)(m.cos(-120) * 80F * scale)) + 1);
            pol.addPoint(px - (int)(m.sin(120) * 80F * scale), (py - (int)(m.cos(120) * 80F * scale)) + 1);
            pol.addPoint(px - (int)(m.sin(120) * 80F * scale), py - (int)(m.cos(120) * 80F * scale) - 1);
            rd.fillPolygon(pol);
            pol.addPoint((px - (int)(m.sin(-120) * 80F * scale)) + 3, (py - (int)(m.cos(-120) * 80F * scale)) + 14);
            pol.addPoint(((px - (int)(m.sin(-120) * 80F * scale)) + 3) - 3, (py - (int)(m.cos(-120) * 80F * scale)) + 17);
            pol.addPoint((px - (int)(m.sin(120) * 80F * scale) - 3) + 3, (py - (int)(m.cos(120) * 80F * scale)) + 17);
            pol.addPoint(px - (int)(m.sin(120) * 80F * scale) - 3, (py - (int)(m.cos(120) * 80F * scale)) + 14);
            String s9 = "Speed: ";
            if(Madness.kph)
                s9 = (new StringBuilder()).append(s9).append((new StringBuilder()).append(dc.format(Math.abs(madness.speed))).append(" Km/h").toString().replace(",", ".")).toString();
            else
                s9 = (new StringBuilder()).append(s9).append((new StringBuilder()).append(dc.format(Math.abs((double)madness.speed / 1.6093440000000001D))).append(" Ml/h").toString().replace(",", ".")).toString();
            tmp = rd.getFont();
            rd.setFont(new Font("Arial", 1, 10));
            ftm = rd.getFontMetrics();
            rd.drawString(s9, px - ftm.stringWidth(s9) / 2, (py - (int)(m.cos(-120) * 80F * scale)) + 13);
            rd.setFont(tmp);
            rd.setColor(new Color(250, 0, 0));
            pol = new Polygon();
            pox = px - (int)(m.sin(degreecnt + 180) * 5F);
            poy = py - (int)(m.cos(degreecnt + 180) * 5F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degreecnt + 90) * 4F);
            poy = py - (int)(m.cos(degreecnt + 90) * 4F);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degreecnt) * 70F * scale);
            poy = py - (int)(m.cos(degreecnt) * 70F * scale);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degreecnt - 90) * 4F);
            poy = py - (int)(m.cos(degreecnt - 90) * 4F);
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
        }
        rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        if(clanchat)
            rd.translate(0, 25);
    }

    public static void modTrackVisor(Graphics2D rd, Medium m, xtGraphics xt, int xm, int ym)
    {
        if(Madness.modon == 3)
            rd.setFont(xtGraphics.fontDigital.deriveFont(1, 15F));
        else
            rd.setFont(new Font("Arial", 1, 14));
        FontMetrics ftm = rd.getFontMetrics();
        int dist = ftm.stringWidth(RadicalMod.name);
        rd.setFont(new Font("Arial", 1, 11));
        ftm = rd.getFontMetrics();
        if(Madness.hidemod)
        {
            if(xm < 35 + dist && ym < 397 && ym > 355)
                modc = 150;
            if(modc == 0 && modp > 0.0F)
                modp -= 0.1F;
            else
            if(modc > 0)
                modc--;
        } else
        {
            modc = 150;
        }
        if(modc > 0 && modp < 1.0F)
            modp += 0.1F;
        if(ftm.stringWidth(RadicalMod.filename) > dist)
            dist = ftm.stringWidth(RadicalMod.filename);
        if(Madness.modon == 1)
        {
            if(m.darksky || m.lightson)
            {
                rd.setColor(new Color(0, 0, 0, 100));
                rd.fillRoundRect(-10, 355, 35 + (int)((float)dist * modp), 40, 12, 12);
            }
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(30, 70, 150) : new Color(co[ci][0], co[ci][1], co[ci][2]));
            rd.fillRoundRect(-10, 340, 20 + (int)(80F * modp), 18, 12, 12);
            rd.drawRoundRect(-10, 355, 35 + (int)((float)dist * modp), 40, 12, 12);
            if(modp == 1.0F)
            {
                rd.setColor(!m.darksky && !m.lightson ? new Color(20, 20, 20) : new Color(250, 250, 250));
                rd.setFont(new Font("Arial", 1, 14));
                rd.drawString(RadicalMod.name, 11, 374);
                rd.setFont(new Font("Arial", 1, 11));
                rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(220, 220, 220) : new Color(20, 20, 20));
                rd.drawString("Now listening: ", 5, 353);
                rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(30, 70, 150) : new Color(co[ci][0], co[ci][1], co[ci][2]));
                rd.drawString(RadicalMod.filename, 12, 387);
            }
        } else
        if(Madness.modon == 2)
        {
            xt.colorSnap(50, 50, 50, 220);
            rd.fillRoundRect(-10, 355, 35 + (int)((float)dist * modp), 40, 12, 12);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            Polygon pol = new Polygon();
            pol.addPoint(0, 340);
            pol.addPoint((int)(85F * modp), 340);
            pol.addPoint(10 + (int)(85F * modp), 349);
            pol.addPoint((int)(85F * modp), 358);
            pol.addPoint(0, 358);
            rd.fillPolygon(pol);
            pol = new Polygon();
            pol.addPoint(5 + (int)(85F * modp), 340);
            pol.addPoint(15 + (int)(85F * modp), 340);
            pol.addPoint(25 + (int)(85F * modp), 349);
            pol.addPoint(15 + (int)(85F * modp), 358);
            pol.addPoint(5 + (int)(85F * modp), 358);
            pol.addPoint(15 + (int)(85F * modp), 349);
            rd.fillPolygon(pol);
            rd.drawRoundRect(-10, 355, 35 + (int)((float)dist * modp), 40, 12, 12);
            if(modp == 1.0F)
            {
                rd.setFont(new Font("Arial", 1, 14));
                rd.drawString(RadicalMod.name, 11, 374);
                rd.setFont(new Font("Arial", 1, 11));
                xt.colorSnap(50, 50, 50);
                rd.drawString("Now listening: ", 5, 353);
                if(xt.m.lightson || xt.m.darksky)
                    rd.setColor(new Color(250, 250, 250, 220));
                else
                    xt.colorSnap(250, 250, 250);
                rd.drawString(RadicalMod.filename, 12, 387);
            }
        } else
        if(Madness.modon == 3)
        {
            xt.colorSnap(0, 0, 0, 100);
            rd.fillRect(-10, 355, 35 + (int)((float)dist * modp), 40);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.fillRect(25 + (int)((float)dist * modp), 355, 10, 41);
            rd.drawRect(-10, 355, 35 + (int)((float)dist * modp), 40);
            if(modp == 1.0F)
            {
                if(m.resdown < 2)
                    rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setFont(xtGraphics.fontDigital.deriveFont(1, 15F));
                rd.drawString(RadicalMod.name, 11, 374);
                rd.setFont(new Font("Arial", 1, 11));
                if(xt.m.lightson || xt.m.darksky)
                    rd.setColor(new Color(250, 250, 250, 220));
                else
                    xt.colorSnap(250, 250, 250);
                rd.drawString(RadicalMod.filename, 12, 387);
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            }
        } else
        if(Madness.modon == 4)
        {
            xt.colorSnap(50, 50, 50, 220);
            rd.fillRect(-10, 355, 35 + (int)((float)dist * modp), 40);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2]));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2]);
            rd.drawRect(-10, 355, 35 + (int)((float)dist * modp), 40);
            Polygon pol = new Polygon();
            pol.addPoint(15 + (int)((float)dist * modp), 355);
            pol.addPoint(25 + (int)((float)dist * modp), 355);
            pol.addPoint(35 + (int)((float)dist * modp), 375);
            pol.addPoint(25 + (int)((float)dist * modp), 396);
            pol.addPoint(15 + (int)((float)dist * modp), 396);
            pol.addPoint(25 + (int)((float)dist * modp), 375);
            rd.fillPolygon(pol);
            rd.translate(12, 0);
            rd.fillPolygon(pol);
            rd.translate(-12, 0);
            if(modp == 1.0F)
            {
                if(m.resdown < 2)
                    rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setFont(new Font("Arial", 1, 14));
                rd.drawString(RadicalMod.name, 11, 374);
                rd.setFont(new Font("Arial", 1, 11));
                if(xt.m.lightson || xt.m.darksky)
                    rd.setColor(new Color(250, 250, 250, 220));
                else
                    xt.colorSnap(250, 250, 250);
                rd.drawString(RadicalMod.filename, 12, 387);
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            }
        }
    }

    public static void reset()
    {
        modc = 150;
        modp = 1.0F;
        speedocnt = 0;
        degreecnt = 117;
        sshake = 0;
        sprevdam = 0;
    }

    public static void position(Graphics2D rd, Medium m, CheckPoints checkpoints, Mad madness, xtGraphics xt)
    {
        if(Madness.poson == 0)
        {
            if(m.darksky)
            {
                float fs[] = new float[3];
                Color.RGBtoHSB(m.csky[0], m.csky[1], m.csky[2], fs);
                fs[2] = 0.6F;
                Color color = Color.getHSBColor(fs[0], fs[1], fs[2]);
                rd.setColor(color);
                rd.fillRect(18, 6, 155, 14);
                rd.drawLine(17, 7, 17, 18);
                rd.drawLine(16, 9, 16, 16);
                rd.drawLine(173, 7, 173, 18);
                rd.drawLine(174, 9, 174, 16);
                rd.fillRect(40, 26, 107, 21);
                rd.drawLine(39, 27, 39, 45);
                rd.drawLine(38, 29, 38, 43);
                rd.drawLine(147, 27, 147, 45);
                rd.drawLine(148, 29, 148, 43);
            }
            rd.drawImage(xt.lap, 19, 7, xt);
            rd.setColor(new Color(0, 0, 100));
            rd.drawString((new StringBuilder()).append("").append(madness.nlaps + 1).append(" / ").append(checkpoints.nlaps).append("").toString(), 51, 18);
            rd.drawImage(xt.was, 92, 7, xt);
            rd.setColor(new Color(0, 0, 100));
            rd.drawString((new StringBuilder()).append("").append(checkpoints.wasted).append(" / ").append(xt.nplayers - 1).append("").toString(), 150, 18);
            rd.drawImage(xt.pos, 42, 27, xt);
            rd.drawImage(xt.rank[checkpoints.pos[madness.im]], 110, 28, xt);
        } else
        if(Madness.poson == 1)
        {
            if(m.darksky || m.lightson)
            {
                rd.setColor(new Color(0, 0, 0, 100));
                if(m.resdown == 0)
                    rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                rd.fillRoundRect(13, 6, 173, 18, 5, 5);
                rd.fillRoundRect(40, 29, 73, 18, 5, 5);
                if(m.resdown == 0)
                    rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            }
            if(m.resdown == 0)
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            rd.setFont(xtGraphics.fontYukari.deriveFont(1, 15F));
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 0, 0) : new Color(250, 250, 250));
            rd.drawString("lap", 19, 20);
            rd.drawString("wasted", 90, 20);
            rd.drawString("position", 46, 42);
            rd.setFont(xtGraphics.fontYukari.deriveFont(0, 13F));
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(30, 70, 150) : new Color(co[ci][0], co[ci][1], co[ci][2]));
            rd.drawString((new StringBuilder()).append(madness.nlaps + 1).append(" / ").append(checkpoints.nlaps).toString(), 51, 20);
            rd.drawString((new StringBuilder()).append(checkpoints.wasted).append(" / ").append(xt.nplayers - 1).toString(), 154, 20);
            rd.setFont(xtGraphics.fontYukari.deriveFont(1, 72F));
            int pos = checkpoints.pos[madness.im] + 1;
            int sp = rd.getFontMetrics().stringWidth((new StringBuilder()).append("").append(pos).toString());
            rd.setColor(xt.colorSnap(0, 0, 0, 110));
            rd.drawString((new StringBuilder()).append("").append(pos).toString(), 112, 82);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(30, 70, 150) : new Color(co[ci][0], co[ci][1], co[ci][2]));
            rd.drawString((new StringBuilder()).append("").append(pos).toString(), 110, 80);
            rd.setFont(xtGraphics.fontYukari.deriveFont(1, 32F));
            String sufix;
            if(pos == 1)
                sufix = "st";
            else
            if(pos == 2)
                sufix = "nd";
            else
            if(pos == 3)
                sufix = "rd";
            else
                sufix = "th";
            rd.setColor(xt.colorSnap(0, 0, 0, 110));
            rd.drawString(sufix, 113 + sp, 77);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 0, 0) : new Color(250, 250, 250));
            rd.drawString(sufix, 111 + sp, 75);
            rd.setFont(new Font("Arial", 1, 11));
            if(m.resdown == 0)
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        } else
        if(Madness.poson == 2)
        {
            xt.colorSnap(50, 50, 50, 220);
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            }
            rd.fillRoundRect(13, 6, 165, 18, 5, 5);
            rd.fillRoundRect(36, 29, 92, 26, 5, 5);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawRoundRect(13, 6, 165, 18, 5, 5);
            rd.drawRoundRect(36, 29, 92, 26, 5, 5);
            rd.setFont(new Font("Arial", 1, 12));
            rd.drawString("Lap:", 19, 20);
            rd.drawString("Wasted:", 92, 20);
            rd.drawString("Position:", 45, 45);
            if(xt.m.lightson || xt.m.darksky)
                rd.setColor(new Color(250, 250, 250, 220));
            else
                xt.colorSnap(250, 250, 250);
            rd.drawString((new StringBuilder()).append("").append(madness.nlaps + 1).append(" / ").append(checkpoints.nlaps).append("").toString(), 51, 20);
            rd.drawString((new StringBuilder()).append("").append(checkpoints.wasted).append(" / ").append(xt.nplayers - 1).append("").toString(), 150, 20);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.setFont(new Font("Arial", 1, 23));
            int pos = checkpoints.pos[madness.im] + 1;
            int sp = rd.getFontMetrics().stringWidth((new StringBuilder()).append("").append(pos).toString());
            rd.drawString((new StringBuilder()).append("").append(pos).toString(), 98, 51);
            rd.setFont(new Font("Arial", 1, 11));
            String sufix;
            if(pos == 1)
                sufix = "st";
            else
            if(pos == 2)
                sufix = "nd";
            else
            if(pos == 3)
                sufix = "rd";
            else
                sufix = "th";
            if(xt.m.lightson || xt.m.darksky)
                rd.setColor(new Color(250, 250, 250, 220));
            else
                xt.colorSnap(250, 250, 250);
            rd.drawString(sufix, 99 + sp, 50);
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            }
        } else
        if(Madness.poson == 3)
        {
            if(m.resdown == 0)
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            xt.colorSnap(0, 0, 0, 100);
            rd.fillRoundRect(6, 6, 120, 80, 10, 10);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawString("Lap:", 12, 20);
            rd.drawString("Wasted:", 12, 35);
            rd.drawString("Position:", 12, 50);
            rd.setFont(xtGraphics.fontDigital.deriveFont(2, 52F));
            int pos = checkpoints.pos[madness.im] + 1;
            rd.drawString((new StringBuilder()).append("").append(pos).toString(), 104 - rd.getFontMetrics().stringWidth((new StringBuilder()).append("").append(pos).toString()), 80);
            rd.setFont(xtGraphics.fontDigital.deriveFont(1, 13F));
            String sufix;
            if(pos == 1)
                sufix = "st";
            else
            if(pos == 2)
                sufix = "nd";
            else
            if(pos == 3)
                sufix = "rd";
            else
                sufix = "th";
            if(xt.m.lightson || xt.m.darksky)
                rd.setColor(new Color(250, 250, 250, 220));
            else
                xt.colorSnap(250, 250, 250);
            rd.drawString(sufix, 108, 79);
            String str = (new StringBuilder()).append(madness.nlaps + 1).append(" / ").append(checkpoints.nlaps).toString();
            rd.drawString(str, 120 - rd.getFontMetrics().stringWidth(str), 21);
            str = (new StringBuilder()).append(checkpoints.wasted).append(" / ").append(xt.nplayers - 1).toString();
            rd.drawString(str, 120 - rd.getFontMetrics().stringWidth(str), 36);
            rd.setFont(new Font("Arial", 1, 11));
            if(m.resdown == 0)
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        } else
        if(Madness.poson == 4)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            xt.colorSnap(50, 50, 50, 220);
            Polygon pol = new Polygon(new int[] {
                -1, 220, 200, -1
            }, new int[] {
                6, 6, 56, 56
            }, 4);
            rd.fillPolygon(pol);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawPolygon(pol);
            Font tmp = rd.getFont();
            rd.setFont(xtGraphics.fontAdventure.deriveFont(0, 14F));
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : Color.WHITE);
            rd.drawString("Lap:", 15, 22);
            rd.drawString("Wasted:", 102, 22);
            rd.drawString("Position:", 32, 42);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(co[ci][0], co[ci][1], co[ci][2]) : new Color(co[ci][0], co[ci][1], co[ci][2]));
            rd.drawString((new StringBuilder()).append(madness.nlaps + 1).append(" / ").append(checkpoints.nlaps).toString(), 46, 22);
            rd.drawString((new StringBuilder()).append(checkpoints.wasted).append(" / ").append(xt.nplayers - 1).toString(), 160, 22);
            int pos = checkpoints.pos[madness.im] + 1;
            String sufix;
            if(pos == 1)
                sufix = "st";
            else
            if(pos == 2)
                sufix = "nd";
            else
            if(pos == 3)
                sufix = "rd";
            else
                sufix = "th";
            sufix = (new StringBuilder()).append(sufix).append(" / ").append(xt.nplayers - checkpoints.wasted).toString();
            rd.drawString(sufix, 125, 42);
            rd.setFont(xtGraphics.fontAdventure.deriveFont(0, 32F));
            rd.drawString(String.valueOf(pos), 121 - rd.getFontMetrics().stringWidth(String.valueOf(pos)), 52);
            rd.setFont(tmp);
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            }
        }
    }

    public static void status(Graphics2D rd, Medium m, CarDefine cd, Mad madness, xtGraphics xt)
    {
        if(Madness.staton == 0)
        {
            if(m.darksky)
            {
                float fs[] = new float[3];
                Color.RGBtoHSB(m.csky[0], m.csky[1], m.csky[2], fs);
                fs[2] = 0.6F;
                Color color = Color.getHSBColor(fs[0], fs[1], fs[2]);
                rd.setColor(color);
                rd.fillRect(602, 9, 54, 14);
                rd.drawLine(601, 10, 601, 21);
                rd.drawLine(600, 12, 600, 19);
                rd.fillRect(607, 29, 49, 14);
                rd.drawLine(606, 30, 606, 41);
                rd.drawLine(605, 32, 605, 39);
            }
            rd.drawImage(xt.dmg, 600, 7, xt);
            rd.drawImage(xt.pwr, 600, 27, xt);
            xt.drawstat(cd.maxmag[madness.cn], madness.hitmag, madness.newcar, madness.power);
        } else
        if(Madness.staton == 1)
        {
            rd.translate(28, 0);
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            if(m.darksky || m.lightson)
            {
                rd.setColor(new Color(0, 0, 0, 100));
                rd.fillRoundRect(590, 6, 174, 18, 5, 5);
                rd.fillRoundRect(597, 26, 167, 18, 5, 5);
            }
            rd.setFont(xtGraphics.fontYukari.deriveFont(1, 15F));
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 0, 0) : new Color(250, 250, 250));
            rd.drawString("damage", 596, 19);
            rd.drawString("power", 605, 39);
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            }
            xt.drawstat(cd.maxmag[madness.cn], madness.hitmag, madness.newcar, madness.power);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 40, 120) : new Color(co[ci][0], co[ci][1], co[ci][2]));
            Stroke stroke = rd.getStroke();
            rd.setStroke(new BasicStroke(2.0F));
            int px[] = new int[4];
            int py[] = new int[4];
            px[0] = 661;
            py[0] = 10;
            px[1] = 661;
            py[1] = 20;
            px[2] = 760;
            py[2] = 20;
            px[3] = 760;
            py[3] = 10;
            rd.drawPolygon(px, py, 4);
            py[0] = 30;
            py[1] = 40;
            py[2] = 40;
            py[3] = 30;
            rd.drawPolygon(px, py, 4);
            rd.setStroke(stroke);
            rd.translate(-28, 0);
            rd.setFont(new Font("Arial", 1, 11));
        } else
        if(Madness.staton == 2)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            xt.colorSnap(50, 50, 50, 220);
            rd.fill(getBFpow());
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.draw(getBFpow());
            rd.drawString("Damage", 669, 41);
            rd.drawString("Power", 669, 52);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(250, 250, 250));
            else
                xt.colorSnap(250, 250, 250);
            String str = (new StringBuilder()).append(String.valueOf((int)(100F * ((float)madness.hitmag / (float)cd.maxmag[madness.cn])))).append("%").toString();
            rd.drawString(str, 778 - rd.getFontMetrics().stringWidth(str), 41);
            str = (new StringBuilder()).append(String.valueOf((int)((double)(madness.power / 98F) * 100D))).append("%").toString();
            rd.drawString(str, 778 - rd.getFontMetrics().stringWidth(str), 52);
            int i176 = 244;
            int i174 = (int)(98F * ((float)madness.hitmag / (float)cd.maxmag[madness.cn]));
            if(i174 > 33)
                i176 = (int)(244F - 233F * ((float)(i174 - 33) / 65F));
            if(i174 > 70)
            {
                if(xt.dmcnt < 10)
                    if(xt.dmflk)
                    {
                        i176 = 170;
                        xt.dmflk = false;
                    } else
                    {
                        xt.dmflk = true;
                    }
                xt.dmcnt++;
                if((double)xt.dmcnt > 167D - (double)i174 * 1.5D)
                    xt.dmcnt = 0;
            }
            if(i176 > 255)
                i176 = 255;
            if(i176 < 0)
                i176 = 0;
            if(m.darksky || m.lightson)
                rd.setColor(new Color(244, i176, 11, 200));
            else
                xt.colorSnap(244, i176, 11);
            int dam = (int)(((float)madness.hitmag / (float)cd.maxmag[madness.cn]) * 110F);
            for(int i = 0; i < 110; i += 8)
            {
                if(i >= dam)
                    xt.colorSnap(50, 50, 50, 220);
                rd.fillRect(669 + i, i != 0 ? ((int) (i != 8 ? 12 : 15)) : 18, 6, i != 0 ? ((int) (i != 8 ? 17 : 14)) : 11);
            }

            int px = 632;
            int py = 40;
            int degrees = 115 - (int)((double)(madness.power / 98F) * 230D);
            rd.setColor(new Color(250, 0, 0));
            Polygon pol = new Polygon();
            int pox = px - (int)(m.sin(degrees + 180) * 5F);
            int poy = py - (int)(m.cos(degrees + 180) * 5F);
            pol.addPoint(pox, poy);
            pox = px - (int)((double)m.sin(degrees + 90) * 3.5D);
            poy = py - (int)((double)m.cos(degrees + 90) * 3.5D);
            pol.addPoint(pox, poy);
            pox = px - (int)(m.sin(degrees) * 32F);
            poy = py - (int)(m.cos(degrees) * 32F);
            pol.addPoint(pox, poy);
            pox = px - (int)((double)m.sin(degrees - 90) * 3.5D);
            poy = py - (int)((double)m.cos(degrees - 90) * 3.5D);
            pol.addPoint(pox, poy);
            rd.fillPolygon(pol);
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        } else
        if(Madness.staton == 3)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            int pow = (int)((madness.power / 98F) * 240F);
            int dam = (int)(((float)madness.hitmag / (float)cd.maxmag[madness.cn]) * 124F);
            xt.colorSnap(0, 0, 0, 100);
            rd.fillRoundRect(604, 6, 191, 42, 10, 10);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.setFont(new Font("Arial", 1, 11));
            rd.drawString("DAMAGE", 661, 43);
            rd.drawString("POW", 610, 21);
            if(m.resdown != 0)
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Shape tmp = rd.getClip();
            Area clip = new Area(new java.awt.geom.Rectangle2D.Float(0.0F, 0.0F, 800F, 450F));
            Area elipse = new Area(new java.awt.geom.Ellipse2D.Float(626F, 19F, 16F, 16F));
            clip.subtract(elipse);
            rd.setClip(clip);
            for(int i = 0; i < 12; i++)
                if(i * 20 < pow)
                    rd.fillArc(pow < 240 || i != groove / 3 - 1 ? 619 : 617, pow < 240 || i != groove / 3 - 1 ? 12 : 10, pow < 240 || i != groove / 3 - 1 ? 30 : 34, pow < 240 || i != groove / 3 - 1 ? 30 : 34, -185 + i * 21, 14);

            rd.setClip(tmp);
            if(m.resdown != 0)
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            rd.drawRoundRect(604, 6, 191, 42, 10, 10);
            int idam = (int)(((float)dam / 124F) * 100F);
            if(idam >= 45 && idam < 80)
            {
                if(m.darksky || m.lightson)
                    rd.setColor(new Color(250, 250, 0, 220));
                else
                    xt.colorSnap(250, 250, 0, 220);
            } else
            if(idam >= 80)
                if(m.darksky || m.lightson)
                    rd.setColor(new Color(250, 30, 0, 220));
                else
                    xt.colorSnap(250, 50, 0, 220);
            String str = (new StringBuilder()).append(idam).append("%").toString();
            rd.drawString(str, 790 - rd.getFontMetrics().stringWidth(str), 43);
            for(int i = 0; i < dam && i < 125; i += 4)
                rd.fillRect(661 + i, idam < 50 || i != groove ? 13 : 11, 2, idam < 50 || i != groove ? 17 : 21);

            groove += 4;
            if(groove > 124)
                groove = 0;
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        } else
        if(Madness.staton == 4)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            xt.colorSnap(50, 50, 50, 220);
            Polygon pol = new Polygon(new int[] {
                580, 801, 801, 600
            }, new int[] {
                6, 6, 56, 56
            }, 4);
            rd.fillPolygon(pol);
            if(m.darksky || m.lightson)
                rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
            else
                xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
            rd.drawPolygon(pol);
            int pow = (int)((madness.power / 98F) * 116F);
            int dam = (int)(((float)madness.hitmag / (float)cd.maxmag[madness.cn]) * 116F);
            int shakex = 0;
            int shakey = 0;
            if(dam != sprevdam)
            {
                if(dam > sprevdam)
                    sshake = 15;
                sprevdam = dam;
            }
            if(sshake > 0)
            {
                shakex = 3 - (int)(Math.random() * 6D);
                shakey = 3 - (int)(Math.random() * 6D);
                rd.translate(shakex, shakey);
            }
            Font tmp = rd.getFont();
            rd.setFont(xtGraphics.fontAdventure.deriveFont(0, 14F));
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : Color.WHITE);
            rd.drawString("Damage", 605, 27);
            rd.drawString("Power", 614, 47);
            if(dam > 0)
            {
                rd.setClip(new Rectangle(669, 14, 116, 14));
                rd.setColor(dam <= 90 ? dam <= 50 ? Color.YELLOW : new Color(250, 140, 0) : Color.RED);
                pol = new Polygon(new int[] {
                    650, 674 + dam, 669 + dam, 650
                }, new int[] {
                    14, 14, 28, 28
                }, 4);
                rd.fillPolygon(pol);
                rd.setClip(null);
            }
            String str = (new StringBuilder()).append((int)Math.floor(100F * ((float)madness.hitmag / (float)cd.maxmag[madness.cn]))).append("%").toString();
            rd.setFont(new Font("Arial", 1, 11));
            dam = dam <= 116 ? dam : 116;
            if(dam > 30)
            {
                rd.setColor(Color.BLACK);
                rd.drawString(str, 671 + (dam - rd.getFontMetrics().stringWidth(str)) / 2, 25);
            } else
            {
                rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : Color.WHITE);
                rd.drawString(str, 675 + dam, 25);
            }
            if(m.darksky || m.lightson)
                rd.setColor(new Color(50, 204, 255, 220));
            else
                xt.colorSnap(50, 204, 255, 220);
            for(int i = 0; i < pow && i < 114; i += 6)
                rd.fillRect(671 + i, pow < 110 || i != sgroove ? 36 : 35, 4, pow < 110 || i != sgroove ? 10 : 12);

            sgroove += 6;
            if(sgroove > 114)
                sgroove = 0;
            str = (new StringBuilder()).append((int)Math.floor(100F * (madness.power / 98F))).append("%").toString();
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : Color.WHITE);
            rd.drawString(str, 782 - rd.getFontMetrics().stringWidth(str), 45);
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            xt.colorSnap(0, 0, 0);
            Stroke stroke = rd.getStroke();
            rd.setStroke(new BasicStroke(2.0F));
            rd.drawRect(668, 13, 118, 16);
            rd.drawRect(668, 33, 118, 16);
            rd.setStroke(stroke);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 0, 0) : Color.RED);
            rd.drawRect(667, 12, 119, 17);
            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(50, 204, 255) : new Color(50, 204, 255));
            rd.drawRect(667, 32, 119, 17);
            rd.setFont(tmp);
            if(sshake > 0)
            {
                rd.translate(-shakex, -shakey);
                sshake--;
            }
        }
    }

    public static void opponentStatus(xtGraphics xt, Graphics2D rd, CheckPoints checkpoints, Medium m, int i, int i_48_, boolean bool)
    {
        int i_66_ = xt.nplayers;
        if(Madness.arrowon == 0)
        {
            for(int i_67_ = 0; i_67_ < i_66_; i_67_++)
            {
                boolean bool_68_ = false;
                for(int i_69_ = 0; i_69_ < xt.nplayers; i_69_++)
                {
                    if(checkpoints.pos[i_69_] != i_67_ || checkpoints.dested[i_69_] != 0 || bool_68_)
                        continue;
                    rd.setColor(new Color(0, 0, 100));
                    if(i_67_ == 0)
                        rd.drawString("1st", 673, 76 + 30 * i_67_);
                    if(i_67_ == 1)
                        rd.drawString("2nd", 671, 76 + 30 * i_67_);
                    if(i_67_ == 2)
                        rd.drawString("3rd", 671, 76 + 30 * i_67_);
                    if(i_67_ >= 3)
                        rd.drawString((new StringBuilder()).append("").append(i_67_ + 1).append("th").toString(), 671, 76 + 30 * i_67_);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString(xt.plnames[i_69_], 730 - xt.ftm.stringWidth(xt.plnames[i_69_]) / 2, 70 + 30 * i_67_);
                    int i_70_ = (int)(60F * checkpoints.magperc[i_69_]);
                    int i_71_ = 244;
                    int i_72_ = 244;
                    int i_73_ = 11;
                    if(i_70_ > 20)
                        i_72_ = (int)(244F - 233F * ((float)(i_70_ - 20) / 40F));
                    i_71_ = (int)((float)i_71_ + (float)i_71_ * ((float)m.snap[0] / 100F));
                    if(i_71_ > 255)
                        i_71_ = 255;
                    if(i_71_ < 0)
                        i_71_ = 0;
                    i_72_ = (int)((float)i_72_ + (float)i_72_ * ((float)m.snap[1] / 100F));
                    if(i_72_ > 255)
                        i_72_ = 255;
                    if(i_72_ < 0)
                        i_72_ = 0;
                    i_73_ = (int)((float)i_73_ + (float)i_73_ * ((float)m.snap[2] / 100F));
                    if(i_73_ > 255)
                        i_73_ = 255;
                    if(i_73_ < 0)
                        i_73_ = 0;
                    rd.setColor(new Color(i_71_, i_72_, i_73_));
                    rd.fillRect(700, 74 + 30 * i_67_, i_70_, 5);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRect(700, 74 + 30 * i_67_, 60, 5);
                    boolean bool_74_ = false;
                    if((xt.im != i_69_ || xt.multion >= 2) && i > 661 && i < 775 && i_48_ > 58 + 30 * i_67_ && i_48_ < 83 + 30 * i_67_)
                    {
                        bool_74_ = true;
                        if(bool)
                        {
                            if(!xt.onlock)
                                if(xt.alocked != i_69_ || xt.multion >= 2)
                                {
                                    xt.alocked = i_69_;
                                    if(xt.multion >= 2)
                                        xt.im = i_69_;
                                } else
                                {
                                    xt.alocked = -1;
                                }
                            xt.onlock = true;
                        } else
                        if(xt.onlock)
                            xt.onlock = false;
                    }
                    if(xt.alocked == i_69_)
                    {
                        i_71_ = (int)(159F + 159F * ((float)m.snap[0] / 100F));
                        if(i_71_ > 255)
                            i_71_ = 255;
                        if(i_71_ < 0)
                            i_71_ = 0;
                        i_72_ = (int)(207F + 207F * ((float)m.snap[1] / 100F));
                        if(i_72_ > 255)
                            i_72_ = 255;
                        if(i_72_ < 0)
                            i_72_ = 0;
                        i_73_ = (int)(255F + 255F * ((float)m.snap[2] / 100F));
                        if(i_73_ > 255)
                            i_73_ = 255;
                        if(i_73_ < 0)
                            i_73_ = 0;
                        rd.setColor(new Color(i_71_, i_72_, i_73_));
                        rd.drawRect(661, 58 + 30 * i_67_, 114, 25);
                        rd.drawRect(662, 59 + 30 * i_67_, 112, 23);
                    }
                    if(bool_74_ && !xt.onlock)
                    {
                        if(xt.alocked == i_69_)
                        {
                            i_71_ = (int)(120F + 120F * ((float)m.snap[0] / 100F));
                            if(i_71_ > 255)
                                i_71_ = 255;
                            if(i_71_ < 0)
                                i_71_ = 0;
                            i_72_ = (int)(114F + 114F * ((float)m.snap[1] / 100F));
                            if(i_72_ > 255)
                                i_72_ = 255;
                            if(i_72_ < 0)
                                i_72_ = 0;
                            i_73_ = (int)(255F + 255F * ((float)m.snap[2] / 100F));
                            if(i_73_ > 255)
                                i_73_ = 255;
                            if(i_73_ < 0)
                                i_73_ = 0;
                        } else
                        {
                            i_71_ = (int)(140F + 140F * ((float)m.snap[0] / 100F));
                            if(i_71_ > 255)
                                i_71_ = 255;
                            if(i_71_ < 0)
                                i_71_ = 0;
                            i_72_ = (int)(160F + 160F * ((float)m.snap[1] / 100F));
                            if(i_72_ > 255)
                                i_72_ = 255;
                            if(i_72_ < 0)
                                i_72_ = 0;
                            i_73_ = (int)(255F + 255F * ((float)m.snap[2] / 100F));
                            if(i_73_ > 255)
                                i_73_ = 255;
                            if(i_73_ < 0)
                                i_73_ = 0;
                        }
                        rd.setColor(new Color(i_71_, i_72_, i_73_));
                        rd.drawRect(660, 57 + 30 * i_67_, 116, 27);
                    }
                    bool_68_ = true;
                }

            }

        } else
        if(Madness.arrowon == 1)
        {
            for(int i_63_ = 0; i_63_ < i_66_; i_63_++)
            {
                boolean bool_64_ = false;
                for(int i_65_ = 0; i_65_ < i_66_; i_65_++)
                {
                    if(checkpoints.pos[i_65_] != i_63_ || checkpoints.dested[i_65_] != 0 || bool_64_)
                        continue;
                    if(m.darksky || m.lightson)
                    {
                        rd.setColor(new Color(0, 0, 0, 100));
                        rd.fillRect(654, 58 + 30 * i_63_, 121, 25);
                    }
                    if(xt.im == i_65_ || xt.alocked == i_65_ && xt.multion < 2)
                    {
                        rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 40, 120) : new Color(co[ci][0], co[ci][1], co[ci][2]));
                        rd.drawRect(654, 58 + 30 * i_63_, 121, 25);
                        rd.fillRect(655, 59 + 30 * i_63_, xt.alocked != i_65_ || xt.multion >= 2 ? 29 : 4, 24);
                    }
                    rd.setColor(xt.im != i_65_ ? !m.darksky && !m.lightson ? xt.colorSnap(30, 70, 150) : new Color(co[ci][0], co[ci][1], co[ci][2]) : !m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : new Color(0, 0, 0));
                    if(i_63_ == 0)
                        rd.drawString("1st", (xt.im != i_65_ ? 2 : -1) + (xt.alocked != i_65_ || xt.multion >= 2 ? 0 : 2) + 662, 76 + 30 * i_63_);
                    if(i_63_ == 1)
                        rd.drawString("2nd", (xt.im != i_65_ ? 2 : 0) + (xt.alocked != i_65_ || xt.multion >= 2 ? 0 : 2) + 660, 76 + 30 * i_63_);
                    if(i_63_ == 2)
                        rd.drawString("3rd", (xt.im != i_65_ ? 2 : 1) + (xt.alocked != i_65_ || xt.multion >= 2 ? 0 : 2) + 660, 76 + 30 * i_63_);
                    if(i_63_ >= 3)
                        rd.drawString((new StringBuilder()).append(i_63_ + 1).append("th").toString(), (xt.im != i_65_ ? 2 : 1) + (xt.alocked != i_65_ || xt.multion >= 2 ? 0 : 2) + 660, 76 + 30 * i_63_);
                    rd.setFont(new Font("Arial", 1, 11));
                    xt.ftm = rd.getFontMetrics();
                    rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(0, 0, 0) : new Color(250, 250, 250));
                    rd.drawString(xt.plnames[i_65_], 730 - xt.ftm.stringWidth(xt.plnames[i_65_]) / 2, 70 + 30 * i_63_);
                    rd.setFont(new Font("Arial", 1, 11));
                    xt.ftm = rd.getFontMetrics();
                    int i_66 = (int)(60F * checkpoints.magperc[i_65_]);
                    int i_68_ = 244;
                    if(i_66 > 20)
                        i_68_ = (int)(244F - 233F * ((float)(i_66 - 20) / 40F));
                    rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(244, i_68_, 11) : new Color(244, i_68_, 11));
                    rd.fillRect(700, 74 + 30 * i_63_, i_66, 5);
                    rd.setColor(!m.darksky && !m.lightson ? new Color(0, 0, 0) : new Color(250, 250, 250));
                    rd.drawRect(700, 74 + 30 * i_63_, 60, 5);
                    boolean bool_74_ = false;
                    if((xt.im != i_65_ || xt.multion >= 2) && i > 653 && i < 775 && i_48_ > 58 + 30 * i_63_ && i_48_ < 83 + 30 * i_63_)
                    {
                        bool_74_ = true;
                        if(bool)
                        {
                            if(!xt.onlock)
                                if(xt.alocked != i_65_ || xt.multion >= 2)
                                {
                                    xt.alocked = i_65_;
                                    if(xt.multion >= 2)
                                        xt.im = i_65_;
                                } else
                                {
                                    xt.alocked = -1;
                                }
                            xt.onlock = true;
                        } else
                        if(xt.onlock)
                            xt.onlock = false;
                    }
                    if(bool_74_ && !xt.onlock)
                    {
                        if(xt.alocked == i_65_)
                            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(120, 114, 255) : new Color(120, 140, 250));
                        else
                            rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(140, 160, 255) : new Color(140, 160, 250));
                        rd.drawRect(653, 57 + 30 * i_63_, 123, 27);
                        rd.drawRect(654, 58 + 30 * i_63_, 121, 25);
                    }
                    bool_64_ = true;
                }

            }

        } else
        if(Madness.arrowon == 2 || Madness.arrowon == 4)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            for(int i_63_ = 0; i_63_ < i_66_; i_63_++)
            {
                boolean bool_64_ = false;
                for(int i_65_ = 0; i_65_ < i_66_; i_65_++)
                {
                    if(checkpoints.pos[i_65_] != i_63_ || checkpoints.dested[i_65_] != 0 || bool_64_)
                        continue;
                    boolean bool_74_ = false;
                    if((xt.im != i_65_ || xt.multion >= 2) && i > 684 && i < 795 && i_48_ > 60 + 30 * i_63_ && i_48_ < 85 + 30 * i_63_)
                    {
                        bool_74_ = true;
                        if(bool)
                        {
                            if(!xt.onlock)
                                if(xt.alocked != i_65_ || xt.multion >= 2)
                                {
                                    xt.alocked = i_65_;
                                    if(xt.multion >= 2)
                                        xt.im = i_65_;
                                } else
                                {
                                    xt.alocked = -1;
                                }
                            xt.onlock = true;
                        } else
                        if(xt.onlock)
                            xt.onlock = false;
                    }
                    if(bool_74_ && !xt.onlock || xt.alocked == i_65_ && xt.multion < 2)
                        xt.colorSnap(0, 0, 0, 120);
                    else
                        xt.colorSnap(50, 50, 50, 220);
                    Polygon pol = new Polygon();
                    pol.addPoint(682, 60 + 30 * i_63_);
                    pol.addPoint(793, 60 + 30 * i_63_);
                    pol.addPoint(787, 85 + 30 * i_63_);
                    pol.addPoint(676, 85 + 30 * i_63_);
                    rd.fill(pol);
                    if(m.darksky || m.lightson)
                        rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
                    else
                        xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
                    if(xt.im == i_65_)
                        rd.draw(pol);
                    rd.setFont(Madness.arrowon != 2 ? xtGraphics.fontAdventure.deriveFont(1, 23F) : new Font("Arial", 1, 23));
                    rd.drawString(String.valueOf(i_63_ + 1), Madness.arrowon != 2 ? 768 : 769, (Madness.arrowon != 2 ? 82 : 81) + 30 * i_63_);
                    int idam = (int)(100F * checkpoints.magperc[i_65_]);
                    if(idam < 25)
                    {
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(50, 250, 0, 220));
                        else
                            xt.colorSnap(50, 250, 0, 220);
                    } else
                    if(idam >= 25 && idam < 60)
                    {
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 250, 0, 220));
                        else
                            xt.colorSnap(250, 250, 0, 220);
                    } else
                    if(idam >= 60 && idam < 80)
                    {
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 140, 0, 220));
                        else
                            xt.colorSnap(250, 140, 0, 220);
                    } else
                    if(idam >= 80)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 30, 0, 220));
                        else
                            xt.colorSnap(250, 50, 0, 220);
                    idam = (int)(checkpoints.magperc[i_65_] * 60F);
                    if(Madness.arrowon == 2)
                    {
                        for(int j = 0; j < idam && j <= 60; j += 3)
                            rd.fillRect(692 + j, 76 + 30 * i_63_, 2, 6);

                    } else
                    {
                        rd.fillPolygon(new int[] {
                            694, 694 + idam, 692 + idam, 692
                        }, new int[] {
                            76 + 30 * i_63_, 76 + 30 * i_63_, 81 + 30 * i_63_, 81 + 30 * i_63_
                        }, 4);
                        rd.setColor(new Color(250, 250, 250, 120));
                        rd.drawPolygon(new int[] {
                            693, 753, 751, 691
                        }, new int[] {
                            75 + 30 * i_63_, 75 + 30 * i_63_, 81 + 30 * i_63_, 81 + 30 * i_63_
                        }, 4);
                    }
                    rd.setFont(new Font("Arial", 1, 11));
                    xt.ftm = rd.getFontMetrics();
                    rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : new Color(250, 250, 250));
                    rd.drawString(xt.plnames[i_65_], 723 - xt.ftm.stringWidth(xt.plnames[i_65_]) / 2, 72 + 30 * i_63_);
                    bool_64_ = true;
                }

            }

            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        } else
        if(Madness.arrowon == 3)
        {
            if(m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            for(int i_63_ = 0; i_63_ < i_66_; i_63_++)
            {
                boolean bool_64_ = false;
                for(int i_65_ = 0; i_65_ < i_66_; i_65_++)
                {
                    if(checkpoints.pos[i_65_] != i_63_ || checkpoints.dested[i_65_] != 0 || bool_64_)
                        continue;
                    boolean bool_74_ = false;
                    if((xt.im != i_65_ || xt.multion >= 2) && i > 684 && i < 795 && i_48_ > 58 + 30 * i_63_ && i_48_ < 83 + 30 * i_63_)
                    {
                        bool_74_ = true;
                        if(bool)
                        {
                            if(!xt.onlock)
                                if(xt.alocked != i_65_ || xt.multion >= 2)
                                {
                                    xt.alocked = i_65_;
                                    if(xt.multion >= 2)
                                        xt.im = i_65_;
                                } else
                                {
                                    xt.alocked = -1;
                                }
                            xt.onlock = true;
                        } else
                        if(xt.onlock)
                            xt.onlock = false;
                    }
                    if(bool_74_ && !xt.onlock || xt.alocked == i_65_ && xt.multion < 2)
                        xt.colorSnap(0, 0, 0, 150);
                    else
                        xt.colorSnap(0, 0, 0, 100);
                    rd.fillRoundRect(684, 58 + 30 * i_63_, 111, 25, 8, 8);
                    if(m.darksky || m.lightson)
                        rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
                    else
                        xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
                    if(xt.im == i_65_)
                        rd.drawRoundRect(684, 58 + 30 * i_63_, 111, 25, 8, 8);
                    rd.setFont(xtGraphics.fontDigital.deriveFont(0, 28F));
                    rd.drawString(String.valueOf(i_63_ + 1), 690, 80 + 30 * i_63_);
                    int idam = (int)(100F * checkpoints.magperc[i_65_]);
                    if(idam < 45)
                    {
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(50, 204, 255, 220));
                        else
                            xt.colorSnap(50, 204, 255, 220);
                    } else
                    if(idam >= 45 && idam < 80)
                    {
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 250, 0, 220));
                        else
                            xt.colorSnap(250, 250, 0, 220);
                    } else
                    if(idam >= 80)
                        if(m.darksky || m.lightson)
                            rd.setColor(new Color(250, 30, 0, 220));
                        else
                            xt.colorSnap(250, 50, 0, 220);
                    idam = (int)(checkpoints.magperc[i_65_] * 60F);
                    for(int j = 0; j < idam && j <= 60; j += 3)
                        rd.fillRect(720 + j, 74 + 30 * i_63_, 2, 6);

                    rd.setFont(new Font("Arial", 1, 11));
                    xt.ftm = rd.getFontMetrics();
                    rd.setColor(!m.darksky && !m.lightson ? xt.colorSnap(250, 250, 250) : new Color(250, 250, 250));
                    rd.drawString(xt.plnames[i_65_], 751 - xt.ftm.stringWidth(xt.plnames[i_65_]) / 2, 70 + 30 * i_63_);
                    bool_64_ = true;
                }

            }

            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        }
    }

    public static void arrow(xtGraphics xt, Graphics2D rd, int point, int missedcp, CheckPoints checkpoints, boolean arrace)
    {
        if(Madness.arrowon == 0 || Madness.arrowon == 1)
        {
            int is[] = new int[7];
            int is_195_[] = new int[7];
            int is_196_[] = new int[7];
            int i_197_ = 400;
            int i_198_ = -90;
            int i_199_ = 700;
            for(int i_200_ = 0; i_200_ < 7; i_200_++)
                is_195_[i_200_] = i_198_;

            is[0] = i_197_;
            is_196_[0] = i_199_ + 110;
            is[1] = i_197_ - 35;
            is_196_[1] = i_199_ + 50;
            is[2] = i_197_ - 15;
            is_196_[2] = i_199_ + 50;
            is[3] = i_197_ - 15;
            is_196_[3] = i_199_ - 50;
            is[4] = i_197_ + 15;
            is_196_[4] = i_199_ - 50;
            is[5] = i_197_ + 15;
            is_196_[5] = i_199_ + 50;
            is[6] = i_197_ + 35;
            is_196_[6] = i_199_ + 50;
            int i_202_;
            if(!arrace)
            {
                int i_203_ = 0;
                if(checkpoints.x[point] - checkpoints.opx[xt.im] >= 0)
                    i_203_ = 180;
                i_202_ = (int)((double)(90 + i_203_) + Math.atan((double)(checkpoints.z[point] - checkpoints.opz[xt.im]) / (double)(checkpoints.x[point] - checkpoints.opx[xt.im])) / 0.017453292519943295D);
            } else
            {
                int i_204_ = 0;
                if(xt.multion == 0 || xt.alocked == -1)
                {
                    int i_205_ = -1;
                    boolean bool_206_ = false;
                    for(int i_207_ = 0; i_207_ < xt.nplayers; i_207_++)
                        if(i_207_ != xt.im && (xt.py(checkpoints.opx[xt.im] / 100, checkpoints.opx[i_207_] / 100, checkpoints.opz[xt.im] / 100, checkpoints.opz[i_207_] / 100) < i_205_ || i_205_ == -1) && (!bool_206_ || checkpoints.onscreen[i_207_] != 0) && checkpoints.dested[i_207_] == 0)
                        {
                            i_204_ = i_207_;
                            i_205_ = xt.py(checkpoints.opx[xt.im] / 100, checkpoints.opx[i_207_] / 100, checkpoints.opz[xt.im] / 100, checkpoints.opz[i_207_] / 100);
                            if(checkpoints.onscreen[i_207_] != 0)
                                bool_206_ = true;
                        }

                } else
                {
                    i_204_ = xt.alocked;
                }
                int i_208_ = 0;
                if(checkpoints.opx[i_204_] - checkpoints.opx[xt.im] >= 0)
                    i_208_ = 180;
                i_202_ = (int)((double)(90 + i_208_) + Math.atan((double)(checkpoints.opz[i_204_] - checkpoints.opz[xt.im]) / (double)(checkpoints.opx[i_204_] - checkpoints.opx[xt.im])) / 0.017453292519943295D);
                if(xt.multion == 0)
                {
                    if(Madness.arrowon == 0)
                        xt.drawcs(13, "[                                ]", 76, 67, 240, 0);
                    else
                        xt.drawcs(13, "[                                ]", 30, 70, 150, 0);
                    xt.drawcs(13, xt.cd.names[xt.sc[i_204_]], 0, 0, 0, 0);
                } else
                {
                    rd.setFont(new Font("Arial", 1, 12));
                    xt.ftm = rd.getFontMetrics();
                    if(Madness.arrowon == 0)
                        xt.drawcs(17, "[                                ]", 76, 67, 240, 0);
                    else
                        xt.drawcs(17, "[                                ]", 30, 70, 150, 0);
                    xt.drawcs(12, xt.plnames[i_204_], 0, 0, 0, 0);
                    rd.setFont(new Font("Arial", 0, 10));
                    xt.ftm = rd.getFontMetrics();
                    xt.drawcs(24, xt.cd.names[xt.sc[i_204_]], 0, 0, 0, 0);
                    rd.setFont(new Font("Arial", 1, 11));
                    xt.ftm = rd.getFontMetrics();
                }
            }
            for(i_202_ += xt.m.xz; i_202_ < 0; i_202_ += 360);
            for(; i_202_ > 180; i_202_ -= 360);
            if(!arrace)
            {
                if(i_202_ > 130)
                    i_202_ = 130;
                if(i_202_ < -130)
                    i_202_ = -130;
            } else
            {
                if(i_202_ > 100)
                    i_202_ = 100;
                if(i_202_ < -100)
                    i_202_ = -100;
            }
            if(Math.abs(xt.ana - i_202_) < 180)
            {
                if(Math.abs(xt.ana - i_202_) < 10)
                    xt.ana = i_202_;
                else
                if(xt.ana < i_202_)
                    xt.ana += 10;
                else
                    xt.ana -= 10;
            } else
            {
                if(i_202_ < 0)
                {
                    xt.ana += 15;
                    if(xt.ana > 180)
                        xt.ana -= 360;
                }
                if(i_202_ > 0)
                {
                    xt.ana -= 15;
                    if(xt.ana < -180)
                        xt.ana += 360;
                }
            }
            xt.rot(is, is_196_, i_197_, i_199_, xt.ana, 7);
            i_202_ = Math.abs(xt.ana);
            if(!arrace)
            {
                if(i_202_ > 7 || missedcp > 0 || missedcp == -2 || xt.cntan != 0 || Madness.arrowon == 1)
                {
                    for(int i_209_ = 0; i_209_ < 7; i_209_++)
                    {
                        is[i_209_] = xt.xs(is[i_209_], is_196_[i_209_]);
                        is_195_[i_209_] = xt.ys(is_195_[i_209_], is_196_[i_209_]);
                    }

                    if(Madness.arrowon == 0)
                    {
                        int i_210_ = (int)(190F + 190F * ((float)xt.m.snap[0] / 100F));
                        if(i_210_ > 255)
                            i_210_ = 255;
                        if(i_210_ < 0)
                            i_210_ = 0;
                        int i_211_ = (int)(255F + 255F * ((float)xt.m.snap[1] / 100F));
                        if(i_211_ > 255)
                            i_211_ = 255;
                        if(i_211_ < 0)
                            i_211_ = 0;
                        int i_212_ = 0;
                        if(missedcp <= 0)
                        {
                            if(i_202_ <= 45 && missedcp != -2 && xt.cntan == 0)
                            {
                                i_210_ = (i_210_ * i_202_ + xt.m.csky[0] * (45 - i_202_)) / 45;
                                i_211_ = (i_211_ * i_202_ + xt.m.csky[1] * (45 - i_202_)) / 45;
                                i_212_ = (i_212_ * i_202_ + xt.m.csky[2] * (45 - i_202_)) / 45;
                            }
                            if(i_202_ >= 90)
                            {
                                int i_213_ = (int)(255F + 255F * ((float)xt.m.snap[0] / 100F));
                                if(i_213_ > 255)
                                    i_213_ = 255;
                                if(i_213_ < 0)
                                    i_213_ = 0;
                                i_210_ = (i_210_ * (140 - i_202_) + i_213_ * (i_202_ - 90)) / 50;
                                if(i_210_ > 255)
                                    i_210_ = 255;
                            }
                        } else
                        if(xt.flk)
                        {
                            i_210_ = (int)(255F + 255F * ((float)xt.m.snap[0] / 100F));
                            if(i_210_ > 255)
                                i_210_ = 255;
                            if(i_210_ < 0)
                                i_210_ = 0;
                            xt.flk = false;
                        } else
                        {
                            i_210_ = (int)(255F + 255F * ((float)xt.m.snap[0] / 100F));
                            if(i_210_ > 255)
                                i_210_ = 255;
                            if(i_210_ < 0)
                                i_210_ = 0;
                            i_211_ = (int)(220F + 220F * ((float)xt.m.snap[1] / 100F));
                            if(i_211_ > 255)
                                i_211_ = 255;
                            if(i_211_ < 0)
                                i_211_ = 0;
                            xt.flk = true;
                        }
                        rd.setColor(new Color(i_210_, i_211_, i_212_));
                    } else
                    if(missedcp <= 0)
                    {
                        if(i_202_ <= 45 && missedcp != -2 && xt.cntan == 0)
                            xt.colorSnap(190, 255, 0, (int)((255F * (45F - (float)i_202_)) / 45F));
                        else
                        if(i_202_ >= 90)
                        {
                            int i_213_ = (int)(255F + 255F * ((float)xt.m.snap[0] / 100F));
                            if(i_213_ > 255)
                                i_213_ = 255;
                            if(i_213_ < 0)
                                i_213_ = 0;
                            xt.colorSnap((190 * (140 - i_202_) + i_213_ * (i_202_ - 90)) / 50, 255, 0, 200);
                        } else
                        {
                            xt.colorSnap(190, 255, 0, 200);
                        }
                    } else
                    if(xt.flk)
                    {
                        xt.colorSnap(255, 255, 0);
                        xt.flk = false;
                    } else
                    {
                        xt.colorSnap(255, 220, 0);
                        xt.flk = true;
                    }
                    rd.fillPolygon(is, is_195_, 7);
                    if(Madness.arrowon == 0)
                    {
                        int i_210_ = (int)(115F + 115F * ((float)xt.m.snap[0] / 100F));
                        if(i_210_ > 255)
                            i_210_ = 255;
                        if(i_210_ < 0)
                            i_210_ = 0;
                        int i_211_ = (int)(170F + 170F * ((float)xt.m.snap[1] / 100F));
                        if(i_211_ > 255)
                            i_211_ = 255;
                        if(i_211_ < 0)
                            i_211_ = 0;
                        int i_212_ = 0;
                        if(missedcp <= 0)
                        {
                            if(i_202_ <= 45 && missedcp != -2 && xt.cntan == 0)
                            {
                                i_210_ = (i_210_ * i_202_ + xt.m.csky[0] * (45 - i_202_)) / 45;
                                i_211_ = (i_211_ * i_202_ + xt.m.csky[1] * (45 - i_202_)) / 45;
                                i_212_ = (i_212_ * i_202_ + xt.m.csky[2] * (45 - i_202_)) / 45;
                            }
                        } else
                        if(xt.flk)
                        {
                            i_210_ = (int)(255F + 255F * ((float)xt.m.snap[0] / 100F));
                            if(i_210_ > 255)
                                i_210_ = 255;
                            if(i_210_ < 0)
                                i_210_ = 0;
                            i_211_ = 0;
                        }
                        rd.setColor(new Color(i_210_, i_211_, i_212_));
                    } else
                    if(missedcp <= 0)
                    {
                        if(i_202_ <= 45 && missedcp != -2 && xt.cntan == 0)
                            xt.colorSnap(115, 170, 0, (int)((255F * (45F - (float)i_202_)) / 45F));
                        else
                            xt.colorSnap(115, 170, 0);
                    } else
                    if(xt.flk)
                        xt.colorSnap(255, 0, 0);
                    else
                        xt.colorSnap(115, 170, 0);
                    rd.drawPolygon(is, is_195_, 7);
                }
            } else
            {
                int i_214_ = 0;
                if(xt.multion != 0)
                    i_214_ = 8;
                for(int i_215_ = 0; i_215_ < 7; i_215_++)
                {
                    is[i_215_] = xt.xs(is[i_215_], is_196_[i_215_]);
                    is_195_[i_215_] = xt.ys(is_195_[i_215_], is_196_[i_215_]) + i_214_;
                }

                if(Madness.arrowon == 0)
                    xt.colorSnap(159, 207, 255);
                else
                    xt.colorSnap(130, 170, 250, 180);
                rd.fillPolygon(is, is_195_, 7);
                if(Madness.arrowon == 0)
                    xt.colorSnap(120, 114, 255);
                else
                    xt.colorSnap(30, 70, 150);
                rd.drawPolygon(is, is_195_, 7);
            }
        } else
        {
            int i_204_ = xt.im;
            int base = 0;
label0:
            for(int l = 0; l < checkpoints.nlaps; l++)
            {
                int i = 0;
                do
                {
                    if(i >= checkpoints.n)
                        continue label0;
                    if((checkpoints.typ[i] == 1 || checkpoints.typ[i] == 2) && ++base == checkpoints.clear[xt.im] + 1)
                    {
                        point = i;
                        continue label0;
                    }
                    i++;
                } while(true);
            }

            int i_202_;
            if(arrace)
            {
                if(xt.multion == 0 || xt.alocked == -1)
                {
                    int i_205_ = -1;
                    boolean bool_206_ = false;
                    for(int i_207_ = 0; i_207_ < xt.nplayers; i_207_++)
                        if(i_207_ != xt.im && (xt.py(checkpoints.opx[xt.im] / 100, checkpoints.opx[i_207_] / 100, checkpoints.opz[xt.im] / 100, checkpoints.opz[i_207_] / 100) < i_205_ || i_205_ == -1) && (!bool_206_ || checkpoints.onscreen[i_207_] != 0) && checkpoints.dested[i_207_] == 0)
                        {
                            i_204_ = i_207_;
                            i_205_ = xt.py(checkpoints.opx[xt.im] / 100, checkpoints.opx[i_207_] / 100, checkpoints.opz[xt.im] / 100, checkpoints.opz[i_207_] / 100);
                            if(checkpoints.onscreen[i_207_] != 0)
                                bool_206_ = true;
                        }

                } else
                {
                    i_204_ = xt.alocked;
                }
                int i_208_ = 0;
                if(checkpoints.opx[i_204_] - checkpoints.opx[xt.im] >= 0)
                    i_208_ = 180;
                i_202_ = (int)((double)(90 + i_208_) + Math.atan((double)(checkpoints.opz[i_204_] - checkpoints.opz[xt.im]) / (double)(checkpoints.opx[i_204_] - checkpoints.opx[xt.im])) / 0.017453292519943295D);
            } else
            {
                int i_203_ = 0;
                if(checkpoints.x[point] - checkpoints.opx[xt.im] >= 0)
                    i_203_ = 180;
                i_202_ = (int)((double)(90 + i_203_) + Math.atan((double)(checkpoints.z[point] - checkpoints.opz[xt.im]) / (double)(checkpoints.x[point] - checkpoints.opx[xt.im])) / 0.017453292519943295D);
            }
            for(i_202_ += xt.m.xz; i_202_ < 0; i_202_ += 360);
            for(; i_202_ > 180; i_202_ -= 360);
            if(Math.abs(xt.ana - i_202_) < 180)
            {
                if(Math.abs(xt.ana - i_202_) < 10)
                    xt.ana = i_202_;
                else
                if(xt.ana < i_202_)
                    xt.ana += 10;
                else
                    xt.ana -= 10;
            } else
            {
                if(i_202_ < 0)
                {
                    xt.ana += 15;
                    if(xt.ana > 180)
                        xt.ana -= 360;
                }
                if(i_202_ > 0)
                {
                    xt.ana -= 15;
                    if(xt.ana < -180)
                        xt.ana += 360;
                }
            }
            i_202_ = -xt.ana;
            float dist;
            if(arrace)
                dist = (float)Math.sqrt(Math.pow((float)(checkpoints.opz[i_204_] - checkpoints.opz[xt.im]), 2D) + Math.pow((float)(checkpoints.opx[i_204_] - checkpoints.opx[xt.im]), 2D)) / 2.0F;
            else
                dist = (float)Math.sqrt(Math.pow((float)(checkpoints.z[point] - checkpoints.opz[xt.im]), 2D) + Math.pow((float)(checkpoints.x[point] - checkpoints.opx[xt.im]), 2D)) / 2.0F;
            if(xt.m.resdown == 0)
            {
                rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
            if(Madness.arrowon == 2)
            {
                xt.colorSnap(50, 50, 50, 220);
                rd.fillRoundRect(328, 13, 149, 49, 48, 48);
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(250, 250, 250));
                else
                    xt.colorSnap(250, 250, 250);
                String str = xt.plnames[i_204_];
                int f = 15;
                do
                {
                    if(f <= 0)
                        break;
                    rd.setFont(new Font("Arial", 1, f));
                    if(rd.getFontMetrics().stringWidth(str) < 83)
                        break;
                    f--;
                } while(true);
                rd.drawString(str, 384, 37);
                str = String.valueOf((int)(dist / 100F));
                rd.setFont(new Font("Arial", 1, 13));
                xt.ftm = rd.getFontMetrics();
                rd.drawString(str, 349 - xt.ftm.stringWidth(str) / 2, 38);
                f = 11;
                do
                {
                    if(f <= 0)
                        break;
                    rd.setFont(new Font("Arial", 0, f));
                    if(rd.getFontMetrics().stringWidth(str) < 83)
                        break;
                    f--;
                } while(true);
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(220, 220, 220));
                else
                    xt.colorSnap(220, 220, 220);
                rd.drawString(xt.cd.names[xt.sc[i_204_]], 385, 49);
                rd.setFont(new Font("Arial", 0, 11));
                xt.ftm = rd.getFontMetrics();
                rd.drawString("mts", 341, 48);
                Area elipse = new Area(new java.awt.geom.Ellipse2D.Float(324F, 12F, 50F, 50F));
                Area sub = new Area(new java.awt.geom.Ellipse2D.Float(331F, 19F, 36F, 36F));
                elipse.subtract(sub);
                Polygon pol = new Polygon();
                int px = 349;
                int py = 37;
                int pox = px - (int)(xt.m.sin(i_202_ - 180) * 36F);
                int poy = py - (int)(xt.m.cos(i_202_ - 180) * 36F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin((i_202_ + 30) - 180) * 24F);
                poy = py - (int)(xt.m.cos((i_202_ + 30) - 180) * 24F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ - 30 - 180) * 24F);
                poy = py - (int)(xt.m.cos(i_202_ - 30 - 180) * 24F);
                pol.addPoint(pox, poy);
                Area trig = new Area(pol);
                elipse.add(trig);
                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(50, 204, 255, 220));
                    else
                        xt.colorSnap(50, 204, 255, 220);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(250, 250, 20));
                else
                    xt.colorSnap(250, 250, 20);
                rd.fill(elipse);
                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(0, 154, 205, 220));
                    else
                        xt.colorSnap(0, 154, 205, 220);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(200, 160, 0));
                else
                    xt.colorSnap(200, 160, 0);
                Stroke tmp = rd.getStroke();
                rd.setStroke(new BasicStroke(2.0F));
                rd.draw(elipse);
                rd.setStroke(tmp);
                rd.setFont(new Font("Arial", 1, 11));
                xt.ftm = rd.getFontMetrics();
            } else
            if(Madness.arrowon == 3)
            {
                xt.colorSnap(0, 0, 0, 100);
                rd.fillRoundRect(320, 6, 160, 42, 10, 10);
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(co[ci][0], co[ci][1], co[ci][2], 220));
                else
                    xt.colorSnap(co[ci][0], co[ci][1], co[ci][2], 220);
                String str = xt.plnames[i_204_];
                int f = 14;
                do
                {
                    if(f <= 0)
                        break;
                    rd.setFont(new Font("Arial", 1, f));
                    if(rd.getFontMetrics().stringWidth(str) < 72)
                        break;
                    f--;
                } while(true);
                rd.drawString(str, 326, 24);
                rd.setFont(new Font("Arial", 0, 11));
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(250, 250, 250, 220));
                else
                    xt.colorSnap(250, 250, 250, 220);
                rd.drawString(xt.cd.names[xt.sc[i_204_]], 326, 40);
                rd.setFont(new Font("Arial", 1, 11));
                Shape tmp = rd.getClip();
                Area clip = new Area(new java.awt.geom.Rectangle2D.Float(0.0F, 0.0F, 800F, 450F));
                Area elipse = new Area(new java.awt.geom.Ellipse2D.Float(421F, 15F, 36F, 13F));
                clip.subtract(elipse);
                rd.setClip(clip);
                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(50, 204, 255, 150));
                    else
                        xt.colorSnap(50, 204, 255, 150);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(220, 220, 0, 150));
                else
                    xt.colorSnap(220, 220, 0, 150);
                for(int i = 0; i < 17; i++)
                    rd.fillArc(404, 12, 70, 25, -185 + i * 21, 14);

                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(50, 204, 255));
                    else
                        xt.colorSnap(50, 204, 255);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(220, 220, 0));
                else
                    xt.colorSnap(220, 220, 0);
                int t1 = (int)(((float)i_202_ / 360F) * 16F);
                int t2 = t1 != 0 ? t1 - 1 : 16;
                int t3 = t1 != 16 ? t1 + 1 : 0;
                rd.fillArc(404, 12, 70, 25, -100 + t1 * 21, 14);
                rd.fillArc(404, 12, 70, 25, -100 + t2 * 21, 14);
                rd.fillArc(404, 12, 70, 25, -100 + t3 * 21, 14);
                rd.setClip(tmp);
            }
            if(Madness.arrowon == 4)
            {
                xt.colorSnap(50, 50, 50, 220);
                rd.fillPolygon(new int[] {
                    320, 340, 460, 479
                }, new int[] {
                    -1, 30, 30, -1
                }, 4);
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(250, 250, 250));
                else
                    xt.colorSnap(250, 250, 250);
                String str = xt.plnames[i_204_];
                rd.setFont(new Font("Arial", 1, 12));
                rd.drawString(str, 400 - rd.getFontMetrics().stringWidth(str) / 2, 13);
                rd.setFont(new Font("Arial", 0, 10));
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(220, 220, 220));
                else
                    xt.colorSnap(220, 220, 220);
                rd.drawString(xt.cd.names[xt.sc[i_204_]], 400 - rd.getFontMetrics().stringWidth(xt.cd.names[xt.sc[i_204_]]) / 2, 24);
                Polygon pol = new Polygon();
                int px = 400;
                int py = 51;
                int pox = px - (int)(xt.m.sin(i_202_ - 180) * 19F);
                int poy = py - (int)(xt.m.cos(i_202_ - 180) * 19F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ + 90) * 16F);
                poy = py - (int)(xt.m.cos(i_202_ + 90) * 16F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ + 90) * 5F);
                poy = py - (int)(xt.m.cos(i_202_ + 90) * 5F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ + 24) * 20F);
                poy = py - (int)(xt.m.cos(i_202_ + 24) * 20F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ - 24) * 20F);
                poy = py - (int)(xt.m.cos(i_202_ - 24) * 20F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ - 90) * 5F);
                poy = py - (int)(xt.m.cos(i_202_ - 90) * 5F);
                pol.addPoint(pox, poy);
                pox = px - (int)(xt.m.sin(i_202_ - 90) * 16F);
                poy = py - (int)(xt.m.cos(i_202_ - 90) * 16F);
                pol.addPoint(pox, poy);
                xt.colorSnap(50, 50, 50, 220);
                rd.translate(0, 5);
                rd.fillPolygon(pol);
                rd.translate(0, -5);
                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(50, 204, 255));
                    else
                        xt.colorSnap(50, 204, 255);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(80, 230, 30));
                else
                    xt.colorSnap(80, 230, 30);
                rd.fillPolygon(pol);
                if(arrace)
                {
                    if(xt.m.darksky || xt.m.lightson)
                        rd.setColor(new Color(0, 154, 205, 220));
                    else
                        xt.colorSnap(0, 154, 205, 220);
                } else
                if(xt.m.darksky || xt.m.lightson)
                    rd.setColor(new Color(50, 150, 20));
                else
                    xt.colorSnap(50, 150, 20);
                Stroke tmp = rd.getStroke();
                rd.setStroke(new BasicStroke(2.0F));
                rd.drawPolygon(pol);
                rd.setStroke(tmp);
                rd.setFont(new Font("Arial", 1, 11));
                xt.ftm = rd.getFontMetrics();
            }
            rd.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            rd.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        }
    }

    private static Area getBFpow()
    {
        if(BF_pow == null)
        {
            Area elipse = new Area(new java.awt.geom.Ellipse2D.Float(597F, 5F, 70F, 70F));
            elipse.add(new Area(new java.awt.geom.Rectangle2D.Float(597F, 40F, 70F, 17F)));
            elipse.subtract(new Area(new java.awt.geom.Rectangle2D.Float(597F, 56F, 70F, 20F)));
            elipse.add(new Area(new java.awt.geom.RoundRectangle2D.Float(690F, 6F, 94F, 50F, 15F, 15F)));
            elipse.add(new Area(new java.awt.geom.Arc2D.Float(643F, 6F, 100F, 100F, 0.0F, 180F, 1)));
            elipse.subtract(new Area(new java.awt.geom.Ellipse2D.Float(604F, 12F, 56F, 56F)));
            elipse.add(new Area(new java.awt.geom.Ellipse2D.Float(619F, 27F, 26F, 26F)));
            elipse.add(new Area(new Polygon(new int[] {
                597, 631, 632, 666
            }, new int[] {
                56, 39, 39, 56
            }, 4)));
            elipse.subtract(new Area(new java.awt.geom.Rectangle2D.Float(597F, 56F, 70F, 20F)));
            BF_pow = elipse;
        }
        return BF_pow;
    }

    static int modc = 150;
    static float modp = 1.0F;
    static int speedocnt = 0;
    static int degreecnt = -80;
    static int co[][] = {
        {
            50, 204, 255
        }, {
            151, 218, 241
        }, {
            138, 181, 71
        }, {
            255, 224, 50
        }, {
            234, 155, 31
        }, {
            255, 10, 0
        }, {
            220, 10, 250
        }, {
            250, 180, 180
        }, {
            250, 250, 250
        }
    };
    static int ci = 0;
    static DecimalFormat dc = new DecimalFormat("##0.00");
    static DecimalFormat dp = new DecimalFormat("00");
    static DecimalFormat dt = new DecimalFormat("000");
    static int groove = 0;
    static int sgroove = 0;
    static int sshake = 0;
    static int sprevdam = 0;
    private static Area BF_pow;

}
