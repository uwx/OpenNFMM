// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Globe.java

import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.*;
import java.net.*;
import java.util.Calendar;

public class Globe
    implements Runnable
{

    public Globe(Graphics2D graphics2d, xtGraphics var_xtGraphics, Medium medium, Login login, CarDefine cardefine, CheckPoints checkpoints, ContO contos[], 
            ContO contos_0[], GameSparker gamesparker)
    {
        domon = false;
        fase = 0;
        open = 0;
        upo = false;
        tab = 3;
        onp = false;
        ptab = 0;
        spos = 0;
        lspos = 0;
        mscro = 825;
        spos2 = 0;
        lspos2 = 0;
        mscro2 = 825;
        spos3 = 0;
        lspos3 = 0;
        mscro3 = 825;
        spos4 = 208;
        lspos4 = 0;
        mscro4 = 825;
        spos5 = 0;
        lspos5 = 0;
        mscro5 = 825;
        overit = 0;
        flk = 0;
        flko = 0;
        flg = false;
        curs = 0;
        waitlink = 0;
        addstage = 0;
        darker = false;
        npo = -1;
        pname = new String[900];
        proom = new int[900];
        pserver = new int[900];
        roomf = new int[3][5];
        npf = -1;
        fname = new String[900];
        cnfname = new String[10];
        ncnf = 0;
        freq = 0;
        sfreq = 0;
        freqname = "";
        sfreqname = "";
        cntf = 0;
        cnames = new String[21];
        sentn = new String[21];
        ctime = new String[21];
        nctime = new long[21];
        updatec = -1;
        proname = "";
        loadedp = false;
        edit = 0;
        upload = 0;
        perc = 0;
        playt = 0;
        uploadt = 0;
        filename = "";
        msg = "";
        trackname = "";
        refresh = false;
        logol = false;
        avatarl = false;
        sentchange = 0;
        badlang = false;
        aboutxt = new String[3];
        nab = 0;
        racing = 50;
        wasting = 150;
        themesong = "";
        sentance = "";
        trackvol = 0;
        comesoon = 0;
        proclan = "";
        nlg = 0;
        logos = new String[200];
        logon = new boolean[200];
        logoi = new Image[200];
        loadmsgs = -1;
        hasmsgs = "";
        lastsub = "";
        nm = 0;
        mname = new String[200];
        mconvo = new String[200];
        msub = new String[200];
        mtyp = new int[200];
        mtime = new String[200];
        mctime = new long[200];
        openc = 0;
        opy = 0;
        addopy = 0;
        oph = 0;
        itemsel = 0;
        loaditem = 0;
        mline = new String[1000];
        mlinetyp = new int[1000];
        mctimes = new long[1000];
        mtimes = new String[1000];
        nml = 0;
        readmsg = 0;
        opname = "";
        blockname = "";
        unblockname = "";
        sendmsg = 0;
        itab = 0;
        litab = -1;
        cadmin = 0;
        cmline = new String[1000];
        cmlinetyp = new int[1000];
        cmctimes = new long[1000];
        cmtimes = new String[1000];
        cnml = 0;
        readclan = 0;
        sendcmsg = 0;
        loadinter = -1;
        ni = 0;
        iclan = new String[200];
        iconvo = new String[200];
        isub = new String[200];
        icheck = new String[200];
        itime = new String[200];
        ictime = new long[200];
        istat = new String[200];
        itcar = new String[200];
        igcar = new String[200];
        iwarn = new String[200];
        openi = 0;
        readint = 0;
        intclan = "";
        lastint = "";
        dispi = 0;
        dwarn = "";
        dtcar = "";
        dgcar = "";
        nil = 0;
        iline = new String[1000];
        ilinetyp = new int[1000];
        ictimes = new long[1000];
        itimes = new String[1000];
        intsel = 0;
        isel = 0;
        ifas = 0;
        leader = -1;
        sendint = 0;
        inishsel = false;
        redif = false;
        imsg = "";
        wag = 0;
        iflk = 0;
        itake = "";
        igive = "";
        viewcar = "";
        warnum = "";
        sendwarnum = false;
        wstages = new String[5];
        wlaps = new int[5];
        wcars = new int[5];
        wclass = new int[5];
        wfix = new int[5];
        nvgames1 = 0;
        nvgames2 = 0;
        viewgame1 = 0;
        viewgame2 = 0;
        viewwar1 = "";
        viewwar2 = "";
        xclan = "";
        sendwar = "";
        ichlng = false;
        vwstages1 = new String[10];
        vwlaps1 = new int[10];
        vwcars1 = new int[10];
        vwclass1 = new int[10];
        vwfix1 = new int[10];
        vwstages2 = new String[10];
        vwlaps2 = new int[10];
        vwcars2 = new int[10];
        vwclass2 = new int[10];
        vwfix2 = new int[10];
        vwinner = new String[10];
        vwscorex = 0;
        vwscorei = 0;
        intclanbg = null;
        intclanlo = "";
        intclanbgloaded = false;
        myclanbg = null;
        loadedmyclanbg = 0;
        cfase = 0;
        notclan = false;
        claname = "EvilOnes";
        loadedc = false;
        clanbgl = false;
        editc = 0;
        em = 0;
        ctab = 0;
        nmb = 0;
        lccnam = "";
        member = new String[20];
        mlevel = new int[20];
        mrank = new String[20];
        nrmb = 0;
        rmember = new String[100];
        showreqs = false;
        blocknote = 0;
        blockb = 0;
        loadedcm = false;
        ncln = 0;
        clname = new String[20];
        smsg = "";
        sltit = "";
        attachetoclan = false;
        loadedlink = false;
        loadedcars = -1;
        loadedcar = 0;
        ltit = "";
        ldes = "";
        lurl = "";
        forcsel = false;
        selcar = "";
        selstage = "";
        perry = "";
        mrot = 0;
        loadedstages = -1;
        loadedstage = 0;
        mouson = -1;
        nclns = 0;
        clanlo = new String[20];
        ntab = 0;
        loadednews = 0;
        spos6 = 0;
        lspos6 = 0;
        nwclan = new String[5];
        nlclan = new String[5];
        nwinob = new String[5];
        nwinp = new int[5];
        nlosp = new int[5];
        nwtime = new String[5];
        il = 0;
        nttime = new String[300];
        text = new String[300];
        nln = new int[300];
        link = new String[300][4][2];
        maxclans = 1000;
        loadwstat = 0;
        ncc = 0;
        champ = -1;
        leadsby = 0;
        eng = -1;
        engo = 0;
        frkl = false;
        underc = 0;
        bgf = 0.0F;
        bgup = false;
        flkn = 0;
        cur = 0;
        sdist = 0;
        scro = 0;
        donewc = false;
        dosrch = false;
        dorank = false;
        doweb1 = false;
        doweb2 = false;
        dommsg = false;
        donemsg = false;
        doi = 0;
        ados = 0;
        lspos6w = 0;
        ntime = 0L;
        loadwbgames = 0;
        warb = 0;
        gameturn = -1;
        warbnum = "";
        vclan = "";
        wbstages = new String[10];
        wbstage = new int[10];
        wblaps = new int[10];
        wbcars = new int[10];
        wbclass = new int[10];
        wbfix = new int[10];
        gameturndisp = "";
        ascore = 0;
        vscore = 0;
        lwbwinner = "";
        canredo = false;
        cnotif = 0;
        rd = graphics2d;
        xt = var_xtGraphics;
        m = medium;
        gs = gamesparker;
        lg = login;
        cd = cardefine;
        cp = checkpoints;
        bco = contos;
        co = contos_0;
        gImage = gs.createImage(560, 300);
        rdo = (Graphics2D)gImage.getGraphics();
        rdo.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        for(int i = 0; i < 21; i++)
        {
            ctime[i] = "";
            cnames[i] = "";
            sentn[i] = "";
            nctime[i] = 0L;
        }

        for(int i = 0; i < 900; i++)
            pname[i] = "";

        for(int i = 0; i < 200; i++)
        {
            logos[i] = "";
            logon[i] = false;
        }

        mt = new MediaTracker(gs);
        gs.sendtyp.setBackground(colorb2k(false, 210, 210, 210));
        gs.sendtyp.setForeground(new Color(0, 0, 0));
        gs.sendtyp.removeAll();
        gs.sendtyp.add(rd, "Write a Message");
        gs.sendtyp.add(rd, "Share a Custom Car");
        gs.sendtyp.add(rd, "Share a Custom Stage");
        gs.sendtyp.add(rd, "Send a Clan Invitation");
        gs.sendtyp.add(rd, "Share a Relative Date");
        gs.senditem.setBackground(colorb2k(false, 230, 230, 230));
        gs.senditem.setForeground(new Color(0, 0, 0));
        gs.datat.setBackground(colorb2k(false, 230, 230, 230));
        gs.datat.setForeground(new Color(0, 0, 0));
        gs.mmsg.setBackground(colorb2k(false, 240, 240, 240));
        gs.mmsg.setForeground(new Color(0, 0, 0));
        gs.clanlev.setBackground(colorb2k(false, 230, 230, 230));
        gs.clanlev.setForeground(new Color(0, 0, 0));
        gs.clcars.setBackground(new Color(0, 0, 0));
        gs.clcars.setForeground(new Color(255, 255, 255));
        gs.ilaps.setBackground(colorb2k(false, 220, 220, 220));
        gs.ilaps.setForeground(new Color(0, 0, 0));
        gs.icars.setBackground(colorb2k(false, 220, 220, 220));
        gs.icars.setForeground(new Color(0, 0, 0));
        if(!xt.clan.equals(""))
            itab = 2;
    }

    public void evalNotif(int newNotif)
    {
        if(newNotif != cnotif)
        {
            if(newNotif > cnotif)
                notif.play();
            cnotif = newNotif;
        }
    }

    public void dome(int i, int i_1, int i_2, boolean bool, Control control)
    {
        boolean bool_3 = false;
        boolean bool_4 = false;
        dommsg = false;
        dorank = false;
        donewc = false;
        dosrch = false;
        doweb1 = false;
        doweb2 = false;
        evalNotif(lg.nmsgs + lg.nfreq + lg.nconf + (lg.clanapv.isEmpty() ? 0 : 1) + lg.ncreq);
        if(open == 0)
        {
            boolean bool_5 = false;
            if(i_2 > 425 && i_2 < 450 && i_1 < 568 && i_1 > 232)
                bool_5 = true;
            if(cnotif == 0 || !bool_5)
            {
                int is[] = {
                    0, 9, 232, 250, 550, 568, 791, 800
                };
                int is_6[] = {
                    452, 443, 443, 425, 425, 443, 443, 452
                };
                if(bool_5)
                    rd.setColor(color2k(255, 255, 255));
                else
                    rd.setColor(new Color(207, 177, 110));
                rd.fillPolygon(is, is_6, 8);
                rd.setColor(new Color(103, 88, 55));
                rd.drawPolygon(is, is_6, 8);
                rd.drawImage(xt.dome, 311, 430, null);
                if(cnotif > 0)
                {
                    rd.setColor(new Color(230, 20, 20));
                    rd.fillOval(545, 415, 20, 20);
                    rd.setColor(new Color(250, 250, 250));
                    rd.setFont(new Font("Arial", 1, 12));
                    String str = String.valueOf(cnotif);
                    rd.drawString(str, 555 - rd.getFontMetrics().stringWidth(str) / 2, 430);
                }
            } else
            {
                StringBuilder builder = (new StringBuilder()).append("You have ");
                if(!lg.clanapv.equals(""))
                {
                    builder.append("been approved for a clan membership");
                    if(lg.nmsgs != 0 || lg.nfreq != 0 || lg.nconf != 0)
                        builder.append("! + You have ").toString();
                }
                if(lg.ncreq != 0)
                {
                    builder.append(lg.ncreq).append(" clan membership requests");
                    if(lg.nmsgs != 0 || lg.nfreq != 0 || lg.nconf != 0)
                        builder.append("! + You have ");
                }
                if(lg.nmsgs != 0)
                {
                    builder.append("new interactions");
                    if(lg.fclan > 0 && lg.fplayer > 0)
                    {
                        String string_7 = "";
                        String string_8 = "";
                        if(lg.fplayer > 1)
                            string_7 = "s";
                        if(lg.fclan > 1)
                            string_8 = "s";
                        builder.append(" from ").append(lg.fplayer).append(" player").append(string_7).append(" & ").append(lg.fclan).append(" clan").append(string_8);
                    } else
                    {
                        if(lg.fclan == 1)
                            builder.append(" from 1 clan");
                        if(lg.fclan > 1)
                            builder.append(" from ").append(lg.fclan).append(" clans");
                        if(lg.fplayer == 1)
                            builder.append(" from 1 player");
                        if(lg.fplayer > 1)
                            builder.append(" from ").append(lg.fplayer).append(" players");
                        if(lg.fclan == 0 && lg.fplayer == 0)
                            builder.append(" from your clan's discussion");
                    }
                    if(lg.nfreq != 0 && lg.nconf != 0)
                    {
                        builder.append(", ");
                    } else
                    {
                        if(lg.nfreq != 0)
                            builder.append(" and ");
                        if(lg.nconf != 0)
                            builder.append(" and ");
                    }
                }
                if(lg.nfreq != 0)
                {
                    builder.append(lg.nfreq).append(" friend request").toString();
                    if(lg.nfreq > 1)
                        builder.append("s").toString();
                    if(lg.nconf != 0)
                        builder.append(" and ").toString();
                }
                if(lg.nconf != 0)
                {
                    builder.append(lg.nconf).append(" friend confirmation");
                    if(lg.nconf > 1)
                        builder.append("s");
                }
                String string = builder.append("!").toString();
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                int i_9 = 0;
                if(ftm.stringWidth(string) > 280)
                    i_9 = (ftm.stringWidth(string) - 280) / 2;
                if(i_2 > 425 && i_2 < 450 && i_1 < 568 + i_9 && i_1 > 232 - i_9)
                    bool_5 = true;
                int is[] = {
                    0, 9, 232 - i_9, 250 - i_9, 550 + i_9, 568 + i_9, 791, 800
                };
                int is_10[] = {
                    452, 443, 443, 425, 425, 443, 443, 452
                };
                if(bool_5)
                    rd.setColor(color2k(255, 255, 255));
                else
                    rd.setColor(new Color(207, 177, 110));
                rd.fillPolygon(is, is_10, 8);
                rd.setColor(new Color(103, 88, 55));
                rd.drawPolygon(is, is_10, 8);
                if(flkn % 3 == 0)
                    rd.setColor(new Color(60, 30, 0));
                else
                    rd.setColor(new Color(0, 100, 0));
                rd.drawString(string, 400 - ftm.stringWidth(string) / 2, 442);
                if(flkn < 33)
                    flkn++;
            }
            if(bool_5 && bool && i < 2)
            {
                open = 2;
                upo = true;
                if(lg.nmsgs != 0)
                {
                    tab = 2;
                    if(lg.fplayer > 0)
                        itab = 0;
                    else
                    if(lg.fclan > 0)
                        itab = 1;
                    else
                        itab = 2;
                    litab = -1;
                }
                if(!lg.clanapv.equals(""))
                {
                    claname = lg.clanapv;
                    loadedc = false;
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    tab = 3;
                    ctab = 0;
                }
                if(lg.ncreq != 0)
                {
                    claname = xt.clan;
                    loadedc = false;
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    tab = 3;
                    ctab = 0;
                }
                if(lg.nfreq != 0 || lg.nconf != 0)
                    ptab = 1;
            }
            if(xt.onviewpro)
            {
                proname = cd.viewname;
                open = 2;
                upo = true;
                tab = 1;
                xt.onviewpro = false;
            }
        } else
        if(flkn != 0)
            flkn = 0;
        if(open >= 2 && open < 452)
        {
            int is[] = {
                0, 0, 9, 232, 250, 550, 568, 791, 800, 800
            };
            int is_11[] = {
                902 - open, 452 - open, 443 - open, 443 - open, 425 - open, 425 - open, 443 - open, 443 - open, 452 - open, 902 - open
            };
            float f = ((float)open - 2.0F) / 450F;
            int i_12 = (int)(255F * (1.0F - f) + 216F * f);
            if(i_12 > 255)
                i_12 = 255;
            if(i_12 < 0)
                i_12 = 0;
            int i_13 = (int)(243F * (1.0F - f) + 179F * f);
            if(i_13 > 255)
                i_13 = 255;
            if(i_13 < 0)
                i_13 = 0;
            int i_14 = (int)(179F * (1.0F - f) + 100F * f);
            if(i_14 > 255)
                i_14 = 255;
            if(i_14 < 0)
                i_14 = 0;
            rd.setColor(new Color(i_12, i_13, i_14));
            rd.fillPolygon(is, is_11, 10);
            rd.drawImage(xt.dome, 311, 430 - open, null);
            if(upo)
                open += 45;
            else
                open -= 45;
            gs.hidefields();
            if(open == 452)
            {
                gs.setCursor(new Cursor(0));
                npo = -1;
                updatec = -1;
                domon = true;
                connector = new Thread(this);
                connector.start();
            }
        }
        if(open == 452)
        {
            if(xt.warning == 210)
                xt.warning = 0;
            cur = 0;
            int i_15 = (int)(255F * bgf + 191F * (1.0F - bgf));
            int i_16 = (int)(176F * bgf + 184F * (1.0F - bgf));
            int i_17 = (int)(67F * bgf + 124F * (1.0F - bgf));
            if(!bgup)
            {
                bgf += 0.02F;
                if(bgf > 0.9F)
                {
                    bgf = 0.9F;
                    bgup = true;
                }
            } else
            {
                bgf -= 0.02F;
                if(bgf < 0.2F)
                {
                    bgf = 0.2F;
                    bgup = false;
                }
            }
            rd.setColor(new Color(i_15, i_16, i_17));
            rd.fillRect(0, 0, 800, 450);
            rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
            rd.drawImage(xt.bgmain, bgx[0], 0, null);
            rd.drawImage(xt.bgmain, bgx[1], 0, null);
            rd.drawImage(xt.bgmain, bgx[2], 0, null);
            rd.drawImage(xt.bgmain, bgx[0], 400, null);
            rd.drawImage(xt.bgmain, bgx[1], 400, null);
            rd.drawImage(xt.bgmain, bgx[2], 400, null);
            rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
            rd.drawImage(xt.bggo, 0, 0, null);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            for(int i_18 = 0; i_18 < 3; i_18++)
            {
                bgx[i_18] -= 5;
                if(bgx[i_18] <= -670)
                    bgx[i_18] = 1340;
            }

            if(drawbutton(xt.exit, 755, 17, i_1, i_2, bool) || i >= 2)
            {
                open = 450;
                upo = false;
                domon = false;
                onexit();
            }
            sdist = 0;
            scro = 0;
            if(domon)
            {
                if(tab == 0)
                {
                    rd.setColor(color2k(230, 230, 230));
                    rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                    if(updatec != -1)
                    {
                        String strings[] = new String[42];
                        String strings_19[] = new String[42];
                        String strings_20[] = new String[42];
                        boolean bools[] = new boolean[42];
                        for(int i_21 = 0; i_21 < 42; i_21++)
                        {
                            strings[i_21] = "";
                            strings_19[i_21] = "";
                            strings_20[i_21] = "";
                            bools[i_21] = false;
                        }

                        int i_22 = 0;
                        rd.setFont(new Font("Tahoma", 0, 11));
                        ftm = rd.getFontMetrics();
                        for(int i_23 = 0; i_23 < 21; i_23++)
                        {
                            strings[i_22] = "";
                            strings_19[i_22] = cnames[i_23];
                            strings_20[i_22] = ctime[i_23];
                            int i_24 = 0;
                            int i_25 = 0;
                            int i_26 = 0;
                            int i_27 = 0;
                            int i_28 = 0;
                            for(; i_24 < sentn[i_23].length(); i_24++)
                            {
                                String string = (new StringBuilder()).append("").append(sentn[i_23].charAt(i_24)).toString();
                                if(string.equals(" "))
                                {
                                    i_25 = i_26;
                                    i_27 = i_24;
                                    i_28++;
                                } else
                                {
                                    i_28 = 0;
                                }
                                if(i_28 > 1)
                                    continue;
                                StringBuilder stringbuilder = new StringBuilder();
                                String strings_29[] = strings;
                                int i_30 = i_22;
                                strings_29[i_30] = stringbuilder.append(strings_29[i_30]).append(string).toString();
                                i_26++;
                                if(ftm.stringWidth(strings[i_22]) <= 469)
                                    continue;
                                if(i_25 != 0)
                                {
                                    strings[i_22] = strings[i_22].substring(0, i_25);
                                    if(i_22 == 41)
                                    {
                                        for(int i_31 = 0; i_31 < 41; i_31++)
                                        {
                                            strings[i_31] = strings[i_31 + 1];
                                            strings_19[i_31] = strings_19[i_31 + 1];
                                            strings_20[i_31] = strings_20[i_31 + 1];
                                            bools[i_31] = bools[i_31 + 1];
                                        }

                                        strings[i_22] = "";
                                        bools[i_22] = true;
                                    } else
                                    {
                                        i_22++;
                                        strings_19[i_22] = cnames[i_23];
                                        strings_20[i_22] = ctime[i_23];
                                    }
                                    i_24 = i_27;
                                    i_26 = 0;
                                    i_25 = 0;
                                } else
                                {
                                    strings[i_22] = "";
                                    i_26 = 0;
                                }
                            }

                            if(i_22 == 41 && i_23 != 20)
                            {
                                for(int i_32 = 0; i_32 < 41; i_32++)
                                {
                                    strings[i_32] = strings[i_32 + 1];
                                    strings_19[i_32] = strings_19[i_32 + 1];
                                    strings_20[i_32] = strings_20[i_32 + 1];
                                    bools[i_32] = bools[i_32 + 1];
                                }

                            } else
                            {
                                i_22++;
                            }
                        }

                        String string = "";
                        int i_33 = i_22;
                        for(int i_34 = 0; i_34 < i_22; i_34++)
                        {
                            if(string.equals(strings_19[i_34]))
                                continue;
                            if(i_34 != 0)
                                i_33++;
                            string = strings_19[i_34];
                        }

                        sdist = (int)(((float)i_33 - 21.5F) * 15F);
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos2 / 275F) * (float)sdist);
                        i_33 = 0;
                        string = "";
                        for(int i_35 = 0; i_35 <= i_22; i_35++)
                            if(i_35 != i_22)
                            {
                                if(!string.equals(strings_19[i_35]))
                                {
                                    if(i_35 != 0)
                                    {
                                        if(i_33 * 15 - scro > -20 && i_33 * 15 - scro < 345)
                                        {
                                            rd.setFont(new Font("Tahoma", 0, 11));
                                            rd.setColor(color2k(125, 125, 125));
                                            rd.drawString(strings_20[i_35 - 1], 297, (82 + i_33 * 15) - scro);
                                        }
                                        i_33++;
                                    }
                                    if(i_33 * 15 - scro > -20 && i_33 * 15 - scro < 345)
                                    {
                                        rd.setFont(new Font("Tahoma", 1, 11));
                                        ftm = rd.getFontMetrics();
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.drawString((new StringBuilder()).append(strings_19[i_35]).append(":").toString(), 292 - ftm.stringWidth((new StringBuilder()).append(strings_19[i_35]).append(":").toString()), (82 + i_33 * 15) - scro);
                                    }
                                    string = strings_19[i_35];
                                }
                                if(bools[i_35] && i_35 == 0 && strings[i_35].indexOf(" ") != -1)
                                    strings[i_35] = (new StringBuilder()).append("...").append(strings[i_35].substring(strings[i_35].indexOf(" "), strings[i_35].length())).append("").toString();
                                if(i_33 * 15 - scro > -20 && i_33 * 15 - scro < 345)
                                {
                                    rd.setFont(new Font("Tahoma", 0, 11));
                                    rd.setColor(new Color(0, 0, 0));
                                    if(Madness.isURL(strings[i_35]))
                                    {
                                        Color tmp = rd.getColor();
                                        rd.setColor(color2k(80, 80, 80));
                                        rd.drawString(strings[i_35], 297, (82 + i_33 * 15) - scro);
                                        rd.drawLine(296, (84 + i_33 * 15) - scro, 297 + rd.getFontMetrics().stringWidth(strings[i_35]), (84 + i_33 * 15) - scro);
                                        gs.customlink(strings[i_35], 297, (82 + i_33 * 15) - scro, rd.getFontMetrics().stringWidth(strings[i_35]));
                                        rd.setColor(tmp);
                                    } else
                                    {
                                        rd.drawString(strings[i_35], 297, (82 + i_33 * 15) - scro);
                                    }
                                }
                                i_33++;
                            } else
                            if(i_33 * 15 - scro > -20 && i_33 * 15 - scro < 345)
                            {
                                rd.setFont(new Font("Tahoma", 0, 11));
                                rd.setColor(color2k(125, 125, 125));
                                rd.drawString(strings_20[i_35 - 1], 297, (82 + i_33 * 15) - scro);
                            }

                    } else
                    {
                        sdist = 0;
                        scro = 0;
                        spos2 = 275;
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Loading chat...", 498 - ftm.stringWidth("Loading chat...") / 2, 220);
                    }
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 46, 582, 25);
                    rd.setFont(new Font("Arial", 1, 12));
                    rd.setColor(color2k(40, 40, 40));
                    rd.drawString("Global Chat", 213, 62);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 68, 770, 68);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 411, 582, 28);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 413, 770, 413);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(772, 88, 17, 306);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(203, 46, 4, 393);
                    bool_3 = true;
                    if((stringbutton(rd, "Send Message", 731, 430, 3, i_1, i_2, bool, 0, 0) || control.enter) && !gs.cmsg.getText().equals("Type here...") && !gs.cmsg.getText().equals("") && xt.acexp != -3)
                    {
                        String string = xt.passRem(gs.cmsg.getText().replace('|', ':'));
                        if(!xt.msgcheck(string) && updatec > -12)
                        {
                            for(int i_36 = 0; i_36 < 20; i_36++)
                            {
                                sentn[i_36] = sentn[i_36 + 1];
                                cnames[i_36] = cnames[i_36 + 1];
                                ctime[i_36] = ctime[i_36 + 1];
                            }

                            sentn[20] = string;
                            cnames[20] = xt.nickname;
                            ctime[20] = "- just now";
                            if(updatec > -11)
                                updatec = -11;
                            else
                                updatec--;
                            spos2 = 275;
                        } else
                        {
                            xt.warning++;
                        }
                        gs.cmsg.setText("");
                        control.enter = false;
                    }
                    if(mscro2 == 831 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(772, 71, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(772, 71, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asu, 777, 77, null);
                    if(mscro2 == 832 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(772, 394, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(772, 394, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asd, 777, 401, null);
                    if(sdist != 0)
                    {
                        if(lspos2 != spos2)
                        {
                            rd.setColor(color2k(215, 215, 215));
                            rd.fillRect(772, 88 + spos2, 17, 31);
                        } else
                        {
                            if(mscro2 == 831)
                                rd.setColor(color2k(215, 215, 215));
                            rd.fill3DRect(772, 88 + spos2, 17, 31, true);
                        }
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(777, 101 + spos2, 783, 101 + spos2);
                        rd.drawLine(777, 103 + spos2, 783, 103 + spos2);
                        rd.drawLine(777, 105 + spos2, 783, 105 + spos2);
                        if(mscro2 > 800 && lspos2 != spos2)
                            lspos2 = spos2;
                        if(bool)
                        {
                            if(mscro2 == 825 && i_1 > 772 && i_1 < 789 && i_2 > 88 + spos2 && i_2 < spos2 + 119)
                                mscro2 = i_2 - spos2;
                            if(mscro2 == 825 && i_1 > 770 && i_1 < 791 && i_2 > 69 && i_2 < 90)
                                mscro2 = 831;
                            if(mscro2 == 825 && i_1 > 770 && i_1 < 791 && i_2 > 392 && i_2 < 413)
                                mscro2 = 832;
                            if(mscro2 == 825 && i_1 > 772 && i_1 < 789 && i_2 > 88 && i_2 < 394)
                            {
                                mscro2 = 103;
                                spos2 = i_2 - mscro2;
                            }
                            int i_37 = 2670 / sdist;
                            if(i_37 < 1)
                                i_37 = 1;
                            if(mscro2 == 831)
                            {
                                spos2 -= i_37;
                                if(spos2 > 275)
                                    spos2 = 275;
                                if(spos2 < 0)
                                    spos2 = 0;
                                lspos2 = spos2;
                            }
                            if(mscro2 == 832)
                            {
                                spos2 += i_37;
                                if(spos2 > 275)
                                    spos2 = 275;
                                if(spos2 < 0)
                                    spos2 = 0;
                                lspos2 = spos2;
                            }
                            if(mscro2 < 800)
                            {
                                spos2 = i_2 - mscro2;
                                if(spos2 > 275)
                                    spos2 = 275;
                                if(spos2 < 0)
                                    spos2 = 0;
                            }
                            if(mscro2 == 825)
                                mscro2 = 925;
                        } else
                        if(mscro2 != 825)
                            mscro2 = 825;
                    }
                }
                if(tab == 1)
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                    rd.setColor(new Color(255, 255, 255));
                    rd.fillRoundRect(207, 45, 577, 394, 20, 20);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(207, 45, 577, 394, 20, 20);
                    if(!flg)
                        flk += 5;
                    else
                        flk -= 5;
                    if(flk >= 100)
                    {
                        flk = 100;
                        flg = true;
                    }
                    if(flk <= 60)
                    {
                        flk = 60;
                        flg = false;
                    }
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.setComposite(AlphaComposite.getInstance(3, (float)flk / 100F));
                    boolean bool_38 = false;
                    if(proname.equals(xt.nickname))
                    {
                        rd.drawString("Your Profile", 232, 67);
                        bool_38 = true;
                    } else
                    {
                        rd.drawString((new StringBuilder()).append("").append(proname).append("'s Profile").toString(), 232, 67);
                    }
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    if(loadedp)
                    {
                        if(!bool_38 && stringbutton(rd, "   My Profile   ", 715, 73, 1, i_1, i_2, bool, 0, 0))
                        {
                            proname = xt.nickname;
                            loadedp = false;
                            onexitpro();
                        }
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 0, 11));
                        ftm = rd.getFontMetrics();
                        if(logol)
                            drawl(rd, proname, 236, 101, true);
                        else
                            rd.drawString("No logo available", 296 - ftm.stringWidth("No logo available") / 2, 121);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        String string = "Logo";
                        if(i_1 > 232 && i_1 < 359 && i_2 > 84 && i_2 < 134 && edit == 0 && bool_38)
                        {
                            string = "Edit Logo";
                            rd.drawLine(238, 98, 238 + ftm.stringWidth(string), 98);
                            if(i_1 > 238 && i_1 < 238 + ftm.stringWidth(string) && i_2 > 85 && i_2 < 100)
                            {
                                cur = 12;
                                if(bool)
                                    if(xt.logged)
                                    {
                                        edit = 1;
                                        msg = "Edit your Nickname's logo";
                                        flko = 0;
                                    } else
                                    {
                                        edit = 5;
                                    }
                            }
                        }
                        rd.drawString(string, 238, 97);
                        rd.drawLine(232, 84, 232, 134);
                        rd.drawLine(232, 84, 238 + ftm.stringWidth(string) + 2, 84);
                        rd.drawLine(238 + ftm.stringWidth(string) + 2, 84, 238 + ftm.stringWidth(string) + 15, 97);
                        rd.drawLine(238 + ftm.stringWidth(string) + 15, 97, 359, 97);
                        rd.drawLine(359, 97, 359, 134);
                        rd.drawLine(232, 134, 359, 134);
                        if(bool_38 && !xt.clan.equals(proclan))
                            proclan = xt.clan;
                        if(!proclan.equals(""))
                        {
                            if(!drawl(rd, (new StringBuilder()).append("#").append(proclan).append("#").toString(), 406, 101, true))
                            {
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("").append(proclan).append("").toString(), 581 - ftm.stringWidth((new StringBuilder()).append("").append(proclan).append("").toString()) / 2, 121);
                            }
                        } else
                        {
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(bool_38)
                            {
                                rd.drawString("You have not joined a clan yet!", 416, 121);
                                if(stringbutton(rd, "   Find a clan to join   ", 663, 121, 1, i_1, i_2, bool, 0, 0))
                                {
                                    tab = 3;
                                    cfase = 2;
                                    em = 1;
                                    msg = "Clan Search";
                                    smsg = "Listing clans with recent activity...";
                                    nclns = 0;
                                    spos5 = 0;
                                    lspos5 = 0;
                                    flko = 0;
                                }
                            } else
                            if(xt.clan.equals(""))
                            {
                                rd.drawString("Has not joined a clan yet", 581 - ftm.stringWidth("Has not joined a clan yet") / 2, 121);
                            } else
                            {
                                rd.drawString("Has not joined a clan yet", 430, 121);
                                if(stringbutton(rd, " Invite to join your clan ", 657, 121, 1, i_1, i_2, bool, 0, 0))
                                {
                                    tab = 2;
                                    itab = 0;
                                    litab = -1;
                                    openc = 10;
                                    if(!opname.equals(proname))
                                    {
                                        opname = proname;
                                        lastsub = "";
                                        readmsg = 1;
                                    }
                                    itemsel = 3;
                                    forcsel = true;
                                }
                            }
                        }
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        string = "Clan";
                        if(i_1 > 402 && i_1 < 759 && i_2 > 84 && i_2 < 134 && !proclan.equals("") && edit == 0)
                        {
                            string = (new StringBuilder()).append("Clan :  ").append(proclan).append("").toString();
                            rd.drawLine(408, 98, 408 + ftm.stringWidth(string), 98);
                            if(i_1 > 408 && i_1 < 408 + ftm.stringWidth(string) && i_2 > 85 && i_2 < 100 || i_1 > 406 && i_1 < 756 && i_2 > 101 && i_2 < 131)
                            {
                                cur = 12;
                                if(bool)
                                {
                                    if(!claname.equals(proclan))
                                    {
                                        claname = proclan;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    tab = 3;
                                    ctab = 0;
                                }
                            }
                        }
                        rd.drawString(string, 408, 97);
                        rd.drawLine(402, 84, 402, 134);
                        rd.drawLine(402, 84, 408 + ftm.stringWidth(string) + 2, 84);
                        rd.drawLine(408 + ftm.stringWidth(string) + 2, 84, 408 + ftm.stringWidth(string) + 15, 97);
                        rd.drawLine(408 + ftm.stringWidth(string) + 15, 97, 759, 97);
                        rd.drawLine(759, 97, 759, 134);
                        rd.drawLine(402, 134, 759, 134);
                        rd.setFont(new Font("Arial", 0, 11));
                        ftm = rd.getFontMetrics();
                        if(avatarl)
                            rd.drawImage(avatar, 236, 161, null);
                        else
                            rd.drawString("No avatar available", 336 - ftm.stringWidth("No avatar available") / 2, 255);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        string = "Avatar";
                        if(i_1 > 232 && i_1 < 439 && i_2 > 144 && i_2 < 364 && edit == 0 && bool_38)
                        {
                            string = "Edit Avatar";
                            rd.drawLine(238, 158, 238 + ftm.stringWidth(string), 158);
                            if(i_1 > 238 && i_1 < 238 + ftm.stringWidth(string) && i_2 > 145 && i_2 < 160)
                            {
                                cur = 12;
                                if(bool)
                                    if(xt.logged)
                                    {
                                        edit = 2;
                                        msg = "Edit your proflie avatar";
                                        flko = 0;
                                    } else
                                    {
                                        edit = 5;
                                    }
                            }
                        }
                        rd.drawString(string, 238, 157);
                        rd.drawLine(232, 144, 232, 364);
                        rd.drawLine(232, 144, 238 + ftm.stringWidth(string) + 2, 144);
                        rd.drawLine(238 + ftm.stringWidth(string) + 2, 144, 238 + ftm.stringWidth(string) + 15, 157);
                        rd.drawLine(238 + ftm.stringWidth(string) + 15, 157, 439, 157);
                        rd.drawLine(439, 157, 439, 364);
                        rd.drawLine(232, 364, 439, 364);
                        string = "About";
                        if(i_1 > 459 && i_1 < 759 && i_2 > 144 && i_2 < 364 && edit == 0 && bool_38)
                        {
                            string = "Edit About";
                            rd.drawLine(465, 158, 465 + ftm.stringWidth(string), 158);
                            if(i_1 > 465 && i_1 < 465 + ftm.stringWidth(string) && i_2 > 145 && i_2 < 160)
                            {
                                cur = 12;
                                if(bool)
                                    if(xt.logged)
                                    {
                                        edit = 3;
                                        msg = "";
                                        flko = 0;
                                        sentchange = 0;
                                        badlang = false;
                                    } else
                                    {
                                        edit = 5;
                                    }
                            }
                        }
                        rd.drawString(string, 465, 157);
                        rd.drawLine(459, 144, 459, 364);
                        rd.drawLine(459, 144, 465 + ftm.stringWidth(string) + 2, 144);
                        rd.drawLine(465 + ftm.stringWidth(string) + 2, 144, 465 + ftm.stringWidth(string) + 15, 157);
                        rd.drawLine(465 + ftm.stringWidth(string) + 15, 157, 759, 157);
                        rd.drawLine(759, 157, 759, 364);
                        rd.drawLine(459, 364, 759, 364);
                        if(nab != 0)
                        {
                            rd.setFont(new Font("Tahoma", 1, 11));
                            int i_39 = 200;
                            if(nab == 2)
                                i_39 = 192;
                            if(nab == 3)
                                i_39 = 185;
                            for(int i_40 = 0; i_40 < nab; i_40++)
                                rd.drawString(aboutxt[i_40], 469, i_39 + i_40 * 15);

                        } else
                        {
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.drawString("No description available", 609 - ftm.stringWidth("No description available") / 2, 200);
                        }
                        rd.drawLine(489, 230, 729, 230);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Racing", 532 - ftm.stringWidth("Racing") / 2, 253);
                        rd.drawString("VS", 532 - ftm.stringWidth("VS") / 2, 270);
                        rd.drawString("Wasting", 532 - ftm.stringWidth("Wasting") / 2, 287);
                        float f = racing;
                        float f_41 = wasting;
                        if(racing > 10 && racing > wasting)
                        {
                            f = 10F;
                            f_41 = (float)wasting / ((float)racing / 10F);
                        }
                        if(wasting > 10 && wasting >= racing)
                        {
                            f_41 = 10F;
                            f = (float)racing / ((float)wasting / 10F);
                        }
                        if(wasting > 10 && racing > 10 && wasting == racing)
                        {
                            f_41 = 10F;
                            f = 10F;
                        }
                        f *= 14F;
                        f_41 *= 14F;
                        for(int i_42 = 0; i_42 < 5; i_42++)
                        {
                            if(f != 0.0F)
                            {
                                rd.setColor(new Color(0, i_42 * 50, 255));
                                rd.drawLine(569, 245 + i_42, (int)(569F + f), 245 + i_42);
                                rd.drawLine(569, 254 - i_42, (int)(569F + f), 254 - i_42);
                            }
                            if(f_41 != 0.0F)
                            {
                                rd.setColor(new Color(255, i_42 * 50, 0));
                                rd.drawLine(569, 279 + i_42, (int)(569F + f_41), 279 + i_42);
                                rd.drawLine(569, 288 - i_42, (int)(569F + f_41), 288 - i_42);
                            }
                        }

                        rd.setColor(new Color(0, 0, 0));
                        rd.drawRect(569, 244, 140, 11);
                        rd.drawRect(569, 278, 140, 11);
                        rd.drawLine(489, 304, 729, 304);
                        if(!themesong.equals("") && trackvol != 0)
                        {
                            if(playt == 1)
                                rd.drawString("Loading theme song, please wait...", 609 - ftm.stringWidth("Loading theme song, please wait...") / 2, 340);
                            if(playt == 0 && stringbutton(rd, " Play Theme Song ", 609, 340, 1, i_1, i_2, bool, 0, 0) && edit == 0)
                                playt = 1;
                            if(playt == 2)
                            {
                                rd.drawString("Theme song playing...", 609 - ftm.stringWidth("Theme song playing...") / 2, 325);
                                if(stringbutton(rd, " Stop ", 609, 350, 2, i_1, i_2, bool, 0, 0))
                                {
                                    xt.strack.unload();
                                    playt = 0;
                                }
                            }
                        } else
                        {
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.drawString("No theme song available", 609 - ftm.stringWidth("No theme song available") / 2, 340);
                        }
                        if(!bool_38)
                        {
                            if(sfreq == 0)
                            {
                                rd.drawRect(232, 378, 527, 50);
                                boolean bool_43 = false;
                                int i_44 = 0;
                                do
                                {
                                    if(i_44 >= npf)
                                        break;
                                    if(proname.toLowerCase().equals(fname[i_44].toLowerCase()))
                                    {
                                        bool_43 = true;
                                        break;
                                    }
                                    i_44++;
                                } while(true);
                                if(bool_43)
                                {
                                    if(stringbutton(rd, "    Un-friend    ", 313, 408, 1, i_1, i_2, bool, 0, 0))
                                        sfreq = 4;
                                } else
                                if(stringbutton(rd, "   Add Friend   ", 313, 408, 1, i_1, i_2, bool, 0, 0))
                                    sfreq = 1;
                                if(stringbutton(rd, "   Send Message   ", 436, 408, 1, i_1, i_2, bool, 0, 0))
                                {
                                    tab = 2;
                                    openc = 10;
                                    itab = 0;
                                    litab = -1;
                                    if(!opname.equals(proname))
                                    {
                                        opname = proname;
                                        lastsub = "";
                                        readmsg = 1;
                                    }
                                }
                                if(stringbutton(rd, "   View Cars   ", 558, 408, 1, i_1, i_2, bool, 0, 0))
                                {
                                    cd.viewname = proname;
                                    onexitpro();
                                    cd.action = 100;
                                    xt.cfase = 100;
                                    xt.onviewpro = true;
                                    xt.fase = 23;
                                }
                                if(stringbutton(rd, "   View Stages   ", 673, 408, 1, i_1, i_2, bool, 0, 0))
                                    underc = 60;
                            } else
                            {
                                rd.setColor(new Color(236, 215, 140));
                                rd.fillRect(232, 378, 527, 50);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawRect(232, 378, 527, 50);
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                if(sfreq == 1)
                                    rd.drawString((new StringBuilder()).append("Sending a friend request to ").append(proname).append(", please wait...").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Sending a friend request to ").append(proname).append(", please wait...").toString()) / 2, 408);
                                if(sfreq == 2)
                                {
                                    rd.drawString((new StringBuilder()).append("Friend request sent, waiting for ").append(proname).append("'s approval.").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Friend request sent, waiting for ").append(proname).append("'s approval.").toString()) / 2, 408);
                                    if(stringbutton(rd, "  OK  ", 690, 408, 1, i_1, i_2, bool, 0, 0))
                                        sfreq = 0;
                                }
                                if(sfreq == 3)
                                {
                                    rd.drawString("Failed to send friend request, please try again later.", 495 - ftm.stringWidth("Failed to send friend request, please try again later.") / 2, 408);
                                    if(stringbutton(rd, "  OK  ", 690, 408, 1, i_1, i_2, bool, 0, 0))
                                        sfreq = 0;
                                }
                                if(sfreq == 4)
                                    rd.drawString((new StringBuilder()).append("Removing ").append(proname).append(" from firends, please wait...").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Removing ").append(proname).append(" from firends, please wait...").toString()) / 2, 408);
                                if(sfreq == 5)
                                {
                                    rd.drawString((new StringBuilder()).append("You are no longer friends with ").append(proname).append(".").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("You are no longer friends with ").append(proname).append(".").toString()) / 2, 408);
                                    if(stringbutton(rd, "  OK  ", 690, 408, 1, i_1, i_2, bool, 0, 0))
                                        sfreq = 0;
                                }
                                if(sfreq == 6)
                                {
                                    rd.drawString("Failed to remove friend, please try again later.", 495 - ftm.stringWidth("Failed to remove friend, please try again later.") / 2, 408);
                                    if(stringbutton(rd, "  OK  ", 690, 408, 1, i_1, i_2, bool, 0, 0))
                                        sfreq = 0;
                                }
                            }
                            if(underc != 0)
                            {
                                int i_45 = ftm.stringWidth("The 'View Stages' option is currently unavailable");
                                rd.setColor(new Color(244, 232, 204));
                                rd.fillRect(495 - (i_45 + 40) / 2, 422, i_45 + 40, 23);
                                rd.setColor(new Color(0, 0, 0));
                                if(underc % 4 != 0)
                                    rd.drawString("The 'View Stages' option is currently unavailable", 495 - i_45 / 2, 438);
                                rd.drawRect(495 - (i_45 + 40) / 2, 422, i_45 + 40, 23);
                                underc--;
                            }
                        }
                        if(edit == 1 || edit == 2)
                        {
                            rd.setColor(new Color(244, 232, 204));
                            rd.fillRoundRect(265, 92, 460, 220, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(265, 92, 460, 220, 20, 20);
                            String strings[] = {
                                "logo", "120x30", "4 : 1"
                            };
                            if(edit == 2)
                            {
                                strings[0] = "avatar";
                                strings[1] = "200x200";
                                strings[2] = "1 : 1";
                            }
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            if(flko % 4 != 0 || flko == 0)
                                rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 115);
                            if(flko != 0)
                                flko--;
                            rd.setFont(new Font("Arial", 0, 12));
                            rd.drawString((new StringBuilder()).append("The ").append(strings[0]).append(" image is ").append(strings[1]).append(" pixels.").toString(), 275, 140);
                            rd.drawString("Any image uploaded will be resized to that width and height. For the best results", 275, 160);
                            rd.drawString((new StringBuilder()).append("try to upload an image that is bigger or equal to ").append(strings[1]).append(" and has the scale of").toString(), 275, 180);
                            rd.drawString((new StringBuilder()).append("[ ").append(strings[2]).append(" ]  in  [ Width : Height ].").toString(), 275, 200);
                            rd.drawString("Image uploaded must be less than 1MB and in the format of JPEG, GIF or PNG.", 275, 220);
                            if(upload == 0)
                            {
                                if(stringbutton(rd, "  Upload Image  ", 495, 250, 0, i_1, i_2, bool, 0, 0))
                                {
                                    FileDialog filedialog = new FileDialog(new Frame(), "Upload Image");
                                    filedialog.setMode(0);
                                    filedialog.setVisible(true);
                                    filename = (new StringBuilder()).append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString();
                                    if(!filename.equals("nullnull"))
                                        upload = 1;
                                }
                            } else
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                if(upload == 1)
                                    rd.drawString("Checking image...", 495 - ftm.stringWidth("Checking image...") / 2, 250);
                                if(upload == 2)
                                    rd.drawString("Authenticating...", 495 - ftm.stringWidth("Authenticating...") / 2, 250);
                                if(upload == 3)
                                    rd.drawString((new StringBuilder()).append("Uploading image :  ").append(perc).append(" %").toString(), 495 - ftm.stringWidth("Uploading image :  80 %") / 2, 250);
                                if(upload == 4)
                                    rd.drawString("Creating image online...", 495 - ftm.stringWidth("Creating image online...") / 2, 250);
                                if(upload == 5)
                                    rd.drawString("Done", 495 - ftm.stringWidth("Done") / 2, 250);
                            }
                            if(stringbutton(rd, " Cancel ", 495, 290, 2, i_1, i_2, bool, 0, 0))
                                if(upload == 0)
                                    edit = 0;
                                else
                                    upload = 0;
                        }
                        if(edit == 3)
                        {
                            rd.setColor(new Color(244, 232, 204));
                            rd.fillRoundRect(265, 38, 460, 390, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(265, 38, 460, 390, 20, 20);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Edit your about section", 495 - ftm.stringWidth("Edit your about section") / 2, 61);
                            rd.setFont(new Font("Arial", 0, 12));
                            if(!badlang)
                            {
                                rd.drawString("Type in a sentence that best describes you and your playing style in the game :", 275, 86);
                            } else
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                rd.drawString("The sentence must not contain bad language!", 275, 86);
                                rd.setFont(new Font("Arial", 0, 12));
                            }
                            bool_4 = true;
                            rd.drawLine(315, 123, 675, 123);
                            rd.drawString("The ( Racing VS Wasting ) is comparison between your multiplayer wins by", 275, 146);
                            rd.drawString("racing versus wasting.", 275, 166);
                            rd.drawString("It does not in anyway signify if you are better or worse than another player!", 275, 186);
                            rd.drawString("It simply shows whether you have a tendency to win games by racing or by", 275, 206);
                            rd.drawString("wasting, it shows what you are better at.", 275, 226);
                            rd.drawLine(315, 241, 675, 241);
                            rd.drawString("Upload your very own theme song!", 275, 264);
                            rd.drawString("The theme song must be a Module Track that is in a zip file and less than 700KB.", 275, 284);
                            rd.drawString("You can find lots of MOD, XM and S3M Tracks at Modarchive.org.", 275, 304);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            if(uploadt == 0)
                            {
                                if(msg.equals(""))
                                {
                                    if(!themesong.equals("") && trackvol != 0)
                                    {
                                        rd.drawString((new StringBuilder()).append("Current Track : ").append(themesong).append("").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Current Track : ").append(themesong).append("").toString()) / 2, 324);
                                    } else
                                    {
                                        rd.setFont(new Font("Arial", 0, 12));
                                        rd.drawString("[ No theme song uploaded... ]", 495 - ftm.stringWidth("[ No theme song uploaded... ]") / 2, 324);
                                    }
                                } else
                                {
                                    if(flko % 4 != 0 || flko == 0)
                                        rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 324);
                                    if(flko != 0)
                                        flko--;
                                }
                                if(stringbutton(rd, "  Upload Track  ", 495, 354, 0, i_1, i_2, bool, 0, 0))
                                {
                                    FileDialog filedialog = new FileDialog(new Frame(), "Upload Track");
                                    filedialog.setMode(0);
                                    filedialog.setFile("*.zip");
                                    filedialog.setVisible(true);
                                    filename = (new StringBuilder()).append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString();
                                    if(!filename.equals("nullnull"))
                                    {
                                        trackname = filedialog.getFile().substring(0, filedialog.getFile().length() - 4);
                                        uploadt = 1;
                                    }
                                }
                            } else
                            {
                                if(uploadt == 1)
                                    rd.drawString("Checking MOD Track...", 495 - ftm.stringWidth("Checking MOD Track...") / 2, 354);
                                if(uploadt == 2)
                                    rd.drawString("Authenticating...", 495 - ftm.stringWidth("Authenticating...") / 2, 354);
                                if(uploadt == 3)
                                    rd.drawString("Uploading track, please wait...", 495 - ftm.stringWidth("Uploading track, please wait...") / 2, 354);
                                if(uploadt == 4)
                                    rd.drawString("Adding track to your profile...", 495 - ftm.stringWidth("Adding track to your profile...") / 2, 354);
                                if(uploadt == 5)
                                    rd.drawString("Done", 495 - ftm.stringWidth("Done") / 2, 354);
                            }
                            rd.drawLine(315, 376, 675, 376);
                            if(stringbutton(rd, "        Done        ", 495, 407, 1, i_1, i_2, bool, 0, 0))
                            {
                                edit = 0;
                                if(sentchange == 1)
                                {
                                    if(xt.msgcheck(sentance) || sentance.toLowerCase().indexOf(gs.tpass.getText().toLowerCase()) != -1 || xt.acexp == -3)
                                    {
                                        edit = 3;
                                        sentchange = 0;
                                        sentance = "";
                                        gs.cmsg.setText(sentance);
                                        badlang = true;
                                    } else
                                    {
                                        sentchange = 2;
                                    }
                                    trunsent();
                                }
                            }
                        }
                        if(edit == 5)
                        {
                            rd.setColor(new Color(244, 232, 204));
                            rd.fillRoundRect(265, 187, 460, 125, 20, 20);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(265, 187, 460, 125, 20, 20);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("You need to upgrade your account to a full account to have a profile!", 495 - ftm.stringWidth("You need to upgrade your account to a full account to have a profile!") / 2, 209);
                            rd.setColor(new Color(206, 171, 98));
                            rd.fillRoundRect(405, 222, 180, 50, 20, 20);
                            if(drawbutton(xt.upgrade, 495, 247, i_1, i_2, bool))
                                gs.editlink(xt.nickname, true);
                            if(stringbutton(rd, "  Cancel  ", 495, 297, 2, i_1, i_2, bool, 0, 0))
                                edit = 0;
                        }
                    } else
                    {
                        rd.drawString("Loading profile, please wait...", 495 - ftm.stringWidth("Loading profile, please wait...") / 2, 222);
                    }
                } else
                {
                    edit = 0;
                    uploadt = 0;
                    sentchange = 0;
                    underc = 0;
                }
                if(tab == 2)
                {
                    dotab2(i_1, i_2, bool);
                } else
                {
                    if(gs.sendtyp.isShowing())
                        gs.sendtyp.hide();
                    if(gs.senditem.isShowing())
                        gs.senditem.hide();
                    if(gs.datat.isShowing())
                        gs.datat.hide();
                    gs.ilaps.hide();
                    gs.icars.hide();
                    gs.sclass.hide();
                    gs.sfix.hide();
                }
                if(tab == 3)
                {
                    dotab3(i_1, i_2, bool);
                } else
                {
                    if(gs.clcars.isShowing())
                        gs.clcars.hide();
                    if(editc != 0)
                    {
                        editc = 0;
                        if(gs.clanlev.isShowing())
                            gs.clanlev.hide();
                    }
                    if(cfase == 1)
                        cfase = 0;
                }
                if(ptab == 0)
                    if(npo != -1)
                    {
                        sdist = (npo - 7) * 50;
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos / 345F) * (float)sdist);
                        for(int i_46 = 0; i_46 < npo; i_46++)
                            if((57 + 50 * i_46) - scro > 0 && (57 + 50 * (i_46 - 1)) - scro < 438)
                            {
                                boolean bool_47 = false;
                                if(i_1 > 26 && i_1 < 146 && i_2 > (38 + 50 * i_46) - scro && i_2 < (68 + 50 * i_46) - scro && !onp && overit == 0)
                                {
                                    bool_47 = true;
                                    cur = 12;
                                    if(bool)
                                    {
                                        tab = 1;
                                        if(!proname.equals(pname[i_46]))
                                        {
                                            proname = pname[i_46];
                                            loadedp = false;
                                            onexitpro();
                                        }
                                    }
                                }
                                boolean bool_48 = drawl(rd, pname[i_46], 26, (38 + 50 * i_46) - scro, bool_47);
                                if(!bool_47 || !bool_48)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString(pname[i_46], 86 - ftm.stringWidth(pname[i_46]) / 2, (49 + 50 * i_46) - scro);
                                    rd.setFont(new Font("Arial", 1, 11));
                                    ftm = rd.getFontMetrics();
                                    String string = "Not in any room...";
                                    if(pserver[i_46] >= 0 && pserver[i_46] <= 2 && proom[i_46] >= 0 && proom[i_46] <= 4)
                                    {
                                        string = (new StringBuilder()).append("").append(lg.snames[pserver[i_46]]).append(" :: Room ").append(proom[i_46] + 1).append("").toString();
                                        rd.setColor(new Color(49, 79, 0));
                                    }
                                    rd.drawString(string, 86 - ftm.stringWidth(string) / 2, (65 + 50 * i_46) - scro);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(5, (77 + 50 * i_46) - scro, 167, (77 + 50 * i_46) - scro);
                            }

                    } else
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Loading players...", 86 - ftm.stringWidth("Loading players...") / 2, 200);
                    }
                if(ptab == 1)
                    if(npf >= 0)
                    {
                        sdist = (npf - 7) * 50;
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos / 345F) * (float)sdist);
                        int i_49 = 0;
                        if(npf != 0)
                        {
                            for(int i_50 = 0; i_50 < npf; i_50++)
                            {
                                int i_51 = -1;
                                int i_52 = 0;
                                do
                                {
                                    if(i_52 >= npo)
                                        break;
                                    if(pname[i_52].toLowerCase().equals(fname[i_50].toLowerCase()))
                                    {
                                        i_51 = i_52;
                                        break;
                                    }
                                    i_52++;
                                } while(true);
                                if(i_51 == -1)
                                    continue;
                                if((57 + 50 * i_49) - scro > 0 && (57 + 50 * (i_49 - 1)) - scro < 438)
                                {
                                    boolean bool_53 = false;
                                    if(i_1 > 26 && i_1 < 146 && i_2 > (38 + 50 * i_49) - scro && i_2 < (68 + 50 * i_49) - scro && !onp && overit == 0 && freq <= 0)
                                    {
                                        bool_53 = true;
                                        cur = 12;
                                        if(bool)
                                        {
                                            tab = 1;
                                            if(!proname.equals(fname[i_50]))
                                            {
                                                proname = fname[i_50];
                                                loadedp = false;
                                                onexitpro();
                                            }
                                        }
                                    }
                                    boolean bool_54 = drawl(rd, fname[i_50], 26, (38 + 50 * i_49) - scro, bool_53);
                                    if(!bool_53 || !bool_54)
                                    {
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.drawString(fname[i_50], 86 - ftm.stringWidth(fname[i_50]) / 2, (49 + 50 * i_49) - scro);
                                        rd.setFont(new Font("Arial", 1, 11));
                                        ftm = rd.getFontMetrics();
                                        String string = "Not in any room...";
                                        if(pserver[i_51] >= 0 && pserver[i_51] <= 2 && proom[i_51] >= 0 && proom[i_51] <= 4)
                                        {
                                            string = (new StringBuilder()).append("").append(lg.snames[pserver[i_51]]).append(" :: Room ").append(proom[i_51] + 1).append("").toString();
                                            rd.setColor(new Color(49, 79, 0));
                                        }
                                        rd.drawString(string, 86 - ftm.stringWidth(string) / 2, (65 + 50 * i_49) - scro);
                                    }
                                    rd.setColor(color2k(150, 150, 150));
                                    rd.drawLine(5, (77 + 50 * i_49) - scro, 167, (77 + 50 * i_49) - scro);
                                }
                                i_49++;
                            }

                            for(int i_55 = 0; i_55 < npf; i_55++)
                            {
                                int i_56 = -1;
                                int i_57 = 0;
                                do
                                {
                                    if(i_57 >= npo)
                                        break;
                                    if(pname[i_57].toLowerCase().equals(fname[i_55].toLowerCase()))
                                    {
                                        i_56 = i_57;
                                        break;
                                    }
                                    i_57++;
                                } while(true);
                                if(i_56 == -1)
                                {
                                    if((57 + 50 * i_49) - scro > 0 && (57 + 50 * (i_49 - 1)) - scro < 438)
                                    {
                                        boolean bool_58 = false;
                                        if(i_1 > 26 && i_1 < 146 && i_2 > (38 + 50 * i_49) - scro && i_2 < (68 + 50 * i_49) - scro && !onp && overit == 0 && freq <= 0)
                                        {
                                            bool_58 = true;
                                            cur = 12;
                                            if(bool)
                                            {
                                                tab = 1;
                                                if(!proname.equals(fname[i_55]))
                                                {
                                                    proname = fname[i_55];
                                                    loadedp = false;
                                                    onexitpro();
                                                }
                                            }
                                        }
                                        boolean bool_59 = drawl(rd, fname[i_55], 26, (38 + 50 * i_49) - scro, bool_58);
                                        if(!bool_58 || !bool_59)
                                        {
                                            rd.setFont(new Font("Arial", 1, 12));
                                            ftm = rd.getFontMetrics();
                                            rd.setColor(new Color(0, 0, 0));
                                            rd.drawString(fname[i_55], 86 - ftm.stringWidth(fname[i_55]) / 2, (49 + 50 * i_49) - scro);
                                            rd.setFont(new Font("Arial", 0, 11));
                                            ftm = rd.getFontMetrics();
                                            String string = "Player Offline";
                                            rd.drawString(string, 86 - ftm.stringWidth(string) / 2, (65 + 50 * i_49) - scro);
                                        }
                                        rd.setColor(color2k(150, 150, 150));
                                        rd.drawLine(5, (77 + 50 * i_49) - scro, 167, (77 + 50 * i_49) - scro);
                                    }
                                    i_49++;
                                }
                            }

                        } else
                        {
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("No friends added yet.", 86 - ftm.stringWidth("No friends added yet.") / 2, 200);
                        }
                        if(freq == 1)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 130);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 130);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Friend request from:", 86 - ftm.stringWidth("Friend request from:") / 2, 45);
                            rd.setColor(new Color(240, 222, 164));
                            rd.fillRect(26, 51, 119, 29);
                            if(!drawl(rd, freqname, 26, 51, true))
                            {
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString(freqname, 86 - ftm.stringWidth(freqname) / 2, 70);
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawRect(26, 51, 119, 29);
                            }
                            if(i_1 > 26 && i_1 < 146 && i_2 > 51 && i_2 < 81)
                            {
                                cur = 12;
                                if(bool)
                                {
                                    tab = 1;
                                    if(!proname.equals(freqname))
                                    {
                                        proname = freqname;
                                        loadedp = false;
                                        onexitpro();
                                    }
                                }
                            }
                            if(stringbutton(rd, "    Confirm    ", 86, 107, 0, i_1, i_2, bool, 0, 0))
                                freq = 2;
                            if(stringbutton(rd, "Cancel", 86, 140, 2, i_1, i_2, bool, 0, 0))
                                freq = 3;
                        }
                        if(freq == -1)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 25);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 25);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Failed to confirm friend!", 86 - ftm.stringWidth("Failed to confirm friend!") / 2, 45);
                            cntf--;
                            if(cntf <= 0)
                                freq = 0;
                        }
                        if(freq == -2)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 25);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 25);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Failed to cancel request!", 86 - ftm.stringWidth("Failed to cancel request!") / 2, 45);
                            cntf--;
                            if(cntf <= 0)
                                freq = 0;
                        }
                        if(freq == 2)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 25);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 25);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Confirming friend...", 86 - ftm.stringWidth("Confirming friend...") / 2, 45);
                        }
                        if(freq == 3)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 25);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 25);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Canceling...", 86 - ftm.stringWidth("Canceling...") / 2, 45);
                        }
                        if(freq == 6)
                        {
                            rd.setColor(new Color(236, 215, 140));
                            rd.fillRect(-10, 28, 200, 61 + ncnf * 35);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRect(-10, 28, 200, 61 + ncnf * 35);
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Friend Confirmation(s):", 86 - ftm.stringWidth("Friend Confirmation(s):") / 2, 45);
                            for(int i_60 = 0; i_60 < ncnf; i_60++)
                            {
                                rd.setColor(new Color(240, 222, 164));
                                rd.fillRect(26, 51 + 35 * i_60, 119, 29);
                                if(!drawl(rd, cnfname[i_60], 26, 51 + 35 * i_60, true))
                                {
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString(cnfname[i_60], 86 - ftm.stringWidth(cnfname[i_60]) / 2, 70 + 35 * i_60);
                                    rd.setColor(color2k(150, 150, 150));
                                    rd.drawRect(26, 51 + 35 * i_60, 119, 29);
                                }
                                if(i_1 <= 26 || i_1 >= 146 || i_2 <= 51 + 35 * i_60 || i_2 >= 81 + 35 * i_60)
                                    continue;
                                cur = 12;
                                if(!bool)
                                    continue;
                                tab = 1;
                                if(!proname.equals(cnfname[i_60]))
                                {
                                    proname = cnfname[i_60];
                                    loadedp = false;
                                    onexitpro();
                                }
                            }

                            if(stringbutton(rd, "  OK  ", 86, 107 + 35 * (ncnf - 1), 0, i_1, i_2, bool, 0, 0))
                                freq = -6;
                        }
                    } else
                    {
                        if(npf == -1)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Loading friends...", 86 - ftm.stringWidth("Loading friends...") / 2, 200);
                        }
                        if(npf == -2)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Failed to load friends!", 86 - ftm.stringWidth("Failed to load friends!") / 2, 200);
                        }
                    }
                if(ptab == 2)
                    if(xt.clan.equals(""))
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Not in a Clan", 86 - ftm.stringWidth("Not in a Clan") / 2, 200);
                        rd.setFont(new Font("Arial", 0, 11));
                        ftm = rd.getFontMetrics();
                        rd.drawString("You haven't joined and clan yet.", 86 - ftm.stringWidth("You haven't joined and clan yet.") / 2, 220);
                    } else
                    if(loadedcm)
                    {
                        sdist = (ncln - 7) * 50;
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos / 345F) * (float)sdist);
                        int i_61 = 0;
                        for(int i_62 = 0; i_62 < ncln; i_62++)
                        {
                            int i_63 = -1;
                            int i_64 = 0;
                            do
                            {
                                if(i_64 >= npo)
                                    break;
                                if(pname[i_64].toLowerCase().equals(clname[i_62].toLowerCase()))
                                {
                                    i_63 = i_64;
                                    break;
                                }
                                i_64++;
                            } while(true);
                            if(i_63 == -1)
                                continue;
                            if((57 + 50 * i_61) - scro > 0 && (57 + 50 * (i_61 - 1)) - scro < 438)
                            {
                                boolean bool_65 = false;
                                if(i_1 > 26 && i_1 < 146 && i_2 > (38 + 50 * i_61) - scro && i_2 < (68 + 50 * i_61) - scro && !onp && overit == 0 && freq <= 0)
                                {
                                    bool_65 = true;
                                    cur = 12;
                                    if(bool)
                                    {
                                        tab = 1;
                                        if(!proname.equals(clname[i_62]))
                                        {
                                            proname = clname[i_62];
                                            loadedp = false;
                                            onexitpro();
                                        }
                                    }
                                }
                                boolean bool_66 = drawl(rd, clname[i_62], 26, (38 + 50 * i_61) - scro, bool_65);
                                if(!bool_65 || !bool_66)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString(clname[i_62], 86 - ftm.stringWidth(clname[i_62]) / 2, (49 + 50 * i_61) - scro);
                                    rd.setFont(new Font("Arial", 1, 11));
                                    ftm = rd.getFontMetrics();
                                    String string = "Not in any room...";
                                    if(pserver[i_63] >= 0 && pserver[i_63] <= 2 && proom[i_63] >= 0 && proom[i_63] <= 4)
                                    {
                                        string = (new StringBuilder()).append("").append(lg.snames[pserver[i_63]]).append(" :: Room ").append(proom[i_63] + 1).append("").toString();
                                        rd.setColor(new Color(49, 79, 0));
                                    }
                                    rd.drawString(string, 86 - ftm.stringWidth(string) / 2, (65 + 50 * i_61) - scro);
                                }
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(5, (77 + 50 * i_61) - scro, 167, (77 + 50 * i_61) - scro);
                            }
                            i_61++;
                        }

                        for(int i_67 = 0; i_67 < ncln; i_67++)
                        {
                            int i_68 = -1;
                            int i_69 = 0;
                            do
                            {
                                if(i_69 >= npo)
                                    break;
                                if(pname[i_69].toLowerCase().equals(clname[i_67].toLowerCase()))
                                {
                                    i_68 = i_69;
                                    break;
                                }
                                i_69++;
                            } while(true);
                            if(i_68 == -1)
                            {
                                if((57 + 50 * i_61) - scro > 0 && (57 + 50 * (i_61 - 1)) - scro < 438)
                                {
                                    boolean bool_70 = false;
                                    if(i_1 > 26 && i_1 < 146 && i_2 > (38 + 50 * i_61) - scro && i_2 < (68 + 50 * i_61) - scro && !onp && overit == 0 && freq <= 0)
                                    {
                                        bool_70 = true;
                                        cur = 12;
                                        if(bool)
                                        {
                                            tab = 1;
                                            if(!proname.equals(clname[i_67]))
                                            {
                                                proname = clname[i_67];
                                                loadedp = false;
                                                onexitpro();
                                            }
                                        }
                                    }
                                    boolean bool_71 = drawl(rd, clname[i_67], 26, (38 + 50 * i_61) - scro, bool_70);
                                    if(!bool_70 || !bool_71)
                                    {
                                        rd.setFont(new Font("Arial", 1, 12));
                                        ftm = rd.getFontMetrics();
                                        rd.setColor(new Color(0, 0, 0));
                                        rd.drawString(clname[i_67], 86 - ftm.stringWidth(clname[i_67]) / 2, (49 + 50 * i_61) - scro);
                                        rd.setFont(new Font("Arial", 0, 11));
                                        ftm = rd.getFontMetrics();
                                        String string = "Player Offline";
                                        rd.drawString(string, 86 - ftm.stringWidth(string) / 2, (65 + 50 * i_61) - scro);
                                    }
                                    rd.setColor(color2k(150, 150, 150));
                                    rd.drawLine(5, (77 + 50 * i_61) - scro, 167, (77 + 50 * i_61) - scro);
                                }
                                i_61++;
                            }
                        }

                    } else
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Loading clan mates...", 86 - ftm.stringWidth("Loading clan mates...") / 2, 200);
                    }
            } else
            if(open == 452)
            {
                rd.setColor(color2k(230, 230, 230));
                rd.fillRoundRect(240, 170, 511, 90, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(240, 170, 511, 90, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                rd.drawString("Failed to connect to server at this time, please exit and try again later.", 495 - ftm.stringWidth("Failed to connect to server at this time, please exit and try again later.") / 2, 200);
                if(stringbutton(rd, "  Exit  ", 495, 230, 1, i_1, i_2, bool, 0, 0))
                {
                    open = 450;
                    upo = false;
                    domon = false;
                }
            }
            int is[] = {
                193, 193, 295, 318
            };
            int is_72[] = {
                33, 10, 10, 33
            };
            for(int i_73 = 0; i_73 < 4; i_73++)
            {
                boolean bool_74 = false;
                if(tab == 3 && i_73 == 0)
                    bool_74 = true;
                if(tab == 1 && i_73 == 1)
                    bool_74 = true;
                if(tab == 2 && i_73 == 2)
                    bool_74 = true;
                if(tab == 0 && i_73 == 3)
                    bool_74 = true;
                rd.setColor(new Color(255, 255, 255));
                if(bool_74)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                else
                    rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
                if(i_2 >= 12 && i_2 <= 32 && i_1 > is[0] && i_1 < is[3])
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                    if(bool && !gs.openm)
                    {
                        if(i_73 == 0)
                            tab = 3;
                        if(i_73 == 1 || i_73 == 2)
                            tab = i_73;
                        if(i_73 == 3)
                            tab = 0;
                        if(tab == 1 && proname.equals(""))
                        {
                            proname = xt.nickname;
                            loadedp = false;
                            onexitpro();
                        }
                    }
                }
                rd.fillPolygon(is, is_72, 4);
                rd.setColor(new Color(0, 0, 0));
                rd.drawPolygon(is, is_72, 4);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i_73 == 0)
                {
                    is_72[1] = 13;
                    is_72[2] = 13;
                    is[2] = 298;
                }
                for(int i_75 = 0; i_75 < 4; i_75++)
                    is[i_75] += 125;

            }

            rd.drawImage(xt.cnmc, 224, 15, null);
            rd.setColor(new Color(0, 0, 0));
            rd.drawLine(191, 34, 800, 34);
            rd.setColor(color2k(200, 200, 200));
            rd.fillRect(0, 0, 190, 28);
            rd.setColor(color2k(150, 150, 150));
            rd.drawLine(0, 25, 170, 25);
            rd.setColor(color2k(200, 200, 200));
            rd.fillRect(0, 438, 190, 12);
            rd.setColor(color2k(150, 150, 150));
            rd.drawLine(0, 440, 170, 440);
            rd.setColor(color2k(200, 200, 200));
            rd.fillRect(173, 28, 17, 410);
            rd.setColor(new Color(0, 0, 0));
            rd.drawLine(191, 0, 191, 450);
            if(i_1 > 0 && i_1 < 171 && i_2 > 2 && i_2 < 23)
            {
                if(!onp)
                {
                    rd.setColor(color2k(220, 220, 220));
                    rd.fillRect(2, 2, 146, 21);
                }
                rd.setColor(color2k(255, 255, 255));
                if(bool && overit == 0 && !onp)
                {
                    onp = true;
                    overit = 5;
                }
            } else
            {
                rd.setColor(color2k(235, 235, 235));
            }
            if(overit < 0)
                overit++;
            rd.fillRect(150, 2, 20, 20);
            rd.setColor(color2k(150, 150, 150));
            rd.drawRect(150, 2, 20, 20);
            rd.setColor(new Color(0, 0, 0));
            rd.drawLine(157, 10, 157, 11);
            rd.drawLine(158, 11, 158, 12);
            rd.drawLine(159, 12, 159, 13);
            rd.drawLine(160, 13, 160, 14);
            rd.drawLine(161, 12, 161, 13);
            rd.drawLine(162, 11, 162, 12);
            rd.drawLine(163, 10, 163, 11);
            if(ptab == 0)
                rd.drawImage(xt.players, 7, 5, null);
            if(ptab == 1)
                rd.drawImage(xt.myfr, 21, 4, null);
            if(ptab == 2)
                rd.drawImage(xt.mycl, 34, 4, null);
            if(onp)
            {
                rd.setColor(color2k(200, 200, 200));
                rd.fillRect(0, 25, 170, 67);
                rd.setColor(color2k(150, 150, 150));
                rd.drawRect(0, 25, 170, 67);
                if(i_1 > 0 && i_1 < 171 && i_2 >= 26 && i_2 < 48)
                {
                    rd.setColor(color2k(235, 235, 235));
                    rd.fillRect(1, 26, 169, 22);
                    if(bool)
                        ptab = 0;
                }
                if(i_1 > 0 && i_1 < 171 && i_2 >= 48 && i_2 < 70)
                {
                    rd.setColor(color2k(235, 235, 235));
                    rd.fillRect(1, 48, 169, 22);
                    if(bool)
                    {
                        ptab = 1;
                        npf = -1;
                    }
                }
                if(i_1 > 0 && i_1 < 171 && i_2 >= 70 && i_2 < 92)
                {
                    rd.setColor(color2k(235, 235, 235));
                    rd.fillRect(1, 70, 169, 22);
                    if(bool)
                        ptab = 2;
                }
                rd.drawImage(xt.players, 7, 30, null);
                rd.drawImage(xt.myfr, 21, 51, null);
                rd.drawImage(xt.mycl, 34, 73, null);
                if(bool && overit == 0)
                {
                    onp = false;
                    overit = -5;
                }
                if(overit > 0)
                    overit--;
            }
            if(mscro == 831 || sdist == 0)
            {
                if(sdist == 0)
                    rd.setColor(color2k(205, 205, 205));
                else
                    rd.setColor(color2k(215, 215, 215));
                rd.fillRect(173, 28, 17, 17);
            } else
            {
                rd.setColor(color2k(220, 220, 220));
                rd.fill3DRect(173, 28, 17, 17, true);
            }
            if(sdist != 0)
                rd.drawImage(xt.asu, 178, 34, null);
            if(mscro == 832 || sdist == 0)
            {
                if(sdist == 0)
                    rd.setColor(color2k(205, 205, 205));
                else
                    rd.setColor(color2k(215, 215, 215));
                rd.fillRect(173, 421, 17, 17);
            } else
            {
                rd.setColor(color2k(220, 220, 220));
                rd.fill3DRect(173, 421, 17, 17, true);
            }
            if(sdist != 0)
                rd.drawImage(xt.asd, 178, 428, null);
            if(sdist != 0)
            {
                if(lspos != spos)
                {
                    rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(173, 45 + spos, 17, 31);
                } else
                {
                    if(mscro == 831)
                        rd.setColor(color2k(215, 215, 215));
                    rd.fill3DRect(173, 45 + spos, 17, 31, true);
                }
                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(178, 58 + spos, 184, 58 + spos);
                rd.drawLine(178, 60 + spos, 184, 60 + spos);
                rd.drawLine(178, 62 + spos, 184, 62 + spos);
                if(mscro > 800 && lspos != spos)
                    lspos = spos;
                if(bool)
                {
                    if(mscro == 825 && i_1 > 173 && i_1 < 190 && i_2 > 45 + spos && i_2 < spos + 76)
                        mscro = i_2 - spos;
                    if(mscro == 825 && i_1 > 171 && i_1 < 192 && i_2 > 26 && i_2 < 47)
                        mscro = 831;
                    if(mscro == 825 && i_1 > 171 && i_1 < 192 && i_2 > 419 && i_2 < 440)
                        mscro = 832;
                    if(mscro == 825 && i_1 > 173 && i_1 < 190 && i_2 > 45 && i_2 < 421)
                    {
                        mscro = 60;
                        spos = i_2 - mscro;
                    }
                    int i_76 = 2670 / sdist;
                    if(i_76 < 1)
                        i_76 = 1;
                    if(mscro == 831)
                    {
                        spos -= i_76;
                        if(spos > 345)
                            spos = 345;
                        if(spos < 0)
                            spos = 0;
                        lspos = spos;
                    }
                    if(mscro == 832)
                    {
                        spos += i_76;
                        if(spos > 345)
                            spos = 345;
                        if(spos < 0)
                            spos = 0;
                        lspos = spos;
                    }
                    if(mscro < 800)
                    {
                        spos = i_2 - mscro;
                        if(spos > 345)
                            spos = 345;
                        if(spos < 0)
                            spos = 0;
                    }
                    if(mscro == 825)
                        mscro = 925;
                } else
                if(mscro != 825)
                    mscro = 825;
            }
            if(cur != curs)
            {
                gs.setCursor(new Cursor(cur));
                curs = cur;
            }
            if(xt.warning != 0)
            {
                xt.drawWarning();
                if(gs.cmsg.isShowing())
                {
                    gs.cmsg.hide();
                    gs.requestFocus();
                }
                xt.warning++;
            }
        }
        if(bool_3)
        {
            if(xt.warning != 0)
                gs.cmsg.hide();
            gs.movefieldd(gs.cmsg, 207, 414, 462, 22, true);
            if(gs.cmsg.getText().equals("Type here...") && i_1 > 197 && i_1 < 679 && i_2 > 404 && i_2 < 446)
                gs.cmsg.setText("");
            if(gs.cmsg.getText().length() > 200)
            {
                gs.cmsg.setText(gs.cmsg.getText().substring(0, 200));
                gs.cmsg.select(200, 200);
            }
        }
        if(bool_4)
        {
            if(!gs.cmsg.isShowing() && xt.warning == 0)
            {
                gs.cmsg.show();
                gs.cmsg.setText(sentance);
                gs.cmsg.requestFocus();
            }
            gs.movefield(gs.cmsg, 275, 91, 440, 22);
            if(!sentance.equals(gs.cmsg.getText()))
            {
                sentchange = 1;
                rd.setFont(new Font("Tahoma", 1, 11));
                ftm = rd.getFontMetrics();
                if(ftm.stringWidth(gs.cmsg.getText()) > 800)
                    gs.cmsg.setText(sentance);
                else
                    sentance = gs.cmsg.getText();
            }
        }
        if(dorank)
        {
            if(!gs.cmsg.isShowing() && xt.warning == 0)
            {
                gs.cmsg.show();
                gs.cmsg.setText(mrank[em]);
                gs.cmsg.requestFocus();
            }
            gs.movefield(gs.cmsg, 402, 131, 300, 22);
            rd.setFont(new Font("Arial", 1, 11));
            ftm = rd.getFontMetrics();
            if(ftm.stringWidth(gs.cmsg.getText()) > 270)
            {
                int i_78 = gs.cmsg.getText().length() - 1;
                if(i_78 < 0)
                    i_78 = 0;
                gs.cmsg.setText(gs.cmsg.getText().substring(0, i_78));
                gs.cmsg.select(i_78, i_78);
            }
        }
        if(donewc)
        {
            if(!gs.temail.isShowing())
            {
                gs.temail.show();
                gs.temail.setText("");
                gs.temail.requestFocus();
            }
            gs.movefield(gs.temail, 473, 141, 150, 22);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(ftm.stringWidth(gs.temail.getText()) > 150)
            {
                int i_79 = gs.temail.getText().length() - 1;
                if(i_79 < 0)
                    i_79 = 0;
                gs.temail.setText(gs.temail.getText().substring(0, i_79));
                gs.temail.select(i_79, i_79);
            }
            if(!gs.temail.getText().equals(lccnam))
            {
                lg.fixtext(gs.temail);
                lccnam = gs.temail.getText();
            }
            if(xt.msgcheck(gs.temail.getText()))
                gs.temail.setText("");
        }
        if(dosrch)
        {
            if(!gs.temail.isShowing())
            {
                gs.temail.show();
                gs.temail.setText("");
                gs.temail.requestFocus();
            }
            gs.movefield(gs.temail, 371, 88, 150, 22);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(ftm.stringWidth(gs.temail.getText()) > 150)
            {
                int i_80 = gs.temail.getText().length() - 1;
                if(i_80 < 0)
                    i_80 = 0;
                gs.temail.setText(gs.temail.getText().substring(0, i_80));
                gs.temail.select(i_80, i_80);
            }
            if(!gs.temail.getText().equals(lccnam))
            {
                lg.fixtext(gs.temail);
                lccnam = gs.temail.getText();
            }
            if(xt.msgcheck(gs.temail.getText()))
                gs.temail.setText("");
        }
        if(doweb1)
        {
            if(!gs.temail.isShowing())
            {
                gs.temail.show();
                gs.temail.setText(ltit);
                gs.temail.requestFocus();
            }
            gs.movefield(gs.temail, 411, 174, 150, 22);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(ftm.stringWidth(gs.temail.getText()) > 200)
            {
                int i_81 = gs.temail.getText().length() - 1;
                if(i_81 < 0)
                    i_81 = 0;
                gs.temail.setText(gs.temail.getText().substring(0, i_81));
                gs.temail.select(i_81, i_81);
            }
            if(xt.msgcheck(gs.temail.getText()))
                gs.temail.setText("");
            if(!gs.cmsg.isShowing())
            {
                gs.cmsg.show();
                gs.cmsg.setText(ldes);
            }
            gs.movefield(gs.cmsg, 411, 204, 300, 22);
            rd.setFont(new Font("Arial", 0, 12));
            ftm = rd.getFontMetrics();
            if(ftm.stringWidth(gs.cmsg.getText()) > 400)
            {
                int i_82 = gs.cmsg.getText().length() - 1;
                if(i_82 < 0)
                    i_82 = 0;
                gs.cmsg.setText(gs.cmsg.getText().substring(0, i_82));
                gs.cmsg.select(i_82, i_82);
            }
            if(xt.msgcheck(gs.cmsg.getText()))
                gs.cmsg.setText("");
        }
        if(doweb2)
        {
            if(!gs.temail.isShowing())
            {
                gs.temail.show();
                gs.temail.requestFocus();
            }
            gs.movefield(gs.temail, 354, 134, 350, 22);
        }
        if(dommsg)
        {
            if(!donemsg && xt.warning == 0)
            {
                gs.mmsg.setText(" ");
                if(!gs.applejava)
                {
                    gs.mmsg.show();
                    gs.mmsg.requestFocus();
                }
                donemsg = true;
            }
            gs.movefielda(gs.mmsg, 207, 389, 450, 50);
        } else
        {
            if(gs.mmsg.isShowing())
                gs.mmsg.hide();
            if(donemsg)
                donemsg = false;
        }
        if(!dosrch && !donewc && !doweb1 && !doweb2 && gs.temail.isShowing())
            gs.temail.hide();
        if(!bool_3 && !bool_4 && !dorank && !doweb1 && open == 452 && gs.cmsg.isShowing())
            gs.cmsg.hide();
    }

    public void dotab3(int i, int i_83, boolean bool)
    {
        if(cfase == 0)
        {
            rd.setColor(new Color(0, 0, 0));
            rd.drawRect(214, 44, 160, 50);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            int i_84 = 239;
            int i_85 = ftm.stringWidth("Search for a clan");
            rd.fillRect(225, 57, 4, 4);
            rd.drawString("Search for a clan", i_84, 63);
            if(i > i_84 && i < i_84 + i_85 && i_83 > 46 && i_83 < 65 && editc == 0)
            {
                rd.drawLine(i_84, 65, i_84 + i_85, 65);
                cur = 12;
                if(bool)
                {
                    cfase = 2;
                    em = 1;
                    msg = "Clan Search";
                    smsg = "Listing clans with recent activity...";
                    nclns = 0;
                    spos5 = 0;
                    lspos5 = 0;
                    flko = 0;
                }
            }
            i_84 = 239;
            i_85 = ftm.stringWidth("Create a new clan");
            rd.fillRect(225, 77, 4, 4);
            rd.drawString("Create a new clan", i_84, 83);
            if(i > i_84 && i < i_84 + i_85 && i_83 > 66 && i_83 < 85 && editc == 0)
            {
                rd.drawLine(i_84, 85, i_84 + i_85, 85);
                cur = 12;
                if(bool)
                {
                    cfase = 1;
                    em = 0;
                    msg = "Start a new Need for Madness clan,";
                    flko = 0;
                }
            }
            if(!xt.clan.equals(""))
            {
                int i_86 = -40;
                int i_87 = 19;
                if(!drawl(rd, (new StringBuilder()).append("#").append(xt.clan).append("#").toString(), 406 + i_87, 101 + i_86, true))
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString((new StringBuilder()).append("").append(xt.clan).append("").toString(), (581 + i_87) - ftm.stringWidth((new StringBuilder()).append("").append(xt.clan).append("").toString()) / 2, 121 + i_86);
                }
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                String string = "Your Clan";
                if(i > 402 + i_87 && i < 759 + i_87 && i_83 > 84 + i_86 && i_83 < 134 + i_86)
                {
                    string = (new StringBuilder()).append("Clan :  ").append(xt.clan).append("").toString();
                    rd.drawLine(408 + i_87, 98 + i_86, 408 + i_87 + ftm.stringWidth(string), 98 + i_86);
                    if(i > 408 + i_87 && i < 408 + i_87 + ftm.stringWidth(string) && i_83 > 85 + i_86 && i_83 < 100 + i_86 || i > 406 + i_87 && i < 756 + i_87 && i_83 > 101 + i_86 && i_83 < 131 + i_86)
                    {
                        cur = 12;
                        if(bool)
                        {
                            if(!claname.equals(xt.clan))
                            {
                                claname = xt.clan;
                                loadedc = false;
                            }
                            spos5 = 0;
                            lspos5 = 0;
                            cfase = 3;
                            ctab = 0;
                            blocknote = 10;
                        }
                    }
                }
                rd.drawString(string, 408 + i_87, 97 + i_86);
                rd.drawLine(402 + i_87, 84 + i_86, 402 + i_87, 134 + i_86);
                rd.drawLine(402 + i_87, 84 + i_86, 408 + i_87 + ftm.stringWidth(string) + 2, 84 + i_86);
                rd.drawLine(408 + i_87 + ftm.stringWidth(string) + 2, 84 + i_86, 408 + i_87 + ftm.stringWidth(string) + 15, 97 + i_86);
                rd.drawLine(408 + i_87 + ftm.stringWidth(string) + 15, 97 + i_86, 759 + i_87, 97 + i_86);
                rd.drawLine(759 + i_87, 97 + i_86, 759 + i_87, 134 + i_86);
                rd.drawLine(402 + i_87, 134 + i_86, 759 + i_87, 134 + i_86);
            }
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(ntab == 0)
            {
                int is[] = {
                    214, 225 + ftm.stringWidth("Game News"), 225 + ftm.stringWidth("Game News") + 23, 778, 778, 214
                };
                int is_88[] = {
                    112, 112, 135, 135, 443, 443
                };
                rd.setColor(new Color(206, 171, 98));
                rd.fillPolygon(is, is_88, 6);
                rd.setColor(new Color(0, 0, 0));
                rd.drawPolygon(is, is_88, 6);
            }
            if(ntab == 1)
            {
                int is[] = {
                    214, 225 + ftm.stringWidth("Game News") + 23, 225 + ftm.stringWidth("Game News") + 23, 236 + ftm.stringWidth("Game News") + 23 + ftm.stringWidth("Wars World Championship"), 236 + ftm.stringWidth("Game News") + 23 + ftm.stringWidth("Wars World Championship") + 23, 778, 778, 214
                };
                int is_89[] = {
                    135, 135, 112, 112, 135, 135, 443, 443
                };
                rd.setColor(new Color(206, 171, 98));
                rd.fillPolygon(is, is_89, 8);
                rd.setColor(new Color(0, 0, 0));
                rd.drawPolygon(is, is_89, 8);
            }
            int i_90 = 223;
            int i_91 = ftm.stringWidth("Game News");
            int i_92 = 23;
            rd.drawString("Game News", i_90, 107 + i_92);
            if(i > i_90 && i < i_90 + i_91 && i_83 > 90 + i_92 && i_83 < 109 + i_92)
            {
                rd.drawLine(i_90, 109 + i_92, i_90 + i_91, 109 + i_92);
                cur = 12;
                if(bool)
                {
                    ntab = 0;
                    spos6 = 0;
                }
            }
            i_90 += i_91 + 35;
            i_91 = ftm.stringWidth("Wars World Championship");
            rd.drawString("Wars World Championship", i_90, 107 + i_92);
            if(i > i_90 && i < i_90 + i_91 && i_83 > 90 + i_92 && i_83 < 109 + i_92)
            {
                rd.drawLine(i_90, 109 + i_92, i_90 + i_91, 109 + i_92);
                cur = 12;
                if(bool)
                {
                    ntab = 1;
                    spos6 = 0;
                }
            }
            rdo.setColor(new Color(206, 171, 98));
            rdo.fillRect(0, 0, 560, 300);
            darker = true;
            if(stringbutton(rd, "  Refresh  ", 738, 125, 3, i, i_83, bool, 0, 0))
            {
                if(ntab == 0)
                    loadednews = 0;
                if(ntab == 1)
                    loadwstat = 0;
            }
            darker = false;
            if(ntab == 0)
            {
                if(loadednews == 1)
                {
                    int i_93 = 0;
                    for(int i_94 = 0; i_94 < 5; i_94++)
                        if(nwarbs[i_94] > 0)
                            i_93++;

                    if(i_93 == 0)
                        i_93 = 1;
                    sdist = (100 + 35 * i_93 + doi * 16) - 200;
                    if(sdist < 0)
                        sdist = 0;
                    scro = (int)(((float)spos6 / 229F) * (float)sdist);
                    if(scro < 55)
                    {
                        rdo.setFont(new Font("Tahoma", 1, 11));
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawString("A big welcome to the latest players to join the game with full accounts!", 18, 15 - scro);
                        for(int i_95 = 0; i_95 < 4; i_95++)
                        {
                            boolean bool_96 = false;
                            boolean bool_97 = false;
                            if(i > 234 + 128 * i_95 && i < 354 + 128 * i_95 && i_83 > 159 - scro && i_83 < 189 - scro && i_83 > 139 && i_83 < 439)
                            {
                                bool_97 = true;
                                cur = 12;
                                if(bool)
                                {
                                    tab = 1;
                                    if(!proname.equals(newplayers[i_95]))
                                    {
                                        proname = newplayers[i_95];
                                        loadedp = false;
                                        onexitpro();
                                    }
                                }
                            }
                            if(!bool_97)
                                bool_96 = drawl(rdo, newplayers[i_95], 18 + 128 * i_95, 20 - scro, true);
                            else
                                drawl(rdo, newplayers[i_95], 18 + 128 * i_95, 20 - scro, false);
                            if(!bool_96)
                            {
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.2F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRect(18 + 128 * i_95, 20 - scro, 119, 29);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.drawRect(18 + 128 * i_95, 20 - scro, 119, 29);
                                rdo.drawString(newplayers[i_95], (78 + 128 * i_95) - ftm.stringWidth(newplayers[i_95]) / 2, 39 - scro);
                            }
                        }

                    }
                    String string;
                    if((75 + 35 * i_93) - scro > 0)
                    {
                        rdo.setFont(new Font("Tahoma", 1, 11));
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawString("Recent clan wars & battles:", 18, 70 - scro);
                        i_93 = 0;
                        for(int i_98 = 0; i_98 < 5; i_98++)
                        {
                            if(nwarbs[i_98] <= 0)
                                continue;
                            rdo.setComposite(AlphaComposite.getInstance(3, 0.2F));
                            boolean bool_99 = false;
                            bool_99 = drawl(rdo, (new StringBuilder()).append("#").append(nwclan[i_98]).append("#").toString(), 18, (75 - scro) + 35 * i_93, true);
                            if(!bool_99)
                            {
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRect(18, (75 - scro) + 35 * i_93, 350, 30);
                            }
                            rdo.setComposite(AlphaComposite.getInstance(3, 0.1F));
                            rdo.setColor(new Color(255, 255, 255));
                            rdo.fillRect(368, (75 - scro) + 35 * i_93, 154, 30);
                            rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.setFont(new Font("Tahoma", 1, 11));
                            string = "war";
                            if(nwarbs[i_98] == 2)
                                string = "car battle";
                            if(nwarbs[i_98] == 3)
                                string = "stage battle";
                            String string_100 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" defeated ").append(nlclan[i_98]).append(" in a ").append(string).append("!").toString();
                            rdo.drawString(string_100, 22, (87 - scro) + 35 * i_93);
                            tlink(rdo, 22, (87 - scro) + 35 * i_93, string_100, nwclan[i_98], i, i_83, bool, 216, 139, 1, nwclan[i_98], "");
                            tlink(rdo, 22, (87 - scro) + 35 * i_93, string_100, nlclan[i_98], i, i_83, bool, 216, 139, 1, nlclan[i_98], "");
                            if(nwarbs[i_98] == 1 && nwinp[i_98] != -1 && nlosp[i_98] != -1)
                                if(nwinob[i_98].equals("champ"))
                                {
                                    String string_101 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" has taken the clan wars world championship title!").toString();
                                    rdo.setFont(new Font("Tahoma", 0, 11));
                                    rdo.drawString(string_101, 22, (100 - scro) + 35 * i_93);
                                    tlink(rdo, 22, (100 - scro) + 35 * i_93, string_101, "clan wars world championship title", i, i_83, bool, 216, 139, 5, "", "");
                                } else
                                if(nwinob[i_98].equals("re-champ"))
                                {
                                    String string_102 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" has defended and re-claimed the clan wars world championship title!").toString();
                                    rdo.setFont(new Font("Tahoma", 0, 11));
                                    rdo.drawString(string_102, 22, (100 - scro) + 35 * i_93);
                                    tlink(rdo, 22, (100 - scro) + 35 * i_93, string_102, "clan wars world championship title", i, i_83, bool, 216, 139, 5, "", "");
                                } else
                                {
                                    String string_103 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" won: [ ").append(nwinp[i_98]).append(" points ]  & ").append(nlclan[i_98]).append(" lost: [ ").append(nlosp[i_98]).append(" points ]").toString();
                                    rdo.setFont(new Font("Tahoma", 0, 11));
                                    rdo.drawString(string_103, 22, (100 - scro) + 35 * i_93);
                                    tlink(rdo, 22, (100 - scro) + 35 * i_93, string_103, (new StringBuilder()).append("").append(nwinp[i_98]).append(" points").toString(), i, i_83, bool, 216, 139, 5, "", "");
                                    tlink(rdo, 22, (100 - scro) + 35 * i_93, string_103, (new StringBuilder()).append("").append(nlosp[i_98]).append(" points").toString(), i, i_83, bool, 216, 139, 5, "", "");
                                }
                            if(nwarbs[i_98] == 2)
                            {
                                String string_104 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" took car [").append(nwinob[i_98]).append("] from ").append(nlclan[i_98]).append(".").toString();
                                rdo.setFont(new Font("Tahoma", 0, 11));
                                rdo.drawString(string_104, 22, (100 - scro) + 35 * i_93);
                                tlink(rdo, 22, (100 - scro) + 35 * i_93, string_104, nwinob[i_98], i, i_83, bool, 216, 139, 3, nwinob[i_98], nwclan[i_98]);
                            }
                            if(nwarbs[i_98] == 3)
                            {
                                String string_105 = nwinob[i_98];
                                if(string_105.length() > 20)
                                    string_105 = (new StringBuilder()).append("").append(string_105.substring(0, 20)).append("...").toString();
                                String string_106 = (new StringBuilder()).append("").append(nwclan[i_98]).append(" took stage [").append(string_105).append("] from ").append(nlclan[i_98]).append(".").toString();
                                rdo.setFont(new Font("Tahoma", 0, 11));
                                rdo.drawString(string_106, 22, (100 - scro) + 35 * i_93);
                                tlink(rdo, 22, (100 - scro) + 35 * i_93, string_106, string_105, i, i_83, bool, 216, 139, 4, nwinob[i_98], nwclan[i_98]);
                            }
                            rdo.setColor(new Color(98, 76, 29));
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString(nwtime[i_98], 518 - ftm.stringWidth(nwtime[i_98]), (87 - scro) + 35 * i_93);
                            i_93++;
                        }

                        if(i_93 == 0)
                        {
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString("(No recent clan wars or battles have been played yet...)", 280 - ftm.stringWidth("(No recent clan wars or battles have been played yet...)") / 2, 91 - scro);
                            i_93 = 1;
                        }
                    }
                    int i_107 = (70 + 35 * i_93) - scro;
                    if(i_107 + 25 > 0)
                    {
                        rdo.setFont(new Font("Tahoma", 1, 11));
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawString("Recent clan activity:", 18, i_107 + 20);
                    }
                    boolean bool_108 = false;
                    string = "";
                    doi = 0;
                    for(int i_109 = 0; i_109 < il; i_109++)
                        if(!text[i_109].equals(string))
                        {
                            if(!bool_108)
                                bool_108 = true;
                            else
                                bool_108 = false;
                            if(i_107 + doi * 16 + 38 > 0 && i_107 + doi * 16 + 18 < 300)
                            {
                                if(bool_108)
                                {
                                    rdo.setComposite(AlphaComposite.getInstance(3, 0.1F));
                                    rdo.setColor(new Color(255, 255, 255));
                                    rdo.fillRect(18, i_107 + doi * 16 + 24, 504, 16);
                                    rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                }
                                rdo.setFont(new Font("Tahoma", 0, 11));
                                ftm = rdo.getFontMetrics();
                                if(text[i_109].startsWith("Battle"))
                                {
                                    rdo.setFont(new Font("Tahoma", 1, 11));
                                } else
                                {
                                    rdo.setColor(new Color(98, 76, 29));
                                    rdo.drawString(nttime[i_109], 518 - ftm.stringWidth(nttime[i_109]), i_107 + doi * 16 + 36);
                                }
                                if(text[i_109].indexOf("started") != -1)
                                {
                                    rdo.setFont(new Font("Tahoma", 1, 11));
                                    if(text[i_109].indexOf("war") == -1)
                                        if(!bool_108)
                                            bool_108 = true;
                                        else
                                            bool_108 = false;
                                }
                                if(text[i_109].indexOf("clan wars world champion") != -1)
                                {
                                    rdo.setFont(new Font("Tahoma", 1, 11));
                                    if(!bool_108)
                                        bool_108 = true;
                                    else
                                        bool_108 = false;
                                }
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString(text[i_109], 22, i_107 + doi * 16 + 36);
                                for(int i_110 = 0; i_110 < nln[i_109]; i_110++)
                                    tlink(rdo, 22, i_107 + doi * 16 + 36, text[i_109], link[i_109][i_110][0], i, i_83, bool, 216, 139, getvalue(link[i_109][i_110][1], 0), getSvalue(link[i_109][i_110][1], 1), getSvalue(link[i_109][i_110][1], 2));

                            }
                            string = text[i_109];
                            doi++;
                        }

                } else
                {
                    sdist = 0;
                }
                if(loadednews == 0)
                {
                    rdo.setFont(new Font("Tahoma", 1, 11));
                    ftm = rdo.getFontMetrics();
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawString("Loading game news, please wait...", 280 - ftm.stringWidth("Loading game news, please wait...") / 2, 140);
                }
                if(loadednews == -1)
                {
                    rdo.setFont(new Font("Tahoma", 1, 11));
                    ftm = rdo.getFontMetrics();
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawString("Failed to load game news, please try again later...", 280 - ftm.stringWidth("Failed to load game news, please try again later...") / 2, 140);
                }
            }
            if(ntab == 1)
            {
                darker = true;
                if(stringbutton(rd, "  About Championship  ", 617, 125, 3, i, i_83, bool, 0, 0))
                    ntab = 2;
                darker = false;
                if(loadwstat == 1)
                {
                    if(eng == -1)
                    {
                        int i_111 = ncc;
                        if(champ >= 0)
                            i_111--;
                        if(i_111 < 0)
                            i_111 = 0;
                        sdist = (154 + i_111 * 45) - 260;
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos6 / 229F) * (float)sdist);
                        rdo.setFont(new Font("Tahoma", 1, 11));
                        ftm = rdo.getFontMetrics();
                        int i_112 = ftm.stringWidth("Engagement Stats");
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawString("Current World Champion", 10, 20 - scro);
                        rdo.setColor(new Color(228, 177, 31));
                        rdo.fillRoundRect(10, 28 - scro, 520, 70, 20, 20);
                        rdo.setColor(new Color(199, 154, 63));
                        rdo.fillRoundRect(13, 33 - scro, 514, 60, 20, 20);
                        rdo.setColor(new Color(255, 198, 0));
                        rdo.drawRoundRect(13, 33 - scro, 514, 60, 20, 20);
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawRoundRect(10, 28 - scro, 520, 70, 20, 20);
                        if(champ == -1)
                        {
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString("No current world champion because no contender has attained or surpassed 3 points yet!", 270 - ftm.stringWidth("No current world champion because no contender has attained or surpassed 3 points yet!") / 2, 65 - scro);
                        }
                        if(champ == -2)
                        {
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString("No current world champion at this moment because the top contenders are tied in points!", 270 - ftm.stringWidth("No current world champion at this moment because the top contenders are tied in points!") / 2, 65 - scro);
                        }
                        if(champ >= 0)
                        {
                            if(!drawl(rdo, (new StringBuilder()).append("#").append(conclan[champ]).append("#").toString(), 21, 40 - scro, true))
                            {
                                rdo.setColor(new Color(100, 77, 31));
                                rdo.drawRect(21, 40 - scro, 349, 29);
                                rdo.setFont(new Font("Arial", 1, 13));
                                ftm = rdo.getFontMetrics();
                                rdo.drawString(conclan[champ], 196 - ftm.stringWidth(conclan[champ]) / 2, 59 - scro);
                            }
                            if(i > 237 && i < 587 && i_83 > 179 - scro && i_83 < 209 - scro && i_83 > 139 && i_83 < 439)
                            {
                                cur = 12;
                                if(bool)
                                {
                                    if(!claname.equals(conclan[champ]))
                                    {
                                        claname = conclan[champ];
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    ctab = 0;
                                }
                            }
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString((new StringBuilder()).append("").append(conclan[champ]).append(" is leading the championship by ").append(leadsby).append(" points difference from the first contender!").toString(), 22, 85 - scro);
                            rdo.setFont(new Font("Tahoma", 1, 11));
                            rdo.drawString((new StringBuilder()).append("Attained points:  [ ").append(totp[champ]).append(" ]").toString(), 383, 51 - scro);
                            rdo.drawString("Engagement Stats", 383, 66 - scro);
                            rdo.drawLine(383, 68 - scro, 383 + i_112, 68 - scro);
                            if(i > 599 && i < 383 + i_112 + 216 && i_83 > 195 - scro && i_83 < 208 - scro && i_83 > 139 && i_83 < 439)
                            {
                                cur = 12;
                                if(bool)
                                {
                                    eng = champ;
                                    engo = 40 - scro;
                                    lspos6w = spos6;
                                    spos6 = 0;
                                }
                            }
                        }
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.setFont(new Font("Tahoma", 1, 11));
                        ftm = rdo.getFontMetrics();
                        rdo.drawString("Contenders", 10, 125 - scro);
                        if(i_111 > 3)
                            i_111 = 160 + 45 * (i_111 - 3);
                        else
                            i_111 = 160;
                        rdo.drawRoundRect(10, 133 - scro, 520, i_111, 20, 20);
                        if(ncc == 0 || ncc == 1 && champ == 0)
                        {
                            rdo.drawString("No contenders...", 270 - ftm.stringWidth("No contenders...") / 2, 160 - scro);
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString("To become a contender, a clan must get points by winning a war against any other clan.", 270 - ftm.stringWidth("To become a contender, a clan must get points by winning a war against any other clan.") / 2, 185 - scro);
                        } else
                        {
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString("To become a contender, a clan must get points by winning a war against any other clan.", 270 - ftm.stringWidth("To become a contender, a clan must get points by winning a war against any other clan.") / 2, 147 - scro);
                            int i_113 = 0;
                            for(int i_114 = 0; i_114 < ncc; i_114++)
                                if(ord[i_114] != champ)
                                {
                                    rdo.setColor(new Color(199, 154, 63));
                                    rdo.fillRect(11, (154 + i_113 * 45) - scro, 519, 40);
                                    if(!drawl(rdo, (new StringBuilder()).append("#").append(conclan[ord[i_114]]).append("#").toString(), 21, (159 + i_113 * 45) - scro, true))
                                    {
                                        rdo.setColor(new Color(100, 77, 31));
                                        rdo.drawRect(21, (159 + i_113 * 45) - scro, 349, 29);
                                        rdo.setFont(new Font("Arial", 1, 13));
                                        ftm = rdo.getFontMetrics();
                                        rdo.drawString(conclan[ord[i_114]], 196 - ftm.stringWidth(conclan[ord[i_114]]) / 2, (178 + i_113 * 45) - scro);
                                    }
                                    if(i > 237 && i < 587 && i_83 > (159 + i_113 * 45 + 139) - scro && i_83 < (189 + i_113 * 45 + 139) - scro && i_83 > 139 && i_83 < 439)
                                    {
                                        cur = 12;
                                        if(bool)
                                        {
                                            if(!claname.equals(conclan[ord[i_114]]))
                                            {
                                                claname = conclan[ord[i_114]];
                                                loadedc = false;
                                            }
                                            spos5 = 0;
                                            lspos5 = 0;
                                            cfase = 3;
                                            ctab = 0;
                                        }
                                    }
                                    rdo.setColor(new Color(0, 0, 0));
                                    rdo.setFont(new Font("Tahoma", 1, 11));
                                    rdo.drawString((new StringBuilder()).append("Attained points:  [ ").append(totp[ord[i_114]]).append(" ]").toString(), 383, (170 + i_113 * 45) - scro);
                                    rdo.drawString("Engagement Stats", 383, (185 + i_113 * 45) - scro);
                                    rdo.drawLine(383, (187 + i_113 * 45) - scro, 383 + i_112, (187 + i_113 * 45) - scro);
                                    if(i > 599 && i < 383 + i_112 + 216 && i_83 > (175 + i_113 * 45 + 139) - scro && i_83 < (188 + i_113 * 45 + 139) - scro && i_83 > 139 && i_83 < 439)
                                    {
                                        cur = 12;
                                        if(bool)
                                        {
                                            eng = ord[i_114];
                                            engo = (159 + i_113 * 45) - scro;
                                            lspos6w = spos6;
                                            spos6 = 0;
                                        }
                                    }
                                    i_113++;
                                }

                        }
                    } else
                    {
                        if(engo == 15)
                        {
                            sdist = (87 + ados + nvc[eng] * 17) - 260;
                            if(sdist < 0)
                                sdist = 0;
                            scro = (int)(((float)spos6 / 229F) * (float)sdist);
                            ados = 0;
                            rdo.setFont(new Font("Tahoma", 1, 11));
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString("Engagement Stats", 385, 40 - scro);
                            String string = "s";
                            if(!xt.clan.equals("") && !xt.clan.toLowerCase().equals(conclan[eng].toLowerCase()))
                            {
                                ados = 116;
                                int i_115 = -1;
                                int i_116 = 0;
                                int i_117 = 0;
                                do
                                {
                                    if(i_117 >= ncc)
                                        break;
                                    if(xt.clan.toLowerCase().equals(conclan[i_117].toLowerCase()))
                                    {
                                        i_116 = totp[i_117];
                                        i_115 = i_117;
                                        break;
                                    }
                                    i_117++;
                                } while(true);
                                int i_118 = totp[eng] + 1;
                                int i_119 = i_116 + 1;
                                if(i_119 > totp[eng])
                                    i_119 = totp[eng];
                                if(i_115 != -1)
                                {
                                    int i_120 = 0;
                                    do
                                    {
                                        if(i_120 >= nvc[i_115])
                                            break;
                                        if(conclan[eng].toLowerCase().equals(verclan[i_115][i_120].toLowerCase()))
                                        {
                                            i_118 -= points[i_115][i_120];
                                            if(i_118 < 0)
                                                i_118 = 0;
                                            break;
                                        }
                                        i_120++;
                                    } while(true);
                                }
                                rdo.setFont(new Font("Tahoma", 1, 11));
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString((new StringBuilder()).append("If your clan ").append(xt.clan).append(" engages & defeats ").append(conclan[eng]).append(" in a war:").toString(), 27, 70 - scro);
                                rdo.setFont(new Font("Tahoma", 0, 11));
                                string = "s";
                                if(i_118 == 1)
                                    string = "";
                                rdo.drawString((new StringBuilder()).append("- Your clan will get:  [ ").append(i_118).append(" point").append(string).append(" ]").toString(), 47, 87 - scro);
                                string = "s";
                                if(i_119 == 1)
                                    string = "";
                                rdo.drawString((new StringBuilder()).append("- ").append(conclan[eng]).append(" will lose:  [ ").append(i_119).append(" point").append(string).append(" ]").toString(), 47, 104 - scro);
                                if(i_118 + i_116 > 3 && i_118 + i_116 > totp[ord[0]] && !xt.clan.toLowerCase().equals(conclan[ord[0]].toLowerCase()))
                                {
                                    if(frkl)
                                    {
                                        rdo.setColor(new Color(0, 0, 0));
                                        frkl = false;
                                    } else
                                    {
                                        rdo.setColor(new Color(106, 80, 0));
                                        frkl = true;
                                    }
                                    if(champ >= 0)
                                        rdo.drawString((new StringBuilder()).append("- Your clan would take the championship title from ").append(conclan[champ]).append(" !").toString(), 47, 121 - scro);
                                    else
                                        rdo.drawString("- Your clan would take the champion ship title!", 42, 121 - scro);
                                    ados += 17;
                                }
                                rdo.setColor(new Color(0, 0, 0));
                                i_118 = i_116 + 1;
                                i_119 = totp[eng] + 1;
                                if(i_119 > i_116)
                                    i_119 = i_116;
                                int i_121 = 0;
                                do
                                {
                                    if(i_121 >= nvc[eng])
                                        break;
                                    if(xt.clan.toLowerCase().equals(verclan[eng][i_121].toLowerCase()))
                                    {
                                        i_118 -= points[eng][i_121];
                                        if(i_118 < 0)
                                            i_118 = 0;
                                        break;
                                    }
                                    i_121++;
                                } while(true);
                                rdo.setFont(new Font("Tahoma", 1, 11));
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString((new StringBuilder()).append("If your clan loses a war against ").append(conclan[eng]).append(":").toString(), 27, (12 + ados) - scro);
                                rdo.setFont(new Font("Tahoma", 0, 11));
                                string = "s";
                                if(i_119 == 1)
                                    string = "";
                                rdo.drawString((new StringBuilder()).append("- Your clan will lose:  [ ").append(i_119).append(" point").append(string).append(" ]").toString(), 47, (29 + ados) - scro);
                                string = "s";
                                if(i_118 == 1)
                                    string = "";
                                rdo.drawString((new StringBuilder()).append("- ").append(conclan[eng]).append(" will get:  [ ").append(i_118).append(" point").append(string).append(" ]").toString(), 47, (46 + ados) - scro);
                            }
                            rdo.setFont(new Font("Tahoma", 1, 11));
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString((new StringBuilder()).append("").append(conclan[eng]).append(" has attained its points from clan wars:").toString(), 27, (70 + ados) - scro);
                            rdo.setFont(new Font("Tahoma", 0, 11));
                            for(int i_122 = 0; i_122 < nvc[eng]; i_122++)
                            {
                                string = "s";
                                if(points[eng][i_122] == 1)
                                    string = "";
                                rdo.drawString((new StringBuilder()).append("Versus clan ").append(verclan[eng][i_122]).append(":  [ ").append(points[eng][i_122]).append(" point").append(string).append(" ]").toString(), 47, (87 + ados + i_122 * 17) - scro);
                            }

                            rdo.setFont(new Font("Tahoma", 1, 11));
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawString((new StringBuilder()).append("Total attained points:  [ ").append(totp[eng]).append(" ]").toString(), 47, (87 + ados + nvc[eng] * 17) - scro);
                        } else
                        if(Math.abs(engo - 15) < 20)
                            engo = 15;
                        else
                        if(engo < 15)
                            engo += 20;
                        else
                            engo -= 20;
                        if(!drawl(rdo, (new StringBuilder()).append("#").append(conclan[eng]).append("#").toString(), 21, engo - scro, true))
                        {
                            rdo.setColor(new Color(100, 77, 31));
                            rdo.drawRect(21, engo - scro, 349, 29);
                            rdo.setFont(new Font("Arial", 1, 13));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString(conclan[champ], 196 - ftm.stringWidth(conclan[champ]) / 2, (engo + 19) - scro);
                        }
                        if(engo == 15)
                        {
                            darker = true;
                            if(!xt.clan.equals("") && !xt.clan.toLowerCase().equals(conclan[eng].toLowerCase()) && stringbutton(rdo, "   Declare War  >   ", 459, 176, 1, i, i_83, bool, 216, 139))
                            {
                                tab = 2;
                                itab = 1;
                                litab = -1;
                                openi = 10;
                                viewgame2 = 0;
                                if(!intclan.equals(conclan[eng]))
                                {
                                    intclan = conclan[eng];
                                    dispi = 0;
                                    nil = 0;
                                    lastint = "";
                                    readint = 1;
                                }
                                redif = true;
                                intsel = 4;
                                eng = -1;
                                spos6 = lspos6w;
                            }
                            if(stringbutton(rdo, "   <  Back   ", 480, 110, 1, i, i_83, bool, 216, 139))
                            {
                                eng = -1;
                                spos6 = lspos6w;
                            }
                            darker = false;
                        }
                    }
                } else
                {
                    sdist = 0;
                }
                if(loadwstat == 0)
                {
                    rdo.setFont(new Font("Tahoma", 1, 11));
                    ftm = rdo.getFontMetrics();
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawString("Loading championship, please wait...", 280 - ftm.stringWidth("Loading championship, please wait...") / 2, 140);
                }
                if(loadwstat == -1)
                {
                    rdo.setFont(new Font("Tahoma", 1, 11));
                    ftm = rdo.getFontMetrics();
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawString("Failed to load championship, please try again later...", 280 - ftm.stringWidth("Failed to load championship, please try again later...") / 2, 140);
                }
            }
            if(ntab == 2)
            {
                rdo.setFont(new Font("Tahoma", 1, 11));
                ftm = rdo.getFontMetrics();
                rdo.setColor(new Color(0, 0, 0));
                rdo.drawString("About the Championship", 280 - ftm.stringWidth("About the Championship") / 2, 40);
                rdo.setFont(new Font("Tahoma", 0, 11));
                rdo.drawString("The clan wars world championship is ongoing championship that does not end!", 7, 70);
                rdo.drawString("Every clan always has a chance to claim & re-claim the championship title from the current winner.", 7, 85);
                rdo.drawString("The champion clan is the clan that is at the current moment attaining the most points.", 7, 115);
                rdo.drawString("Clans get points by defeating other clans in wars, but not every clan you defeat earns you the same amount of", 7, 130);
                rdo.drawString("points. It depends on how much points that clan has and from which wars where these points attained.", 7, 145);
                rdo.drawString("The points system is designed to deliver a fair & balanced championship that is also fun, exiting and never ending!", 7, 160);
                rdo.setFont(new Font("Tahoma", 1, 11));
                rdo.drawString("Currently there are no rewards in the game for claiming or re-claiming the championship title, but", 7, 190);
                rdo.drawString("in the coming updates there will be rewards that can be used to 'super power' clan cars!", 7, 205);
                rdo.setFont(new Font("Tahoma", 0, 11));
                rdo.drawString("Stay tuned for the rewards system to come!", 7, 220);
                rdo.setFont(new Font("Tahoma", 1, 11));
                ftm = rdo.getFontMetrics();
                rdo.drawString("Good Luck!", 280 - ftm.stringWidth("Good Luck!") / 2, 250);
                darker = true;
                if(stringbutton(rdo, "   <  Back   ", 280, 280, 1, i, i_83, bool, 216, 139))
                    ntab = 1;
                darker = false;
            }
            if(sdist != 0)
            {
                int i_123 = 27;
                rdo.setColor(color2k(200, 200, 200));
                rdo.fillRect(540, 20, 17, 260);
                if(mscro5 == 831)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 3, 17, 17);
                } else
                {
                    rdo.setColor(color2k(220, 220, 220));
                    rdo.fill3DRect(540, 3, 17, 17, true);
                }
                rdo.drawImage(xt.asu, 545, 9, null);
                if(mscro5 == 832)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 280, 17, 17);
                } else
                {
                    rdo.setColor(color2k(220, 220, 220));
                    rdo.fill3DRect(540, 280, 17, 17, true);
                }
                rdo.drawImage(xt.asd, 545, 287, null);
                if(lspos6 != spos6)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 20 + spos6, 17, 31);
                } else
                {
                    if(mscro5 == 831)
                        rdo.setColor(color2k(215, 215, 215));
                    rdo.fill3DRect(540, 20 + spos6, 17, 31, true);
                }
                rdo.setColor(color2k(150, 150, 150));
                rdo.drawLine(545, 33 + spos6, 551, 33 + spos6);
                rdo.drawLine(545, 35 + spos6, 551, 35 + spos6);
                rdo.drawLine(545, 37 + spos6, 551, 37 + spos6);
                if(mscro5 > 800 && lspos6 != spos6)
                    lspos6 = spos6;
                if(bool)
                {
                    if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 + i_123 + spos6 && i_83 < spos6 + i_123 + 163)
                        mscro5 = i_83 - spos6;
                    if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 26 + i_123 && i_83 < 134 + i_123)
                        mscro5 = 831;
                    if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 390 + i_123 && i_83 < 411 + i_123)
                        mscro5 = 832;
                    if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 + i_123 && i_83 < 392 + i_123)
                    {
                        mscro5 = 152 + i_123;
                        spos6 = i_83 - mscro5;
                    }
                    int i_124 = 2670 / sdist;
                    if(i_124 < 1)
                        i_124 = 1;
                    if(mscro5 == 831)
                    {
                        spos6 -= i_124;
                        if(spos6 > 229)
                            spos6 = 229;
                        if(spos6 < 0)
                            spos6 = 0;
                        lspos6 = spos6;
                    }
                    if(mscro5 == 832)
                    {
                        spos6 += i_124;
                        if(spos6 > 229)
                            spos6 = 229;
                        if(spos6 < 0)
                            spos6 = 0;
                        lspos6 = spos6;
                    }
                    if(mscro5 < 800)
                    {
                        spos6 = i_83 - mscro5;
                        if(spos6 > 229)
                            spos6 = 229;
                        if(spos6 < 0)
                            spos6 = 0;
                    }
                    if(mscro5 == 825)
                        mscro5 = 925;
                } else
                if(mscro5 != 825)
                    mscro5 = 825;
            }
            rd.drawImage(gImage, 216, 139, null);
        }
        if(cfase == 1)
            if(xt.logged)
            {
                if(xt.clan.equals(""))
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                    rd.setColor(new Color(255, 255, 255));
                    rd.fillRoundRect(232, 90, 527, 176, 20, 20);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(232, 90, 527, 176, 20, 20);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    if(flko % 4 != 0 || flko == 0)
                        rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 120);
                    if(flko != 0)
                        flko--;
                    rd.drawString("Clan name :", 462 - ftm.stringWidth("Clan name :"), 156);
                    donewc = true;
                    if(em != 1)
                    {
                        if(stringbutton(rd, "     Create     ", 495, 204, 0, i, i_83, bool, 0, 0))
                            if(!gs.temail.getText().equals(""))
                            {
                                em = 1;
                            } else
                            {
                                msg = "Please enter a clan name!";
                                flko = 45;
                            }
                        if(stringbutton(rd, " Cancel ", 495, 244, 2, i, i_83, bool, 0, 0))
                            cfase = 0;
                    } else
                    {
                        rd.drawString("Creating, please wait...", 495 - ftm.stringWidth("Creating, please wait...") / 2, 224);
                    }
                } else
                {
                    rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                    rd.setColor(new Color(255, 255, 255));
                    rd.fillRoundRect(232, 90, 527, 136, 20, 20);
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(232, 90, 527, 136, 20, 20);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString((new StringBuilder()).append("You are already a member of a clan (").append(xt.clan).append(").").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("You are already a member of a clan (").append(xt.clan).append(").").toString()) / 2, 120);
                    rd.drawString("You need to leave your clan first in order to create a new one.", 495 - ftm.stringWidth("You need to leave your clan first in order to create a new one.") / 2, 140);
                    if(stringbutton(rd, "   OK   ", 495, 204, 0, i, i_83, bool, 0, 0))
                        cfase = 0;
                }
            } else
            {
                rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
                rd.setColor(new Color(255, 255, 255));
                rd.fillRoundRect(232, 90, 527, 176, 20, 20);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(232, 90, 527, 176, 20, 20);
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                rd.drawString("You are currently using a trial account.", 495 - ftm.stringWidth("You are currently using a trial account.") / 2, 120);
                rd.drawString("You need to upgrade to be able participate in any NFM clan activity.", 495 - ftm.stringWidth("You need to upgrade to be able participate in any NFM clan activity.") / 2, 140);
                rd.setColor(new Color(206, 171, 98));
                rd.fillRoundRect(405, 163, 180, 50, 20, 20);
                if(drawbutton(xt.upgrade, 495, 188, i, i_83, bool))
                    gs.editlink(xt.nickname, true);
                if(stringbutton(rd, " Cancel ", 495, 244, 2, i, i_83, bool, 0, 0))
                    cfase = 0;
            }
        if(cfase == 2)
        {
            rd.setColor(new Color(0, 0, 0));
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(flko % 4 != 0 || flko == 0)
                rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 60);
            if(flko != 0)
                flko--;
            rd.setComposite(AlphaComposite.getInstance(3, 0.2F));
            rd.setColor(new Color(255, 255, 255));
            rd.fillRoundRect(197, 73, 597, 371, 20, 20);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(197, 73, 597, 371, 20, 20);
            dosrch = true;
            darker = true;
            if(stringbutton(rd, "   Search   ", 579, 104, 2, i, i_83, bool, 0, 0))
                if(!gs.temail.getText().equals(""))
                {
                    em = 2;
                    smsg = (new StringBuilder()).append("Searching for '").append(gs.temail.getText()).append("' in clans...").toString();
                    nclns = 0;
                    spos5 = 0;
                    lspos5 = 0;
                } else
                {
                    msg = "Please enter a search phrase!";
                    flko = 45;
                }
            rd.setColor(new Color(0, 0, 0));
            rd.setFont(new Font("Arial", 1, 13));
            rd.drawString(smsg, 218, 135);
            if(stringbutton(rd, " <   Back to Main  ", 725, 60, 2, i, i_83, bool, 0, 0))
                cfase = 0;
            darker = false;
            rdo.setColor(new Color(206, 171, 98));
            rdo.fillRect(0, 0, 560, 300);
            sdist = (int)(((float)nclns - 4.5F) * 55F);
            if(sdist < 0 || nclns == 0)
                sdist = 0;
            scro = (int)(((float)spos5 / 229F) * (float)sdist);
            rdo.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            for(int i_125 = 0; i_125 < nclns; i_125++)
            {
                if((60 + i_125 * 55) - scro <= 0 || (20 + i_125 * 55) - scro >= 300)
                    continue;
                boolean bool_126 = true;
                if(i > 308 && i < 683 && i_83 > (159 + i_125 * 55) - scro && i_83 < (199 + i_125 * 55) - scro)
                {
                    cur = 12;
                    bool_126 = false;
                    if(bool)
                    {
                        if(!claname.equals(clanlo[i_125]))
                        {
                            claname = clanlo[i_125];
                            loadedc = false;
                        }
                        spos5 = 0;
                        lspos5 = 0;
                        cfase = 3;
                        ctab = 0;
                    }
                }
                rdo.setColor(new Color(0, 0, 0));
                rdo.drawRoundRect(92, (20 + i_125 * 55) - scro, 375, 40, 20, 20);
                if(!drawl(rdo, (new StringBuilder()).append("#").append(clanlo[i_125]).append("#").toString(), 105, (25 + i_125 * 55) - scro, bool_126) || !bool_126)
                    rdo.drawString((new StringBuilder()).append("").append(clanlo[i_125]).append("").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("").append(clanlo[i_125]).append("").toString()) / 2, (45 + i_125 * 55) - scro);
            }

            if(sdist != 0)
            {
                int i_127 = 27;
                rdo.setColor(color2k(200, 200, 200));
                rdo.fillRect(540, 20, 17, 260);
                if(mscro5 == 831)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 3, 17, 17);
                } else
                {
                    rdo.setColor(color2k(220, 220, 220));
                    rdo.fill3DRect(540, 3, 17, 17, true);
                }
                rdo.drawImage(xt.asu, 545, 9, null);
                if(mscro5 == 832)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 280, 17, 17);
                } else
                {
                    rdo.setColor(color2k(220, 220, 220));
                    rdo.fill3DRect(540, 280, 17, 17, true);
                }
                rdo.drawImage(xt.asd, 545, 287, null);
                if(lspos5 != spos5)
                {
                    rdo.setColor(color2k(215, 215, 215));
                    rdo.fillRect(540, 20 + spos5, 17, 31);
                } else
                {
                    if(mscro5 == 831)
                        rdo.setColor(color2k(215, 215, 215));
                    rdo.fill3DRect(540, 20 + spos5, 17, 31, true);
                }
                rdo.setColor(color2k(150, 150, 150));
                rdo.drawLine(545, 33 + spos5, 551, 33 + spos5);
                rdo.drawLine(545, 35 + spos5, 551, 35 + spos5);
                rdo.drawLine(545, 37 + spos5, 551, 37 + spos5);
                if(mscro5 > 800 && lspos5 != spos5)
                    lspos5 = spos5;
                if(bool)
                {
                    if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 + i_127 + spos5 && i_83 < spos5 + i_127 + 163)
                        mscro5 = i_83 - spos5;
                    if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 26 + i_127 && i_83 < 134 + i_127)
                        mscro5 = 831;
                    if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 390 + i_127 && i_83 < 411 + i_127)
                        mscro5 = 832;
                    if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 + i_127 && i_83 < 392 + i_127)
                    {
                        mscro5 = 152 + i_127;
                        spos5 = i_83 - mscro5;
                    }
                    int i_128 = 2670 / sdist;
                    if(i_128 < 1)
                        i_128 = 1;
                    if(mscro5 == 831)
                    {
                        spos5 -= i_128;
                        if(spos5 > 229)
                            spos5 = 229;
                        if(spos5 < 0)
                            spos5 = 0;
                        lspos5 = spos5;
                    }
                    if(mscro5 == 832)
                    {
                        spos5 += i_128;
                        if(spos5 > 229)
                            spos5 = 229;
                        if(spos5 < 0)
                            spos5 = 0;
                        lspos5 = spos5;
                    }
                    if(mscro5 < 800)
                    {
                        spos5 = i_83 - mscro5;
                        if(spos5 > 229)
                            spos5 = 229;
                        if(spos5 < 0)
                            spos5 = 0;
                    }
                    if(mscro5 == 825)
                        mscro5 = 925;
                } else
                if(mscro5 != 825)
                    mscro5 = 825;
            }
            rd.drawImage(gImage, 216, 139, null);
        }
        if(cfase == 3)
        {
            rd.setComposite(AlphaComposite.getInstance(3, 0.4F));
            rd.setColor(new Color(255, 255, 255));
            rd.fillRoundRect(197, 40, 597, 404, 20, 20);
            rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(197, 40, 597, 404, 20, 20);
            rd.setFont(new Font("Arial", 1, 13));
            ftm = rd.getFontMetrics();
            if(loadedc)
            {
                int i_129 = -1;
                for(int i_130 = 0; i_130 < nmb; i_130++)
                    if(member[i_130].toLowerCase().equals(xt.nickname.toLowerCase()) && (mlevel[i_130] == 7 || i_130 == 0))
                        i_129 = i_130;

                boolean bool_131 = false;
                if(i > 197 && i < 563 && i_83 > 40 && i_83 < 83 && editc == 0)
                    bool_131 = true;
                boolean bool_132 = drawl(rd, (new StringBuilder()).append("#").append(claname).append("#").toString(), 206, 47, !bool_131);
                if(!bool_132 || bool_131)
                {
                    rd.drawString((new StringBuilder()).append("Clan :  ").append(claname).append("").toString(), 381 - ftm.stringWidth((new StringBuilder()).append("Clan :  ").append(claname).append("").toString()) / 2, 67);
                    if(i_129 != -1)
                    {
                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Edit Logo", 505, 74);
                        rd.drawLine(505, 76, 505 + ftm.stringWidth("Edit Logo"), 76);
                        if(i > 505 && i < 505 + ftm.stringWidth("Edit Logo") && i_83 > 62 && i_83 < 77 && editc == 0)
                        {
                            cur = 12;
                            if(bool)
                            {
                                editc = 1;
                                msg = "Edit Clan's Logo Image";
                                flko = 0;
                            }
                        }
                    }
                }
                rd.drawLine(563, 40, 563, 83);
                rd.drawLine(563, 83, 197, 83);
                if(stringbutton(rd, "   <   Back to Main  ", 688, 69, 1, i, i_83, bool, 0, 0))
                    cfase = 0;
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                int i_133 = 220;
                int i_134 = ftm.stringWidth("Members");
                if(ctab != 0)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                rd.drawString("Members", i_133, 107);
                if(ctab != 0)
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i > i_133 && i < i_133 + i_134 && i_83 > 90 && i_83 < 109 && editc == 0)
                {
                    rd.drawLine(i_133, 109, i_133 + i_134, 109);
                    cur = 12;
                    if(bool)
                        ctab = 0;
                }
                i_133 += i_134 + 20;
                i_134 = ftm.stringWidth("Cars");
                if(ctab != 2)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                rd.drawString("Cars", i_133, 107);
                if(ctab != 2)
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i > i_133 && i < i_133 + i_134 && i_83 > 90 && i_83 < 109 && editc == 0 && !notclan)
                {
                    rd.drawLine(i_133, 109, i_133 + i_134, 109);
                    cur = 12;
                    if(bool)
                    {
                        ctab = 2;
                        loadedcars = -1;
                    }
                }
                i_133 += i_134 + 20;
                i_134 = ftm.stringWidth("Stages");
                if(ctab != 3)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                rd.drawString("Stages", i_133, 107);
                if(ctab != 3)
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i > i_133 && i < i_133 + i_134 && i_83 > 90 && i_83 < 109 && editc == 0 && !notclan)
                {
                    rd.drawLine(i_133, 109, i_133 + i_134, 109);
                    cur = 12;
                    if(bool)
                    {
                        ctab = 3;
                        loadedstages = -1;
                    }
                }
                i_133 += i_134 + 20;
                i_134 = ftm.stringWidth("Interact");
                if(ctab != 1)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                rd.drawString("Interact", i_133, 107);
                if(ctab != 1)
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i > i_133 && i < i_133 + i_134 && i_83 > 90 && i_83 < 109 && editc == 0 && !notclan)
                {
                    rd.drawLine(i_133, 109, i_133 + i_134, 109);
                    cur = 12;
                    if(bool)
                        ctab = 1;
                }
                i_133 += i_134 + 20;
                i_134 = ftm.stringWidth("Web Presence");
                if(ctab != 4)
                    rd.setComposite(AlphaComposite.getInstance(3, 0.6F));
                rd.drawString("Web Presence", i_133, 107);
                if(ctab != 4)
                    rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                if(i > i_133 && i < i_133 + i_134 && i_83 > 90 && i_83 < 109 && editc == 0 && !notclan)
                {
                    rd.drawLine(i_133, 109, i_133 + i_134, 109);
                    cur = 12;
                    if(bool)
                    {
                        ctab = 4;
                        loadedlink = false;
                    }
                }
                rdo.setColor(new Color(206, 171, 98));
                rdo.fillRect(0, 0, 560, 300);
                if(clanbgl)
                    rdo.drawImage(clanbg, 0, 0, null);
                if(notclan)
                {
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.setFont(new Font("Arial", 1, 13));
                    ftm = rdo.getFontMetrics();
                    rdo.drawString("[  Clan Removed  ]", 280 - ftm.stringWidth("[  Clan Removed  ]") / 2, 40);
                    rdo.drawString("This clan has been abandoned by its members and no longer exists...", 280 - ftm.stringWidth("This clan has been abandoned by its members and no longer exists...") / 2, 140);
                }
                if(i_129 != -1 && i > 216 && i < 776 && i_83 > 92 && i_83 < 412 && editc == 0)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Edit Background", 688, 107);
                    rd.drawLine(688, 109, 688 + ftm.stringWidth("Edit Background"), 109);
                    if(i > 688 && i < 688 + ftm.stringWidth("Edit Background") && i_83 > 95 && i_83 < 110 && editc == 0)
                    {
                        cur = 12;
                        if(bool)
                        {
                            editc = 2;
                            msg = "Edit Clan's Background Display Image";
                            flko = 0;
                        }
                    }
                }
                if(ctab == 0)
                    if(!showreqs)
                    {
                        sdist = (int)(((float)nmb - 4F) * 55F);
                        if(sdist < 0 || nmb < 5)
                            sdist = 0;
                    } else
                    {
                        sdist = (int)(((float)nrmb - 4F) * 40F);
                        if(sdist < 0)
                            sdist = 0;
                    }
                if(ctab == 1 || ctab == 2 || ctab == 3 || ctab == 4)
                {
                    sdist = 0;
                    if(sdist < 0)
                        sdist = 0;
                }
                scro = (int)(((float)spos5 / 229F) * (float)sdist);
                if(ctab == 0)
                    if(!showreqs)
                    {
                        int i_135 = 0;
                        for(int i_136 = 0; i_136 < nmb; i_136++)
                        {
                            boolean bool_137 = false;
                            for(int i_138 = 0; i_138 < npo; i_138++)
                                if(member[i_136].toLowerCase().equals(pname[i_138].toLowerCase()))
                                {
                                    bool_137 = true;
                                    i_135++;
                                }

                            if((60 + i_136 * 55) - scro <= 0 || (20 + i_136 * 55) - scro >= 300)
                                continue;
                            int i_139 = 0;
                            float f = 0.5F;
                            if(i > 266 && i < 726 && i_83 > (132 + i_136 * 55) - scro && i_83 < (172 + i_136 * 55) - scro && editc == 0)
                            {
                                f = 0.8F;
                                if(i_136 >= i_129 && i_129 != -1)
                                    i_139 = 1;
                                if(xt.nickname.toLowerCase().equals(member[i_136].toLowerCase()) && i_139 == 0)
                                    i_139 = 2;
                            }
                            rdo.setComposite(AlphaComposite.getInstance(3, f));
                            rdo.setColor(new Color(255, 255, 255));
                            rdo.fillRoundRect(50, (20 + i_136 * 55) - scro, 460, 40, 20, 20);
                            rdo.setColor(new Color(0, 0, 0));
                            if(bool_137)
                                rdo.setColor(new Color(123, 200, 0));
                            rdo.drawRoundRect(50, (20 + i_136 * 55) - scro, 460, 40, 20, 20);
                            rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            boolean bool_140 = false;
                            boolean bool_141 = false;
                            if(i > 276 && i < 396 && i_83 > (137 + i_136 * 55) - scro && i_83 < (167 + i_136 * 55) - scro && i_83 > 112 && i_83 < 412 && editc == 0)
                            {
                                bool_141 = true;
                                cur = 12;
                                if(bool)
                                {
                                    tab = 1;
                                    if(!proname.equals(member[i_136]))
                                    {
                                        proname = member[i_136];
                                        loadedp = false;
                                        onexitpro();
                                    }
                                }
                            }
                            if(!bool_141)
                                bool_140 = drawl(rdo, member[i_136], 60, (25 + i_136 * 55) - scro, true);
                            else
                                drawl(rdo, member[i_136], 60, (25 + i_136 * 55) - scro, false);
                            if(!bool_140)
                            {
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.5F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRect(60, (25 + i_136 * 55) - scro, 119, 29);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.drawRect(60, (25 + i_136 * 55) - scro, 119, 29);
                                rdo.drawString(member[i_136], 120 - ftm.stringWidth(member[i_136]) / 2, (44 + i_136 * 55) - scro);
                            }
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.setFont(new Font("Arial", 1, 11));
                            ftm = rdo.getFontMetrics();
                            String string = "";
                            if(i_136 == 0)
                                string = "  ( Clan Leader / Admin )";
                            else
                            if(mlevel[i_136] == 7)
                                string = "  ( Admin )";
                            rdo.drawString((new StringBuilder()).append("Level :  ").append(mlevel[i_136]).append("").append(string).append("").toString(), 190, (36 + i_136 * 55) - scro);
                            rdo.drawString((new StringBuilder()).append("Rank :  ").append(mrank[i_136]).append("").toString(), 190, (52 + i_136 * 55) - scro);
                            if(i_139 != 0)
                            {
                                if(i_139 == 1)
                                {
                                    rdo.drawString("Edit", 424, (36 + i_136 * 55) - scro);
                                    rdo.drawLine(424, (38 + i_136 * 55) - scro, 424 + ftm.stringWidth("Edit"), (38 + i_136 * 55) - scro);
                                    if(i > 640 && i < 640 + ftm.stringWidth("Edit") && i_83 > (136 + i_136 * 55) - scro && i_83 < (151 + i_136 * 55) - scro && editc == 0)
                                    {
                                        cur = 12;
                                        if(bool)
                                        {
                                            em = i_136;
                                            editc = 3;
                                        }
                                    }
                                }
                                String string_142 = "Remove";
                                if(xt.nickname.toLowerCase().equals(member[i_136].toLowerCase()))
                                    string_142 = "Leave";
                                rdo.drawString(string_142, 454, (36 + i_136 * 55) - scro);
                                rdo.drawLine(454, (38 + i_136 * 55) - scro, 454 + ftm.stringWidth(string_142), (38 + i_136 * 55) - scro);
                                if(i <= 670 || i >= 670 + ftm.stringWidth(string_142) || i_83 <= (136 + i_136 * 55) - scro || i_83 >= (151 + i_136 * 55) - scro || editc != 0)
                                    continue;
                                cur = 12;
                                if(bool)
                                {
                                    em = i_136;
                                    editc = 4;
                                }
                                continue;
                            }
                            if(bool_137)
                            {
                                rdo.setColor(new Color(49, 79, 0));
                                rdo.drawString("Online", 454, (36 + i_136 * 55) - scro);
                            }
                        }

                        if(nmb == 1 && i_129 != -1)
                        {
                            float f = 0.5F;
                            if(i > 266 && i < 726 && i_83 > 187 - scro && i_83 < 287 - scro && editc == 0)
                                f = 0.8F;
                            rdo.setComposite(AlphaComposite.getInstance(3, f));
                            rdo.setColor(new Color(255, 255, 255));
                            rdo.fillRoundRect(50, 75 - scro, 460, 100, 20, 20);
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawRoundRect(50, 75 - scro, 460, 100, 20, 20);
                            rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            rdo.setFont(new Font("Arial", 1, 12));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString((new StringBuilder()).append("Welcome to your clan ").append(claname).append("!").toString(), 60, 91 - scro);
                            rdo.drawString("Now you will need to invite other players to join this clan.", 60, 121 - scro);
                            rdo.drawString("To invite, visit a player's profile and in the clan area click 'Invite to Join...'.", 60, 136 - scro);
                            rdo.drawString("(If the player is not already a member of another clan, of course).", 60, 151 - scro);
                            rdo.drawString("The maximum number of members a clan can have is 20.", 60, 166 - scro);
                        } else
                        if(nmb > 1)
                        {
                            rdo.setComposite(AlphaComposite.getInstance(3, 0.8F));
                            rdo.setColor(new Color(255, 255, 255));
                            rdo.fillRoundRect(212, (20 + nmb * 55) - scro, 136, 27, 20, 20);
                            rdo.setColor(new Color(0, 0, 0));
                            rdo.drawRoundRect(212, (20 + nmb * 55) - scro, 136, 27, 20, 20);
                            rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                            rdo.setFont(new Font("Arial", 1, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString((new StringBuilder()).append("").append(i_135).append(" player(s) online").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("").append(i_135).append(" player(s) online").toString()) / 2, (37 + nmb * 55) - scro);
                        }
                    } else
                    {
                        rdo.setComposite(AlphaComposite.getInstance(3, 0.8F));
                        rdo.setColor(new Color(244, 232, 204));
                        rdo.fillRoundRect(70, 20 - scro, 420, 80 + nrmb * 40, 20, 20);
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawRoundRect(70, 20 - scro, 420, 80 + nrmb * 40, 20, 20);
                        rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                        rdo.setFont(new Font("Arial", 1, 13));
                        ftm = rdo.getFontMetrics();
                        rdo.drawString("Membership Requests", 280 - ftm.stringWidth("Membership Requests") / 2, 45 - scro);
                        darker = true;
                        for(int i_143 = 0; i_143 < nrmb; i_143++)
                        {
                            boolean bool_144 = false;
                            boolean bool_145 = false;
                            if(i > 356 && i < 476 && i_83 > (172 + i_143 * 40) - scro && i_83 < (202 + i_143 * 55) - scro && i_83 > 112 && i_83 < 412 && editc == 0)
                            {
                                bool_145 = true;
                                cur = 12;
                                if(bool)
                                {
                                    tab = 1;
                                    if(!proname.equals(rmember[i_143]))
                                    {
                                        proname = rmember[i_143];
                                        loadedp = false;
                                        onexitpro();
                                    }
                                }
                            }
                            if(!bool_145)
                                bool_144 = drawl(rdo, rmember[i_143], 140, (60 + i_143 * 40) - scro, true);
                            else
                                drawl(rdo, rmember[i_143], 140, (60 + i_143 * 40) - scro, false);
                            if(!bool_144)
                            {
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.5F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRect(140, (60 + i_143 * 40) - scro, 119, 29);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.drawRect(140, (60 + i_143 * 40) - scro, 119, 29);
                                rdo.drawString(rmember[i_143], 200 - ftm.stringWidth(rmember[i_143]) / 2, (79 + i_143 * 40) - scro);
                            }
                            if(stringbutton(rdo, "  Approve  ", 310, (79 + i_143 * 40) - scro, 3, i, i_83, bool && editc == 0, 216, 112))
                            {
                                em = i_143;
                                editc = 66;
                            }
                            if(stringbutton(rdo, "  Deny  ", 391, (79 + i_143 * 40) - scro, 3, i, i_83, bool && editc == 0, 216, 112))
                            {
                                em = i_143;
                                editc = 77;
                            }
                        }

                        if(stringbutton(rdo, "    Decide Later    ", 280, (80 + nrmb * 40) - scro, 1, i, i_83, bool && editc == 0, 216, 112))
                        {
                            spos5 = 0;
                            lspos5 = 0;
                            showreqs = false;
                        }
                        darker = false;
                    }
                if(ctab == 1)
                {
                    rdo.setComposite(AlphaComposite.getInstance(3, 0.25F));
                    rdo.setColor(new Color(255, 255, 255));
                    rdo.fillRoundRect(20, 246, 520, 39, 20, 20);
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawRoundRect(20, 246, 520, 39, 20, 20);
                    rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    if(xt.clan.toLowerCase().equals(claname.toLowerCase()))
                    {
                        if(stringbutton(rdo, "       Open your clan's discussion       ", 280, 270, -1, i, i_83, bool && !gs.openm, 216, 112))
                        {
                            tab = 2;
                            itab = 2;
                            litab = -1;
                        }
                    } else
                    {
                        if(stringbutton(rdo, (new StringBuilder()).append("       Declare war on ").append(claname).append("       ").toString(), 162, 270, -1, i, i_83, bool && !gs.openm, 216, 112))
                        {
                            tab = 2;
                            itab = 1;
                            litab = -1;
                            openi = 10;
                            viewgame2 = 0;
                            if(!intclan.equals(claname))
                            {
                                intclan = claname;
                                dispi = 0;
                                nil = 0;
                                lastint = "";
                                readint = 1;
                            }
                            redif = true;
                            intsel = 4;
                        }
                        if(stringbutton(rdo, (new StringBuilder()).append("    Talk with ").append(claname).append("    ").toString(), 422, 270, -1, i, i_83, bool && !gs.openm, 216, 112))
                        {
                            tab = 2;
                            itab = 1;
                            litab = -1;
                            openi = 10;
                            viewgame2 = 0;
                            if(!intclan.equals(claname))
                            {
                                intclan = claname;
                                dispi = 0;
                                nil = 0;
                                lastint = "";
                                readint = 1;
                            }
                        }
                    }
                }
                if(ctab == 3)
                {
                    if(loadedstages != 1 && loadedstages != 5)
                    {
                        rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
                        rdo.setColor(new Color(255, 255, 255));
                        rdo.fillRoundRect(60, 70, 440, 100, 20, 20);
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawRoundRect(60, 70, 440, 100, 20, 20);
                        rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    }
                    rdo.setFont(new Font("Arial", 1, 12));
                    ftm = rdo.getFontMetrics();
                    if(loadedstages == -2)
                        rdo.drawString("Failed to load clan stages, connection error, try again later...", 280 - ftm.stringWidth("Failed to load clan stages, connection error, try again later...") / 2, 125);
                    if(loadedstages == -1)
                        rdo.drawString("Loading clan stages, please wait...", 280 - ftm.stringWidth("Loading clan stages, please wait...") / 2, 125);
                    if(loadedstages == 0)
                        rdo.drawString("No custom clan stages have been added yet!", 280 - ftm.stringWidth("No custom clan stages have been added yet!") / 2, 125);
                    if(loadedstages == 2)
                        rdo.drawString((new StringBuilder()).append("Searching for and loading stages created by you,  ").append(perry).append("  ...").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("Searching for and loading stages created by you,  ").append(perry).append("  ...").toString()) / 2, 125);
                    if(loadedstages == 3)
                    {
                        rdo.drawString("Found no stages that can be added!", 280 - ftm.stringWidth("Found no stages that can be added!") / 2, 95);
                        rdo.drawString("Found no stages created by you that also do not already belong to a clan.", 280 - ftm.stringWidth("Found no stages created by you that also do not already belong to a clan.") / 2, 115);
                        if(stringbutton(rdo, " OK ", 280, 155, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = -1;
                    }
                    if(loadedstages == 4)
                    {
                        rdo.drawString("Failed to load stages created by you, connection error, try again later...", 280 - ftm.stringWidth("Failed to load stages created by you, connection error, try again later...") / 2, 110);
                        if(stringbutton(rdo, " OK ", 280, 140, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = -1;
                    }
                    if(loadedstages == 6)
                        rdo.drawString("Adding stage to your clan's stages, please wait...", 280 - ftm.stringWidth("Adding stage to your clan's stages, please wait...") / 2, 125);
                    if(loadedstages == 7)
                    {
                        rdo.drawString("Failed to add stage, server error, try again later...", 280 - ftm.stringWidth("Failed to add stage, server error, try again later...") / 2, 110);
                        if(stringbutton(rdo, " OK ", 280, 140, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = -1;
                    }
                    if(loadedstages == 8)
                        rdo.drawString("Removing stage from your clan's cars, please wait...", 280 - ftm.stringWidth("Removing stage from your clan's cars, please wait...") / 2, 125);
                    if(loadedstages == 9)
                    {
                        rdo.drawString("Failed to remove stage, server error, try again later...", 280 - ftm.stringWidth("Failed to remove stage, server error, try again later...") / 2, 110);
                        if(stringbutton(rdo, " OK ", 280, 140, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = -1;
                    }
                    if(loadedstages == 10)
                    {
                        rdo.drawString("Are you sure you want to remove this stage from your clan's stages?", 280 - ftm.stringWidth("Are you sure you want to remove this stage from your clan's stages?") / 2, 93);
                        if(stringbutton(rdo, "    Yes    ", 280, 128, -2, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = 8;
                        if(stringbutton(rdo, "  No  ", 280, 158, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = 1;
                    }
                    if(loadedstages == 5)
                    {
                        rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
                        rdo.setColor(new Color(255, 255, 255));
                        rdo.fillRoundRect(60, 58, 440, 162, 20, 20);
                        rdo.setColor(new Color(0, 0, 0));
                        rdo.drawRoundRect(60, 58, 440, 162, 20, 20);
                        rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                        rdo.drawString("Select a stage to add.", 280 - ftm.stringWidth("Select a stage to add.") / 2, 80);
                        gs.clcars.move(496 - gs.clcars.getWidth() / 2, 206);
                        if(editc == 0)
                        {
                            if(!gs.clcars.isShowing())
                            {
                                gs.clcars.show();
                                gs.clcars.select(0);
                            }
                        } else
                        {
                            gs.clcars.hide();
                        }
                        if(!gs.clcars.getSelectedItem().equals(selstage))
                            selstage = gs.clcars.getSelectedItem();
                        if(gs.clcars.open)
                            blocknote = 20;
                        if(stringbutton(rdo, "     Add Stage     ", 280, 150, -2, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = 6;
                        if(stringbutton(rdo, "  Cancel  ", 280, 200, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedstages = -1;
                    }
                    if(loadedstages == 1)
                    {
                        if(editc == 0)
                        {
                            if(!gs.clcars.isShowing())
                            {
                                gs.clcars.show();
                                selstage = gs.clcars.getSelectedItem();
                            }
                        } else
                        {
                            gs.clcars.hide();
                        }
                        gs.clcars.move(496 - gs.clcars.getWidth() / 2, 122);
                        if(!gs.clcars.getSelectedItem().equals(selstage))
                        {
                            selstage = gs.clcars.getSelectedItem();
                            loadedstage = 0;
                            addstage = 0;
                        }
                        if(gs.clcars.open)
                            blocknote = 20;
                        if(!selstage.equals("Select Stage"))
                        {
                            if(loadedstage > 0)
                            {
                                m.trk = 3;
                                m.ih = 0;
                                m.iw = 0;
                                m.h = 300;
                                m.w = 560;
                                m.cx = 280;
                                m.cy = 150;
                                m.aroundtrack(cp);
                                rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                                int i_146 = 0;
                                int is[] = new int[200];
                                for(int i_147 = 0; i_147 < gs.nob; i_147++)
                                    if(co[i_147].dist != 0)
                                    {
                                        is[i_146] = i_147;
                                        i_146++;
                                    } else
                                    {
                                        co[i_147].d(rdo);
                                    }

                                int is_148[] = new int[i_146];
                                for(int i_149 = 0; i_149 < i_146; i_149++)
                                    is_148[i_149] = 0;

                                for(int i_150 = 0; i_150 < i_146; i_150++)
                                {
                                    for(int i_151 = i_150 + 1; i_151 < i_146; i_151++)
                                    {
                                        if(co[is[i_150]].dist != co[is[i_151]].dist)
                                        {
                                            if(co[is[i_150]].dist < co[is[i_151]].dist)
                                                is_148[i_150]++;
                                            else
                                                is_148[i_151]++;
                                            continue;
                                        }
                                        if(i_151 > i_150)
                                            is_148[i_150]++;
                                        else
                                            is_148[i_151]++;
                                    }

                                }

                                for(int i_152 = 0; i_152 < i_146; i_152++)
                                {
                                    for(int i_153 = 0; i_153 < i_146; i_153++)
                                        if(is_148[i_153] == i_152)
                                            co[is[i_153]].d(rdo);

                                }

                                rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                                m.trk = 0;
                                m.h = 450;
                                m.w = 800;
                                m.cx = 400;
                                m.cy = 225;
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.5F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRoundRect(9, 44, 136, 39, 20, 20);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Created/Published by", 17, 59);
                                int i_154 = (17 + ftm.stringWidth("Created/Published by") / 2) - ftm.stringWidth(cp.maker) / 2;
                                int i_155 = i_154 + ftm.stringWidth(cp.maker);
                                rdo.drawString(cp.maker, i_154, 74);
                                rdo.drawLine(i_154, 76, i_155, 76);
                                if(i > i_154 + 216 && i < i_155 + 216 && i_83 > 174 && i_83 < 188)
                                {
                                    cur = 12;
                                    if(bool)
                                    {
                                        tab = 1;
                                        if(!proname.equals(cp.maker))
                                        {
                                            proname = cp.maker;
                                            loadedp = false;
                                            onexitpro();
                                        }
                                    }
                                }
                                if((i_129 != -1 || cp.maker.toLowerCase().equals(xt.nickname.toLowerCase())) && stringbutton(rdo, " Remove X ", 510, 27, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    loadedstages = 10;
                                if(gs.clcars.getSelectedIndex() != gs.clcars.no - 1 && stringbutton(rdo, " Next > ", 520, 137, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    gs.clcars.sel++;
                                if(gs.clcars.getSelectedIndex() != 1 && stringbutton(rdo, " < Prev ", 40, 137, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    gs.clcars.sel--;
                                if(cp.pubt > 0)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    if(addstage == 2)
                                    {
                                        rd.drawString("Adding Stage...", 496 - ftm.stringWidth("Adding Stage...") / 2, 432);
                                        if(cd.staction == 0)
                                            addstage = 3;
                                        if(cd.staction == -2)
                                            addstage = 4;
                                        if(cd.staction == -3)
                                            addstage = 5;
                                        if(cd.staction == -1)
                                            addstage = 6;
                                    }
                                    if(addstage == 3)
                                        rd.drawString((new StringBuilder()).append("[").append(cd.onstage).append("] has been added to your stages!").toString(), 496 - ftm.stringWidth((new StringBuilder()).append("[").append(cd.onstage).append("] has been added to your stages!").toString()) / 2, 432);
                                    if(addstage == 4)
                                        rd.drawString("You already have this stage.", 496 - ftm.stringWidth("You already have this stage.") / 2, 432);
                                    if(addstage == 5)
                                        rd.drawString("Cannot add more then 20 stages to your account!", 496 - ftm.stringWidth("Cannot add more then 20 stages to your account!") / 2, 432);
                                    if(addstage == 6)
                                        rd.drawString("Failed to add stage!  Unknown error, please try again later.", 496 - ftm.stringWidth("Failed to add stage!  Unknown error, please try again later.") / 2, 432);
                                    if(addstage == 1)
                                    {
                                        String string = "Upgrade to a full account to add custom stages!";
                                        int i_156 = 496 - ftm.stringWidth(string) / 2;
                                        int i_157 = i_156 + ftm.stringWidth(string);
                                        rd.drawString(string, i_156, 432);
                                        if(waitlink != -1)
                                            rd.drawLine(i_156, 435, i_157, 435);
                                        if(i > i_156 && i < i_157 && i_83 > 421 && i_83 < 435)
                                        {
                                            if(waitlink != -1)
                                                cur = 12;
                                            if(bool && waitlink == 0)
                                            {
                                                gs.editlink(xt.nickname, true);
                                                waitlink = -1;
                                            }
                                        }
                                        if(waitlink > 0)
                                            waitlink--;
                                    }
                                    if(addstage == 0 && xt.drawcarb(true, null, " Add to My Stages ", 437, 414, i, i_83, bool && blocknote == 0))
                                        if(xt.logged)
                                        {
                                            cd.onstage = selstage;
                                            cd.staction = 2;
                                            cd.sparkstageaction();
                                            addstage = 2;
                                        } else
                                        {
                                            addstage = 1;
                                            waitlink = 20;
                                        }
                                } else
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("Private Stage", 496 - ftm.stringWidth("Private Stage") / 2, 432);
                                }
                            }
                            if(loadedstage == 0)
                            {
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRoundRect(150, 100, 260, 40, 20, 20);
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawRoundRect(150, 100, 260, 40, 20, 20);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Loading...", 280 - ftm.stringWidth("Loading...") / 2, 125);
                            }
                            if(loadedstage == -1)
                            {
                                rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
                                rdo.setColor(new Color(255, 255, 255));
                                rdo.fillRoundRect(50, 100, 460, 40, 20, 20);
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawRoundRect(50, 100, 460, 40, 20, 20);
                                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Error loading stage, try again later...", 280 - ftm.stringWidth("Error loading stage, try again later...") / 2, 125);
                            }
                        }
                    }
                    if(loadedstages != 1 && loadedstages != 5 && gs.clcars.isShowing())
                        gs.clcars.hide();
                    if(xt.clan.toLowerCase().equals(claname.toLowerCase()))
                    {
                        if(loadedstages >= 0 && loadedstages < 2 && stringbutton(rdo, "     Add a stage of yours to the clan's stages     ", 280, 286, -2, i, i_83, bool && !gs.openm, 216, 112))
                        {
                            loadedstages = 2;
                            perry = "0 %";
                        }
                    } else
                    if(loadedstages == 1 && !selstage.equals("Select Stage") && loadedstage > 0 && stringbutton(rdo, "     Battle with clan over this stage!     ", 280, 286, -2, i, i_83, bool && !gs.openm, 216, 112))
                    {
                        tab = 2;
                        itab = 1;
                        litab = -1;
                        openi = 10;
                        if(!intclan.equals(claname))
                        {
                            intclan = claname;
                            dispi = 0;
                            nil = 0;
                            lastint = "";
                            readint = 1;
                        }
                        redif = true;
                        intsel = 2;
                    }
                }
                if(ctab == 2)
                {
                    float f = 0.7F;
                    if(loadedcars == 1)
                        f = 0.5F;
                    rdo.setComposite(AlphaComposite.getInstance(3, f));
                    rdo.setColor(new Color(255, 255, 255));
                    rdo.fillRoundRect(40, 20, 480, 245, 20, 20);
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawRoundRect(40, 20, 480, 245, 20, 20);
                    rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    rdo.setFont(new Font("Arial", 1, 12));
                    ftm = rdo.getFontMetrics();
                    if(loadedcars == -2)
                        rdo.drawString("Failed to load clan cars, connection error, try again later...", 280 - ftm.stringWidth("Failed to load clan cars, connection error, try again later...") / 2, 125);
                    if(loadedcars == -1)
                        rdo.drawString("Loading clan cars, please wait...", 280 - ftm.stringWidth("Loading clan cars, please wait...") / 2, 125);
                    if(loadedcars == 0)
                        rdo.drawString("No custom clan cars have been added yet!", 280 - ftm.stringWidth("No custom clan cars have been added yet!") / 2, 125);
                    if(loadedcars == 2)
                        rdo.drawString((new StringBuilder()).append("Searching for and loading cars created by you,  ").append(perry).append("  ...").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("Searching for and loading cars created by you,  ").append(perry).append("  ...").toString()) / 2, 125);
                    if(loadedcars == 3)
                    {
                        rdo.drawString("Found no cars that can be added!", 280 - ftm.stringWidth("Found no cars that can be added!") / 2, 105);
                        rdo.drawString("Found no cars created by you that also do not already belong to a clan.", 280 - ftm.stringWidth("Found no cars created by you that also do not already belong to a clan.") / 2, 125);
                        if(stringbutton(rdo, " OK ", 280, 155, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = -1;
                    }
                    if(loadedcars == 4)
                    {
                        rdo.drawString("Failed to load cars created by you, connection error, try again later...", 280 - ftm.stringWidth("Failed to load cars created by you, connection error, try again later...") / 2, 125);
                        if(stringbutton(rdo, " OK ", 280, 155, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = -1;
                    }
                    if(loadedcars == 6)
                        rdo.drawString((new StringBuilder()).append("Adding ").append(selcar).append(" to your clan's cars, please wait...").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("Adding ").append(selcar).append(" to your clan's cars, please wait...").toString()) / 2, 125);
                    if(loadedcars == 7)
                    {
                        rdo.drawString("Failed to add car, server error, try again later...", 280 - ftm.stringWidth("Failed to add car, server error, try again later...") / 2, 125);
                        if(stringbutton(rdo, " OK ", 280, 155, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = -1;
                    }
                    if(loadedcars == 8)
                        rdo.drawString((new StringBuilder()).append("Removing ").append(selcar).append(" from your clan's cars, please wait...").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("Removing ").append(selcar).append(" from your clan's cars, please wait...").toString()) / 2, 125);
                    if(loadedcars == 9)
                    {
                        rdo.drawString("Failed to remove car, server error, try again later...", 280 - ftm.stringWidth("Failed to remove car, server error, try again later...") / 2, 125);
                        if(stringbutton(rdo, " OK ", 280, 155, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = -1;
                    }
                    if(loadedcars == 10)
                    {
                        rdo.drawString((new StringBuilder()).append("Are you sure you want to remove ").append(selcar).append(" from your clan's cars?").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("Are you sure you want to remove ").append(selcar).append(" from your clan's cars?").toString()) / 2, 100);
                        if(stringbutton(rdo, "    Yes    ", 280, 135, -2, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = 8;
                        if(stringbutton(rdo, "  No  ", 280, 165, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = 1;
                    }
                    if(loadedcars == 5)
                    {
                        rdo.drawString("Select a car to add.", 280 - ftm.stringWidth("Select a car to add.") / 2, 80);
                        gs.clcars.move(496 - gs.clcars.getWidth() / 2, 206);
                        if(editc == 0)
                        {
                            if(!gs.clcars.isShowing())
                            {
                                gs.clcars.show();
                                gs.clcars.select(0);
                            }
                        } else
                        {
                            gs.clcars.hide();
                        }
                        if(!gs.clcars.getSelectedItem().equals(selcar))
                            selcar = gs.clcars.getSelectedItem();
                        if(gs.clcars.open)
                            blocknote = 20;
                        if(stringbutton(rdo, "     Add Car     ", 280, 150, -2, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = 6;
                        if(stringbutton(rdo, "  Cancel  ", 280, 200, -3, i, i_83, bool && !gs.openm, 216, 112))
                            loadedcars = -1;
                    }
                    if(loadedcars == 1)
                    {
                        if(editc == 0)
                        {
                            if(!gs.clcars.isShowing())
                            {
                                gs.clcars.show();
                                selcar = gs.clcars.getSelectedItem();
                            }
                        } else
                        {
                            gs.clcars.hide();
                        }
                        gs.clcars.move(496 - gs.clcars.getWidth() / 2, 140);
                        if(!gs.clcars.getSelectedItem().equals(selcar))
                        {
                            selcar = gs.clcars.getSelectedItem();
                            loadedcar = 0;
                            cd.action = 0;
                        }
                        if(gs.clcars.open)
                            blocknote = 20;
                        if(!selcar.equals("Select Car"))
                        {
                            if(loadedcar > 0)
                            {
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Created/Published by", 63, 37);
                                int i_158 = (63 + ftm.stringWidth("Created/Published by") / 2) - ftm.stringWidth(cd.createdby[19 + cd.haltload]) / 2;
                                int i_159 = i_158 + ftm.stringWidth(cd.createdby[19 + cd.haltload]);
                                rdo.drawString(cd.createdby[19 + cd.haltload], i_158, 52);
                                rdo.drawLine(i_158, 54, i_159, 54);
                                if(i > i_158 + 216 && i < i_159 + 216 && i_83 > 152 && i_83 < 166)
                                {
                                    cur = 12;
                                    if(bool)
                                    {
                                        tab = 1;
                                        if(!proname.equals(cd.createdby[19 + cd.haltload]))
                                        {
                                            proname = cd.createdby[19 + cd.haltload];
                                            loadedp = false;
                                            onexitpro();
                                        }
                                    }
                                }
                                String string = "Class C";
                                if(cd.cclass[35 + cd.haltload] == 1)
                                    string = "Class B&C";
                                if(cd.cclass[35 + cd.haltload] == 2)
                                    string = "Class B";
                                if(cd.cclass[35 + cd.haltload] == 3)
                                    string = "Class A&B";
                                if(cd.cclass[35 + cd.haltload] == 4)
                                    string = "Class A";
                                rdo.drawString(string, 389 - ftm.stringWidth(string) / 2, 45);
                                if((i_129 != -1 || cd.createdby[19 + cd.haltload].toLowerCase().equals(xt.nickname.toLowerCase())) && stringbutton(rdo, " Remove X ", 466, 45, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    loadedcars = 10;
                                m.crs = true;
                                m.focus_point = 400;
                                m.x = -335;
                                m.y = 0;
                                m.z = -50;
                                m.xz = 0;
                                m.zy = 20;
                                m.ground = -2000;
                                m.cx = 280;
                                m.cy = 150;
                                bco[35 + cd.haltload].z = 1000;
                                bco[35 + cd.haltload].y = 480 - bco[35 + cd.haltload].grat;
                                bco[35 + cd.haltload].x = -52;
                                bco[35 + cd.haltload].zy = 0;
                                bco[35 + cd.haltload].xz = mrot;
                                mrot -= 5;
                                if(mrot < -360)
                                    mrot += 360;
                                bco[35 + cd.haltload].xy = 0;
                                bco[35 + cd.haltload].wzy -= 10;
                                if(bco[35 + cd.haltload].wzy < -45)
                                    bco[35 + cd.haltload].wzy += 45;
                                rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                                bco[35 + cd.haltload].d(rdo);
                                rdo.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                                m.cx = 400;
                                m.cy = 225;
                                int i_160 = 137;
                                if(xt.sc[0] == 35 + cd.haltload)
                                    i_160 = 255;
                                if(gs.clcars.getSelectedIndex() != gs.clcars.no - 1 && stringbutton(rdo, " Next > ", 476, i_160, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    gs.clcars.sel++;
                                if(gs.clcars.getSelectedIndex() != 1 && stringbutton(rdo, " < Prev ", 84, i_160, -3, i, i_83, bool && !gs.openm, 216, 112))
                                    gs.clcars.sel--;
                                if(xt.sc[0] != 35 + cd.haltload || i < 256 || i > 736 || i_83 < 132 || i_83 > 377)
                                {
                                    rdo.setFont(new Font("Arial", 1, 11));
                                    ftm = rdo.getFontMetrics();
                                    rdo.setColor(new Color(0, 0, 0));
                                    int i_161 = -36;
                                    int i_162 = -181;
                                    int i_163 = -155;
                                    rdo.drawString("Top Speed:", 98 + i_161, 343 + i_163);
                                    rdo.drawImage(xt.statb, 162 + i_161, 337 + i_163, null);
                                    rdo.drawString("Acceleration:", 88 + i_161, 358 + i_163);
                                    rdo.drawImage(xt.statb, 162 + i_161, 352 + i_163, null);
                                    rdo.drawString("Handling:", 110 + i_161, 373 + i_163);
                                    rdo.drawImage(xt.statb, 162 + i_161, 367 + i_163, null);
                                    rdo.drawString("Stunts:", 495 + i_162, 343 + i_163);
                                    rdo.drawImage(xt.statb, 536 + i_162, 337 + i_163, null);
                                    rdo.drawString("Strength:", 483 + i_162, 358 + i_163);
                                    rdo.drawImage(xt.statb, 536 + i_162, 352 + i_163, null);
                                    rdo.drawString("Endurance:", 473 + i_162, 373 + i_163);
                                    rdo.drawImage(xt.statb, 536 + i_162, 367 + i_163, null);
                                    rdo.setColor(new Color(0, 0, 0));
                                    float f_164 = (float)(cd.swits[35 + cd.haltload][2] - 220) / 90F;
                                    if((double)f_164 < 0.20000000000000001D)
                                        f_164 = 0.2F;
                                    rdo.fillRect((int)(162F + 156F * f_164) + i_161, 337 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    f_164 = (cd.acelf[35 + cd.haltload][1] * cd.acelf[35 + cd.haltload][0] * cd.acelf[35 + cd.haltload][2] * cd.grip[35 + cd.haltload]) / 7700F;
                                    if(f_164 > 1.0F)
                                        f_164 = 1.0F;
                                    rdo.fillRect((int)(162F + 156F * f_164) + i_161, 352 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    f_164 = cd.dishandle[35 + cd.haltload];
                                    rdo.fillRect((int)(162F + 156F * f_164) + i_161, 367 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    f_164 = ((float)cd.airc[35 + cd.haltload] * cd.airs[35 + cd.haltload] * cd.bounce[35 + cd.haltload] + 28F) / 139F;
                                    if(f_164 > 1.0F)
                                        f_164 = 1.0F;
                                    rdo.fillRect((int)(536F + 156F * f_164) + i_162, 337 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    float f_165 = 0.5F;
                                    f_164 = (cd.moment[35 + cd.haltload] + f_165) / 2.6F;
                                    if(f_164 > 1.0F)
                                        f_164 = 1.0F;
                                    rdo.fillRect((int)(536F + 156F * f_164) + i_162, 352 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    f_164 = cd.outdam[35 + cd.haltload];
                                    rdo.fillRect((int)(536F + 156F * f_164) + i_162, 367 + i_163, (int)(156F * (1.0F - f_164) + 1.0F), 7);
                                    rdo.drawImage(xt.statbo, 162 + i_161, 337 + i_163, null);
                                    rdo.drawImage(xt.statbo, 162 + i_161, 352 + i_163, null);
                                    rdo.drawImage(xt.statbo, 162 + i_161, 367 + i_163, null);
                                    rdo.drawImage(xt.statbo, 536 + i_162, 337 + i_163, null);
                                    rdo.drawImage(xt.statbo, 536 + i_162, 352 + i_163, null);
                                    rdo.drawImage(xt.statbo, 536 + i_162, 367 + i_163, null);
                                } else
                                {
                                    int i_166 = -20;
                                    int i_167 = -220;
                                    rdo.setFont(new Font("Arial", 1, 10));
                                    ftm = rd.getFontMetrics();
                                    rdo.drawString("Hue  | ", 97 + i_166, 70);
                                    rdo.drawImage(xt.brt, 137 + i_166, 63, null);
                                    rdo.drawString("Intensity", 121 + i_166, 219);
                                    rdo.drawString("Hue  | ", 647 + i_167, 70);
                                    rdo.drawImage(xt.brt, 687 + i_167, 63, null);
                                    rdo.drawString("Intensity", 671 + i_167, 219);
                                    for(int i_168 = 0; i_168 < 161; i_168++)
                                    {
                                        rdo.setColor(Color.getHSBColor((float)((double)(float)i_168 * 0.0062500000000000003D), 1.0F, 1.0F));
                                        rdo.drawLine(102 + i_166, 75 + i_168, 110 + i_166, 75 + i_168);
                                        if(i_168 <= 128)
                                        {
                                            rdo.setColor(Color.getHSBColor(1.0F, 0.0F, (float)(1.0D - (double)(float)i_168 * 0.0062500000000000003D)));
                                            rdo.drawLine(137 + i_166, 75 + i_168, 145 + i_166, 75 + i_168);
                                        }
                                        rdo.setColor(Color.getHSBColor((float)((double)(float)i_168 * 0.0062500000000000003D), 1.0F, 1.0F));
                                        rdo.drawLine(652 + i_167, 75 + i_168, 660 + i_167, 75 + i_168);
                                        if(i_168 <= 128)
                                        {
                                            rdo.setColor(Color.getHSBColor(1.0F, 0.0F, (float)(1.0D - (double)(float)i_168 * 0.0062500000000000003D)));
                                            rdo.drawLine(687 + i_167, 75 + i_168, 695 + i_167, 75 + i_168);
                                        }
                                    }

                                    for(int i_169 = 0; i_169 < 40; i_169++)
                                    {
                                        rdo.setColor(Color.getHSBColor(xt.arnp[0], (float)((double)(float)i_169 * 0.025000000000000001D), 1.0F - xt.arnp[2]));
                                        rdo.drawLine(121 + i_169 + i_166, 224, 121 + i_169 + i_166, 230);
                                        rdo.setColor(Color.getHSBColor(xt.arnp[3], (float)((double)(float)i_169 * 0.025000000000000001D), 1.0F - xt.arnp[5]));
                                        rdo.drawLine(671 + i_169 + i_167, 224, 671 + i_169 + i_167, 230);
                                    }

                                    rdo.drawImage(xt.arn, 110 + i_166, 71 + (int)(xt.arnp[0] * 160F), null);
                                    rdo.drawImage(xt.arn, 145 + i_166, 71 + (int)(xt.arnp[2] * 160F), null);
                                    rdo.drawImage(xt.arn, 660 + i_167, 71 + (int)(xt.arnp[3] * 160F), null);
                                    rdo.drawImage(xt.arn, 695 + i_167, 71 + (int)(xt.arnp[5] * 160F), null);
                                    rdo.setColor(new Color(0, 0, 0));
                                    rdo.fillRect(120 + i_166 + (int)(xt.arnp[1] * 40F), 222, 3, 3);
                                    rdo.drawLine(121 + i_166 + (int)(xt.arnp[1] * 40F), 224, 121 + i_166 + (int)(xt.arnp[1] * 40F), 230);
                                    rdo.fillRect(120 + i_166 + (int)(xt.arnp[1] * 40F), 230, 3, 3);
                                    rdo.fillRect(670 + i_167 + (int)(xt.arnp[4] * 40F), 222, 3, 3);
                                    rdo.drawLine(671 + i_167 + (int)(xt.arnp[4] * 40F), 224, 671 + i_167 + (int)(xt.arnp[4] * 40F), 230);
                                    rdo.fillRect(670 + i_167 + (int)(xt.arnp[4] * 40F), 230, 3, 3);
                                    if(bool)
                                    {
                                        if(mouson == -1)
                                        {
                                            mouson = -2;
                                            if(i > 335 + i_166 && i < 379 + i_166 && i_83 > 334 && i_83 < 344)
                                                mouson = 1;
                                            if(i > 885 + i_167 && i < 929 + i_167 && i_83 > 334 && i_83 < 344)
                                                mouson = 4;
                                            if(i > 314 + i_166 && i < 338 + i_166 && i_83 > 181 && i_83 < 353 && mouson == -2)
                                                mouson = 0;
                                            if(i > 349 + i_166 && i < 373 + i_166 && i_83 > 181 && i_83 < 321 && mouson == -2)
                                                mouson = 2;
                                            if(i > 864 + i_167 && i < 888 + i_167 && i_83 > 181 && i_83 < 353 && mouson == -2)
                                                mouson = 3;
                                            if(i > 899 + i_167 && i < 923 + i_167 && i_83 > 181 && i_83 < 321 && mouson == -2)
                                                mouson = 5;
                                        }
                                    } else
                                    if(mouson != -1)
                                        mouson = -1;
                                    if(mouson >= 0 && mouson <= 5)
                                        blocknote = 20;
                                    if(mouson == 0 || mouson == 2 || mouson == 3 || mouson == 5)
                                    {
                                        xt.arnp[mouson] = (float)((double)((float)i_83 - 187F) * 0.0062500000000000003D);
                                        if(mouson == 2 || mouson == 5)
                                        {
                                            if((double)xt.arnp[mouson] > 0.80000000000000004D)
                                                xt.arnp[mouson] = 0.8F;
                                        } else
                                        if(xt.arnp[mouson] > 1.0F)
                                            xt.arnp[mouson] = 1.0F;
                                        if(xt.arnp[mouson] < 0.0F)
                                            xt.arnp[mouson] = 0.0F;
                                    }
                                    if(mouson == 1)
                                    {
                                        xt.arnp[mouson] = (float)((double)((float)i - (float)(337 + i_166)) * 0.025000000000000001D);
                                        if(xt.arnp[mouson] > 1.0F)
                                            xt.arnp[mouson] = 1.0F;
                                        if(xt.arnp[mouson] < 0.0F)
                                            xt.arnp[mouson] = 0.0F;
                                    }
                                    if(mouson == 4)
                                    {
                                        xt.arnp[mouson] = (float)((double)((float)i - (float)(887 + i_167)) * 0.025000000000000001D);
                                        if(xt.arnp[mouson] > 1.0F)
                                            xt.arnp[mouson] = 1.0F;
                                        if(xt.arnp[mouson] < 0.0F)
                                            xt.arnp[mouson] = 0.0F;
                                    }
                                    Color color = Color.getHSBColor(xt.arnp[0], xt.arnp[1], 1.0F - xt.arnp[2]);
                                    Color color_170 = Color.getHSBColor(xt.arnp[3], xt.arnp[4], 1.0F - xt.arnp[5]);
                                    for(int i_171 = 0; i_171 < bco[36].npl; i_171++)
                                    {
                                        if(bco[36].p[i_171].colnum == 1)
                                        {
                                            bco[36].p[i_171].hsb[0] = xt.arnp[0];
                                            bco[36].p[i_171].hsb[1] = xt.arnp[1];
                                            bco[36].p[i_171].hsb[2] = 1.0F - xt.arnp[2];
                                            bco[36].p[i_171].c[0] = color.getRed();
                                            bco[36].p[i_171].c[1] = color.getGreen();
                                            bco[36].p[i_171].c[2] = color.getBlue();
                                            bco[36].p[i_171].oc[0] = color.getRed();
                                            bco[36].p[i_171].oc[1] = color.getGreen();
                                            bco[36].p[i_171].oc[2] = color.getBlue();
                                        }
                                        if(bco[36].p[i_171].colnum == 2)
                                        {
                                            bco[36].p[i_171].hsb[0] = xt.arnp[3];
                                            bco[36].p[i_171].hsb[1] = xt.arnp[4];
                                            bco[36].p[i_171].hsb[2] = 1.0F - xt.arnp[5];
                                            bco[36].p[i_171].c[0] = color_170.getRed();
                                            bco[36].p[i_171].c[1] = color_170.getGreen();
                                            bco[36].p[i_171].c[2] = color_170.getBlue();
                                            bco[36].p[i_171].oc[0] = color_170.getRed();
                                            bco[36].p[i_171].oc[1] = color_170.getGreen();
                                            bco[36].p[i_171].oc[2] = color_170.getBlue();
                                        }
                                    }

                                    if(stringbutton(rdo, "    Play >    ", 280, 220, -1, i, i_83, bool && !gs.openm, 216, 112))
                                    {
                                        open = 450;
                                        upo = false;
                                        domon = false;
                                        onexit();
                                    }
                                }
                                if(xt.clan.toLowerCase().equals(claname.toLowerCase()))
                                    if(xt.sc[0] != 36)
                                    {
                                        if(stringbutton(rdo, "     Switch to using clan cars     ", 280, 250, -2, i, i_83, bool && !gs.openm, 216, 112))
                                        {
                                            xt.sc[0] = 36;
                                            boolean bool_172 = false;
                                            for(int i_173 = 0; i_173 < bco[36].npl && !bool_172; i_173++)
                                                if(bco[36].p[i_173].colnum == 1)
                                                {
                                                    float fs[] = new float[3];
                                                    Color.RGBtoHSB(bco[36].p[i_173].c[0], bco[36].p[i_173].c[1], bco[36].p[i_173].c[2], fs);
                                                    xt.arnp[0] = fs[0];
                                                    xt.arnp[1] = fs[1];
                                                    xt.arnp[2] = 1.0F - fs[2];
                                                    bool_172 = true;
                                                }

                                            bool_172 = false;
                                            for(int i_174 = 0; i_174 < bco[36].npl && !bool_172; i_174++)
                                                if(bco[36].p[i_174].colnum == 2)
                                                {
                                                    float fs[] = new float[3];
                                                    Color.RGBtoHSB(bco[36].p[i_174].c[0], bco[36].p[i_174].c[1], bco[36].p[i_174].c[2], fs);
                                                    xt.arnp[3] = fs[0];
                                                    xt.arnp[4] = fs[1];
                                                    xt.arnp[5] = 1.0F - fs[2];
                                                    bool_172 = true;
                                                }

                                        }
                                    } else
                                    {
                                        rdo.setFont(new Font("Arial", 1, 12));
                                        ftm = rdo.getFontMetrics();
                                        rdo.setColor(new Color(0, 0, 0));
                                        rdo.drawString("You are currently using your clan's cars.", 280 - ftm.stringWidth("You are currently using your clan's cars.") / 2, 250);
                                    }
                                if(cd.publish[19 + cd.haltload] > 0)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    if(cd.action == -9)
                                        rd.drawString("Failed to add car!  Unknown error, please try again later.", 496 - ftm.stringWidth("Failed to add car!  Unknown error, please try again later.") / 2, 432);
                                    if(cd.action == -8)
                                        rd.drawString("Cannot add more then 20 cars to your account!", 496 - ftm.stringWidth("Cannot add more then 20 cars to your account!") / 2, 432);
                                    if(cd.action == 7)
                                        rd.drawString((new StringBuilder()).append("[").append(cd.acname).append("] has been added to your cars!").toString(), 496 - ftm.stringWidth((new StringBuilder()).append("[").append(cd.acname).append("] has been added to your cars!").toString()) / 2, 432);
                                    if(cd.action == -7)
                                        rd.drawString("You already have this car.", 496 - ftm.stringWidth("You already have this car.") / 2, 432);
                                    if(cd.action == 6)
                                        rd.drawString("Adding Car...", 496 - ftm.stringWidth("Adding Car...") / 2, 432);
                                    if(cd.action == -6)
                                    {
                                        String string_175 = "Upgrade to a full account to add custom cars!";
                                        int i_176 = 496 - ftm.stringWidth(string_175) / 2;
                                        int i_177 = i_176 + ftm.stringWidth(string_175);
                                        rd.drawString(string_175, i_176, 432);
                                        if(waitlink != -1)
                                            rd.drawLine(i_176, 435, i_177, 435);
                                        if(i > i_176 && i < i_177 && i_83 > 421 && i_83 < 435)
                                        {
                                            if(waitlink != -1)
                                                cur = 12;
                                            if(bool && waitlink == 0)
                                            {
                                                gs.editlink(xt.nickname, true);
                                                waitlink = -1;
                                            }
                                        }
                                        if(waitlink > 0)
                                            waitlink--;
                                    }
                                    if(cd.action == 0 && xt.drawcarb(true, null, " Add to My Cars ", 437, 414, i, i_83, bool && blocknote == 0))
                                        if(xt.logged)
                                        {
                                            cd.action = 6;
                                            cd.ac = -1;
                                            cd.acname = selcar;
                                            cd.sparkactionloader();
                                        } else
                                        {
                                            cd.action = -6;
                                            waitlink = 20;
                                        }
                                } else
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString("Private Car", 496 - ftm.stringWidth("Private Car") / 2, 432);
                                }
                            }
                            if(loadedcar == 0)
                            {
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Loading...", 280 - ftm.stringWidth("Loading...") / 2, 125);
                            }
                            if(loadedcar == -1)
                            {
                                rdo.setFont(new Font("Arial", 1, 12));
                                ftm = rdo.getFontMetrics();
                                rdo.setColor(new Color(0, 0, 0));
                                rdo.drawString("Error loading car, try again later...", 280 - ftm.stringWidth("Error loading car, try again later...") / 2, 125);
                            }
                        }
                    }
                    if(loadedcars != 1 && loadedcars != 5 && gs.clcars.isShowing())
                        gs.clcars.hide();
                    if(xt.clan.toLowerCase().equals(claname.toLowerCase()))
                    {
                        if(loadedcars >= 0 && loadedcars < 2 && stringbutton(rdo, "     Add a car of yours to the clan's cars     ", 280, 286, -2, i, i_83, bool && !gs.openm, 216, 112))
                        {
                            loadedcars = 2;
                            perry = "0 %";
                        }
                    } else
                    if(loadedcars == 1 && !selcar.equals("Select Car") && loadedcar > 0 && stringbutton(rdo, "     Battle with clan over this car!     ", 280, 286, -2, i, i_83, bool && !gs.openm, 216, 112))
                    {
                        tab = 2;
                        itab = 1;
                        litab = -1;
                        openi = 10;
                        if(!intclan.equals(claname))
                        {
                            intclan = claname;
                            dispi = 0;
                            nil = 0;
                            lastint = "";
                            readint = 1;
                        }
                        redif = true;
                        intsel = 3;
                    }
                }
                if(ctab != 2 && ctab != 3 && gs.clcars.isShowing())
                    gs.clcars.hide();
                if(ctab == 4)
                {
                    boolean bool_178 = false;
                    if(i > 266 && i < 726 && i_83 > 162 && i_83 < 223 && editc == 0)
                        bool_178 = true;
                    rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
                    rdo.setColor(new Color(255, 255, 255));
                    rdo.fillRoundRect(50, 50, 460, 61, 20, 20);
                    rdo.setColor(new Color(0, 0, 0));
                    rdo.drawRoundRect(50, 50, 460, 61, 20, 20);
                    rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    if(loadedlink)
                    {
                        if(i_129 != -1 && bool_178)
                        {
                            rdo.setFont(new Font("Arial", 1, 11));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString("Edit", 480, 66);
                            rdo.drawLine(480, 68, 480 + ftm.stringWidth("Edit"), 68);
                            if(i > 696 && i < 696 + ftm.stringWidth("Edit") && i_83 > 166 && i_83 < 181 && editc == 0)
                            {
                                cur = 12;
                                if(bool)
                                {
                                    editc = 6;
                                    msg = "Edit Clan's Web Presence";
                                    flko = 0;
                                    bool = false;
                                }
                            }
                        }
                        if(!ltit.equals("") && !lurl.equals(""))
                        {
                            rdo.setFont(new Font("Arial", 1, 13));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString(ltit, 70, 74);
                            if(bool_178)
                                rdo.drawLine(70, 76, 70 + ftm.stringWidth(ltit), 76);
                            rdo.setFont(new Font("Arial", 0, 12));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString(ldes, 70, 94);
                            if(bool_178 && editc == 0)
                            {
                                cur = 12;
                                if(bool)
                                    gs.openurl(lurl);
                            }
                        } else
                        {
                            rdo.setFont(new Font("Arial", 1, 12));
                            ftm = rdo.getFontMetrics();
                            rdo.drawString((new StringBuilder()).append("").append(claname).append(" has no external online presence.").toString(), 280 - ftm.stringWidth((new StringBuilder()).append("").append(claname).append(" has no external online presence.").toString()) / 2, 85);
                        }
                    } else
                    {
                        rdo.setFont(new Font("Arial", 1, 12));
                        ftm = rdo.getFontMetrics();
                        rdo.drawString("Loading...", 280 - ftm.stringWidth("Loading...") / 2, 85);
                    }
                }
                if(sdist != 0)
                {
                    rdo.setColor(color2k(200, 200, 200));
                    rdo.fillRect(540, 20, 17, 260);
                    if(mscro5 == 831)
                    {
                        rdo.setColor(color2k(215, 215, 215));
                        rdo.fillRect(540, 3, 17, 17);
                    } else
                    {
                        rdo.setColor(color2k(220, 220, 220));
                        rdo.fill3DRect(540, 3, 17, 17, true);
                    }
                    rdo.drawImage(xt.asu, 545, 9, null);
                    if(mscro5 == 832)
                    {
                        rdo.setColor(color2k(215, 215, 215));
                        rdo.fillRect(540, 280, 17, 17);
                    } else
                    {
                        rdo.setColor(color2k(220, 220, 220));
                        rdo.fill3DRect(540, 280, 17, 17, true);
                    }
                    rdo.drawImage(xt.asd, 545, 287, null);
                    if(lspos5 != spos5)
                    {
                        rdo.setColor(color2k(215, 215, 215));
                        rdo.fillRect(540, 20 + spos5, 17, 31);
                    } else
                    {
                        if(mscro5 == 831)
                            rdo.setColor(color2k(215, 215, 215));
                        rdo.fill3DRect(540, 20 + spos5, 17, 31, true);
                    }
                    rdo.setColor(color2k(150, 150, 150));
                    rdo.drawLine(545, 33 + spos5, 551, 33 + spos5);
                    rdo.drawLine(545, 35 + spos5, 551, 35 + spos5);
                    rdo.drawLine(545, 37 + spos5, 551, 37 + spos5);
                    if(mscro5 > 800 && lspos5 != spos5)
                        lspos5 = spos5;
                    if(bool)
                    {
                        if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 + spos5 && i_83 < spos5 + 163)
                            mscro5 = i_83 - spos5;
                        if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 26 && i_83 < 134)
                            mscro5 = 831;
                        if(mscro5 == 825 && i > 754 && i < 775 && i_83 > 390 && i_83 < 411)
                            mscro5 = 832;
                        if(mscro5 == 825 && i > 756 && i < 773 && i_83 > 132 && i_83 < 392)
                        {
                            mscro5 = 152;
                            spos5 = i_83 - mscro5;
                        }
                        int i_179 = 2670 / sdist;
                        if(i_179 < 1)
                            i_179 = 1;
                        if(mscro5 == 831)
                        {
                            spos5 -= i_179;
                            if(spos5 > 229)
                                spos5 = 229;
                            if(spos5 < 0)
                                spos5 = 0;
                            lspos5 = spos5;
                        }
                        if(mscro5 == 832)
                        {
                            spos5 += i_179;
                            if(spos5 > 229)
                                spos5 = 229;
                            if(spos5 < 0)
                                spos5 = 0;
                            lspos5 = spos5;
                        }
                        if(mscro5 < 800)
                        {
                            spos5 = i_83 - mscro5;
                            if(spos5 > 229)
                                spos5 = 229;
                            if(spos5 < 0)
                                spos5 = 0;
                        }
                        if(mscro5 == 825)
                            mscro5 = 925;
                    } else
                    if(mscro5 != 825)
                        mscro5 = 825;
                }
                rd.drawImage(gImage, 216, 112, null);
                if(ctab != 2 && ctab != 3 && xt.clan.equals(""))
                {
                    boolean bool_180 = false;
                    int i_181 = 0;
                    do
                    {
                        if(i_181 >= nmb)
                            break;
                        if(xt.nickname.toLowerCase().equals(member[i_181].toLowerCase()))
                        {
                            bool_180 = true;
                            break;
                        }
                        i_181++;
                    } while(true);
                    if(!bool_180)
                    {
                        boolean bool_182 = false;
                        int i_183 = 0;
                        do
                        {
                            if(i_183 >= nrmb)
                                break;
                            if(xt.nickname.toLowerCase().equals(rmember[i_183].toLowerCase()))
                            {
                                bool_182 = true;
                                break;
                            }
                            i_183++;
                        } while(true);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        if(!bool_182)
                        {
                            if(stringbutton(rd, "      Request to Join this Clan      ", 496, 432, 3, i, i_83, bool && !gs.openm, 0, 0))
                                if(xt.logged)
                                    editc = 99;
                                else
                                    editc = 101;
                            int i_184 = ftm.stringWidth("      Request to Join this Clan      ");
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(496 - i_184 / 2 - 20, 415, i_184 + 40, 24, 20, 20);
                        } else
                        {
                            int i_185 = ftm.stringWidth("You have requested to join this clan, waiting for admin to approve your membership.");
                            rd.drawString("You have requested to join this clan, waiting for admin to approve your membership.", 496 - i_185 / 2, 432);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawRoundRect(496 - i_185 / 2 - 20, 415, i_185 + 40, 24, 20, 20);
                        }
                    }
                }
                if(editc == 1 || editc == 2)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(265, 92, 460, 220, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(265, 92, 460, 220, 20, 20);
                    String strings[] = {
                        "logo", "350x30", "35 : 3"
                    };
                    if(editc == 2)
                    {
                        strings[0] = "background";
                        strings[1] = "560x300";
                        strings[2] = "56 : 30";
                    }
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    if(flko % 4 != 0 || flko == 0)
                        rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 115);
                    if(flko != 0)
                        flko--;
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString((new StringBuilder()).append("The ").append(strings[0]).append(" image is ").append(strings[1]).append(" pixels.").toString(), 275, 140);
                    rd.drawString("Any image uploaded will be resized to that width and height. For the best results", 275, 160);
                    rd.drawString((new StringBuilder()).append("try to upload an image that is bigger or equal to ").append(strings[1]).append(" and has the scale of").toString(), 275, 180);
                    rd.drawString((new StringBuilder()).append("[ ").append(strings[2]).append(" ]  in  [ Width : Height ].").toString(), 275, 200);
                    rd.drawString("Image uploaded must be less than 1MB and in the format of JPEG, GIF or PNG.", 275, 220);
                    if(upload == 0)
                    {
                        if(stringbutton(rd, "  Upload Image  ", 495, 250, 0, i, i_83, bool, 0, 0))
                        {
                            FileDialog filedialog = new FileDialog(new Frame(), "Upload Image");
                            filedialog.setMode(0);
                            filedialog.setVisible(true);
                            filename = (new StringBuilder()).append("").append(filedialog.getDirectory()).append("").append(filedialog.getFile()).append("").toString();
                            if(!filename.equals("nullnull"))
                                upload = 1;
                        }
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        if(upload == 1)
                            rd.drawString("Checking image...", 495 - ftm.stringWidth("Checking image...") / 2, 250);
                        if(upload == 2)
                            rd.drawString("Authenticating...", 495 - ftm.stringWidth("Authenticating...") / 2, 250);
                        if(upload == 3)
                            rd.drawString((new StringBuilder()).append("Uploading image :  ").append(perc).append(" %").toString(), 495 - ftm.stringWidth("Uploading image :  80 %") / 2, 250);
                        if(upload == 4)
                            rd.drawString("Creating image online...", 495 - ftm.stringWidth("Creating image online...") / 2, 250);
                        if(upload == 5)
                            rd.drawString("Done", 495 - ftm.stringWidth("Done") / 2, 250);
                    }
                    if(stringbutton(rd, " Cancel ", 495, 290, 2, i, i_83, bool, 0, 0))
                        if(upload == 0)
                            editc = 0;
                        else
                            upload = 0;
                }
                if(editc == 3)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(245, 92, 500, 190, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(245, 92, 500, 190, 20, 20);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    String string = (new StringBuilder()).append("").append(member[em]).append("'s").toString();
                    if(xt.nickname.toLowerCase().equals(member[em].toLowerCase()))
                        string = "Your";
                    rd.drawString((new StringBuilder()).append("Edit ").append(string).append(" Clan Membership").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Edit ").append(string).append("'s Clan Membership").toString()) / 2, 115);
                    rd.drawString("Rank Description :", 399 - ftm.stringWidth("Membership Level :"), 146);
                    dorank = true;
                    rd.drawString("Membership Level :", 503 - ftm.stringWidth("Membership Level :"), 176);
                    gs.clanlev.move(513, 159);
                    if(!gs.clanlev.isShowing())
                    {
                        gs.clanlev.select(mlevel[em] - 1);
                        if(em == 0 && mlevel[em] == 7)
                            gs.clanlev.disable();
                        else
                            gs.clanlev.enable();
                        gs.clanlev.show();
                    }
                    if(stringbutton(rd, "     Save     ", 495, 220, 0, i, i_83, bool, 0, 0))
                    {
                        gs.clanlev.hide();
                        editc = 33;
                    }
                    if(stringbutton(rd, " Cancel ", 495, 260, 2, i, i_83, bool, 0, 0))
                    {
                        editc = 0;
                        gs.clanlev.hide();
                    }
                }
                if(editc == 4)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(220, 92, 550, 155, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(220, 92, 550, 155, 20, 20);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    String string = (new StringBuilder()).append("").append(member[em]).append("").toString();
                    if(xt.nickname.toLowerCase().equals(member[em].toLowerCase()))
                        string = "yourself";
                    rd.drawString((new StringBuilder()).append("Are you sure you want to remove ").append(string).append(" from the clan?").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Are you sure you want to remove ").append(string).append(" from the clan?").toString()) / 2, 120);
                    if(xt.nickname.toLowerCase().equals(member[em].toLowerCase()) && em == 0)
                    {
                        rd.setFont(new Font("Arial", 0, 12));
                        ftm = rd.getFontMetrics();
                        if(nmb > 1)
                            rd.drawString((new StringBuilder()).append("Note: This will result in the second high ranking player (").append(member[1]).append(") becoming the new Clan Leader!").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Note: This will result in the second high ranking player (").append(member[1]).append(") becoming the new Clan Leader!").toString()) / 2, 140);
                        else
                            rd.drawString("Note: This will result in the deletion of this clan since you are the only player in it.", 495 - ftm.stringWidth("Note: This will result in the deletion of this clan since you are the only player in it.") / 2, 140);
                    }
                    if(stringbutton(rd, "     Yes     ", 495, 185, 0, i, i_83, bool, 0, 0))
                        editc = 44;
                    if(stringbutton(rd, " No, Cancel ", 495, 225, 2, i, i_83, bool, 0, 0))
                        editc = 0;
                }
                if(editc == 6)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(245, 92, 500, 225, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(245, 92, 500, 225, 20, 20);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    if(flko % 4 != 0 || flko == 0)
                        rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 115);
                    if(flko != 0)
                        flko--;
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString("Does your clan have an online forum, a Facebook group, a website or any online", 255, 140);
                    rd.drawString("presence at all beyond the game?  If so, you can link to it from here!", 255, 160);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Link Title :", 400 - ftm.stringWidth("Link Title :"), 190);
                    rd.drawString("Link Description :", 400 - ftm.stringWidth("Link Description :"), 220);
                    doweb1 = true;
                    if(stringbutton(rd, "     Next >     ", 495, 255, 0, i, i_83, bool, 0, 0))
                        if(gs.temail.getText().equals("") || gs.cmsg.getText().equals(""))
                        {
                            msg = "Please enter a link title and a link description!";
                            flko = 45;
                        } else
                        {
                            sltit = gs.temail.getText();
                            if(!lurl.equals("") && lurl.toLowerCase().startsWith("http"))
                                gs.temail.setText(lurl);
                            else
                                gs.temail.setText("http://");
                            msg = "Edit Clan's Web Presence";
                            flko = 0;
                            editc = 7;
                        }
                    if(stringbutton(rd, " Cancel ", 495, 295, 2, i, i_83, bool, 0, 0))
                        editc = 0;
                }
                if(editc == 7)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(245, 92, 500, 225, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(245, 92, 500, 225, 20, 20);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    if(flko % 4 != 0 || flko == 0)
                        rd.drawString(msg, 495 - ftm.stringWidth(msg) / 2, 115);
                    if(flko != 0)
                        flko--;
                    rd.drawString("Link URL :", 343 - ftm.stringWidth("Link URL :"), 150);
                    doweb2 = true;
                    rd.drawString("WARNING :", 255, 180);
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString("Any link placed that contains inappropriate, spam or unrelated content will result in", 255, 200);
                    rd.drawString("instant clan deletion and permanent account banning!", 255, 220);
                    if(stringbutton(rd, "     Save     ", 495, 255, 0, i, i_83, bool, 0, 0))
                        if(gs.temail.getText().equals("") || gs.temail.getText().equals("http://"))
                        {
                            msg = "Please enter a link URL!";
                            flko = 45;
                        } else
                        {
                            editc = 55;
                        }
                    if(stringbutton(rd, " Cancel ", 495, 295, 2, i, i_83, bool, 0, 0))
                        editc = 0;
                }
                if(editc == 33 || editc == 44 || editc == 66 || editc == 77 || editc == 99 || editc == 55)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(345, 92, 300, 40, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(345, 92, 300, 40, 20, 20);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("One moment...", 495 - ftm.stringWidth("One moment...") / 2, 117);
                }
                if(editc == 5)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(265, 92, 460, 115, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(265, 92, 460, 115, 20, 20);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Server error occurred or was unable to authorize this action.", 495 - ftm.stringWidth("Server error occurred or was unable to authorize this action.") / 2, 120);
                    rd.drawString("Please try again later.", 495 - ftm.stringWidth("Please try again later.") / 2, 150);
                    if(stringbutton(rd, "     OK     ", 495, 185, 2, i, i_83, bool, 0, 0))
                        editc = 0;
                }
                if(editc == 101)
                {
                    rd.setColor(new Color(244, 232, 204));
                    rd.fillRoundRect(232, 90, 527, 176, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(232, 90, 527, 176, 20, 20);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("You are currently using a trial account.", 495 - ftm.stringWidth("You are currently using a trial account.") / 2, 120);
                    rd.drawString("You need to upgrade to be able participate in any NFM clan activity.", 495 - ftm.stringWidth("You need to upgrade to be able participate in any NFM clan activity.") / 2, 140);
                    rd.setColor(new Color(206, 171, 98));
                    rd.fillRoundRect(405, 163, 180, 50, 20, 20);
                    if(drawbutton(xt.upgrade, 495, 188, i, i_83, bool))
                        gs.editlink(xt.nickname, true);
                    if(stringbutton(rd, " Cancel ", 495, 244, 2, i, i_83, bool, 0, 0))
                        editc = 0;
                }
            } else
            {
                rd.drawString((new StringBuilder()).append("Loading clan: ").append(claname).append(", please wait...").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("Loading clan: ").append(claname).append(", please wait...").toString()) / 2, 222);
            }
        } else
        {
            if(gs.clcars.isShowing())
                gs.clcars.hide();
            if(editc != 0)
            {
                editc = 0;
                if(gs.clanlev.isShowing())
                    gs.clanlev.hide();
            }
        }
    }

    public void dotab2(int i, int i_186, boolean bool)
    {
        if(itab == 0)
        {
            if(litab != itab)
            {
                spos3 = 0;
                gs.senditem.hide();
                gs.datat.hide();
                gs.sendtyp.removeAll();
                gs.sendtyp.add(rd, "Write a Message");
                gs.sendtyp.add(rd, "Share a Custom Car");
                gs.sendtyp.add(rd, "Share a Custom Stage");
                gs.sendtyp.add(rd, "Send a Clan Invitation");
                gs.sendtyp.add(rd, "Share a Relative Date");
                if(!forcsel)
                    gs.sendtyp.select(0);
                else
                    gs.sendtyp.select(itemsel);
                forcsel = false;
                flko = 0;
                itemsel = 0;
                flko = 0;
                litab = itab;
            }
            if(openc != 10)
            {
                rd.setColor(color2k(230, 230, 230));
                rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                if(loadmsgs != 0 && loadmsgs != -2 && loadmsgs != -1)
                {
                    sdist = (nm - 10) * 31;
                    if(sdist < 0)
                        sdist = 0;
                    scro = (int)(((float)spos3 / 268F) * (float)sdist);
                    int i_187 = 0;
                    for(int i_188 = 0; i_188 < nm; i_188++)
                    {
                        if(mtyp[i_188] == 3)
                            continue;
                        if((76 + 31 * i_187) - scro < 408 && (107 + 31 * i_187) - scro > 76)
                        {
                            boolean bool_189 = false;
                            if(i > 207 && i < 770 && i_186 > (76 + 31 * i_187) - scro && i_186 < (106 + 31 * i_187) - scro)
                            {
                                bool_189 = true;
                                cur = 12;
                                if(bool && openc == 0)
                                {
                                    opy = (70 + 31 * i_187) - scro;
                                    addopy = (40 - opy) / 10;
                                    oph = 44;
                                    openc = 1;
                                    if(!opname.equals(mname[i_188]))
                                    {
                                        opname = mname[i_188];
                                        lastsub = "";
                                        readmsg = 1;
                                    }
                                }
                            }
                            if(mtyp[i_188] == 1)
                            {
                                rd.setColor(color2k(240, 240, 240));
                                rd.fillRect(207, (77 + 31 * i_187) - scro, 564, 30);
                            }
                            if(bool_189)
                            {
                                rd.setColor(color2k(250, 250, 250));
                                rd.fillRect(207, (77 + 31 * i_187) - scro, 564, 30);
                            }
                            boolean bool_190 = drawl(rd, mname[i_188], 207, (77 + 31 * i_187) - scro, bool_189);
                            if(!bool_189 || !bool_190)
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString(mname[i_188], 267 - ftm.stringWidth(mname[i_188]) / 2, (96 + 31 * i_187) - scro);
                            }
                            int is[] = {
                                0, 5, 5, 14, 14, 5, 5
                            };
                            int is_191[] = {
                                0, -5, -2, -2, 3, 3, 5
                            };
                            if(mtyp[i_188] != 2)
                            {
                                for(int i_192 = 0; i_192 < 7; i_192++)
                                {
                                    is[i_192] += 335;
                                    is_191[i_192] += (98 + 31 * i_187) - scro;
                                }

                                rd.setColor(new Color(0, 128, 0));
                            } else
                            {
                                for(int i_193 = 0; i_193 < 7; i_193++)
                                {
                                    is[i_193] = 349 - is[i_193];
                                    is_191[i_193] += (98 + 31 * i_187) - scro;
                                }

                                rd.setColor(new Color(0, 0, 128));
                            }
                            rd.fillPolygon(is, is_191, 7);
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(color2k(125, 125, 125));
                            rd.drawString(mtime[i_188], 760 - ftm.stringWidth(mtime[i_188]), (102 + 31 * i_187) - scro);
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString(msub[i_188], 335, (89 + 31 * i_187) - scro);
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(207, (107 + 31 * i_187) - scro, 770, (107 + 31 * i_187) - scro);
                        }
                        i_187++;
                    }

                    for(int i_194 = 0; i_194 < nm; i_194++)
                    {
                        if(mtyp[i_194] != 3)
                            continue;
                        if((76 + 31 * i_187) - scro < 408 && (107 + 31 * i_187) - scro > 76)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            boolean bool_195 = false;
                            if(i > 207 && i < 770 && i_186 > (76 + 31 * i_187) - scro && i_186 < (106 + 31 * i_187) - scro)
                                bool_195 = true;
                            boolean bool_196 = drawl(rd, mname[i_194], 207, (77 + 31 * i_187) - scro, bool_195);
                            if(!bool_195 || !bool_196)
                            {
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString(mname[i_194], 267 - ftm.stringWidth(mname[i_194]) / 2, (96 + 31 * i_187) - scro);
                            }
                            rd.setColor(color2k(100, 100, 100));
                            rd.fillRect(327, (77 + 31 * i_187) - scro, 444, 30);
                            rd.setColor(color2k(200, 200, 200));
                            if(unblockname.equals(""))
                                rd.drawString("Blocked", 337, (96 + 31 * i_187) - scro);
                            else
                                rd.drawString("Unblocking...", 337, (96 + 31 * i_187) - scro);
                            if(bool_195 && stringbutton(rd, "   Unblock  ", 724, (96 + 31 * i_187) - scro, 3, i, i_186, bool, 0, 0) && unblockname.equals(""))
                                unblockname = mname[i_194];
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(207, (107 + 31 * i_187) - scro, 770, (107 + 31 * i_187) - scro);
                        }
                        i_187++;
                    }

                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 46, 582, 30);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    String strings[] = {
                        "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
                    };
                    int is[] = {
                        207, 390, 368, 207
                    };
                    int is_197[] = {
                        73, 73, 51, 51
                    };
                    for(int i_198 = 0; i_198 < 3; i_198++)
                    {
                        if(itab == i_198)
                        {
                            rd.setColor(color2k(230, 230, 230));
                            rd.fillPolygon(is, is_197, 4);
                        } else
                        if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                        {
                            rd.setColor(color2k(217, 217, 217));
                            rd.fillPolygon(is, is_197, 4);
                            if(bool)
                                itab = i_198;
                        }
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawPolygon(is, is_197, 4);
                        rd.setColor(color2k(40, 40, 40));
                        rd.drawString(strings[i_198], (is[0] + 80) - ftm.stringWidth(strings[i_198]) / 2, 67);
                        for(int i_199 = 0; i_199 < 4; i_199++)
                            is[i_199] += 183;

                    }

                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 73, 770, 73);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 409, 582, 30);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 411, 770, 411);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(772, 93, 17, 299);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(203, 46, 4, 393);
                    if(mscro3 == 831 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(772, 76, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(772, 76, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asu, 777, 82, null);
                    if(mscro3 == 832 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(772, 392, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(772, 392, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asd, 777, 399, null);
                    if(sdist != 0)
                    {
                        if(lspos3 != spos3)
                        {
                            rd.setColor(color2k(215, 215, 215));
                            rd.fillRect(772, 93 + spos3, 17, 31);
                        } else
                        {
                            if(mscro3 == 831)
                                rd.setColor(color2k(215, 215, 215));
                            rd.fill3DRect(772, 93 + spos3, 17, 31, true);
                        }
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(777, 106 + spos3, 783, 106 + spos3);
                        rd.drawLine(777, 108 + spos3, 783, 108 + spos3);
                        rd.drawLine(777, 110 + spos3, 783, 110 + spos3);
                        if(mscro3 > 800 && lspos3 != spos3)
                            lspos3 = spos3;
                        if(bool && openc == 0)
                        {
                            if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 + spos3 && i_186 < spos3 + 124)
                                mscro3 = i_186 - spos3;
                            if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 74 && i_186 < 95)
                                mscro3 = 831;
                            if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 390 && i_186 < 411)
                                mscro3 = 832;
                            if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 && i_186 < 392)
                            {
                                mscro3 = 108;
                                spos3 = i_186 - mscro3;
                            }
                            int i_200 = 2670 / sdist;
                            if(i_200 < 1)
                                i_200 = 1;
                            if(mscro3 == 831)
                            {
                                spos3 -= i_200;
                                if(spos3 > 268)
                                    spos3 = 268;
                                if(spos3 < 0)
                                    spos3 = 0;
                                lspos3 = spos3;
                            }
                            if(mscro3 == 832)
                            {
                                spos3 += i_200;
                                if(spos3 > 268)
                                    spos3 = 268;
                                if(spos3 < 0)
                                    spos3 = 0;
                                lspos3 = spos3;
                            }
                            if(mscro3 < 800)
                            {
                                spos3 = i_186 - mscro3;
                                if(spos3 > 268)
                                    spos3 = 268;
                                if(spos3 < 0)
                                    spos3 = 0;
                            }
                            if(mscro3 == 825)
                                mscro3 = 925;
                        } else
                        if(mscro3 != 825)
                            mscro3 = 825;
                    }
                } else
                {
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 46, 582, 30);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    String strings[] = {
                        "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
                    };
                    int is[] = {
                        207, 390, 368, 207
                    };
                    int is_201[] = {
                        73, 73, 51, 51
                    };
                    for(int i_202 = 0; i_202 < 3; i_202++)
                    {
                        if(itab == i_202)
                        {
                            rd.setColor(color2k(230, 230, 230));
                            rd.fillPolygon(is, is_201, 4);
                        } else
                        if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                        {
                            rd.setColor(color2k(217, 217, 217));
                            rd.fillPolygon(is, is_201, 4);
                            if(bool)
                                itab = i_202;
                        }
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawPolygon(is, is_201, 4);
                        rd.setColor(color2k(40, 40, 40));
                        rd.drawString(strings[i_202], (is[0] + 80) - ftm.stringWidth(strings[i_202]) / 2, 67);
                        for(int i_203 = 0; i_203 < 4; i_203++)
                            is[i_203] += 183;

                    }

                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 73, 770, 73);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(207, 409, 582, 30);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(207, 411, 770, 411);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(772, 76, 17, 333);
                    rd.setColor(color2k(205, 205, 205));
                    rd.fillRect(203, 46, 4, 393);
                    if(loadmsgs == 0)
                    {
                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("You have not started any conversations yet.", 487 - ftm.stringWidth("You have not started any conversations yet.") / 2, 200);
                    }
                    if(loadmsgs == -2)
                    {
                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Failed to load conversations, will try again now...", 487 - ftm.stringWidth("Failed to load conversations, will try again now...") / 2, 200);
                    }
                    if(loadmsgs == -1)
                    {
                        rd.setFont(new Font("Arial", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Loading conversations, please wait...", 487 - ftm.stringWidth("Loading conversation, please wait...") / 2, 200);
                    }
                }
                if(gs.sendtyp.isShowing())
                {
                    gs.sendtyp.hide();
                    gs.sendtyp.select(0);
                    flko = 0;
                }
                if(gs.senditem.isShowing())
                    gs.senditem.hide();
                if(gs.datat.isShowing())
                    gs.datat.hide();
            } else
            {
                rd.setColor(color2k(240, 240, 240));
                rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                rd.setColor(color2k(250, 250, 250));
                rd.fillRect(207, 86, 577, 274);
                sdist = (int)(((float)nml - 14.75F) * 17F);
                if(sdist < 0)
                    sdist = 0;
                scro = (int)(((float)spos4 / 208F) * (float)sdist);
                if(readmsg == 2)
                {
                    if(gs.openm)
                        blockb = 10;
                    else
                    if(blockb != 0)
                        blockb--;
                    for(int i_204 = 0; i_204 < nml; i_204++)
                    {
                        if((86 + 17 * i_204) - scro >= 360 || (125 + 17 * i_204) - scro <= 86 || mlinetyp[i_204] == 167)
                            continue;
                        rd.setColor(new Color(0, 0, 0));
                        if(mlinetyp[i_204] != 10 && mlinetyp[i_204] != 20 && mlinetyp[i_204] != 30)
                        {
                            if(mlinetyp[i_204] == 0 || mlinetyp[i_204] == 1 || mlinetyp[i_204] == 2 || mlinetyp[i_204] == 3 || mlinetyp[i_204] == 4)
                                rd.setFont(new Font("Tahoma", 1, 11));
                            else
                                rd.setFont(new Font("Tahoma", 0, 11));
                            mline[i_204] = mline[i_204].trim();
                            if(Madness.isURL(mline[i_204]))
                            {
                                Color tmp = rd.getColor();
                                rd.setColor(color2k(80, 80, 80));
                                rd.drawString(mline[i_204], 217, (103 + 17 * i_204) - scro);
                                rd.drawLine(216, (105 + i_204 * 17) - scro, 217 + rd.getFontMetrics().stringWidth(mline[i_204]), (105 + i_204 * 17) - scro);
                                gs.customlink(mline[i_204], 217, (103 + 17 * i_204) - scro, rd.getFontMetrics().stringWidth(mline[i_204]));
                                rd.setColor(tmp);
                            } else
                            {
                                rd.drawString(mline[i_204], 217, (103 + 17 * i_204) - scro);
                            }
                            if(mlinetyp[i_204] == 0 || mlinetyp[i_204] == 1 || mlinetyp[i_204] == 2 || mlinetyp[i_204] == 3 || mlinetyp[i_204] == 4)
                            {
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                rd.setColor(color2k(125, 125, 125));
                                rd.drawString(mtimes[i_204], 757 - ftm.stringWidth(mtimes[i_204]), (103 + 17 * i_204) - scro);
                            }
                            continue;
                        }
                        if(mlinetyp[i_204] == 30)
                        {
                            boolean bool_205 = true;
                            if(i > 217 && i < 567 && i_186 > (93 + i_204 * 17) - scro && i_186 < (123 + i_204 * 17) - scro && blockb == 0)
                            {
                                cur = 12;
                                bool_205 = false;
                                if(bool)
                                {
                                    if(!claname.equals(mline[i_204]))
                                    {
                                        claname = mline[i_204];
                                        loadedc = false;
                                    }
                                    tab = 3;
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    ctab = 0;
                                }
                            }
                            if(!drawl(rd, (new StringBuilder()).append("#").append(mline[i_204]).append("#").toString(), 217, (93 + i_204 * 17) - scro, bool_205) || !bool_205)
                            {
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawRect(217, (93 + i_204 * 17) - scro, 349, 29);
                                rd.setFont(new Font("Arial", 1, 13));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("").append(mline[i_204]).append("").toString(), 392 - ftm.stringWidth((new StringBuilder()).append("").append(mline[i_204]).append("").toString()) / 2, (113 + i_204 * 17) - scro);
                            }
                        }
                        if(mlinetyp[i_204] == 10)
                        {
                            if(cd.acname.equals(mline[i_204]))
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                ftm = rd.getFontMetrics();
                                if(cd.action == -9)
                                    rd.drawString("Failed to add car!  Unknown error, please try again later.", 217, (109 + 17 * i_204) - scro);
                                if(cd.action == -8)
                                    rd.drawString("Cannot add more then 20 cars to your account!", 217, (109 + 17 * i_204) - scro);
                                if(cd.action == 7)
                                {
                                    rd.setColor(new Color(94, 170, 0));
                                    rd.drawString((new StringBuilder()).append("[").append(mline[i_204]).append("] has been added to your cars!").toString(), 217, (109 + 17 * i_204) - scro);
                                }
                                if(cd.action == -7)
                                    rd.drawString("You already have this car.", 217, (109 + 17 * i_204) - scro);
                                if(cd.action == 6)
                                    rd.drawString("Adding Car...", 217, (109 + 17 * i_204) - scro);
                                if(cd.action == -6)
                                {
                                    rd.setColor(new Color(193, 106, 0));
                                    String string = "Upgrade to a full account to add custom cars!";
                                    int i_206 = 217;
                                    int i_207 = i_206 + ftm.stringWidth(string);
                                    rd.drawString(string, i_206, (109 + 17 * i_204) - scro);
                                    if(waitlink != -1)
                                        rd.drawLine(i_206, (111 + 17 * i_204) - scro, i_207, (111 + 17 * i_204) - scro);
                                    if(i > i_206 && i < i_207 && i_186 > (98 + 17 * i_204) - scro && i_186 < (111 + 17 * i_204) - scro)
                                    {
                                        if(waitlink != -1)
                                            cur = 12;
                                        if(bool && waitlink == 0)
                                        {
                                            gs.editlink(xt.nickname, true);
                                            waitlink = -1;
                                        }
                                    }
                                    if(waitlink > 0)
                                        waitlink--;
                                }
                            }
                            if(cd.action == 0 || !cd.acname.equals(mline[i_204]))
                            {
                                rd.setFont(new Font("Arial", 1, 12));
                                rd.drawString((new StringBuilder()).append("[  ").append(mline[i_204]).append("  ]").toString(), 340, (109 + 17 * i_204) - scro);
                                if(xt.drawcarb(true, null, " Add to My Cars ", 217, (90 + 17 * i_204) - scro, i, i_186, bool && blockb == 0))
                                    if(xt.logged)
                                    {
                                        cd.action = 6;
                                        cd.ac = -1;
                                        cd.acname = mline[i_204];
                                        cd.sparkactionloader();
                                    } else
                                    {
                                        cd.acname = mline[i_204];
                                        cd.action = -6;
                                        waitlink = 20;
                                    }
                            }
                        }
                        if(mlinetyp[i_204] != 20)
                            continue;
                        if(cd.onstage.equals(mline[i_204]))
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            if(addstage == 2)
                            {
                                rd.drawString("Adding stage...", 217, (109 + 17 * i_204) - scro);
                                if(cd.staction == 0)
                                    addstage = 3;
                                if(cd.staction == -2)
                                    addstage = 4;
                                if(cd.staction == -3)
                                    addstage = 5;
                                if(cd.staction == -1)
                                    addstage = 6;
                            }
                            if(addstage == 3)
                            {
                                rd.setColor(new Color(94, 170, 0));
                                rd.drawString((new StringBuilder()).append("[").append(mline[i_204]).append("] has been added to your stages!").toString(), 217, (109 + 17 * i_204) - scro);
                            }
                            if(addstage == 4)
                                rd.drawString("You already have this stage.", 217, (109 + 17 * i_204) - scro);
                            if(addstage == 5)
                                rd.drawString("Cannot add more then 20 stages to your account!", 217, (109 + 17 * i_204) - scro);
                            if(addstage == 6)
                                rd.drawString("Failed to add stage!  Unknown error, please try again later.", 217, (109 + 17 * i_204) - scro);
                            if(addstage == 1)
                            {
                                rd.setColor(new Color(193, 106, 0));
                                String string = "Upgrade to a full account to add custom stages!";
                                int i_208 = 217;
                                int i_209 = i_208 + ftm.stringWidth(string);
                                rd.drawString(string, i_208, (109 + 17 * i_204) - scro);
                                if(waitlink != -1)
                                    rd.drawLine(i_208, (111 + 17 * i_204) - scro, i_209, (111 + 17 * i_204) - scro);
                                if(i > i_208 && i < i_209 && i_186 > (98 + 17 * i_204) - scro && i_186 < (111 + 17 * i_204) - scro)
                                {
                                    if(waitlink != -1)
                                        cur = 12;
                                    if(bool && waitlink == 0)
                                    {
                                        gs.editlink(xt.nickname, true);
                                        waitlink = -1;
                                    }
                                }
                                if(waitlink > 0)
                                    waitlink--;
                            }
                        }
                        if(addstage != 0 && cd.onstage.equals(mline[i_204]))
                            continue;
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.drawString((new StringBuilder()).append("[  ").append(mline[i_204]).append("  ]").toString(), 355, (109 + 17 * i_204) - scro);
                        if(!xt.drawcarb(true, null, " Add to My Stages ", 217, (90 + 17 * i_204) - scro, i, i_186, bool && blockb == 0))
                            continue;
                        if(xt.logged)
                        {
                            cd.onstage = mline[i_204];
                            cd.staction = 2;
                            cd.sparkstageaction();
                            addstage = 2;
                        } else
                        {
                            cd.onstage = mline[i_204];
                            addstage = 1;
                            waitlink = 20;
                        }
                    }

                }
                if(readmsg == 1)
                {
                    rd.setFont(new Font("Tahoma", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Reading...", 487 - ftm.stringWidth("Reading...") / 2, 200);
                }
                if(readmsg == 3)
                {
                    rd.setFont(new Font("Tahoma", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Failed to fetch and load conversation.", 487 - ftm.stringWidth("Failed to fetch and load conversation.") / 2, 200);
                }
                if(readmsg == 4)
                {
                    rd.setFont(new Font("Tahoma", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Failed to load conversation, server error, please try again later.", 487 - ftm.stringWidth("Failed to load conversation, please try again later.") / 2, 200);
                }
                if(readmsg == 5)
                {
                    rd.setFont(new Font("Tahoma", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Failed to send message, server error, please try again later.", 487 - ftm.stringWidth("Failed to send message, server error, please try again later.") / 2, 200);
                }
                rd.setColor(color2k(240, 240, 240));
                rd.fillRect(207, 47, 577, 39);
                rd.fillRect(207, 360, 577, 39);
                rd.setColor(color2k(205, 205, 205));
                rd.drawLine(207, 86, 783, 86);
                rd.drawLine(207, 86, 207, 360);
                rd.drawLine(207, 360, 783, 360);
                rd.fillRect(767, 104, 17, 239);
                if(mscro4 == 831 || sdist == 0)
                {
                    if(sdist == 0)
                        rd.setColor(color2k(205, 205, 205));
                    else
                        rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(767, 87, 17, 17);
                } else
                {
                    rd.setColor(color2k(220, 220, 220));
                    rd.fill3DRect(767, 87, 17, 17, true);
                }
                if(sdist != 0)
                    rd.drawImage(xt.asu, 772, 93, null);
                if(mscro4 == 832 || sdist == 0)
                {
                    if(sdist == 0)
                        rd.setColor(color2k(205, 205, 205));
                    else
                        rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(767, 343, 17, 17);
                } else
                {
                    rd.setColor(color2k(220, 220, 220));
                    rd.fill3DRect(767, 343, 17, 17, true);
                }
                if(sdist != 0)
                    rd.drawImage(xt.asd, 772, 350, null);
                if(sdist != 0)
                {
                    if(lspos4 != spos4)
                    {
                        rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(767, 104 + spos4, 17, 31);
                    } else
                    {
                        if(mscro4 == 831)
                            rd.setColor(color2k(215, 215, 215));
                        rd.fill3DRect(767, 104 + spos4, 17, 31, true);
                    }
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawLine(772, 117 + spos4, 778, 117 + spos4);
                    rd.drawLine(772, 119 + spos4, 778, 119 + spos4);
                    rd.drawLine(772, 121 + spos4, 778, 121 + spos4);
                    if(mscro4 > 800 && lspos4 != spos4)
                        lspos4 = spos4;
                    if(bool)
                    {
                        if(mscro4 == 825 && i > 767 && i < 784 && i_186 > 104 + spos4 && i_186 < spos4 + 135)
                            mscro4 = i_186 - spos4;
                        if(mscro4 == 825 && i > 765 && i < 786 && i_186 > 85 && i_186 < 106)
                            mscro4 = 831;
                        if(mscro4 == 825 && i > 765 && i < 786 && i_186 > 341 && i_186 < 362)
                            mscro4 = 832;
                        if(mscro4 == 825 && i > 767 && i < 784 && i_186 > 104 && i_186 < 343)
                        {
                            mscro4 = 119;
                            spos4 = i_186 - mscro4;
                        }
                        int i_210 = 2670 / sdist;
                        if(i_210 < 1)
                            i_210 = 1;
                        if(mscro4 == 831)
                        {
                            spos4 -= i_210;
                            if(spos4 > 208)
                                spos4 = 208;
                            if(spos4 < 0)
                                spos4 = 0;
                            lspos4 = spos4;
                        }
                        if(mscro4 == 832)
                        {
                            spos4 += i_210;
                            if(spos4 > 208)
                                spos4 = 208;
                            if(spos4 < 0)
                                spos4 = 0;
                            lspos4 = spos4;
                        }
                        if(mscro4 < 800)
                        {
                            spos4 = i_186 - mscro4;
                            if(spos4 > 208)
                                spos4 = 208;
                            if(spos4 < 0)
                                spos4 = 0;
                        }
                        if(mscro4 == 825)
                            mscro4 = 925;
                    } else
                    if(mscro4 != 825)
                        mscro4 = 825;
                }
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                if(!drawl(rd, opname, 207, 47, true))
                {
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString(opname, 267 - ftm.stringWidth(opname) / 2, 66);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawRect(207, 47, 119, 29);
                }
                rd.setColor(new Color(0, 0, 0));
                rd.drawString((new StringBuilder()).append("::  Conversation with ").append(opname).append("").toString(), 336, 72);
                if(i > 207 && i < 327 && i_186 > 47 && i_186 < 77)
                {
                    cur = 12;
                    if(bool)
                    {
                        tab = 1;
                        if(!proname.equals(opname))
                        {
                            proname = opname;
                            loadedp = false;
                            onexitpro();
                        }
                    }
                }
                if(stringbutton(rd, "Block / Ignore", 665, 66, 0, i, i_186, bool, 0, 0))
                {
                    openc = 0;
                    blockname = opname;
                }
                if(stringbutton(rd, "Close X", 752, 66, 0, i, i_186, bool, 0, 0))
                {
                    openc = 0;
                    readmsg = 0;
                }
                if(!gs.sendtyp.isShowing())
                    gs.sendtyp.show();
                gs.sendtyp.move(207, 365);
                if(sendmsg != 0)
                    gs.sendtyp.disable();
                else
                    gs.sendtyp.enable();
                String string = "";
                if(gs.sendtyp.getSelectedIndex() == 0)
                {
                    dommsg = true;
                    if(loaditem != 0)
                        loaditem = 0;
                }
                if(gs.sendtyp.getSelectedIndex() == 1)
                {
                    string = "car";
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString("Send a public car you have or a private car that belongs to you.", 376, 382);
                }
                if(gs.sendtyp.getSelectedIndex() == 2)
                {
                    string = "stage";
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString("Send a public stage you have or a private stage that belongs to you.", 376, 382);
                }
                if(gs.sendtyp.getSelectedIndex() == 3)
                {
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString((new StringBuilder()).append("Send an invitation to ").append(opname).append(" to join your clan.").toString(), 376, 382);
                }
                if(gs.sendtyp.getSelectedIndex() == 4)
                {
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.drawString("A date that gets converted to the local time of the person previewing it.", 376, 382);
                }
                if(itemsel != gs.sendtyp.getSelectedIndex())
                {
                    gs.senditem.hide();
                    gs.datat.hide();
                    itemsel = gs.sendtyp.getSelectedIndex();
                }
                if(gs.sendtyp.getSelectedIndex() == 0)
                    if(sendmsg == 0)
                    {
                        if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0) && !gs.mmsg.getText().trim().equals("") && gs.mmsg.getText().toLowerCase().indexOf(gs.tpass.getText().toLowerCase()) == -1 && xt.acexp != -3)
                            if(!xt.msgcheck(gs.mmsg.getText()))
                            {
                                sendmsg = 1;
                            } else
                            {
                                gs.sendtyp.hide();
                                xt.warning++;
                            }
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                    }
                if(gs.sendtyp.getSelectedIndex() == 1 || gs.sendtyp.getSelectedIndex() == 2)
                {
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString((new StringBuilder()).append("Select ").append(string).append(" to share:").toString(), 207, 420);
                    if(!gs.senditem.isShowing())
                    {
                        gs.senditem.removeAll();
                        if(xt.logged)
                        {
                            gs.senditem.add(rd, (new StringBuilder()).append("Loading your ").append(string).append(" list, please wait...").toString());
                            loaditem = gs.sendtyp.getSelectedIndex();
                        } else
                        {
                            gs.senditem.add(rd, (new StringBuilder()).append("You need to upgrade to have custom ").append(string).append("s!").toString());
                        }
                        gs.senditem.select(0);
                        gs.senditem.show();
                    }
                    gs.senditem.move(207 + ftm.stringWidth((new StringBuilder()).append("Select ").append(string).append(" to share:").toString()) + 11, 403);
                    if(loaditem == 10 && gs.sendtyp.getSelectedIndex() == 1 || loaditem == 20 && gs.sendtyp.getSelectedIndex() == 2 || !xt.logged)
                        if(xt.logged)
                        {
                            if(sendmsg == 0)
                            {
                                if(stringbutton(rd, "   Send  >  ", 723, 420, 0, i, i_186, bool, 0, 0))
                                    sendmsg = 1;
                            } else
                            {
                                rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 420);
                            }
                        } else
                        {
                            rd.setColor(new Color(206, 171, 98));
                            rd.fillRoundRect(651, 391, 136, 46, 20, 20);
                            if(drawbutton(xt.upgrade, 719, 414, i, i_186, bool))
                                gs.editlink(xt.nickname, true);
                        }
                }
                if(gs.sendtyp.getSelectedIndex() == 3)
                {
                    if(!xt.clan.equals(""))
                    {
                        int i_211 = 306;
                        int i_212 = -195;
                        if(!drawl(rd, (new StringBuilder()).append("#").append(xt.clan).append("#").toString(), 406 + i_212, 101 + i_211, true))
                        {
                            rd.setFont(new Font("Arial", 1, 13));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("").append(xt.clan).append("").toString(), (581 + i_212) - ftm.stringWidth((new StringBuilder()).append("").append(xt.clan).append("").toString()) / 2, 121 + i_211);
                        }
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        String string_213 = "Your Clan";
                        if(i > 402 + i_212 && i < 759 + i_212 && i_186 > 84 + i_211 && i_186 < 134 + i_211)
                        {
                            string_213 = (new StringBuilder()).append("Clan :  ").append(xt.clan).append("").toString();
                            rd.drawLine(408 + i_212, 98 + i_211, 408 + i_212 + ftm.stringWidth(string_213), 98 + i_211);
                            if(i > 408 + i_212 && i < 408 + i_212 + ftm.stringWidth(string_213) && i_186 > 85 + i_211 && i_186 < 100 + i_211 || i > 406 + i_212 && i < 756 + i_212 && i_186 > 101 + i_211 && i_186 < 131 + i_211)
                            {
                                cur = 12;
                                if(bool && sendmsg == 0)
                                {
                                    if(!claname.equals(xt.clan))
                                    {
                                        claname = xt.clan;
                                        loadedc = false;
                                    }
                                    tab = 3;
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    ctab = 0;
                                }
                            }
                        }
                        rd.drawString(string_213, 408 + i_212, 97 + i_211);
                        rd.drawLine(402 + i_212, 84 + i_211, 402 + i_212, 134 + i_211);
                        rd.drawLine(402 + i_212, 84 + i_211, 408 + i_212 + ftm.stringWidth(string_213) + 2, 84 + i_211);
                        rd.drawLine(408 + i_212 + ftm.stringWidth(string_213) + 2, 84 + i_211, 408 + i_212 + ftm.stringWidth(string_213) + 15, 97 + i_211);
                        rd.drawLine(408 + i_212 + ftm.stringWidth(string_213) + 15, 97 + i_211, 759 + i_212, 97 + i_211);
                        rd.drawLine(759 + i_212, 97 + i_211, 759 + i_212, 134 + i_211);
                        rd.drawLine(402 + i_212, 134 + i_211, 759 + i_212, 134 + i_211);
                    } else
                    if(xt.logged)
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        if(flko % 4 != 0 || flko == 0)
                            rd.drawString("You are not a member of any clan yet!", 376 - ftm.stringWidth("You are not a member of any clan yet!") / 2, 417);
                        if(flko != 0)
                            flko--;
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("You need to upgrade to a full account to participate in NFM clan's activities.", 207, 420);
                        rd.setColor(new Color(206, 171, 98));
                        rd.fillRoundRect(651, 391, 136, 46, 20, 20);
                        if(drawbutton(xt.upgrade, 719, 414, i, i_186, bool))
                            gs.editlink(xt.nickname, true);
                    }
                    if(xt.logged)
                        if(sendmsg == 0)
                        {
                            if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0))
                                if(!xt.clan.equals(""))
                                    sendmsg = 1;
                                else
                                    flko = 45;
                        } else
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                        }
                }
                if(gs.sendtyp.getSelectedIndex() == 4)
                {
                    if(!gs.senditem.isShowing())
                    {
                        gs.senditem.removeAll();
                        Calendar calendar = Calendar.getInstance();
                        boolean bool_214 = false;
                        for(int i_215 = 0; i_215 < 20; i_215++)
                        {
                            String strings[] = wday;
                            Calendar calendar_216 = calendar;
                            if(calendar == null);
                            String string_217 = strings[calendar_216.get(7) - 1];
                            if(!bool_214)
                            {
                                string_217 = "Today";
                                bool_214 = true;
                            }
                            Smenu smenu = gs.senditem;
                            Graphics2D graphics2d = rd;
                            StringBuilder stringbuilder = (new StringBuilder()).append("").append(string_217).append("  -  ");
                            String strings_218[] = month;
                            Calendar calendar_219 = calendar;
                            if(calendar == null);
                            StringBuilder stringbuilder_220 = stringbuilder.append(strings_218[calendar_219.get(2)]).append(" ");
                            Calendar calendar_221 = calendar;
                            if(calendar == null);
                            smenu.add(graphics2d, stringbuilder_220.append(calendar_221.get(5)).append("").toString());
                            Calendar calendar_222 = calendar;
                            if(calendar == null);
                            calendar_222.roll(5, true);
                        }

                        gs.senditem.select(0);
                        gs.senditem.show();
                    }
                    if(!gs.datat.isShowing())
                    {
                        gs.datat.removeAll();
                        int i_223 = 12;
                        String string_224 = "PM";
                        for(int i_225 = 0; i_225 < 24; i_225++)
                        {
                            gs.datat.add(rd, (new StringBuilder()).append("").append(i_223).append(" ").append(string_224).append("").toString());
                            if(++i_223 == 12)
                                string_224 = "AM";
                            if(i_223 == 13)
                                i_223 = 1;
                        }

                        gs.datat.select(0);
                        gs.datat.show();
                    }
                    gs.senditem.move(300, 395);
                    gs.datat.move(491, 395);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Date is displayed based on your computer calendar's date/time, please make sure it is correct.", 207, 435);
                    if(sendmsg == 0)
                    {
                        if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0))
                            sendmsg = 1;
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                    }
                }
            }
            if(openc >= 1 && openc < 10)
            {
                rd.setColor(color2k(240, 240, 230));
                rd.fillRoundRect(197, opy, 597, oph, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(197, opy, 597, oph, 20, 20);
                if(!drawl(rd, opname, 207, opy + 7, true))
                {
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString(opname, 267 - ftm.stringWidth(opname) / 2, opy + 26);
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawRect(207, opy + 7, 119, 29);
                }
                opy += addopy;
                oph += 36;
                openc++;
            }
        }
        if(itab == 1)
        {
            if(litab != itab)
            {
                spos3 = 0;
                gs.senditem.hide();
                gs.datat.hide();
                gs.sendtyp.removeAll();
                gs.sendtyp.add(rd, "Write a Message");
                gs.sendtyp.add(rd, "Share a Relative Date");
                gs.sendtyp.add(rd, "Battle over Stage");
                gs.sendtyp.add(rd, "Battle over Car");
                gs.sendtyp.add(rd, "Declare War");
                if(!redif)
                {
                    gs.sendtyp.select(0);
                } else
                {
                    gs.sendtyp.select(intsel);
                    if(intsel == 4)
                        redif = false;
                }
                if(sendwarnum)
                    gs.sendtyp.sel = intsel;
                intsel = 0;
                litab = itab;
            }
            if(!xt.clan.equals(""))
            {
                if(openi != 10)
                {
                    rd.setColor(color2k(230, 230, 230));
                    rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                    if(loadinter != 0 && loadinter != -2 && loadinter != -1)
                    {
                        sdist = (ni - 10) * 31;
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos3 / 268F) * (float)sdist);
                        int i_226 = 0;
                        for(int i_227 = 0; i_227 < ni; i_227++)
                        {
                            if((76 + 31 * i_226) - scro < 408 && (107 + 31 * i_226) - scro > 76)
                            {
                                boolean bool_228 = false;
                                if(i > 207 && i < 770 && i_186 > (76 + 31 * i_226) - scro && i_186 < (106 + 31 * i_226) - scro)
                                {
                                    bool_228 = true;
                                    cur = 12;
                                    if(bool && openc == 0)
                                    {
                                        opy = (70 + 31 * i_226) - scro;
                                        addopy = (40 - opy) / 10;
                                        oph = 44;
                                        openi = 1;
                                        if(!intclan.equals(iclan[i_227]))
                                        {
                                            intclan = iclan[i_227];
                                            dispi = 0;
                                            nil = 0;
                                            lastint = "";
                                            readint = 1;
                                        }
                                    }
                                }
                                if(icheck[i_227].toLowerCase().indexOf(xt.nickname.toLowerCase()) == -1)
                                {
                                    rd.setColor(color2k(240, 240, 240));
                                    rd.fillRect(207, (77 + 31 * i_226) - scro, 564, 30);
                                }
                                if(bool_228)
                                {
                                    rd.setColor(color2k(250, 250, 250));
                                    rd.fillRect(207, (77 + 31 * i_226) - scro, 564, 30);
                                }
                                boolean bool_229 = drawl(rd, (new StringBuilder()).append("#").append(iclan[i_227]).append("#").toString(), 207, (77 + 31 * i_226) - scro, bool_228);
                                if(!bool_228 || !bool_229)
                                {
                                    rd.setFont(new Font("Arial", 1, 12));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.drawString(iclan[i_227], 382 - ftm.stringWidth(iclan[i_227]) / 2, (96 + 31 * i_226) - scro);
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                rd.setColor(color2k(125, 125, 125));
                                rd.drawString(itime[i_227], 760 - ftm.stringWidth(itime[i_227]), (102 + 31 * i_226) - scro);
                                rd.setColor(new Color(0, 0, 0));
                                rd.drawString(isub[i_227], 565, (89 + 31 * i_226) - scro);
                                rd.setFont(new Font("Arial", 1, 11));
                                rd.setColor(new Color(117, 67, 0));
                                rd.drawString(istat[i_227], 565, (102 + 31 * i_226) - scro);
                                rd.setColor(color2k(150, 150, 150));
                                rd.drawLine(207, (107 + 31 * i_226) - scro, 770, (107 + 31 * i_226) - scro);
                            }
                            i_226++;
                        }

                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(207, 46, 582, 30);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        String strings[] = {
                            "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
                        };
                        int is[] = {
                            207, 390, 368, 207
                        };
                        int is_230[] = {
                            73, 73, 51, 51
                        };
                        for(int i_231 = 0; i_231 < 3; i_231++)
                        {
                            if(itab == i_231)
                            {
                                rd.setColor(color2k(230, 230, 230));
                                rd.fillPolygon(is, is_230, 4);
                            } else
                            if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                            {
                                rd.setColor(color2k(217, 217, 217));
                                rd.fillPolygon(is, is_230, 4);
                                if(bool)
                                    itab = i_231;
                            }
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawPolygon(is, is_230, 4);
                            rd.setColor(color2k(40, 40, 40));
                            rd.drawString(strings[i_231], (is[0] + 80) - ftm.stringWidth(strings[i_231]) / 2, 67);
                            for(int i_232 = 0; i_232 < 4; i_232++)
                                is[i_232] += 183;

                        }

                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(207, 73, 770, 73);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(207, 409, 582, 30);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(207, 411, 770, 411);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(772, 93, 17, 299);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(203, 46, 4, 393);
                        if(mscro3 == 831 || sdist == 0)
                        {
                            if(sdist == 0)
                                rd.setColor(color2k(205, 205, 205));
                            else
                                rd.setColor(color2k(215, 215, 215));
                            rd.fillRect(772, 76, 17, 17);
                        } else
                        {
                            rd.setColor(color2k(220, 220, 220));
                            rd.fill3DRect(772, 76, 17, 17, true);
                        }
                        if(sdist != 0)
                            rd.drawImage(xt.asu, 777, 82, null);
                        if(mscro3 == 832 || sdist == 0)
                        {
                            if(sdist == 0)
                                rd.setColor(color2k(205, 205, 205));
                            else
                                rd.setColor(color2k(215, 215, 215));
                            rd.fillRect(772, 392, 17, 17);
                        } else
                        {
                            rd.setColor(color2k(220, 220, 220));
                            rd.fill3DRect(772, 392, 17, 17, true);
                        }
                        if(sdist != 0)
                            rd.drawImage(xt.asd, 777, 399, null);
                        if(sdist != 0)
                        {
                            if(lspos3 != spos3)
                            {
                                rd.setColor(color2k(215, 215, 215));
                                rd.fillRect(772, 93 + spos3, 17, 31);
                            } else
                            {
                                if(mscro3 == 831)
                                    rd.setColor(color2k(215, 215, 215));
                                rd.fill3DRect(772, 93 + spos3, 17, 31, true);
                            }
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawLine(777, 106 + spos3, 783, 106 + spos3);
                            rd.drawLine(777, 108 + spos3, 783, 108 + spos3);
                            rd.drawLine(777, 110 + spos3, 783, 110 + spos3);
                            if(mscro3 > 800 && lspos3 != spos3)
                                lspos3 = spos3;
                            if(bool && openc == 0)
                            {
                                if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 + spos3 && i_186 < spos3 + 124)
                                    mscro3 = i_186 - spos3;
                                if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 74 && i_186 < 95)
                                    mscro3 = 831;
                                if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 390 && i_186 < 411)
                                    mscro3 = 832;
                                if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 && i_186 < 392)
                                {
                                    mscro3 = 108;
                                    spos3 = i_186 - mscro3;
                                }
                                int i_233 = 2670 / sdist;
                                if(i_233 < 1)
                                    i_233 = 1;
                                if(mscro3 == 831)
                                {
                                    spos3 -= i_233;
                                    if(spos3 > 268)
                                        spos3 = 268;
                                    if(spos3 < 0)
                                        spos3 = 0;
                                    lspos3 = spos3;
                                }
                                if(mscro3 == 832)
                                {
                                    spos3 += i_233;
                                    if(spos3 > 268)
                                        spos3 = 268;
                                    if(spos3 < 0)
                                        spos3 = 0;
                                    lspos3 = spos3;
                                }
                                if(mscro3 < 800)
                                {
                                    spos3 = i_186 - mscro3;
                                    if(spos3 > 268)
                                        spos3 = 268;
                                    if(spos3 < 0)
                                        spos3 = 0;
                                }
                                if(mscro3 == 825)
                                    mscro3 = 925;
                            } else
                            if(mscro3 != 825)
                                mscro3 = 825;
                        }
                    } else
                    {
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(207, 46, 582, 30);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        String strings[] = {
                            "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
                        };
                        int is[] = {
                            207, 390, 368, 207
                        };
                        int is_234[] = {
                            73, 73, 51, 51
                        };
                        for(int i_235 = 0; i_235 < 3; i_235++)
                        {
                            if(itab == i_235)
                            {
                                rd.setColor(color2k(230, 230, 230));
                                rd.fillPolygon(is, is_234, 4);
                            } else
                            if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                            {
                                rd.setColor(color2k(217, 217, 217));
                                rd.fillPolygon(is, is_234, 4);
                                if(bool)
                                    itab = i_235;
                            }
                            rd.setColor(color2k(150, 150, 150));
                            rd.drawPolygon(is, is_234, 4);
                            rd.setColor(color2k(40, 40, 40));
                            rd.drawString(strings[i_235], (is[0] + 80) - ftm.stringWidth(strings[i_235]) / 2, 67);
                            for(int i_236 = 0; i_236 < 4; i_236++)
                                is[i_236] += 183;

                        }

                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(207, 73, 770, 73);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(207, 409, 582, 30);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(207, 411, 770, 411);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(772, 76, 17, 333);
                        rd.setColor(color2k(205, 205, 205));
                        rd.fillRect(203, 46, 4, 393);
                        if(loadinter == 0)
                        {
                            rd.setFont(new Font("Arial", 1, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("You have not started any interactions with other clans yet.", 487 - ftm.stringWidth("You have not started any interactions with other clans yet.") / 2, 200);
                        }
                        if(loadinter == -2)
                        {
                            rd.setFont(new Font("Arial", 1, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Failed to load interactions, will try again now...", 487 - ftm.stringWidth("Failed to load interactions, will try again now...") / 2, 200);
                        }
                        if(loadinter == -1)
                        {
                            rd.setFont(new Font("Arial", 1, 11));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Loading interactions, please wait...", 487 - ftm.stringWidth("Loading interactions, please wait...") / 2, 200);
                        }
                    }
                    if(gs.sendtyp.isShowing())
                        gs.sendtyp.hide();
                    if(gs.senditem.isShowing())
                        gs.senditem.hide();
                    if(gs.datat.isShowing())
                        gs.datat.hide();
                    gs.ilaps.hide();
                    gs.icars.hide();
                    gs.sclass.hide();
                    gs.sfix.hide();
                    if(gs.sendtyp.getSelectedIndex() != 0)
                    {
                        gs.sendtyp.select(0);
                        intsel = 0;
                    }
                } else
                {
                    rd.setColor(color2k(240, 240, 240));
                    rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                    rd.setColor(color2k(250, 250, 250));
                    rd.fillRect(207, 86, 577, 274);
                    if(intclanlo.equals(intclan) && intclanbgloaded)
                    {
                        rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
                        rd.drawImage(intclanbg, 207, 86, null);
                        rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
                    }
                    sdist = 0;
                    if((readint == 2 || readint == 1) && viewgame2 == 0)
                    {
                        sdist = (int)(((float)nil - 14.75F) * 17F);
                        if(sdist < 0)
                            sdist = 0;
                        scro = (int)(((float)spos4 / 208F) * (float)sdist);
                        if(gs.openm)
                            blockb = 10;
                        else
                        if(blockb != 0)
                            blockb--;
                        for(int i_237 = 0; i_237 < nil; i_237++)
                        {
                            if((86 + 17 * i_237) - scro >= 360 || (125 + 17 * i_237) - scro <= 86 || ilinetyp[i_237] == 167)
                                continue;
                            rd.setColor(new Color(0, 0, 0));
                            if(ilinetyp[i_237] != 20 && ilinetyp[i_237] != 30 && ilinetyp[i_237] != 40 && ilinetyp[i_237] != 80 && ilinetyp[i_237] != 90 && ilinetyp[i_237] != 100)
                            {
                                if(ilinetyp[i_237] >= 0)
                                    rd.setFont(new Font("Tahoma", 1, 11));
                                else
                                    rd.setFont(new Font("Tahoma", 0, 11));
                                iline[i_237] = iline[i_237].trim();
                                if(Madness.isURL(iline[i_237]))
                                {
                                    Color tmp = rd.getColor();
                                    rd.setColor(color2k(80, 80, 80));
                                    rd.drawString(iline[i_237], 217, (103 + 17 * i_237) - scro);
                                    rd.drawLine(216, (105 + i_237 * 17) - scro, 217 + rd.getFontMetrics().stringWidth(iline[i_237]), (105 + i_237 * 17) - scro);
                                    gs.customlink(iline[i_237], 217, (103 + 17 * i_237) - scro, rd.getFontMetrics().stringWidth(iline[i_237]));
                                    rd.setColor(tmp);
                                } else
                                {
                                    rd.drawString(iline[i_237], 217, (103 + 17 * i_237) - scro);
                                }
                                if(ilinetyp[i_237] >= 0)
                                {
                                    rd.setFont(new Font("Tahoma", 0, 11));
                                    ftm = rd.getFontMetrics();
                                    rd.setColor(color2k(125, 125, 125));
                                    rd.drawString(itimes[i_237], 757 - ftm.stringWidth(itimes[i_237]), (103 + 17 * i_237) - scro);
                                }
                                continue;
                            }
                            if(ilinetyp[i_237] == 40)
                            {
                                if(stringbutton(rd, "  View War Declaration  ", 300, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewgame2 = 1;
                                    nvgames2 = 4;
                                    viewwar2 = getSvalue(iline[i_237], 1);
                                    if(iline[i_237].startsWith("I|"))
                                        ichlng = true;
                                    else
                                        ichlng = false;
                                }
                                if(!iline[i_237].endsWith("|out|"))
                                {
                                    if(iline[i_237].startsWith("Y|") && stringbutton(rd, "  Accept War  ", 441, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                    {
                                        gs.sendtyp.sel = 7;
                                        sendwar = getSvalue(iline[i_237], 1);
                                    }
                                } else
                                {
                                    rd.setColor(color2k(170, 170, 170));
                                    rd.drawString("[ Accepted or interaction replaced. ]", 490 - ftm.stringWidth("[ Accepted or interaction replaced. ]") / 2, (112 + 17 * i_237) - scro);
                                }
                            }
                            if(ilinetyp[i_237] == 30)
                            {
                                if(stringbutton(rd, "  View Car Battle  ", 282, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewgame2 = 1;
                                    nvgames2 = 2;
                                    viewwar2 = getSvalue(iline[i_237], 3);
                                    if(iline[i_237].startsWith("I|"))
                                        ichlng = true;
                                    else
                                        ichlng = false;
                                }
                                if(!iline[i_237].endsWith("|out|"))
                                {
                                    if(iline[i_237].startsWith("Y|") && stringbutton(rd, "  Accept Battle  ", 410, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                    {
                                        gs.sendtyp.sel = 6;
                                        itake = getSvalue(iline[i_237], 1);
                                        igive = getSvalue(iline[i_237], 2);
                                        sendwar = getSvalue(iline[i_237], 3);
                                    }
                                } else
                                {
                                    rd.setColor(color2k(170, 170, 170));
                                    rd.drawString("[ Accepted or interaction replaced. ]", 454 - ftm.stringWidth("[ Accepted or interaction replaced. ]") / 2, (112 + 17 * i_237) - scro);
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                if(stringbutton(rd, "  View Car  ", 217 + ftm.stringWidth(iline[i_237 + 2]) + 47, (137 + 17 * i_237) - scro, 6, i, i_186, bool, 0, 0))
                                {
                                    viewcar = getSvalue(iline[i_237], 1);
                                    if(!claname.equals(intclan))
                                    {
                                        claname = intclan;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    loadedcars = -1;
                                    loadedcar = 0;
                                    ctab = 2;
                                    tab = 3;
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                if(stringbutton(rd, "  View Car  ", 217 + ftm.stringWidth(iline[i_237 + 3]) + 47, (154 + 17 * i_237) - scro, 6, i, i_186, bool, 0, 0))
                                {
                                    viewcar = getSvalue(iline[i_237], 2);
                                    if(!claname.equals(xt.clan))
                                    {
                                        claname = xt.clan;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    loadedcars = -1;
                                    loadedcar = 0;
                                    ctab = 2;
                                    tab = 3;
                                }
                            }
                            if(ilinetyp[i_237] == 20)
                            {
                                if(stringbutton(rd, "  View Stage Battle  ", 289, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewgame2 = 1;
                                    nvgames2 = 2;
                                    viewwar2 = getSvalue(iline[i_237], 3);
                                    if(iline[i_237].startsWith("I|"))
                                        ichlng = true;
                                    else
                                        ichlng = false;
                                }
                                if(!iline[i_237].endsWith("|out|"))
                                {
                                    if(iline[i_237].startsWith("Y|") && stringbutton(rd, "  Accept Battle  ", 424, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                    {
                                        gs.sendtyp.sel = 5;
                                        itake = getSvalue(iline[i_237], 1);
                                        igive = getSvalue(iline[i_237], 2);
                                        sendwar = getSvalue(iline[i_237], 3);
                                    }
                                } else
                                {
                                    rd.setColor(color2k(170, 170, 170));
                                    rd.drawString("[ Accepted or interaction replaced. ]", 468 - ftm.stringWidth("[ Accepted or interaction replaced. ]") / 2, (112 + 17 * i_237) - scro);
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                if(stringbutton(rd, "  View Stage  ", 217 + ftm.stringWidth(iline[i_237 + 2]) + 54, (137 + 17 * i_237) - scro, 6, i, i_186, bool, 0, 0))
                                {
                                    viewcar = getSvalue(iline[i_237], 1);
                                    if(!claname.equals(intclan))
                                    {
                                        claname = intclan;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    loadedstages = -1;
                                    loadedstage = 0;
                                    ctab = 3;
                                    tab = 3;
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                if(stringbutton(rd, "  View Stage  ", 217 + ftm.stringWidth(iline[i_237 + 3]) + 54, (154 + 17 * i_237) - scro, 6, i, i_186, bool, 0, 0))
                                {
                                    viewcar = getSvalue(iline[i_237], 2);
                                    if(!claname.equals(xt.clan))
                                    {
                                        claname = xt.clan;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    loadedstages = -1;
                                    loadedstage = 0;
                                    ctab = 3;
                                    tab = 3;
                                }
                            }
                            if(ilinetyp[i_237] == 80)
                            {
                                if(stringbutton(rd, "        View War        ", 284, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewgame2 = 1;
                                    nvgames2 = 9;
                                    viewwar2 = getSvalue(iline[i_237], 0);
                                }
                                if(stringbutton(rd, "  View Championship  ", 432, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    cfase = 0;
                                    ntab = 1;
                                    loadwstat = 0;
                                    tab = 3;
                                }
                            }
                            String string;
                            if(ilinetyp[i_237] == 90)
                            {
                                if(stringbutton(rd, "        View Battle        ", 284, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewgame2 = 1;
                                    nvgames2 = 5;
                                    viewwar2 = getSvalue(iline[i_237], 0);
                                }
                                if(stringbutton(rd, "        View Car        ", 424, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    viewcar = getSvalue(iline[i_237], 1);
                                    string = getSvalue(iline[i_237], 2);
                                    if(!claname.equals(string))
                                    {
                                        claname = string;
                                        loadedc = false;
                                    }
                                    spos5 = 0;
                                    lspos5 = 0;
                                    cfase = 3;
                                    loadedcars = -1;
                                    loadedcar = 0;
                                    ctab = 2;
                                    tab = 3;
                                }
                            }
                            if(ilinetyp[i_237] != 100)
                                continue;
                            if(stringbutton(rd, "        View Battle        ", 284, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame2 = 1;
                                nvgames2 = 5;
                                viewwar2 = getSvalue(iline[i_237], 0);
                            }
                            if(!stringbutton(rd, "        View Stage        ", 431, (112 + 17 * i_237) - scro, 0, i, i_186, bool, 0, 0))
                                continue;
                            viewcar = getSvalue(iline[i_237], 1);
                            string = getSvalue(iline[i_237], 2);
                            if(!claname.equals(string))
                            {
                                claname = string;
                                loadedc = false;
                            }
                            spos5 = 0;
                            lspos5 = 0;
                            cfase = 3;
                            loadedstages = -1;
                            loadedstage = 0;
                            ctab = 3;
                            tab = 3;
                        }

                    }
                    if(readint == 1)
                    {
                        rd.setColor(color2k(240, 240, 240));
                        rd.fillRoundRect(387, 140, 200, 30, 20, 20);
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawRoundRect(387, 140, 200, 30, 20, 20);
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Reading...", 487 - ftm.stringWidth("Reading...") / 2, 160);
                    }
                    if(readint == 3)
                    {
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Failed to fetch and load interaction.", 487 - ftm.stringWidth("Failed to fetch and load interaction.") / 2, 200);
                    }
                    if(readint == 4)
                    {
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Failed to load interaction, server error, please try again later.", 487 - ftm.stringWidth("Failed to load interaction, server error, please try again later.") / 2, 200);
                    }
                    if(readint == 5)
                    {
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Failed to send interaction, please try again later.", 487 - ftm.stringWidth("Failed to send interaction, please try again later.") / 2, 200);
                    }
                    if(readint == 6)
                    {
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("The war or battle you are trying to engage has expired or was not found...", 487 - ftm.stringWidth("The war or battle you are trying to engage has expired or was not found...") / 2, 200);
                    }
                    rd.setColor(color2k(240, 240, 240));
                    rd.fillRect(207, 47, 577, 39);
                    rd.fillRect(207, 360, 577, 70);
                    rd.setColor(color2k(205, 205, 205));
                    rd.drawLine(207, 86, 783, 86);
                    rd.drawLine(207, 86, 207, 360);
                    rd.drawLine(207, 360, 783, 360);
                    rd.fillRect(767, 104, 17, 239);
                    if(mscro4 == 831 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(767, 87, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(767, 87, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asu, 772, 93, null);
                    if(mscro4 == 832 || sdist == 0)
                    {
                        if(sdist == 0)
                            rd.setColor(color2k(205, 205, 205));
                        else
                            rd.setColor(color2k(215, 215, 215));
                        rd.fillRect(767, 343, 17, 17);
                    } else
                    {
                        rd.setColor(color2k(220, 220, 220));
                        rd.fill3DRect(767, 343, 17, 17, true);
                    }
                    if(sdist != 0)
                        rd.drawImage(xt.asd, 772, 350, null);
                    if(sdist != 0)
                    {
                        if(lspos4 != spos4)
                        {
                            rd.setColor(color2k(215, 215, 215));
                            rd.fillRect(767, 104 + spos4, 17, 31);
                        } else
                        {
                            if(mscro4 == 831)
                                rd.setColor(color2k(215, 215, 215));
                            rd.fill3DRect(767, 104 + spos4, 17, 31, true);
                        }
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawLine(772, 117 + spos4, 778, 117 + spos4);
                        rd.drawLine(772, 119 + spos4, 778, 119 + spos4);
                        rd.drawLine(772, 121 + spos4, 778, 121 + spos4);
                        if(mscro4 > 800 && lspos4 != spos4)
                            lspos4 = spos4;
                        if(bool)
                        {
                            if(mscro4 == 825 && i > 767 && i < 784 && i_186 > 104 + spos4 && i_186 < spos4 + 135)
                                mscro4 = i_186 - spos4;
                            if(mscro4 == 825 && i > 765 && i < 786 && i_186 > 85 && i_186 < 106)
                                mscro4 = 831;
                            if(mscro4 == 825 && i > 765 && i < 786 && i_186 > 341 && i_186 < 362)
                                mscro4 = 832;
                            if(mscro4 == 825 && i > 767 && i < 784 && i_186 > 104 && i_186 < 343)
                            {
                                mscro4 = 119;
                                spos4 = i_186 - mscro4;
                            }
                            int i_238 = 2670 / sdist;
                            if(i_238 < 1)
                                i_238 = 1;
                            if(mscro4 == 831)
                            {
                                spos4 -= i_238;
                                if(spos4 > 208)
                                    spos4 = 208;
                                if(spos4 < 0)
                                    spos4 = 0;
                                lspos4 = spos4;
                            }
                            if(mscro4 == 832)
                            {
                                spos4 += i_238;
                                if(spos4 > 208)
                                    spos4 = 208;
                                if(spos4 < 0)
                                    spos4 = 0;
                                lspos4 = spos4;
                            }
                            if(mscro4 < 800)
                            {
                                spos4 = i_186 - mscro4;
                                if(spos4 > 208)
                                    spos4 = 208;
                                if(spos4 < 0)
                                    spos4 = 0;
                            }
                            if(mscro4 == 825)
                                mscro4 = 925;
                        } else
                        if(mscro4 != 825)
                            mscro4 = 825;
                    }
                    if(dispi != 0)
                    {
                        int i_239 = 558;
                        if(viewgame2 != 0)
                            i_239 = 577;
                        rd.setColor(color2k(220, 220, 220));
                        rd.fillRect(207, 86, i_239, 41);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawRect(207, 86, i_239, 41);
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.setColor(new Color(0, 0, 0));
                        if(dispi == 1)
                        {
                            rd.drawString((new StringBuilder()).append("Car battle with ").append(intclan).append(" is on!").toString(), 215, 101);
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("You win: [ ").append(dtcar).append(" ]").toString(), 215, 118);
                            int i_240 = 215 + ftm.stringWidth((new StringBuilder()).append("You win: [ ").append(dtcar).append(" ]").toString()) + 44;
                            if(stringbutton(rd, "View Car", i_240, 119, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = dtcar;
                                if(!claname.equals(intclan))
                                {
                                    claname = intclan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedcars = -1;
                                loadedcar = 0;
                                ctab = 2;
                                tab = 3;
                            }
                            i_240 += 44;
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            rd.drawString((new StringBuilder()).append("You lose: [ ").append(dgcar).append(" ]").toString(), i_240, 118);
                            i_240 += ftm.stringWidth((new StringBuilder()).append("You lose: [ ").append(dgcar).append(" ]").toString()) + 44;
                            if(stringbutton(rd, "View Car", i_240, 119, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = dgcar;
                                if(!claname.equals(xt.clan))
                                {
                                    claname = xt.clan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedcars = -1;
                                loadedcar = 0;
                                ctab = 2;
                                tab = 3;
                            }
                            if(stringbutton(rd, "View Battle", 714, 111, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame2 = 1;
                                nvgames2 = 5;
                                viewwar2 = dwarn;
                            }
                        }
                        if(dispi == 2)
                        {
                            rd.drawString((new StringBuilder()).append("Stage battle with ").append(intclan).append(" is on!").toString(), 215, 101);
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            String string = dtcar;
                            if(string.length() > 10)
                                string = (new StringBuilder()).append("").append(string.substring(0, 10)).append("...").toString();
                            rd.drawString((new StringBuilder()).append("You win: [ ").append(string).append(" ]").toString(), 215, 118);
                            int i_241 = 215 + ftm.stringWidth((new StringBuilder()).append("You win: [ ").append(string).append(" ]").toString()) + 51;
                            if(stringbutton(rd, "View Stage", i_241, 119, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = dtcar;
                                if(!claname.equals(intclan))
                                {
                                    claname = intclan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedstages = -1;
                                loadedstage = 0;
                                ctab = 3;
                                tab = 3;
                            }
                            i_241 += 51;
                            rd.setFont(new Font("Arial", 0, 11));
                            ftm = rd.getFontMetrics();
                            string = dgcar;
                            if(string.length() > 10)
                                string = (new StringBuilder()).append("").append(string.substring(0, 10)).append("...").toString();
                            rd.drawString((new StringBuilder()).append("You lose: [ ").append(string).append(" ]").toString(), i_241, 118);
                            i_241 += ftm.stringWidth((new StringBuilder()).append("You lose: [ ").append(string).append(" ]").toString()) + 51;
                            if(stringbutton(rd, "View Stage", i_241, 119, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = dgcar;
                                if(!claname.equals(xt.clan))
                                {
                                    claname = xt.clan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedstages = -1;
                                loadedstage = 0;
                                ctab = 3;
                                tab = 3;
                            }
                            if(stringbutton(rd, "View Battle", 714, 111, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame2 = 1;
                                nvgames2 = 5;
                                viewwar2 = dwarn;
                            }
                        }
                        if(dispi == 3)
                        {
                            rd.drawString((new StringBuilder()).append("War between your clan and ").append(intclan).append(" has started!").toString(), 227, 111);
                            if(stringbutton(rd, "         View War         ", 670, 111, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame2 = 1;
                                nvgames2 = 9;
                                viewwar2 = dwarn;
                            }
                        }
                    }
                    if(viewgame2 != 0)
                    {
                        rd.setColor(color2k(210, 210, 210));
                        rd.fillRoundRect(204, 127, 583, 230, 20, 20);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawRoundRect(204, 127, 583, 230, 20, 20);
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        if(nvgames2 == 4)
                        {
                            rd.drawString((new StringBuilder()).append("War declaration, your clan ").append(xt.clan).append(" versus ").append(intclan).append(".").toString(), 215, 145);
                            if(viewgame2 == 2)
                                if(ichlng)
                                    rd.drawString((new StringBuilder()).append("").append(intclan).append(" would create 5 more games and the first clan to win 5 games wins the war!").toString(), 215, 210 + nvgames2 * 18);
                                else
                                    rd.drawString("Your clan would create 5 more games and the first clan to win 5 games wins the war!", 215, 210 + nvgames2 * 18);
                        }
                        if(nvgames2 == 2)
                        {
                            rd.drawString((new StringBuilder()).append("Battle, your clan ").append(xt.clan).append(" versus ").append(intclan).append(".").toString(), 215, 145);
                            if(viewgame2 == 2)
                                if(ichlng)
                                    rd.drawString((new StringBuilder()).append("").append(intclan).append(" would create 3 more games and the first clan to win 3 games wins the battle!").toString(), 215, 210 + nvgames2 * 18);
                                else
                                    rd.drawString("Your clan would create 3 more games and the first clan to win 3 games wins the battle!", 215, 210 + nvgames2 * 18);
                        }
                        if((nvgames2 == 9 || nvgames2 == 5) && viewgame2 == 2)
                        {
                            rd.drawString((new StringBuilder()).append("").append(xt.clan).append("  ").append(vwscorex).append("           |           ").append(intclan).append("  ").append(vwscorei).append("").toString(), 505 - ftm.stringWidth((new StringBuilder()).append("").append(xt.clan).append("  ").append(vwscorex).append("           |           ").append(intclan).append("  ").append(vwscorei).append("").toString()) / 2, 145);
                            rd.drawRect(320, 131, 370, 19);
                        }
                        if(stringbutton(rd, "Close X", 749, 148, 3, i, i_186, bool, 0, 0))
                            viewgame2 = 0;
                        rd.setFont(new Font("Tahoma", 1, 11));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        if(viewgame2 == 2)
                        {
                            rd.drawString("Game", 246 - ftm.stringWidth("Game") / 2, 175);
                            rd.drawString("Stage", 412 - ftm.stringWidth("Stage") / 2, 175);
                            rd.drawString("Laps", 564 - ftm.stringWidth("Laps") / 2, 175);
                            rd.drawString("Type of Cars", 653 - ftm.stringWidth("Type of Cars") / 2, 175);
                            rd.drawString("Fixing", 751 - ftm.stringWidth("Fixing") / 2, 175);
                            int i_242 = 1;
                            int i_243 = 1;
                            if(nvgames2 == 4 || nvgames2 == 2)
                            {
                                i_242 = 2;
                                i_243 = 2;
                            }
                            for(int i_244 = 0; i_244 < nvgames2; i_244++)
                            {
                                if(!vwinner[i_244].equals(""))
                                {
                                    rd.setColor(color2k(220, 220, 220));
                                    rd.fillRect(213, 180 + i_244 * 18, 565, 18);
                                    rd.setColor(new Color(0, 0, 0));
                                }
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                rd.drawString((new StringBuilder()).append("# ").append(i_242).append("").toString(), 246 - ftm.stringWidth((new StringBuilder()).append("# ").append(i_242).append("").toString()) / 2, 193 + i_244 * 18);
                                i_242 += i_243;
                                rd.drawString(vwstages2[i_244], 412 - ftm.stringWidth(vwstages2[i_244]) / 2, 193 + i_244 * 18);
                                rd.drawString((new StringBuilder()).append("").append(vwlaps2[i_244]).append("").toString(), 564 - ftm.stringWidth((new StringBuilder()).append("").append(vwlaps2[i_244]).append("").toString()) / 2, 193 + i_244 * 18);
                                String string = "All Cars";
                                if(vwcars2[i_244] == 2)
                                    string = "Clan Cars";
                                if(vwcars2[i_244] == 3)
                                    string = "Game Cars";
                                if(vwclass2[i_244] == 0)
                                    string = (new StringBuilder()).append(string).append(", All Classes").toString();
                                if(vwclass2[i_244] == 1)
                                    string = (new StringBuilder()).append(string).append(", Class C").toString();
                                if(vwclass2[i_244] == 2)
                                    string = (new StringBuilder()).append(string).append(", Class B & C").toString();
                                if(vwclass2[i_244] == 3)
                                    string = (new StringBuilder()).append(string).append(", Class B").toString();
                                if(vwclass2[i_244] == 4)
                                    string = (new StringBuilder()).append(string).append(", Class A & B").toString();
                                if(vwclass2[i_244] == 5)
                                    string = (new StringBuilder()).append(string).append(", Class A").toString();
                                rd.drawString(string, 653 - ftm.stringWidth(string) / 2, 193 + i_244 * 18);
                                String string_245 = "Infinite";
                                if(vwfix2[i_244] == 1)
                                    string_245 = "4 Fixes";
                                if(vwfix2[i_244] == 2)
                                    string_245 = "3 Fixes";
                                if(vwfix2[i_244] == 3)
                                    string_245 = "2 Fixes";
                                if(vwfix2[i_244] == 4)
                                    string_245 = "1 Fix";
                                if(vwfix2[i_244] == 5)
                                    string_245 = "No Fixing";
                                rd.drawString(string_245, 751 - ftm.stringWidth(string_245) / 2, 193 + i_244 * 18);
                                rd.drawRect(213, 180 + i_244 * 18, 565, 18);
                            }

                            rd.drawLine(213, 162, 213, 180 + nvgames2 * 18);
                            rd.drawLine(279, 162, 279, 180 + nvgames2 * 18);
                            rd.drawLine(546, 162, 546, 180 + nvgames2 * 18);
                            rd.drawLine(583, 162, 583, 180 + nvgames2 * 18);
                            rd.drawLine(723, 162, 723, 180 + nvgames2 * 18);
                            rd.drawLine(778, 162, 778, 180 + nvgames2 * 18);
                            for(int i_246 = 0; i_246 < nvgames2; i_246++)
                                if(i > 213 && i < 778 && i_186 > 180 + i_246 * 18 && i_186 < 198 + i_246 * 18 && !vwinner[i_246].equals(""))
                                {
                                    rd.setColor(color2k(230, 230, 230));
                                    rd.fillRect(213, 180 + i_246 * 18, 565, 18);
                                    rd.setColor(new Color(0, 0, 0));
                                    rd.setFont(new Font("Tahoma", 1, 11));
                                    ftm = rd.getFontMetrics();
                                    rd.drawString((new StringBuilder()).append("").append(vwinner[i_246]).append("  Wins!").toString(), 495 - ftm.stringWidth((new StringBuilder()).append("").append(vwinner[i_246]).append("  Wins!").toString()) / 2, 193 + i_246 * 18);
                                    rd.drawRect(213, 180 + i_246 * 18, 565, 18);
                                }

                        }
                        if(viewgame2 == 1)
                            rd.drawString("Loading...", 495 - ftm.stringWidth("Loading...") / 2, 242);
                        if(viewgame2 == 3)
                        {
                            if(nvgames2 == 4 || nvgames2 == 9)
                                rd.drawString("This war has expired and no longer exists.", 495 - ftm.stringWidth("This war has expired and no longer exists.") / 2, 232);
                            if(nvgames2 == 2 || nvgames2 == 5)
                                rd.drawString("This battle has expired and no longer exists.", 495 - ftm.stringWidth("This battle has expired and no longer exists.") / 2, 232);
                            if(nvgames2 == 9 || nvgames2 == 5)
                                rd.drawString("(Started/finished wars and battles expire after 180 days.)", 495 - ftm.stringWidth("(Started/finished wars and battles expire after 180 days.)") / 2, 252);
                            else
                                rd.drawString("(Suggestions expire after 90 days.)", 495 - ftm.stringWidth("(Suggestions expire after 90 days.)") / 2, 252);
                        }
                        if(viewgame2 == 4)
                            rd.drawString("Error loading games, please try again later...", 495 - ftm.stringWidth("Error loading games, please try again later...") / 2, 242);
                    }
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    if(!drawl(rd, (new StringBuilder()).append("#").append(intclan).append("#").toString(), 207, 47, true))
                    {
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString(intclan, 382 - ftm.stringWidth(intclan) / 2, 66);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawRect(207, 47, 349, 29);
                    }
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("::  Versus your clan", 566, 72);
                    if(i > 207 && i < 557 && i_186 > 47 && i_186 < 77)
                    {
                        cur = 12;
                        if(bool)
                        {
                            if(!claname.equals(intclan))
                            {
                                claname = intclan;
                                loadedc = false;
                            }
                            spos5 = 0;
                            lspos5 = 0;
                            cfase = 3;
                            ctab = 0;
                            tab = 3;
                        }
                    }
                    if(stringbutton(rd, "Close X", 752, 66, 0, i, i_186, bool, 0, 0))
                    {
                        openi = 0;
                        readint = 0;
                        viewgame2 = 0;
                    }
                    if(gs.sendtyp.getSelectedIndex() < 5)
                    {
                        if(!gs.sendtyp.isShowing())
                            gs.sendtyp.show();
                        gs.sendtyp.move(207, 365);
                    } else
                    {
                        gs.sendtyp.hide();
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.setColor(new Color(0, 0, 0));
                        if(gs.sendtyp.getSelectedIndex() == 5)
                            rd.drawString("::  Accept Stage Battle", 207, 382);
                        if(gs.sendtyp.getSelectedIndex() == 6)
                            rd.drawString("::  Accept Car Battle", 207, 382);
                        if(gs.sendtyp.getSelectedIndex() == 7)
                            rd.drawString("::  Accept War", 207, 382);
                        if(stringbutton(rd, "  Cancel  ", 742, 382, 3, i, i_186, bool, 0, 0))
                            gs.sendtyp.select(0);
                    }
                    if(sendint != 0)
                        gs.sendtyp.disable();
                    else
                        gs.sendtyp.enable();
                    if(intsel != gs.sendtyp.getSelectedIndex())
                    {
                        gs.senditem.hide();
                        gs.datat.hide();
                        gs.ilaps.hide();
                        gs.icars.hide();
                        gs.sclass.hide();
                        gs.sfix.hide();
                        gs.senditem.enable();
                        gs.datat.enable();
                        gs.ilaps.enable();
                        gs.icars.enable();
                        gs.sclass.enable();
                        gs.sfix.enable();
                        intsel = gs.sendtyp.getSelectedIndex();
                        inishsel = true;
                    }
                    if(gs.sendtyp.getSelectedIndex() == 0)
                    {
                        dommsg = true;
                        if(sendint == 0)
                        {
                            if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0) && !gs.mmsg.getText().trim().equals("") && gs.mmsg.getText().toLowerCase().indexOf(gs.tpass.getText().toLowerCase()) == -1 && xt.acexp != -3)
                                if(!xt.msgcheck(gs.mmsg.getText()))
                                {
                                    sendint = 1;
                                } else
                                {
                                    gs.sendtyp.hide();
                                    xt.warning++;
                                }
                        } else
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 1)
                    {
                        rd.setFont(new Font("Arial", 0, 12));
                        rd.drawString("A date that gets converted to the local time of any person previewing it.", 376, 382);
                        if(!gs.senditem.isShowing())
                        {
                            gs.senditem.removeAll();
                            Calendar calendar = Calendar.getInstance();
                            boolean bool_247 = false;
                            for(int i_248 = 0; i_248 < 20; i_248++)
                            {
                                String strings[] = wday;
                                Calendar calendar_249 = calendar;
                                if(calendar == null);
                                String string = strings[calendar_249.get(7) - 1];
                                if(!bool_247)
                                {
                                    string = "Today";
                                    bool_247 = true;
                                }
                                Smenu smenu = gs.senditem;
                                Graphics2D graphics2d = rd;
                                StringBuilder stringbuilder = (new StringBuilder()).append("").append(string).append("  -  ");
                                String strings_250[] = month;
                                Calendar calendar_251 = calendar;
                                if(calendar == null);
                                StringBuilder stringbuilder_252 = stringbuilder.append(strings_250[calendar_251.get(2)]).append(" ");
                                Calendar calendar_253 = calendar;
                                if(calendar == null);
                                smenu.add(graphics2d, stringbuilder_252.append(calendar_253.get(5)).append("").toString());
                                Calendar calendar_254 = calendar;
                                if(calendar == null);
                                calendar_254.roll(5, true);
                            }

                            gs.senditem.select(0);
                            gs.senditem.show();
                        }
                        if(!gs.datat.isShowing())
                        {
                            gs.datat.removeAll();
                            int i_255 = 12;
                            String string = "PM";
                            for(int i_256 = 0; i_256 < 24; i_256++)
                            {
                                gs.datat.add(rd, (new StringBuilder()).append("").append(i_255).append(" ").append(string).append("").toString());
                                if(++i_255 == 12)
                                    string = "AM";
                                if(i_255 == 13)
                                    i_255 = 1;
                            }

                            gs.datat.select(0);
                            gs.datat.show();
                        }
                        gs.senditem.move(300, 395);
                        gs.datat.move(491, 395);
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Date is displayed based on your computer calendar's date/time, please make sure it is correct.", 207, 435);
                        if(sendint == 0)
                        {
                            if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0))
                                sendint = 1;
                        } else
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 2)
                    {
                        if(inishsel)
                        {
                            if(redif)
                            {
                                ifas = 1;
                                gs.datat.removeAll();
                                for(int i_257 = 0; i_257 < gs.clcars.getItemCount(); i_257++)
                                    gs.datat.add(rd, gs.clcars.getItem(i_257));

                                gs.datat.select(gs.clcars.getSelectedIndex());
                                redif = false;
                            } else
                            {
                                ifas = 0;
                                gs.datat.removeAll();
                                gs.datat.add(rd, (new StringBuilder()).append("Loading ").append(intclan).append("'s stages, please wait...").toString());
                            }
                            imsg = (new StringBuilder()).append("Battle over a stage that belongs to ").append(intclan).append(" to take it.").toString();
                            iflk = 0;
                            if(sendwarnum)
                            {
                                ifas = 4;
                                sendint = 1;
                                gs.senditem.disable();
                                gs.datat.disable();
                                gs.ilaps.disable();
                                gs.icars.disable();
                                gs.sclass.disable();
                                gs.sfix.disable();
                            }
                        }
                        rd.setFont(new Font("Arial", 0, 12));
                        if(iflk % 3 != 0 || iflk == 0)
                            rd.drawString(imsg, 376, 382);
                        if(iflk != 0)
                            iflk--;
                        if(ifas == 0 || ifas == 1)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Choose the stage of ").append(intclan).append(" you want to take to your clan, if you win!").toString(), 207, 402);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(495 - gs.datat.getWidth() / 2, 410);
                        }
                        if(ifas == 2 || ifas == 3)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Choose a stage of your clan that you would give to ").append(intclan).append(", if you lose!").toString(), 207, 402);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(495 - gs.datat.getWidth() / 2, 410);
                        }
                        if(ifas == 4 || ifas == 5)
                        {
                            if(ifas == 4)
                            {
                                isel = 0;
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, " NFM Multiplayer ");
                                gs.senditem.add(rd, " NFM 2     ");
                                gs.senditem.add(rd, " NFM 1     ");
                                gs.senditem.add(rd, " Clan Stages ");
                                gs.senditem.select(0);
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_258 = 0; i_258 < 5; i_258++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_258 + 1).append("").toString());

                                gs.datat.select(0);
                                gs.ilaps.hide();
                                gs.icars.hide();
                                gs.sclass.hide();
                                gs.sfix.hide();
                                ifas = 5;
                            }
                            rd.setFont(new Font("Arial", 0, 12));
                            if(iflk % 3 != 0 || iflk == 0)
                                rd.drawString(imsg, 376, 382);
                            if(iflk != 0)
                                iflk--;
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Game #").append(wag * 2 + 2).append(" :").toString(), 207, 407);
                            if(!gs.senditem.isShowing())
                                gs.senditem.show();
                            gs.senditem.move(280, 390);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(286 + gs.senditem.getWidth(), 390);
                            int i_259 = 207;
                            if(!gs.ilaps.isShowing())
                            {
                                gs.ilaps.show();
                                gs.ilaps.select(0);
                            }
                            gs.ilaps.move(i_259, 415);
                            i_259 += 6 + gs.ilaps.getWidth();
                            if(!gs.icars.isShowing())
                            {
                                gs.icars.show();
                                gs.icars.select(0);
                            }
                            gs.icars.move(i_259, 415);
                            i_259 += 6 + gs.icars.getWidth();
                            if(!gs.sclass.isShowing())
                            {
                                gs.sclass.show();
                                gs.sclass.select(0);
                            }
                            gs.sclass.move(i_259, 415);
                            gs.sclass.revup = true;
                            i_259 += 6 + gs.sclass.getWidth();
                            if(!gs.sfix.isShowing())
                            {
                                gs.sfix.show();
                                gs.sfix.select(0);
                            }
                            gs.sfix.move(i_259, 415);
                            gs.sfix.revup = true;
                            gs.datat.setSize((i_259 + gs.sfix.getWidth()) - 286 - gs.senditem.getWidth(), 22);
                            if(gs.senditem.getSelectedIndex() == 0 && isel != 0)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_260 = 0; i_260 < 5; i_260++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_260 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 0;
                            }
                            if(gs.senditem.getSelectedIndex() == 1 && isel != 1)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_261 = 0; i_261 < 17; i_261++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_261 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 1;
                            }
                            if(gs.senditem.getSelectedIndex() == 2 && isel != 2)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_262 = 0; i_262 < 10; i_262++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_262 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 2;
                            }
                            if(gs.senditem.getSelectedIndex() == 3 && isel < 3)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Loading stages, please wait...");
                                gs.datat.select(0);
                                isel = 3;
                            }
                        }
                        if(sendint == 0)
                        {
                            String string = "  Next >  ";
                            if(ifas == 5 && wag == 1)
                                string = "   Done   ";
                            if(stringbutton(rd, string, 742, 417, 0, i, i_186, bool, 0, 0))
                            {
                                if(ifas == 4 || ifas == 5)
                                    if(gs.datat.getSelectedIndex() != 0)
                                    {
                                        if(gs.ilaps.getSelectedIndex() != 0)
                                        {
                                            if(gs.icars.getSelectedIndex() != 0)
                                            {
                                                if(gs.senditem.getSelectedIndex() == 0)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 27).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 1)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 10).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 2)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex()).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 3)
                                                    wstages[wag] = (new StringBuilder()).append("").append(gs.datat.getSelectedItem()).append("").toString();
                                                wlaps[wag] = gs.ilaps.getSelectedIndex();
                                                wcars[wag] = gs.icars.getSelectedIndex();
                                                wclass[wag] = gs.sclass.getSelectedIndex();
                                                wfix[wag] = gs.sfix.getSelectedIndex();
                                                wag++;
                                                if(wag < 2)
                                                {
                                                    ifas = 4;
                                                    imsg = "Create second game.";
                                                } else
                                                {
                                                    wag--;
                                                    sendint = 1;
                                                    gs.senditem.disable();
                                                    gs.datat.disable();
                                                    gs.ilaps.disable();
                                                    gs.icars.disable();
                                                    gs.sclass.disable();
                                                    gs.sfix.disable();
                                                }
                                            } else
                                            {
                                                imsg = "Please choose a type of cars for this game!";
                                                iflk = 40;
                                            }
                                        } else
                                        {
                                            imsg = "Please select a number of laps!";
                                            iflk = 40;
                                        }
                                    } else
                                    {
                                        imsg = "Please select a stage!";
                                        iflk = 40;
                                    }
                                if(ifas == 2 || ifas == 3)
                                    if(gs.datat.getSelectedIndex() == 0)
                                    {
                                        imsg = (new StringBuilder()).append("Please choose a stage to give to ").append(intclan).append(" if you lose!").toString();
                                        iflk = 40;
                                    } else
                                    {
                                        imsg = (new StringBuilder()).append("Create 2 games and ").append(intclan).append(" will create another 3.").toString();
                                        iflk = 0;
                                        igive = gs.datat.getSelectedItem();
                                        ifas = 4;
                                        wag = 0;
                                    }
                                if(ifas == 0 || ifas == 1)
                                    if(gs.datat.getSelectedIndex() == 0)
                                    {
                                        imsg = "Please choose a stage to battle over!";
                                        iflk = 40;
                                    } else
                                    {
                                        imsg = (new StringBuilder()).append("Battle over a stage that belongs to ").append(intclan).append(" to take it.").toString();
                                        iflk = 0;
                                        itake = gs.datat.getSelectedItem();
                                        gs.datat.removeAll();
                                        gs.datat.add(rd, "Loading your clan's stages, please wait...");
                                        ifas = 2;
                                    }
                            }
                        } else
                        {
                            imsg = "Sending stage battle, pleas wait...";
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 742 - ftm.stringWidth("Sending...") / 2, 417);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 3)
                    {
                        if(inishsel)
                        {
                            if(redif)
                            {
                                ifas = 1;
                                gs.datat.removeAll();
                                for(int i_263 = 0; i_263 < gs.clcars.getItemCount(); i_263++)
                                    gs.datat.add(rd, gs.clcars.getItem(i_263));

                                gs.datat.select(gs.clcars.getSelectedIndex());
                                redif = false;
                            } else
                            {
                                ifas = 0;
                                gs.datat.removeAll();
                                gs.datat.add(rd, (new StringBuilder()).append("Loading ").append(intclan).append("'s cars, please wait...").toString());
                            }
                            imsg = (new StringBuilder()).append("Battle over a car that belongs to ").append(intclan).append(" to take it.").toString();
                            iflk = 0;
                            if(sendwarnum)
                            {
                                ifas = 4;
                                sendint = 1;
                                gs.senditem.disable();
                                gs.datat.disable();
                                gs.ilaps.disable();
                                gs.icars.disable();
                                gs.sclass.disable();
                                gs.sfix.disable();
                            }
                        }
                        rd.setFont(new Font("Arial", 0, 12));
                        if(iflk % 3 != 0 || iflk == 0)
                            rd.drawString(imsg, 376, 382);
                        if(iflk != 0)
                            iflk--;
                        if(ifas == 0 || ifas == 1)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Choose the car of ").append(intclan).append(" you want to take to your clan, if you win!").toString(), 207, 402);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(495 - gs.datat.getWidth() / 2, 410);
                        }
                        if(ifas == 2 || ifas == 3)
                        {
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Choose a car of your clan that you would give to ").append(intclan).append(", if you lose!").toString(), 207, 402);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(495 - gs.datat.getWidth() / 2, 410);
                        }
                        if(ifas == 4 || ifas == 5)
                        {
                            if(ifas == 4)
                            {
                                isel = 0;
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, " NFM Multiplayer ");
                                gs.senditem.add(rd, " NFM 2     ");
                                gs.senditem.add(rd, " NFM 1     ");
                                gs.senditem.add(rd, " Clan Stages ");
                                gs.senditem.select(0);
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_264 = 0; i_264 < 5; i_264++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_264 + 1).append("").toString());

                                gs.datat.select(0);
                                gs.ilaps.hide();
                                gs.icars.hide();
                                gs.sclass.hide();
                                gs.sfix.hide();
                                ifas = 5;
                            }
                            rd.setFont(new Font("Arial", 0, 12));
                            if(iflk % 3 != 0 || iflk == 0)
                                rd.drawString(imsg, 376, 382);
                            if(iflk != 0)
                                iflk--;
                            rd.setFont(new Font("Arial", 1, 12));
                            rd.drawString((new StringBuilder()).append("Game #").append(wag * 2 + 2).append(" :").toString(), 207, 407);
                            if(!gs.senditem.isShowing())
                                gs.senditem.show();
                            gs.senditem.move(280, 390);
                            if(!gs.datat.isShowing())
                                gs.datat.show();
                            gs.datat.move(286 + gs.senditem.getWidth(), 390);
                            int i_265 = 207;
                            if(!gs.ilaps.isShowing())
                            {
                                gs.ilaps.show();
                                gs.ilaps.select(0);
                            }
                            gs.ilaps.move(i_265, 415);
                            i_265 += 6 + gs.ilaps.getWidth();
                            if(!gs.icars.isShowing())
                            {
                                gs.icars.show();
                                gs.icars.select(0);
                            }
                            gs.icars.move(i_265, 415);
                            i_265 += 6 + gs.icars.getWidth();
                            if(!gs.sclass.isShowing())
                            {
                                gs.sclass.show();
                                gs.sclass.select(0);
                            }
                            gs.sclass.move(i_265, 415);
                            gs.sclass.revup = true;
                            i_265 += 6 + gs.sclass.getWidth();
                            if(!gs.sfix.isShowing())
                            {
                                gs.sfix.show();
                                gs.sfix.select(0);
                            }
                            gs.sfix.move(i_265, 415);
                            gs.sfix.revup = true;
                            gs.datat.setSize((i_265 + gs.sfix.getWidth()) - 286 - gs.senditem.getWidth(), 22);
                            if(gs.senditem.getSelectedIndex() == 0 && isel != 0)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_266 = 0; i_266 < 5; i_266++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_266 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 0;
                            }
                            if(gs.senditem.getSelectedIndex() == 1 && isel != 1)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_267 = 0; i_267 < 17; i_267++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_267 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 1;
                            }
                            if(gs.senditem.getSelectedIndex() == 2 && isel != 2)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Select Stage");
                                for(int i_268 = 0; i_268 < 10; i_268++)
                                    gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_268 + 1).append("").toString());

                                gs.datat.select(0);
                                isel = 2;
                            }
                            if(gs.senditem.getSelectedIndex() == 3 && isel < 3)
                            {
                                gs.datat.removeAll();
                                gs.datat.add(rd, "Loading stages, please wait...");
                                gs.datat.select(0);
                                isel = 3;
                            }
                        }
                        if(sendint == 0)
                        {
                            String string = "  Next >  ";
                            if(ifas == 5 && wag == 1)
                                string = "   Done   ";
                            if(stringbutton(rd, string, 742, 417, 0, i, i_186, bool, 0, 0))
                            {
                                if(ifas == 4 || ifas == 5)
                                    if(gs.datat.getSelectedIndex() != 0)
                                    {
                                        if(gs.ilaps.getSelectedIndex() != 0)
                                        {
                                            if(gs.icars.getSelectedIndex() != 0)
                                            {
                                                if(gs.senditem.getSelectedIndex() == 0)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 27).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 1)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 10).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 2)
                                                    wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex()).append("").toString();
                                                if(gs.senditem.getSelectedIndex() == 3)
                                                    wstages[wag] = (new StringBuilder()).append("").append(gs.datat.getSelectedItem()).append("").toString();
                                                wlaps[wag] = gs.ilaps.getSelectedIndex();
                                                wcars[wag] = gs.icars.getSelectedIndex();
                                                wclass[wag] = gs.sclass.getSelectedIndex();
                                                wfix[wag] = gs.sfix.getSelectedIndex();
                                                wag++;
                                                if(wag < 2)
                                                {
                                                    ifas = 4;
                                                    imsg = "Create second game.";
                                                } else
                                                {
                                                    wag--;
                                                    sendint = 1;
                                                    gs.senditem.disable();
                                                    gs.datat.disable();
                                                    gs.ilaps.disable();
                                                    gs.icars.disable();
                                                    gs.sclass.disable();
                                                    gs.sfix.disable();
                                                }
                                            } else
                                            {
                                                imsg = "Please choose a type of cars for this game!";
                                                iflk = 40;
                                            }
                                        } else
                                        {
                                            imsg = "Please select a number of laps!";
                                            iflk = 40;
                                        }
                                    } else
                                    {
                                        imsg = "Please select a stage!";
                                        iflk = 40;
                                    }
                                if(ifas == 2 || ifas == 3)
                                    if(gs.datat.getSelectedIndex() == 0)
                                    {
                                        imsg = (new StringBuilder()).append("Please choose a car to give to ").append(intclan).append(" if you lose!").toString();
                                        iflk = 40;
                                    } else
                                    {
                                        imsg = (new StringBuilder()).append("Create 2 games and ").append(intclan).append(" will create another 3.").toString();
                                        iflk = 0;
                                        igive = gs.datat.getSelectedItem();
                                        ifas = 4;
                                        wag = 0;
                                    }
                                if(ifas == 0 || ifas == 1)
                                    if(gs.datat.getSelectedIndex() == 0)
                                    {
                                        imsg = "Please choose a car to battle over!";
                                        iflk = 40;
                                    } else
                                    {
                                        imsg = (new StringBuilder()).append("Battle over a car that belongs to ").append(intclan).append(" to take it.").toString();
                                        iflk = 0;
                                        itake = gs.datat.getSelectedItem();
                                        gs.datat.removeAll();
                                        gs.datat.add(rd, "Loading your clan's cars, please wait...");
                                        ifas = 2;
                                    }
                            }
                        } else
                        {
                            imsg = "Sending car battle, pleas wait...";
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 742 - ftm.stringWidth("Sending...") / 2, 417);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 4)
                    {
                        if(inishsel || redif)
                        {
                            isel = 0;
                            gs.senditem.removeAll();
                            gs.senditem.add(rd, " NFM Multiplayer ");
                            gs.senditem.add(rd, " NFM 2     ");
                            gs.senditem.add(rd, " NFM 1     ");
                            gs.senditem.add(rd, " Clan Stages ");
                            gs.senditem.select(0);
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_269 = 0; i_269 < 5; i_269++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_269 + 1).append("").toString());

                            gs.datat.select(0);
                            if(!redif)
                            {
                                wag = 0;
                                imsg = (new StringBuilder()).append("Create 4 games and ").append(intclan).append(" will create another 5.").toString();
                                iflk = 0;
                            } else
                            {
                                imsg = "Create next game.";
                                if(wag == 3)
                                    imsg = "Create last game.";
                                iflk = 0;
                                gs.ilaps.hide();
                                gs.icars.hide();
                                gs.sclass.hide();
                                gs.sfix.hide();
                            }
                            if(sendwarnum)
                            {
                                sendint = 1;
                                gs.senditem.disable();
                                gs.datat.disable();
                                gs.ilaps.disable();
                                gs.icars.disable();
                                gs.sclass.disable();
                                gs.sfix.disable();
                            }
                            redif = false;
                        }
                        rd.setFont(new Font("Arial", 0, 12));
                        if(iflk % 3 != 0 || iflk == 0)
                            rd.drawString(imsg, 376, 382);
                        if(iflk != 0)
                            iflk--;
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.drawString((new StringBuilder()).append("Game #").append(wag * 2 + 2).append(" :").toString(), 207, 407);
                        if(!gs.senditem.isShowing())
                            gs.senditem.show();
                        gs.senditem.move(280, 390);
                        if(!gs.datat.isShowing())
                            gs.datat.show();
                        gs.datat.move(286 + gs.senditem.getWidth(), 390);
                        int i_270 = 207;
                        if(!gs.ilaps.isShowing())
                        {
                            gs.ilaps.show();
                            gs.ilaps.select(0);
                        }
                        gs.ilaps.move(i_270, 415);
                        i_270 += 6 + gs.ilaps.getWidth();
                        if(!gs.icars.isShowing())
                        {
                            gs.icars.show();
                            gs.icars.select(0);
                        }
                        gs.icars.move(i_270, 415);
                        i_270 += 6 + gs.icars.getWidth();
                        if(!gs.sclass.isShowing())
                        {
                            gs.sclass.show();
                            gs.sclass.select(0);
                        }
                        gs.sclass.move(i_270, 415);
                        gs.sclass.revup = true;
                        i_270 += 6 + gs.sclass.getWidth();
                        if(!gs.sfix.isShowing())
                        {
                            gs.sfix.show();
                            gs.sfix.select(0);
                        }
                        gs.sfix.move(i_270, 415);
                        gs.sfix.revup = true;
                        gs.datat.setSize((i_270 + gs.sfix.getWidth()) - 286 - gs.senditem.getWidth(), 22);
                        if(gs.senditem.getSelectedIndex() == 0 && isel != 0)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_271 = 0; i_271 < 5; i_271++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_271 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 0;
                        }
                        if(gs.senditem.getSelectedIndex() == 1 && isel != 1)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_272 = 0; i_272 < 17; i_272++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_272 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 1;
                        }
                        if(gs.senditem.getSelectedIndex() == 2 && isel != 2)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_273 = 0; i_273 < 10; i_273++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_273 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 2;
                        }
                        if(gs.senditem.getSelectedIndex() == 3 && isel < 3)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Loading stages, please wait...");
                            gs.datat.select(0);
                            isel = 3;
                        }
                        if(sendint == 0)
                        {
                            String string = "  Next >  ";
                            if(wag == 3)
                                string = "   Done   ";
                            if(stringbutton(rd, string, 742, 417, 0, i, i_186, bool, 0, 0))
                                if(gs.datat.getSelectedIndex() != 0)
                                {
                                    if(gs.ilaps.getSelectedIndex() != 0)
                                    {
                                        if(gs.icars.getSelectedIndex() != 0)
                                        {
                                            if(gs.senditem.getSelectedIndex() == 0)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 27).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 1)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 10).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 2)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex()).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 3)
                                                wstages[wag] = (new StringBuilder()).append("").append(gs.datat.getSelectedItem()).append("").toString();
                                            wlaps[wag] = gs.ilaps.getSelectedIndex();
                                            wcars[wag] = gs.icars.getSelectedIndex();
                                            wclass[wag] = gs.sclass.getSelectedIndex();
                                            wfix[wag] = gs.sfix.getSelectedIndex();
                                            wag++;
                                            if(wag < 4)
                                            {
                                                redif = true;
                                            } else
                                            {
                                                wag--;
                                                sendint = 1;
                                                gs.senditem.disable();
                                                gs.datat.disable();
                                                gs.ilaps.disable();
                                                gs.icars.disable();
                                                gs.sclass.disable();
                                                gs.sfix.disable();
                                            }
                                        } else
                                        {
                                            imsg = "Please choose a type of cars for this game!";
                                            iflk = 40;
                                        }
                                    } else
                                    {
                                        imsg = "Please select a number of laps!";
                                        iflk = 40;
                                    }
                                } else
                                {
                                    imsg = "Please select a stage!";
                                    iflk = 40;
                                }
                        } else
                        {
                            imsg = "Sending war declaration, pleas wait...";
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 742 - ftm.stringWidth("Sending...") / 2, 417);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 5 || gs.sendtyp.getSelectedIndex() == 6)
                    {
                        if(inishsel || redif)
                        {
                            isel = 0;
                            gs.senditem.removeAll();
                            gs.senditem.add(rd, " NFM Multiplayer ");
                            gs.senditem.add(rd, " NFM 2     ");
                            gs.senditem.add(rd, " NFM 1     ");
                            gs.senditem.add(rd, " Clan Stages ");
                            gs.senditem.select(0);
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_274 = 0; i_274 < 5; i_274++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_274 + 1).append("").toString());

                            gs.datat.select(0);
                            if(!redif)
                            {
                                wag = 0;
                                imsg = "Create 3 games to be added to the battle.";
                                iflk = 0;
                            } else
                            {
                                imsg = "Create next game.";
                                if(wag == 2)
                                    imsg = "Create last game.";
                                iflk = 0;
                                gs.ilaps.hide();
                                gs.icars.hide();
                                gs.sclass.hide();
                                gs.sfix.hide();
                            }
                            if(sendwarnum)
                            {
                                sendint = 1;
                                gs.senditem.disable();
                                gs.datat.disable();
                                gs.ilaps.disable();
                                gs.icars.disable();
                                gs.sclass.disable();
                                gs.sfix.disable();
                            }
                            redif = false;
                        }
                        rd.setFont(new Font("Arial", 0, 12));
                        if(iflk % 3 != 0 || iflk == 0)
                            rd.drawString(imsg, 350, 382);
                        if(iflk != 0)
                            iflk--;
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.drawString((new StringBuilder()).append("Game #").append(wag * 2 + 1).append(" :").toString(), 207, 407);
                        if(!gs.senditem.isShowing())
                            gs.senditem.show();
                        gs.senditem.move(280, 390);
                        if(!gs.datat.isShowing())
                            gs.datat.show();
                        gs.datat.move(286 + gs.senditem.getWidth(), 390);
                        int i_275 = 207;
                        if(!gs.ilaps.isShowing())
                        {
                            gs.ilaps.show();
                            gs.ilaps.select(0);
                        }
                        gs.ilaps.move(i_275, 415);
                        i_275 += 6 + gs.ilaps.getWidth();
                        if(!gs.icars.isShowing())
                        {
                            gs.icars.show();
                            gs.icars.select(0);
                        }
                        gs.icars.move(i_275, 415);
                        i_275 += 6 + gs.icars.getWidth();
                        if(!gs.sclass.isShowing())
                        {
                            gs.sclass.show();
                            gs.sclass.select(0);
                        }
                        gs.sclass.move(i_275, 415);
                        gs.sclass.revup = true;
                        i_275 += 6 + gs.sclass.getWidth();
                        if(!gs.sfix.isShowing())
                        {
                            gs.sfix.show();
                            gs.sfix.select(0);
                        }
                        gs.sfix.move(i_275, 415);
                        gs.sfix.revup = true;
                        gs.datat.setSize((i_275 + gs.sfix.getWidth()) - 286 - gs.senditem.getWidth(), 22);
                        if(gs.senditem.getSelectedIndex() == 0 && isel != 0)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_276 = 0; i_276 < 5; i_276++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_276 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 0;
                        }
                        if(gs.senditem.getSelectedIndex() == 1 && isel != 1)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_277 = 0; i_277 < 17; i_277++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_277 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 1;
                        }
                        if(gs.senditem.getSelectedIndex() == 2 && isel != 2)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_278 = 0; i_278 < 10; i_278++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_278 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 2;
                        }
                        if(gs.senditem.getSelectedIndex() == 3 && isel < 3)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Loading stages, please wait...");
                            gs.datat.select(0);
                            isel = 3;
                        }
                        if(sendint == 0)
                        {
                            String string = "  Next >  ";
                            if(wag == 2)
                                string = "   Done   ";
                            if(stringbutton(rd, string, 742, 417, 0, i, i_186, bool, 0, 0))
                                if(gs.datat.getSelectedIndex() != 0)
                                {
                                    if(gs.ilaps.getSelectedIndex() != 0)
                                    {
                                        if(gs.icars.getSelectedIndex() != 0)
                                        {
                                            if(gs.senditem.getSelectedIndex() == 0)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 27).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 1)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 10).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 2)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex()).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 3)
                                                wstages[wag] = (new StringBuilder()).append("").append(gs.datat.getSelectedItem()).append("").toString();
                                            wlaps[wag] = gs.ilaps.getSelectedIndex();
                                            wcars[wag] = gs.icars.getSelectedIndex();
                                            wclass[wag] = gs.sclass.getSelectedIndex();
                                            wfix[wag] = gs.sfix.getSelectedIndex();
                                            wag++;
                                            if(wag < 3)
                                            {
                                                redif = true;
                                            } else
                                            {
                                                wag--;
                                                sendint = 1;
                                                gs.senditem.disable();
                                                gs.datat.disable();
                                                gs.ilaps.disable();
                                                gs.icars.disable();
                                                gs.sclass.disable();
                                                gs.sfix.disable();
                                            }
                                        } else
                                        {
                                            imsg = "Please choose a type of cars for this game!";
                                            iflk = 40;
                                        }
                                    } else
                                    {
                                        imsg = "Please select a number of laps!";
                                        iflk = 40;
                                    }
                                } else
                                {
                                    imsg = "Please select a stage!";
                                    iflk = 40;
                                }
                        } else
                        {
                            imsg = "Sending war declaration, pleas wait...";
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 742 - ftm.stringWidth("Sending...") / 2, 417);
                        }
                    }
                    if(gs.sendtyp.getSelectedIndex() == 7)
                    {
                        if(inishsel || redif)
                        {
                            isel = 0;
                            gs.senditem.removeAll();
                            gs.senditem.add(rd, " NFM Multiplayer ");
                            gs.senditem.add(rd, " NFM 2     ");
                            gs.senditem.add(rd, " NFM 1     ");
                            gs.senditem.add(rd, " Clan Stages ");
                            gs.senditem.select(0);
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_279 = 0; i_279 < 5; i_279++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_279 + 1).append("").toString());

                            gs.datat.select(0);
                            if(!redif)
                            {
                                wag = 0;
                                imsg = "Create 5 games to be added to the war.";
                                iflk = 0;
                            } else
                            {
                                imsg = "Create next game.";
                                if(wag == 4)
                                    imsg = "Create last game.";
                                iflk = 0;
                                gs.ilaps.hide();
                                gs.icars.hide();
                                gs.sclass.hide();
                                gs.sfix.hide();
                            }
                            if(sendwarnum)
                            {
                                sendint = 1;
                                gs.senditem.disable();
                                gs.datat.disable();
                                gs.ilaps.disable();
                                gs.icars.disable();
                                gs.sclass.disable();
                                gs.sfix.disable();
                            }
                            redif = false;
                        }
                        rd.setFont(new Font("Arial", 0, 12));
                        if(iflk % 3 != 0 || iflk == 0)
                            rd.drawString(imsg, 350, 382);
                        if(iflk != 0)
                            iflk--;
                        rd.setFont(new Font("Arial", 1, 12));
                        rd.drawString((new StringBuilder()).append("Game #").append(wag * 2 + 1).append(" :").toString(), 207, 407);
                        if(!gs.senditem.isShowing())
                            gs.senditem.show();
                        gs.senditem.move(280, 390);
                        if(!gs.datat.isShowing())
                            gs.datat.show();
                        gs.datat.move(286 + gs.senditem.getWidth(), 390);
                        int i_280 = 207;
                        if(!gs.ilaps.isShowing())
                        {
                            gs.ilaps.show();
                            gs.ilaps.select(0);
                        }
                        gs.ilaps.move(i_280, 415);
                        i_280 += 6 + gs.ilaps.getWidth();
                        if(!gs.icars.isShowing())
                        {
                            gs.icars.show();
                            gs.icars.select(0);
                        }
                        gs.icars.move(i_280, 415);
                        i_280 += 6 + gs.icars.getWidth();
                        if(!gs.sclass.isShowing())
                        {
                            gs.sclass.show();
                            gs.sclass.select(0);
                        }
                        gs.sclass.move(i_280, 415);
                        gs.sclass.revup = true;
                        i_280 += 6 + gs.sclass.getWidth();
                        if(!gs.sfix.isShowing())
                        {
                            gs.sfix.show();
                            gs.sfix.select(0);
                        }
                        gs.sfix.move(i_280, 415);
                        gs.sfix.revup = true;
                        gs.datat.setSize((i_280 + gs.sfix.getWidth()) - 286 - gs.senditem.getWidth(), 22);
                        if(gs.senditem.getSelectedIndex() == 0 && isel != 0)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_281 = 0; i_281 < 5; i_281++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_281 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 0;
                        }
                        if(gs.senditem.getSelectedIndex() == 1 && isel != 1)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_282 = 0; i_282 < 17; i_282++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_282 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 1;
                        }
                        if(gs.senditem.getSelectedIndex() == 2 && isel != 2)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Select Stage");
                            for(int i_283 = 0; i_283 < 10; i_283++)
                                gs.datat.add(rd, (new StringBuilder()).append(" Stage ").append(i_283 + 1).append("").toString());

                            gs.datat.select(0);
                            isel = 2;
                        }
                        if(gs.senditem.getSelectedIndex() == 3 && isel < 3)
                        {
                            gs.datat.removeAll();
                            gs.datat.add(rd, "Loading stages, please wait...");
                            gs.datat.select(0);
                            isel = 3;
                        }
                        if(sendint == 0)
                        {
                            String string = "  Next >  ";
                            if(wag == 4)
                                string = "   Done   ";
                            if(stringbutton(rd, string, 742, 417, 0, i, i_186, bool, 0, 0))
                                if(gs.datat.getSelectedIndex() != 0)
                                {
                                    if(gs.ilaps.getSelectedIndex() != 0)
                                    {
                                        if(gs.icars.getSelectedIndex() != 0)
                                        {
                                            if(gs.senditem.getSelectedIndex() == 0)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 27).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 1)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex() + 10).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 2)
                                                wstages[wag] = (new StringBuilder()).append("#").append(gs.datat.getSelectedIndex()).append("").toString();
                                            if(gs.senditem.getSelectedIndex() == 3)
                                                wstages[wag] = (new StringBuilder()).append("").append(gs.datat.getSelectedItem()).append("").toString();
                                            wlaps[wag] = gs.ilaps.getSelectedIndex();
                                            wcars[wag] = gs.icars.getSelectedIndex();
                                            wclass[wag] = gs.sclass.getSelectedIndex();
                                            wfix[wag] = gs.sfix.getSelectedIndex();
                                            wag++;
                                            if(wag < 5)
                                            {
                                                redif = true;
                                            } else
                                            {
                                                wag--;
                                                sendint = 1;
                                                gs.senditem.disable();
                                                gs.datat.disable();
                                                gs.ilaps.disable();
                                                gs.icars.disable();
                                                gs.sclass.disable();
                                                gs.sfix.disable();
                                            }
                                        } else
                                        {
                                            imsg = "Please choose a type of cars for this game!";
                                            iflk = 40;
                                        }
                                    } else
                                    {
                                        imsg = "Please select a number of laps!";
                                        iflk = 40;
                                    }
                                } else
                                {
                                    imsg = "Please select a stage!";
                                    iflk = 40;
                                }
                        } else
                        {
                            imsg = "Sending war declaration, pleas wait...";
                            rd.setFont(new Font("Arial", 1, 12));
                            ftm = rd.getFontMetrics();
                            rd.setColor(new Color(0, 0, 0));
                            rd.drawString("Sending...", 742 - ftm.stringWidth("Sending...") / 2, 417);
                        }
                    }
                    if(inishsel)
                        inishsel = false;
                }
                if(openi >= 1 && openi < 10)
                {
                    rd.setColor(color2k(240, 240, 230));
                    rd.fillRoundRect(197, opy, 597, oph, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(197, opy, 597, oph, 20, 20);
                    if(!drawl(rd, (new StringBuilder()).append("#").append(intclan).append("#").toString(), 207, opy + 7, true))
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString(intclan, 382 - ftm.stringWidth(intclan) / 2, opy + 26);
                        rd.setColor(color2k(150, 150, 150));
                        rd.drawRect(207, opy + 7, 349, 29);
                    }
                    opy += addopy;
                    oph += 36;
                    openi++;
                }
            } else
            {
                rd.setColor(color2k(230, 230, 230));
                rd.fillRoundRect(197, 40, 597, 404, 20, 20);
                rd.setColor(new Color(0, 0, 0));
                rd.drawRoundRect(197, 40, 597, 404, 20, 20);
                if(xt.logged)
                {
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("You are not a member of any clan.  You need to join a clan first to have access to this.", 487 - ftm.stringWidth("You are not a member of any clan.  You need to join a clan first to have access to this.") / 2, 200);
                    if(stringbutton(rd, "   Find a clan to join   ", 487, 230, 1, i, i_186, bool, 0, 0))
                    {
                        tab = 3;
                        cfase = 2;
                        em = 1;
                        msg = "Clan Search";
                        smsg = "Listing clans with recent activity...";
                        nclns = 0;
                        spos5 = 0;
                        lspos5 = 0;
                        flko = 0;
                    }
                } else
                {
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString("You are currently using a trial account.", 495 - ftm.stringWidth("You are currently using a trial account.") / 2, 180);
                    rd.drawString("You need to upgrade to be able participate in NFM clan's activities.", 495 - ftm.stringWidth("You need to upgrade to be able participate in NFM clan's activities.") / 2, 200);
                    rd.setColor(new Color(206, 171, 98));
                    rd.fillRoundRect(405, 223, 180, 50, 20, 20);
                    if(drawbutton(xt.upgrade, 495, 248, i, i_186, bool))
                        gs.editlink(xt.nickname, true);
                }
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(207, 46, 582, 30);
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                String strings[] = {
                    "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
                };
                int is[] = {
                    207, 390, 368, 207
                };
                int is_284[] = {
                    73, 73, 51, 51
                };
                for(int i_285 = 0; i_285 < 3; i_285++)
                {
                    if(itab == i_285)
                    {
                        rd.setColor(color2k(230, 230, 230));
                        rd.fillPolygon(is, is_284, 4);
                    } else
                    if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                    {
                        rd.setColor(color2k(217, 217, 217));
                        rd.fillPolygon(is, is_284, 4);
                        if(bool)
                            itab = i_285;
                    }
                    rd.setColor(color2k(150, 150, 150));
                    rd.drawPolygon(is, is_284, 4);
                    rd.setColor(color2k(40, 40, 40));
                    rd.drawString(strings[i_285], (is[0] + 80) - ftm.stringWidth(strings[i_285]) / 2, 67);
                    for(int i_286 = 0; i_286 < 4; i_286++)
                        is[i_286] += 183;

                }

                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(207, 73, 770, 73);
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(207, 409, 582, 30);
                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(207, 411, 770, 411);
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(772, 76, 17, 333);
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(203, 46, 4, 393);
            }
        }
        if(itab == 2)
        {
            if(litab != itab)
            {
                if(readclan > 0)
                    spos3 = 219;
                gs.senditem.hide();
                gs.datat.hide();
                gs.ilaps.hide();
                gs.icars.hide();
                gs.sclass.hide();
                gs.sfix.hide();
                gs.senditem.enable();
                gs.datat.enable();
                gs.ilaps.enable();
                gs.icars.enable();
                gs.sclass.enable();
                gs.sfix.enable();
                gs.sendtyp.removeAll();
                gs.sendtyp.add(rd, "Write a Message");
                gs.sendtyp.add(rd, "Share a Relative Date");
                gs.sendtyp.select(0);
                litab = itab;
            }
            rd.setColor(color2k(230, 230, 230));
            rd.fillRoundRect(197, 40, 597, 404, 20, 20);
            rd.setColor(new Color(0, 0, 0));
            rd.drawRoundRect(197, 40, 597, 404, 20, 20);
            if(!xt.clan.equals(""))
            {
                rd.setColor(color2k(250, 250, 250));
                rd.fillRect(207, 76, 565, 300);
            }
            if(loadedmyclanbg == 1)
            {
                rd.setComposite(AlphaComposite.getInstance(3, 0.1F));
                rd.drawImage(myclanbg, 207, 76, 565, 300, null);
                rd.setComposite(AlphaComposite.getInstance(3, 1.0F));
            }
            rd.setColor(new Color(0, 0, 0));
            sdist = 0;
            if(!xt.clan.equals(""))
            {
                if(gs.openm)
                    blockb = 10;
                else
                if(blockb != 0)
                    blockb--;
                if((readclan > 0 || readclan == -3) && viewgame1 == 0)
                {
                    sdist = (int)(((float)cnml - 14.75F) * 17F);
                    if(sdist < 0)
                        sdist = 0;
                    scro = (int)(((float)spos3 / 219F) * (float)sdist);
                    for(int i_287 = 0; i_287 < cnml; i_287++)
                    {
                        if((86 + 17 * i_287) - scro >= 360 || (125 + 17 * i_287) - scro <= 76 || cmlinetyp[i_287] == 167)
                            continue;
                        if(cmlinetyp[i_287] != 20 && cmlinetyp[i_287] != 30 && cmlinetyp[i_287] != 40 && cmlinetyp[i_287] != 50 && cmlinetyp[i_287] != 60 && cmlinetyp[i_287] != 70 && cmlinetyp[i_287] != 80)
                        {
                            rd.setColor(new Color(0, 0, 0));
                            if(cmlinetyp[i_287] >= 0)
                                rd.setFont(new Font("Tahoma", 1, 11));
                            else
                                rd.setFont(new Font("Tahoma", 0, 11));
                            cmline[i_287] = cmline[i_287].trim();
                            if(Madness.isURL(cmline[i_287]))
                            {
                                Color tmp = rd.getColor();
                                rd.setColor(color2k(80, 80, 80));
                                rd.drawString(cmline[i_287], 217, (103 + 17 * i_287) - scro);
                                rd.drawLine(216, (105 + i_287 * 17) - scro, 217 + rd.getFontMetrics().stringWidth(cmline[i_287]), (105 + i_287 * 17) - scro);
                                gs.customlink(cmline[i_287], 217, (103 + 17 * i_287) - scro, rd.getFontMetrics().stringWidth(cmline[i_287]));
                                rd.setColor(tmp);
                            } else
                            {
                                rd.drawString(cmline[i_287], 217, (103 + 17 * i_287) - scro);
                            }
                            if(cmlinetyp[i_287] >= 0)
                            {
                                rd.setFont(new Font("Tahoma", 0, 11));
                                ftm = rd.getFontMetrics();
                                rd.setColor(color2k(125, 125, 125));
                                rd.drawString(cmtimes[i_287], 757 - ftm.stringWidth(cmtimes[i_287]), (103 + 17 * i_287) - scro);
                            }
                            continue;
                        }
                        if(cmlinetyp[i_287] == 20 || cmlinetyp[i_287] == 50)
                        {
                            if(stringbutton(rd, "  View Clan  ", 267, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                String string = getSvalue(cmline[i_287], 0);
                                if(!claname.equals(string))
                                {
                                    claname = string;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                ctab = 0;
                                tab = 3;
                            }
                            if(stringbutton(rd, "  View War Suggestion  ", 403, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame1 = 1;
                                if(cmlinetyp[i_287] == 20)
                                    nvgames1 = 4;
                                else
                                    nvgames1 = 9;
                                xclan = getSvalue(cmline[i_287], 0);
                                viewwar1 = getSvalue(cmline[i_287], 1);
                            }
                            if(!cmline[i_287].endsWith("|out|"))
                            {
                                if(cadmin == 1 && stringbutton(rd, "  Approve War  ", 548, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    tab = 2;
                                    itab = 1;
                                    litab = -1;
                                    openi = 10;
                                    String string = getSvalue(cmline[i_287], 0);
                                    if(!intclan.equals(string))
                                    {
                                        intclan = string;
                                        dispi = 0;
                                        nil = 0;
                                        lastint = "";
                                        readint = 1;
                                    }
                                    warnum = getSvalue(cmline[i_287], 1);
                                    sendwarnum = true;
                                    if(cmlinetyp[i_287] == 20)
                                        intsel = 4;
                                    else
                                        intsel = 7;
                                }
                            } else
                            {
                                rd.setColor(color2k(170, 170, 170));
                                rd.drawString("[ Approved or interaction replaced. ]", 597 - ftm.stringWidth("[ Approved or interaction replaced. ]") / 2, (112 + 17 * i_287) - scro);
                            }
                        }
                        if(cmlinetyp[i_287] == 30 || cmlinetyp[i_287] == 60)
                        {
                            if(stringbutton(rd, "  View Clan  ", 267, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                String string = getSvalue(cmline[i_287], 0);
                                if(!claname.equals(string))
                                {
                                    claname = string;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                ctab = 0;
                                tab = 3;
                            }
                            if(stringbutton(rd, "  View Battle Suggestion  ", 407, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame1 = 1;
                                if(cmlinetyp[i_287] == 30)
                                    nvgames1 = 2;
                                else
                                    nvgames1 = 5;
                                xclan = getSvalue(cmline[i_287], 0);
                                viewwar1 = getSvalue(cmline[i_287], 3);
                            }
                            if(!cmline[i_287].endsWith("|out|"))
                            {
                                if(cadmin == 1 && stringbutton(rd, "  Approve Battle  ", 560, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    tab = 2;
                                    itab = 1;
                                    litab = -1;
                                    openi = 10;
                                    String string = getSvalue(cmline[i_287], 0);
                                    if(!intclan.equals(string))
                                    {
                                        intclan = string;
                                        dispi = 0;
                                        nil = 0;
                                        lastint = "";
                                        readint = 1;
                                    }
                                    itake = getSvalue(cmline[i_287], 1);
                                    igive = getSvalue(cmline[i_287], 2);
                                    warnum = getSvalue(cmline[i_287], 3);
                                    sendwarnum = true;
                                    if(cmlinetyp[i_287] == 30)
                                        intsel = 3;
                                    else
                                        intsel = 6;
                                }
                            } else
                            {
                                rd.setColor(color2k(170, 170, 170));
                                rd.drawString("[ Approved or interaction replaced. ]", 604 - ftm.stringWidth("[ Approved or interaction replaced. ]") / 2, (112 + 17 * i_287) - scro);
                            }
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(stringbutton(rd, "  View Car  ", 217 + ftm.stringWidth(cmline[i_287 + 2]) + 47, (137 + 17 * i_287) - scro, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = getSvalue(cmline[i_287], 1);
                                String string = getSvalue(cmline[i_287], 0);
                                if(!claname.equals(string))
                                {
                                    claname = string;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedcars = -1;
                                loadedcar = 0;
                                ctab = 2;
                                tab = 3;
                            }
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(stringbutton(rd, "  View Car  ", 217 + ftm.stringWidth(cmline[i_287 + 3]) + 47, (154 + 17 * i_287) - scro, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = getSvalue(cmline[i_287], 2);
                                if(!claname.equals(xt.clan))
                                {
                                    claname = xt.clan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedcars = -1;
                                loadedcar = 0;
                                ctab = 2;
                                tab = 3;
                            }
                        }
                        if(cmlinetyp[i_287] == 40 || cmlinetyp[i_287] == 70)
                        {
                            if(stringbutton(rd, "  View Clan  ", 267, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                String string = getSvalue(cmline[i_287], 0);
                                if(!claname.equals(string))
                                {
                                    claname = string;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                ctab = 0;
                                tab = 3;
                            }
                            if(stringbutton(rd, "  View Battle Suggestion  ", 407, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                            {
                                viewgame1 = 1;
                                if(cmlinetyp[i_287] == 40)
                                    nvgames1 = 2;
                                else
                                    nvgames1 = 5;
                                xclan = getSvalue(cmline[i_287], 0);
                                viewwar1 = getSvalue(cmline[i_287], 3);
                            }
                            if(!cmline[i_287].endsWith("|out|"))
                            {
                                if(cadmin == 1 && stringbutton(rd, "  Approve Battle  ", 560, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                                {
                                    tab = 2;
                                    itab = 1;
                                    litab = -1;
                                    openi = 10;
                                    String string = getSvalue(cmline[i_287], 0);
                                    if(!intclan.equals(string))
                                    {
                                        intclan = string;
                                        dispi = 0;
                                        nil = 0;
                                        lastint = "";
                                        readint = 1;
                                    }
                                    itake = getSvalue(cmline[i_287], 1);
                                    igive = getSvalue(cmline[i_287], 2);
                                    warnum = getSvalue(cmline[i_287], 3);
                                    sendwarnum = true;
                                    if(cmlinetyp[i_287] == 40)
                                        intsel = 2;
                                    else
                                        intsel = 5;
                                }
                            } else
                            {
                                rd.setColor(color2k(170, 170, 170));
                                rd.drawString("[ Approved or interaction replaced. ]", 604 - ftm.stringWidth("[ Approved or interaction replaced. ]") / 2, (112 + 17 * i_287) - scro);
                            }
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(stringbutton(rd, "  View Stage  ", 217 + ftm.stringWidth(cmline[i_287 + 2]) + 54, (137 + 17 * i_287) - scro, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = getSvalue(cmline[i_287], 1);
                                String string = getSvalue(cmline[i_287], 0);
                                if(!claname.equals(string))
                                {
                                    claname = string;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedstages = -1;
                                loadedstage = 0;
                                ctab = 3;
                                tab = 3;
                            }
                            rd.setFont(new Font("Tahoma", 0, 11));
                            ftm = rd.getFontMetrics();
                            if(stringbutton(rd, "  View Stage  ", 217 + ftm.stringWidth(cmline[i_287 + 3]) + 54, (154 + 17 * i_287) - scro, 6, i, i_186, bool, 0, 0))
                            {
                                viewcar = getSvalue(cmline[i_287], 2);
                                if(!claname.equals(xt.clan))
                                {
                                    claname = xt.clan;
                                    loadedc = false;
                                }
                                spos5 = 0;
                                lspos5 = 0;
                                cfase = 3;
                                loadedstages = -1;
                                loadedstage = 0;
                                ctab = 3;
                                tab = 3;
                            }
                        }
                        if(cmlinetyp[i_287] == 80 && stringbutton(rd, "  View Championship  ", 295, (112 + 17 * i_287) - scro, 0, i, i_186, bool, 0, 0))
                        {
                            cfase = 0;
                            ntab = 1;
                            loadwstat = 0;
                            tab = 3;
                        }
                    }

                }
                if(readclan == -3)
                {
                    rd.setColor(color2k(240, 240, 240));
                    rd.fillRoundRect(387, 140, 200, 30, 20, 20);
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawRoundRect(387, 140, 200, 30, 20, 20);
                    rd.setFont(new Font("Tahoma", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Reading...", 487 - ftm.stringWidth("Reading...") / 2, 160);
                }
                if(readclan == -1)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Failed to load clan's conversation, please try again later...", 487 - ftm.stringWidth("Failed to load clan's conversation, please try again later...") / 2, 200);
                }
                if(readclan == -2)
                {
                    rd.setFont(new Font("Arial", 1, 11));
                    ftm = rd.getFontMetrics();
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("Failed to send data, please try again later...", 487 - ftm.stringWidth("Failed to send data, please try again later...") / 2, 200);
                }
                rd.setColor(color2k(205, 205, 205));
                rd.fillRect(207, 76, 357, 36);
                if(!drawl(rd, (new StringBuilder()).append("#").append(xt.clan).append("#").toString(), 209, 78, true))
                {
                    rd.drawRect(209, 78, 349, 29);
                    rd.setFont(new Font("Arial", 1, 13));
                    ftm = rd.getFontMetrics();
                    rd.drawString((new StringBuilder()).append("").append(xt.clan).append("").toString(), 384 - ftm.stringWidth((new StringBuilder()).append("").append(xt.clan).append("").toString()) / 2, 98);
                }
                if(i > 209 && i < 559 && i_186 > 78 && i_186 < 108 && blockb == 0)
                {
                    cur = 12;
                    if(bool)
                    {
                        if(!claname.equals(xt.clan))
                        {
                            claname = xt.clan;
                            loadedc = false;
                        }
                        spos5 = 0;
                        lspos5 = 0;
                        cfase = 3;
                        ctab = 0;
                        tab = 3;
                    }
                }
            } else
            if(xt.logged)
            {
                rd.setFont(new Font("Arial", 1, 12));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                rd.drawString("You are not a member of any clan.  You need to join a clan first to have access to this.", 487 - ftm.stringWidth("You are not a member of any clan.  You need to join a clan first to have access to this.") / 2, 170);
                if(stringbutton(rd, "   Find a clan to join   ", 487, 200, 1, i, i_186, bool, 0, 0))
                {
                    tab = 3;
                    cfase = 2;
                    em = 1;
                    msg = "Clan Search";
                    smsg = "Listing clans with recent activity...";
                    nclns = 0;
                    spos5 = 0;
                    lspos5 = 0;
                    flko = 0;
                }
            } else
            {
                rd.setFont(new Font("Arial", 1, 13));
                ftm = rd.getFontMetrics();
                rd.drawString("You are currently using a trial account.", 495 - ftm.stringWidth("You are currently using a trial account.") / 2, 150);
                rd.drawString("You need to upgrade to be able participate in NFM clan's activities.", 495 - ftm.stringWidth("You need to upgrade to be able participate in NFM clan's activities.") / 2, 170);
                rd.setColor(new Color(206, 171, 98));
                rd.fillRoundRect(405, 193, 180, 50, 20, 20);
                if(drawbutton(xt.upgrade, 495, 218, i, i_186, bool))
                    gs.editlink(xt.nickname, true);
            }
            rd.setColor(color2k(205, 205, 205));
            rd.fillRect(207, 46, 582, 30);
            rd.setFont(new Font("Arial", 1, 12));
            ftm = rd.getFontMetrics();
            String strings[] = {
                "Player Interaction", "Clan Interaction", "Your Clan's Discussion"
            };
            int is[] = {
                207, 390, 368, 207
            };
            int is_288[] = {
                73, 73, 51, 51
            };
            for(int i_289 = 0; i_289 < 3; i_289++)
            {
                if(itab == i_289)
                {
                    rd.setColor(color2k(230, 230, 230));
                    rd.fillPolygon(is, is_288, 4);
                } else
                if(i > is[0] && i < is[2] && i_186 > 51 && i_186 < 73)
                {
                    rd.setColor(color2k(217, 217, 217));
                    rd.fillPolygon(is, is_288, 4);
                    if(bool)
                        itab = i_289;
                }
                rd.setColor(color2k(150, 150, 150));
                rd.drawPolygon(is, is_288, 4);
                rd.setColor(color2k(40, 40, 40));
                rd.drawString(strings[i_289], (is[0] + 80) - ftm.stringWidth(strings[i_289]) / 2, 67);
                for(int i_290 = 0; i_290 < 4; i_290++)
                    is[i_290] += 183;

            }

            rd.setColor(color2k(150, 150, 150));
            rd.drawLine(207, 73, 770, 73);
            rd.setColor(color2k(205, 205, 205));
            rd.fillRect(207, 360, 582, 79);
            rd.setColor(color2k(150, 150, 150));
            rd.drawLine(207, 362, 770, 362);
            rd.setColor(color2k(205, 205, 205));
            rd.fillRect(772, 76, 17, 333);
            rd.setColor(color2k(205, 205, 205));
            rd.fillRect(203, 46, 4, 393);
            if(mscro3 == 831 || sdist == 0)
            {
                if(sdist == 0)
                    rd.setColor(color2k(205, 205, 205));
                else
                    rd.setColor(color2k(215, 215, 215));
                rd.fillRect(772, 76, 17, 17);
            } else
            {
                rd.setColor(color2k(220, 220, 220));
                rd.fill3DRect(772, 76, 17, 17, true);
            }
            if(sdist != 0)
                rd.drawImage(xt.asu, 777, 82, null);
            if(mscro3 == 832 || sdist == 0)
            {
                if(sdist == 0)
                    rd.setColor(color2k(205, 205, 205));
                else
                    rd.setColor(color2k(215, 215, 215));
                rd.fillRect(772, 343, 17, 17);
            } else
            {
                rd.setColor(color2k(220, 220, 220));
                rd.fill3DRect(772, 343, 17, 17, true);
            }
            if(sdist != 0)
                rd.drawImage(xt.asd, 777, 350, null);
            if(sdist != 0)
            {
                if(lspos3 != spos3)
                {
                    rd.setColor(color2k(215, 215, 215));
                    rd.fillRect(772, 93 + spos3, 17, 31);
                } else
                {
                    if(mscro3 == 831)
                        rd.setColor(color2k(215, 215, 215));
                    rd.fill3DRect(772, 93 + spos3, 17, 31, true);
                }
                rd.setColor(color2k(150, 150, 150));
                rd.drawLine(777, 106 + spos3, 783, 106 + spos3);
                rd.drawLine(777, 108 + spos3, 783, 108 + spos3);
                rd.drawLine(777, 110 + spos3, 783, 110 + spos3);
                if(mscro3 > 800 && lspos3 != spos3)
                    lspos3 = spos3;
                if(bool && openc == 0)
                {
                    if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 + spos3 && i_186 < spos3 + 124)
                        mscro3 = i_186 - spos3;
                    if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 74 && i_186 < 95)
                        mscro3 = 831;
                    if(mscro3 == 825 && i > 770 && i < 791 && i_186 > 341 && i_186 < 362)
                        mscro3 = 832;
                    if(mscro3 == 825 && i > 772 && i < 789 && i_186 > 93 && i_186 < 343)
                    {
                        mscro3 = 108;
                        spos3 = i_186 - mscro3;
                    }
                    int i_291 = 2670 / sdist;
                    if(i_291 < 1)
                        i_291 = 1;
                    if(mscro3 == 831)
                    {
                        spos3 -= i_291;
                        if(spos3 > 219)
                            spos3 = 219;
                        if(spos3 < 0)
                            spos3 = 0;
                        lspos3 = spos3;
                    }
                    if(mscro3 == 832)
                    {
                        spos3 += i_291;
                        if(spos3 > 219)
                            spos3 = 219;
                        if(spos3 < 0)
                            spos3 = 0;
                        lspos3 = spos3;
                    }
                    if(mscro3 < 800)
                    {
                        spos3 = i_186 - mscro3;
                        if(spos3 > 219)
                            spos3 = 219;
                        if(spos3 < 0)
                            spos3 = 0;
                    }
                    if(mscro3 == 825)
                        mscro3 = 925;
                } else
                if(mscro3 != 825)
                    mscro3 = 825;
            }
            if(viewgame1 != 0)
            {
                rd.setColor(color2k(210, 210, 210));
                rd.fillRoundRect(204, 127, 583, 230, 20, 20);
                rd.setColor(color2k(150, 150, 150));
                rd.drawRoundRect(204, 127, 583, 230, 20, 20);
                rd.setFont(new Font("Tahoma", 1, 11));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                if(nvgames1 == 4)
                {
                    rd.drawString((new StringBuilder()).append("War declaration, your clan ").append(xt.clan).append(" versus ").append(xclan).append(".").toString(), 215, 145);
                    if(viewgame1 == 2)
                        rd.drawString((new StringBuilder()).append("").append(xclan).append(" would create 5 more games and the first clan to win 5 games wins the war!").toString(), 215, 210 + nvgames1 * 18);
                }
                if(nvgames1 == 2)
                {
                    rd.drawString((new StringBuilder()).append("Battle, your clan ").append(xt.clan).append(" versus ").append(xclan).append(".").toString(), 215, 145);
                    if(viewgame1 == 2)
                        rd.drawString((new StringBuilder()).append("").append(xclan).append(" would create 3 more games and the first clan to win 3 games wins the battle!").toString(), 215, 210 + nvgames1 * 18);
                }
                if(nvgames1 == 9)
                    rd.drawString((new StringBuilder()).append("Suggestion to accept war, your clan ").append(xt.clan).append(" versus ").append(xclan).append(".").toString(), 215, 145);
                if(nvgames1 == 5)
                    rd.drawString((new StringBuilder()).append("Suggestion to accept to battle, your clan ").append(xt.clan).append(" versus ").append(xclan).append(".").toString(), 215, 145);
                if(stringbutton(rd, "Close X", 749, 148, 3, i, i_186, bool, 0, 0))
                    viewgame1 = 0;
                rd.setFont(new Font("Tahoma", 1, 11));
                ftm = rd.getFontMetrics();
                rd.setColor(new Color(0, 0, 0));
                if(viewgame1 == 2)
                {
                    rd.drawString("Game", 246 - ftm.stringWidth("Game") / 2, 175);
                    rd.drawString("Stage", 412 - ftm.stringWidth("Stage") / 2, 175);
                    rd.drawString("Laps", 564 - ftm.stringWidth("Laps") / 2, 175);
                    rd.drawString("Type of Cars", 653 - ftm.stringWidth("Type of Cars") / 2, 175);
                    rd.drawString("Fixing", 751 - ftm.stringWidth("Fixing") / 2, 175);
                    int i_292 = 1;
                    int i_293 = 1;
                    if(nvgames1 == 4 || nvgames1 == 2)
                    {
                        i_292 = 2;
                        i_293 = 2;
                    }
                    for(int i_294 = 0; i_294 < nvgames1; i_294++)
                    {
                        rd.setFont(new Font("Tahoma", 0, 11));
                        ftm = rd.getFontMetrics();
                        rd.drawString((new StringBuilder()).append("# ").append(i_292).append("").toString(), 246 - ftm.stringWidth((new StringBuilder()).append("# ").append(i_292).append("").toString()) / 2, 193 + i_294 * 18);
                        i_292 += i_293;
                        rd.drawString(vwstages1[i_294], 412 - ftm.stringWidth(vwstages1[i_294]) / 2, 193 + i_294 * 18);
                        rd.drawString((new StringBuilder()).append("").append(vwlaps1[i_294]).append("").toString(), 564 - ftm.stringWidth((new StringBuilder()).append("").append(vwlaps1[i_294]).append("").toString()) / 2, 193 + i_294 * 18);
                        String string = "All Cars";
                        if(vwcars1[i_294] == 2)
                            string = "Clan Cars";
                        if(vwcars1[i_294] == 3)
                            string = "Game Cars";
                        if(vwclass1[i_294] == 0)
                            string = (new StringBuilder()).append(string).append(", All Classes").toString();
                        if(vwclass1[i_294] == 1)
                            string = (new StringBuilder()).append(string).append(", Class C").toString();
                        if(vwclass1[i_294] == 2)
                            string = (new StringBuilder()).append(string).append(", Class B & C").toString();
                        if(vwclass1[i_294] == 3)
                            string = (new StringBuilder()).append(string).append(", Class B").toString();
                        if(vwclass1[i_294] == 4)
                            string = (new StringBuilder()).append(string).append(", Class A & B").toString();
                        if(vwclass1[i_294] == 5)
                            string = (new StringBuilder()).append(string).append(", Class A").toString();
                        rd.drawString(string, 653 - ftm.stringWidth(string) / 2, 193 + i_294 * 18);
                        String string_295 = "Infinite";
                        if(vwfix1[i_294] == 1)
                            string_295 = "4 Fixes";
                        if(vwfix1[i_294] == 2)
                            string_295 = "3 Fixes";
                        if(vwfix1[i_294] == 3)
                            string_295 = "2 Fixes";
                        if(vwfix1[i_294] == 4)
                            string_295 = "1 Fix";
                        if(vwfix1[i_294] == 5)
                            string_295 = "No Fixing";
                        rd.drawString(string_295, 751 - ftm.stringWidth(string_295) / 2, 193 + i_294 * 18);
                        rd.drawRect(213, 180 + i_294 * 18, 565, 18);
                    }

                    rd.drawLine(213, 162, 213, 180 + nvgames1 * 18);
                    rd.drawLine(279, 162, 279, 180 + nvgames1 * 18);
                    rd.drawLine(546, 162, 546, 180 + nvgames1 * 18);
                    rd.drawLine(583, 162, 583, 180 + nvgames1 * 18);
                    rd.drawLine(723, 162, 723, 180 + nvgames1 * 18);
                    rd.drawLine(778, 162, 778, 180 + nvgames1 * 18);
                }
                if(viewgame1 == 1)
                    rd.drawString("Loading...", 495 - ftm.stringWidth("Loading...") / 2, 242);
                if(viewgame1 == 3)
                {
                    if(nvgames1 == 4 || nvgames1 == 9)
                        rd.drawString("This war suggestion has expired and no longer exists.", 495 - ftm.stringWidth("This war suggestion has expired and no longer exists.") / 2, 232);
                    if(nvgames1 == 2 || nvgames1 == 5)
                        rd.drawString("This battle suggestion has expired and no longer exists.", 495 - ftm.stringWidth("This battle suggestion has expired and no longer exists.") / 2, 232);
                    rd.drawString("(Suggestions expire after 90 days.)", 495 - ftm.stringWidth("(Suggestions expire after 90 days.)") / 2, 252);
                }
                if(viewgame1 == 4)
                    rd.drawString("Error loading suggestion, please try again later...", 495 - ftm.stringWidth("Error loading suggestion, please try again later...") / 2, 242);
            }
            if(!xt.clan.equals(""))
            {
                if(!gs.sendtyp.isShowing())
                {
                    gs.sendtyp.show();
                    gs.sendtyp.select(0);
                }
                gs.sendtyp.move(207, 365);
                if(sendcmsg != 0)
                    gs.sendtyp.disable();
                else
                    gs.sendtyp.enable();
                darker = true;
                if(gs.sendtyp.getSelectedIndex() == 0)
                {
                    dommsg = true;
                    if(sendcmsg == 0)
                    {
                        if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0) && !gs.mmsg.getText().trim().equals("") && gs.mmsg.getText().toLowerCase().indexOf(gs.tpass.getText().toLowerCase()) == -1 && xt.acexp != -3)
                            if(!xt.msgcheck(gs.mmsg.getText()))
                            {
                                sendcmsg = 1;
                                viewgame1 = 0;
                            } else
                            {
                                gs.sendtyp.hide();
                                xt.warning++;
                            }
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.setColor(new Color(0, 0, 0));
                        rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                    }
                }
                if(gs.sendtyp.getSelectedIndex() == 1)
                {
                    rd.setFont(new Font("Arial", 0, 12));
                    rd.setColor(new Color(0, 0, 0));
                    rd.drawString("A date that gets converted to the local time of any person previewing it.", 376, 382);
                    if(!gs.senditem.isShowing())
                    {
                        gs.senditem.removeAll();
                        Calendar calendar = Calendar.getInstance();
                        boolean bool_296 = false;
                        for(int i_297 = 0; i_297 < 20; i_297++)
                        {
                            String strings_298[] = wday;
                            Calendar calendar_299 = calendar;
                            if(calendar == null);
                            String string = strings_298[calendar_299.get(7) - 1];
                            if(!bool_296)
                            {
                                string = "Today";
                                bool_296 = true;
                            }
                            Smenu smenu = gs.senditem;
                            Graphics2D graphics2d = rd;
                            StringBuilder stringbuilder = (new StringBuilder()).append("").append(string).append("  -  ");
                            String strings_300[] = month;
                            Calendar calendar_301 = calendar;
                            if(calendar == null);
                            StringBuilder stringbuilder_302 = stringbuilder.append(strings_300[calendar_301.get(2)]).append(" ");
                            Calendar calendar_303 = calendar;
                            if(calendar == null);
                            smenu.add(graphics2d, stringbuilder_302.append(calendar_303.get(5)).append("").toString());
                            Calendar calendar_304 = calendar;
                            if(calendar == null);
                            calendar_304.roll(5, true);
                        }

                        gs.senditem.select(0);
                        gs.senditem.show();
                    }
                    if(!gs.datat.isShowing())
                    {
                        gs.datat.removeAll();
                        int i_305 = 12;
                        String string = "PM";
                        for(int i_306 = 0; i_306 < 24; i_306++)
                        {
                            gs.datat.add(rd, (new StringBuilder()).append("").append(i_305).append(" ").append(string).append("").toString());
                            if(++i_305 == 12)
                                string = "AM";
                            if(i_305 == 13)
                                i_305 = 1;
                        }

                        gs.datat.select(0);
                        gs.datat.show();
                    }
                    gs.senditem.move(300, 395);
                    gs.datat.move(491, 395);
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    rd.drawString("Date is displayed based on your computer calendar's date/time, please make sure it is correct.", 207, 435);
                    if(sendcmsg == 0)
                    {
                        if(stringbutton(rd, "   Send  >  ", 723, 408, 0, i, i_186, bool, 0, 0))
                        {
                            sendcmsg = 1;
                            viewgame1 = 0;
                        }
                    } else
                    {
                        rd.setFont(new Font("Arial", 1, 12));
                        ftm = rd.getFontMetrics();
                        rd.drawString("Sending...", 723 - ftm.stringWidth("Sending...") / 2, 408);
                    }
                } else
                {
                    if(gs.senditem.isShowing())
                        gs.senditem.hide();
                    if(gs.datat.isShowing())
                        gs.datat.hide();
                }
                darker = false;
            }
        }
    }

    public void run()
    {
        try
        {
            socket = new Socket(lg.servers[0], 7061);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
        }
        catch(Exception exception)
        {
            domon = false;
        }
        while(domon) 
        {
            String string = "";
            String string_307 = "";
            string = (new StringBuilder()).append("101|0|").append(xt.nickname).append(":").append(xt.nickey).append("|").toString();
            try
            {
                dout.println(string);
                string_307 = din.readLine();
                if(string_307 == null)
                    domon = false;
            }
            catch(Exception exception)
            {
                domon = false;
            }
            if(domon)
            {
                ntime = getLvalue(string_307, 0);
                maxclans = getvalue(string_307, 1);
                int i;
                for(i = 0; i < 3; i++)
                {
                    for(int i_308 = 0; i_308 < 5; i_308++)
                        roomf[i][i_308] = 0;

                }

                i = 0;
                int i_309 = 2;
                boolean bool = false;
                while(!bool) 
                {
                    String string_310 = getSvalue(string_307, i_309);
                    if(!string_310.equals(""))
                    {
                        int i_311 = getvalue(string_307, i_309 + 1);
                        int i_312 = getvalue(string_307, i_309 + 2);
                        if((i_311 == -1 || i_312 == -1) && i < 900)
                        {
                            pname[i] = string_310;
                            proom[i] = i_311;
                            pserver[i] = i_312;
                            i++;
                        }
                    } else
                    {
                        bool = true;
                    }
                    i_309 += 3;
                }
                i_309 = 2;
                for(bool = false; !bool; i_309 += 3)
                {
                    String string_313 = getSvalue(string_307, i_309);
                    if(!string_313.equals(""))
                    {
                        int i_314 = getvalue(string_307, i_309 + 1);
                        int i_315 = getvalue(string_307, i_309 + 2);
                        if(i_314 < 0 || i_314 > 4 || i_315 < 0 || i_315 > 2)
                            continue;
                        roomf[i_315][i_314]++;
                        if(i < 900)
                        {
                            pname[i] = string_313;
                            proom[i] = i_314;
                            pserver[i] = i_315;
                            i++;
                        }
                    } else
                    {
                        bool = true;
                    }
                }

                npo = i;
            }
            if(ptab == 1)
            {
                if(freq == 2)
                {
                    string = (new StringBuilder()).append("101|14|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(freqname).append("|").toString();
                    try
                    {
                        dout.println(string);
                        string_307 = din.readLine();
                    }
                    catch(Exception exception) { }
                    if(string_307.equals("OK"))
                    {
                        freq = 0;
                        npf = -1;
                    } else
                    {
                        freq = -1;
                        cntf = 40;
                    }
                }
                if(freq == 3)
                {
                    string = (new StringBuilder()).append("101|15|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(freqname).append("|").toString();
                    try
                    {
                        dout.println(string);
                        string_307 = din.readLine();
                    }
                    catch(Exception exception) { }
                    if(string_307.equals("OK"))
                    {
                        freq = 0;
                        npf = -1;
                    } else
                    {
                        freq = -2;
                        cntf = 40;
                    }
                }
                if(freq == -6)
                {
                    string = (new StringBuilder()).append("101|18|").append(xt.nickname).append("|").append(xt.nickey).append("|").toString();
                    try
                    {
                        dout.println(string);
                        string_307 = din.readLine();
                    }
                    catch(Exception exception) { }
                    freq = 0;
                }
                loadfriends();
            }
            if(sfreq == 1)
            {
                string = (new StringBuilder()).append("101|16|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(proname).append("|").toString();
                try
                {
                    dout.println(string);
                    string_307 = din.readLine();
                }
                catch(Exception exception) { }
                if(string_307.equals("OK"))
                    sfreq = 2;
                else
                    sfreq = 3;
            }
            if(sfreq == 4)
            {
                string = (new StringBuilder()).append("101|17|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(proname).append("|").toString();
                try
                {
                    dout.println(string);
                    string_307 = din.readLine();
                }
                catch(Exception exception) { }
                if(string_307.equals("OK"))
                {
                    sfreq = 5;
                    npf = -1;
                } else
                {
                    sfreq = 6;
                }
            }
            if(sentchange == 2 && domon)
            {
                string = (new StringBuilder()).append("101|5|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(sentance).append("|").toString();
                try
                {
                    dout.println(string);
                    string_307 = din.readLine();
                }
                catch(Exception exception) { }
                sentchange = 0;
            }
            if(tab == 2 && domon)
            {
                if(itab == 0)
                {
                    if(!blockname.equals(""))
                    {
                        int i = 0;
                        do
                        {
                            if(i >= nm)
                                break;
                            if(mname[i].equals(blockname))
                            {
                                mtyp[i] = 3;
                                break;
                            }
                            i++;
                        } while(true);
                        try
                        {
                            string = (new StringBuilder()).append("101|11|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(blockname).append("|").toString();
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception) { }
                        blockname = "";
                    }
                    if(!unblockname.equals(""))
                    {
                        int i = 0;
                        do
                        {
                            if(i >= nm)
                                break;
                            if(mname[i].equals(unblockname))
                            {
                                mtyp[i] = 0;
                                break;
                            }
                            i++;
                        } while(true);
                        try
                        {
                            string = (new StringBuilder()).append("101|12|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(unblockname).append("|").toString();
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception) { }
                        unblockname = "";
                    }
                    try
                    {
                        string = (new StringBuilder()).append("101|13|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(loadmsgs).append("|").toString();
                        dout.println(string);
                        string_307 = din.readLine();
                        if(string_307.startsWith("MSGS"))
                        {
                            loadmsgs = getvalue(string_307, 1);
                            DataInputStream datainputstream = new DataInputStream(socket.getInputStream());
                            byte is[] = new byte[loadmsgs];
                            datainputstream.readFully(is);
                            string_307 = din.readLine();
                            datainputstream = new DataInputStream(new ByteArrayInputStream(is));
                            String string_316 = "";
                            for(nm = 0; (string_316 = datainputstream.readLine()) != null && nm < 200; nm++)
                            {
                                mname[nm] = getSvalue(string_316, 0);
                                mtyp[nm] = getvalue(string_316, 1);
                                mconvo[nm] = getSvalue(string_316, 2);
                                msub[nm] = getSvalue(string_316, 3);
                                mctime[nm] = getLvalue(string_316, 4);
                                mtime[nm] = "";
                            }

                        } else
                        if(string_307.equals("NOMSGS"))
                            loadmsgs = 0;
                    }
                    catch(Exception exception)
                    {
                        loadmsgs = -2;
                    }
                    if(loadmsgs > 0)
                    {
                        for(int i = 0; i < nm; i++)
                            if(mctime[i] > 0L)
                                try
                                {
                                    long l = ntime - mctime[i];
                                    String string_317 = "Received";
                                    if(mtyp[i] == 2)
                                        string_317 = "Sent";
                                    if(l >= 1000L && l < 60000L)
                                        mtime[i] = (new StringBuilder()).append("").append(string_317).append(" seconds ago").toString();
                                    if(l >= 60000L && l < 0x36ee80L)
                                    {
                                        int i_318 = (int)(l / 60000L);
                                        String string_319 = "s";
                                        if(i_318 == 1)
                                            string_319 = "";
                                        mtime[i] = (new StringBuilder()).append("").append(string_317).append(" ").append(i_318).append(" minute").append(string_319).append(" ago").toString();
                                    }
                                    if(l >= 0x36ee80L && l < 0x5265c00L)
                                    {
                                        int i_320 = (int)(l / 0x36ee80L);
                                        String string_321 = "s";
                                        if(i_320 == 1)
                                            string_321 = "";
                                        mtime[i] = (new StringBuilder()).append("").append(string_317).append(" ").append(i_320).append(" hour").append(string_321).append(" ago").toString();
                                    }
                                    if(l < 0x5265c00L)
                                        continue;
                                    int i_322 = (int)(l / 0x5265c00L);
                                    String string_323 = "s";
                                    if(i_322 == 1)
                                        string_323 = "";
                                    mtime[i] = (new StringBuilder()).append("").append(string_317).append(" ").append(i_322).append(" day").append(string_323).append(" ago").toString();
                                }
                                catch(Exception exception)
                                {
                                    mtime[i] = "";
                                }
                            else
                                mtime[i] = "";

                    }
                    if(openc != 0)
                    {
                        boolean bool = false;
                        int i = -1;
                        int i_324 = 0;
                        do
                        {
                            if(i_324 >= nm)
                                break;
                            if(mname[i_324].equals(opname))
                            {
                                i = i_324;
                                break;
                            }
                            i_324++;
                        } while(true);
                        if(i != -1 && readmsg != 3 && readmsg != 4 && readmsg != 5)
                        {
                            if(!lastsub.equals((new StringBuilder()).append("").append(mctime[i]).toString()))
                            {
                                bool = true;
                                readmsg = 1;
                            } else
                            {
                                readmsg = 2;
                            }
                        } else
                        {
                            lastsub = "";
                            if(readmsg == 1)
                            {
                                readmsg = 0;
                                nml = 0;
                            }
                        }
                        if(bool)
                            try
                            {
                                string = (new StringBuilder()).append("101|8|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(mconvo[i]).append("").toString();
                                dout.println(string);
                                string_307 = din.readLine();
                                if(string_307.startsWith("RECIVE"))
                                {
                                    for(int i_325 = 0; i_325 < nml; i_325++)
                                    {
                                        mline[i_325] = null;
                                        mlinetyp[i_325] = 0;
                                        mctimes[i_325] = 0L;
                                        mtimes[i_325] = null;
                                    }

                                    nml = 0;
                                    cd.acname = "";
                                    cd.action = 0;
                                    cd.onstage = "";
                                    addstage = 0;
                                    nclns = 0;
                                    int i_326 = getvalue(string_307, 1);
                                    DataInputStream datainputstream = new DataInputStream(socket.getInputStream());
                                    byte is[] = new byte[i_326];
                                    datainputstream.readFully(is);
                                    string_307 = din.readLine();
                                    datainputstream = new DataInputStream(new ByteArrayInputStream(is));
                                    String string_327 = "";
                                    do
                                    {
                                        if((string_327 = datainputstream.readLine()) == null)
                                            break;
                                        if(string_327.startsWith("|"))
                                        {
                                            if(nml != 0)
                                            {
                                                mline[nml] = "";
                                                mlinetyp[nml] = 167;
                                                nml++;
                                            }
                                            String string_328 = getSvalue(string_327, 1);
                                            if(string_328.toLowerCase().equals(xt.nickname.toLowerCase()))
                                                string_328 = "You";
                                            mlinetyp[nml] = getvalue(string_327, 2);
                                            int i_329 = mlinetyp[nml];
                                            if(i_329 == 0)
                                            {
                                                mline[nml] = (new StringBuilder()).append("").append(string_328).append(" wrote:").toString();
                                                mctimes[nml] = getLvalue(string_327, 3);
                                                mtimes[nml] = "";
                                                nml++;
                                            }
                                            if(i_329 == 1)
                                            {
                                                mline[nml] = (new StringBuilder()).append("").append(string_328).append(" shared a car:").toString();
                                                mctimes[nml] = getLvalue(string_327, 3);
                                                mtimes[nml] = "";
                                                nml++;
                                                mline[nml] = getSvalue(string_327, 4);
                                                mlinetyp[nml] = 10;
                                                nml++;
                                                mline[nml] = "";
                                                mlinetyp[nml] = 167;
                                                nml++;
                                            }
                                            if(i_329 == 2)
                                            {
                                                mline[nml] = (new StringBuilder()).append("").append(string_328).append(" shared a stage:").toString();
                                                mctimes[nml] = getLvalue(string_327, 3);
                                                mtimes[nml] = "";
                                                nml++;
                                                mline[nml] = getSvalue(string_327, 4);
                                                mlinetyp[nml] = 20;
                                                nml++;
                                                mline[nml] = "";
                                                mlinetyp[nml] = 167;
                                                nml++;
                                            }
                                            if(i_329 == 3)
                                            {
                                                if(string_328.equals("You"))
                                                    mline[nml] = (new StringBuilder()).append("You have invited ").append(mname[i]).append(" to join your clan:").toString();
                                                else
                                                    mline[nml] = (new StringBuilder()).append("").append(string_328).append(" has invited you to join clan:").toString();
                                                mctimes[nml] = getLvalue(string_327, 3);
                                                mtimes[nml] = "";
                                                nml++;
                                                mline[nml] = getSvalue(string_327, 4);
                                                if(nclns < 20)
                                                {
                                                    clanlo[nclns] = mline[nml];
                                                    nclns++;
                                                }
                                                mlinetyp[nml] = 30;
                                                nml++;
                                                mline[nml] = "";
                                                mlinetyp[nml] = 167;
                                                nml++;
                                                if(!string_328.equals("You"))
                                                {
                                                    if(xt.clan.equals(""))
                                                        mline[nml] = "(If you would like join this clan, visit that clan's page and click 'Request to Join..'.)";
                                                    else
                                                        mline[nml] = (new StringBuilder()).append("(You will need to leave your clan ").append(xt.clan).append(" first before being able to join...)").toString();
                                                    mlinetyp[nml] = -1;
                                                    nml++;
                                                }
                                            }
                                            if(i_329 == 4)
                                            {
                                                if(string_328.equals("You"))
                                                    mline[nml] = "You have shared the following date:";
                                                else
                                                    mline[nml] = (new StringBuilder()).append("").append(string_328).append(" has shared the following date:").toString();
                                                mctimes[nml] = getLvalue(string_327, 3);
                                                mtimes[nml] = "";
                                                Calendar calendar = Calendar.getInstance();
                                                long l = (calendar.getTimeInMillis() - (ntime - mctimes[nml])) + getLvalue(string_327, 4);
                                                if(l > 0L)
                                                    calendar.setTimeInMillis(l);
                                                nml++;
                                                Calendar calendar_330 = calendar;
                                                if(calendar == null);
                                                int i_331 = calendar_330.get(11);
                                                String string_332 = "AM";
                                                Calendar calendar_333 = calendar;
                                                if(calendar == null);
                                                if(calendar_333.get(12) > 30 && ++i_331 == 24)
                                                    i_331 -= 24;
                                                if(i_331 >= 12)
                                                    string_332 = "PM";
                                                if(i_331 > 12)
                                                    i_331 -= 12;
                                                if(i_331 == 0)
                                                    i_331 = 12;
                                                try
                                                {
                                                    String strings[] = mline;
                                                    int i_334 = nml;
                                                    StringBuilder stringbuilder = (new StringBuilder()).append("[  ");
                                                    String strings_335[] = wday;
                                                    Calendar calendar_336 = calendar;
                                                    if(calendar == null);
                                                    StringBuilder stringbuilder_337 = stringbuilder.append(strings_335[calendar_336.get(7) - 1]).append("  -  ");
                                                    String strings_338[] = month;
                                                    Calendar calendar_339 = calendar;
                                                    if(calendar == null);
                                                    StringBuilder stringbuilder_340 = stringbuilder_337.append(strings_338[calendar_339.get(2)]).append(" ");
                                                    Calendar calendar_341 = calendar;
                                                    if(calendar == null);
                                                    strings[i_334] = stringbuilder_340.append(calendar_341.get(5)).append(",  ").append(i_331).append(" ").append(string_332).append("  ]").toString();
                                                }
                                                catch(Exception exception)
                                                {
                                                    mline[nml] = "Error occurred while calculating this date.";
                                                }
                                                mlinetyp[nml] = -1;
                                                nml++;
                                                mline[nml] = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
                                                mlinetyp[nml] = -1;
                                                nml++;
                                            }
                                        } else
                                        {
                                            mline[nml] = string_327;
                                            try
                                            {
                                                rd.setFont(new Font("Tahoma", 0, 11));
                                                ftm = rd.getFontMetrics();
                                                int i_342 = 0;
                                                String string_343 = "";
                                                for(; i_342 < string_327.length(); i_342++)
                                                {
                                                    string_343 = (new StringBuilder()).append(string_343).append(string_327.charAt(i_342)).toString();
                                                    if(ftm.stringWidth(string_343) <= 540)
                                                        continue;
                                                    if(string_343.lastIndexOf(" ") != -1)
                                                    {
                                                        mline[nml] = string_343.substring(0, string_343.lastIndexOf(" "));
                                                        string_343 = string_343.substring(string_343.lastIndexOf(" ") + 1, string_343.length());
                                                    } else
                                                    {
                                                        mline[nml] = string_343;
                                                        string_343 = "";
                                                    }
                                                    mlinetyp[nml] = -1;
                                                    nml++;
                                                }

                                                mline[nml] = string_343;
                                            }
                                            catch(Exception exception) { }
                                            mlinetyp[nml] = -1;
                                            nml++;
                                        }
                                    } while(true);
                                    readmsg = 2;
                                    lastsub = (new StringBuilder()).append("").append(mctime[i]).toString();
                                    if(mtyp[i] == 1)
                                    {
                                        mtyp[i] = 0;
                                        try
                                        {
                                            dout.println((new StringBuilder()).append("101|10|").append(xt.nickname).append("|").append(opname).append("|").toString());
                                            string_307 = din.readLine();
                                        }
                                        catch(Exception exception) { }
                                    }
                                    spos4 = 208;
                                } else
                                {
                                    readmsg = 3;
                                }
                            }
                            catch(Exception exception)
                            {
                                readmsg = 4;
                            }
                        if(readmsg == 2)
                        {
                            for(int i_344 = 0; i_344 < nml; i_344++)
                                if((mlinetyp[i_344] == 0 || mlinetyp[i_344] == 1 || mlinetyp[i_344] == 2 || mlinetyp[i_344] == 3 || mlinetyp[i_344] == 4) && mctimes[i_344] > 0L)
                                    try
                                    {
                                        long l = ntime - mctimes[i_344];
                                        if(l >= 1000L && l < 60000L)
                                            mtimes[i_344] = "seconds ago";
                                        if(l >= 60000L && l < 0x36ee80L)
                                        {
                                            int i_345 = (int)(l / 60000L);
                                            String string_346 = "s";
                                            if(i_345 == 1)
                                                string_346 = "";
                                            mtimes[i_344] = (new StringBuilder()).append("").append(i_345).append(" minute").append(string_346).append(" ago").toString();
                                        }
                                        if(l >= 0x36ee80L && l < 0x5265c00L)
                                        {
                                            int i_347 = (int)(l / 0x36ee80L);
                                            String string_348 = "s";
                                            if(i_347 == 1)
                                                string_348 = "";
                                            mtimes[i_344] = (new StringBuilder()).append("").append(i_347).append(" hour").append(string_348).append(" ago").toString();
                                        }
                                        if(l < 0x5265c00L)
                                            continue;
                                        int i_349 = (int)(l / 0x5265c00L);
                                        String string_350 = "s";
                                        if(i_349 == 1)
                                            string_350 = "";
                                        mtimes[i_344] = (new StringBuilder()).append("").append(i_349).append(" day").append(string_350).append(" ago").toString();
                                    }
                                    catch(Exception exception)
                                    {
                                        mtimes[i_344] = "";
                                    }
                                else
                                    mtimes[i_344] = "";

                        }
                    }
                    if(sendmsg == 2)
                    {
                        gs.mmsg.setText(" ");
                        sendmsg = 0;
                    }
                    if(openc == 10)
                    {
                        if(loaditem == 1)
                        {
                            int i = 0;
                            String strings[] = new String[700];
                            try
                            {
                                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                                url.openConnection().setConnectTimeout(2000);
                                String string_351 = "";
                                DataInputStream datainputstream = new DataInputStream(url.openStream());
                                do
                                {
                                    if((string_351 = datainputstream.readLine()) == null)
                                        break;
                                    string_351 = (new StringBuilder()).append("").append(string_351.trim()).toString();
                                    if(string_351.startsWith("mycars"))
                                    {
                                        boolean bool = true;
                                        while(bool && i < 700) 
                                        {
                                            strings[i] = getfuncSvalue("mycars", string_351, i);
                                            if(strings[i].equals(""))
                                                bool = false;
                                            else
                                                i++;
                                        }
                                    }
                                } while(true);
                                datainputstream.close();
                            }
                            catch(Exception exception)
                            {
                                String string_352 = (new StringBuilder()).append("").append(exception).toString();
                                if(string_352.indexOf("FileNotFound") != -1)
                                    i = 0;
                                else
                                    i = -1;
                            }
                            if(i == -1)
                            {
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, "Failed to load your cars, please try again later.");
                                loaditem = 0;
                            }
                            if(i == 0)
                            {
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, "You have no added or published cars to load.");
                                loaditem = 0;
                            }
                            if(i > 0)
                            {
                                String strings_353[] = new String[700];
                                int i_354 = 0;
                                for(int i_355 = 0; i_355 < i; i_355++)
                                {
                                    gs.senditem.removeAll();
                                    gs.senditem.add(rd, (new StringBuilder()).append("Loading shareable cars,  ").append((int)(((float)i_355 / (float)i) * 100F)).append(" %").toString());
                                    try
                                    {
                                        String string_356 = (new StringBuilder()).append("http://multiplayer.needformadness.com/cars/").append(strings[i_355]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                                        string_356 = string_356.replace(' ', '_');
                                        URL url = new URL(string_356);
                                        url.openConnection().setConnectTimeout(2000);
                                        String string_357 = "";
                                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                                        do
                                        {
                                            if((string_357 = datainputstream.readLine()) == null)
                                                break;
                                            string_357 = (new StringBuilder()).append("").append(string_357.trim()).toString();
                                            if(string_357.startsWith("details"))
                                            {
                                                String string_358 = getfuncSvalue("details", string_357, 0);
                                                int i_359 = getfuncvalue("details", string_357, 1);
                                                if(i_359 > 0 || string_358.toLowerCase().equals(gs.tnick.getText().toLowerCase()))
                                                {
                                                    strings_353[i_354] = strings[i_355];
                                                    i_354++;
                                                }
                                            }
                                        } while(true);
                                        datainputstream.close();
                                    }
                                    catch(Exception exception) { }
                                }

                                gs.senditem.removeAll();
                                if(i_354 > 0)
                                {
                                    for(int i_360 = 0; i_360 < i_354; i_360++)
                                        gs.senditem.add(rd, strings_353[i_360]);

                                    loaditem = 10;
                                } else
                                {
                                    gs.senditem.add(rd, "You have no cars that can be shared.");
                                    loaditem = 0;
                                }
                            }
                        }
                        if(loaditem == 2)
                        {
                            int i = 0;
                            String strings[] = new String[700];
                            try
                            {
                                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
                                url.openConnection().setConnectTimeout(2000);
                                String string_361 = "";
                                DataInputStream datainputstream = new DataInputStream(url.openStream());
                                do
                                {
                                    if((string_361 = datainputstream.readLine()) == null)
                                        break;
                                    string_361 = (new StringBuilder()).append("").append(string_361.trim()).toString();
                                    if(string_361.startsWith("mystages"))
                                    {
                                        boolean bool = true;
                                        while(bool && i < 700) 
                                        {
                                            strings[i] = getfuncSvalue("mystages", string_361, i);
                                            if(strings[i].equals(""))
                                                bool = false;
                                            else
                                                i++;
                                        }
                                    }
                                } while(true);
                                datainputstream.close();
                            }
                            catch(Exception exception)
                            {
                                String string_362 = (new StringBuilder()).append("").append(exception).toString();
                                if(string_362.indexOf("FileNotFound") != -1)
                                    i = 0;
                                else
                                    i = -1;
                            }
                            if(i == -1)
                            {
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, "Failed to load your stages, please try again later.");
                                loaditem = 0;
                            }
                            if(i == 0)
                            {
                                gs.senditem.removeAll();
                                gs.senditem.add(rd, "You have no added or published stages to load.");
                                loaditem = 0;
                            }
                            if(i > 0)
                            {
                                String strings_363[] = new String[700];
                                int i_364 = 0;
                                for(int i_365 = 0; i_365 < i; i_365++)
                                {
                                    gs.senditem.removeAll();
                                    gs.senditem.add(rd, (new StringBuilder()).append("Loading shareable stages,  ").append((int)(((float)i_365 / (float)i) * 100F)).append(" %").toString());
                                    try
                                    {
                                        String string_366 = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(strings[i_365]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                                        string_366 = string_366.replace(' ', '_');
                                        URL url = new URL(string_366);
                                        url.openConnection().setConnectTimeout(2000);
                                        String string_367 = "";
                                        DataInputStream datainputstream = new DataInputStream(url.openStream());
                                        do
                                        {
                                            if((string_367 = datainputstream.readLine()) == null)
                                                break;
                                            string_367 = (new StringBuilder()).append("").append(string_367.trim()).toString();
                                            if(string_367.startsWith("details"))
                                            {
                                                String string_368 = getfuncSvalue("details", string_367, 0);
                                                int i_369 = getfuncvalue("details", string_367, 1);
                                                if(i_369 > 0 || string_368.toLowerCase().equals(gs.tnick.getText().toLowerCase()))
                                                {
                                                    strings_363[i_364] = strings[i_365];
                                                    i_364++;
                                                }
                                            }
                                        } while(true);
                                        datainputstream.close();
                                    }
                                    catch(Exception exception) { }
                                }

                                gs.senditem.removeAll();
                                if(i_364 > 0)
                                {
                                    for(int i_370 = 0; i_370 < i_364; i_370++)
                                        gs.senditem.add(rd, strings_363[i_370]);

                                    loaditem = 20;
                                } else
                                {
                                    gs.senditem.add(rd, "You have no stages that can be shared.");
                                    loaditem = 0;
                                }
                            }
                        }
                        if(gs.sendtyp.getSelectedIndex() == 3 && !xt.clan.equals(""))
                            clanlogopng(xt.clan);
                        if(sendmsg == 1)
                            try
                            {
                                String string_371 = "#nada#";
                                int i = 0;
                                do
                                {
                                    if(i >= nm)
                                        break;
                                    if(mname[i].equals(opname))
                                    {
                                        string_371 = mconvo[i];
                                        break;
                                    }
                                    i++;
                                } while(true);
                                string = (new StringBuilder()).append("101|9|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(opname).append("|").append(string_371).append("|").append(gs.sendtyp.getSelectedIndex()).append("|").toString();
                                if(gs.sendtyp.getSelectedIndex() == 0)
                                {
                                    String string_372 = gs.mmsg.getText().replace("|", ":");
                                    string_372 = string_372.replaceAll("[\\t\\n\\r]", "|");
                                    String string_373 = "";
                                    int i = 0;
                                    int i_374 = 0;
                                    for(; i < string_372.length(); i++)
                                    {
                                        String string_375 = (new StringBuilder()).append("").append(string_372.charAt(i)).toString();
                                        if(string_375.equals("|"))
                                            i_374++;
                                        else
                                            i_374 = 0;
                                        if(i_374 <= 1)
                                            string_373 = (new StringBuilder()).append(string_373).append(string_375).toString();
                                    }

                                    string = (new StringBuilder()).append(string).append("").append(string_373).append("||").toString();
                                }
                                if(gs.sendtyp.getSelectedIndex() == 1 || gs.sendtyp.getSelectedIndex() == 2)
                                    string = (new StringBuilder()).append(string).append("").append(gs.senditem.getSelectedItem()).append("|").toString();
                                if(gs.sendtyp.getSelectedIndex() == 3)
                                    string = (new StringBuilder()).append(string).append("").append(xt.clan).append("|").toString();
                                if(gs.sendtyp.getSelectedIndex() == 4)
                                {
                                    Calendar calendar = Calendar.getInstance();
                                    long l = calendar.getTimeInMillis();
                                    Calendar calendar_376 = calendar;
                                    if(calendar == null);
                                    calendar_376.roll(5, gs.senditem.getSelectedIndex());
                                    int i = gs.datat.getSelectedIndex() + 12;
                                    if(i >= 24)
                                        i -= 24;
                                    Calendar calendar_377 = calendar;
                                    Calendar calendar_378 = calendar;
                                    if(calendar == null);
                                    int i_379 = calendar_378.get(1);
                                    Calendar calendar_380 = calendar;
                                    if(calendar == null);
                                    int i_381 = calendar_380.get(2);
                                    Calendar calendar_382 = calendar;
                                    if(calendar == null);
                                    calendar_377.set(i_379, i_381, calendar_382.get(5), i, 0);
                                    l = calendar.getTimeInMillis() - l;
                                    string = (new StringBuilder()).append(string).append("").append(l).append("|").toString();
                                }
                                dout.println(string);
                                string_307 = din.readLine();
                                if(string_307.equals("OK"))
                                {
                                    sendmsg = 2;
                                } else
                                {
                                    readmsg = 5;
                                    sendmsg = 0;
                                }
                            }
                            catch(Exception exception)
                            {
                                readmsg = 5;
                                sendmsg = 0;
                            }
                    }
                }
                if(itab == 1 && !xt.clan.equals(""))
                {
                    try
                    {
                        string = (new StringBuilder()).append("101|38|").append(xt.clan).append("|").append(xt.clankey).append("|").append(loadinter).append("|").toString();
                        dout.println(string);
                        string_307 = din.readLine();
                        if(string_307.startsWith("INTER"))
                        {
                            loadinter = getvalue(string_307, 1);
                            DataInputStream datainputstream = new DataInputStream(socket.getInputStream());
                            byte is[] = new byte[loadinter];
                            datainputstream.readFully(is);
                            string_307 = din.readLine();
                            datainputstream = new DataInputStream(new ByteArrayInputStream(is));
                            String string_383 = "";
                            for(ni = 0; (string_383 = datainputstream.readLine()) != null && ni < 200; ni++)
                            {
                                iclan[ni] = getSvalue(string_383, 0);
                                icheck[ni] = getSvalue(string_383, 1);
                                iconvo[ni] = getSvalue(string_383, 2);
                                isub[ni] = getSvalue(string_383, 3);
                                ictime[ni] = getLvalue(string_383, 4);
                                itime[ni] = "";
                                istat[ni] = getSvalue(string_383, 5);
                                if(istat[ni].equals("War"))
                                    iwarn[ni] = getSvalue(string_383, 6);
                                if(istat[ni].equals("Car Battle") || istat[ni].equals("Stage Battle"))
                                {
                                    iwarn[ni] = getSvalue(string_383, 6);
                                    itcar[ni] = getSvalue(string_383, 7);
                                    igcar[ni] = getSvalue(string_383, 8);
                                }
                            }

                        } else
                        if(string_307.equals("NOINTER"))
                            loadinter = 0;
                    }
                    catch(Exception exception)
                    {
                        loadmsgs = -2;
                    }
                    if(loadinter > 0)
                    {
                        for(int i = 0; i < ni; i++)
                            if(ictime[i] > 0L)
                                try
                                {
                                    long l = ntime - ictime[i];
                                    if(l >= 1000L && l < 60000L)
                                        itime[i] = "Seconds ago";
                                    if(l >= 60000L && l < 0x36ee80L)
                                    {
                                        int i_384 = (int)(l / 60000L);
                                        String string_385 = "s";
                                        if(i_384 == 1)
                                            string_385 = "";
                                        itime[i] = (new StringBuilder()).append("").append(i_384).append(" minute").append(string_385).append(" ago").toString();
                                    }
                                    if(l >= 0x36ee80L && l < 0x5265c00L)
                                    {
                                        int i_386 = (int)(l / 0x36ee80L);
                                        String string_387 = "s";
                                        if(i_386 == 1)
                                            string_387 = "";
                                        itime[i] = (new StringBuilder()).append("").append(i_386).append(" hour").append(string_387).append(" ago").toString();
                                    }
                                    if(l < 0x5265c00L)
                                        continue;
                                    int i_388 = (int)(l / 0x5265c00L);
                                    String string_389 = "s";
                                    if(i_388 == 1)
                                        string_389 = "";
                                    itime[i] = (new StringBuilder()).append("").append(i_388).append(" day").append(string_389).append(" ago").toString();
                                }
                                catch(Exception exception)
                                {
                                    itime[i] = "";
                                }
                            else
                                itime[i] = "";

                    }
                    if(loadwstat == 0)
                        loadchamps();
                    if(openi != 0)
                    {
                        boolean bool = false;
                        int i = -1;
                        int i_390 = 0;
                        do
                        {
                            if(i_390 >= ni)
                                break;
                            if(iclan[i_390].equals(intclan))
                            {
                                i = i_390;
                                break;
                            }
                            i_390++;
                        } while(true);
                        if(readint == 6)
                            try
                            {
                                if(connector == null);
                                Thread.sleep(2000L);
                            }
                            catch(InterruptedException interruptedexception) { }
                        if(i != -1 && readint != 3 && readint != 4 && readint != 5)
                        {
                            if(!lastint.equals((new StringBuilder()).append("").append(ictime[i]).toString()))
                            {
                                bool = true;
                                readint = 1;
                            } else
                            {
                                readint = 2;
                            }
                        } else
                        {
                            lastint = "";
                            if(readint == 1)
                            {
                                readint = 0;
                                nil = 0;
                            }
                        }
                        if(bool && sendint != 1)
                            try
                            {
                                string = (new StringBuilder()).append("101|40|").append(xt.clan).append("|").append(xt.clankey).append("|").append(iconvo[i]).append("|").toString();
                                dout.println(string);
                                string_307 = din.readLine();
                                if(string_307.startsWith("RECIVE"))
                                {
                                    if(istat[i].equals("Car Battle"))
                                    {
                                        dispi = 1;
                                        dwarn = iwarn[i];
                                        dtcar = itcar[i];
                                        dgcar = igcar[i];
                                    }
                                    if(istat[i].equals("Stage Battle"))
                                    {
                                        dispi = 2;
                                        dwarn = iwarn[i];
                                        dtcar = itcar[i];
                                        dgcar = igcar[i];
                                    }
                                    if(istat[i].equals("War"))
                                    {
                                        dispi = 3;
                                        dwarn = iwarn[i];
                                    }
                                    int i_391 = 0;
                                    String strings[] = new String[1000];
                                    int is[] = new int[1000];
                                    long ls[] = new long[1000];
                                    String strings_392[] = new String[1000];
                                    if(dispi != 0)
                                    {
                                        strings[i_391] = "";
                                        is[i_391] = 167;
                                        i_391++;
                                        strings[i_391] = "";
                                        is[i_391] = 167;
                                        i_391++;
                                    }
                                    int i_393 = getvalue(string_307, 1);
                                    DataInputStream datainputstream = new DataInputStream(socket.getInputStream());
                                    byte is_394[] = new byte[i_393];
                                    datainputstream.readFully(is_394);
                                    string_307 = din.readLine();
                                    datainputstream = new DataInputStream(new ByteArrayInputStream(is_394));
                                    String string_395 = "";
                                    do
                                    {
                                        if((string_395 = datainputstream.readLine()) == null)
                                            break;
                                        if(string_395.startsWith("|"))
                                        {
                                            if(i_391 != 0)
                                            {
                                                strings[i_391] = "";
                                                is[i_391] = 167;
                                                i_391++;
                                            }
                                            String string_396 = getSvalue(string_395, 1);
                                            if(string_396.toLowerCase().equals(xt.nickname.toLowerCase()))
                                                string_396 = "You";
                                            is[i_391] = getvalue(string_395, 2);
                                            int i_397 = is[i_391];
                                            if(i_397 == 0)
                                            {
                                                strings[i_391] = (new StringBuilder()).append("").append(string_396).append(" wrote:").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                i_391++;
                                            }
                                            if(i_397 == 1)
                                            {
                                                if(string_396.equals("You"))
                                                    strings[i_391] = "You have shared the following date:";
                                                else
                                                    strings[i_391] = (new StringBuilder()).append("").append(string_396).append(" has shared the following date:").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                Calendar calendar = Calendar.getInstance();
                                                long l = (calendar.getTimeInMillis() - (ntime - ls[i_391])) + getLvalue(string_395, 4);
                                                if(l > 0L)
                                                    calendar.setTimeInMillis(l);
                                                i_391++;
                                                Calendar calendar_398 = calendar;
                                                if(calendar == null);
                                                int i_399 = calendar_398.get(11);
                                                String string_400 = "AM";
                                                Calendar calendar_401 = calendar;
                                                if(calendar == null);
                                                if(calendar_401.get(12) > 30 && ++i_399 == 24)
                                                    i_399 -= 24;
                                                if(i_399 >= 12)
                                                    string_400 = "PM";
                                                if(i_399 > 12)
                                                    i_399 -= 12;
                                                if(i_399 == 0)
                                                    i_399 = 12;
                                                try
                                                {
                                                    String strings_402[] = strings;
                                                    int i_403 = i_391;
                                                    StringBuilder stringbuilder = (new StringBuilder()).append("[  ");
                                                    String strings_404[] = wday;
                                                    Calendar calendar_405 = calendar;
                                                    if(calendar == null);
                                                    StringBuilder stringbuilder_406 = stringbuilder.append(strings_404[calendar_405.get(7) - 1]).append("  -  ");
                                                    String strings_407[] = month;
                                                    Calendar calendar_408 = calendar;
                                                    if(calendar == null);
                                                    StringBuilder stringbuilder_409 = stringbuilder_406.append(strings_407[calendar_408.get(2)]).append(" ");
                                                    Calendar calendar_410 = calendar;
                                                    if(calendar == null);
                                                    strings_402[i_403] = stringbuilder_409.append(calendar_410.get(5)).append(",  ").append(i_399).append(" ").append(string_400).append("  ]").toString();
                                                }
                                                catch(Exception exception)
                                                {
                                                    strings[i_391] = "Error occurred while calculating this date.";
                                                }
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
                                                is[i_391] = -1;
                                                i_391++;
                                            }
                                            if(i_397 == 4)
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has declared war on ").append(intclan).append(":").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("I|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").toString();
                                                    is[i_391] = 40;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    if(loadwstat == 1 && !string_395.endsWith("|out|"))
                                                    {
                                                        int i_411 = -1;
                                                        int i_412 = 0;
                                                        int i_413 = -1;
                                                        int i_414 = 0;
                                                        for(int i_415 = 0; i_415 < ncc; i_415++)
                                                        {
                                                            if(xt.clan.toLowerCase().equals(conclan[i_415].toLowerCase()))
                                                            {
                                                                i_412 = totp[i_415];
                                                                i_411 = i_415;
                                                            }
                                                            if(intclan.toLowerCase().equals(conclan[i_415].toLowerCase()))
                                                            {
                                                                i_414 = totp[i_415];
                                                                i_413 = i_415;
                                                            }
                                                        }

                                                        int i_416 = i_414 + 1;
                                                        int i_417 = i_412 + 1;
                                                        if(i_417 > i_414)
                                                            i_417 = i_414;
                                                        if(i_411 != -1)
                                                        {
                                                            int i_418 = 0;
                                                            do
                                                            {
                                                                if(i_418 >= nvc[i_411])
                                                                    break;
                                                                if(intclan.toLowerCase().equals(verclan[i_411][i_418].toLowerCase()))
                                                                {
                                                                    i_416 -= points[i_411][i_418];
                                                                    if(i_416 < 0)
                                                                        i_416 = 0;
                                                                    break;
                                                                }
                                                                i_418++;
                                                            } while(true);
                                                        }
                                                        strings[i_391] = (new StringBuilder()).append("If you win this war, your clan would get:  [ ").append(i_416).append(" points ]   &  ").append(intclan).append(" would lose:  [ ").append(i_417).append(" points ]").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                        i_416 = i_412 + 1;
                                                        i_417 = i_414 + 1;
                                                        if(i_417 > i_412)
                                                            i_417 = i_412;
                                                        if(i_413 != -1)
                                                        {
                                                            int i_419 = 0;
                                                            do
                                                            {
                                                                if(i_419 >= nvc[i_413])
                                                                    break;
                                                                if(xt.clan.toLowerCase().equals(verclan[i_413][i_419].toLowerCase()))
                                                                {
                                                                    i_416 -= points[i_413][i_419];
                                                                    if(i_416 < 0)
                                                                        i_416 = 0;
                                                                    break;
                                                                }
                                                                i_419++;
                                                            } while(true);
                                                        }
                                                        strings[i_391] = (new StringBuilder()).append("If you lose this war, your clan would lose:  [ ").append(i_417).append(" points ]   &  ").append(intclan).append(" would get:  [ ").append(i_416).append(" points ]").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = (new StringBuilder()).append("(Waiting for ").append(intclan).append(" to accept this war declaration and create 5 more games.)").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                } else
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("").append(intclan).append(" has declaring war on your clan:").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("Y|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").toString();
                                                    is[i_391] = 40;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    if(loadwstat == 1 && !string_395.endsWith("|out|"))
                                                    {
                                                        int i_420 = -1;
                                                        int i_421 = 0;
                                                        int i_422 = -1;
                                                        int i_423 = 0;
                                                        for(int i_424 = 0; i_424 < ncc; i_424++)
                                                        {
                                                            if(xt.clan.toLowerCase().equals(conclan[i_424].toLowerCase()))
                                                            {
                                                                i_421 = totp[i_424];
                                                                i_420 = i_424;
                                                            }
                                                            if(intclan.toLowerCase().equals(conclan[i_424].toLowerCase()))
                                                            {
                                                                i_423 = totp[i_424];
                                                                i_422 = i_424;
                                                            }
                                                        }

                                                        int i_425 = i_423 + 1;
                                                        int i_426 = i_421 + 1;
                                                        if(i_426 > i_423)
                                                            i_426 = i_423;
                                                        if(i_420 != -1)
                                                        {
                                                            int i_427 = 0;
                                                            do
                                                            {
                                                                if(i_427 >= nvc[i_420])
                                                                    break;
                                                                if(intclan.toLowerCase().equals(verclan[i_420][i_427].toLowerCase()))
                                                                {
                                                                    i_425 -= points[i_420][i_427];
                                                                    if(i_425 < 0)
                                                                        i_425 = 0;
                                                                    break;
                                                                }
                                                                i_427++;
                                                            } while(true);
                                                        }
                                                        strings[i_391] = (new StringBuilder()).append("If you win this war, your clan would get:  [ ").append(i_425).append(" points ]   &  ").append(intclan).append(" would lose:  [ ").append(i_426).append(" points ]").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                        i_425 = i_421 + 1;
                                                        i_426 = i_423 + 1;
                                                        if(i_426 > i_421)
                                                            i_426 = i_421;
                                                        if(i_422 != -1)
                                                        {
                                                            int i_428 = 0;
                                                            do
                                                            {
                                                                if(i_428 >= nvc[i_422])
                                                                    break;
                                                                if(xt.clan.toLowerCase().equals(verclan[i_422][i_428].toLowerCase()))
                                                                {
                                                                    i_425 -= points[i_422][i_428];
                                                                    if(i_425 < 0)
                                                                        i_425 = 0;
                                                                    break;
                                                                }
                                                                i_428++;
                                                            } while(true);
                                                        }
                                                        strings[i_391] = (new StringBuilder()).append("If you lose this war, your clan would lose:  [ ").append(i_426).append(" points ]   &  ").append(intclan).append(" would get:  [ ").append(i_425).append(" points ]").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = "(You accept this war declaration by creating 5 more games to be added to it.)";
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                }
                                            if(i_397 == 3)
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has challenged ").append(intclan).append(" to a car battle:").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("I|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").append(getSvalue(string_395, 6)).append("|").append(getSvalue(string_395, 7)).append("|").toString();
                                                    is[i_391] = 30;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("If you win you will take ").append(intclan).append("'s car :  [ ").append(getSvalue(string_395, 4)).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("If you lose you will give ").append(intclan).append(" your clan's car :  [ ").append(getSvalue(string_395, 5)).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = (new StringBuilder()).append("(Waiting for ").append(intclan).append(" to accept this car battle and create 3 more games.)").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                } else
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("").append(intclan).append(" has challenged your clan to a car battle:").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("Y|").append(getSvalue(string_395, 5)).append("|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 6)).append("|").append(getSvalue(string_395, 7)).append("|").toString();
                                                    is[i_391] = 30;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("If you win you will take ").append(intclan).append("'s car :  [ ").append(getSvalue(string_395, 5)).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("If you lose you will give ").append(intclan).append(" your clan's car :  [ ").append(getSvalue(string_395, 4)).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = "(You accept this car battle by creating 3 more games to be added to it.)";
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                }
                                            if(i_397 == 2)
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has challenged ").append(intclan).append(" to a stage battle:").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("I|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").append(getSvalue(string_395, 6)).append("|").append(getSvalue(string_395, 7)).append("|").toString();
                                                    is[i_391] = 20;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    String string_429 = getSvalue(string_395, 4);
                                                    if(string_429.length() > 20)
                                                        string_429 = (new StringBuilder()).append("").append(string_429.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("If you win you will take ").append(intclan).append("'s stage :  [ ").append(string_429).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_429 = getSvalue(string_395, 5);
                                                    if(string_429.length() > 20)
                                                        string_429 = (new StringBuilder()).append("").append(string_429.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("If you lose you will give ").append(intclan).append(" your clan's stage :  [ ").append(string_429).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = (new StringBuilder()).append("(Waiting for ").append(intclan).append(" to accept this stage battle and create 3 more games.)").toString();
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                } else
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("").append(intclan).append(" has challenged your clan to a stage battle:").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("Y|").append(getSvalue(string_395, 5)).append("|").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 6)).append("|").append(getSvalue(string_395, 7)).append("|").toString();
                                                    is[i_391] = 20;
                                                    i_391++;
                                                    strings[i_391] = "";
                                                    is[i_391] = 167;
                                                    i_391++;
                                                    String string_430 = getSvalue(string_395, 5);
                                                    if(string_430.length() > 20)
                                                        string_430 = (new StringBuilder()).append("").append(string_430.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("If you win you will take ").append(intclan).append("'s stage :  [ ").append(string_430).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_430 = getSvalue(string_395, 4);
                                                    if(string_430.length() > 20)
                                                        string_430 = (new StringBuilder()).append("").append(string_430.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("If you lose you will give ").append(intclan).append(" your clan's stage :  [ ").append(string_430).append(" ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    if(!string_395.endsWith("|out|"))
                                                    {
                                                        strings[i_391] = "(You accept this stage battle by creating 3 more games to be added to it.)";
                                                        is[i_391] = -1;
                                                        i_391++;
                                                    }
                                                }
                                            if(i_397 == 5)
                                            {
                                                strings[i_391] = (new StringBuilder()).append("A stage battle has now started between your clan and ").append(intclan).append(" !").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                i_391++;
                                                strings[i_391] = "(See the bar at the top of the page for more details.)";
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = (new StringBuilder()).append("Arrange to meet ").append(intclan).append(" at a chosen room in a server on a specific date to play the battle.").toString();
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
                                                is[i_391] = -1;
                                                i_391++;
                                            }
                                            if(i_397 == 6)
                                            {
                                                strings[i_391] = (new StringBuilder()).append("A car battle has now started between your clan and ").append(intclan).append(" !").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                i_391++;
                                                strings[i_391] = "(See the bar at the top of the page for more details.)";
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = (new StringBuilder()).append("Arrange to meet ").append(intclan).append(" at a chosen room in a server on a specific date to play the battle.").toString();
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
                                                is[i_391] = -1;
                                                i_391++;
                                            }
                                            if(i_397 == 7)
                                            {
                                                strings[i_391] = (new StringBuilder()).append("A war has now started between your clan and ").append(intclan).append(" !").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                i_391++;
                                                if(loadwstat == 1)
                                                {
                                                    int i_431 = -1;
                                                    int i_432 = 0;
                                                    int i_433 = -1;
                                                    int i_434 = 0;
                                                    for(int i_435 = 0; i_435 < ncc; i_435++)
                                                    {
                                                        if(xt.clan.toLowerCase().equals(conclan[i_435].toLowerCase()))
                                                        {
                                                            i_432 = totp[i_435];
                                                            i_431 = i_435;
                                                        }
                                                        if(intclan.toLowerCase().equals(conclan[i_435].toLowerCase()))
                                                        {
                                                            i_434 = totp[i_435];
                                                            i_433 = i_435;
                                                        }
                                                    }

                                                    int i_436 = i_434 + 1;
                                                    int i_437 = i_432 + 1;
                                                    if(i_437 > i_434)
                                                        i_437 = i_434;
                                                    if(i_431 != -1)
                                                    {
                                                        int i_438 = 0;
                                                        do
                                                        {
                                                            if(i_438 >= nvc[i_431])
                                                                break;
                                                            if(intclan.toLowerCase().equals(verclan[i_431][i_438].toLowerCase()))
                                                            {
                                                                i_436 -= points[i_431][i_438];
                                                                if(i_436 < 0)
                                                                    i_436 = 0;
                                                                break;
                                                            }
                                                            i_438++;
                                                        } while(true);
                                                    }
                                                    strings[i_391] = (new StringBuilder()).append("If you win this war, your clan would get:  [ ").append(i_436).append(" points ]   &  ").append(intclan).append(" would lose:  [ ").append(i_437).append(" points ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    i_436 = i_432 + 1;
                                                    i_437 = i_434 + 1;
                                                    if(i_437 > i_432)
                                                        i_437 = i_432;
                                                    if(i_433 != -1)
                                                    {
                                                        int i_439 = 0;
                                                        do
                                                        {
                                                            if(i_439 >= nvc[i_433])
                                                                break;
                                                            if(xt.clan.toLowerCase().equals(verclan[i_433][i_439].toLowerCase()))
                                                            {
                                                                i_436 -= points[i_433][i_439];
                                                                if(i_436 < 0)
                                                                    i_436 = 0;
                                                                break;
                                                            }
                                                            i_439++;
                                                        } while(true);
                                                    }
                                                    strings[i_391] = (new StringBuilder()).append("If you lose this war, your clan would lose:  [ ").append(i_437).append(" points ]   &  ").append(intclan).append(" would get:  [ ").append(i_436).append(" points ]").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                }
                                                strings[i_391] = "(See the bar at the top of the page for more details.)";
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = (new StringBuilder()).append("Arrange to meet ").append(intclan).append(" at a chosen room in a server on a specific date to play the war.").toString();
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = "Use the 'Share a Relative Date' option to help you organize a time that is suitable for all.";
                                                is[i_391] = -1;
                                                i_391++;
                                            }
                                            if(i_397 == 8)
                                            {
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has defeated ").append(intclan).append(" in the war, congratulations!").toString();
                                                else
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has lost the war against ").append(intclan).append(".").toString();
                                                ls[i_391] = getLvalue(string_395, 3);
                                                strings_392[i_391] = "";
                                                i_391++;
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                    strings[i_391] = (new StringBuilder()).append("Your clan won:  [ ").append(getSvalue(string_395, 5)).append(" points ]   &  ").append(intclan).append(" lost:  [ ").append(getSvalue(string_395, 6)).append(" points ]").toString();
                                                else
                                                    strings[i_391] = (new StringBuilder()).append("Your clan lost:  [ ").append(getSvalue(string_395, 6)).append(" points ]   &  ").append(intclan).append(" won:  [ ").append(getSvalue(string_395, 5)).append(" points ]").toString();
                                                is[i_391] = -1;
                                                i_391++;
                                                strings[i_391] = (new StringBuilder()).append("").append(getSvalue(string_395, 4)).append("|").toString();
                                                is[i_391] = 80;
                                                i_391++;
                                                strings[i_391] = "";
                                                is[i_391] = 167;
                                                i_391++;
                                            }
                                            if(i_397 == 9)
                                            {
                                                String string_440 = "";
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has defeated ").append(intclan).append(" in the car battle, congratulations!").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("You took ").append(intclan).append("'s car :  [ ").append(getSvalue(string_395, 5)).append(" ] !").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_440 = xt.clan;
                                                } else
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has lost the car battle against ").append(intclan).append(".").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    strings[i_391] = (new StringBuilder()).append("").append(intclan).append(" took your car :  [ ").append(getSvalue(string_395, 5)).append(" ] !").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_440 = intclan;
                                                }
                                                strings[i_391] = (new StringBuilder()).append("").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").append(string_440).append("|").toString();
                                                is[i_391] = 90;
                                                i_391++;
                                                strings[i_391] = "";
                                                is[i_391] = 167;
                                                i_391++;
                                            }
                                            if(i_397 == 10)
                                            {
                                                String string_441 = "";
                                                if(string_396.toLowerCase().equals(xt.clan.toLowerCase()))
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has defeated ").append(intclan).append(" in the stage battle, congratulations!").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    String string_442 = getSvalue(string_395, 5);
                                                    if(string_442.length() > 20)
                                                        string_442 = (new StringBuilder()).append("").append(string_442.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("You took ").append(intclan).append("'s stage :  [ ").append(string_442).append(" ] !").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_441 = xt.clan;
                                                } else
                                                {
                                                    strings[i_391] = (new StringBuilder()).append("Your clan has lost the stage battle against ").append(intclan).append(".").toString();
                                                    ls[i_391] = getLvalue(string_395, 3);
                                                    strings_392[i_391] = "";
                                                    i_391++;
                                                    String string_443 = getSvalue(string_395, 5);
                                                    if(string_443.length() > 20)
                                                        string_443 = (new StringBuilder()).append("").append(string_443.substring(0, 20)).append("...").toString();
                                                    strings[i_391] = (new StringBuilder()).append("").append(intclan).append(" took your stage :  [ ").append(string_443).append(" ] !").toString();
                                                    is[i_391] = -1;
                                                    i_391++;
                                                    string_441 = intclan;
                                                }
                                                strings[i_391] = (new StringBuilder()).append("").append(getSvalue(string_395, 4)).append("|").append(getSvalue(string_395, 5)).append("|").append(string_441).append("|").toString();
                                                is[i_391] = 100;
                                                i_391++;
                                                strings[i_391] = "";
                                                is[i_391] = 167;
                                                i_391++;
                                            }
                                        } else
                                        {
                                            strings[i_391] = string_395;
                                            try
                                            {
                                                rd.setFont(new Font("Tahoma", 0, 11));
                                                ftm = rd.getFontMetrics();
                                                int i_444 = 0;
                                                String string_445 = "";
                                                for(; i_444 < string_395.length(); i_444++)
                                                {
                                                    string_445 = (new StringBuilder()).append(string_445).append(string_395.charAt(i_444)).toString();
                                                    if(ftm.stringWidth(string_445) <= 540)
                                                        continue;
                                                    if(string_445.lastIndexOf(" ") != -1)
                                                    {
                                                        strings[i_391] = string_445.substring(0, string_445.lastIndexOf(" "));
                                                        string_445 = string_445.substring(string_445.lastIndexOf(" ") + 1, string_445.length());
                                                    } else
                                                    {
                                                        strings[i_391] = string_445;
                                                        string_445 = "";
                                                    }
                                                    is[i_391] = -1;
                                                    i_391++;
                                                }

                                                strings[i_391] = string_445;
                                            }
                                            catch(Exception exception) { }
                                            is[i_391] = -1;
                                            i_391++;
                                        }
                                    } while(true);
                                    for(int i_446 = 0; i_446 < i_391; i_446++)
                                    {
                                        iline[i_446] = strings[i_446];
                                        ilinetyp[i_446] = is[i_446];
                                        ictimes[i_446] = ls[i_446];
                                        itimes[i_446] = strings_392[i_446];
                                    }

                                    nil = i_391;
                                    readint = 2;
                                    lastint = (new StringBuilder()).append("").append(ictime[i]).toString();
                                    if(icheck[i].toLowerCase().indexOf(xt.nickname.toLowerCase()) == -1)
                                    {
                                        StringBuilder stringbuilder = new StringBuilder();
                                        String strings_447[] = icheck;
                                        int i_448 = i;
                                        strings_447[i_448] = stringbuilder.append(strings_447[i_448]).append("#").append(xt.nickname).append("#").toString();
                                        try
                                        {
                                            dout.println((new StringBuilder()).append("101|41|").append(xt.nickname).append("|").append(xt.clan).append("|").append(intclan).append("|").toString());
                                            string_307 = din.readLine();
                                        }
                                        catch(Exception exception) { }
                                    }
                                    spos4 = 208;
                                } else
                                {
                                    readint = 3;
                                }
                            }
                            catch(Exception exception)
                            {
                                readint = 4;
                            }
                        if(readint == 2)
                        {
                            for(int i_449 = 0; i_449 < nil; i_449++)
                                if(ilinetyp[i_449] >= 0 && ilinetyp[i_449] != 167 && ictimes[i_449] > 0L)
                                    try
                                    {
                                        long l = ntime - ictimes[i_449];
                                        if(l >= 1000L && l < 60000L)
                                            itimes[i_449] = "seconds ago";
                                        if(l >= 60000L && l < 0x36ee80L)
                                        {
                                            int i_450 = (int)(l / 60000L);
                                            String string_451 = "s";
                                            if(i_450 == 1)
                                                string_451 = "";
                                            itimes[i_449] = (new StringBuilder()).append("").append(i_450).append(" minute").append(string_451).append(" ago").toString();
                                        }
                                        if(l >= 0x36ee80L && l < 0x5265c00L)
                                        {
                                            int i_452 = (int)(l / 0x36ee80L);
                                            String string_453 = "s";
                                            if(i_452 == 1)
                                                string_453 = "";
                                            itimes[i_449] = (new StringBuilder()).append("").append(i_452).append(" hour").append(string_453).append(" ago").toString();
                                        }
                                        if(l < 0x5265c00L)
                                            continue;
                                        int i_454 = (int)(l / 0x5265c00L);
                                        String string_455 = "s";
                                        if(i_454 == 1)
                                            string_455 = "";
                                        itimes[i_449] = (new StringBuilder()).append("").append(i_454).append(" day").append(string_455).append(" ago").toString();
                                    }
                                    catch(Exception exception)
                                    {
                                        itimes[i_449] = "";
                                    }
                                else
                                    itimes[i_449] = "";

                        }
                        intclanbgpng(intclan);
                    }
                    if(sendint == 2)
                    {
                        gs.mmsg.setText(" ");
                        sendint = 0;
                        if(gs.sendtyp.getSelectedIndex() > 1)
                            gs.sendtyp.select(0);
                    }
                    if(openi == 10)
                    {
                        if(viewgame2 == 1)
                        {
                            vwscorex = 0;
                            vwscorei = 0;
                            String string_456 = "pending_war";
                            if(nvgames2 == 2)
                                string_456 = "pending_battle";
                            if(nvgames2 == 9)
                                string_456 = "war";
                            if(nvgames2 == 5)
                                string_456 = "battle";
                            try
                            {
                                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/interact/").append(string_456).append("/").append(viewwar2).append(".txt").toString());
                                url.openConnection().setConnectTimeout(2000);
                                String string_457 = url.openConnection().getContentType();
                                if(string_457.equals("text/plain"))
                                {
                                    DataInputStream datainputstream = new DataInputStream(url.openStream());
                                    String string_458 = "";
                                    int i;
                                    for(i = 0; (string_458 = datainputstream.readLine()) != null && i < nvgames2; i++)
                                    {
                                        String string_459 = getSvalue(string_458, 0);
                                        if(string_459.startsWith("#"))
                                        {
                                            boolean bool = true;
                                            int i_460;
                                            try
                                            {
                                                i_460 = Integer.valueOf(string_459.substring(1)).intValue();
                                            }
                                            catch(Exception exception)
                                            {
                                                i_460 = 1;
                                            }
                                            string_459 = (new StringBuilder()).append("NFM 1  -  Stage ").append(i_460).append("").toString();
                                            if(i_460 > 10)
                                                string_459 = (new StringBuilder()).append("NFM 2  -  Stage ").append(i_460 - 10).append("").toString();
                                            if(i_460 > 27)
                                                string_459 = (new StringBuilder()).append("NFM Multiplayer  -  Stage ").append(i_460 - 27).append("").toString();
                                        }
                                        vwstages2[i] = string_459;
                                        vwlaps2[i] = getvalue(string_458, 1);
                                        vwcars2[i] = getvalue(string_458, 2);
                                        vwclass2[i] = getvalue(string_458, 3);
                                        vwfix2[i] = getvalue(string_458, 4);
                                        vwinner[i] = getSvalue(string_458, 5);
                                        if(vwinner[i].toLowerCase().equals(xt.clan.toLowerCase()))
                                            vwscorex++;
                                        if(vwinner[i].toLowerCase().equals(intclan.toLowerCase()))
                                            vwscorei++;
                                    }

                                    datainputstream.close();
                                    if(i != 0)
                                        viewgame2 = 2;
                                    else
                                        viewgame2 = 4;
                                } else
                                {
                                    viewgame2 = 3;
                                }
                            }
                            catch(Exception exception)
                            {
                                viewgame2 = 4;
                            }
                        }
                        if((gs.sendtyp.getSelectedIndex() == 4 || gs.sendtyp.getSelectedIndex() == 5 || gs.sendtyp.getSelectedIndex() == 6 || gs.sendtyp.getSelectedIndex() == 7) && gs.senditem.getSelectedIndex() == 3 && isel == 3)
                        {
                            loadiclanstages(xt.clan);
                            isel = 4;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 3 && ifas == 0)
                        {
                            loadiclancars(intclan);
                            ifas = 1;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 3 && ifas == 2)
                        {
                            loadiclancars(xt.clan);
                            ifas = 3;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 3 && gs.senditem.getSelectedIndex() == 3 && ifas == 5 && isel == 3)
                        {
                            loadiclanstages(xt.clan);
                            isel = 4;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 2 && ifas == 0)
                        {
                            loadiclanstages(intclan);
                            ifas = 1;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 2 && ifas == 2)
                        {
                            loadiclanstages(xt.clan);
                            ifas = 3;
                        }
                        if(gs.sendtyp.getSelectedIndex() == 2 && gs.senditem.getSelectedIndex() == 3 && ifas == 5 && isel == 3)
                        {
                            loadiclanstages(xt.clan);
                            isel = 4;
                        }
                        if(sendint == 1)
                            try
                            {
                                String string_461 = "#nada#";
                                int i = 0;
                                do
                                {
                                    if(i >= ni)
                                        break;
                                    if(iclan[i].equals(intclan))
                                    {
                                        string_461 = iconvo[i];
                                        break;
                                    }
                                    i++;
                                } while(true);
                                string = (new StringBuilder()).append("101|39|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(xt.clan).append("|").append(xt.clankey).append("|").append(intclan).append("|").append(string_461).append("|").append(gs.sendtyp.getSelectedIndex()).append("|").toString();
                                if(gs.sendtyp.getSelectedIndex() == 0)
                                {
                                    String string_462 = gs.mmsg.getText().replace("|", ":");
                                    string_462 = string_462.replaceAll("[\\t\\n\\r]", "|");
                                    String string_463 = "";
                                    int i = 0;
                                    int i_464 = 0;
                                    for(; i < string_462.length(); i++)
                                    {
                                        String string_465 = (new StringBuilder()).append("").append(string_462.charAt(i)).toString();
                                        if(string_465.equals("|"))
                                            i_464++;
                                        else
                                            i_464 = 0;
                                        if(i_464 <= 1)
                                            string_463 = (new StringBuilder()).append(string_463).append(string_465).toString();
                                    }

                                    string = (new StringBuilder()).append(string).append("").append(string_463).append("||").toString();
                                }
                                if(gs.sendtyp.getSelectedIndex() == 1)
                                {
                                    Calendar calendar = Calendar.getInstance();
                                    long l = calendar.getTimeInMillis();
                                    Calendar calendar_466 = calendar;
                                    if(calendar == null);
                                    calendar_466.roll(5, gs.senditem.getSelectedIndex());
                                    int i = gs.datat.getSelectedIndex() + 12;
                                    if(i >= 24)
                                        i -= 24;
                                    Calendar calendar_467 = calendar;
                                    Calendar calendar_468 = calendar;
                                    if(calendar == null);
                                    int i_469 = calendar_468.get(1);
                                    Calendar calendar_470 = calendar;
                                    if(calendar == null);
                                    int i_471 = calendar_470.get(2);
                                    Calendar calendar_472 = calendar;
                                    if(calendar == null);
                                    calendar_467.set(i_469, i_471, calendar_472.get(5), i, 0);
                                    l = calendar.getTimeInMillis() - l;
                                    string = (new StringBuilder()).append(string).append("").append(l).append("|").toString();
                                }
                                if(gs.sendtyp.getSelectedIndex() == 2 || gs.sendtyp.getSelectedIndex() == 3)
                                {
                                    string = (new StringBuilder()).append(string).append("").append(itake).append("|").append(igive).append("|").toString();
                                    if(!sendwarnum)
                                    {
                                        for(calendar = 0; calendar < 2; calendar++)
                                            string = (new StringBuilder()).append(string).append("").append(wstages[calendar]).append("|").append(wlaps[calendar]).append("|").append(wcars[calendar]).append("|").append(wclass[calendar]).append("|").append(wfix[calendar]).append("|").toString();

                                    } else
                                    {
                                        string = (new StringBuilder()).append(string).append("warnum#|").append(warnum).append("|").toString();
                                        sendwarnum = false;
                                    }
                                }
                                if(gs.sendtyp.getSelectedIndex() == 4)
                                    if(!sendwarnum)
                                    {
                                        for(calendar = 0; calendar < 4; calendar++)
                                            string = (new StringBuilder()).append(string).append("").append(wstages[calendar]).append("|").append(wlaps[calendar]).append("|").append(wcars[calendar]).append("|").append(wclass[calendar]).append("|").append(wfix[calendar]).append("|").toString();

                                    } else
                                    {
                                        string = (new StringBuilder()).append(string).append("warnum#|").append(warnum).append("|").toString();
                                        sendwarnum = false;
                                    }
                                if(gs.sendtyp.getSelectedIndex() == 5 || gs.sendtyp.getSelectedIndex() == 6)
                                {
                                    string = (new StringBuilder()).append(string).append("").append(itake).append("|").append(igive).append("|").toString();
                                    if(!sendwarnum)
                                    {
                                        string = (new StringBuilder()).append(string).append("").append(sendwar).append("|").toString();
                                        for(calendar = 0; calendar < 3; calendar++)
                                            string = (new StringBuilder()).append(string).append("").append(wstages[calendar]).append("|").append(wlaps[calendar]).append("|").append(wcars[calendar]).append("|").append(wclass[calendar]).append("|").append(wfix[calendar]).append("|").toString();

                                    } else
                                    {
                                        string = (new StringBuilder()).append(string).append("warnum#|").append(warnum).append("|").toString();
                                        sendwarnum = false;
                                    }
                                }
                                if(gs.sendtyp.getSelectedIndex() == 7)
                                    if(!sendwarnum)
                                    {
                                        string = (new StringBuilder()).append(string).append("").append(sendwar).append("|").toString();
                                        for(calendar = 0; calendar < 5; calendar++)
                                            string = (new StringBuilder()).append(string).append("").append(wstages[calendar]).append("|").append(wlaps[calendar]).append("|").append(wcars[calendar]).append("|").append(wclass[calendar]).append("|").append(wfix[calendar]).append("|").toString();

                                    } else
                                    {
                                        string = (new StringBuilder()).append(string).append("warnum#|").append(warnum).append("|").toString();
                                        sendwarnum = false;
                                    }
                                dout.println(string);
                                string_307 = din.readLine();
                                if(string_307.equals("OK"))
                                    sendint = 2;
                                else
                                if(string_307.equals("SUJ"))
                                {
                                    itab = 2;
                                    sendint = 0;
                                    openi = 0;
                                    readint = 0;
                                } else
                                if(string_307.equals("failfile"))
                                {
                                    readint = 6;
                                    sendint = 0;
                                    gs.mmsg.setText(" ");
                                    gs.sendtyp.select(0);
                                } else
                                {
                                    readint = 5;
                                    sendint = 0;
                                }
                            }
                            catch(Exception exception)
                            {
                                readint = 5;
                                sendint = 0;
                            }
                    }
                }
                if(itab == 2 && !xt.clan.equals(""))
                {
                    try
                    {
                        string = (new StringBuilder()).append("101|36|").append(xt.clan).append("|").append(xt.clankey).append("|").append(readclan).append("|").append(xt.nickname).append("|").toString();
                        dout.println(string);
                        string_307 = din.readLine();
                        if(string_307.startsWith("RECIVE"))
                        {
                            readclan = -3;
                            if(loadwstat == 0)
                                loadchamps();
                            int i = getvalue(string_307, 1);
                            cadmin = getvalue(string_307, 2);
                            int i_473 = 0;
                            String strings[] = new String[1000];
                            int is[] = new int[1000];
                            long ls[] = new long[1000];
                            String strings_474[] = new String[1000];
                            strings[i_473] = "";
                            is[i_473] = 167;
                            i_473++;
                            DataInputStream datainputstream = new DataInputStream(socket.getInputStream());
                            byte is_475[] = new byte[i];
                            datainputstream.readFully(is_475);
                            string_307 = din.readLine();
                            datainputstream = new DataInputStream(new ByteArrayInputStream(is_475));
                            String string_476 = "";
                            do
                            {
                                if((string_476 = datainputstream.readLine()) == null)
                                    break;
                                if(string_476.startsWith("|"))
                                {
                                    strings[i_473] = "";
                                    is[i_473] = 167;
                                    i_473++;
                                    String string_477 = getSvalue(string_476, 1);
                                    if(string_477.toLowerCase().equals(xt.nickname.toLowerCase()))
                                        string_477 = "You";
                                    is[i_473] = getvalue(string_476, 2);
                                    int i_478 = is[i_473];
                                    if(i_478 == 0)
                                    {
                                        strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" wrote:").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                    }
                                    if(i_478 == 1)
                                    {
                                        if(string_477.equals("You"))
                                            strings[i_473] = "You have shared the following date:";
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" has shared the following date:").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        Calendar calendar = Calendar.getInstance();
                                        long l = (calendar.getTimeInMillis() - (ntime - ls[i_473])) + getLvalue(string_476, 4);
                                        if(l > 0L)
                                            calendar.setTimeInMillis(l);
                                        i_473++;
                                        Calendar calendar_479 = calendar;
                                        if(calendar == null);
                                        int i_480 = calendar_479.get(11);
                                        String string_481 = "AM";
                                        Calendar calendar_482 = calendar;
                                        if(calendar == null);
                                        if(calendar_482.get(12) > 30 && ++i_480 == 24)
                                            i_480 -= 24;
                                        if(i_480 >= 12)
                                            string_481 = "PM";
                                        if(i_480 > 12)
                                            i_480 -= 12;
                                        if(i_480 == 0)
                                            i_480 = 12;
                                        try
                                        {
                                            String strings_483[] = strings;
                                            int i_484 = i_473;
                                            StringBuilder stringbuilder = (new StringBuilder()).append("[  ");
                                            String strings_485[] = wday;
                                            Calendar calendar_486 = calendar;
                                            if(calendar == null);
                                            StringBuilder stringbuilder_487 = stringbuilder.append(strings_485[calendar_486.get(7) - 1]).append("  -  ");
                                            String strings_488[] = month;
                                            Calendar calendar_489 = calendar;
                                            if(calendar == null);
                                            StringBuilder stringbuilder_490 = stringbuilder_487.append(strings_488[calendar_489.get(2)]).append(" ");
                                            Calendar calendar_491 = calendar;
                                            if(calendar == null);
                                            strings_483[i_484] = stringbuilder_490.append(calendar_491.get(5)).append(",  ").append(i_480).append(" ").append(string_481).append("  ]").toString();
                                        }
                                        catch(Exception exception)
                                        {
                                            strings[i_473] = "Error occurred while calculating this date.";
                                        }
                                        is[i_473] = -1;
                                        i_473++;
                                        strings[i_473] = "(Please make sure your computer's calendar/clock is adjusted correctly, to read this date in your local time.)";
                                        is[i_473] = -1;
                                        i_473++;
                                    }
                                    if(i_478 == 2)
                                    {
                                        String string_492 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested declaring war on [ ").append(string_492).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested declaring war on [ ").append(string_492).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_492).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").toString();
                                        is[i_473] = 20;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        if(loadwstat == 1 && !string_476.endsWith("|out|"))
                                        {
                                            int i_493 = -1;
                                            int i_494 = 0;
                                            int i_495 = -1;
                                            int i_496 = 0;
                                            for(int i_497 = 0; i_497 < ncc; i_497++)
                                            {
                                                if(xt.clan.toLowerCase().equals(conclan[i_497].toLowerCase()))
                                                {
                                                    i_494 = totp[i_497];
                                                    i_493 = i_497;
                                                }
                                                if(string_492.toLowerCase().equals(conclan[i_497].toLowerCase()))
                                                {
                                                    i_496 = totp[i_497];
                                                    i_495 = i_497;
                                                }
                                            }

                                            int i_498 = i_496 + 1;
                                            int i_499 = i_494 + 1;
                                            if(i_499 > i_496)
                                                i_499 = i_496;
                                            if(i_493 != -1)
                                            {
                                                int i_500 = 0;
                                                do
                                                {
                                                    if(i_500 >= nvc[i_493])
                                                        break;
                                                    if(string_492.toLowerCase().equals(verclan[i_493][i_500].toLowerCase()))
                                                    {
                                                        i_498 -= points[i_493][i_500];
                                                        if(i_498 < 0)
                                                            i_498 = 0;
                                                        break;
                                                    }
                                                    i_500++;
                                                } while(true);
                                            }
                                            strings[i_473] = (new StringBuilder()).append("If you win this war, your clan would get:  [ ").append(i_498).append(" points ]   &  ").append(string_492).append(" would lose:  [ ").append(i_499).append(" points ]").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                            i_498 = i_494 + 1;
                                            i_499 = i_496 + 1;
                                            if(i_499 > i_494)
                                                i_499 = i_494;
                                            if(i_495 != -1)
                                            {
                                                int i_501 = 0;
                                                do
                                                {
                                                    if(i_501 >= nvc[i_495])
                                                        break;
                                                    if(xt.clan.toLowerCase().equals(verclan[i_495][i_501].toLowerCase()))
                                                    {
                                                        i_498 -= points[i_495][i_501];
                                                        if(i_498 < 0)
                                                            i_498 = 0;
                                                        break;
                                                    }
                                                    i_501++;
                                                } while(true);
                                            }
                                            strings[i_473] = (new StringBuilder()).append("If you lose this war, your clan would lose:  [ ").append(i_499).append(" points ]   &  ").append(string_492).append(" would get:  [ ").append(i_498).append(" points ]").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be declared on ").append(string_492).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 3)
                                    {
                                        String string_502 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested to car battle with [ ").append(string_502).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested to car battle with [ ").append(string_502).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_502).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").append(getSvalue(string_476, 7)).append("|").append(getSvalue(string_476, 8)).append("|").toString();
                                        is[i_473] = 30;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("If you win you will take ").append(string_502).append("'s car :  [ ").append(getSvalue(string_476, 5)).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("If you lose you will give ").append(string_502).append(" your clan's car :  [ ").append(getSvalue(string_476, 6)).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be sent to ").append(string_502).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 4)
                                    {
                                        String string_503 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested to stage battle with [ ").append(string_503).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested to stage battle with [ ").append(string_503).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_503).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").append(getSvalue(string_476, 7)).append("|").append(getSvalue(string_476, 8)).append("|").toString();
                                        is[i_473] = 40;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        String string_504 = getSvalue(string_476, 5);
                                        if(string_504.length() > 20)
                                            string_504 = (new StringBuilder()).append("").append(string_504.substring(0, 20)).append("...").toString();
                                        strings[i_473] = (new StringBuilder()).append("If you win you will take ").append(string_503).append("'s stage :  [ ").append(string_504).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        string_504 = getSvalue(string_476, 6);
                                        if(string_504.length() > 20)
                                            string_504 = (new StringBuilder()).append("").append(string_504.substring(0, 20)).append("...").toString();
                                        strings[i_473] = (new StringBuilder()).append("If you lose you will give ").append(string_503).append(" your clan's stage :  [ ").append(string_504).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be sent to ").append(string_503).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 5)
                                    {
                                        String string_505 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested accepting to go to war with [ ").append(string_505).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested accepting to go to war with [ ").append(string_505).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_505).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").toString();
                                        is[i_473] = 50;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        if(loadwstat == 1 && !string_476.endsWith("|out|"))
                                        {
                                            int i_506 = -1;
                                            int i_507 = 0;
                                            int i_508 = -1;
                                            int i_509 = 0;
                                            for(int i_510 = 0; i_510 < ncc; i_510++)
                                            {
                                                if(xt.clan.toLowerCase().equals(conclan[i_510].toLowerCase()))
                                                {
                                                    i_507 = totp[i_510];
                                                    i_506 = i_510;
                                                }
                                                if(string_505.toLowerCase().equals(conclan[i_510].toLowerCase()))
                                                {
                                                    i_509 = totp[i_510];
                                                    i_508 = i_510;
                                                }
                                            }

                                            int i_511 = i_509 + 1;
                                            int i_512 = i_507 + 1;
                                            if(i_512 > i_509)
                                                i_512 = i_509;
                                            if(i_506 != -1)
                                            {
                                                int i_513 = 0;
                                                do
                                                {
                                                    if(i_513 >= nvc[i_506])
                                                        break;
                                                    if(string_505.toLowerCase().equals(verclan[i_506][i_513].toLowerCase()))
                                                    {
                                                        i_511 -= points[i_506][i_513];
                                                        if(i_511 < 0)
                                                            i_511 = 0;
                                                        break;
                                                    }
                                                    i_513++;
                                                } while(true);
                                            }
                                            strings[i_473] = (new StringBuilder()).append("If you win this war, your clan would get:  [ ").append(i_511).append(" points ]   &  ").append(string_505).append(" would lose:  [ ").append(i_512).append(" points ]").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                            i_511 = i_507 + 1;
                                            i_512 = i_509 + 1;
                                            if(i_512 > i_507)
                                                i_512 = i_507;
                                            if(i_508 != -1)
                                            {
                                                int i_514 = 0;
                                                do
                                                {
                                                    if(i_514 >= nvc[i_508])
                                                        break;
                                                    if(xt.clan.toLowerCase().equals(verclan[i_508][i_514].toLowerCase()))
                                                    {
                                                        i_511 -= points[i_508][i_514];
                                                        if(i_511 < 0)
                                                            i_511 = 0;
                                                        break;
                                                    }
                                                    i_514++;
                                                } while(true);
                                            }
                                            strings[i_473] = (new StringBuilder()).append("If you lose this war, your clan would lose:  [ ").append(i_512).append(" points ]   &  ").append(string_505).append(" would get:  [ ").append(i_511).append(" points ]").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be declared on ").append(string_505).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 6)
                                    {
                                        String string_515 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested accepting to car battle with [ ").append(string_515).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested accepting to car battle with [ ").append(string_515).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_515).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").append(getSvalue(string_476, 7)).append("|").append(getSvalue(string_476, 8)).append("|").toString();
                                        is[i_473] = 60;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("If you win you will take ").append(string_515).append("'s car :  [ ").append(getSvalue(string_476, 5)).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("If you lose you will give ").append(string_515).append(" your clan's car :  [ ").append(getSvalue(string_476, 6)).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be sent to ").append(string_515).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 7)
                                    {
                                        String string_516 = getSvalue(string_476, 4);
                                        if(string_477.equals("You"))
                                            strings[i_473] = (new StringBuilder()).append("You have suggested accepting to stage battle with [ ").append(string_516).append(" ] :").toString();
                                        else
                                            strings[i_473] = (new StringBuilder()).append("").append(string_477).append(" suggested accepting to stage battle with [ ").append(string_516).append(" ] :").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        strings[i_473] = (new StringBuilder()).append("").append(string_516).append("|").append(getSvalue(string_476, 5)).append("|").append(getSvalue(string_476, 6)).append("|").append(getSvalue(string_476, 7)).append("|").append(getSvalue(string_476, 8)).append("|").toString();
                                        is[i_473] = 70;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                        String string_517 = getSvalue(string_476, 5);
                                        if(string_517.length() > 20)
                                            string_517 = (new StringBuilder()).append("").append(string_517.substring(0, 20)).append("...").toString();
                                        strings[i_473] = (new StringBuilder()).append("If you win you will take ").append(string_516).append("'s stage :  [ ").append(string_517).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        string_517 = getSvalue(string_476, 6);
                                        if(string_517.length() > 20)
                                            string_517 = (new StringBuilder()).append("").append(string_517.substring(0, 20)).append("...").toString();
                                        strings[i_473] = (new StringBuilder()).append("If you lose you will give ").append(string_516).append(" your clan's stage :  [ ").append(string_517).append(" ]").toString();
                                        is[i_473] = -1;
                                        i_473++;
                                        if(!string_476.endsWith("|out|"))
                                        {
                                            strings[i_473] = (new StringBuilder()).append("(This needs to be approved by the Clan Leader or an Admin to be sent to ").append(string_516).append(".)").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                    }
                                    if(i_478 == 8)
                                    {
                                        int i_518 = getvalue(string_476, 4);
                                        String string_519 = "taken";
                                        if(i_518 == 2)
                                            string_519 = "re-claimed";
                                        strings[i_473] = (new StringBuilder()).append("Congratulations!!  Your clan has ").append(string_519).append(" the clan wars world championship title!").toString();
                                        ls[i_473] = getLvalue(string_476, 3);
                                        strings_474[i_473] = "";
                                        i_473++;
                                        if(i_518 == 1)
                                        {
                                            strings[i_473] = (new StringBuilder()).append("Your recent win in the war against ").append(getSvalue(string_476, 6)).append(" has given you the championship title!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(i_518 == 2)
                                        {
                                            strings[i_473] = (new StringBuilder()).append("You have successfully defended your championship title against ").append(getSvalue(string_476, 6)).append("!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(i_518 == 3)
                                        {
                                            strings[i_473] = (new StringBuilder()).append("A recent war between ").append(getSvalue(string_476, 5)).append(" and ").append(getSvalue(string_476, 6)).append(" has resulted in a change of points!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(i_518 == 4)
                                        {
                                            strings[i_473] = (new StringBuilder()).append("Clan ").append(getSvalue(string_476, 5)).append(" removed itself from the game which resulted in a change of points, giving you the title!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        if(i_518 != 2)
                                        {
                                            strings[i_473] = (new StringBuilder()).append("").append(xt.clan).append(" is now the new champion of the world in Need for Madness!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        } else
                                        {
                                            strings[i_473] = (new StringBuilder()).append("").append(xt.clan).append(" still remains the champion of the world in Need for Madness!").toString();
                                            is[i_473] = -1;
                                            i_473++;
                                        }
                                        is[i_473] = 80;
                                        i_473++;
                                        strings[i_473] = "";
                                        is[i_473] = 167;
                                        i_473++;
                                    }
                                } else
                                {
                                    strings[i_473] = string_476;
                                    try
                                    {
                                        rd.setFont(new Font("Tahoma", 0, 11));
                                        ftm = rd.getFontMetrics();
                                        int i_520 = 0;
                                        String string_521 = "";
                                        for(; i_520 < string_476.length(); i_520++)
                                        {
                                            string_521 = (new StringBuilder()).append(string_521).append(string_476.charAt(i_520)).toString();
                                            if(ftm.stringWidth(string_521) <= 540)
                                                continue;
                                            if(string_521.lastIndexOf(" ") != -1)
                                            {
                                                strings[i_473] = string_521.substring(0, string_521.lastIndexOf(" "));
                                                string_521 = string_521.substring(string_521.lastIndexOf(" ") + 1, string_521.length());
                                            } else
                                            {
                                                strings[i_473] = string_521;
                                                string_521 = "";
                                            }
                                            is[i_473] = -1;
                                            i_473++;
                                        }

                                        strings[i_473] = string_521;
                                    }
                                    catch(Exception exception) { }
                                    is[i_473] = -1;
                                    i_473++;
                                }
                            } while(true);
                            for(int i_522 = 0; i_522 < i_473; i_522++)
                            {
                                cmline[i_522] = strings[i_522];
                                cmlinetyp[i_522] = is[i_522];
                                cmctimes[i_522] = ls[i_522];
                                cmtimes[i_522] = strings_474[i_522];
                            }

                            cnml = i_473;
                            readclan = i;
                            spos3 = 219;
                        }
                    }
                    catch(Exception exception)
                    {
                        readclan = -1;
                    }
                    if(readclan > 0)
                    {
                        for(int i = 0; i < cnml; i++)
                            if(cmlinetyp[i] >= 0 && cmlinetyp[i] != 167 && cmctimes[i] > 0L)
                                try
                                {
                                    long l = ntime - cmctimes[i];
                                    if(l >= 1000L && l < 60000L)
                                        cmtimes[i] = "seconds ago";
                                    if(l >= 60000L && l < 0x36ee80L)
                                    {
                                        int i_523 = (int)(l / 60000L);
                                        String string_524 = "s";
                                        if(i_523 == 1)
                                            string_524 = "";
                                        cmtimes[i] = (new StringBuilder()).append("").append(i_523).append(" minute").append(string_524).append(" ago").toString();
                                    }
                                    if(l >= 0x36ee80L && l < 0x5265c00L)
                                    {
                                        int i_525 = (int)(l / 0x36ee80L);
                                        String string_526 = "s";
                                        if(i_525 == 1)
                                            string_526 = "";
                                        cmtimes[i] = (new StringBuilder()).append("").append(i_525).append(" hour").append(string_526).append(" ago").toString();
                                    }
                                    if(l < 0x5265c00L)
                                        continue;
                                    int i_527 = (int)(l / 0x5265c00L);
                                    String string_528 = "s";
                                    if(i_527 == 1)
                                        string_528 = "";
                                    cmtimes[i] = (new StringBuilder()).append("").append(i_527).append(" day").append(string_528).append(" ago").toString();
                                }
                                catch(Exception exception)
                                {
                                    cmtimes[i] = "";
                                }
                            else
                                cmtimes[i] = "";

                    }
                    clanlogopng(xt.clan);
                    if(sendcmsg == 2)
                    {
                        gs.mmsg.setText(" ");
                        sendcmsg = 0;
                    }
                    if(viewgame1 == 1)
                        try
                        {
                            String string_529 = "pending_war";
                            if(nvgames1 == 2 || nvgames1 == 5)
                                string_529 = "pending_battle";
                            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/interact/").append(string_529).append("/").append(viewwar1).append(".txt").toString());
                            url.openConnection().setConnectTimeout(2000);
                            String string_530 = url.openConnection().getContentType();
                            if(string_530.equals("text/plain"))
                            {
                                DataInputStream datainputstream = new DataInputStream(url.openStream());
                                String string_531 = "";
                                int i;
                                for(i = 0; (string_531 = datainputstream.readLine()) != null && i < nvgames1; i++)
                                {
                                    String string_532 = getSvalue(string_531, 0);
                                    if(string_532.startsWith("#"))
                                    {
                                        boolean bool = true;
                                        int i_533;
                                        try
                                        {
                                            i_533 = Integer.valueOf(string_532.substring(1)).intValue();
                                        }
                                        catch(Exception exception)
                                        {
                                            i_533 = 1;
                                        }
                                        string_532 = (new StringBuilder()).append("NFM 1  -  Stage ").append(i_533).append("").toString();
                                        if(i_533 > 10)
                                            string_532 = (new StringBuilder()).append("NFM 2  -  Stage ").append(i_533 - 10).append("").toString();
                                        if(i_533 > 27)
                                            string_532 = (new StringBuilder()).append("NFM Multiplayer  -  Stage ").append(i_533 - 27).append("").toString();
                                    }
                                    vwstages1[i] = string_532;
                                    vwlaps1[i] = getvalue(string_531, 1);
                                    vwcars1[i] = getvalue(string_531, 2);
                                    vwclass1[i] = getvalue(string_531, 3);
                                    vwfix1[i] = getvalue(string_531, 4);
                                }

                                datainputstream.close();
                                if(i != 0)
                                    viewgame1 = 2;
                                else
                                    viewgame1 = 4;
                            } else
                            {
                                viewgame1 = 3;
                            }
                        }
                        catch(Exception exception)
                        {
                            viewgame1 = 4;
                        }
                    if(sendcmsg == 1)
                        try
                        {
                            string = (new StringBuilder()).append("101|37|").append(xt.nickname).append("|").append(xt.nickey).append("|").append(xt.clan).append("|").append(xt.clankey).append("|").append(gs.sendtyp.getSelectedIndex()).append("|").toString();
                            if(gs.sendtyp.getSelectedIndex() == 0)
                            {
                                String string_534 = gs.mmsg.getText().replace("|", ":");
                                string_534 = string_534.replaceAll("[\\t\\n\\r]", "|");
                                String string_535 = "";
                                int i = 0;
                                int i_536 = 0;
                                for(; i < string_534.length(); i++)
                                {
                                    String string_537 = (new StringBuilder()).append("").append(string_534.charAt(i)).toString();
                                    if(string_537.equals("|"))
                                        i_536++;
                                    else
                                        i_536 = 0;
                                    if(i_536 <= 1)
                                        string_535 = (new StringBuilder()).append(string_535).append(string_537).toString();
                                }

                                string = (new StringBuilder()).append(string).append("").append(string_535).append("||").toString();
                            }
                            if(gs.sendtyp.getSelectedIndex() == 1)
                            {
                                Calendar calendar = Calendar.getInstance();
                                long l = calendar.getTimeInMillis();
                                Calendar calendar_538 = calendar;
                                if(calendar == null);
                                calendar_538.roll(5, gs.senditem.getSelectedIndex());
                                int i = gs.datat.getSelectedIndex() + 12;
                                if(i >= 24)
                                    i -= 24;
                                Calendar calendar_539 = calendar;
                                Calendar calendar_540 = calendar;
                                if(calendar == null);
                                int i_541 = calendar_540.get(1);
                                Calendar calendar_542 = calendar;
                                if(calendar == null);
                                int i_543 = calendar_542.get(2);
                                Calendar calendar_544 = calendar;
                                if(calendar == null);
                                calendar_539.set(i_541, i_543, calendar_544.get(5), i, 0);
                                l = calendar.getTimeInMillis() - l;
                                string = (new StringBuilder()).append(string).append("").append(l).append("|").toString();
                            }
                            dout.println(string);
                            string_307 = din.readLine();
                            if(string_307.equals("OK"))
                            {
                                sendcmsg = 2;
                            } else
                            {
                                readclan = -2;
                                sendcmsg = 0;
                            }
                        }
                        catch(Exception exception)
                        {
                            readclan = -2;
                            sendcmsg = 0;
                        }
                    loadmyclanbg();
                }
            }
            if(lg.nmsgs != 0 || lg.nfreq != 0 || lg.nconf != 0 || lg.ncreq != 0 || !lg.clanapv.equals(""))
            {
                string = (new StringBuilder()).append("101|19|").append(xt.nickname).append("|").append(xt.nickey).append("|").toString();
                try
                {
                    dout.println(string);
                    string_307 = din.readLine();
                }
                catch(Exception exception) { }
                lg.nmsgs = 0;
                lg.nfreq = 0;
                lg.nconf = 0;
                lg.ncreq = 0;
                lg.clanapv = "";
            }
            if(tab == 0 && domon)
            {
                string = (new StringBuilder()).append("101|101|").append(updatec).append("|").toString();
                if(updatec <= -11)
                {
                    for(int i = 0; i < -updatec - 10; i++)
                        string = (new StringBuilder()).append(string).append("").append(cnames[20 - i]).append("|").append(sentn[20 - i]).append("|").toString();

                    updatec = -2;
                }
                try
                {
                    dout.println(string);
                    string_307 = din.readLine();
                    if(string_307 == null)
                        domon = false;
                }
                catch(Exception exception)
                {
                    domon = false;
                }
                if(domon)
                {
                    int i = getvalue(string_307, 0);
                    if(updatec != i && updatec >= -2)
                    {
                        for(int i_545 = 0; i_545 < 21; i_545++)
                        {
                            cnames[i_545] = getSvalue(string_307, 1 + i_545 * 3);
                            sentn[i_545] = getSvalue(string_307, 2 + i_545 * 3);
                            nctime[i_545] = getLvalue(string_307, 3 + i_545 * 3);
                        }

                        updatec = i;
                    }
                    for(int i_546 = 0; i_546 < 21; i_546++)
                        if(nctime[i_546] > 0L)
                        {
                            long l = ntime - nctime[i_546];
                            if(l < 1000L)
                                ctime[i_546] = "- just now";
                            if(l >= 1000L && l < 60000L)
                                ctime[i_546] = "- seconds ago";
                            if(l >= 60000L && l < 0x36ee80L)
                            {
                                int i_547 = (int)(l / 60000L);
                                String string_548 = "s";
                                if(i_547 == 1)
                                    string_548 = "";
                                ctime[i_546] = (new StringBuilder()).append("- ").append(i_547).append(" minute").append(string_548).append(" ago").toString();
                            }
                            if(l >= 0x36ee80L && l < 0x5265c00L)
                            {
                                int i_549 = (int)(l / 0x36ee80L);
                                String string_550 = "s";
                                if(i_549 == 1)
                                    string_550 = "";
                                ctime[i_546] = (new StringBuilder()).append("- ").append(i_549).append(" hour").append(string_550).append(" ago").toString();
                            }
                            if(l < 0x5265c00L)
                                continue;
                            int i_551 = (int)(l / 0x5265c00L);
                            String string_552 = "s";
                            if(i_551 == 1)
                                string_552 = "";
                            ctime[i_546] = (new StringBuilder()).append("- ").append(i_551).append(" day").append(string_552).append(" ago").toString();
                        } else
                        {
                            ctime[i_546] = "";
                        }

                }
            }
            if(tab == 1)
            {
                if(upload == 5)
                {
                    upload = 0;
                    loadedp = false;
                    edit = 0;
                    refresh = true;
                }
                if(!loadedp)
                {
                    if(!refresh)
                    {
                        loadproinfo();
                        trunsent();
                    }
                    logopng();
                    avatarpng();
                    clanlogopng(proclan);
                    refresh = false;
                    loadedp = true;
                }
            }
            if(ptab == 2 && !xt.clan.equals("") && !loadedcm)
            {
                loadfclan();
                loadedcm = true;
            }
            if(tab == 3)
            {
                if(cfase == 0)
                {
                    if(!xt.clan.equals(""))
                        clanlogopng(xt.clan);
                    if(ntab == 0 && loadednews == 0)
                        loadnews();
                    if(ntab == 1 && loadwstat == 0)
                        loadchamps();
                }
                if(cfase == 1 && em == 1)
                {
                    String string_553 = gs.temail.getText();
                    string = (new StringBuilder()).append("101|26|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(string_553).append("|").toString();
                    try
                    {
                        dout.println(string);
                        string_307 = din.readLine();
                    }
                    catch(Exception exception)
                    {
                        string_307 = "fail";
                    }
                    if(string_307.startsWith("OK"))
                    {
                        xt.clan = string_553;
                        xt.clankey = getSvalue(string_307, 1);
                        spos5 = 0;
                        lspos5 = 0;
                        cfase = 3;
                        claname = string_553;
                        loadedc = false;
                        ctab = 0;
                        em = 0;
                    } else
                    if(string_307.equals("FOUND"))
                    {
                        msg = (new StringBuilder()).append("The name '").append(string_553).append("' is already used by another clan!").toString();
                        flko = 45;
                        em = 0;
                    } else
                    {
                        msg = "Server error authorizing clan creation, please try again later...";
                        flko = 45;
                        em = 0;
                    }
                }
                if(cfase == 2)
                {
                    if(em == 1)
                    {
                        string = "101|27|";
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "";
                        }
                        nclns = 0;
                        for(String string_554 = getSvalue(string_307, nclns); !string_554.equals("") && nclns < 20; string_554 = getSvalue(string_307, nclns))
                        {
                            clanlo[nclns] = string_554;
                            nclns++;
                        }

                        if(nclns != 0)
                            smsg = "Clans with recent activity:";
                        else
                            smsg = "Found no clans with recent activity.";
                        em = 0;
                    }
                    if(em == 2)
                    {
                        string = (new StringBuilder()).append("101|28|").append(gs.temail.getText()).append("").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "";
                        }
                        nclns = 0;
                        for(String string_555 = getSvalue(string_307, nclns); !string_555.equals("") && nclns < 20; string_555 = getSvalue(string_307, nclns))
                        {
                            clanlo[nclns] = string_555;
                            nclns++;
                        }

                        if(nclns != 0)
                            smsg = (new StringBuilder()).append("Search result for '").append(gs.temail.getText()).append("' in clans:").toString();
                        else
                            smsg = (new StringBuilder()).append("Found no clans with the phrase '").append(gs.temail.getText()).append("' in them.").toString();
                        em = 0;
                    }
                }
                if(cfase == 3)
                {
                    if(editc == 33)
                    {
                        string = (new StringBuilder()).append("101|24|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(member[em]).append("|").append(gs.clanlev.getSelectedIndex() + 1).append("|").append(gs.cmsg.getText()).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            loadedc = false;
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(editc == 66)
                    {
                        string = (new StringBuilder()).append("101|24|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(rmember[em]).append("|1|New member - just approved.|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            if(nrmb == 1)
                            {
                                spos5 = 0;
                                lspos5 = 0;
                            }
                            loadedc = false;
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(editc == 44)
                    {
                        string = (new StringBuilder()).append("101|25|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(member[em]).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            loadedc = false;
                            if(member[em].toLowerCase().equals(xt.nickname.toLowerCase()))
                            {
                                if(proname.equals(xt.nickname))
                                    proclan = "";
                                xt.clan = "";
                                xt.clankey = "";
                                if(nmb == 1)
                                    cfase = 0;
                            }
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(editc == 77)
                    {
                        string = (new StringBuilder()).append("101|25|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(rmember[em]).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            if(nrmb == 1)
                            {
                                spos5 = 0;
                                lspos5 = 0;
                            }
                            loadedc = false;
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(editc == 99)
                    {
                        string = (new StringBuilder()).append("101|30|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            loadedc = false;
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(upload == 5)
                    {
                        upload = 0;
                        loadedc = false;
                        if(editc == 2)
                            loadedmyclanbg = -1;
                        editc = 0;
                        refresh = true;
                    }
                    if(!loadedc)
                    {
                        if(!refresh)
                            loadclan();
                        clanlogopng(claname);
                        clanbgpng();
                        refresh = false;
                        loadedc = true;
                    }
                    if(attachetoclan)
                    {
                        string = (new StringBuilder()).append("101|29|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.indexOf("|") != -1)
                        {
                            xt.clan = getSvalue(string_307, 0);
                            xt.clankey = getSvalue(string_307, 1);
                        }
                        attachetoclan = false;
                    }
                    if(editc == 55)
                    {
                        string = (new StringBuilder()).append("101|31|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(sltit).append("|").append(gs.cmsg.getText()).append("|").append(gs.temail.getText()).append("|").toString();
                        try
                        {
                            dout.println(string);
                            string_307 = din.readLine();
                        }
                        catch(Exception exception)
                        {
                            string_307 = "fail";
                        }
                        if(string_307.equals("OK"))
                        {
                            editc = 0;
                            loadedlink = false;
                        } else
                        {
                            editc = 5;
                        }
                    }
                    if(ctab == 2)
                    {
                        if(loadedcars == 6)
                        {
                            string = (new StringBuilder()).append("101|32|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(selcar).append("|").toString();
                            try
                            {
                                dout.println(string);
                                string_307 = din.readLine();
                            }
                            catch(Exception exception)
                            {
                                string_307 = "fail";
                            }
                            if(string_307.equals("OK"))
                                loadedcars = -1;
                            else
                                loadedcars = 7;
                        }
                        if(loadedcars == 8)
                        {
                            string = (new StringBuilder()).append("101|33|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(selcar).append("|").toString();
                            try
                            {
                                dout.println(string);
                                string_307 = din.readLine();
                            }
                            catch(Exception exception)
                            {
                                string_307 = "fail";
                            }
                            if(string_307.equals("OK"))
                                loadedcars = -1;
                            else
                                loadedcars = 9;
                        }
                        if(loadedcars == -1)
                            loadedcars = loadclancars();
                        if(loadedcars == 1 && !selcar.equals("Select Car") && loadedcar == 0)
                        {
                            if(xt.sc[0] != 36 || xt.clan.toLowerCase().equals(claname.toLowerCase()))
                                cd.haltload = 1;
                            else
                                cd.haltload = 2;
                            while(cd.haltload == cd.onloadingcar) ;
                            loadedcar = cd.loadonlinecar(selcar, 35 + cd.haltload);
                            if(xt.sc[0] == 36 && cd.haltload == 1 && loadedcar > 0)
                            {
                                boolean bool = false;
                                for(int i = 0; i < bco[36].npl && !bool; i++)
                                    if(bco[36].p[i].colnum == 1)
                                    {
                                        float fs[] = new float[3];
                                        Color.RGBtoHSB(bco[36].p[i].c[0], bco[36].p[i].c[1], bco[36].p[i].c[2], fs);
                                        xt.arnp[0] = fs[0];
                                        xt.arnp[1] = fs[1];
                                        xt.arnp[2] = 1.0F - fs[2];
                                        bool = true;
                                    }

                                bool = false;
                                for(int i = 0; i < bco[36].npl && !bool; i++)
                                    if(bco[36].p[i].colnum == 2)
                                    {
                                        float fs[] = new float[3];
                                        Color.RGBtoHSB(bco[36].p[i].c[0], bco[36].p[i].c[1], bco[36].p[i].c[2], fs);
                                        xt.arnp[3] = fs[0];
                                        xt.arnp[4] = fs[1];
                                        xt.arnp[5] = 1.0F - fs[2];
                                        bool = true;
                                    }

                            }
                        }
                        if(loadedcars == 2)
                            loadedcars = loadaddcars();
                    }
                    if(ctab == 3)
                    {
                        if(loadedstages == 6)
                        {
                            string = (new StringBuilder()).append("101|34|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(selstage).append("|").toString();
                            try
                            {
                                dout.println(string);
                                string_307 = din.readLine();
                            }
                            catch(Exception exception)
                            {
                                string_307 = "fail";
                            }
                            if(string_307.equals("OK"))
                                loadedstages = -1;
                            else
                                loadedstages = 7;
                        }
                        if(loadedstages == 8)
                        {
                            string = (new StringBuilder()).append("101|35|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(claname).append("|").append(selstage).append("|").toString();
                            try
                            {
                                dout.println(string);
                                string_307 = din.readLine();
                            }
                            catch(Exception exception)
                            {
                                string_307 = "fail";
                            }
                            if(string_307.equals("OK"))
                                loadedstages = -1;
                            else
                                loadedstages = 9;
                        }
                        if(loadedstages == -1)
                            loadedstages = loadclanstages();
                        if(loadedstages == 1 && !selstage.equals("Select Stage") && loadedstage == 0)
                        {
                            cd.t.nt = 0;
                            if(gs.loadstagePreview(-2, selstage, co, bco, m, cp))
                            {
                                loadedstage = 1;
                                m.ptr = 0;
                                m.ptcnt = -10;
                                m.hit = 45000;
                                m.fallen = 0;
                                m.nrnd = 0;
                            } else
                            {
                                loadedstage = -1;
                            }
                        }
                        if(loadedstages == 2)
                            loadedstages = loadaddstages();
                    }
                    if(ctab == 4 && !loadedlink)
                    {
                        loadclanlink();
                        loadedlink = true;
                    }
                }
            }
            if(upload != 0)
                if(filename.toLowerCase().endsWith(".gif") || filename.toLowerCase().endsWith(".jpg") || filename.toLowerCase().endsWith(".jpeg") || filename.toLowerCase().endsWith(".png"))
                {
                    File file = new File(filename);
                    if(file.exists())
                    {
                        int i = (int)file.length();
                        if(i < 0x100000)
                        {
                            if(upload != 0)
                            {
                                upload = 2;
                                try
                                {
                                    int i_556 = 2;
                                    if(tab == 1 && edit == 2)
                                        i_556 = 3;
                                    String string_557 = "";
                                    if(tab == 3)
                                    {
                                        if(editc == 1)
                                            i_556 = 22;
                                        if(editc == 2)
                                            i_556 = 23;
                                        string_557 = (new StringBuilder()).append("").append(claname).append("|").toString();
                                    }
                                    string = (new StringBuilder()).append("101|").append(i_556).append("|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(i).append("|").append(string_557).append("").toString();
                                    dout.println(string);
                                    string_307 = din.readLine();
                                    if(string_307.equals("OK"))
                                    {
                                        FileInputStream fileinputstream = new FileInputStream(file);
                                        byte is[] = new byte[i];
                                        fileinputstream.read(is);
                                        fileinputstream.close();
                                        DataOutputStream dataoutputstream = new DataOutputStream(socket.getOutputStream());
                                        if(upload != 0)
                                            upload = 3;
                                        perc = 0;
                                        for(int i_558 = 0; i_558 < i && upload != 0;)
                                        {
                                            int i_559 = 10240;
                                            if(i_558 + i_559 > i)
                                                i_559 = i - i_558;
                                            dataoutputstream.write(is, i_558, i_559);
                                            i_558 += i_559;
                                            perc = (int)(((float)i_558 / (float)i) * 100F);
                                        }

                                        if(upload != 0)
                                        {
                                            string_307 = din.readLine();
                                            if(string_307.equals("CR"))
                                            {
                                                upload = 4;
                                            } else
                                            {
                                                msg = "Failed to create image online, server error!";
                                                flko = 45;
                                                upload = 0;
                                            }
                                            string_307 = din.readLine();
                                            if(string_307.equals("OK"))
                                                upload = 5;
                                        } else
                                        {
                                            try
                                            {
                                                socket.close();
                                                socket = null;
                                                din.close();
                                                din = null;
                                                dout.close();
                                                dout = null;
                                                connector = null;
                                            }
                                            catch(Exception exception) { }
                                            try
                                            {
                                                socket = new Socket(lg.servers[0], 7061);
                                                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                                                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                                            }
                                            catch(Exception exception) { }
                                        }
                                    } else
                                    {
                                        msg = "Failed to authenticate to start an uploading connection!";
                                        flko = 45;
                                        upload = 0;
                                    }
                                }
                                catch(Exception exception)
                                {
                                    msg = "Failed to upload image, unknown error!";
                                    flko = 45;
                                    upload = 0;
                                    try
                                    {
                                        socket.close();
                                        socket = null;
                                        din.close();
                                        din = null;
                                        dout.close();
                                        dout = null;
                                        connector = null;
                                    }
                                    catch(Exception exception_560) { }
                                    try
                                    {
                                        socket = new Socket(lg.servers[0], 7061);
                                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                                    }
                                    catch(Exception exception_561) { }
                                }
                            }
                        } else
                        {
                            msg = "Uploaded image must be less than 1MB in size!";
                            flko = 45;
                            upload = 0;
                        }
                    } else
                    {
                        msg = "The file chosen is invalid or does not exist!";
                        flko = 45;
                        upload = 0;
                    }
                } else
                {
                    msg = "Uploaded image must be JPEG, GIF or PNG!";
                    flko = 45;
                    upload = 0;
                }
            if(uploadt == 5)
            {
                uploadt = 0;
                msg = "";
            }
            if(uploadt != 0)
            {
                File file = new File(filename);
                if(file.exists())
                {
                    int i = (int)file.length();
                    if(i < 0x3e800)
                    {
                        xt.strack = new RadicalMod(filename, true);
                        if(xt.strack.loaded == 2)
                        {
                            trackvol = (int)(220F / ((float)xt.strack.rvol / 3750F));
                            xt.strack.unload();
                            if(uploadt != 0)
                            {
                                uploadt = 2;
                                try
                                {
                                    string = (new StringBuilder()).append("101|4|").append(gs.tnick.getText()).append("|").append(gs.tpass.getText()).append("|").append(trackname).append("|").append(trackvol).append("|").append(i).append("|").toString();
                                    dout.println(string);
                                    string_307 = din.readLine();
                                    if(string_307.equals("OK"))
                                    {
                                        string_307 = din.readLine();
                                        if(uploadt != 0)
                                        {
                                            if(string_307.equals("UPLOAD"))
                                            {
                                                uploadt = 3;
                                                FileInputStream fileinputstream = new FileInputStream(file);
                                                byte is[] = new byte[i];
                                                fileinputstream.read(is);
                                                fileinputstream.close();
                                                DataOutputStream dataoutputstream = new DataOutputStream(socket.getOutputStream());
                                                dataoutputstream.write(is, 0, i);
                                                uploadt = 4;
                                                string_307 = din.readLine();
                                            }
                                            if(string_307.equals("FOUND"))
                                            {
                                                uploadt = 4;
                                                string_307 = din.readLine();
                                            }
                                            if(string_307.equals("OK"))
                                            {
                                                themesong = trackname;
                                                uploadt = 5;
                                            } else
                                            if(string_307.equals("EXIST"))
                                            {
                                                msg = "Another track with the same name already exists, please rename you file!";
                                                flko = 45;
                                                uploadt = 0;
                                            } else
                                            {
                                                msg = "Failed to add MOD Track to your profile, unknown error!";
                                                flko = 45;
                                                uploadt = 0;
                                            }
                                        } else
                                        {
                                            try
                                            {
                                                socket.close();
                                                socket = null;
                                                din.close();
                                                din = null;
                                                dout.close();
                                                dout = null;
                                                connector = null;
                                            }
                                            catch(Exception exception) { }
                                            try
                                            {
                                                socket = new Socket(lg.servers[0], 7061);
                                                din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                                                dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                                            }
                                            catch(Exception exception) { }
                                        }
                                    } else
                                    {
                                        msg = "Failed to authenticate to start an uploading connection!";
                                        flko = 45;
                                        uploadt = 0;
                                    }
                                }
                                catch(Exception exception)
                                {
                                    msg = "Failed to upload track, unknown error!";
                                    flko = 45;
                                    uploadt = 0;
                                    try
                                    {
                                        socket.close();
                                        socket = null;
                                        din.close();
                                        din = null;
                                        dout.close();
                                        dout = null;
                                        connector = null;
                                    }
                                    catch(Exception exception_562) { }
                                    try
                                    {
                                        socket = new Socket(lg.servers[0], 7061);
                                        din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
                                        dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
                                    }
                                    catch(Exception exception_563) { }
                                }
                            }
                        } else
                        {
                            xt.strack.unload();
                            msg = "The file choosen is not a valid MOD Track!";
                            flko = 45;
                            uploadt = 0;
                        }
                    } else
                    {
                        msg = "Uploaded file must be less than 250KB in size!";
                        flko = 45;
                        uploadt = 0;
                    }
                } else
                {
                    msg = "The file chosen is invalid or does not exist!";
                    flko = 45;
                    uploadt = 0;
                }
            }
            if(playt == 1)
            {
                xt.strack = new RadicalMod(themesong, trackvol, 8000, 125, false, true);
                xt.strack.play();
                playt = 2;
            }
            domelogos();
            try
            {
                if(connector == null);
                Thread.sleep(600L);
            }
            catch(InterruptedException interruptedexception) { }
        }
        onexit();
    }

    public void onexit()
    {
        onexitpro();
        gs.hidefields();
        cd.acname = "";
        cd.action = 0;
        cd.staction = 0;
        cd.onstage = "";
        addstage = 0;
        npf = -1;
        editc = 0;
        openc = 0;
        readmsg = 0;
        loadmsgs = -1;
        readclan = 0;
        if(cd.haltload == 2)
        {
            cd.haltload = 1;
            cd.lcardate[1] = 0;
        }
        if(cd.haltload == 1)
            if(xt.sc[0] == 36)
            {
                if(!xt.clan.toLowerCase().equals(claname.toLowerCase()))
                    loadedcars = -1;
            } else
            {
                cd.haltload = 0;
                cd.lcardate[0] = 0;
            }
        m.crs = true;
        m.focus_point = 400;
        m.x = -335;
        m.y = 0;
        m.z = -50;
        m.xz = 0;
        m.zy = 20;
        m.ground = -2000;
        try
        {
            socket.close();
            socket = null;
            din.close();
            din = null;
            dout.close();
            dout = null;
            connector = null;
        }
        catch(Exception exception) { }
    }

    public void onexitpro()
    {
        edit = 0;
        upload = 0;
        uploadt = 0;
        sfreq = 0;
        if(playt == 2)
        {
            xt.strack.unload();
            playt = 0;
        }
    }

    public void stopallnow()
    {
        if(connector != null)
        {
            connector.stop();
            connector = null;
        }
        try
        {
            socket.close();
            socket = null;
            din.close();
            din = null;
            dout.close();
            dout = null;
            connector = null;
        }
        catch(Exception exception) { }
    }

    public void trunsent()
    {
        for(int i = 0; i < 3; i++)
            aboutxt[i] = "";

        if(!sentance.equals(""))
        {
            rd.setFont(new Font("Tahoma", 1, 11));
            ftm = rd.getFontMetrics();
            int i = 0;
            int i_564 = 0;
            int i_565 = 0;
            int i_566 = 0;
            boolean bool = false;
            for(; i_564 < sentance.length(); i_564++)
            {
                String string = (new StringBuilder()).append("").append(sentance.charAt(i_564)).toString();
                if(string.equals(" "))
                    i_565 = i_564;
                StringBuilder stringbuilder;
                String strings[];
                if(i < 3)
                {
                    stringbuilder = new StringBuilder();
                    strings = aboutxt;
                    int i_567 = i;
                    strings[i_567] = stringbuilder.append(strings[i_567]).append(string).toString();
                    if(ftm.stringWidth(aboutxt[i]) <= 276)
                        continue;
                    if(i_565 != i_566)
                    {
                        aboutxt[i] = sentance.substring(i_566, i_565);
                        i_564 = i_565;
                        i_566 = i_564;
                    } else
                    if(i == 2)
                        bool = true;
                    i++;
                    continue;
                }
                if(bool)
                    aboutxt[2] = aboutxt[2].substring(0, aboutxt[2].length() - 3);
                stringbuilder = new StringBuilder();
                strings = aboutxt;
                int i_568 = 2;
                strings[i_568] = stringbuilder.append(strings[i_568]).append("...").toString();
                i_564 = sentance.length();
            }

        }
        nab = 0;
        for(int i = 0; i < 3 && !aboutxt[i].equals(""); i++)
        {
            aboutxt[i] = aboutxt[i].trim();
            nab++;
        }

    }

    public void roomlogos(String strings[], int i)
    {
        for(int i_569 = 0; i_569 < 2; i_569++)
        {
            boolean bool = true;
            String string = "";
            int i_570 = 0;
            do
            {
                if(i_570 >= i)
                    break;
                bool = false;
                int i_571 = 0;
                do
                {
                    if(i_571 >= nlg)
                        break;
                    if(strings[i_570].toLowerCase().equals(logos[i_571].toLowerCase()))
                    {
                        bool = true;
                        break;
                    }
                    i_571++;
                } while(true);
                if(!bool)
                {
                    string = strings[i_570].toLowerCase();
                    break;
                }
                i_570++;
            } while(true);
            if(bool)
                break;
            logos[nlg] = string;
            logon[nlg] = false;
            try
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(logos[nlg]).append("/logo.png").toString());
                url.openConnection().setConnectTimeout(2000);
                String string_572 = url.openConnection().getContentType();
                if(string_572.equals("image/png"))
                {
                    logoi[nlg] = Toolkit.getDefaultToolkit().createImage(url);
                    mt.addImage(logoi[nlg], nlg);
                    logon[nlg] = true;
                }
            }
            catch(Exception exception) { }
            nlg++;
            if(nlg == 200)
                nlg = 0;
        }

    }

    public void domelogos()
    {
        for(int i = 0; i < 5; i++)
        {
            boolean bool = true;
            boolean bool_573 = false;
            String string = "";
            String string_574 = "";
            if(freq == 1)
            {
                bool = false;
                int i_575 = 0;
                do
                {
                    if(i_575 >= nlg)
                        break;
                    if(freqname.toLowerCase().equals(logos[i_575].toLowerCase()))
                    {
                        bool = true;
                        break;
                    }
                    i_575++;
                } while(true);
                if(!bool)
                    string = freqname.toLowerCase();
            }
            if(bool && loadednews == 1)
            {
                for(int i_576 = 0; i_576 < 4; i_576++)
                {
                    if(newplayers[i_576].equals(""))
                        continue;
                    bool = false;
                    int i_577 = 0;
                    do
                    {
                        if(i_577 >= nlg)
                            break;
                        if(newplayers[i_576].toLowerCase().equals(logos[i_577].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_577++;
                    } while(true);
                    if(bool)
                        continue;
                    string = newplayers[i_576].toLowerCase();
                    break;
                }

            }
            if(bool && loadednews == 1)
            {
                for(int i_578 = 0; i_578 < 5; i_578++)
                {
                    if(nwarbs[i_578] <= 0)
                        continue;
                    bool = false;
                    String string_579 = (new StringBuilder()).append("#").append(nwclan[i_578]).append("#").toString();
                    int i_580 = 0;
                    do
                    {
                        if(i_580 >= nlg)
                            break;
                        if(string_579.toLowerCase().equals(logos[i_580].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_580++;
                    } while(true);
                    if(bool)
                        continue;
                    string = string_579.toLowerCase();
                    bool_573 = true;
                    string_574 = nwclan[i_578];
                    break;
                }

            }
            if(bool && loadwstat == 1)
            {
                for(int i_581 = 0; i_581 < 5; i_581++)
                {
                    if(ncc <= 0)
                        continue;
                    bool = false;
                    String string_582 = (new StringBuilder()).append("#").append(conclan[i_581]).append("#").toString();
                    int i_583 = 0;
                    do
                    {
                        if(i_583 >= nlg)
                            break;
                        if(string_582.toLowerCase().equals(logos[i_583].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_583++;
                    } while(true);
                    if(bool)
                        continue;
                    string = string_582.toLowerCase();
                    bool_573 = true;
                    string_574 = conclan[i_581];
                    break;
                }

            }
            if(bool && ni > 0)
            {
                int i_584 = 0;
                do
                {
                    if(i_584 >= ni)
                        break;
                    bool = false;
                    String string_585 = (new StringBuilder()).append("#").append(iclan[i_584]).append("#").toString();
                    int i_586 = 0;
                    do
                    {
                        if(i_586 >= nlg)
                            break;
                        if(string_585.toLowerCase().equals(logos[i_586].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_586++;
                    } while(true);
                    if(!bool)
                    {
                        string = string_585.toLowerCase();
                        bool_573 = true;
                        string_574 = iclan[i_584];
                        break;
                    }
                    i_584++;
                } while(true);
            }
            if(bool && nclns > 0)
            {
                int i_587 = 0;
                do
                {
                    if(i_587 >= nclns)
                        break;
                    bool = false;
                    String string_588 = (new StringBuilder()).append("#").append(clanlo[i_587]).append("#").toString();
                    int i_589 = 0;
                    do
                    {
                        if(i_589 >= nlg)
                            break;
                        if(string_588.toLowerCase().equals(logos[i_589].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_589++;
                    } while(true);
                    if(!bool)
                    {
                        string = string_588.toLowerCase();
                        bool_573 = true;
                        string_574 = clanlo[i_587];
                        break;
                    }
                    i_587++;
                } while(true);
            }
            if(bool && nrmb > 0 && showreqs)
            {
                int i_590 = 0;
                do
                {
                    if(i_590 >= nrmb)
                        break;
                    bool = false;
                    int i_591 = 0;
                    do
                    {
                        if(i_591 >= nlg)
                            break;
                        if(rmember[i_590].toLowerCase().equals(logos[i_591].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_591++;
                    } while(true);
                    if(!bool)
                    {
                        string = rmember[i_590].toLowerCase();
                        break;
                    }
                    i_590++;
                } while(true);
            }
            if(bool && nmb > 0)
            {
                int i_592 = 0;
                do
                {
                    if(i_592 >= nmb)
                        break;
                    bool = false;
                    int i_593 = 0;
                    do
                    {
                        if(i_593 >= nlg)
                            break;
                        if(member[i_592].toLowerCase().equals(logos[i_593].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_593++;
                    } while(true);
                    if(!bool)
                    {
                        string = member[i_592].toLowerCase();
                        break;
                    }
                    i_592++;
                } while(true);
            }
            if(bool && nclns > 0)
            {
                int i_594 = 0;
                do
                {
                    if(i_594 >= ncln)
                        break;
                    bool = false;
                    int i_595 = 0;
                    do
                    {
                        if(i_595 >= nlg)
                            break;
                        if(clname[i_594].toLowerCase().equals(logos[i_595].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_595++;
                    } while(true);
                    if(!bool)
                    {
                        string = clname[i_594].toLowerCase();
                        break;
                    }
                    i_594++;
                } while(true);
            }
            if(bool && npf > 0)
            {
                int i_596 = 0;
                do
                {
                    if(i_596 >= npf)
                        break;
                    bool = false;
                    int i_597 = 0;
                    do
                    {
                        if(i_597 >= nlg)
                            break;
                        if(fname[i_596].toLowerCase().equals(logos[i_597].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_597++;
                    } while(true);
                    if(!bool)
                    {
                        string = fname[i_596].toLowerCase();
                        break;
                    }
                    i_596++;
                } while(true);
            }
            if(bool && nm > 0)
            {
                int i_598 = 0;
                do
                {
                    if(i_598 >= nm)
                        break;
                    bool = false;
                    int i_599 = 0;
                    do
                    {
                        if(i_599 >= nlg)
                            break;
                        if(mname[i_598].toLowerCase().equals(logos[i_599].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_599++;
                    } while(true);
                    if(!bool)
                    {
                        string = mname[i_598].toLowerCase();
                        break;
                    }
                    i_598++;
                } while(true);
            }
            if(bool)
            {
                int i_600 = 0;
                do
                {
                    if(i_600 >= npo)
                        break;
                    bool = false;
                    int i_601 = 0;
                    do
                    {
                        if(i_601 >= nlg)
                            break;
                        if(pname[i_600].toLowerCase().equals(logos[i_601].toLowerCase()))
                        {
                            bool = true;
                            break;
                        }
                        i_601++;
                    } while(true);
                    if(!bool)
                    {
                        string = pname[i_600].toLowerCase();
                        break;
                    }
                    i_600++;
                } while(true);
            }
            if(bool)
                break;
            logos[nlg] = string;
            logon[nlg] = false;
            try
            {
                String string_602 = (new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(logos[nlg]).append("/logo.png").toString();
                if(bool_573)
                    string_602 = (new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(string_574).append("/logo.png").toString();
                URL url = new URL(string_602);
                url.openConnection().setConnectTimeout(2000);
                String string_603 = url.openConnection().getContentType();
                if(string_603.equals("image/png"))
                {
                    logoi[nlg] = Toolkit.getDefaultToolkit().createImage(url);
                    mt.addImage(logoi[nlg], nlg);
                    logon[nlg] = true;
                }
            }
            catch(Exception exception) { }
            nlg++;
            if(nlg == 200)
                nlg = 0;
        }

    }

    public boolean drawl(Graphics2D graphics2d, String string, int i, int i_604, boolean bool)
    {
        boolean bool_605 = false;
        int i_606 = -1;
        int i_607 = 0;
        do
        {
            if(i_607 >= nlg)
                break;
            if(string.toLowerCase().equals(logos[i_607].toLowerCase()))
            {
                i_606 = i_607;
                break;
            }
            i_607++;
        } while(true);
        if(i_606 != -1 && logon[i_606])
        {
            if(!bool)
                graphics2d.setComposite(AlphaComposite.getInstance(3, 0.1F));
            graphics2d.drawImage(logoi[i_606], i, i_604, null);
            bool_605 = mt.checkID(i_606);
            if(!bool)
                graphics2d.setComposite(AlphaComposite.getInstance(3, 1.0F));
        }
        return bool_605;
    }

    public void logopng()
    {
        int i = -1;
        boolean bool = false;
        int i_608 = 0;
        do
        {
            if(i_608 >= nlg)
                break;
            if(proname.toLowerCase().equals(logos[i_608].toLowerCase()))
            {
                i = i_608;
                if(logon[i] && !refresh)
                {
                    bool = true;
                    logol = true;
                }
                break;
            }
            i_608++;
        } while(true);
        if(!bool)
        {
            if(i == -1)
            {
                i = nlg;
                nlg++;
                if(nlg == 200)
                    nlg = 0;
            }
            logos[i] = proname.toLowerCase();
            try
            {
                String string = "";
                if(refresh)
                    string = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(proname).append("/logo.png").append(string).append("").toString());
                url.openConnection().setConnectTimeout(2000);
                String string_609 = url.openConnection().getContentType();
                if(string_609.equals("image/png"))
                {
                    logoi[i] = Toolkit.getDefaultToolkit().createImage(url);
                    mt.addImage(logoi[i], i);
                    logon[i] = true;
                } else
                {
                    logon[i] = false;
                }
            }
            catch(Exception exception) { }
            logol = logon[i];
        }
    }

    public void clanlogopng(String string)
    {
        int i = -1;
        boolean bool = false;
        String string_610 = (new StringBuilder()).append("#").append(string.toLowerCase()).append("#").toString();
        int i_611 = 0;
        do
        {
            if(i_611 >= nlg)
                break;
            if(string_610.equals(logos[i_611]))
            {
                i = i_611;
                if(logon[i] && !refresh)
                    bool = true;
                break;
            }
            i_611++;
        } while(true);
        if(!bool)
        {
            if(i == -1)
            {
                i = nlg;
                nlg++;
                if(nlg == 200)
                    nlg = 0;
            }
            logos[i] = string_610;
            try
            {
                String string_612 = "";
                if(refresh)
                    string_612 = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(string).append("/logo.png").append(string_612).append("").toString());
                url.openConnection().setConnectTimeout(2000);
                String string_613 = url.openConnection().getContentType();
                if(string_613.equals("image/png"))
                {
                    logoi[i] = Toolkit.getDefaultToolkit().createImage(url);
                    mt.addImage(logoi[i], i);
                    logon[i] = true;
                } else
                {
                    logon[i] = false;
                }
            }
            catch(Exception exception) { }
        }
    }

    public void avatarpng()
    {
        avatarl = false;
        String string = "";
        if(refresh)
            string = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(proname).append("/avatar.png").append(string).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_614 = url.openConnection().getContentType();
            if(string_614.equals("image/png"))
            {
                avatar = Toolkit.getDefaultToolkit().createImage(url);
                avatarl = true;
            }
        }
        catch(Exception exception) { }
    }

    public void clanbgpng()
    {
        clanbgl = false;
        String string = "";
        if(refresh)
            string = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(claname).append("/bg.jpg").append(string).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_615 = url.openConnection().getContentType();
            if(string_615.equals("image/jpeg"))
            {
                clanbg = Toolkit.getDefaultToolkit().createImage(url);
                clanbgl = true;
            }
        }
        catch(Exception exception) { }
    }

    public void intclanbgpng(String string)
    {
        if(!intclanlo.equals(string))
        {
            intclanbgloaded = false;
            try
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(string).append("/bg.jpg").toString());
                url.openConnection().setConnectTimeout(2000);
                String string_616 = url.openConnection().getContentType();
                if(string_616.equals("image/jpeg"))
                {
                    intclanbg = Toolkit.getDefaultToolkit().createImage(url);
                    intclanbgloaded = true;
                }
            }
            catch(Exception exception) { }
            intclanlo = string;
        }
    }

    public void loadmyclanbg()
    {
        if(loadedmyclanbg <= 0)
        {
            String string = "";
            if(loadedmyclanbg == -1)
                string = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
            loadedmyclanbg = 2;
            try
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(xt.clan).append("/bg.jpg").append(string).append("").toString());
                url.openConnection().setConnectTimeout(2000);
                String string_617 = url.openConnection().getContentType();
                if(string_617.equals("image/jpeg"))
                {
                    myclanbg = Toolkit.getDefaultToolkit().createImage(url);
                    loadedmyclanbg = 1;
                }
            }
            catch(Exception exception) { }
        }
    }

    public void loadclan()
    {
        notclan = false;
        int i = 0;
        String strings[] = new String[20];
        int is[] = new int[20];
        String strings_618[] = new String[20];
        showreqs = false;
        nrmb = 0;
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(claname).append("/members.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string = url.openConnection().getContentType();
            if(string.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_619 = "";
                do
                {
                    if((string_619 = datainputstream.readLine()) == null || i >= 20)
                        break;
                    string_619 = string_619.trim();
                    String string_620 = getSvalue(string_619, 0);
                    if(!string_620.equals(""))
                    {
                        int i_621 = getvalue(string_619, 1);
                        if(i_621 != 0)
                        {
                            strings[i] = string_620;
                            is[i] = i_621;
                            strings_618[i] = getSvalue(string_619, 2);
                            i++;
                        } else
                        if(nrmb < 100)
                        {
                            rmember[nrmb] = string_620;
                            nrmb++;
                        }
                    }
                } while(true);
                datainputstream.close();
            } else
            {
                notclan = true;
            }
        }
        catch(Exception exception) { }
        nmb = 0;
        if(!notclan)
        {
            for(int i_622 = 7; i_622 > 0; i_622--)
            {
                for(int i_623 = 0; i_623 < i; i_623++)
                    if(is[i_623] == i_622)
                    {
                        member[nmb] = strings[i_623];
                        mrank[nmb] = strings_618[i_623];
                        mlevel[nmb] = is[i_623];
                        nmb++;
                    }

            }

            for(int i_624 = 0; i_624 < nmb; i_624++)
            {
                if(!xt.nickname.toLowerCase().equals(member[i_624].toLowerCase()))
                    continue;
                if((mlevel[i_624] == 7 || i_624 == 0) && nrmb != 0)
                    showreqs = true;
                if(!xt.clan.toLowerCase().equals(claname.toLowerCase()))
                    attachetoclan = true;
            }

            if(xt.clan.toLowerCase().equals(claname.toLowerCase()))
            {
                for(int i_625 = 0; i_625 < i; i_625++)
                    clname[i_625] = strings[i_625];

                ncln = i;
                loadedcm = true;
            }
        }
    }

    public void loadclanlink()
    {
        ltit = "";
        ldes = "";
        lurl = "";
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(claname).append("/link.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string = url.openConnection().getContentType();
            if(string.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_626 = "";
                for(int i = 0; (string_626 = datainputstream.readLine()) != null && i < 3; i++)
                {
                    string_626 = string_626.trim();
                    if(i == 0)
                        ltit = string_626;
                    if(i == 1)
                        ldes = string_626;
                    if(i == 2)
                        lurl = string_626;
                }

                datainputstream.close();
            }
        }
        catch(Exception exception)
        {
            ltit = "";
            ldes = "";
            lurl = "";
        }
    }

    public void loadfclan()
    {
        ncln = 0;
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(xt.clan).append("/members.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            String string = "";
            do
            {
                if((string = datainputstream.readLine()) == null || ncln >= 20)
                    break;
                string = string.trim();
                String string_627 = getSvalue(string, 0);
                if(!string_627.equals("") && getvalue(string, 1) != 0)
                {
                    clname[ncln] = string_627;
                    ncln++;
                }
            } while(true);
            datainputstream.close();
        }
        catch(Exception exception) { }
    }

    public int loadclancars()
    {
        m.csky[0] = 170;
        m.csky[1] = 220;
        m.csky[2] = 255;
        m.cfade[0] = 255;
        m.cfade[1] = 220;
        m.cfade[2] = 220;
        m.snap[0] = 0;
        m.snap[1] = 0;
        m.snap[2] = 0;
        int i = 0;
        gs.clcars.removeAll();
        gs.clcars.add(rd, "Select Car");
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(claname).append("/cars.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string = url.openConnection().getContentType();
            if(string.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_628 = "";
                int i_629 = 0;
                do
                {
                    if((string_628 = datainputstream.readLine()) == null || i_629 >= 700)
                        break;
                    gs.clcars.add(rd, string_628);
                    i_629++;
                    if(i != 1)
                        i = 1;
                } while(true);
                datainputstream.close();
            }
        }
        catch(Exception exception)
        {
            i = -2;
        }
        if(i == 1)
        {
            if(viewcar.equals(""))
            {
                gs.clcars.select(0);
            } else
            {
                gs.clcars.select(viewcar);
                viewcar = "";
            }
            selcar = gs.clcars.getSelectedItem();
        }
        return i;
    }

    public int loadaddcars()
    {
        int i = 3;
        int i_630 = 0;
        String strings[] = new String[700];
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/cars/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            String string = "";
            do
            {
                if((string = datainputstream.readLine()) == null)
                    break;
                string = (new StringBuilder()).append("").append(string.trim()).toString();
                if(string.startsWith("mycars"))
                {
                    boolean bool = true;
                    while(bool && i_630 < 700) 
                    {
                        strings[i_630] = getfuncSvalue("mycars", string, i_630);
                        if(strings[i_630].equals(""))
                            bool = false;
                        else
                            i_630++;
                    }
                }
            } while(true);
            datainputstream.close();
        }
        catch(Exception exception)
        {
            String string = (new StringBuilder()).append("").append(exception).toString();
            if(string.indexOf("FileNotFound") != -1)
            {
                i_630 = 0;
                i = 3;
            } else
            {
                i_630 = -1;
                i = 4;
            }
        }
        if(i_630 > 0)
        {
            String strings_631[] = new String[700];
            int i_632 = 0;
            for(int i_633 = 0; i_633 < i_630; i_633++)
            {
                perry = (new StringBuilder()).append("").append((int)(((float)i_633 / (float)i_630) * 100F)).append(" %").toString();
                try
                {
                    String string = (new StringBuilder()).append("http://multiplayer.needformadness.com/cars/").append(strings[i_633]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                    string = string.replace(' ', '_');
                    URL url = new URL(string);
                    url.openConnection().setConnectTimeout(2000);
                    DataInputStream datainputstream = new DataInputStream(url.openStream());
                    String string_634 = "";
                    do
                    {
                        if((string_634 = datainputstream.readLine()) == null)
                            break;
                        string_634 = (new StringBuilder()).append("").append(string_634.trim()).toString();
                        if(string_634.startsWith("details"))
                        {
                            String string_635 = getfuncSvalue("details", string_634, 0);
                            if(string_635.toLowerCase().equals(gs.tnick.getText().toLowerCase()) && string_634.indexOf("Clan#") == -1)
                            {
                                strings_631[i_632] = strings[i_633];
                                i_632++;
                            }
                        }
                    } while(true);
                    datainputstream.close();
                }
                catch(Exception exception) { }
            }

            if(i_632 > 0)
            {
                gs.clcars.removeAll();
                for(int i_636 = 0; i_636 < i_632; i_636++)
                    gs.clcars.add(rd, strings_631[i_636]);

                i = 5;
            } else
            {
                i = 3;
            }
        }
        return i;
    }

    public void loadiclancars(String string)
    {
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(string).append("/cars.txt").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_637 = url.openConnection().getContentType();
            if(string_637.equals("text/plain"))
            {
                gs.datat.removeAll();
                gs.datat.add(rd, "Select Car");
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_638 = "";
                for(int i = 0; (string_638 = datainputstream.readLine()) != null && i < 700; i++)
                    gs.datat.add(rd, string_638);

                datainputstream.close();
            } else
            {
                gs.datat.removeAll();
                gs.datat.add(rd, "No clan cars where found.");
            }
        }
        catch(Exception exception)
        {
            gs.datat.removeAll();
            gs.datat.add(rd, "Failed to load cars, try again later...");
        }
        gs.datat.select(0);
    }

    public int loadclanstages()
    {
        int i = 0;
        gs.clcars.removeAll();
        gs.clcars.add(rd, "Select Stage");
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(claname).append("/stages.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string = url.openConnection().getContentType();
            if(string.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_639 = "";
                int i_640 = 0;
                do
                {
                    if((string_639 = datainputstream.readLine()) == null || i_640 >= 700)
                        break;
                    gs.clcars.add(rd, string_639);
                    i_640++;
                    if(i != 1)
                        i = 1;
                } while(true);
                datainputstream.close();
            }
        }
        catch(Exception exception)
        {
            i = -2;
        }
        if(i == 1)
        {
            if(viewcar.equals(""))
            {
                gs.clcars.select(0);
            } else
            {
                gs.clcars.select(viewcar);
                viewcar = "";
            }
            selstage = gs.clcars.getSelectedItem();
        }
        return i;
    }

    public int loadaddstages()
    {
        int i = 3;
        int i_641 = 0;
        String strings[] = new String[700];
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/lists/").append(gs.tnick.getText()).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            String string = "";
            do
            {
                if((string = datainputstream.readLine()) == null)
                    break;
                string = (new StringBuilder()).append("").append(string.trim()).toString();
                if(string.startsWith("mystages"))
                {
                    boolean bool = true;
                    while(bool && i_641 < 700) 
                    {
                        strings[i_641] = getfuncSvalue("mystages", string, i_641);
                        if(strings[i_641].equals(""))
                            bool = false;
                        else
                            i_641++;
                    }
                }
            } while(true);
            datainputstream.close();
        }
        catch(Exception exception)
        {
            String string = (new StringBuilder()).append("").append(exception).toString();
            if(string.indexOf("FileNotFound") != -1)
            {
                i_641 = 0;
                i = 3;
            } else
            {
                i_641 = -1;
                i = 4;
            }
        }
        if(i_641 > 0)
        {
            String strings_642[] = new String[700];
            int i_643 = 0;
            for(int i_644 = 0; i_644 < i_641; i_644++)
            {
                perry = (new StringBuilder()).append("").append((int)(((float)i_644 / (float)i_641) * 100F)).append(" %").toString();
                try
                {
                    String string = (new StringBuilder()).append("http://multiplayer.needformadness.com/tracks/").append(strings[i_644]).append(".txt?reqlo=").append((int)(Math.random() * 1000D)).append("").toString();
                    string = string.replace(' ', '_');
                    URL url = new URL(string);
                    url.openConnection().setConnectTimeout(2000);
                    DataInputStream datainputstream = new DataInputStream(url.openStream());
                    String string_645 = "";
                    do
                    {
                        if((string_645 = datainputstream.readLine()) == null)
                            break;
                        string_645 = (new StringBuilder()).append("").append(string_645.trim()).toString();
                        if(string_645.startsWith("details"))
                        {
                            String string_646 = getfuncSvalue("details", string_645, 0);
                            if(string_646.toLowerCase().equals(gs.tnick.getText().toLowerCase()) && string_645.indexOf("Clan#") == -1)
                            {
                                strings_642[i_643] = strings[i_644];
                                i_643++;
                            }
                        }
                    } while(true);
                    datainputstream.close();
                }
                catch(Exception exception) { }
            }

            if(i_643 > 0)
            {
                gs.clcars.removeAll();
                for(int i_647 = 0; i_647 < i_643; i_647++)
                    gs.clcars.add(rd, strings_642[i_647]);

                i = 5;
            } else
            {
                i = 3;
            }
        }
        return i;
    }

    public void loadiclanstages(String string)
    {
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(string).append("/stages.txt").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_648 = url.openConnection().getContentType();
            if(string_648.equals("text/plain"))
            {
                gs.datat.removeAll();
                gs.datat.add(rd, "Select Stage");
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_649 = "";
                for(int i = 0; (string_649 = datainputstream.readLine()) != null && i < 700; i++)
                    gs.datat.add(rd, string_649);

                datainputstream.close();
            } else
            {
                gs.datat.removeAll();
                gs.datat.add(rd, "No clan stages where found.");
            }
        }
        catch(Exception exception)
        {
            gs.datat.removeAll();
            gs.datat.add(rd, "Failed to load stages, try again later...");
        }
        gs.datat.select(0);
    }

    public void loadproinfo()
    {
        if(!proname.equals(xt.nickname) && npf == -1)
            loadfriends();
        racing = 0;
        wasting = 0;
        themesong = "";
        trackvol = 0;
        sentance = "";
        proclan = "";
        try
        {
            String string = "";
            if(proname.equals(xt.nickname))
                string = (new StringBuilder()).append("?req=").append((int)(Math.random() * 1000D)).append("").toString();
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(proname).append("/info.txt").append(string).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_650 = url.openConnection().getContentType();
            if(string_650.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_651 = "";
                for(int i = 0; (string_651 = datainputstream.readLine()) != null && i < 9; i++)
                {
                    string_651 = string_651.trim();
                    if(i == 0)
                        themesong = string_651;
                    if(i == 1)
                    {
                        boolean bool = false;
                        int i_652;
                        try
                        {
                            i_652 = Integer.valueOf(string_651).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_652 = 0;
                        }
                        trackvol = i_652;
                    }
                    if(i == 2)
                    {
                        boolean bool = false;
                        int i_653;
                        try
                        {
                            i_653 = Integer.valueOf(string_651).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_653 = 0;
                        }
                        racing = i_653;
                    }
                    if(i == 3)
                    {
                        boolean bool = false;
                        int i_654;
                        try
                        {
                            i_654 = Integer.valueOf(string_651).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_654 = 0;
                        }
                        wasting = i_654;
                    }
                    if(i == 4)
                        proclan = string_651;
                    if(i == 8)
                        sentance = string_651;
                }

                datainputstream.close();
            }
        }
        catch(Exception exception)
        {
            sentance = "Failed to load profile info, server error!";
        }
    }

    public void loadfriends()
    {
        if(npf == -1)
        {
            freq = 0;
            try
            {
                URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/profiles/").append(xt.nickname).append("/friends.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
                url.openConnection().setConnectTimeout(2000);
                String string = url.openConnection().getContentType();
                if(string.equals("text/plain"))
                {
                    int i = 0;
                    DataInputStream datainputstream = new DataInputStream(url.openStream());
                    String string_655 = "";
                    for(int i_656 = 0; (string_655 = datainputstream.readLine()) != null && i_656 < 3; i_656++)
                    {
                        string_655 = string_655.trim();
                        if(i_656 == 0)
                        {
                            for(String string_657 = getSvalue(string_655, i); !string_657.equals("") && npf < 900; string_657 = getSvalue(string_655, i))
                            {
                                fname[i] = string_657;
                                i++;
                            }

                        }
                        if(i_656 == 1)
                        {
                            freqname = getSvalue(string_655, 0);
                            if(!freqname.equals(""))
                                freq = 1;
                        }
                        if(i_656 != 2 || freq == 1)
                            continue;
                        ncnf = 0;
                        for(String string_658 = getSvalue(string_655, ncnf); !string_658.equals("") && ncnf < 10; string_658 = getSvalue(string_655, ncnf))
                        {
                            cnfname[ncnf] = string_658;
                            ncnf++;
                        }

                        if(ncnf != 0)
                            freq = 6;
                    }

                    datainputstream.close();
                    npf = i;
                } else
                {
                    npf = 0;
                }
            }
            catch(Exception exception)
            {
                npf = -2;
            }
        }
    }

    public void loadnews()
    {
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/interact/news.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            String string = "";
            int i = 0;
            String string_659 = "";
            il = 0;
            for(; (string = datainputstream.readLine()) != null && i < 300; i++)
            {
                string = string.trim();
                if(i == 0)
                {
                    for(int i_660 = 0; i_660 < 4; i_660++)
                        newplayers[i_660] = getSvalue(string, i_660);

                }
                if(i >= 1 && i <= 5)
                {
                    nwtime[i - 1] = contime(getLvalue(string, 0));
                    nwarbs[i - 1] = getvalue(string, 1);
                    nwclan[i - 1] = getSvalue(string, 2);
                    nlclan[i - 1] = getSvalue(string, 3);
                    nwinob[i - 1] = getSvalue(string, 4);
                    nwinp[i - 1] = getvalue(string, 5);
                    nlosp[i - 1] = getvalue(string, 6);
                }
                if(i < 6 || il >= 300)
                    continue;
                nttime[il] = contime(getLvalue(string, 0));
                int i_661 = getvalue(string, 1);
                if(i_661 == 4)
                {
                    int i_662 = getvalue(string, 4);
                    if(i_662 <= 0)
                    {
                        text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has joined clan ").append(getSvalue(string, 3)).append(".").toString();
                    } else
                    {
                        int i_663 = getvalue(string, 5);
                        if(i_663 == i_662)
                        {
                            text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" got a new rank in clan ").append(getSvalue(string, 3)).append(".").toString();
                        } else
                        {
                            String string_664 = "promoted";
                            if(i_663 - i_662 < 0)
                                string_664 = "demoted";
                            if(i_663 != 7)
                                text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has been ").append(string_664).append(" in clan ").append(getSvalue(string, 3)).append(" to a level ").append(i_663).append(" member.").toString();
                            else
                                text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has been ").append(string_664).append(" in clan ").append(getSvalue(string, 3)).append(" to Clan Admin!").toString();
                        }
                    }
                    nln[il] = 2;
                    link[il][0][0] = getSvalue(string, 2);
                    link[il][0][1] = (new StringBuilder()).append("0|").append(getSvalue(string, 2)).append("|").toString();
                    link[il][1][0] = getSvalue(string, 3);
                    link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 3)).append("|").toString();
                    il++;
                }
                if(i_661 == 5)
                {
                    String string_665 = getSvalue(string, 2);
                    String string_666 = getSvalue(string, 4);
                    String string_667 = "left";
                    if(!string_665.toLowerCase().equals(string_666.toLowerCase()))
                        string_667 = "been removed from";
                    text[il] = (new StringBuilder()).append("").append(string_665).append(" has ").append(string_667).append(" clan ").append(getSvalue(string, 3)).append(".").toString();
                    nln[il] = 2;
                    link[il][0][0] = getSvalue(string, 2);
                    link[il][0][1] = (new StringBuilder()).append("0|").append(getSvalue(string, 2)).append("|").toString();
                    link[il][1][0] = getSvalue(string, 3);
                    link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 3)).append("|").toString();
                    il++;
                }
                if(i_661 == 6)
                {
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has updated clan ").append(getSvalue(string, 3)).append("'s web presence.").toString();
                    nln[il] = 3;
                    link[il][0][0] = getSvalue(string, 2);
                    link[il][0][1] = (new StringBuilder()).append("0|").append(getSvalue(string, 2)).append("|").toString();
                    link[il][1][0] = getSvalue(string, 3);
                    link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 3)).append("|").toString();
                    link[il][2][0] = "web presence";
                    link[il][2][1] = (new StringBuilder()).append("2|").append(getSvalue(string, 3)).append("|").toString();
                    il++;
                }
                if(i_661 == 7 && string_659.indexOf((new StringBuilder()).append("#").append(getSvalue(string, 4)).append("#").toString()) == -1)
                {
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has added car ").append(getSvalue(string, 4)).append(" to clan ").append(getSvalue(string, 3)).append(".").toString();
                    nln[il] = 3;
                    link[il][0][0] = getSvalue(string, 2);
                    link[il][0][1] = (new StringBuilder()).append("0|").append(getSvalue(string, 2)).append("|").toString();
                    link[il][1][0] = getSvalue(string, 3);
                    link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 3)).append("|").toString();
                    link[il][2][0] = getSvalue(string, 4);
                    link[il][2][1] = (new StringBuilder()).append("3|").append(getSvalue(string, 4)).append("|").append(getSvalue(string, 3)).append("|").toString();
                    string_659 = (new StringBuilder()).append(string_659).append("#").append(getSvalue(string, 4)).append("#").toString();
                    il++;
                }
                if(i_661 == 8 && string_659.indexOf((new StringBuilder()).append("#").append(getSvalue(string, 4)).append("#").toString()) == -1)
                {
                    String string_668 = getSvalue(string, 4);
                    if(string_668.length() > 20)
                        string_668 = (new StringBuilder()).append("").append(string_668.substring(0, 20)).append("...").toString();
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has added stage ").append(string_668).append(" to clan ").append(getSvalue(string, 3)).append(".").toString();
                    nln[il] = 3;
                    link[il][0][0] = getSvalue(string, 2);
                    link[il][0][1] = (new StringBuilder()).append("0|").append(getSvalue(string, 2)).append("|").toString();
                    link[il][1][0] = getSvalue(string, 3);
                    link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 3)).append("|").toString();
                    link[il][2][0] = string_668;
                    link[il][2][1] = (new StringBuilder()).append("4|").append(getSvalue(string, 4)).append("|").append(getSvalue(string, 3)).append("|").toString();
                    string_659 = (new StringBuilder()).append(string_659).append("#").append(getSvalue(string, 4)).append("#").toString();
                    il++;
                }
                if(i_661 == 9)
                {
                    String string_669 = getSvalue(string, 2);
                    if(string_669.startsWith("War"))
                    {
                        text[il] = (new StringBuilder()).append("Clans ").append(getSvalue(string, 7)).append(" & ").append(getSvalue(string, 8)).append(" have now started a war!").toString();
                        nln[il] = 2;
                        link[il][0][0] = getSvalue(string, 7);
                        link[il][0][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 7)).append("|").toString();
                        link[il][1][0] = getSvalue(string, 8);
                        link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 8)).append("|").toString();
                        il++;
                    }
                    if(string_669.startsWith("Car"))
                    {
                        text[il] = (new StringBuilder()).append("Clans ").append(getSvalue(string, 7)).append(" & ").append(getSvalue(string, 8)).append(" have started a car battle!").toString();
                        nln[il] = 2;
                        link[il][0][0] = getSvalue(string, 7);
                        link[il][0][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 7)).append("|").toString();
                        link[il][1][0] = getSvalue(string, 8);
                        link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 8)).append("|").toString();
                        il++;
                        if(il < 300)
                        {
                            text[il] = (new StringBuilder()).append("Battle over cars: [").append(getSvalue(string, 4)).append("] & [").append(getSvalue(string, 5)).append("]").toString();
                            nln[il] = 2;
                            link[il][0][0] = getSvalue(string, 4);
                            link[il][0][1] = (new StringBuilder()).append("3|").append(getSvalue(string, 4)).append("|").append(getSvalue(string, 8)).append("|").toString();
                            link[il][1][0] = getSvalue(string, 5);
                            link[il][1][1] = (new StringBuilder()).append("3|").append(getSvalue(string, 5)).append("|").append(getSvalue(string, 7)).append("|").toString();
                            nttime[il] = "";
                            il++;
                        }
                    }
                    if(string_669.startsWith("Stage"))
                    {
                        String string_670 = getSvalue(string, 4);
                        if(string_670.length() > 20)
                            string_670 = (new StringBuilder()).append("").append(string_670.substring(0, 20)).append("...").toString();
                        String string_671 = getSvalue(string, 5);
                        if(string_671.length() > 20)
                            string_671 = (new StringBuilder()).append("").append(string_671.substring(0, 20)).append("...").toString();
                        text[il] = (new StringBuilder()).append("Clans ").append(getSvalue(string, 7)).append(" & ").append(getSvalue(string, 8)).append(" have started a stage battle!").toString();
                        nln[il] = 2;
                        link[il][0][0] = getSvalue(string, 7);
                        link[il][0][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 7)).append("|").toString();
                        link[il][1][0] = getSvalue(string, 8);
                        link[il][1][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 8)).append("|").toString();
                        il++;
                        if(il < 300)
                        {
                            text[il] = (new StringBuilder()).append("Battle over stages: [").append(string_670).append("] & [").append(string_671).append("]").toString();
                            nln[il] = 2;
                            link[il][0][0] = string_670;
                            link[il][0][1] = (new StringBuilder()).append("4|").append(getSvalue(string, 4)).append("|").append(getSvalue(string, 8)).append("|").toString();
                            link[il][1][0] = string_671;
                            link[il][1][1] = (new StringBuilder()).append("4|").append(getSvalue(string, 5)).append("|").append(getSvalue(string, 7)).append("|").toString();
                            nttime[il] = "";
                            il++;
                        }
                    }
                }
                if(i_661 != 10 && i_661 != 11 && i_661 != 12 && i_661 != 13)
                    continue;
                if(i_661 == 11)
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has re-claimed its title as clan wars world champion!").toString();
                else
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has now become the new clan wars world champion!").toString();
                nln[il] = 2;
                link[il][0][0] = getSvalue(string, 2);
                link[il][0][1] = (new StringBuilder()).append("1|").append(getSvalue(string, 2)).append("|").toString();
                link[il][1][0] = "clan wars world champion";
                link[il][1][1] = "5|championship|";
                if(getSvalue(string, 2).equals(""))
                {
                    text[il] = "No one is currently the clan wars world champion!";
                    nln[il] = 1;
                    link[il][0][0] = "clan wars world champion";
                    link[il][0][1] = "5|championship|";
                }
                il++;
                if(i_661 == 10)
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" recent win against ").append(getSvalue(string, 4)).append(" has given it the championship title!").toString();
                if(i_661 == 11)
                    text[il] = (new StringBuilder()).append("").append(getSvalue(string, 2)).append(" has successfully defended its championship title against ").append(getSvalue(string, 4)).append("!").toString();
                if(i_661 == 12)
                    text[il] = (new StringBuilder()).append("A recent war between ").append(getSvalue(string, 3)).append(" and ").append(getSvalue(string, 4)).append(" has resulted in a change of points!").toString();
                if(i_661 == 13)
                    text[il] = (new StringBuilder()).append("Clan ").append(getSvalue(string, 3)).append(" removed itself from the game which resulted in a change of points!").toString();
                nttime[il] = "";
                nln[il] = 0;
                il++;
            }

            datainputstream.close();
            spos6 = 0;
            loadednews = 1;
        }
        catch(Exception exception)
        {
            loadednews = -1;
        }
    }

    public void loadchamps()
    {
        eng = -1;
        engo = 0;
        if(maxclans <= 0)
            maxclans = 1000;
        ncc = 0;
        champ = -1;
        int i = 0;
        conclan = new String[maxclans];
        totp = new int[maxclans];
        nvc = new int[maxclans];
        points = new int[maxclans][maxclans];
        verclan = new String[maxclans][maxclans];
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/interact/clanstat.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            DataInputStream datainputstream = new DataInputStream(url.openStream());
            String string = "";
            do
            {
                if((string = datainputstream.readLine()) == null || ncc >= maxclans)
                    break;
                conclan[ncc] = getSvalue(string, 0);
                if(!conclan[ncc].equals(""))
                {
                    totp[ncc] = 0;
                    nvc[ncc] = 0;
                    for(int i_672 = getpvalue(string, 1); i_672 != 0 && nvc[ncc] < maxclans; i_672 = getpvalue(string, 1 + nvc[ncc] * 2))
                    {
                        totp[ncc] += i_672;
                        points[ncc][nvc[ncc]] = i_672;
                        verclan[ncc][nvc[ncc]] = getSvalue(string, 2 + nvc[ncc] * 2);
                        nvc[ncc]++;
                    }

                    if(totp[ncc] >= i && totp[ncc] >= 3)
                        if(totp[ncc] == i)
                        {
                            champ = -2;
                        } else
                        {
                            i = totp[ncc];
                            champ = ncc;
                        }
                    ncc++;
                }
            } while(true);
            datainputstream.close();
            ord = new int[ncc];
            int is[] = new int[ncc];
            leadsby = i;
            for(int i_673 = 0; i_673 < ncc; i_673++)
            {
                if(i_673 != champ && i - totp[i_673] < leadsby)
                    leadsby = i - totp[i_673];
                is[i_673] = 0;
            }

            for(int i_674 = 0; i_674 < ncc; i_674++)
            {
                for(int i_675 = i_674 + 1; i_675 < ncc; i_675++)
                    if(totp[i_674] < totp[i_675])
                        is[i_674]++;
                    else
                        is[i_675]++;

                ord[is[i_674]] = i_674;
            }

            spos6 = 0;
            loadwstat = 1;
        }
        catch(Exception exception)
        {
            String string = (new StringBuilder()).append("").append(exception).toString();
            if(string.indexOf("java.io.FileNotFoundException") != -1)
                loadwstat = 1;
            else
                loadwstat = -1;
        }
    }

    public String contime(long l)
    {
        String string = "";
        if(l != -1L)
            try
            {
                long l_676 = ntime - l;
                if(l_676 >= 1000L && l_676 < 60000L)
                    string = "seconds ago";
                if(l_676 >= 60000L && l_676 < 0x36ee80L)
                {
                    int i = (int)(l_676 / 60000L);
                    String string_677 = "s";
                    if(i == 1)
                        string_677 = "";
                    string = (new StringBuilder()).append("").append(i).append(" minute").append(string_677).append(" ago").toString();
                }
                if(l_676 >= 0x36ee80L && l_676 < 0x5265c00L)
                {
                    int i = (int)(l_676 / 0x36ee80L);
                    String string_678 = "s";
                    if(i == 1)
                        string_678 = "";
                    string = (new StringBuilder()).append("").append(i).append(" hour").append(string_678).append(" ago").toString();
                }
                if(l_676 >= 0x5265c00L)
                {
                    int i = (int)(l_676 / 0x5265c00L);
                    String string_679 = "s";
                    if(i == 1)
                        string_679 = "";
                    string = (new StringBuilder()).append("").append(i).append(" day").append(string_679).append(" ago").toString();
                }
            }
            catch(Exception exception)
            {
                string = "";
            }
        return string;
    }

    public void tlink(Graphics2D graphics2d, int i, int i_680, String string, String string_681, int i_682, int i_683, 
            boolean bool, int i_684, int i_685, int i_686, String string_687, String string_688)
    {
        ftm = rdo.getFontMetrics();
        int i_689 = 0;
        int i_690 = 0;
        int i_691 = string.indexOf(string_681);
        if(i_691 != -1)
        {
            i_689 = ftm.stringWidth(string.substring(0, i_691)) + i;
            i_690 = (i_689 + ftm.stringWidth(string_681)) - 2;
        }
        rdo.drawLine(i_689, i_680 + 1, i_690, i_680 + 1);
        if(i_682 > i_689 + i_684 && i_682 < i_690 + i_684 && i_683 > (i_680 - 11) + i_685 && i_683 < i_680 + 1 + i_685)
        {
            cur = 12;
            if(bool)
            {
                if(i_686 == 0)
                {
                    tab = 1;
                    if(!proname.equals(string_687))
                    {
                        proname = string_687;
                        loadedp = false;
                        onexitpro();
                    }
                }
                if(i_686 == 1)
                {
                    if(!claname.equals(string_687))
                    {
                        claname = string_687;
                        loadedc = false;
                    }
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    ctab = 0;
                    tab = 3;
                }
                if(i_686 == 2)
                {
                    if(!claname.equals(string_687))
                    {
                        claname = string_687;
                        loadedc = false;
                    }
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    loadedlink = false;
                    ctab = 4;
                    tab = 3;
                }
                if(i_686 == 3)
                {
                    viewcar = string_687;
                    if(!claname.equals(string_688))
                    {
                        claname = string_688;
                        loadedc = false;
                    }
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    loadedcars = -1;
                    loadedcar = 0;
                    ctab = 2;
                    tab = 3;
                }
                if(i_686 == 4)
                {
                    viewcar = string_687;
                    if(!claname.equals(string_688))
                    {
                        claname = string_688;
                        loadedc = false;
                    }
                    spos5 = 0;
                    lspos5 = 0;
                    cfase = 3;
                    loadedstages = -1;
                    loadedstage = 0;
                    ctab = 3;
                    tab = 3;
                }
                if(i_686 == 5)
                {
                    loadwstat = 0;
                    ntab = 1;
                }
            }
        }
    }

    public void loadwarb()
    {
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/clans/").append(xt.clan).append("/inter.txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string = url.openConnection().getContentType();
            gs.warb.removeAll();
            gs.warb.add(rd, " Select  War / Battle");
            if(string.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_692 = "";
                int i = 0;
                boolean bool = false;
                for(; (string_692 = datainputstream.readLine()) != null && i < 100; i++)
                {
                    string_692 = string_692.trim();
                    String string_693 = getSvalue(string_692, 5);
                    if(string_693.equals("War"))
                    {
                        gs.warb.addw((new StringBuilder()).append(" War with ").append(getSvalue(string_692, 0)).append("").toString(), (new StringBuilder()).append("").append(getSvalue(string_692, 6)).append("|").append(getSvalue(string_692, 0)).append("|").toString());
                        bool = true;
                    }
                    if(string_693.equals("Car Battle"))
                    {
                        gs.warb.addw((new StringBuilder()).append(" Car battle with ").append(getSvalue(string_692, 0)).append("").toString(), (new StringBuilder()).append("").append(getSvalue(string_692, 6)).append("|").append(getSvalue(string_692, 0)).append("|").toString());
                        bool = true;
                    }
                    if(string_693.equals("Stage Battle"))
                    {
                        gs.warb.addw((new StringBuilder()).append(" Stage battle with ").append(getSvalue(string_692, 0)).append("").toString(), (new StringBuilder()).append("").append(getSvalue(string_692, 6)).append("|").append(getSvalue(string_692, 0)).append("|").toString());
                        bool = true;
                    }
                }

                datainputstream.close();
                if(!bool)
                {
                    gs.warb.removeAll();
                    gs.warb.add(rd, "Your clan has not started any new wars or battles.");
                }
            } else
            {
                gs.warb.removeAll();
                gs.warb.add(rd, "Your clan has not started any wars or battles yet.");
            }
        }
        catch(Exception exception)
        {
            gs.warb.removeAll();
            gs.warb.add(rd, "Error occurred while loading, please try again later.");
        }
        gs.warb.select(0);
    }

    public void loadwgames()
    {
        canredo = false;
        gameturn = -1;
        lwbwinner = "";
        ascore = 0;
        vscore = 0;
        gs.pgame.removeAll();
        gs.pgame.add(rd, " Select Game");
        int i = 5;
        String string = "battle";
        warb = 2;
        if(gs.warb.sopts[gs.warb.sel].startsWith(" War with"))
        {
            i = 9;
            string = "war";
            warb = 1;
        }
        if(gs.warb.sopts[gs.warb.sel].startsWith(" Stage battle with"))
            warb = 3;
        warbnum = getSvalue(gs.warb.opts[gs.warb.sel], 0);
        vclan = getSvalue(gs.warb.opts[gs.warb.sel], 1);
        try
        {
            URL url = new URL((new StringBuilder()).append("http://multiplayer.needformadness.com/interact/").append(string).append("/").append(warbnum).append(".txt?req=").append((int)(Math.random() * 1000D)).append("").toString());
            url.openConnection().setConnectTimeout(2000);
            String string_694 = url.openConnection().getContentType();
            if(string_694.equals("text/plain"))
            {
                DataInputStream datainputstream = new DataInputStream(url.openStream());
                String string_695 = "";
                int i_696;
                for(i_696 = 0; (string_695 = datainputstream.readLine()) != null && i_696 < i; i_696++)
                {
                    String string_697 = getSvalue(string_695, 0);
                    if(string_697.startsWith("#"))
                    {
                        boolean bool = true;
                        int i_698;
                        try
                        {
                            i_698 = Integer.valueOf(string_697.substring(1)).intValue();
                        }
                        catch(Exception exception)
                        {
                            i_698 = 1;
                        }
                        wbstage[i_696] = i_698;
                        string_697 = (new StringBuilder()).append("NFM 1 - Stage ").append(i_698).append("").toString();
                        if(i_698 > 10)
                            string_697 = (new StringBuilder()).append("NFM 2 - Stage ").append(i_698 - 10).append("").toString();
                        if(i_698 > 27)
                            string_697 = (new StringBuilder()).append("NFM Multiplayer - Stage ").append(i_698 - 27).append("").toString();
                    } else
                    {
                        wbstage[i_696] = 101;
                    }
                    wbstages[i_696] = string_697;
                    wblaps[i_696] = getvalue(string_695, 1);
                    wbcars[i_696] = getvalue(string_695, 2);
                    wbclass[i_696] = getvalue(string_695, 3);
                    wbfix[i_696] = getvalue(string_695, 4);
                    String string_699 = getSvalue(string_695, 5);
                    String string_700 = "";
                    if(wbcars[i_696] == 2)
                        string_700 = ",  Clan Cars";
                    if(wbcars[i_696] == 3)
                        string_700 = ",  Game Cars";
                    if(wbclass[i_696] == 1)
                        string_700 = (new StringBuilder()).append(string_700).append(",  Class C").toString();
                    if(wbclass[i_696] == 2)
                        string_700 = (new StringBuilder()).append(string_700).append(",  Class B & C").toString();
                    if(wbclass[i_696] == 3)
                        string_700 = (new StringBuilder()).append(string_700).append(",  Class B").toString();
                    if(wbclass[i_696] == 4)
                        string_700 = (new StringBuilder()).append(string_700).append(",  Class A & B").toString();
                    if(wbclass[i_696] == 5)
                        string_700 = (new StringBuilder()).append(string_700).append(",  Class A").toString();
                    String string_701 = "";
                    if(wbfix[i_696] == 1)
                        string_701 = ",  4 Fixes";
                    if(wbfix[i_696] == 2)
                        string_701 = ",  3 Fixes";
                    if(wbfix[i_696] == 3)
                        string_701 = ",  2 Fixes";
                    if(wbfix[i_696] == 4)
                        string_701 = ",  1 Fix";
                    if(wbfix[i_696] == 5)
                        string_701 = ",  No Fixing";
                    rd.setFont(new Font("Arial", 1, 12));
                    ftm = rd.getFontMetrics();
                    String string_702 = wbstages[i_696];
                    String string_703;
                    for(string_703 = (new StringBuilder()).append("Game #").append(i_696 + 1).append(":  ").append(string_702).append("").append(string_700).append("").append(string_701).append(",  ").append(wblaps[i_696]).append(" Laps").toString(); ftm.stringWidth(string_703) > 400; string_703 = (new StringBuilder()).append("Game #").append(i_696 + 1).append(":  ").append(string_702).append("...").append(string_700).append("").append(string_701).append(",  ").append(wblaps[i_696]).append(" Laps").toString())
                        string_702 = string_702.substring(0, string_702.length() - 1);

                    if(gameturn == -1)
                        if(string_699.equals("") || string_699.equals("#redo#"))
                        {
                            if(!string_699.equals("#redo#") && i_696 > 0)
                                canredo = true;
                            gameturn = i_696;
                            gameturndisp = string_703;
                        } else
                        {
                            if(string_699.toLowerCase().equals(xt.clan.toLowerCase()))
                                ascore++;
                            if(string_699.toLowerCase().equals(vclan.toLowerCase()))
                                vscore++;
                            lwbwinner = string_699;
                        }
                    gs.pgame.add(rd, (new StringBuilder()).append(" ").append(string_703).append("").toString());
                }

                datainputstream.close();
                if(i_696 != 0)
                    loadwbgames = 2;
                else
                    loadwbgames = 3;
            } else
            {
                loadwbgames = 4;
            }
        }
        catch(Exception exception)
        {
            loadwbgames = 3;
        }
    }

    public void redogame()
    {
        try
        {
            socket = new Socket(lg.servers[0], 7061);
            din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
            dout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "ISO-8859-1"), true);
            String string = (new StringBuilder()).append("101|43|").append(warb).append("|").append(warbnum).append("|").toString();
            dout.println(string);
            String string_704 = din.readLine();
            if(!string_704.equals("OK"))
                loadwbgames = 6;
            socket.close();
            socket = null;
            din.close();
            din = null;
            dout.close();
            dout = null;
        }
        catch(Exception exception)
        {
            loadwbgames = 6;
        }
        if(loadwbgames != 6)
            loadwgames();
    }

    public boolean drawbutton(Image image, int i, int i_705, int i_706, int i_707, boolean bool)
    {
        boolean bool_708 = false;
        boolean bool_709 = false;
        int i_710 = image.getWidth(ob);
        if(Math.abs(i_706 - i) < i_710 / 2 + 12 && Math.abs(i_707 - i_705) < 14 && bool)
            bool_709 = true;
        if(Math.abs(i_706 - i) < i_710 / 2 + 12 && Math.abs(i_707 - i_705) < 14 && gs.mouses <= -1)
        {
            bool_708 = true;
            gs.mouses = 0;
        }
        if(!bool_709)
        {
            rd.drawImage(image, i - i_710 / 2, i_705 - image.getHeight(ob) / 2, null);
            rd.drawImage(xt.bols, i - i_710 / 2 - 15, i_705 - 13, null);
            rd.drawImage(xt.bors, i + i_710 / 2 + 9, i_705 - 13, null);
            rd.drawImage(xt.bot, i - i_710 / 2 - 9, i_705 - 13, i_710 + 18, 3, null);
            rd.drawImage(xt.bob, i - i_710 / 2 - 9, i_705 + 10, i_710 + 18, 3, null);
        } else
        {
            rd.drawImage(image, (i - i_710 / 2) + 1, (i_705 - image.getHeight(ob) / 2) + 1, null);
            rd.drawImage(xt.bolps, i - i_710 / 2 - 15, i_705 - 13, null);
            rd.drawImage(xt.borps, i + i_710 / 2 + 9, i_705 - 13, null);
            rd.drawImage(xt.bob, i - i_710 / 2 - 9, i_705 - 13, i_710 + 18, 3, null);
            rd.drawImage(xt.bot, i - i_710 / 2 - 9, i_705 + 10, i_710 + 18, 3, null);
        }
        return bool_708;
    }

    public boolean stringbutton(Graphics2D graphics2d, String string, int i, int i_711, int i_712, int i_713, int i_714, 
            boolean bool, int i_715, int i_716)
    {
        boolean bool_717 = false;
        boolean bool_718 = false;
        graphics2d.setFont(new Font("Arial", 1, 12));
        ftm = graphics2d.getFontMetrics();
        if(i_712 == 6)
        {
            graphics2d.setFont(new Font("Arial", 1, 11));
            ftm = graphics2d.getFontMetrics();
        }
        int i_719 = ftm.stringWidth(string);
        if(Math.abs(i_713 - i_715 - i) < i_719 / 2 + 12 && Math.abs(i_714 - i_716 - i_711) < 14 && bool)
            bool_718 = true;
        if(Math.abs(i_713 - i_715 - i) < i_719 / 2 + 12 && Math.abs(i_714 - i_716 - i_711) < 14 && gs.mouses <= -1 && blocknote == 0 && blockb == 0 && !gs.openm && (editc == 0 || i_715 == 0))
        {
            bool_717 = true;
            gs.mouses = 0;
        }
        if(blocknote != 0)
            blocknote--;
        boolean bool_720 = false;
        if(i_712 < 0)
        {
            i_712 *= -1;
            bool_720 = true;
        }
        if(bool_720)
            rdo.setComposite(AlphaComposite.getInstance(3, 0.7F));
        if(!bool_718)
        {
            graphics2d.setColor(colorb2k(bool_720, 220, 220, 220));
            graphics2d.fillRect(i - i_719 / 2 - 10, i_711 - (17 - i_712), i_719 + 20, 25 - i_712 * 2);
            graphics2d.setColor(colorb2k(bool_720, 240, 240, 240));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (17 - i_712), i + i_719 / 2 + 10, i_711 - (17 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (18 - i_712), i + i_719 / 2 + 10, i_711 - (18 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 9, i_711 - (19 - i_712), i + i_719 / 2 + 9, i_711 - (19 - i_712));
            graphics2d.setColor(colorb2k(bool_720, 200, 200, 200));
            graphics2d.drawLine(i + i_719 / 2 + 10, i_711 - (17 - i_712), i + i_719 / 2 + 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i + i_719 / 2 + 11, i_711 - (17 - i_712), i + i_719 / 2 + 11, i_711 + (7 - i_712));
            graphics2d.drawLine(i + i_719 / 2 + 12, i_711 - (16 - i_712), i + i_719 / 2 + 12, i_711 + (6 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 + (7 - i_712), i + i_719 / 2 + 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 + (8 - i_712), i + i_719 / 2 + 10, i_711 + (8 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 9, i_711 + (9 - i_712), i + i_719 / 2 + 9, i_711 + (9 - i_712));
            graphics2d.setColor(colorb2k(bool_720, 240, 240, 240));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (17 - i_712), i - i_719 / 2 - 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 11, i_711 - (17 - i_712), i - i_719 / 2 - 11, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 12, i_711 - (16 - i_712), i - i_719 / 2 - 12, i_711 + (6 - i_712));
            if(bool_720)
                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
            graphics2d.setColor(new Color(0, 0, 0));
            graphics2d.drawString(string, i - i_719 / 2, i_711);
        } else
        {
            graphics2d.setColor(colorb2k(bool_720, 210, 210, 210));
            graphics2d.fillRect(i - i_719 / 2 - 10, i_711 - (17 - i_712), i_719 + 20, 25 - i_712 * 2);
            graphics2d.setColor(colorb2k(bool_720, 200, 200, 200));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (17 - i_712), i + i_719 / 2 + 10, i_711 - (17 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (18 - i_712), i + i_719 / 2 + 10, i_711 - (18 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 9, i_711 - (19 - i_712), i + i_719 / 2 + 9, i_711 - (19 - i_712));
            graphics2d.drawLine(i + i_719 / 2 + 10, i_711 - (17 - i_712), i + i_719 / 2 + 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i + i_719 / 2 + 11, i_711 - (17 - i_712), i + i_719 / 2 + 11, i_711 + (7 - i_712));
            graphics2d.drawLine(i + i_719 / 2 + 12, i_711 - (16 - i_712), i + i_719 / 2 + 12, i_711 + (6 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 + (7 - i_712), i + i_719 / 2 + 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 + (8 - i_712), i + i_719 / 2 + 10, i_711 + (8 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 9, i_711 + (9 - i_712), i + i_719 / 2 + 9, i_711 + (9 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 10, i_711 - (17 - i_712), i - i_719 / 2 - 10, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 11, i_711 - (17 - i_712), i - i_719 / 2 - 11, i_711 + (7 - i_712));
            graphics2d.drawLine(i - i_719 / 2 - 12, i_711 - (16 - i_712), i - i_719 / 2 - 12, i_711 + (6 - i_712));
            if(bool_720)
                rdo.setComposite(AlphaComposite.getInstance(3, 1.0F));
            graphics2d.setColor(new Color(0, 0, 0));
            graphics2d.drawString(string, (i - i_719 / 2) + 1, i_711);
        }
        return bool_717;
    }

    public Color color2k(int i, int i_721, int i_722)
    {
        Color color = new Color(i, i_721, i_722);
        float fs[] = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
        fs[0] = 0.13F;
        fs[1] = 0.35F;
        return Color.getHSBColor(fs[0], fs[1], fs[2]);
    }

    public Color colorb2k(boolean bool, int i, int i_723, int i_724)
    {
        Color color = new Color(i, i_723, i_724);
        if(!bool)
        {
            float fs[] = new float[3];
            Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), fs);
            fs[0] = 0.13F;
            fs[1] = 0.35F;
            if(darker)
                fs[2] *= 0.9F;
            color = Color.getHSBColor(fs[0], fs[1], fs[2]);
        } else
        {
            color = new Color((int)((float)i * 0.9F), (int)((float)i_723 * 0.9F), (int)((float)i_724 * 0.9F));
        }
        return color;
    }

    public int getvalue(String string, int i)
    {
        int i_725 = -1;
        try
        {
            int i_726 = 0;
            int i_727 = 0;
            int i_728 = 0;
            String string_729 = "";
            String string_730 = "";
            for(; i_726 < string.length() && i_728 != 2; i_726++)
            {
                string_729 = (new StringBuilder()).append("").append(string.charAt(i_726)).toString();
                if(string_729.equals("|"))
                {
                    i_727++;
                    if(i_728 == 1 || i_727 > i)
                        i_728 = 2;
                    continue;
                }
                if(i_727 == i)
                {
                    string_730 = (new StringBuilder()).append(string_730).append(string_729).toString();
                    i_728 = 1;
                }
            }

            if(string_730.equals(""))
                string_730 = "-1";
            i_725 = Integer.valueOf(string_730).intValue();
        }
        catch(Exception exception) { }
        return i_725;
    }

    public String getSvalue(String string, int i)
    {
        String string_731 = "";
        try
        {
            int i_732 = 0;
            int i_733 = 0;
            int i_734 = 0;
            String string_735 = "";
            String string_736 = "";
            for(; i_732 < string.length() && i_734 != 2; i_732++)
            {
                string_735 = (new StringBuilder()).append("").append(string.charAt(i_732)).toString();
                if(string_735.equals("|"))
                {
                    i_733++;
                    if(i_734 == 1 || i_733 > i)
                        i_734 = 2;
                    continue;
                }
                if(i_733 == i)
                {
                    string_736 = (new StringBuilder()).append(string_736).append(string_735).toString();
                    i_734 = 1;
                }
            }

            string_731 = string_736;
        }
        catch(Exception exception) { }
        return string_731;
    }

    public long getLvalue(String string, int i)
    {
        long l = -1L;
        try
        {
            int i_737 = 0;
            int i_738 = 0;
            int i_739 = 0;
            String string_740 = "";
            String string_741 = "";
            for(; i_737 < string.length() && i_739 != 2; i_737++)
            {
                string_740 = (new StringBuilder()).append("").append(string.charAt(i_737)).toString();
                if(string_740.equals("|"))
                {
                    i_738++;
                    if(i_739 == 1 || i_738 > i)
                        i_739 = 2;
                    continue;
                }
                if(i_738 == i)
                {
                    string_741 = (new StringBuilder()).append(string_741).append(string_740).toString();
                    i_739 = 1;
                }
            }

            if(string_741.equals(""))
                string_741 = "-1";
            l = Long.valueOf(string_741).longValue();
        }
        catch(Exception exception) { }
        return l;
    }

    public int getpvalue(String string, int i)
    {
        int i_742 = 0;
        try
        {
            int i_743 = 0;
            int i_744 = 0;
            int i_745 = 0;
            String string_746 = "";
            String string_747 = "";
            for(; i_743 < string.length() && i_745 != 2; i_743++)
            {
                string_746 = (new StringBuilder()).append("").append(string.charAt(i_743)).toString();
                if(string_746.equals("|"))
                {
                    i_744++;
                    if(i_745 == 1 || i_744 > i)
                        i_745 = 2;
                    continue;
                }
                if(i_744 == i)
                {
                    string_747 = (new StringBuilder()).append(string_747).append(string_746).toString();
                    i_745 = 1;
                }
            }

            if(string_747.equals(""))
                string_747 = "0";
            i_742 = Integer.valueOf(string_747).intValue();
        }
        catch(Exception exception) { }
        return i_742;
    }

    public int getfuncvalue(String string, String string_748, int i)
    {
        int i_749 = 0;
        String string_750 = "";
        for(int i_751 = string.length() + 1; i_751 < string_748.length(); i_751++)
        {
            String string_752 = (new StringBuilder()).append("").append(string_748.charAt(i_751)).toString();
            if(string_752.equals(",") || string_752.equals(")"))
            {
                i_749++;
                i_751++;
            }
            if(i_749 == i)
                string_750 = (new StringBuilder()).append(string_750).append(string_748.charAt(i_751)).toString();
        }

        return Float.valueOf(string_750).intValue();
    }

    public String getfuncSvalue(String string, String string_753, int i)
    {
        String string_754 = "";
        int i_755 = 0;
        for(int i_756 = string.length() + 1; i_756 < string_753.length() && i_755 <= i; i_756++)
        {
            String string_757 = (new StringBuilder()).append("").append(string_753.charAt(i_756)).toString();
            if(string_757.equals(",") || string_757.equals(")"))
            {
                i_755++;
                continue;
            }
            if(i_755 == i)
                string_754 = (new StringBuilder()).append(string_754).append(string_757).toString();
        }

        return string_754;
    }

    MediaTracker mt;
    Graphics2D rd;
    xtGraphics xt;
    FontMetrics ftm;
    ImageObserver ob;
    GameSparker gs;
    Login lg;
    CarDefine cd;
    Medium m;
    Graphics2D rdo;
    Image gImage;
    Thread connector;
    boolean domon;
    Socket socket;
    BufferedReader din;
    PrintWriter dout;
    int fase;
    int open;
    boolean upo;
    int tab;
    boolean onp;
    int ptab;
    int spos;
    int lspos;
    int mscro;
    int spos2;
    int lspos2;
    int mscro2;
    int spos3;
    int lspos3;
    int mscro3;
    int spos4;
    int lspos4;
    int mscro4;
    int spos5;
    int lspos5;
    int mscro5;
    int overit;
    int flk;
    int flko;
    boolean flg;
    int curs;
    int waitlink;
    int addstage;
    boolean darker;
    int npo;
    String pname[];
    int proom[];
    int pserver[];
    int roomf[][];
    int npf;
    String fname[];
    String cnfname[];
    int ncnf;
    int freq;
    int sfreq;
    String freqname;
    String sfreqname;
    int cntf;
    String cnames[];
    String sentn[];
    String ctime[];
    long nctime[];
    int updatec;
    String proname;
    boolean loadedp;
    int edit;
    int upload;
    int perc;
    int playt;
    int uploadt;
    String filename;
    String msg;
    String trackname;
    boolean refresh;
    boolean logol;
    boolean avatarl;
    int sentchange;
    boolean badlang;
    String aboutxt[];
    int nab;
    Image clanlogo;
    Image avatar;
    int racing;
    int wasting;
    String themesong;
    String sentance;
    int trackvol;
    int comesoon;
    String proclan;
    int nlg;
    String logos[];
    boolean logon[];
    Image logoi[];
    int loadmsgs;
    String hasmsgs;
    String lastsub;
    int nm;
    String mname[];
    String mconvo[];
    String msub[];
    int mtyp[];
    String mtime[];
    long mctime[];
    int openc;
    int opy;
    int addopy;
    int oph;
    int itemsel;
    int loaditem;
    String mline[];
    int mlinetyp[];
    long mctimes[];
    String mtimes[];
    int nml;
    int readmsg;
    String opname;
    String blockname;
    String unblockname;
    int sendmsg;
    String wday[] = {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };
    String month[] = {
        "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", 
        "November", "December"
    };
    int itab;
    int litab;
    int cadmin;
    String cmline[];
    int cmlinetyp[];
    long cmctimes[];
    String cmtimes[];
    int cnml;
    int readclan;
    int sendcmsg;
    int loadinter;
    int ni;
    String iclan[];
    String iconvo[];
    String isub[];
    String icheck[];
    String itime[];
    long ictime[];
    String istat[];
    String itcar[];
    String igcar[];
    String iwarn[];
    int openi;
    int readint;
    String intclan;
    String lastint;
    int dispi;
    String dwarn;
    String dtcar;
    String dgcar;
    int nil;
    String iline[];
    int ilinetyp[];
    long ictimes[];
    String itimes[];
    int intsel;
    int isel;
    int ifas;
    int leader;
    int sendint;
    boolean inishsel;
    boolean redif;
    String imsg;
    int wag;
    int iflk;
    String itake;
    String igive;
    String viewcar;
    String warnum;
    boolean sendwarnum;
    String wstages[];
    int wlaps[];
    int wcars[];
    int wclass[];
    int wfix[];
    int nvgames1;
    int nvgames2;
    int viewgame1;
    int viewgame2;
    String viewwar1;
    String viewwar2;
    String xclan;
    String sendwar;
    boolean ichlng;
    String vwstages1[];
    int vwlaps1[];
    int vwcars1[];
    int vwclass1[];
    int vwfix1[];
    String vwstages2[];
    int vwlaps2[];
    int vwcars2[];
    int vwclass2[];
    int vwfix2[];
    String vwinner[];
    int vwscorex;
    int vwscorei;
    Image intclanbg;
    String intclanlo;
    boolean intclanbgloaded;
    Image myclanbg;
    int loadedmyclanbg;
    int cfase;
    boolean notclan;
    String claname;
    boolean loadedc;
    boolean clanbgl;
    Image clanbg;
    int editc;
    int em;
    int ctab;
    int nmb;
    String lccnam;
    String member[];
    int mlevel[];
    String mrank[];
    int nrmb;
    String rmember[];
    boolean showreqs;
    int blocknote;
    int blockb;
    boolean loadedcm;
    int ncln;
    String clname[];
    String smsg;
    String sltit;
    boolean attachetoclan;
    boolean loadedlink;
    int loadedcars;
    int loadedcar;
    String ltit;
    String ldes;
    String lurl;
    boolean forcsel;
    String selcar;
    String selstage;
    String perry;
    int mrot;
    int loadedstages;
    int loadedstage;
    CheckPoints cp;
    ContO bco[];
    ContO co[];
    int mouson;
    int nclns;
    String clanlo[];
    int ntab;
    int loadednews;
    int spos6;
    int lspos6;
    String newplayers[] = {
        "", "", "", "", ""
    };
    int nwarbs[] = {
        -1, -1, -1, -1, -1
    };
    String nwclan[];
    String nlclan[];
    String nwinob[];
    int nwinp[];
    int nlosp[];
    String nwtime[];
    int il;
    String nttime[];
    String text[];
    int nln[];
    String link[][][];
    int maxclans;
    int loadwstat;
    int ncc;
    int champ;
    int leadsby;
    String conclan[];
    int totp[];
    int ord[];
    int nvc[];
    int points[][];
    String verclan[][];
    int eng;
    int engo;
    boolean frkl;
    int underc;
    float bgf;
    boolean bgup;
    int bgx[] = {
        0, 670, 1340
    };
    int flkn;
    int cur;
    int sdist;
    int scro;
    boolean donewc;
    boolean dosrch;
    boolean dorank;
    boolean doweb1;
    boolean doweb2;
    boolean dommsg;
    boolean donemsg;
    int doi;
    int ados;
    int lspos6w;
    long ntime;
    int loadwbgames;
    int warb;
    int gameturn;
    String warbnum;
    String vclan;
    String wbstages[];
    int wbstage[];
    int wblaps[];
    int wbcars[];
    int wbclass[];
    int wbfix[];
    String gameturndisp;
    int ascore;
    int vscore;
    String lwbwinner;
    boolean canredo;
    static soundClip notif;
    int cnotif;
}
