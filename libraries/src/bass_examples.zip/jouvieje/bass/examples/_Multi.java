/*
 * Created on 22 d�c. 07
 */
package jouvieje.bass.examples;

public class _Multi
{

}
