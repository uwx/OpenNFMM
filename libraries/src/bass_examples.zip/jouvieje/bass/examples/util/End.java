package jouvieje.bass.examples.util;

/**
 * @author Jérôme Jouvie (Jouvieje)
 * @site   http://jerome.jouvie.free.fr/
 * @mail   jerome.jouvie@gmail.com
 */
public interface End {
	public void end();
}
